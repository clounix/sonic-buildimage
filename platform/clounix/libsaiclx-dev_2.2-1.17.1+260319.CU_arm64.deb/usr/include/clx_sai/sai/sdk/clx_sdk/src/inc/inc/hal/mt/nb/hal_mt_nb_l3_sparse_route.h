/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_l3_sparse_route.h
 * PURPOSE:
 *      Provide HAL driver API functions for CL8570.
 * NOTES:
 *
 *
 */
#ifndef HAL_MT_NB_L3_SPARSE_RTE_H
#define HAL_MT_NB_L3_SPARSE_RTE_H

/*****************************************************************************
 * INCLUDE FILE DECLARATIONS
 *****************************************************************************
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_swc.h>
#include <clx/clx_l3.h>
#include <clx/clx_l2.h>
#include <util/util.h>
#include <util/lib/util_lib_avl.h>
#include <util/lib/util_lib_list.h>
#include <util/lib/util_lib_bit.h>
#include <util/lib/util_lib_bmp.h>
#include <hal/hal_l3.h>
#include <tob/mt/tbl/tob_mt_tbl.h>
#include <hal/hal_io.h>
#include <hal/hal_swc.h>
#include <hal/hal_lag.h>
#include <tob/mt/tob_mt.h>
#include <hal/mt/nb/hal_mt_nb_swc.h>

/*****************************************************************************
 * NAMING CONSTANT DECLARATIONS
 *****************************************************************************
 */

bool
hal_mt_nb_l3_sparse_route_rim_is_used(const uint32 unit,
                                      const clx_cia_rim_alloc_t type,
                                      const uint32 redir_idx);

clx_error_no_t
hal_mt_nb_l3_sparse_route_usage_get(const uint32 unit, const uint32 param, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_nb_l3_sparse_route_capacity_get(const uint32 unit,
                                       const clx_swc_rsrc_t type,
                                       const uint32 param,
                                       uint32 *ptr_size);

clx_error_no_t
hal_mt_nb_l3_sparse_route_usage_cia_get(const uint32 unit,
                                        const clx_swc_rsrc_t type,
                                        const uint32 param,
                                        uint32 *ptr_cnt);

clx_error_no_t
hal_mt_nb_l3_sparse_route_init(const uint32 unit);

clx_error_no_t
hal_mt_nb_l3_sparse_route_deinit(const uint32 unit);

/* CLX API */
clx_error_no_t
hal_mt_nb_l3_sparse_route_add(const uint32 unit, const clx_l3_route_t *ptr_route);

clx_error_no_t
hal_mt_nb_l3_sparse_route_del(const uint32 unit, const clx_l3_addr_t *ptr_route_addr);

clx_error_no_t
hal_mt_nb_l3_sparse_route_get(const uint32 unit, clx_l3_route_t *ptr_route);

clx_error_no_t
hal_mt_nb_l3_sparse_route_trav(const uint32 unit,
                               const clx_l3_route_trav_func_t cb,
                               void *ptr_cookie);

#endif /* End of HAL_L3_SPARSE_RTE_H */
