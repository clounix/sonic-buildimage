/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_led.h
 * PURPOSE:
 *    Provide HAL driver API functions for CL8400.
 *
 * NOTES:
 *
 */

#ifndef __HAL_MT_KG_LED_H__
#define __HAL_MT_KG_LED_H__

#include <util/util_log.h>
#include <math.h>
#include <hal/hal_port.h>

#define HAL_MT_KG_LED_MASTER_INST (0)
#define HAL_MT_KG_LED_SLAVE_INST  (1)

#define HAL_MT_KG_LED_SERIAL_MAX_NUM           (4)
#define HAL_MT_KG_LED_MAX_LED_BIT_NUM          (1024)
#define HAL_MT_KG_LED_BIT_NUM_WIDTH            (11)
#define HAL_MT_KG_LED_MEM_DEPTH                (1152)
#define HAL_MT_KG_LED_BIT_CTRL_MAX_ADDR        (1024)
#define HAL_MT_KG_LED_BIT_CTRL_LANE_OFFSET     (0)
#define HAL_MT_KG_LED_BIT_CTRL_SPEED_OFFSET    (7)
#define HAL_MT_KG_LED_BIT_CTRL_ADMIN_OFFSET    (22)
#define HAL_MT_KG_LED_BIT_CTRL_LINK_OFFSET     (23)
#define HAL_MT_KG_LED_BIT_CTRL_ACTIVE_OFFSET   (24)
#define HAL_MT_KG_LED_BIT_CTRL_FORCE_OFFSET    (26)
#define HAL_MT_KG_LED_BIT_CTRL_CFG_DATA_OFFSET (6)
#define HAL_MT_KG_LED_LANE_STAT_SPEED_OFFSET   (0)
#define HAL_MT_KG_LED_LANE_STAT_ADMIN_OFFSET   (15)
#define HAL_MT_KG_LED_LANE_STAT_LINK_OFFSET    (16)
#define HAL_MT_KG_LED_LANE_STAT_TX_STAT_OFFSET (17)
#define HAL_MT_KG_LED_LANE_STAT_RX_STAT_OFFSET (18)

typedef enum hal_mt_kg_led_speed_e {
    HAL_MT_KG_LED_SPEED_ABILITY_400GR8 = (1U << 0),          /* 400G R8 */
    HAL_MT_KG_LED_SPEED_ABILITY_200GR4 = (1U << 1),          /* 200G R4 */
    HAL_MT_KG_LED_SPEED_ABILITY_100GR2 = (1U << 2),          /* 100G R2 */
    HAL_MT_KG_LED_SPEED_ABILITY_100GR4 = (1U << 3),          /* 100G R4 */
    HAL_MT_KG_LED_SPEED_ABILITY_50GR1 = (1U << 4),           /* 50G R1 */
    HAL_MT_KG_LED_SPEED_ABILITY_50GR2 = (1U << 5),           /* 50G R2 */
    HAL_MT_KG_LED_SPEED_ABILITY_40GR2 = (1U << 6),           /* 40G R4 */
    HAL_MT_KG_LED_SPEED_ABILITY_40GR4 = (1U << 7),           /* 40G R4 */
    HAL_MT_KG_LED_SPEED_ABILITY_25GR1 = (1U << 8),           /* 25G R1 */
    HAL_MT_KG_LED_SPEED_ABILITY_10GR1 = (1U << 9),           /* 10G R1 */
    HAL_MT_KG_LED_SPEED_ABILITY_SGMII_100MR1 = (1U << 10),   /* 100M R1 */
    HAL_MT_KG_LED_SPEED_ABILITY_USXGMII_5GR1 = (1U << 11),   /* 5G R1 */
    HAL_MT_KG_LED_SPEED_ABILITY_USXGMII_2_5GR1 = (1U << 12), /* 2.5G R1 */
    HAL_MT_KG_LED_SPEED_ABILITY_SGMII_10MR1 = (1U << 13),    /* 10M R1 */
    HAL_MT_KG_LED_SPEED_ABILITY_SGMII_1GR1 = (1U << 14),     /* 1G R1 */
} hal_mt_kg_led_speed_t;

typedef enum hal_mt_kg_led_mode_type_e {
    HAL_MT_KG_LED_MODE_TYPE_NORMAL = 0x0,
    HAL_MT_KG_LED_MODE_TYPE_BIT_ON,
    HAL_MT_KG_LED_MODE_TYPE_BIT_OFF,
    HAL_MT_KG_LED_MODE_TYPE_LAST
} hal_mt_kg_led_mode_type_t;

typedef struct hal_mt_kg_led_mem_data_s {
    uint32 lane_id;
    uint32 speed_ability;
    uint32 admin_en;
    uint32 linkup;
    uint32 active;
    hal_mt_kg_led_mode_type_t force_mode;
    uint32 tx_status;
    uint32 rx_status;
} hal_mt_kg_led_mem_data_t;

clx_error_no_t
hal_mt_kg_led_speed_to_speed_abi_trans(uint32 unit,
                                       uint32 port,
                                       clx_port_speed_t speed,
                                       hal_mt_kg_led_speed_t *led_speed);

clx_error_no_t
hal_mt_kg_led_ctl_led_control_set(uint32 unit, uint32 led_inst, uint32 *buf);

clx_error_no_t
hal_mt_kg_led_ctl_led_control_get(uint32 unit, uint32 led_inst, uint32 *buf);

/**
 * @brief To set led start.
 *
 * Bit0: ecc_single_err_int
 * bit1: ecc_double_err_int
 * write 1 to clear.
 *
 * @param [in]    unit      - Chip id.
 * @param [in]    led_id    - Led id, range 0-3.
 * @param [in]    buf       - Led start bit value.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_led_ctl_led_start_addr_set(uint32 unit, uint32 led_id, uint32 *buf);

/**
 * @brief To get led start bit.
 *
 * @param [in]     unit      - Chip id.
 * @param [in]     led_id    - Led id, range 0-3.
 * @param [out]    buf       - Led start bit value.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_led_ctl_led_start_addr_get(uint32 unit, uint32 led_id, uint32 *buf);

clx_error_no_t
hal_mt_kg_led_ctl_led_end_addr_set(uint32 unit, uint32 led_id, uint32 *buf);

clx_error_no_t
hal_mt_kg_led_ctl_led_end_addr_get(uint32 unit, uint32 led_id, uint32 *buf);

/**
 * @brief To set led memory tod ecc interrupt, write 1 to clear.
 *
 * Bit0: ecc_single_err_int
 * bit1: ecc_double_err_int
 * write 1 to clear.
 *
 * @param [in]    unit    - Chip id.
 * @param [in]    buf     - Led mem tod ecc.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_led_int_led_mem_tod_ecc_set(uint32 unit, uint32 *buf);

clx_error_no_t
hal_mt_kg_led_int_led_mem_tod_ecc_get(uint32 unit, uint32 *buf);

clx_error_no_t
hal_mt_kg_led_int_led_mem_tod_ecc_msk_set(uint32 unit, uint32 *buf);

clx_error_no_t
hal_mt_kg_led_int_led_mem_tod_ecc_msk_get(uint32 unit, uint32 *buf);

clx_error_no_t
hal_mt_kg_led_int_led_mem_tod_ecc_tst_set(uint32 unit, uint32 *buf);

clx_error_no_t
hal_mt_kg_led_int_led_mem_tod_ecc_tst_get(uint32 unit, uint32 *buf);

clx_error_no_t
hal_mt_kg_led_sym_led_mem_top_err_info_get(uint32 unit, uint32 *buf);

clx_error_no_t
hal_mt_kg_led_bit_ctrl_force_mode_set(uint32 unit,
                                      uint32 led_module,
                                      uint32 led_bit,
                                      hal_mt_kg_led_mode_type_t force_mode);
/**
 * @brief To set led bit contrl message.
 *
 * Led memory shared by 4 led modules.
 *
 * @param [in]    unit          - Chip id.
 * @param [in]    led_module    - Led module.
 * @param [in]    led_bit       - Led bit, range 0-2047 -- bit[7:0], lane_id,
 *                                range 0-255 -- bit[21:8], speed ability -- bit[22:22],
 *                                admin_en -- bit[23:23], linkup -- bit[25:24],
 *                                active, 2'b00/11:RXTX, 2'b01:TX, 2'b10:RX -- bit[27:26],
 *                                force_mode, 2'b00/11:actual, 2'b01: on,
 *                                2'b10: off.
 * @param [in]    ptr_data      - Led mem data.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_led_bit_ctrl_set(uint32 unit,
                           uint32 led_module,
                           uint32 led_bit,
                           hal_mt_kg_led_mem_data_t *ptr_data);

/**
 * @brief To set led bit contrl message.
 *
 * Led memory shared by 4 led modules.
 *
 * @param [in]     unit          - Chip id.
 * @param [in]     led_module    - Led module.
 * @param [in]     led_bit       - Led bit, range 0-2047.
 * @param [out]    ptr_data      - Led mem data.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_led_bit_ctrl_get(uint32 unit,
                           uint32 led_module,
                           uint32 led_bit,
                           hal_mt_kg_led_mem_data_t *ptr_data);

clx_error_no_t
hal_mt_kg_led_bit_ctrl_data_set(uint32 unit, uint32 led_module, uint32 led_bit, uint32 *ptr_data);

clx_error_no_t
hal_mt_kg_led_lane_status_speed_set(uint32 unit, uint32 port, clx_port_speed_t speed);

/**
 * @brief To set led lane status.
 *
 * @param [in]    unit        - Chip id.
 * @param [in]    lane_id     - Lane_id, range 0-255.
 * @param [in]    speed       - Speed ability, bit[14:0].
 * @param [in]    admin_en    - Bit[15:15].
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_led_lane_status_set(uint32 unit,
                              uint32 lane_id,
                              hal_mt_kg_led_speed_t speed,
                              uint32 admin_en);

/**
 * @brief To set led lane status.
 *
 * @param [in]     unit          - Chip id.
 * @param [in]     led_module    - Led module.
 * @param [in]     lane_id       - Lane_id, range 0-255.
 * @param [out]    ptr_data      - Led mem data.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_led_lane_status_get(uint32 unit,
                              uint32 led_module,
                              uint32 lane_id,
                              hal_mt_kg_led_mem_data_t *ptr_data);

clx_error_no_t
hal_mt_kg_led_port_led_cfg_get(const uint32 cfg_id, uint32 **pptr_fw, uint32 *ptr_fw_size);

clx_error_no_t
hal_mt_kg_led_mem_init(const uint32 unit);

clx_error_no_t
hal_mt_kg_led_init(const uint32 unit);

#endif
