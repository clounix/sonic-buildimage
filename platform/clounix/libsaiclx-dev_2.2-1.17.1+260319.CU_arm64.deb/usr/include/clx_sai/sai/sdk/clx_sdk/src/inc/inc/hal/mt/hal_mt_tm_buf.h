/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_tm_buf.h
 * PURPOSE:
 *  Traffic Management Buffer Management header file.
 * NOTES:
 *
 */

#ifndef HAL_MT_TM_BUF_H
#define HAL_MT_TM_BUF_H

#include <hal/hal.h>
#include <hal/mt/hal_mt_tm.h>

/*****************************************************************************
 * NAMING CONSTANT DECLARATIONS
 *****************************************************************************
 */
/* The number of ingress queue buf prof */
#define HAL_MT_TM_BUF_IGR_QUEUE_PROF_NUM (16)
/* The number of egress queue buf prof */
#define HAL_MT_TM_BUF_EGR_QUEUE_PROF_NUM (16)
/* egress pool number */
#define HAL_MT_TM_BUF_POOL_NUM (4)
/* The invalid index of buf prof */
#define HAL_MT_TM_BUF_PROF_INVALID_INDEX (0xFFFFFFFF)

#define HAL_MT_TM_BUF_MBURST_PROF_MAX_NUM (16)

#define HAL_MT_TM_BUF_MBURST_INFO_FIFO_SIZE (1024)

typedef struct hal_mt_tm_buf_prof_entry_s {
    boolean is_valid; /* The prof is valid or not */
    uint32 ref_cnt;   /* The prof reference counter */
} hal_mt_tm_buf_prof_entry_t;

typedef struct hal_mt_tm_buf_port_cfg_s {
    uint32 igr_queue_prof_id[HAL_MT_TM_TC_NUM];
    uint32 igr_queue_hw_prof_id[HAL_MT_TM_TC_NUM];
    uint32 *egr_uc_queue_td_prof_id;
    uint32 *egr_uc_queue_wred_prof_id;
    uint32 *egr_uc_queue_hw_prof_id;
    uint32 *egr_uc_queue_mburst_prof_id;
    uint32 egr_mc_queue_td_prof_id[HAL_MT_TM_MULTICAST_QUEUE_NUM];
    uint32 egr_mc_queue_wred_prof_id[HAL_MT_TM_MULTICAST_QUEUE_NUM];
    uint32 egr_mc_queue_hw_prof_id[HAL_MT_TM_MULTICAST_QUEUE_NUM];
    uint32 egr_mc_queue_mburst_prof_id[HAL_MT_TM_MULTICAST_QUEUE_NUM];
} hal_mt_tm_buf_port_cfg_t; /* Buf configure struct of port*/

typedef struct hal_mt_tm_buf_egr_td_s {
    clx_tm_buf_egr_prof_t prof;
} hal_mt_tm_buf_egr_td_t;

typedef struct hal_mt_tm_buf_egr_wred_s {
    clx_tm_wred_prof_t prof;
} hal_mt_tm_buf_egr_wred_t;

typedef struct hal_mt_tm_buf_igr_s {
    clx_tm_buf_igr_prof_t prof;
} hal_mt_tm_buf_igr_t;

typedef struct hal_mt_tm_buf_mburst_prof_s {
    uint32 high_th;
    uint32 low_th;
    uint32 ref_cnt;   /* The prof reference counter */
    boolean is_valid; /* The prof is valid or not */
} hal_mt_tm_buf_mburst_prof_t;

typedef struct hal_mt_tm_buf_mburst_cfg_s {
    boolean enable;
    uint32 report_interval; /* unit: 1024*1024 ns */
} hal_mt_tm_buf_mburst_cfg_t;

typedef struct hal_mt_tm_buf_const_s {
    uint32 egr_queue_buf_prof_num;
    uint32 igr_queue_buf_prof_num;
    uint32 mburst_buf_prof_num;
} hal_mt_tm_buf_const_t;

typedef struct hal_mt_tm_buf_mburst_fifo_s {
    clx_tm_mburst_info_t mburst_info[HAL_MT_TM_BUF_MBURST_INFO_FIFO_SIZE];
    uint32 count;
} hal_mt_tm_buf_mburst_fifo_t;

typedef struct hal_mt_tm_buf_cb_s {
    hal_mt_tm_buf_port_cfg_t port_buf_cfg[CLX_PORT_NUM];
    hal_mt_tm_buf_prof_entry_t igr_queue_prof[HAL_MT_TM_BUF_IGR_QUEUE_PROF_NUM];
    hal_mt_tm_buf_prof_entry_t igr_queue_hw_prof[HAL_MT_TM_BUF_IGR_QUEUE_PROF_NUM];
    hal_mt_tm_buf_prof_entry_t egr_queue_td_prof[HAL_MT_TM_BUF_EGR_QUEUE_PROF_NUM];
    hal_mt_tm_buf_prof_entry_t egr_queue_wred_prof[HAL_MT_TM_BUF_EGR_QUEUE_PROF_NUM];
    hal_mt_tm_buf_prof_entry_t egr_queue_hw_prof[HAL_MT_TM_BUF_EGR_QUEUE_PROF_NUM];
    hal_mt_tm_buf_igr_t sq_prof[HAL_MT_TM_BUF_IGR_QUEUE_PROF_NUM];
    hal_mt_tm_buf_egr_td_t oq_td_prof[HAL_MT_TM_BUF_EGR_QUEUE_PROF_NUM];
    hal_mt_tm_buf_egr_wred_t oq_wred_prof[HAL_MT_TM_BUF_EGR_QUEUE_PROF_NUM];
    hal_mt_tm_buf_mburst_prof_t mburst_prof[HAL_MT_TM_BUF_MBURST_PROF_MAX_NUM];
    hal_mt_tm_buf_mburst_cfg_t mburst_cfg;
    uint32 mburst_prof_num;
} hal_mt_tm_buf_cb_t;

typedef struct hal_mt_tm_buf_egr_pool_th_s {
    uint32 min;    /* Minimum guarantee threshold */
    uint32 mid_th; /* Middle threshold for wred drop or ecn */
    uint32 max_th; /* Maximum threshold for wred drop or ecn */
} hal_mt_tm_buf_egr_pool_th_t;

/* buf prof data info */
extern hal_mt_tm_buf_cb_t _hal_mt_tm_buf_prof_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/* Macro definitions for accessing buf prof data */
#define HAL_MT_TM_BUF_PROF_CB_PTR(unit) &(_hal_mt_tm_buf_prof_cb[unit])

#define HAL_MT_TM_BUF_PORT_CFG_PTR(unit, port) &(_hal_mt_tm_buf_prof_cb[unit].port_buf_cfg[port])

#define HAL_MT_TM_BUF_SQ_PROF_PTR(unit, prof_id) \
    &(_hal_mt_tm_buf_prof_cb[unit].sq_prof[prof_id].prof)

#define HAL_MT_TM_BUF_OQ_TD_PROF_PTR(unit, prof_id) \
    &(_hal_mt_tm_buf_prof_cb[unit].oq_td_prof[prof_id].prof)

#define HAL_MT_TM_BUF_OQ_WRED_PROF_PTR(unit, prof_id) \
    &(_hal_mt_tm_buf_prof_cb[unit].oq_wred_prof[prof_id].prof)

#define HAL_MT_TM_BUF_MBURST_PROF_NUM(unit) (_hal_mt_tm_buf_prof_cb[unit].mburst_prof_num)

#define HAL_MT_TM_BUF_MBURST_PROF_PTR(unit, prof_id) \
    &(_hal_mt_tm_buf_prof_cb[unit].mburst_prof[prof_id])

/*****************************************************************************
 * FUNCTION DECLARATIONS
 *****************************************************************************
 */
clx_error_no_t
hal_mt_tm_buf_mburst_prof_create(const uint32 unit, const uint32 prof_id);

clx_error_no_t
hal_mt_tm_buf_mburst_prof_destroy(const uint32 unit, const uint32 prof_id);

clx_error_no_t
hal_mt_tm_buf_mburst_prof_set(const uint32 unit,
                              const uint32 prof_id,
                              const clx_tm_mburst_prof_t *ptr_prof);
clx_error_no_t
hal_mt_tm_buf_mburst_prof_get(const uint32 unit,
                              const uint32 prof_id,
                              clx_tm_mburst_prof_t *ptr_prof);
clx_error_no_t
hal_mt_tm_buf_mburst_cfg_set(const uint32 unit,
                             const uint32 port,
                             const clx_tm_handler_t handler,
                             const clx_tm_mburst_cfg_t *ptr_mburst_cfg);

clx_error_no_t
hal_mt_tm_buf_mburst_cfg_get(const uint32 unit,
                             const uint32 port,
                             const clx_tm_handler_t handler,
                             clx_tm_mburst_cfg_t *ptr_mburst_cfg);
clx_error_no_t
hal_mt_tm_buf_mburst_cb_register(const uint32 unit,
                                 const clx_tm_mburst_func_t func,
                                 void *ptr_cookie);
clx_error_no_t
hal_mt_tm_buf_mburst_cb_deregister(const uint32 unit,
                                   const clx_tm_mburst_func_t func,
                                   void *ptr_cookie);
clx_error_no_t
hal_mt_tm_buf_mburst_glb_cfg_set(const uint32 unit,
                                 const clx_tm_cfg_type_t type,
                                 const uint32 value);

clx_error_no_t
hal_mt_tm_buf_mburst_glb_cfg_get(const uint32 unit, clx_tm_cfg_type_t type, uint32 *ptr_value);

clx_error_no_t
hal_mt_tm_buf_mburst_fifo_enqueue(const uint32 unit, const clx_tm_mburst_info_t *ptr_mburst_info);

clx_error_no_t
hal_mt_tm_buf_sw_egress_prof_id_get(const uint32 unit,
                                    const uint32 port,
                                    const clx_tm_handler_t handler,
                                    uint32 *ptr_oq_td_prof_id,
                                    uint32 *ptr_oq_wred_prof_id,
                                    uint32 *ptr_oq_hw_prof_id,
                                    uint32 *ptr_oq_mburst_prof_id);

clx_error_no_t
hal_mt_tm_buf_task_init(const uint32 unit);

clx_error_no_t
hal_mt_tm_buf_task_deinit(const uint32 unit);

clx_error_no_t
hal_mt_tm_buf_rsrc_init(const uint32 unit);

clx_error_no_t
hal_mt_tm_buf_rsrc_deinit(const uint32 unit);

uint32
hal_mt_tm_buf_wb_size_get(const uint32 unit);

uint32
hal_mt_tm_buf_wb_init(const uint32 unit, hal_io_obj_meta_t *ptr_obj);

uint32
hal_mt_tm_buf_wb_deinit(const uint32 unit, hal_io_obj_meta_t *ptr_obj);

uint32
hal_mt_tm_buf_port_uc_queue_num_get(const uint32 unit, const uint32 port);

#endif /* End of HAL_MT_TM_H */
