/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_tm_tcb.h
 * PURPOSE:
 * NOTES:
 *
 */

#ifndef HAL_MT_TM_TCB_H
#define HAL_MT_TM_TCB_H

#include <hal/hal.h>

/*****************************************************************************
 * NAMING CONSTANT DECLARATIONS
 *****************************************************************************
 */

#define HAL_MT_TM_TCB_SUB_SLC_BMP_NUM (4)
#define HAL_MT_TM_TCB_CB_NUM          (3)
#define HAL_MT_TM_TCB_PLANE_NUM       (8)

typedef struct hal_mt_tm_tcb_callback_s {
    clx_tm_tcb_func_t callback;
    void *ptr_cookie;
} hal_mt_tm_tcb_callback_t;

typedef struct hal_mt_tm_tcb_cb_s {
    /* data */
    clx_tm_tcb_match_t match;
    hal_mt_tm_tcb_callback_t callback_list[HAL_MT_TM_TCB_CB_NUM];
    uint32 act_pdb_bmp;
    uint32 act_plane_bmp[1];
    uint32 sub_slc_bmp[HAL_MT_TM_TCB_SUB_SLC_BMP_NUM];
    uint32 trig_pos;
    clx_tm_tcb_op_type_t op;
} hal_mt_tm_tcb_cb_t;

hal_mt_tm_tcb_cb_t *
hal_mt_tm_tcb_cb_get(const uint32 unit);

clx_error_no_t
hal_mt_tm_tcb_match_set(const uint32 unit,
                        const clx_tm_tcb_match_type_t type,
                        const clx_tm_tcb_match_t *ptr_match);

clx_error_no_t
hal_mt_tm_tcb_match_get(const uint32 unit,
                        const clx_tm_tcb_match_type_t type,
                        clx_tm_tcb_match_t *ptr_match);

clx_error_no_t
hal_mt_tm_tcb_cfg_set(const uint32 unit, const clx_tm_tcb_cfg_type_t type, const uint32 value);

clx_error_no_t
hal_mt_tm_tcb_cfg_get(const uint32 unit, const clx_tm_tcb_cfg_type_t type, uint32 *ptr_value);

clx_error_no_t
hal_mt_tm_tcb_cb_register(const uint32 unit, const clx_tm_tcb_func_t func, void *ptr_cookie);

clx_error_no_t
hal_mt_tm_tcb_cb_deregister(const uint32 unit, const clx_tm_tcb_func_t func, void *ptr_cookie);

clx_error_no_t
hal_mt_tm_tcb_rsrc_init(const uint32 unit);

clx_error_no_t
hal_mt_tm_tcb_rsrc_deinit(const uint32 unit);

clx_error_no_t
hal_mt_tm_tcb_wb_init(const uint32 unit);

clx_error_no_t
hal_mt_tm_tcb_wb_deinit(const uint32 unit);

#endif /* End of HAL_MT_TM_TCB_H */
