/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_RPFGROUP_H__)
#define __CLX_SAI_RPFGROUP_H__

#define CLXS_RPFGRP_CB(unit) (g_clxs_rpfgrp_db[unit])

#define CLXS_RPFGRP_LOCK(unit) \
    osal_semaphore_take(&g_clxs_rpfgrp_db[unit]->sema, CLX_SEMAPHORE_WAIT_FOREVER);

#define CLXS_RPFGRP_UNLOCK(unit) \
    osal_semaphore_give(&g_clxs_rpfgrp_db[unit]->sema);

/*******************************************************************************
* Data Type Definitions
 *******************************************************************************/
typedef struct
{
    util_lib_list_t            *ptr_member_list; /* member list */
} clxs_rpfgrp_grp_entry_t;

typedef struct
{
    uint32                        intf_id;
    clxs_rpf_group_member_attrs_t attr_info;
} clxs_rpfgrp_member_entry_t;

typedef struct
{
    /* group */
    uint32_t                *ptr_rpfgrp_grp_bmp;
    clxs_rpfgrp_grp_entry_t  *ptr_rpfgrp_grp;
    /* member */
    uint32_t                  *ptr_rpfgrp_member_bmp;
    clxs_rpfgrp_member_entry_t *ptr_rpfgrp_member;
    clx_semaphore_id_t      sema;
} clxs_rpfgrp_db_t;

/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_rpf_group_api_t        rpfgroup_api;

/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t clxs_rpfgrp_get_grp_info(
    _In_  sai_object_id_t   obj_id,
    _Out_ uint32_t          *ptr_unit,
    _Out_ clx_ip_addr_t     *ptr_ip,
    _Out_ uint32_t          *ptr_cnt,
    _Out_ uint32_t          *ptr_grp_id);

sai_status_t clxs_rpfgrp_get_obj_by_ip(
    _In_   clx_ip_addr_t    *ptr_ip,
    _In_   uint32_t         unit,
    _Out_  sai_object_id_t  *ptr_obj_id);

sai_status_t clxs_rpfgrp_init(
    const uint32_t    unit);

sai_status_t clxs_rpfgrp_deinit(
    const uint32_t    unit);

sai_status_t clxs_get_rpf_object_count(
    _In_ const uint32_t unit,
    _In_ uint32_t  type,
    _Out_ uint32_t *count);

#endif /* __CLX_SAI_RPFGROUP_H__ */
