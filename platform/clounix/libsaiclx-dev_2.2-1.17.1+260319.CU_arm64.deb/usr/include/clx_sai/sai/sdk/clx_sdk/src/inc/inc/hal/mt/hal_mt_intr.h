/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_intr.h
 * PURPOSE:
 *      1. hal_mt_intr.h provides HAL ISR manipulation APIs.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_INTR_H
#define HAL_MT_INTR_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_intr.h>
#include <drv/drv.h>

#include <hal/hal.h>
#include <util/lib/util_lib_queue.h>

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MT_INTR_GET_INTR_FUNC_PTR(unit) (hal_mt_intr_func[unit])

#define HAL_MT_INTR_VEC_CHAIN24      (24)
#define HAL_MT_INTR_VEC_CHAIN25      (25)
#define HAL_MT_INTR_VEC_CHAIN29      (29)
#define HAL_MT_INTR_VEC_CHAIN31      (31)
#define HAL_MT_INTR_MASK_UMAC0       (0)
#define HAL_MT_INTR_MASK_UMAC1       (1)
#define HAL_MT_INTR_MAX_CAHIN_SIZE   (32)
#define HAL_MT_INTR_MAX_SLAVE_SIZE   (32)
#define HAL_MT_INTR_CHAIN29_CMAC_SLV (16)

#define HAL_MT_INTR_QUEUE_MAX_CNT (100)

#define HAL_MT_INTR_STAT_MASKED   (1)
#define HAL_MT_INTR_STAT_UNMASKED (0)

typedef enum hal_mt_intr_type_e {
    /* PL per slice chains */
    HAL_INTR_TYPE_IPL_SLV,
    HAL_INTR_TYPE_IPL_DP_SLV,
    HAL_INTR_TYPE_IPL_APP_SLV,
    HAL_INTR_TYPE_LBM_SLV,
    HAL_INTR_TYPE_EPL_APP_SLV,
    HAL_INTR_TYPE_EPL_DP_SLV,
    HAL_INTR_TYPE_EPL_SLV,

    /* PP per slice chains */
    HAL_INTR_TYPE_TDS_SLV,
    HAL_INTR_TYPE_DIS_SLV,
    HAL_INTR_TYPE_CNT_SLV,
    HAL_INTR_TYPE_MTR_SLV,
    HAL_INTR_TYPE_RWO_SLV,
    HAL_INTR_TYPE_RWI_SLV,
    HAL_INTR_TYPE_FWR_SLV,

    /* PP FPU share */
    HAL_INTR_TYPE_FPUHSH_SLV,
    HAL_INTR_TYPE_FPUTCAM_SLV,
    HAL_INTR_TYPE_FPUMISC_SLV,
    HAL_INTR_TYPE_FPUMEM_SLV,

    /* PP CIA share */
    HAL_INTR_TYPE_ICIA_SLV,
    HAL_INTR_TYPE_ECIA_SLV,
    HAL_INTR_TYPE_CIAT_SLV,

    /* TM per slice chains */
    HAL_INTR_TYPE_ASM_SLV,
    HAL_INTR_TYPE_REP_SLV,
    HAL_INTR_TYPE_BAC_SLV,
    HAL_INTR_TYPE_DQC_SLV,
    HAL_INTR_TYPE_OQC_SLV,
    HAL_INTR_TYPE_FRG_SLV,
    HAL_INTR_TYPE_SCH_SLV,

    /* TM module share */
    HAL_INTR_TYPE_PDB_QUAD_SLV,
    HAL_INTR_TYPE_PDB_CENTER_SLV,
    HAL_INTR_TYPE_PPL_SLV,
    HAL_INTR_TYPE_MCDB_SLV,
    HAL_INTR_TYPE_BAC_TOP_SLV,
    HAL_INTR_TYPE_OQC_TOP_SLV,
    HAL_INTR_TYPE_DQC_TOP_SLV,
    HAL_INTR_TYPE_PDM_SLV,
    HAL_INTR_TYPE_PDM_EME_SLV,

    /* UMAC */
    HAL_INTR_TYPE_UMAC_SLV, /* UMAC_WRAP && UMAC_AXI*/
    HAL_INTR_TYPE_PHY_WRAP_SLV,

    /* PCX */
    HAL_INTR_TYPE_TOP_SLV,
    HAL_INTR_TYPE_PDMA_SLV,
    HAL_INTR_TYPE_TOD_SLV,
    HAL_INTR_TYPE_ECPU_SLV,
    HAL_INTR_TYPE_PLDA_SLV,
    HAL_INTR_TYPE_PHY_SLV,

    HAL_INTR_TYPE_CMAC_SLV, /* CMAC_WRAP && CMAC_AXI*/
    HAL_INTR_TYPE_CMAC_PHY_SLV,

    HAL_INTR_TYPE_SLV_LAST,

    HAL_INTR_TYPE_START = HAL_INTR_TYPE_SLV_LAST,
    HAL_INTR_TYPE_PDMA_NORMAL = HAL_INTR_TYPE_START,
    HAL_INTR_TYPE_PDMA_RX_FIFO0,
    HAL_INTR_TYPE_PDMA_RX_FIFO1,
    HAL_INTR_TYPE_PDMA_RX_FIFO2,
    HAL_INTR_TYPE_PDMA_RX_FIFO3,
    HAL_INTR_TYPE_PDMA_TX_FIFO0,
    HAL_INTR_TYPE_PDMA_TX_FIFO1,
    HAL_INTR_TYPE_PDMA_TX_FIFO2,
    HAL_INTR_TYPE_PDMA_TX_FIFO3,
    HAL_INTR_TYPE_PDMA_GENERAL,
    HAL_INTR_TYPE_PDMA_L2_FIFO,
    HAL_INTR_TYPE_PDMA_IOAM_FIFO,
    HAL_INTR_TYPE_PDMA_ECPU_TX_FIFO,
    HAL_INTR_TYPE_PDMA_ECPU_RX_FIFO,
    HAL_INTR_TYPE_PDMA_ERR,
    HAL_INTR_TYPE_DRV_IO_ERR,
    HAL_INTR_TYPE_PORT_ANLT_LINK_GOOD,
    HAL_INTR_TYPE_PORT_ANLT_AN_DONE,
    HAL_INTR_TYPE_PORT_ANLT_AN_NEWPAGE,
    HAL_INTR_TYPE_PORT_ANLT_FSM_MON,
    HAL_INTR_TYPE_TDS_SLV_ECC,
    HAL_INTR_TYPE_DIS_SLV_ECC,
    HAL_INTR_TYPE_FPUMEM_SLV_ECC,
    HAL_INTR_TYPE_FPUHSH_SLV_ECC,
    HAL_INTR_TYPE_FWR_SLV_ECC,
    HAL_INTR_TYPE_RWI_SLV_ECC,
    HAL_INTR_TYPE_RWO_SLV_ECC,
    HAL_INTR_TYPE_MTR_SLV_ECC,
    HAL_INTR_TYPE_CNT_SLV_ECC,
    HAL_INTR_TYPE_ICIA_SLV_ECC,
    HAL_INTR_TYPE_ECIA_SLV_ECC,
    HAL_INTR_TYPE_CIAT_SLV_ECC,
    HAL_INTR_TYPE_ASM_SLV_ECC,
    HAL_INTR_TYPE_BAC_SLV_ECC,
    HAL_INTR_TYPE_BAC_TOP_SLV_ECC,
    HAL_INTR_TYPE_DQC_SLV_ECC,
    HAL_INTR_TYPE_MCDB_SLV_ECC,
    HAL_INTR_TYPE_OQC_SLV_ECC,
    HAL_INTR_TYPE_OQC_TOP_SLV_ECC,
    HAL_INTR_TYPE_PDB_QUAD_SLV_ECC,
    HAL_INTR_TYPE_DQC_TOP_SLV_ECC,
    HAL_INTR_TYPE_PPL_SLV_ECC,
    HAL_INTR_TYPE_FRG_SLV_ECC,
    HAL_INTR_TYPE_PDM_SLV_ECC,
    HAL_INTR_TYPE_PDM_EME_SLV_ECC,
    HAL_INTR_TYPE_UMAC_SLV_ECC,
    HAL_INTR_TYPE_REP_SLV_ECC,
    HAL_INTR_TYPE_SCH_SLV_ECC,
    HAL_INTR_TYPE_IPL_SLV_ECC,
    HAL_INTR_TYPE_IPL_APP_SLV_ECC,
    HAL_INTR_TYPE_IPL_DP_SLV_ECC,
    HAL_INTR_TYPE_EPL_SLV_ECC,
    HAL_INTR_TYPE_EPL_APP_SLV_ECC,
    HAL_INTR_TYPE_EPL_DP_SLV_ECC,
    HAL_INTR_TYPE_LBM_SLV_ECC,
    HAL_INTR_TYPE_PDB_CENTER_SLV_ECC,
    HAL_INTR_TYPE_RWI_SLV_TELM_HDR,
    HAL_INTR_TYPE_IFMON,
    HAL_INTR_TYPE_COMMON_THREAD_TYPE,
    HAL_INTR_TYPE_TM_PFCWD,
    HAL_INTR_TYPE_PDB_TCB_DONE,
    HAL_INTR_TYPE_BAC_SLV_GENERAL,

    /* health event report */
    HAL_INTR_TYPE_BAC_TOP_GENERAL,
    HAL_INTR_TYPE_BAC_GENERAL,
    HAL_INTR_TYPE_OQC_TOP_LA_DONE,
    HAL_INTR_TYPE_REP_ABNORMAL,

    HAL_INTR_TYPE_RWI_RWX_LATENCY,
    HAL_INTR_TYPE_RWO_SLV_RWO_IRQ,

    /* kg */
    HAL_INTR_TYPE_CLX_DDC_SLV,
    HAL_INTR_TYPE_CLX_DDC_SLV_ECC,
    HAL_INTR_TYPE_CLX_TOD_UMAC_WRAP_SLV,
    HAL_INTR_TYPE_CLX_UMAC_WRAP_SLV,
    HAL_INTR_TYPE_CLX_UMAC_WRAP_SLV_ECC,
    HAL_INTR_TYPE_DDA_SLV,
    HAL_INTR_TYPE_DDA_SLV_ECC,
    HAL_INTR_TYPE_DISMEM_SLV,
    HAL_INTR_TYPE_DISMEM_SLV_ECC,
    HAL_INTR_TYPE_ECPU_SLV_ECC,
    HAL_INTR_TYPE_EPL_CMN_SLV,
    HAL_INTR_TYPE_EPL_CMN_SLV_ECC,
    HAL_INTR_TYPE_EPL_PIPE_SLV,
    HAL_INTR_TYPE_EPL_PIPE_SLV_ECC,
    HAL_INTR_TYPE_EQC_PDE_SLV,
    HAL_INTR_TYPE_EQC_PDE_SLV_ECC,
    HAL_INTR_TYPE_EQC_SLV,
    HAL_INTR_TYPE_EQC_SLV_ECC,

    HAL_INTR_TYPE_IPL_CMN_SLV,
    HAL_INTR_TYPE_IPL_PIPE_SLV,
    HAL_INTR_TYPE_IQC_SLV,
    HAL_INTR_TYPE_IQC_SLV_ECC,

    HAL_INTR_TYPE_NFE_SLV,
    HAL_INTR_TYPE_NFE_SLV_ECC,
    HAL_INTR_TYPE_PCIE_SLV,

    HAL_INTR_TYPE_PDE_SLV,
    HAL_INTR_TYPE_PDE_SLV_ECC,
    HAL_INTR_TYPE_PDMA_SLV_ECC,
    HAL_INTR_TYPE_PHY_WRAP_SLV_ECC,
    HAL_INTR_TYPE_TOD_SLV_ECC,
    HAL_INTR_TYPE_TOP_SLV_ECC,
    HAL_INTR_TYPE_UMAC_WRAP_SLV,
    HAL_INTR_TYPE_UMAC_WRAP_SLV_ECC,
    HAL_INTR_TYPE_PDMA_NFE_FIFO,
    HAL_INTR_TYPE_LT_FAILURE,
    HAL_INTR_TYPE_IPL_PIPE_SLV_ECC,

    HAL_INTR_TYPE_LAST
} hal_mt_intr_type_t;

typedef struct hal_mt_intr_reg_node_s {
    hal_mt_intr_type_t intr_type;

    uint32 inst_idx;
    uint32 subinst_idx;

    uint32 stat_reg; /* intr reg id, such as MT_NB_REG_TDS_SLV_TDS_TIMEOUT_IRQ_ID */
    uint32 mask_reg;
    uint32 clr_reg;
    uint32 test_reg;
} hal_mt_intr_reg_node_t;

typedef struct hal_mt_intr_handler_ctx_s {
    hal_mt_intr_reg_node_t reg_info;              /* reg node info */
    uint32 stat_reg_val[HAL_MAX_ENTRY_WORD_SIZE]; /* stat_reg value in reg_info */
} hal_mt_intr_handler_ctx_t;

typedef clx_error_no_t (*hal_mt_intr_isr_handle_func_t)(const uint32 unit, void *ptr_cookie);

typedef struct hal_mt_intr_thread_ctx_s {
    clx_thread_id_t thread_id[HAL_INTR_TYPE_LAST];              /* thread id */
    hal_mt_intr_isr_handle_func_t callback[HAL_INTR_TYPE_LAST]; /* callback function */
    util_lib_queue_t *ptr_queue_head[HAL_INTR_TYPE_LAST]; /* hal_mt_intr_reg_node_t node queue head
                                                           */
    volatile boolean is_deinit; /* deinit flag to prevent enqueue during deinit */
} hal_mt_intr_thread_ctx_t;

typedef struct hal_mt_intr_node_s {
    hal_mt_intr_reg_node_t reg_info;
    hal_mt_intr_isr_handle_func_t intr_handle_func;
    const struct hal_mt_intr_node_s *next;
} hal_mt_intr_node_t;

/* Callback Functions for IRQ related registers R/W */
typedef clx_error_no_t (*hal_mt_intr_read_func_t)(const uint32 unit,
                                                  uint32 *ptr_reg_val,
                                                  uint32 *word_size,
                                                  const hal_mt_intr_reg_node_t intr_node);

typedef clx_error_no_t (*hal_mt_intr_read_mask_func_t)(const uint32 unit,
                                                       uint32 *ptr_reg_val,
                                                       const hal_mt_intr_reg_node_t intr_node);

typedef clx_error_no_t (*hal_mt_intr_write_func_t)(const uint32 unit,
                                                   uint32 *reg_val,
                                                   hal_mt_intr_reg_node_t intr_node);

typedef clx_error_no_t (*hal_mt_intr_type_write_func_t)(const uint32 unit,
                                                        const hal_mt_intr_type_t intr_type);

typedef clx_error_no_t (*hal_mt_intr_chain_unmask_func_t)(const uint32 unit, const uint32 reg_val);

typedef clx_error_no_t (*hal_mt_intr_dump_func_t)(const uint32 unit);

typedef struct hal_mt_intr_vec_s {
    uint32 slave;
    uint32 inst_idx;
    uint32 subinst_idx;
    const hal_mt_intr_node_t *slave_head;
} hal_mt_intr_vec_t;

typedef struct hal_mt_intr_func_s {
    hal_mt_intr_read_func_t intr_read_stat;
    hal_mt_intr_write_func_t intr_set;
    hal_mt_intr_write_func_t intr_clear;
    hal_mt_intr_read_mask_func_t intr_read_mask;
    hal_mt_intr_write_func_t intr_mask;
    hal_mt_intr_write_func_t intr_unmask;
    hal_mt_intr_type_write_func_t intr_type_unmask;
    hal_mt_intr_type_write_func_t intr_type_mask;
    hal_mt_intr_chain_unmask_func_t intr_umac_unmask;
    hal_mt_intr_dump_func_t intr_dump;
} hal_mt_intr_func_t;

/* Interrupt control blocks */
typedef struct hal_mt_intr_cb_s {
    clx_isrlock_id_t spin_lock[HAL_INTR_TYPE_LAST];   /* lock the intr reg operation */
    clx_irq_flags_t irq_flag[HAL_INTR_TYPE_LAST];     /* irq_flag for spin_lock */
    clx_semaphore_id_t sync_sema[HAL_INTR_TYPE_LAST]; /* notify the bottom half handler */
    uint32 sync_sema_cntr[HAL_INTR_TYPE_LAST];        /* the intr count */

    /* for mask/unmask intr status sw table */
    uint32 intr_masked_stat[HAL_INTR_TYPE_LAST];    /* the intr status: HAL_MT_INTR_STAT_MASKED or
                                                       HAL_MT_INTR_STAT_UNMASKED */
    clx_semaphore_id_t sw_lock[HAL_INTR_TYPE_LAST]; /* lock the intr status */
    boolean curr_on_intr[HAL_INTR_TYPE_LAST];       /* the current on interrupt */
} hal_mt_intr_cb_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* -------------------------------------- Init and deinit */
clx_error_no_t
hal_mt_intr_init(const uint32 unit);

clx_error_no_t
hal_mt_intr_deinit(const uint32 unit);

clx_error_no_t
hal_mt_intr_cfg_init(const uint32 unit);

clx_error_no_t
hal_mt_intr_cfg_deinit(const uint32 unit);

/* -------------------------------------- Reg operation */
clx_error_no_t
hal_mt_intr_read(const uint32 unit,
                 uint32 *reg_val,
                 uint32 *word_size,
                 const hal_mt_intr_reg_node_t intr_node);

clx_error_no_t
hal_mt_intr_mask(const uint32 unit, uint32 *reg_val, const hal_mt_intr_reg_node_t intr_node);

clx_error_no_t
hal_mt_intr_clear(const uint32 unit, uint32 *reg_val, const hal_mt_intr_reg_node_t intr_node);

clx_error_no_t
hal_mt_intr_unmask(const uint32 unit, uint32 *reg_val, const hal_mt_intr_reg_node_t intr_node);

clx_error_no_t
hal_mt_intr_type_unmask(const uint32 unit, const hal_mt_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_umac_unmask(const uint32 unit, const uint32 reg_val);

clx_error_no_t
hal_mt_intr_type_mask(const uint32 unit, const hal_mt_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_dump(const uint32 unit);

/* -------------------------------------- API and callbacks */
clx_error_no_t
hal_mt_intr_irq_request(const uint32 unit,
                        hal_mt_intr_type_t intr_type,
                        hal_mt_intr_isr_handle_func_t handler);

clx_error_no_t
hal_mt_intr_event_trigger(const uint32 unit, const hal_mt_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_event_reg_trigger(const uint32 unit, void *ptr_cookie);

clx_error_no_t
hal_mt_intr_common_event_trigger(const uint32 unit, void *ptr_cookie);

clx_error_no_t
hal_mt_intr_event_wait(const uint32 unit, const hal_mt_intr_type_t intr_type, const uint32 timeout);

clx_error_no_t
hal_mt_intr_spinlock_take(const uint32 unit, const hal_mt_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_spinlock_give(const uint32 unit, const hal_mt_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_ifmon_event_wait(const uint32 unit, const uint32 timeout);

clx_error_no_t
hal_mt_intr_event_cnt_get(const uint32 unit, const hal_mt_intr_type_t intr_type, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_intr_event_cnt_incr(const uint32 unit, const hal_mt_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_event_cnt_clear(const uint32 unit, const hal_mt_intr_type_t intr_type);

const char *
hal_mt_intr_event_string_get(const uint32 unit, const hal_mt_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_enable_get(const uint32 unit, const uint32 intr_type, boolean *ptr_enable);

clx_error_no_t
hal_mt_intr_enable_set(const uint32 unit, const uint32 intr_type, const boolean enable);

uint32
hal_mt_intr_sw_mask_stat_get(const uint32 unit, const hal_mt_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_sw_tbl_lock(const uint32 unit, const hal_mt_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_sw_tbl_unlock(const uint32 unit, const hal_mt_intr_type_t intr_type);

boolean
hal_mt_intr_cur_on_intr_get(const uint32 unit, const hal_mt_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_cur_on_intr_set(const uint32 unit,
                            const hal_mt_intr_type_t intr_type,
                            const boolean on_intr);

clx_error_no_t
hal_mt_intr_irq_thread_register(const uint32 unit,
                                const boolean create_thread,
                                hal_mt_intr_type_t intr_type,
                                hal_mt_intr_isr_handle_func_t handler);

clx_error_no_t
hal_mt_intr_dequeue(const uint32 unit,
                    const hal_mt_intr_type_t intr_type,
                    hal_mt_intr_reg_node_t *ptr_intr_node);
#endif /* #ifndef HAL_MT_INTR_H */
