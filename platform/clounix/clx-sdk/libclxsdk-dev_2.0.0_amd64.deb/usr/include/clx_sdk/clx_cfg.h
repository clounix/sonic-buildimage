/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:   clx_cfg.h
 * PURPOSE:
 *      Customer configuration on CLX SDK.
 * NOTES:
 */

#ifndef CLX_CFG_H
#define CLX_CFG_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_types.h>
#include <clx_error.h>


/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM    (16)
#define CLX_CFG_USER_PORT_NUM               (96)

/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    CLX_CFG_TYPE_CHIP_MODE,                  /* chip operating mode. 0: legacy mode, 1:hybrid mode */

    CLX_CFG_TYPE_PORT_MAX_SPEED,             /* Reference to CLX_PORT_SPEED_XXX */
    CLX_CFG_TYPE_PORT_LANE_NUM,              /* Port lane mumber */
    CLX_CFG_TYPE_PORT_TX_LANE,               /* Port tx lane */
    CLX_CFG_TYPE_PORT_RX_LANE,               /* Port rx lane */
    CLX_CFG_TYPE_PORT_TX_POLARITY_REV,       /* Port tx polarity reserve */
    CLX_CFG_TYPE_PORT_RX_POLARITY_REV,       /* Port rx polarity reserve */
    CLX_CFG_TYPE_PORT_EXT_LANE,              /* Port extencd lane */
    CLX_CFG_TYPE_PORT_VALID,                 /* Port valid */

    /* l2 module related configuration */
    CLX_CFG_TYPE_L2_THREAD_PRI,              /* L2 thread priority */
    CLX_CFG_TYPE_L2_THREAD_STACK,            /* customize L2 thread stack size in bytes */
    CLX_CFG_TYPE_L2_ADDR_MODE,               /* L2 address operation mode. 0: Polling mode, 1: FIFO mode */
    CLX_CFG_TYPE_L2_TRAVERSE_THREAD_PRI,     /* L2 traverse thread priority for non blocking mode */
    CLX_CFG_TYPE_L2_TRAVERSE_THREAD_STACK,   /* customize L2 thread stack size in bytes for non blocking mode */

    /* PKT module related configuration */
    CLX_CFG_TYPE_PKT_TX_GPD_NUM,             /* Tx GPD (General Packet Descriptor) number */
    CLX_CFG_TYPE_PKT_RX_GPD_NUM,             /* Rx GPD (General Packet Descriptor) number */
    CLX_CFG_TYPE_PKT_RX_SCHED_MODE,          /* 0: RR mode, 1: WRR mode                   */
    CLX_CFG_TYPE_PKT_TX_QUEUE_LEN,           /* Initialize Tx GPD-queue (of first SW-GPD) length */
    CLX_CFG_TYPE_PKT_RX_QUEUE_LEN,           /* Initialize Rx GPD-queue (of first SW-GPD) length */
    CLX_CFG_TYPE_PKT_RX_QUEUE_WEIGHT,        /* valid while CLX_CFG_TYPE_PKT_RX_SCHED_MODE is 1
                                              * param0: queue
                                              * param1: NA
                                              * value : weight
                                              */
    CLX_CFG_TYPE_PKT_RX_ISR_THREAD_PRI,       /* Packet receive thread priority */
    CLX_CFG_TYPE_PKT_RX_ISR_THREAD_STACK,     /* customize PKT RX ISR thread stack size in bytes */
    CLX_CFG_TYPE_PKT_RX_FREE_THREAD_PRI,      /* Packet receive free thread priority */
    CLX_CFG_TYPE_PKT_RX_FREE_THREAD_STACK,    /* customize PKT RX free thread stack size in bytes */
    CLX_CFG_TYPE_PKT_TX_ISR_THREAD_PRI,       /* Packet transmit thread priority */
    CLX_CFG_TYPE_PKT_TX_ISR_THREAD_STACK,     /* customize PKT TX ISR thread stack size in bytes */
    CLX_CFG_TYPE_PKT_TX_FREE_THREAD_PRI,      /* Packet transmit free thread priority */
    CLX_CFG_TYPE_PKT_TX_FREE_THREAD_STACK,    /* customize PKT TX free thread stack size in bytes */
    CLX_CFG_TYPE_PKT_ERROR_ISR_THREAD_PRI,    /* Pakcet error thread priority */
    CLX_CFG_TYPE_PKT_ERROR_ISR_THREAD_STACK,  /* customize PKT ERROR ISR thread stack size in bytes */

    /* STAT module related configuration */
    CLX_CFG_TYPE_CNT_THREAD_PRI,            /* Counter thread priority */
    CLX_CFG_TYPE_CNT_THREAD_STACK,          /* customize CNT thread stack size in bytes */
    CLX_CFG_TYPE_CNT_POLLING_INTERVAL,      /* STAT polling interval */

    /* IFMON module related configuration */
    CLX_CFG_TYPE_IFMON_THREAD_PRI,          /* Interface monitor thread priority */
    CLX_CFG_TYPE_IFMON_THREAD_STACK,        /* customize IFMON thread stack size in bytes */

    /* share memory related configuration */
    CLX_CFG_TYPE_SHARE_MEM_SDN_ENTRY_NUM,   /* SDN flow table entry number from share memory */
    CLX_CFG_TYPE_SHARE_MEM_L3_ENTRY_NUM,    /* L3 entry number from share memory */
    CLX_CFG_TYPE_SHARE_MEM_L2_ENTRY_NUM,    /* L2 entry number from share memory */

    /* DLB related configuration */
    CLX_CFG_TYPE_DLB_MONITOR_MODE,          /* DLB monitor mode. 1: async, 0: sync */
    CLX_CFG_TYPE_DLB_LAG_MONITOR_THREAD_PRI,            /* dlb lag monitor thread pri         */
    CLX_CFG_TYPE_DLB_LAG_MONITOR_THREAD_SLEEP_TIME,     /* dlb lag monitor thread sleep time  */
    CLX_CFG_TYPE_DLB_L3_MONITOR_THREAD_PRI,             /* dlb l3 monitor thread pri          */
    CLX_CFG_TYPE_DLB_L3_MONITOR_THREAD_SLEEP_TIME,      /* dlb l3 monitor thread sleep time   */
    CLX_CFG_TYPE_DLB_L3_INTR_THREAD_PRI,                /* dlb l3 intr thread pri             */
    CLX_CFG_TYPE_DLB_NVO3_MONITOR_THREAD_PRI,           /* dlb nvo3 monitor thread pri        */
    CLX_CFG_TYPE_DLB_NVO3_MONITOR_THREAD_SLEEP_TIME,    /* dlb nvo3 monitor thread sleep time */
    CLX_CFG_TYPE_DLB_NVO3_INTR_THREAD_PRI,              /* dlb nvo3 intr thread pri           */

    /* l3 related configuration */
    CLX_CFG_TYPE_L3_ECMP_MIN_BLOCK_SIZE,                                /* config each ecmp group member min number, not use            */
    CLX_CFG_TYPE_L3_ECMP_BLOCK_SIZE,                                    /* config each ecmp group member max number                     */
    CLX_CFG_TYPE_TCAM_L3_WITH_IPV6_PREFIX_128_REGION_ENTRY_NUM,         /* Tcam ipv6 4x resource, ipv4 1x can use this resource         */
    CLX_CFG_TYPE_TCAM_L3_WITH_IPV6_PREFIX_64_REGION_ENTRY_NUM,          /* Tcam ipv6 2x resource, ipv4 1x can use this resource         */

    /* share memory related configuration */
    CLX_CFG_TYPE_HASH_L2_FDB_REGION_ENTRY_NUM,                          /* l2 fdb share memory resource                                 */
    CLX_CFG_TYPE_HASH_L2_GROUP_REGION_ENTRY_NUM,                        /* l2 group share memory resource                               */
    CLX_CFG_TYPE_HASH_SECURITY_REGION_ENTRY_NUM,                        /* security share memory resource                               */
    CLX_CFG_TYPE_HASH_L3_WITH_IPV6_PREFIX_128_REGION_ENTRY_NUM,         /* hash ipv6 4x route resource, ipv4 1x can use this resource   */
    CLX_CFG_TYPE_HASH_L3_WITH_IPV6_PREFIX_64_REGION_ENTRY_NUM,          /* hash ipv6 2x route resource, ipv4 1x can use this resource   */
    CLX_CFG_TYPE_HASH_L3_WITHOUT_PREFIX_REGION_ENTRY_NUM,               /* hash 1x resource, ipv6 use 4x, ipv4 use 1x                   */
    CLX_CFG_TYPE_HASH_FLOW_REGION_ENTRY_NUM,                            /* flow share memory resource                                   */

    CLX_CFG_TYPE_PORT_FC_MODE,                 /* (Not support for CL8360 and CL8570) only use to init port TM buffer
                                                * configuration for specific FC mode,
                                                * which not enable/disable FC/PFC
                                                * for the port/pcp.
                                                * param0: port.
                                                * param1: Invalid.
                                                * value : 0, FC disable;
                                                *         1, 802.3x FC;
                                                *         2, PFC.
                                                */
    CLX_CFG_TYPE_PORT_PFC_STATE,               /* valid while CLX_CFG_TYPE_PORT_TYPE_FC_MODE
                                                * of the port is PFC.
                                                * param0: port.
                                                * param1: pcp.
                                                * value : 0, PFC disable;
                                                *         1, PFC enable.
                                                */
    CLX_CFG_TYPE_PORT_PFC_QUEUE_STATE,         /* valid while CLX_CFG_TYPE_PORT_TYPE_FC_MODE
                                                * of the port is PFC.
                                                * param0: port.
                                                * param1: queue.
                                                * value : 0, PFC disable;
                                                *         1, PFC enable;
                                                */
    CLX_CFG_TYPE_PORT_PFC_MAPPING,             /* valid while CLX_CFG_TYPE_PORT_FC_MODE
                                                * of the port is PFC.
                                                * param0: port.
                                                * param1: queue.
                                                * value : PCP bitmap;
                                                *
                                                */
    CLX_CFG_TYPE_TRILL_ENABLE,                 /* TRILL module related configuration */
    CLX_CFG_TYPE_USE_UNIT_PORT,                /* use UNIT_PORT or native port of CLX_PORT_T
                                                * 1 : UNIT_PORT, 0 : native port
                                                */
    CLX_CFG_TYPE_MAC_VLAN_ENABLE,              /* use dadicate mac vlan table */
    CLX_CFG_TYPE_CPI_PORT_MODE,                /* use to init CPI port working mode.
                                                * param0: CPI port number.
                                                *         0, CPI port 0.
                                                *         1, CPI port 1.
                                                * param1: NA.
                                                * value : 0, CPI mode.
                                                *         1, Ether mode. (default)
                                                */
    CLX_CFG_TYPE_PHY_ADDR,                     /* to assign external phy address if it exists. */
    CLX_CFG_TYPE_LED_CFG,                      /* User config decides to load the desired led */
    CLX_CFG_TYPE_USER_BUF_CTRL,
    CLX_CFG_TYPE_FAIR_BUF_CTRL,                /* to enable the fairness in flow-control traffic.
                                                * value : 0, disable fairness.
                                                *         1, enable fairness.
                                                */
    CLX_CFG_TYPE_HRM_BUF_SIZE,                 /* to assign the head room size of port speed.
                                                * param0: Port speed.
                                                *         0, 1G (default)
                                                *         1, 10G
                                                *         2, 25G
                                                *         3, 40G
                                                *         4, 50G
                                                *         5, 100G
                                                * value : cell number.
                                                */
    CLX_CFG_TYPE_STEERING_TRUNCATE_ENABLE,     /* (CL8360 only)set value 0: Do not truncate steering packets.
                                                * set value 1: steering packets will be trucated to 1 cell and
                                                * the cell size is based on chip.
                                                */
    CLX_CFG_TYPE_FABRIC_MODE_ENABLE,           /* set value 0: Non-farbic chip mode. (default)
                                                * set value 1: Fabric chip mode.
                                                */
    CLX_CFG_TYPE_ACL_TCP_FLAGS_ENCODE_ENABLE,  /* set value 0: Do not encode tcp flags at acl entry.
                                                *              (Can only match bit 0-6 of tcp flags.)
                                                * set value 1: Encode tcp flags at acl entry. (default)
                                                */
    CLX_CFG_TYPE_TCAM_ECC_SCAN_ENABLE,         /* set value 0: Disable ECC TCAM scanning. (default)
                                                * set value 1: Enable  ECC TCAM scanning.
                                                */
    CLX_CFG_TYPE_PORT_BUF_MAX,                 /*
                                                * Port max buffer threshold and unit is cell count.
                                                * param0: port.
                                                * param1: 0, ingress;
                                                *         1, egress.
                                                * value : 0, disable;
                                                *         others, enable max threshold.
                                                */
    CLX_CFG_TYPE_INGRESS_DYNAMIC_BUF,          /*
                                                * Queue dynamic alpha setting and value will be
                                                * enlarge to multiple of 256. For example, set value
                                                * as 16 to indicate alpha as 1/16. Set value
                                                * as 256 to indicate alpha as 1.
                                                * param0: port.
                                                * param1: queue (0~7: sc).
                                                * value : alpha * 256.
                                                */
    CLX_CFG_TYPE_EGRESS_DYNAMIC_BUF,           /*
                                                * Queue dynamic alpha setting and value will be
                                                * enlarge to multiple of 256. For example, set value
                                                * as 16 to indicate alpha as 1/16. Set value
                                                * as 256 to indicate alpha as 1.
                                                * param0: port.
                                                * param1: queue (0~7: uc, 8~15: mc).
                                                * value : alpha * 256.
                                                */

    CLX_CFG_TYPE_DCQCN_ENABLE,                 /* set value 0: Disable DCQCN. (default)
                                                * set value 1: Enable  DCQCN.
                                                */

    CLX_CFG_TYPE_DCTCP_MODE,                   /* set value 0: Fix gap mode. (default)
                                                * set value 1: Percentage mode.
                                                */

    CLX_CFG_TYPE_QUEUE_GROUP_MAP,              /* To map MC egress accounting from qeueu to group.
                                                * param0: queue id. (0~7).
                                                * value : group id.
                                                */

    CLX_CFG_TYPE_FLOWCTRL_RESERVE_MODE,        /* the FC/PFC reservation mode of all ports will be applied.
                                                * param0: Invalid.
                                                * param1: Invalid.
                                                * value : 0, reservation disable;
                                                          1, reservation index 0 enable.
                                                          2, reservation index 0, 1 enable.
                                                */

    CLX_CFG_TYPE_FLOWCTRL_RESERVE_QUEUE,       /* valid while CLX_CFG_TYPE_FLOWCTRL_RESERVE_MODE of all ports is enabled.
                                                * the queue is used to map from lossless index and FC.
                                                * param0: Index ID. (only index 0 & 1 are valid)
                                                * param1: Invalid.
                                                * value : Queue id (index 0: default 7 & FC, index 1: default 6)
                                                */


    CLX_CFG_TYPE_EGR_SYSTEM_GROUP_MAP,         /* To account egress system group from egress queue.
                                                * PG setting is availabled when CLX_CFG_TYPE_USER_BUF_CTRL is enabled.
                                                * param0: queue id. (0~47 for PCIE, 0-7 for others).
                                                * param1: 0, Front port UC type.
                                                          1, Front port MC type.
                                                          2, Local CPU type.
                                                          3, Remote CPU type.
                                                          4, PCIE type.
                                                          5, MIRROR type.
                                                * value : group id.
                                                */


    CLX_CFG_TYPE_MPLS_SR_NUM,                   /* MPLS Segment Routing
                                                 * value: encapsulation number
                                                 */
    CLX_CFG_TYPE_L2_BYPASS_LAG_PRUNE_GROUP_NUM, /* default value: 0 */
    CLX_CFG_TYPE_L3_BYPASS_LAG_PRUNE_GROUP_NUM, /* default value: 0 */

    /* DTEL related configuration */
    CLX_CFG_TYPE_DTEL_PROFILE_NUM,              /* DTEL profile number, it share with sFlow */

    /* l3 related configuration */
    CLX_CFG_TYPE_TCAM_L3_SIP_ENABLE,            /* default value: 0, to expand TCAM capacity */
    CLX_CFG_TYPE_L3_ECMP_FDL_ENABLE,            /* default value: 0, to reserve adj for FDL */

    CLX_CFG_TYPE_HASH_L3_IPV4_PREFIX_LENGTH_ENTRY_NUM,  /* param0: prefix-length (1~32) */
                                                        /* param1: 1: vrf, 0: global */
                                                        /* value: entry number */

    CLX_CFG_TYPE_HASH_L3_IPV6_PREFIX_LENGTH_ENTRY_NUM,  /* param0: prefix-length (1~128) */
                                                        /* param1: 1: vrf, 0: global */
                                                        /* value: entry number */

    CLX_CFG_TYPE_ACL_DROP_REDIRECT_CPU_PKT,     /* set value 0: acl drop_cpu action would not drop redirect to cpu pkt.
                                                 *              (default)
                                                 * set value 1: acl drop_cpu action would drop redirect to cpu pkt.
                                                 */
    CLX_CFG_TYPE_STACKING_CHIP_PORT_NUM,        /* In stacking/chassis system, max used port num per device.
                                                 * default value: hw default max port
                                                 */
    CLX_CFG_TYPE_BUF_SNAPSHOT_INTERVAL,         /* range: 1~1000
                                                 * unit: 10 ms
                                                 * default value: 100 (per 1000ms will collect whole chip buffer snapshot)
                                                 */
    CLX_CFG_TYPE_LAG_MEMBER_AUTO_UPDATE,        /* use to configure LAG member add/remove automatically by SDK
                                                 * if link status has been changed.
                                                 * param0: NA.
                                                 * param1: NA.
                                                 * value : 0, disable (default).
                                                 *         1, enable.
                                                 */
    CLX_CFG_TYPE_PKT_DMA_ENHANCE_ENABLE,        /* used to turn on the enhancement in DMA address cnversion
                                                 * param0: NA
                                                 * param1: NA
                                                 * value : 0, disable (default)
                                                 *         1, enable
                                                 */
    CLX_CFG_TYPE_L2_POLLING_INTERVAL,           /* Times (msec) to poll all L2 FDB entries.
                                                 * Need to sleep at least 50ms whenever poll 8k fdb entries.
                                                 * Ex. if fdb entries is 64k, minimum polling interval would be (64k/8k)*50ms
                                                 */
    CLX_CFG_TYPE_LAG_MC_RESILIENT_ENABLE,       /* Enable lag multicast resilient or not.
                                                 * default value: 0 (disable)
                                                 * Should not enable this in stacking scenario.
                                                 */
    CLX_CFG_TYPE_L2_SKIP_SIZE_BEFORE_VLAN,      /* range: 0-7 Size of 2B to skip, including Etype min: 0 Bytes, max: 14 Bytes */
    CLX_CFG_TYPE_L2_SKIP_ETHERTYPE_BEFORE_VLAN, /* Ethertype to skip. */
    CLX_CFG_TYPE_L2_SKIP_SIZE_AFTER_VLAN,       /* range: 0-7 Size of 2B to skip, including Etype min: 0 Bytes, max: 14 Bytes */
    CLX_CFG_TYPE_L2_SKIP_ETHERTYPE_AFTER_VLAN,  /* Ethertype to skip. */
    CLX_CFG_TYPE_PFCWD_POLLING_INTERVAL,        /* Polling Interval for pfcwd task in ms */
    CLX_CFG_TYPE_LAG_MEMBER_SKIP_PORT_CHECK,    /* Skip port validity check, when adding port members to LAG group */
    CLX_CFG_TYPE_ACL_HW_INSERT_DECENDING,       /* used to config insert hw entry order.
                                                 * param0: NA
                                                 * param1: NA
                                                 * value : 0, insert from first entry (default)
                                                 *         1, insert from last entry
                                                 */
    CLX_CFG_TYPE_L3_BULK_ROUTE_ENABLE,          /* default value: 0, disable bulk route     */
    CLX_CFG_TYPE_L3_BULK_ROUTE_V4_LOW_MASK,     /* default value: 0, do not care mask; user can config mask 5.9.13.17...29      */
    CLX_CFG_TYPE_L3_BULK_ROUTE_V6_LOW_MASK,     /* default value: 0, do not care mask; user can config mask 5.10.15.20.25...60  */
    CLX_CFG_TYPE_SEC_DOS_CHECK_ENABLE,          /* enable all dos check
                                                 * param0: NA.
                                                 * param1: NA.
                                                 * value : 0, disable
                                                 *         1, enable.(default)
                                                 */
    CLX_CFG_TYPE_L3_BULK_PRE_ALLOC_EN,          /* default value: 0, do not pre alloc; user can config 0/1              */
    CLX_CFG_TYPE_L3_BULK_PRE_ALLOC_V4_NUM,      /* default value: 0, do not pre alloc; user can config mask 1,2,4,8     */
    CLX_CFG_TYPE_L3_BULK_PRE_ALLOC_V6_NUM,      /* default value: 0, do not pre alloc; user can config mask 1,2,4,8,16  */
    CLX_CFG_TYPE_L3_HOST_MOVE_V4_EN,            /* default value: 0, do not move v4 host to bottom                      */
    CLX_CFG_TYPE_LAST

}CLX_CFG_TYPE_T;

typedef struct CLX_CFG_VALUE_S
{
    UI32_T  param0;             /*(Optional) The optional parameter which is available
                                 * when the CLX_CFG_TYPE_T needs the first arguments*/
    UI32_T  param1;             /*(Optional) The optional parameter which is available
                                 * when the CLX_CFG_TYPE_T needs the second arguments*/
    I32_T   value;              /* Configuration value */

}CLX_CFG_VALUE_T;

typedef CLX_ERROR_NO_T
    (*CLX_CFG_GET_FUNC_T)(
    const UI32_T            unit,
    const CLX_CFG_TYPE_T    cfg_type,
    CLX_CFG_VALUE_T         *ptr_cfg_value);

typedef CLX_ERROR_NO_T
    (*CLX_CFG_GET_LED_FUNC_T)
(
    const UI32_T            unit,
    UI32_T                  **pptr_led_cfg,
    UI32_T                  *ptr_cfg_size);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   clx_cfg_register
 * PURPOSE:
 *      The function is to register CLX_CFG_GET_FUNC_T to SDK.
 *
 * INPUT:
 *      unit -- Device unit number.
 *      ptr_cfg_callback -- function to get the configuration value.
 *
 * OUTPUT:
 *      None
 *
 * RETURN:
 *      CLX_E_OK -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *
 * NOTES:
 *      1.  During SDK initializtion, it will call registered CLX_CFG_GET_FUNC_T to get configuration
 *          and apply them.
 *          If no registered CLX_CFG_GET_FUNC_T or can not get specified CLX_CFG_TYPE_T
 *          configuration, SDK will apply default setting.
 *      2.  This function should be called before calling clx_init
 */
CLX_ERROR_NO_T
clx_cfg_register(
    const UI32_T            unit,
    CLX_CFG_GET_FUNC_T      ptr_cfg_callback);

/* FUNCTION NAME:   clx_cfg_led_register
 * PURPOSE:
 *      The function is to register CLX_CFG_GET_LED_FUNC_T to SDK.
 *
 * INPUT:
 *      unit -- Device unit number.
 *      ptr_led_cfg_callback -- function to get LED configuration array.
 *
 * OUTPUT:
 *      None
 *
 * RETURN:
 *      CLX_E_OK -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *
 * NOTES:
 *      1.  During SDK initializtion, it will call registered CLX_CFG_GET_LED_FUNC_T to get LED configuration
 *          and apply them.
 *          If no registered CLX_CFG_GET_LED_FUNC_T or can not get specified external LED cfg
 *          configuration, SDK will apply default setting.
 *      2.  This function should be called before calling clx_init
 */
CLX_ERROR_NO_T
clx_cfg_led_register(
    const UI32_T            unit,
    CLX_CFG_GET_LED_FUNC_T  ptr_led_cfg_callback);

#endif  /* CLX_CFG_H */
