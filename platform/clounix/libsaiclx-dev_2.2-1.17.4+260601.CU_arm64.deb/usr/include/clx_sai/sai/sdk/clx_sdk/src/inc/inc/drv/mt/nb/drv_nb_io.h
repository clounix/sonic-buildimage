/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  drv_nb_io.h
 * PURPOSE:
 *  1. Provide the IO channel access interface to chip Device Control Command(DRV_MT).
 *  2. Define DRV_MT IO channel related structures.
 *
 * NOTES:
 *
 */

#ifndef DRV_NB_IO_H
#define DRV_NB_IO_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <osal/osal.h>
#include <clx/clx_init.h>
#include <drv/drv_io.h>
#include <drv/mt/drv_mt_io.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define DRV_IO_NB_BROADCAST_ADDR                (0x8000000)
#define DRV_IO_NB_BROADCAST_ECPU_REP_NUM_ADDR   (0x051C0038)
#define DRV_IO_NB_BROADCAST_ECPU_ADDR_STEP_ADDR (0x051C003C)
#define DRV_IO_NB_BROADCAST_PDMA_REP_NUM_ADDR   (0x051C0040)
#define DRV_IO_NB_BROADCAST_PDMA_ADDR_STEP_ADDR (0x051C0044)
#define DRV_IO_NB_BROADCAST_CMST_REP_NUM_ADDR   (0x051C0048)
#define DRV_IO_NB_BROADCAST_CMST_ADDR_STEP_ADDR (0x051C004C)

#define DRV_MT_IO_NB_IND_FPU_HASH_STATUS_REG_WORD_SIZE (19)

#pragma pack(push, 1)
#if defined(CLX_EN_BIG_ENDIAN)
typedef union drv_nb_io_reg_cpu_hit_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 8;
        uint32 cpu_hit_ind_addr : 20;
        uint32 sel_hsh_or_tcam : 1;
        uint32 cpu_hit_ind_cmd : 3;
    } field;
} drv_nb_io_reg_cpu_hit_cmd_reg_t;
/* tile_hsh_ind_addr */
typedef union drv_nb_io_reg_hash_ind_addr_reg_u {
    uint32 reg[DRV_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 : 12;
        uint32 ind_addr : 20;
    } field;
} drv_nb_io_reg_hash_ind_addr_reg_t;

typedef union drv_nb_io_reg_fpu_hash_stat_reg_u {
    uint32 reg[DRV_MT_IO_NB_IND_FPU_HASH_STATUS_REG_WORD_SIZE];
    struct {
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 8;
        uint32 cpu_fd_dup : 1;
        uint32 cpu_fd_hit : 1;
        uint32 cpu_fd_tile_no : 5;
        uint32 cpu_fd_idx : 15;
        uint32 op_suc : 1;
        uint32 ind_access_done : 1;
    } field;
} drv_nb_io_reg_fpu_hash_stat_reg_t;

/* tile_hsh_ind_status Response status */
typedef union drv_nb_io_reg_hash_stat_reg_u {
    uint32 reg[DRV_MT_IO_IND_HASH_STATUS_REG_WORD_SIZE];
    struct {
        uint32 ind_result2 : 32;
        uint32 ind_result1 : 32;
        uint32 ind_result0 : 30;
        uint32 op_suc : 1;
        uint32 ind_access_done : 1;
    } field;
} drv_nb_io_reg_hash_stat_reg_t;

typedef union drv_nb_io_reg_fpu_hash_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 del_hit_op : 1;
        uint32 insert_hit_op : 1;
        uint32 acc_bmp : 24;
        uint32 ecc_access : 1;
        uint32 key_type : 2;
        uint32 cmd : 3;
    } field;
} drv_nb_io_reg_fpu_hash_cmd_reg_t;

typedef union drv_nb_io_reg_hash_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 28;
        uint32 ecc_access : 1;
        uint32 cmd : 3;
    } field;
    struct {
        uint32 : 27;
        uint32 ecc_access : 1;
        uint32 key_type : 1;
        uint32 cmd : 3;
    } field1;
} drv_nb_io_reg_hash_cmd_reg_t;

/* slc0_tile_tcam_ind_cmd */
typedef union drv_nb_io_reg_fpu_tcam_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 26;
        uint32 ind_slc_select : 1;
        uint32 mode : 2;
        uint32 cmd : 3;
    } field;
} drv_nb_io_reg_fpu_tcam_cmd_reg_t;

typedef union drv_nb_io_reg_tcam_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 26;
        uint32 mode : 3;
        uint32 cmd : 3;
    } field;
} drv_nb_io_reg_tcam_cmd_reg_t;

/* tile_tcam_ind_addr */
typedef union drv_nb_io_reg_fpu_tcam_addr_reg_u {
    uint32 reg[DRV_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 : 17;
        uint32 ind_mem_addr : 15;
    } field;
} drv_nb_io_reg_fpu_tcam_addr_reg_t;

typedef union drv_nb_io_reg_tcam_addr_reg_u {
    uint32 reg[DRV_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 : 18;
        uint32 ind_mem_addr : 14;
    } field;
} drv_nb_io_reg_tcam_addr_reg_t;

typedef union drv_nb_io_reg_tcam_sta_reg_u {
    uint32 reg[DRV_MT_IO_IND_STATUS_REG_WORD_SIZE];
    struct {
        uint32 : 31;
        uint32 ind_access_done : 1;
    } field;
} drv_nb_io_reg_tcam_sta_reg_t;

typedef union drv_nb_io_reg_tcam_move_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_TCAM_MOVE_REG_WORD_SIZE];
    struct {
        uint32 move_mode : 2;
        uint32 op_num : 14;
        uint32 dst_addr : 14;
        uint32 src_addr : 14;
    } ciat_cmd;
    struct {
        uint32 move_or_init : 1;
        uint32 move_mode : 2;
        uint32 op_num : 15;
        uint32 dst_addr : 15;
        uint32 src_addr : 15;
    } fpu_cmd;
    struct {
        uint32 move_or_init : 1;
        uint32 move_mode : 2;
        uint32 op_num : 11;
        uint32 dst_addr : 11;
        uint32 src_addr : 11;
    } dis_cmd;
} drv_nb_io_reg_tcam_move_cmd_reg_t;

typedef union drv_nb_io_reg_tcam_move_sta_reg_u {
    uint32 reg[DRV_MT_IO_IND_STATUS_REG_WORD_SIZE];
    struct {
        uint32 cur_src_ptr : 15;
        uint32 move_done : 1;
        uint32 ack_lock : 4;
        uint32 cur_status : 3;
    } field;
} drv_nb_io_reg_tcam_move_sta_reg_t;

/* cpx_data_buf_mem_addr */
typedef union drv_nb_io_reg_ipl_cpx_data_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 20;
        uint32 mem_inst_sel : 4;
        uint32 address : 8;
    } field;
} drv_nb_io_reg_ipl_cpx_data_buf_mem_addr_t;

/* cpx_fd_buf_mem_addr */
typedef union drv_nb_io_reg_ipl_cpx_fd_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 22;
        uint32 address : 10;
    } field;
} drv_nb_io_reg_ipl_cpx_fd_buf_mem_addr_t;

/* data_buf_mem_addr */
typedef union drv_nb_io_reg_ipl_data_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 14;
        uint32 mem_umac_id : 2;
        uint32 mem_bank_id : 4;
        uint32 address : 12;
    } field;
} drv_nb_io_reg_ipl_data_buf_mem_addr_t;

/* fd_buf_mem_addr */
typedef union drv_nb_io_reg_ipl_app_fd_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 15;
        uint32 mem_umac_id : 2;
        uint32 address : 15;
    } field;
} drv_nb_io_reg_ipl_app_fd_buf_mem_addr_t;

/* fbm_mem_addr */
typedef union drv_nb_io_reg_ipl_app_fbm_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 24;
        uint32 mem_umac_id : 2;
        uint32 address : 6;
    } field;
} drv_nb_io_reg_ipl_app_fbm_mem_addr_t;

/* wd_mem_addr */
typedef union drv_nb_io_reg_ipl_lbm_wd_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 20;
        uint32 dp_sel : 1;
        uint32 address : 11;
    } field;
} drv_nb_io_reg_ipl_lbm_wd_mem_addr_t;

/* data_buf_addr */
typedef union drv_nb_io_reg_ipl_lbm_data_buf_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 17;
        uint32 dp_sel : 1;
        uint32 mem_sel : 5;
        uint32 address : 9;
    } field;
} drv_nb_io_reg_ipl_lbm_data_buf_addr_t;

/* epl_app_umac_data_buf_mem_addr */
typedef union drv_nb_io_reg_epl_app_umac_data_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 15;
        uint32 umac_id_sel : 2;
        uint32 bank_idx : 5;
        uint32 address : 10;
    } field;
} drv_nb_io_reg_epl_app_umac_data_buf_mem_addr_t;

/* epl_umac_data_buf_mem_addr */
typedef union drv_nb_io_reg_epl_umac_data_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 15;
        uint32 umac_id_sel : 2;
        uint32 bank_idx : 5;
        uint32 address : 10;
    } field;
} drv_nb_io_reg_epl_umac_data_buf_mem_addr_t;

/* epl_umac_fd_buf_mem_addr */
typedef union drv_nb_io_reg_epl_umac_fd_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 17;
        uint32 umac_id_sel : 2;
        uint32 address : 13;
    } field;
} drv_nb_io_reg_epl_umac_fd_buf_mem_addr_t;

/* epl_cpx_data_buf_mem_addr */
typedef union drv_nb_io_reg_epl_cpx_data_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 20;
        uint32 address : 7;
        uint32 bank_id : 5;
    } field;
} drv_nb_io_reg_epl_cpx_data_buf_mem_addr_t;

/* epl_cpx_fd_buf_mem_addr */
typedef union drv_nb_io_reg_epl_cpx_fd_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 22;
        uint32 address : 10;
    } field;
} drv_nb_io_reg_epl_cpx_fd_buf_mem_addr_t;

/* vrf_mem_addr */
typedef union drv_nb_io_reg_tm_vrf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 14;
        uint32 mem_inst_sel : 9; /* range 0~287, range 0~71, emu0:0~35 , emu1:36~71 emu7:252-287 */
        uint32 address : 9;
    } field;
} drv_nb_io_reg_tm_vrf_mem_addr_t;

#elif defined(CLX_EN_LITTLE_ENDIAN)
typedef union drv_nb_io_reg_cpu_hit_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 cpu_hit_ind_cmd : 3;
        uint32 sel_hsh_or_tcam : 1;
        uint32 cpu_hit_ind_addr : 20;
        uint32 : 8;
    } field;
} drv_nb_io_reg_cpu_hit_cmd_reg_t;

/* tile_hsh_ind_addr */
typedef union drv_nb_io_reg_hash_ind_addr_reg_u {
    uint32 reg[DRV_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 ind_addr : 20;
        uint32 : 12;
    } field;
} drv_nb_io_reg_hash_ind_addr_reg_t;

/* Response status */
typedef union drv_nb_io_reg_fpu_hash_stat_reg_u {
    uint32 reg[DRV_MT_IO_NB_IND_FPU_HASH_STATUS_REG_WORD_SIZE];
    struct {
        uint32 ind_access_done : 1;
        uint32 op_suc : 1;
        uint32 cpu_fd_idx : 15;
        uint32 cpu_fd_tile_no : 5;
        uint32 cpu_fd_hit : 1;
        uint32 cpu_fd_dup : 1;
        // uint32 cpu_fd_hit_idx       :     360;
        // uint32 cpu_fd_key_exist_bmp :     24;
        // uint32 cpu_fd_row_freebmp   :     192;
    } field;
} drv_nb_io_reg_fpu_hash_stat_reg_t;

/* tile_hsh_ind_status Response status */
typedef union drv_nb_io_reg_hash_stat_reg_u {
    uint32 reg[DRV_MT_IO_IND_HASH_STATUS_REG_WORD_SIZE];
    struct {
        uint32 ind_access_done : 1;
        uint32 op_suc : 1;
        uint32 ind_result0 : 30;
        uint32 ind_result1 : 32;
        uint32 ind_result2 : 32;
    } field;
} drv_nb_io_reg_hash_stat_reg_t;

typedef union drv_nb_io_reg_fpu_hash_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 cmd : 3;
        uint32 key_type : 2;
        uint32 ecc_access : 1;
        uint32 acc_bmp : 24;
        uint32 insert_hit_op : 1;
        uint32 del_hit_op : 1;
    } field;
} drv_nb_io_reg_fpu_hash_cmd_reg_t;

typedef union drv_nb_io_reg_hash_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 cmd : 3;
        uint32 ecc_access : 1;
    } field;
    struct {
        uint32 cmd : 3;
        uint32 key_type : 1;
        uint32 ecc_access : 1;
    } field1;
} drv_nb_io_reg_hash_cmd_reg_t;

/* slc0_tile_tcam_ind_cmd */
typedef union drv_nb_io_reg_fpu_tcam_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 cmd : 3;
        uint32 mode : 2;
        uint32 ind_slc_select : 1;
    } field;
} drv_nb_io_reg_fpu_tcam_cmd_reg_t;

typedef union drv_nb_io_reg_tcam_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 cmd : 3;
        uint32 mode : 3;
    } field;
} drv_nb_io_reg_tcam_cmd_reg_t;

/* tile_tcam_ind_addr */
typedef union drv_nb_io_reg_fpu_tcam_addr_reg_u {
    uint32 reg[DRV_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 ind_mem_addr : 15;
    } field;
} drv_nb_io_reg_fpu_tcam_addr_reg_t;

typedef union drv_nb_io_reg_tcam_addr_reg_u {
    uint32 reg[DRV_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 ind_mem_addr : 14;
    } field;
} drv_nb_io_reg_tcam_addr_reg_t;

typedef union drv_nb_io_reg_tcam_sta_reg_u {
    uint32 reg[DRV_MT_IO_IND_STATUS_REG_WORD_SIZE];
    struct {
        uint32 ind_access_done : 1;
    } field;
} drv_nb_io_reg_tcam_sta_reg_t;

typedef union drv_nb_io_reg_tcam_move_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_TCAM_MOVE_REG_WORD_SIZE];
    struct {
        uint32 src_addr : 14;
        uint32 dst_addr : 14;
        uint32 op_num : 14;
        uint32 move_mode : 2;
    } ciat_cmd;
    struct {
        uint32 src_addr : 15;
        uint32 dst_addr : 15;
        uint32 op_num : 15;
        uint32 move_mode : 2;
        uint32 move_or_init : 1;
    } fpu_cmd;
    struct {
        uint32 src_addr : 11;
        uint32 dst_addr : 11;
        uint32 op_num : 11;
        uint32 move_mode : 2;
        uint32 move_or_init : 1;
    } dis_cmd;
} drv_nb_io_reg_tcam_move_cmd_reg_t;

typedef union drv_nb_io_reg_tcam_move_sta_reg_u {
    uint32 reg[DRV_MT_IO_IND_STATUS_REG_WORD_SIZE];
    struct {
        uint32 cur_status : 3;
        uint32 ack_lock : 4;
        uint32 move_done : 1;
        uint32 cur_src_ptr : 15;
    } field;
} drv_nb_io_reg_tcam_move_sta_reg_t;

/* cpx_data_buf_mem_addr */
typedef union drv_nb_io_reg_ipl_cpx_data_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 8;
        uint32 mem_inst_sel : 4;
    } field;
} drv_nb_io_reg_ipl_cpx_data_buf_mem_addr_t;

/* cpx_fd_buf_mem_addr */
typedef union drv_nb_io_reg_ipl_cpx_fd_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 10;
    } field;
} drv_nb_io_reg_ipl_cpx_fd_buf_mem_addr_t;

/* data_buf_mem_addr */
typedef union drv_nb_io_reg_ipl_data_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 12;
        uint32 mem_bank_id : 4;
        uint32 mem_umac_id : 2;
    } field;
} drv_nb_io_reg_ipl_data_buf_mem_addr_t;

/* fd_buf_mem_addr */
typedef union drv_nb_io_reg_ipl_app_fd_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 15;
        uint32 mem_umac_id : 2;
    } field;
} drv_nb_io_reg_ipl_app_fd_buf_mem_addr_t;

/* fbm_mem_addr */
typedef union drv_nb_io_reg_ipl_app_fbm_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 6;
        uint32 mem_umac_id : 2;
    } field;
} drv_nb_io_reg_ipl_app_fbm_mem_addr_t;

/* wd_mem_addr */
typedef union drv_nb_io_reg_ipl_lbm_wd_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 11;
        uint32 dp_sel : 1;
    } field;
} drv_nb_io_reg_ipl_lbm_wd_mem_addr_t;

/* data_buf_addr */
typedef union drv_nb_io_reg_ipl_lbm_data_buf_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 9;
        uint32 mem_sel : 5;
        uint32 dp_sel : 1;
    } field;
} drv_nb_io_reg_ipl_lbm_data_buf_addr_t;

/* epl_app_umac_data_buf_mem_addr */
typedef union drv_nb_io_reg_epl_app_umac_data_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 10;
        uint32 bank_idx : 5;
        uint32 umac_id_sel : 2;
    } field;
} drv_nb_io_reg_epl_app_umac_data_buf_mem_addr_t;

/* epl_umac_data_buf_mem_addr */
typedef union drv_nb_io_reg_epl_umac_data_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 10;
        uint32 bank_idx : 5;
        uint32 umac_id_sel : 2;
    } field;
} drv_nb_io_reg_epl_umac_data_buf_mem_addr_t;

/* epl_umac_fd_buf_mem_addr */
typedef union drv_nb_io_reg_epl_umac_fd_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 13;
        uint32 umac_id_sel : 2;
    } field;
} drv_nb_io_reg_epl_umac_fd_buf_mem_addr_t;

/* epl_cpx_data_buf_mem_addr */
typedef union drv_nb_io_reg_epl_cpx_data_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 bank_id : 5;
        uint32 address : 7;
    } field;
} drv_nb_io_reg_epl_cpx_data_buf_mem_addr_t;

/* epl_cpx_fd_buf_mem_addr */
typedef union drv_nb_io_reg_epl_cpx_fd_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 10;
    } field;
} drv_nb_io_reg_epl_cpx_fd_buf_mem_addr_t;

/* vrf_mem_addr */
typedef union drv_nb_io_reg_tm_vrf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 9;
        uint32 mem_inst_sel : 9; /* range 0~287, range 0~71, emu0:0~35 , emu1:36~71 emu7:252-287 */
        uint32 : 14;
    } field;
} drv_nb_io_reg_tm_vrf_mem_addr_t;

#else
#error "Host endian is not defined!!\n"
#endif
#pragma pack(pop)

typedef struct drv_nb_io_tcam_fpu_info_s {
    drv_nb_io_reg_fpu_tcam_cmd_reg_t ind_cmd;
    drv_nb_io_reg_fpu_tcam_addr_reg_t ind_addr;
    drv_nb_io_reg_tcam_sta_reg_t ind_sta;
    uint32 acc_bmp;
} drv_nb_io_tcam_fpu_info_t;

typedef struct drv_nb_io_tcam_info_s {
    drv_nb_io_reg_tcam_cmd_reg_t ind_cmd;
    drv_nb_io_reg_tcam_addr_reg_t ind_addr;
    drv_nb_io_reg_tcam_sta_reg_t ind_sta;
} drv_nb_io_tcam_info_t;

typedef struct drv_nb_io_hash_fpu_info_s {
    drv_nb_io_reg_fpu_hash_cmd_reg_t ind_cmd;
    drv_nb_io_reg_hash_ind_addr_reg_t ind_addr;
    drv_nb_io_reg_fpu_hash_stat_reg_t ind_sta;
} drv_nb_io_hash_fpu_info_t;

typedef struct drv_nb_io_hash_info_s {
    drv_nb_io_reg_hash_cmd_reg_t ind_cmd;
    drv_nb_io_reg_hash_ind_addr_reg_t ind_addr;
    drv_nb_io_reg_hash_stat_reg_t ind_sta;
} drv_nb_io_hash_info_t;

typedef struct drv_nb_io_tcam_move_info_s {
    drv_nb_io_reg_tcam_move_cmd_reg_t ind_move_cmd;
    drv_nb_io_reg_tcam_move_sta_reg_t ind_move_sta;
} drv_nb_io_tcam_move_info_t;

typedef union drv_nb_io_pl_tm_ind_mem_info_u {
    /* pl */
    drv_nb_io_reg_epl_cpx_data_buf_mem_addr_t epl_cpx_data_buf_mem_ind_cmd;
    drv_nb_io_reg_epl_umac_fd_buf_mem_addr_t epl_umac_fd_buf_mem_ind_cmd;
    drv_nb_io_reg_epl_umac_data_buf_mem_addr_t epl_umac_data_buf_mem_ind_cmd;
    drv_nb_io_reg_epl_app_umac_data_buf_mem_addr_t epl_app_umac_data_buf_mem_ind_cmd;
    drv_nb_io_reg_ipl_lbm_data_buf_addr_t ipl_lbm_data_buf_ind_cmd;
    drv_nb_io_reg_ipl_lbm_wd_mem_addr_t ipl_lbm_wd_mem_ind_cmd;
    drv_nb_io_reg_ipl_app_fbm_mem_addr_t ipl_app_fbm_mem_ind_cmd;
    drv_nb_io_reg_ipl_app_fd_buf_mem_addr_t ipl_app_fd_mem_ind_cmd;
    drv_nb_io_reg_ipl_data_buf_mem_addr_t ipl_data_buf_mem_ind_cmd;
    drv_nb_io_reg_ipl_cpx_fd_buf_mem_addr_t ipl_cpx_fd_bum_mem_ind_cmd;
    drv_nb_io_reg_ipl_cpx_data_buf_mem_addr_t ipl_cpx_data_buf_mem_ind_cmd;

    /* tm */
    drv_nb_io_reg_tm_vrf_mem_addr_t tm_emu_verf_mem_ind_cmd;
} drv_nb_io_pl_tm_ind_mem_info_t;

typedef struct drv_nb_io_table_meta_s {
    uint32 ind_cmd_addr;
    uint32 ind_address_addr;
    uint32 ind_status_addr;
    uint32 ind_data_addr;
    uint32 acc_bmp_addr;

    union {
        drv_nb_io_tcam_fpu_info_t tcam_fpu_info;
        drv_nb_io_tcam_info_t tcam_info;
        drv_nb_io_hash_fpu_info_t hash_fpu_info;
        drv_nb_io_hash_info_t hash_info;
        drv_nb_io_pl_tm_ind_mem_info_t tm_pl_info;
        drv_nb_io_tcam_move_info_t tcam_move_info;
    };

    drv_mt_io_table_type_t table_type;
    boolean access_by_dma;

} drv_nb_io_table_meta_t;

/* DRV CMST ERROR LOG */
#pragma pack(push, 1)
#if defined(CLX_EN_BIG_ENDIAN)
typedef struct drv_nb_io_error_cmst_code_s {
    uint32 req_addr_2 : 21;
    uint32 req_mid : 3;
    uint32 req_sn : 8;
    uint32 : 3;
    uint32 error_info_valid : 1;
    uint32 master_id : 3;
    uint32 cmst_error_code : 3;
    uint32 req_type : 2;
    uint32 req_attr : 3;
    uint32 req_size : 6;
    uint32 : 2;
    uint32 req_addr_1 : 9;
} drv_nb_io_error_cmst_code_t;

typedef struct drv_nb_io_error_cslv_code_s {
    uint32 req_addr_2 : 21;
    uint32 req_mid : 3;
    uint32 req_sn : 8;
    uint32 : 3;
    uint32 error_info_valid : 1;
    uint32 master_id : 3;
    uint32 cmst_error_code : 3;
    uint32 req_type : 2;
    uint32 req_attr : 3;
    uint32 req_size : 6;
    uint32 slv_error_code : 2;
    uint32 req_addr_1 : 9;
} drv_nb_io_error_cslv_code_t;

typedef struct drv_nb_io_error_other_code_s {
    uint32 chain_id_2 : 5;
    uint32 : 8;
    uint32 req_addr_lsb : 8;
    uint32 : 3;
    uint32 : 8;
    uint32 : 3;
    uint32 error_info_valid : 1;
    uint32 master_id : 3;
    uint32 cmst_error_code : 3;
    uint32 req_type : 2;
    uint32 req_attr : 3;
    uint32 req_size : 6;
    uint32 : 2;
    uint32 : 5;
    uint32 chain_id_1 : 4;
} drv_nb_io_error_other_code_t;
#elif defined(CLX_EN_LITTLE_ENDIAN)
typedef struct drv_nb_io_error_cmst_code_s {
    uint32 req_sn : 8;
    uint32 req_mid : 3;
    uint32 req_addr_2 : 21;
    uint32 req_addr_1 : 9;
    uint32 : 2;
    uint32 req_size : 6;
    uint32 req_attr : 3;
    uint32 req_type : 2;
    uint32 cmst_error_code : 3;
    uint32 master_id : 3;
    uint32 error_info_valid : 1;
    uint32 : 3;
} drv_nb_io_error_cmst_code_t;

typedef struct drv_nb_io_error_cslv_code_s {
    uint32 req_sn : 8;
    uint32 req_mid : 3;
    uint32 req_addr_2 : 21;
    uint32 req_addr_1 : 9;
    uint32 slv_error_code : 2;
    uint32 req_size : 6;
    uint32 req_attr : 3;
    uint32 req_type : 2;
    uint32 cmst_error_code : 3;
    uint32 master_id : 3;
    uint32 error_info_valid : 1;
    uint32 : 3;
} drv_nb_io_error_cslv_code_t;

typedef struct drv_nb_io_error_other_code_s {
    uint32 : 8;
    uint32 : 3;
    uint32 req_addr_lsb : 8;
    uint32 : 8;
    uint32 chain_id_2 : 5;
    uint32 chain_id_1 : 4;
    uint32 : 5;
    uint32 : 2;
    uint32 req_size : 6;
    uint32 req_attr : 3;
    uint32 req_type : 2;
    uint32 cmst_error_code : 3;
    uint32 master_id : 3;
    uint32 error_info_valid : 1;
    uint32 : 3;
} drv_nb_io_error_other_code_t;
#else
#error "Host endian is not defined!!\n"
#endif
#pragma pack(pop)

typedef struct drv_nb_io_error_code_s {
    union {
        drv_nb_io_error_cmst_code_t cmst_code;
        drv_nb_io_error_cslv_code_t cslv_code;
        drv_nb_io_error_other_code_t other_code;
    };

} drv_nb_io_error_code_t;

#endif /* END of DRV_NB_IO_H*/
