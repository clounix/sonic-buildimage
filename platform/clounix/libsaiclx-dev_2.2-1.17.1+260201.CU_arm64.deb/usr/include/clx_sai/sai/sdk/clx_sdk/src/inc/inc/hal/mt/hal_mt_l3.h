/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_l3.h
 * PURPOSE:
 *      Provide HAL driver API functions for CL8570.
 * NOTES:
 *
 *
 */
#ifndef HAL_MT_L3_H
#define HAL_MT_L3_H

/*****************************************************************************
 * INCLUDE FILE DECLARATIONS
 *****************************************************************************
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_swc.h>
#include <clx/clx_l3.h>
#include <hal/hal_l3.h>

/*****************************************************************************
 * NAMING CONSTANT DECLARATIONS
 *****************************************************************************
 */
/* HITBIT */

/* INTF */

/* MTU */

/* VRF */

/* RMAC */

/* ADJ*/

/* ROUTE */

/* ECMP */

/* MCAST */

/*****************************************************************************
 * MACRO FUNCTION DECLARATIONS
 *****************************************************************************
 */

/* ADJ */

/* HOST */
#define HAL_MT_L3_FLUSH_POLLING_NUM_MAX  (10000)
#define HAL_MT_L3_FLUSH_POLLING_USEC     (1000)
#define HAL_MT_L3_FLUSH_HASH_ENTRY_WORDS (6)
#define HAL_MT_L3_FLUSH_TCAM_ENTRY_WORDS (8)

#define HAL_MT_L3_FLUSH_AGE    (0)
#define HAL_MT_L3_FLUSH_SEARCH (1)

#define HAL_MT_L3_FLUSH_UNEQUAL (0)
#define HAL_MT_L3_FLUSH_EQUAL   (1)
#define HAL_MT_L3_FLUSH_BOTH    (2)

#define HAL_MT_L3_FLUSH_MODIFY (1)
#define HAL_MT_L3_FLUSH_REMOVE (2)

#define HAL_MT_L3_RMAC_INVLD (4095)
/* HOST EXTRA FLAGS */
#define HAL_MT_L3_HOST_MC_ADD_FLAG (1U << 31) /* add host for mroute */
#define HAL_MT_L3_TCAM_ADD_FLAG    (1U << 30) /* add tcam entry for test */

/* ROUTE */
#define HAL_MT_L3_ROUTE_TRIE_BIT_MAX (31)

/* MCAST */
#define HAL_MT_L3_RPF_TCAM_MAX_NUM      (1024)
#define HAL_MT_L3_MCAST_SG_TCAM_MAX_NUM (1024)

/* RMAC */
#define HAL_MT_L3_RMAC_GET(__mac__, __msk__)    \
    do {                                        \
        __mac__[0] = (__mac__[0] & __msk__[0]); \
        __mac__[1] = (__mac__[1] & __msk__[1]); \
        __mac__[2] = (__mac__[2] & __msk__[2]); \
        __mac__[3] = (__mac__[3] & __msk__[3]); \
        __mac__[4] = (__mac__[4] & __msk__[4]); \
        __mac__[5] = (__mac__[5] & __msk__[5]); \
    } while (0)

/*****************************************************************************
 * DATA TYPE DECLARATIONS
 *****************************************************************************
 */

#define HAL_MT_L3_WBDB_ECMP_BASE  (HAL_MT_L3_WBDB_ADJ_BASE + HAL_MT_L3_WBDB_ADJ_LAST)
#define HAL_MT_L3_WBDB_HOST_BASE  (HAL_MT_L3_WBDB_ECMP_BASE + HAL_MT_L3_WBDB_ECMP_LAST)
#define HAL_MT_L3_WBDB_ROUTE_BASE (HAL_MT_L3_WBDB_HOST_BASE + HAL_MT_L3_WBDB_HOST_LAST)
#define HAL_MT_L3_WBDB_MCAST_BASE (HAL_MT_L3_WBDB_ROUTE_BASE + HAL_MT_L3_WBDB_ROUTE_LAST)
#define HAL_MT_L3_WBDB_RMAC_BASE  (HAL_MT_L3_WBDB_MCAST_BASE + HAL_MT_L3_WBDB_MCAST_LAST)
#define HAL_MT_L3_WBDB_NUM        (HAL_MT_L3_WBDB_RMAC_BASE + HAL_MT_L3_WBDB_RMAC_LAST)

/* MGI KEY LEN */
typedef enum hal_mt_l3_mc_mgi_type_e {
    HAL_L3_MC_MGI_TYPE_V4 = 0,   /* 0:v4 key         */
    HAL_L3_MC_MGI_TYPE_MPLS = 1, /* 1:mpls key       */
    HAL_L3_MC_MGI_TYPE_LAST
} hal_mt_l3_mc_mgi_type_t;

typedef enum hal_mt_l3_mpfc_mode_type_e {
    HAL_L3_MCAST_RPFC_SINGLE_INTF_MODE = 0, /* single intf mode */
    HAL_L3_MCAST_RPFC_ECMP_MODE = 1,        /* ecmp mode */
    HAL_L3_MCAST_RPFC_PIM_BIDIR_MODE = 2,   /* bidir-pim mode */
    HAL_L3_MCAST_RPFC_MODE_TYPE_LAST
} hal_mt_l3_mpfc_mode_type_t;

typedef enum hal_mt_l3_rpfc_type_e {
    HAL_L3_RPFC_RP_TYPE = 0,   /* MTREE-ID */
    HAL_L3_RPFC_ECMP_TYPE = 1, /* ECMP-BASE */
    HAL_L3_RPFC_TYPE_LAST
} hal_mt_l3_rpfc_type_t;

/* RESOURCE TYPE */
typedef enum hal_mt_l3_rsrc_type_e {
    HAL_MT_L3_RSRC_TYPE_TCAM = 0x1,
    HAL_MT_L3_RSRC_TYPE_SRAM,
    HAL_MT_L3_RSRC_TYPE_HASH,
    HAL_MT_L3_RSRC_TYPE_LAST
} hal_mt_l3_rsrc_type_t;

typedef enum hal_mt_l3_rmac_type_e {
    HAL_MT_L3_RMAC_TYPE_NONE = 0,
    HAL_MT_L3_RMAC_TYPE_FLEX,
    HAL_MT_L3_RMAC_TYPE_FIXED,
    HAL_MT_L3_RMAC_TYPE_LAST
} hal_mt_l3_rmac_type_t;

typedef struct hal_mt_l3_rmac_intf_s {
    hal_mt_l3_rmac_type_t type;
    uint32 intf_id;
    uint32 intf_mask;
} hal_mt_l3_rmac_intf_t;
typedef struct hal_mt_l3_cb_s {
    clx_semaphore_id_t sema;
    hal_mt_l3_rmac_intf_t *idx2intf; /* Array of rmac index */
    uint32 *intf2idx;                /* Array of l3 interface to rmac index */
    uint32 cpu_id_queue;             /* cpu id and queue */
} hal_mt_l3_cb_t;

typedef enum hal_mt_l3_route_rsrc_maximize_e {
    HAL_MT_L3_ROUTE_RSRC_MAXIMIZE_NONE = 0,
    HAL_MT_L3_ROUTE_RSRC_MAXIMIZE_V6,
    HAL_MT_L3_ROUTE_RSRC_MAXIMIZE_V4,
    HAL_MT_L3_ROUTE_RSRC_MAXIMIZE_V4V6,
    HAL_MT_L3_ROUTE_RSRC_MAXIMIZE_LAST
} hal_mt_l3_route_rsrc_maximize_t;

/* HOST */
typedef struct hal_mt_l3_host_rsrc_s {
#define MT_FPU_HSH_L3_V4_WORDS MAX(MT_NB_CDB_FPU_HSH_L3_V4_WORDS, MT_KG_CDB_FPU_HSH_L3_V4_WORDS)
#define MT_FPU_HSH_L3_V6_WORDS MAX(MT_NB_CDB_FPU_HSH_L3_V6_WORDS, MT_KG_CDB_FPU_HSH_L3_V6_WORDS)
#define MT_FPU_TCAM_FIB_V4_WORDS \
    MAX(MT_NB_CDB_FPU_TCAM_FIB_V4_WORDS, MT_KG_CDB_FPU_TCAM_FIB_V4_WORDS)
#define MT_FPU_TCAM_FIB_V6_4X_WORDS \
    MAX(MT_NB_CDB_FPU_TCAM_FIB_V6_4X_WORDS, MT_KG_CDB_FPU_TCAM_FIB_V6_4X_WORDS)
#define MT_FPU_RSLT_FIB_WORDS MAX(MT_NB_CDB_FPU_RSLT_FIB_WORDS, MT_KG_CDB_FPU_RSLT_FIB_WORDS)

    boolean ipv4;
    clx_ip_t ip;
    uint32 hash_tbl; /* FPU hsh table ID       */
    uint32 tcam_tbl; /* FPU tcam table ID      */
    uint32 rslt_tbl; /* FPU rslt table ID      */
    uint32 is_tcam;  /* FPU tcam bank bitmap   */
    uint32 grp_lbl;  /* FPU in-band CIA result */
    uint32 decr_ttl; /* FPU decr_ttl           */
    uint32 sa_dc;    /* FPU sa_dc              */
    uint32 fwd_ptr;  /* FPU fwd_ptr            */
    union {
        uint32 ipv4_buf[MT_FPU_HSH_L3_V4_WORDS];
        uint32 ipv6_buf[MT_FPU_HSH_L3_V6_WORDS];
    } hash_buf;
    union {
        uint32 ipv4_buf[MT_FPU_TCAM_FIB_V4_WORDS];
        uint32 ipv6_buf[MT_FPU_TCAM_FIB_V6_4X_WORDS];
    } tcam_buf;
    uint32 rslt_buf[MT_FPU_RSLT_FIB_WORDS];
    uint32 d_ile_idx; /* TCAM DIP IDX         */
    uint32 s_ile_idx; /* TCAM SIP IDX         */
    uint32 fpu;       /* HASH IDX             */
    char ip_str[UTIL_IP_ADDR_STR_SIZE];

    /* hitbit */
    uint32 sip_hit;
    /* swdb */
    uint32 vrf_id;
    clx_nhp_t nhp;
    uint32 subnet_bc_id;
    uint32 mpls_lbl;
    uint32 mpls_en;
    uint32 uc_drop;
    boolean mc_add;
    uint32 is_host_route;            /* is host route or not, prefix 32/128 entry */
    hal_swc_hsh_tile_bmp_t bank_bmp; /* FPU hsh bank bitmap    */
} hal_mt_l3_host_rsrc_t;

/* MCAST */
typedef enum hal_mt_l3_mcast_mbr_trav_type_e {
    HAL_L3MC_LKUP_TYPE_FL = 0,
    HAL_L3MC_LKUP_TYPE_SN,
    HAL_L3MC_LKUP_TYPE_PORT,
    HAL_L3MC_LKUP_TYPE_LAST
} hal_mt_l3_mcast_mbr_trav_type_t;

/* Warmboot */
typedef enum hal_mt_l3_wbdb_intf_e {
    HAL_MT_L3_WBDB_INTF_IEV_L2UC_DROP_IDX = 0, /* iev_l2uc_drop_idx     */
    HAL_MT_L3_WBDB_INTF_INTF2FDID,             /* ptr_intf2fdid         */
    HAL_MT_L3_WBDB_INTF_FDID2INTF,             /* ptr_fdid2intf         */
    HAL_MT_L3_WBDB_INTF_INTF2VRF,              /* ptr_intf2vrf          */
    HAL_MT_L3_WBDB_INTF_LAST
} hal_mt_l3_wbdb_intf_t;

typedef enum hal_mt_l3_wbdb_vrf_e {
    HAL_MT_L3_WBDB_VRF_IPV4_STATE_BMP = 0, /* ptr_ipv4_state_bmp    */
    HAL_MT_L3_WBDB_VRF_IPV6_STATE_BMP,     /* ptr_ipv4_state_bmp    */
    HAL_MT_L3_WBDB_VRF_LAST
} hal_mt_l3_wbdb_vrf_t;

typedef enum hal_mt_l3_wbdb_adj_e {
    HAL_MT_L3_WBDB_ADJ_AVL = 0,         /* ptr_avl               */
    HAL_MT_L3_WBDB_ADJ_1X_ALLOC_BMP,    /* alloc idx bmp         */
    HAL_MT_L3_WBDB_ADJ_2X_ALLOC_BMP,    /* alloc idx bmp         */
    HAL_MT_L3_WBDB_ADJ_1X_MAX_NUM,      /* total adj idx         */
    HAL_MT_L3_WBDB_ADJ_2X_MAX_NUM,      /* total adj idx         */
    HAL_MT_L3_WBDB_ADJ_1X_ARP_BANK_BMP, /* arp bank bmp          */
    HAL_MT_L3_WBDB_ADJ_2X_ARP_BANK_BMP, /* arp bank bmp          */
    HAL_MT_L3_WBDB_ADJ_RPFC_BANK_BMP,   /* rpfc bank bmp         */
    HAL_MT_L3_WBDB_ADJ_RPFC_TCAM_INFO,  /* rpfc_tcam_info        */
    HAL_MT_L3_WBDB_ADJ_LAST
} hal_mt_l3_wbdb_adj_t;

typedef enum hal_mt_l3_wbdb_ecmp_e {
    HAL_MT_L3_WBDB_ECMP_AVL = 0,               /* ptr_avl               */
    HAL_MT_L3_WBDB_ECMP_L3IF_AVL,              /* l3if avl              */
    HAL_MT_L3_WBDB_ECMP_FDL_AVL,               /* fdl avl               */
    HAL_MT_L3_WBDB_ECMP_AR_AVL,                /* ar avl                */
    HAL_MT_L3_WBDB_ECMP_TNL_AVL,               /* tnl avl               */
    HAL_MT_L3_WBDB_ECMP_SW_ECMP_PATH_BLOCK_SZ, /* sw_ecmp_path_block_sz */
    HAL_MT_L3_WBDB_ECMP_ALGO_MODE,             /* algo_mode             */
    HAL_MT_L3_WBDB_ECMP_RESILIENT_EN,          /* resilient_en          */
    HAL_MT_L3_WBDB_ECMP_GRP_NUM,               /* ecmp grp num          */
    HAL_MT_L3_WBDB_ECMP_PATH_NUM,              /* add path num          */
    HAL_MT_L3_WBDB_ECMP_ALLOC_PATH_NUM,        /* alloc path num        */
    HAL_MT_L3_WBDB_ECMP_LAST
} hal_mt_l3_wbdb_ecmp_t;

typedef enum hal_mt_l3_wbdb_host_e {
    HAL_MT_L3_WBDB_HOST_IPV4_HASH_1X_CNT = 0, /* ipv4_hash_1x_cnt           */
    HAL_MT_L3_WBDB_HOST_IPV6_HASH_2X_CNT,     /* ipv6_hash_2x_cnt           */
    HAL_MT_L3_WBDB_HOST_IPV4_TCAM_1X_CNT,     /* ipv4_tcam_1x_cnt           */
    HAL_MT_L3_WBDB_HOST_IPV6_TCAM_4X_CNT,     /* ipv6_tcam_4x_cnt           */
    HAL_MT_L3_WBDB_HOST_TILE_BMP,             /* host tile bmp              */
    HAL_MT_L3_WBDB_HOST_ROUTE_TILE_BMP,       /* host route tile bmp        */
    HAL_MT_L3_WBDB_HOST_HASH_V4_CNT,          /* per tile ipv4_hash_1x_cnt  */
    HAL_MT_L3_WBDB_HOST_HASH_V6_CNT,          /* per tile ipv6_hash_2x_cnt  */
    HAL_MT_L3_WBDB_HOST_TCAM_V4_CNT,          /* per bank ipv4_tcam_1x_cnt  */
    HAL_MT_L3_WBDB_HOST_TCAM_V6_CNT,          /* per bankipv6_tcam_4x_cnt   */
    HAL_MT_L3_WBDB_HOST_TCAM_SIP_EN,          /* host_tcam_sip_en           */
    HAL_MT_L3_WBDB_HOST_AVL,                  /* host_avl                   */
    HAL_MT_L3_WBDB_HOST_BCAST_AVL,            /* bcast_avl                  */
    HAL_MT_L3_WBDB_HOST_HASH_BMP,             /* tile bmp                   */
    HAL_MT_L3_WBDB_HOST_LAST
} hal_mt_l3_wbdb_host_t;

typedef enum hal_mt_l3_wbdb_route_e {
    HAL_MT_L3_WBDB_ROUTE_TCAM_SIP_EN = 0,         /* tcam_sip_en           */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_2X_CNT,        /* tcam_bank_2x_cnt      */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_4X_CNT,        /* tcam_bank_4x_cnt      */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK,               /* tcam_bank             */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BLOCK_1X,           /* tcam_block_1x         */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BLOCK_2X,           /* tcam_block_2x         */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BLOCK_4X,           /* tcam_block_4x         */
    HAL_MT_L3_WBDB_ROUTE_IPV4_TCAM_1X_CNT,        /* ipv4_tcam_1x_cnt      */
    HAL_MT_L3_WBDB_ROUTE_IPV6_TCAM_2X_CNT,        /* ipv6_tcam_2x_cnt      */
    HAL_MT_L3_WBDB_ROUTE_IPV6_TCAM_4X_CNT,        /* ipv6_tcam_4x_cnt      */
    HAL_MT_L3_WBDB_ROUTE_IPV4_HASH_CNT,           /* ipv4_hash_cnt         */
    HAL_MT_L3_WBDB_ROUTE_IPV6_HASH_CNT,           /* ipv6_hash_cnt         */
    HAL_MT_L3_WBDB_ROUTE_USED_V4_CNT,             /* used_v4_cnt           */
    HAL_MT_L3_WBDB_ROUTE_USED_V6_CNT,             /* used_v6_cnt           */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_GLB_CNT,       /* tcam_bank_glb_cnt     */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_ENTRY_CNT,     /* tcam_bank_entry_cnt   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_GLB_ENTRY_CNT, /* tcam_bank_entry_cnt   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BMP,                /* tcam_route_bmp        */
    HAL_MT_L3_WBDB_ROUTE_HASH_BMP,                /* hash_route_bmp        */
    HAL_MT_L3_WBDB_ROUTE_ACL_LABEL_EN,            /* acl_label_en          */
    HAL_MT_L3_WBDB_ROUTE_BULK_EN,                 /* bulk_route_en         */
    HAL_MT_L3_WBDB_ROUTE_PROFILE_UDF_EN,          /* profile_udf_en        */
    HAL_MT_L3_WBDB_ROUTE_V6_RSRC_MAXIMIZE,        /* v6_rsrc_maxmize       */
    HAL_MT_L3_WBDB_ROUTE_IPV4_1X_ROOT_NUM,        /* ipv4_1x_root_num      */
    HAL_MT_L3_WBDB_ROUTE_IPV6_2X_ROOT_NUM,        /* ipv6_2x_root_num      */
    HAL_MT_L3_WBDB_ROUTE_IPV6_4X_ROOT_NUM,        /* ipv6_4x_root_num      */
    HAL_MT_L3_WBDB_ROUTE_AFIB_ENABLE,             /* lpm afib enable       */
    HAL_MT_L3_WBDB_ROUTE_BULK_V4_AVL,             /* lpm bulk avl swdb     */
    HAL_MT_L3_WBDB_ROUTE_BULK_V6_AVL,             /* lpm bulk avl swdb     */
    HAL_MT_L3_WBDB_ROUTE_DROP_FPU_IDX,            /* fpu drop adj hw addr  */
    HAL_MT_L3_WBDB_ROUTE_PRE_ALLOC_EN,            /* lpm pre alloc enabel  */
    HAL_MT_L3_WBDB_ROUTE_COVER_CHECK_EN,          /* lpm cover check enabel*/
    HAL_MT_L3_WBDB_ROUTE_V6MC_WA_ENABLE,          /* lpm v6mc wa enable    */
    HAL_MT_L3_WBDB_ROUTE_V4_ALLOC_NUM,            /* lpm v4 alloc count    */
    HAL_MT_L3_WBDB_ROUTE_V6_ALLOC_NUM,            /* lpm v4 alloc count    */
    HAL_MT_L3_WBDB_ROUTE_V4_TRIE,                 /* lpm v4 trie           */
    HAL_MT_L3_WBDB_ROUTE_V6_TRIE,                 /* lpm v6 trie           */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_BMP_DA_4X,     /* tcam_bank_bmp_da_4x   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_BMP_SA_4X,     /* tcam_bank_bmp_sa_4x   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_BMP_DA_2X,     /* tcam_bank_bmp_da_2x   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_BMP_SA_2X,     /* tcam_bank_bmp_sa_2x   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_BMP_DA_4X_GLB, /* tcam_bank_bmp_da_4x   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_BMP_SA_4X_GLB, /* tcam_bank_bmp_sa_4x   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_BMP_DA_2X_GLB, /* tcam_bank_bmp_da_2x   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_BMP_SA_2X_GLB, /* tcam_bank_bmp_sa_2x   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_4X_RSVD,            /* tcam_4x_rsvd          */
    HAL_MT_L3_WBDB_ROUTE_LPM_TILE_INFO,           /* lpm_tile_info          */
    HAL_MT_L3_WBDB_ROUTE_LAST
} hal_mt_l3_wbdb_route_t;

typedef enum hal_mt_l3_wbdb_mcast_e {
    HAL_MT_L3_WBDB_MCAST_RP_ID_BMP = 0,    /* rp_id_bmp             */
    HAL_MT_L3_WBDB_MCAST_MGI_BANK_BMP,     /* mgi_bank_bmp          */
    HAL_MT_L3_WBDB_MCAST_MSGI_BANK_BMP,    /* mgi_bank_bmp          */
    HAL_MT_L3_WBDB_MCAST_RPFC_BANK_BMP,    /* rpfc_bank_bmp         */
    HAL_MT_L3_WBDB_MCAST_RPA_AVL,          /* ptr_rpa_avl           */
    HAL_MT_L3_WBDB_MCAST_GRP_AVL,          /* ptr_grp_avl           */
    HAL_MT_L3_WBDB_MCAST_SG_AVL,           /* ptr_sg_node_avl       */
    HAL_MT_L3_WBDB_MCAST_S_G_AVL,          /* ptr_s_or_g_node_avl   */
    HAL_MT_L3_WBDB_MCAST_MEL_AVL,          /* ptr_intf_node_avl     */
    HAL_MT_L3_WBDB_MCAST_IPV4_HASH_1X_CNT, /* ipv4_hash_1x_cnt      */
    HAL_MT_L3_WBDB_MCAST_IPV6_HASH_2X_CNT, /* ipv6_hash_2x_cnt      */
    HAL_MT_L3_WBDB_MCAST_SG_TCAM_CNT,      /* sg_hash_cnt           */
    HAL_MT_L3_WBDB_MCAST_IPV4_XG_CNT,      /* ipv4_xg_cnt           */
    HAL_MT_L3_WBDB_MCAST_IPV6_XG_CNT,      /* ipv6_xg_cnt           */
    HAL_MT_L3_WBDB_MCAST_IPV4_SG_CNT,      /* ipv4_sg_cnt           */
    HAL_MT_L3_WBDB_MCAST_IPV6_SG_CNT,      /* ipv6_sg_cnt           */
    HAL_MT_L3_WBDB_MCAST_LAST
} hal_mt_l3_wbdb_mcast_t;

typedef enum hal_mt_l3_wbdb_rmac_e {
    HAL_MT_L3_WBDB_RMAC_IDX_INTF = 0, /* rmac idx to inff         */
    HAL_MT_L3_WBDB_RMAC_INTF_IDX,     /* intf to rmac             */
    HAL_MT_L3_WBDB_CPU_DI,            /* cpu di                   */
    HAL_MT_L3_WBDB_RMAC_LAST
} hal_mt_l3_wbdb_rmac_t;

#define HAL_MT_L3_WBDB_INTF_BASE  (0)
#define HAL_MT_L3_WBDB_VRF_BASE   (HAL_MT_L3_WBDB_INTF_BASE + HAL_MT_L3_WBDB_INTF_LAST)
#define HAL_MT_L3_WBDB_ADJ_BASE   (HAL_MT_L3_WBDB_VRF_BASE + HAL_MT_L3_WBDB_VRF_LAST)
#define HAL_MT_L3_WBDB_ECMP_BASE  (HAL_MT_L3_WBDB_ADJ_BASE + HAL_MT_L3_WBDB_ADJ_LAST)
#define HAL_MT_L3_WBDB_HOST_BASE  (HAL_MT_L3_WBDB_ECMP_BASE + HAL_MT_L3_WBDB_ECMP_LAST)
#define HAL_MT_L3_WBDB_ROUTE_BASE (HAL_MT_L3_WBDB_HOST_BASE + HAL_MT_L3_WBDB_HOST_LAST)
#define HAL_MT_L3_WBDB_MCAST_BASE (HAL_MT_L3_WBDB_ROUTE_BASE + HAL_MT_L3_WBDB_ROUTE_LAST)
#define HAL_MT_L3_WBDB_RMAC_BASE  (HAL_MT_L3_WBDB_MCAST_BASE + HAL_MT_L3_WBDB_MCAST_LAST)
#define HAL_MT_L3_WBDB_NUM        (HAL_MT_L3_WBDB_RMAC_BASE + HAL_MT_L3_WBDB_RMAC_LAST)

/*****************************************************************************
 * LOCAL SUBPROGRAM BODIES
 *****************************************************************************
 */
/* ----------------------------------------------------------------------------------- MAIN */

#endif /* End of HAL_MT_KG_L3_H */
