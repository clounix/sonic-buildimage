/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_srv6.h
 * PURPOSE:
 *      It provide srv6 tunnel hal layer api.
 * NOTES:
 *
 */

#ifndef HAL_SRV6_H
#define HAL_SRV6_H
#include <clx/clx_srv6.h>
#include <clx/clx_cfg.h>
#include <clx/clx_types.h>
#include <util/util_log.h>
#include <hal/hal_cmn.h>

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */
typedef enum hal_srv6_sid_slv_mode_e {
    HAL_SRV6_SID_SLV_MODE_DISABLE = 0,
    HAL_SRV6_SID_SLV_MODE_SRV6 = 1,
    HAL_SRV6_SID_SLV_MODE_USID = 2,
    HAL_SRV6_SID_SLV_MODE_GSRV6 = 3,
    HAL_SRV6_SID_SLV_MODE_LAST
} hal_srv6_sid_slv_mode_t;

#define HAL_SRV6_SID_SLV_LOCATOR_LEN_DEFAULT     (8)
#define HAL_SRV6_SID_SLV_FUNC_LEN_DEFAULT        (4)
#define HAL_SRV6_SID_SLV_ARG_LEN_DEFAULT         (2)
#define HAL_SRV6_SID_SLV_USID_BLOCK_LEN_DEFAULT  (7)
#define HAL_SRV6_SID_SLV_USID_NODE_LEN_DEFAULT   (1)
#define HAL_SRV6_SID_SLV_GSRV6_PREFIX_DEFAULT    (4)
#define HAL_SRV6_SID_SLV_GSRV6_SI_OFFSET_DEFAULT (4)

#define HAL_SRV6_SID_LOCATOR_LEN_MAX      (16) /* Max number of locator size */
#define HAL_SRV6_SID_FUNC_LEN_MAX         (4)  /* Max number of function size */
#define HAL_SRV6_SID_ARG_LEN_MAX          (2)  /* Max number of argument size */
#define HAL_SRV6_SID_USID_BLOCK_LEN_MAX   (7)  /* Max number of uSID block size */
#define HAL_SRV6_SID_USID_NODE_LEN_MAX    (7)  /* Max number of uSID node id size */
#define HAL_SRV6_SID_GSRV6_PREFIX_LEN_MAX (12) /* Max number of G-SRv6 prefix size */
#define HAL_SRV6_SID_GSRV6_SI_OFFSET_MAX  (16) /* Max number of G-SRv6 SID index offset */
#define HAL_SRV6_VRFI_MIN                 (0)
#define HAL_SRV6_VRFI_MAX                 (8191)
/* cl8600 supports packaging up to 4 segment identifiers in SRH */
#define HAL_SRV6_MAX_NUM_OF_SEGMENT_LIST (4)

typedef enum hal_srv6_trav_type_e {
    HAL_SRV6_TRAV_TYPE_PORT,
    HAL_SRV6_TRAV_TYPE_LOCAL,
    HAL_SRV6_TRAV_TYPE_ENCAPS,
    HAL_SRV6_TRAV_TYPE_NVO3ROUTE,
    HAL_SRV6_TRAV_TYPE_ENDPOINT_POLICY,
    HAL_SRV6_TRAV_TYPE_LAST
} hal_srv6_trav_type_t;

#define HAL_SRV6_NVO3_ENCAPS_NUM           (8192)
#define HAL_SRV6_ENCAP_IDX_BITMAP_SIZE     (CLX_BITMAP_SIZE(HAL_TNL_NUM))
#define HAL_SRV6_LOCATOR_LABEL_NUM         (512)
#define HAL_SRV6_VPN_LABEL_NUM             (0x100000)
#define HAL_SRV6_LOCATOR_LABEL_BITMAP_SIZE (CLX_BITMAP_SIZE(HAL_SRV6_LOCATOR_LABEL_NUM))
#define HAL_SRV6_INVALID_ECMP_MBR_IDX      (0) /* Invalid FWR_RSLT_TNL_ECMP_MBR idx */

#define HAL_SRV6_TDS_SLV_HAH_BDO_SEL_NUM      (2)
#define HAL_SRV6_TDS_SLV_HAH_SRC_TEP_SEL_NUM  (4)
#define HAL_SRV6_TDS_SLV_HAH_MSGO_SEL_NUM     (2)
#define HAL_SRV6_TDS_SLV_HAH_MGO_SEL_NUM      (4)
#define HAL_SRV6_TDS_SLV_HAH_MPLS_LSP_SEL_NUM (2)

#define HAL_SRV6_HASH_SRV6_ENTRIES_PER_TILE (16 * 1024)
#define HAL_SRV6_TRAVERSE_DMA_ENTRY_NUM     (512)
#define HAL_SRV6_TRAVERSE_SLEEP_USEC        (5 * 1000)
#define HAL_SRV6_TRAVERSE_SLEEP_TH_DMA_NUM  (16)

#define HAL_SRV6_DROP_PKT_DISABLE              (0)
#define HAL_SRV6_DROP_PKT_UNTAGGED             (1)
#define HAL_SRV6_DROP_PKT_TAGGED               (2)
#define HAL_SRV6_DROP_PKT_TAGGED_EXPT_DFLT_VID (3)

/* NB FPU HSH DMA is 24 bytes alignment. TODO: maybe tob will have this macro */
#define HAL_SRV6_DMA_HSH_ENTRY_BYTES (24)

/* Unsupported attr_bmp list for CLX86 chip family */
#define HAL_NB_SRV6_LOCAL_ATTR_UNSUPPORTED                                               \
    (CLX_SRV6_LOCAL_ATTR_PRE_CIA_FAVOR_INNER | CLX_SRV6_LOCAL_ATTR_IGR_CIA_FAVOR_INNER | \
     CLX_SRV6_LOCAL_ATTR_ISOLATE_GRP_EN)
#define HAL_NB_SRV6_ENCAP_ATTR_UNSUPPORTED \
    (CLX_SRV6_ENCAP_ATTR_NH | CLX_SRV6_ENCAP_ATTR_ESI_ATTACH | CLX_SRV6_ENCAP_ATTR_ISOLATE_GRP_EN)
#define HAL_NB_SRV6_MYSID_ATTR_UNSUPPORTED                                               \
    (CLX_SRV6_MYSID_ATTR_PORT | CLX_SRV6_MYSID_ATTR_L3_INTF | CLX_SRV6_MYSID_ATTR_BDID | \
     CLX_SRV6_MYSID_ATTR_NH | CLX_SRV6_MYSID_ATTR_GRP_LBL | CLX_SRV6_MYSID_ATTR_TTL_KEEP)
/* Unsupported attr_bmp list for CLX84 chip family */
#define HAL_KG_SRV6_LOCAL_ATTR_UNSUPPORTED \
    (CLX_SRV6_LOCAL_ATTR_NOT_ALLOW_CTAG | CLX_SRV6_LOCAL_ATTR_DIST_CNT_ID)
#define HAL_KG_SRV6_ENCAP_ATTR_UNSUPPORTED (CLX_SRV6_ENCAP_ATTR_DIST_CNT_ID)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_SRV6_IS_ENCAP_BEHAVIOR(__beh__) \
    (((HAL_SRV6_BEHAVIOR_ENCAP & __beh__) > 0) ? TRUE : FALSE)
#define HAL_SRV6_IS_END_BEHAVIOR(__beh__) (((HAL_SRV6_BEHAVIOR_END & __beh__) > 0) ? TRUE : FALSE)
#define HAL_SRV6_IS_ENCAP_NHP(__beh__) \
    (((HAL_SRV6_BEHAVIOR_ENCAP_NHP & __beh__) > 0) ? TRUE : FALSE)
#define HAL_SRV6_SET_ENCAP_BEHAVIOR(__beh__) (__beh__ = (__beh__ | HAL_SRV6_BEHAVIOR_ENCAP))
#define HAL_SRV6_SET_END_BEHAVIOR(__beh__)   (__beh__ = (__beh__ | HAL_SRV6_BEHAVIOR_END))
#define HAL_SRV6_SET_ENCAP_NHP(__beh__)      (__beh__ = (__beh__ | HAL_SRV6_BEHAVIOR_ENCAP_NHP))
#define HAL_SRV6_CLR_ENCAP_BEHAVIOR(__beh__) (__beh__ = (__beh__ & ~HAL_SRV6_BEHAVIOR_ENCAP))
#define HAL_SRV6_CLR_END_BEHAVIOR(__beh__)   (__beh__ = (__beh__ & ~HAL_SRV6_BEHAVIOR_END))
#define HAL_SRV6_CLR_ENCAP_NHP(__beh__)      (__beh__ = (__beh__ & ~HAL_SRV6_BEHAVIOR_ENCAP_NHP))

#define HAL_SRV6_IPV6_IS_ZERO(ptr_ip) \
    (0x0 == (ptr_ip)[0] && 0 == osal_memcmp((ptr_ip), (ptr_ip) + 1, 15))

#define HAL_SRV6_CHECK_FLD_RANGE_VALID(__unit__, __tbl_id__, __field_id__, __value__)         \
    do {                                                                                      \
        if (!HAL_IS_UI32_FLD_RANGE_VALID(__unit__, __tbl_id__, __field_id__, __value__)) {    \
            UTIL_LOG_PRINT(UTIL_LOG_SRV6, UTIL_LOG_WARN, "u=%u, invalid " #__value__ "=%d\n", \
                           __unit__, __value__);                                              \
            return CLX_E_BAD_PARAMETER;                                                       \
        }                                                                                     \
    } while (0)

#define HAL_SRV6_FPU_SIZE(__bitmap__, __bitmap_size__, __fpu_size__, __size__) \
    do {                                                                       \
        uint32 bit;                                                            \
        __size__ = 0;                                                          \
        UTIL_LIB_BMP_BIT_FOREACH(__bitmap__, bit, __bitmap_size__)             \
        {                                                                      \
            __size__ = __size__ + __fpu_size__;                                \
        }                                                                      \
    } while (0)

#define HAL_SRV6_POLICY_SUPPORT(__unit__, __tile__)                                 \
    do {                                                                            \
        /* nb may have double fpu resources */                                      \
        if (UTIL_LIB_BMP_EMPTY((__tile__), HAL_SWC_HSH_TILE_BMP_SIZE * 2)) {        \
            UTIL_LOG_PRINT(UTIL_LOG_SRV6, UTIL_LOG_ERR,                             \
                           "u=%u, no hash tile for endpoint policy\n", (__unit__)); \
            return CLX_E_BAD_PARAMETER;                                             \
        }                                                                           \
    } while (0)

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_srv6_behavior_e {
    HAL_SRV6_BEHAVIOR_NONE = 0,
    HAL_SRV6_BEHAVIOR_ENCAP = (0x1U << 0),
    HAL_SRV6_BEHAVIOR_END = (0x1U << 1),
    HAL_SRV6_BEHAVIOR_ENCAP_NHP = (0x1U << 2),
    HAL_SRV6_BEHAVIOR_LAST
} hal_srv6_behavior_t;
typedef enum hal_srv6_wbdb_e {
    HAL_SRV6_WBDB_LOCATOR,
    HAL_SRV6_WBDB_FUNCTION,
    HAL_SRV6_WBDB_NVO3_RTE,
    HAL_SRV6_WBDB_ENCAP,
    HAL_SRV6_WBDB_SIDLIST,
    HAL_SRV6_WBDB_PORT_USAGE,
    HAL_SRV6_WBDB_LAST
} hal_srv6_wbdb_t;

typedef enum hal_srv6db_dump_flags_e {
    HAL_SRV6_DB_DUMP_FLAGS_PORT = 0,
    HAL_SRV6_DB_DUMP_FLAGS_LOCATOR,
    HAL_SRV6_DB_DUMP_FLAGS_FUNCTION,
    HAL_SRV6_DB_DUMP_FLAGS_LOCATOR_LABEL_ELEMENT,
    HAL_SRV6_DB_DUMP_FLAGS_NVO3_ROUTE,
    HAL_SRV6_DB_DUMP_FLAGS_LAST,
} hal_srv6db_dump_flags_t;

typedef struct hal_srv6_port_avl_node_s {
    uint32 srv6_beh; /* HAL_SRV6_BEHAVIOR_T */
    uint16 nvo3_encap_idx;
    uint32 tnl_lcl_idx;

    /* Source Node Result */
    uint32 ip_sa_idx;
    uint32 ip_da_idx;
    clx_srv6_encap_behavior_t encap_beh_code;
    /* sidlist could only use RWO_SRAM_TNL_IPDA0 in CLX84 as path sids */
    boolean use_ipda0_only;

    /* Endpoint Node Result */
    uint32 hsh_src_tep_idx;
    /* rmt_src_ip empty means don't care source node ip address,
     * in that case we need enable tapping-skip-src-ip-check */
    clx_ipv6_t rmt_src_ip;
    uint32 underlay_vrf;
} hal_srv6_port_avl_node_t;

typedef struct hal_srv6_nvo3_encap_element_s {
    hal_srv6_port_avl_node_t srv6_port_node;
} hal_srv6_nvo3_encap_element_t;

typedef struct hal_srv6_locator_key_s {
    uint16 underlay_vrf;
    uint32 locator_len;
    clx_ip_addr_t locator_ip;
} hal_srv6_locator_key_t;

typedef struct hal_srv6_locator_avl_node_s {
    hal_srv6_locator_key_t key; /* AVL tree key,  SRV6 locator */
    /* Data content */
    uint32 entry_idx;   /* index to TDS_TCAM_DST_TEP or TDS_HSH_DST_SRV6 */
    uint32 locator_lbl; /* locator label */
    boolean dst_tep_2x; /* not used on CLX84 */
} hal_srv6_locator_avl_node_t;

typedef struct hal_srv6_func_key_s {
    uint32 srv6_func;
    uint32 locator_lbl;
    uint32 function_len;
} hal_srv6_func_key_t;

typedef struct hal_srv6_func_avl_node_s {
    hal_srv6_func_key_t key; /* AVL tree key,  SRV6 Function */
    /* Data content */
    uint32 flags; /* CLX84 refer to HAL_MT_KG_SRV6_MYSID_FLAGS_XXX */
} hal_srv6_func_avl_node_t;

typedef struct hal_srv6_locator_label_element_s {
    hal_srv6_locator_avl_node_t *ptr_locator_node;
    util_lib_list_t *ptr_function_list;
} hal_srv6_locator_label_element_t;

typedef struct hal_srv6_sidlist_avl_node_s {
    clx_srv6_sidlist_t sidlist;
    uint16 prof_idx;
    uint16 ref_cnt;
} hal_srv6_sidlist_avl_node_t;

typedef struct hal_srv6_trav_port_node_s {
    clx_port_t port;
    clx_srv6_local_cfg_t local_info;
    clx_srv6_encap_cfg_t encap_info;
    clx_srv6_nvo3_route_info_t nvo3_route_info;
} hal_srv6_trav_port_node_t;

typedef struct hal_srv6_trav_mysid_node_s {
    clx_srv6_mysid_entry_t mysid_entry;
    clx_srv6_mysid_cfg_t mysid_info;
} hal_srv6_trav_mysid_node_t;

typedef struct hal_srv6_cb_s {
    util_lib_avl_head_t *ptr_locator_avl;       /* hal_srv6_locator_avl_node_t */
    util_lib_avl_head_t *ptr_function_avl;      /* hal_srv6_func_avl_node_t */
    util_lib_avl_head_t *ptr_iev_ecmp_path_avl; /* hal_cmn_rte_node_t   */
    hal_cmn_rte_node_t **pptr_iev_nvo3_adj_arr; /* maintain nvo3_adj_id->ecmp_path_idx relation */

    hal_srv6_locator_label_element_t *ptr_locator_lbl_arr; /* hal_srv6_locator_label_element_t    */
    hal_srv6_nvo3_encap_element_t *ptr_nvo3_encap_idx_arr; /* hal_srv6_nvo3_encap_element_t       */
    uint32 nvo3_encap_idx_bitmap[HAL_SRV6_ENCAP_IDX_BITMAP_SIZE];
    uint32 locator_lbl_bitmap[HAL_SRV6_LOCATOR_LABEL_BITMAP_SIZE];
    uint32 mode;        /* SRv6 mode: 1. normal; 2. G-SRv6; 3. uSID */
    uint32 locator_len; /* Locator size */
    uint32 func_len;    /* Function size */
    uint32 arg_len;     /* Argument size */
    clx_semaphore_id_t srv6_sema;

    uint32 hash_endpoint_policy_size[HAL_SWC_FPU_NUM];
    void *ptr_traverse_dma_entry_not_align;
    void *ptr_traverse_dma_entry;
    hal_swc_hsh_tile_bmp_t fpu_hsh_srv6_encap_tile_bmp;
    util_lib_avl_head_t *ptr_sidlist_avl; /* hal_srv6_sidlist_avl_node_t */
} hal_srv6_cb_t;

typedef hal_srv6_cb_t hal_srv6_cb_p[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
typedef uint32 hal_hsh_encap_entry_t[MT_NB_CDB_FPU_HSH_SRV6_ENCAP_WORDS];

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
clx_error_no_t
hal_srv6_init(const uint32 unit);

clx_error_no_t
hal_srv6_deinit(const uint32 unit);

clx_error_no_t
hal_srv6_port_create(const uint32 unit, const uint32 flag, clx_port_t *ptr_port);

clx_error_no_t
hal_srv6_port_destroy(const uint32 unit, const clx_port_t port);

clx_error_no_t
hal_srv6_port_trav(const uint32 unit, const clx_srv6_port_trav_func_t callback, void *ptr_cookie);

clx_error_no_t
hal_srv6_local_add(const uint32 unit,
                   const clx_port_t port,
                   const clx_srv6_local_cfg_t *ptr_local_info);

clx_error_no_t
hal_srv6_local_del(const uint32 unit, const clx_port_t port);

clx_error_no_t
hal_srv6_local_set(const uint32 unit,
                   const clx_port_t port,
                   const clx_srv6_local_cfg_t *ptr_local_info);

clx_error_no_t
hal_srv6_local_get(const uint32 unit, const clx_port_t port, clx_srv6_local_cfg_t *ptr_local_info);

clx_error_no_t
hal_srv6_local_trav(const uint32 unit, const clx_srv6_local_trav_func_t callback, void *ptr_cookie);

clx_error_no_t
hal_srv6_encap_add(const uint32 unit,
                   const clx_port_t port,
                   const clx_srv6_encap_cfg_t *ptr_encap_info);

clx_error_no_t
hal_srv6_encap_del(const uint32 unit, const clx_port_t port);

clx_error_no_t
hal_srv6_encap_set(const uint32 unit,
                   const clx_port_t port,
                   const clx_srv6_encap_cfg_t *ptr_encap_info);

clx_error_no_t
hal_srv6_encap_get(const uint32 unit, const clx_port_t port, clx_srv6_encap_cfg_t *ptr_encap_info);

clx_error_no_t
hal_srv6_encap_trav(const uint32 unit, const clx_srv6_encap_trav_func_t callback, void *ptr_cookie);

clx_error_no_t
hal_srv6_mysid_entry_add(const uint32 unit,
                         const clx_srv6_mysid_entry_t *ptr_mysid_entry,
                         const clx_srv6_mysid_cfg_t *ptr_mysid_info);

clx_error_no_t
hal_srv6_mysid_entry_del(const uint32 unit, const clx_srv6_mysid_entry_t *ptr_mysid_entry);

clx_error_no_t
hal_srv6_mysid_entry_set(const uint32 unit,
                         const clx_srv6_mysid_entry_t *ptr_mysid_entry,
                         const clx_srv6_mysid_cfg_t *ptr_mysid_info);

clx_error_no_t
hal_srv6_mysid_entry_get(const uint32 unit,
                         const clx_srv6_mysid_entry_t *ptr_mysid_entry,
                         clx_srv6_mysid_cfg_t *ptr_mysid_info);

clx_error_no_t
hal_srv6_mysid_entry_trav(const uint32 unit,
                          const clx_srv6_mysid_entry_trav_func_t callback,
                          void *ptr_cookie);

clx_error_no_t
hal_srv6_property_set(const uint32 unit, const clx_srv6_property_t *ptr_property);

clx_error_no_t
hal_srv6_property_get(const uint32 unit, clx_srv6_property_t *ptr_property);

clx_error_no_t
hal_srv6_nvo3_route_add(const uint32 unit,
                        const clx_port_t port,
                        const clx_srv6_nvo3_route_info_t *ptr_srv6_nvo3_route);

clx_error_no_t
hal_srv6_nvo3_route_set(const uint32 unit,
                        const clx_port_t port,
                        const clx_srv6_nvo3_route_info_t *ptr_srv6_nvo3_route);

clx_error_no_t
hal_srv6_nvo3_route_del(const uint32 unit, const clx_port_t port);

clx_error_no_t
hal_srv6_nvo3_route_get(const uint32 unit,
                        const clx_port_t port,
                        clx_srv6_nvo3_route_info_t *ptr_srv6_nvo3_route);

clx_error_no_t
hal_srv6_endpoint_policy_add(const uint32 unit,
                             const clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

clx_error_no_t
hal_srv6_endpoint_policy_del(const uint32 unit,
                             const clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

clx_error_no_t
hal_srv6_endpoint_policy_set(const uint32 unit,
                             const clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

clx_error_no_t
hal_srv6_endpoint_policy_get(const uint32 unit, clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

clx_error_no_t
hal_srv6_endpoint_policy_trav(const uint32 unit,
                              const clx_srv6_endpoint_policy_trav_func_t callback,
                              void *ptr_cookie);

clx_error_no_t
hal_srv6_seg_srv_add(const uint32 unit,
                     const clx_port_t port,
                     const uint32 service_id,
                     const uint32 bdid);

clx_error_no_t
hal_srv6_seg_srv_del(const uint32 unit, const clx_port_t port, const uint32 service_id);

clx_error_no_t
hal_srv6_seg_srv_set(const uint32 unit,
                     const clx_port_t port,
                     const uint32 service_id,
                     const uint32 bdid);

clx_error_no_t
hal_srv6_seg_srv_get(const uint32 unit,
                     const clx_port_t port,
                     const uint32 service_id,
                     uint32 *ptr_bdid);

clx_error_no_t
hal_srv6_nvo3_route_trav(const uint32 unit,
                         const clx_srv6_nvo3_route_trav_func_t callback,
                         void *ptr_cookie);

/* Below is internal Libary Function */
hal_srv6_cb_p *
hal_srv6_ctrl_block_get(const uint32 unit);

clx_error_no_t
hal_srv6_db_dump(const uint32 unit, const uint32 flags);

clx_error_no_t
hal_srv6_sw_init_info_get(const uint32 unit, const uint32 nvo3_encap_idx, clx_port_t *ptr_port);

clx_error_no_t
hal_srv6_hw_init_info_get(const uint32 unit,
                          const clx_port_t srv6_port,
                          uint32 *ptr_nvo3_encap_idx);

clx_error_no_t
hal_srv6_clx_port_compose(const uint32 unit, const uint32 nvo3_encap_idx, clx_port_t *ptr_port);

clx_error_no_t
hal_srv6_port_db_dump(const uint32 unit);

clx_error_no_t
hal_srv6_locator_db_dump(const uint32 unit);

clx_error_no_t
hal_srv6_func_db_dump(const uint32 unit);

clx_error_no_t
hal_srv6_locator_lbl_db_dump(const uint32 unit);

clx_error_no_t
hal_srv6_nvo3_encap_element_db_dump(const uint32 unit);

clx_error_no_t
hal_srv6_nvo3_route_db_dump(const uint32 unit);

clx_error_no_t
hal_srv6_port_validate(const uint32 unit, const clx_port_t port);

clx_error_no_t
hal_srv6_nvo3_adj_info_update(const uint32 unit,
                              const uint32 nvo3_adj_id,
                              const clx_port_t clx_port);

clx_error_no_t
hal_srv6_hash_action_set(const uint32 unit,
                         const clx_srv6_hash_type_t hash_type,
                         const clx_srv6_hash_action_t *ptr_hash_action);

clx_error_no_t
hal_srv6_hash_action_get(const uint32 unit,
                         const clx_srv6_hash_type_t hash_type,
                         clx_srv6_hash_action_t *ptr_hash_action);

/**
 * @brief Operate swdb ptr_sidlist_avl.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     swdb_action      - Swdb action.
 * @param [in]     ptr_in_node      - Swdb node to be operated (add/get/del).
 * @param [out]    pptr_out_node    - Swdb node to be returned (add/get).
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_srv6_sidlist_swdb_cfg(const uint32 unit,
                          const hal_cmn_action_t swdb_action,
                          hal_srv6_sidlist_avl_node_t *ptr_in_node,
                          hal_srv6_sidlist_avl_node_t **pptr_out_node);

clx_error_no_t
hal_srv6_encap_info_update(const uint32 unit,
                           const clx_srv6_encap_cfg_t *user_obj,
                           clx_srv6_encap_cfg_t *updated_obj);

clx_error_no_t
hal_srv6_property_update(const uint32 unit,
                         const clx_srv6_property_t *user_property,
                         clx_srv6_property_t *updated_property);

clx_error_no_t
hal_srv6_nvo3_encap_idx_get(const uint32 unit,
                            const clx_port_t srv6_port,
                            uint32 *ptr_nvo3_encap_idx);

/**
 * @brief Get swdb node by srv6_port.
 *
 * @param [in]     unit                   - Device unit number.
 * @param [in]     port                   - Tunnel port.
 * @param [out]    ptr_found_srv6_node    - Swdb_node got from srv6_port.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_srv6_swdb_node_get_by_port(const uint32 unit,
                               const clx_port_t port,
                               void **ptr_found_srv6_node);

/**
 * @brief Traverse swdb, save to list, then walk through list and trigger callback.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     type            - Swdb type to be traversed.
 * @param [in]     ptr_callback    - User callback.
 * @param [in]     ptr_cookie      - Input parameter of callback function.
 * @param [out]    ptr_cookie      - Output parameter of callback function.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_srv6_trav(const uint32 unit,
              const hal_srv6_trav_type_t type,
              const void *ptr_callback,
              void *ptr_cookie);

/**
 * @brief Traverse srv6 tunnel information then save to a list.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     type        - Swdb type to be traversed.
 * @param [out]    ptr_list    - List to store srv6 information.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_srv6_trav_list_trans(const uint32 unit,
                         const hal_srv6_trav_type_t type,
                         util_lib_list_t *ptr_list);

clx_error_no_t
hal_srv6_property_param_chk(const uint32 unit, const clx_srv6_property_t *ptr_property);

clx_error_no_t
hal_srv6_igr_sflow_prof_cfg(const uint32 unit,
                            const clx_srv6_local_cfg_t *ptr_local_info,
                            const uint32 ori_sflow_prof_id,
                            uint32 *ptr_new_sflow_prof_id);

void
hal_srv6_mysid_locator_key_retrieve(const uint32 unit,
                                    const clx_srv6_mysid_entry_t mysid_entry,
                                    hal_srv6_locator_key_t *key);

void
hal_srv6_mysid_func_key_retrieve(const uint32 unit,
                                 const clx_srv6_mysid_entry_t mysid_entry,
                                 hal_srv6_func_key_t *key);

/**
 * @brief Operate swdb ptr_locator_avl.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     swdb_action      - Swdb action.
 * @param [in]     ptr_in_node      - Swdb node to be operated (add/get/del).
 * @param [out]    pptr_out_node    - Swdb node to be returned (add/get).
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_NO_MEMORY          - No memory.
 * @return         CLX_E_OP_INVALID         - Invalid operation.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry not found.
 */
clx_error_no_t
hal_srv6_locator_swdb_cfg(const uint32 unit,
                          const hal_cmn_action_t swdb_action,
                          hal_srv6_locator_avl_node_t *ptr_in_node,
                          hal_srv6_locator_avl_node_t **pptr_out_node);

/**
 * @brief Operate swdb ptr_function_avl.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     swdb_action      - Swdb action.
 * @param [in]     ptr_in_node      - Swdb node to be operated (add/get/del).
 * @param [out]    pptr_out_node    - Swdb node to be returned (add/get).
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_NO_MEMORY          - No memory.
 * @return         CLX_E_OP_INVALID         - Invalid operation.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry not found.
 */
clx_error_no_t
hal_srv6_func_swdb_cfg(const uint32 unit,
                       const hal_cmn_action_t swdb_action,
                       hal_srv6_func_avl_node_t *ptr_in_node,
                       hal_srv6_func_avl_node_t **pptr_out_node);

clx_error_no_t
hal_srv6_locator_lbl_alloc(const uint32 unit, uint32 *ptr_locator_lbl);

void
hal_srv6_locator_func_mysid_retrieve(const hal_srv6_locator_key_t *ptr_locator_key,
                                     const hal_srv6_func_key_t *ptr_func_key,
                                     clx_srv6_mysid_entry_t *ptr_mysid_entry);

void
hal_srv6_list_node_free(void *ptr_node);

void
hal_srv6_mysid_ipv4_trans(clx_ipv4_t *ipv4, const clx_ipv6_t mysid, const uint32 size);

boolean
hal_srv6_l2vpn_apply(clx_srv6_endpoint_behavior_t beh_code);

boolean
hal_srv6_mysid_xc_type_chk(const clx_srv6_endpoint_behavior_t end_beh_code);

boolean
hal_srv6_mysid_endpoint_policy_type_chk(const clx_srv6_endpoint_behavior_t end_beh_code);

#endif /* End of HAL_SRV6_H */
