/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_export_ifdiag.h
 * PURPOSE:
 *      It provide interface diagnostic export module api.
 * NOTES:
 *
 */

#ifndef __HAL_EXPORT_IFDIAG_H__
#define __HAL_EXPORT_IFDIAG_H__

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_port.h>
#include <hal/hal_eparser.h>

#ifdef __cplusplus
extern "C" {
#endif

/* NAMING CONSTANT DECLARATIONS
 */
#ifndef CLX_PORT_LANE_MAX_NUM
#define CLX_PORT_LANE_MAX_NUM (8)
#endif
#ifndef DSH_MAX_HEX_NUM
#define DSH_MAX_HEX_NUM (16)
#endif

/* DATA TYPE DECLARATIONS
 */

/* Interface diagnostic message type definitions */
typedef enum hal_export_ifdiag_msg_type_e {
    HAL_EXPORT_IFDIAG_MSG_INVALID = 0,
    HAL_EXPORT_IFDIAG_MSG_START = 1,
    HAL_EXPORT_IFDIAG_MSG_DONE = 2,
    HAL_EXPORT_IFDIAG_MSG_ERROR = 3,
} hal_export_ifdiag_msg_type_t;

/* Message header structure with fragment flags. Only for reply, ahead of TLVs */
typedef struct hal_export_ifdiag_msg_hdr_s {
    hal_export_ifdiag_msg_type_t msg_type; /* Message type, should be 2 or 3 */
    uint8_t fragment_index;                /* Current fragment index, 0-based */
    uint8_t total_fragments;               /* Total number of fragments */
    uint16_t reserved;                     /* Reserved for future use */
} hal_export_ifdiag_msg_hdr_t;

typedef struct hal_export_ifdiag_request_msg_s {
    hal_export_ifdiag_msg_type_t msg_type; /* Message type, should be HAL_EXPORT_IFDIAG_MSG_START:1
                                            */
    uint8_t include_lane : 1;              /* 0: only port info, 1: port + lane*/
    uint8_t include_all_field : 1;         /* include all field flag */
    uint8_t reserved : 6;                  /* reserved bits for future use */
    uint8_t lane_number;                   /* lane array number, only for spec intf id,
                                              0xff used for max lane_number as asic define */
    uint16_t port_id;                      /* 0xFFFF: all, others: spec port id */
} hal_export_ifdiag_request_msg_t;

typedef struct hal_export_ifdiag_port_diag_base_tlv_s {
    uint32 admin_status;
    clx_port_speed_t port_speed;   /* enum type, 4 bytes */
    clx_port_medium_t port_medium; /* enum type, 4 bytes */
    uint32 port_fec;
} hal_export_ifdiag_port_diag_base_tlv_t;

typedef struct hal_export_ifdiag_lane_map_info_tlv_s {
    uint32 eth_macro;
    uint32 lane;
    uint32 hw_lane;
    clx_port_speed_t max_speed;  /* enum type, 4 bytes */
    uint32 flags;                /* used by CLX_PORT_FLAGS_XXX */
    clx_port_speed_t lane_speed; /* enum type, 4 bytes */
    uint32 ppid;
    uint32 port_di;
} hal_export_ifdiag_lane_map_info_tlv_t;

typedef struct hal_export_ifdiag_mac_diag_base_tlv_s {
    uint32 link_state;  /* link state 0-down, 1-up */
    uint32 fault_state; /* link fault state 0-not fault, 1-local fault, 2-remote fault*/
    uint32 ud_link_en;  /* mac unidirectional link enable */
} hal_export_ifdiag_mac_diag_base_tlv_t;

typedef struct hal_export_ifdiag_mac_cfg_tlv_s {
    /* channel cfg */
    uint32 mac_sw_reset;
    uint32 mac_chmode;
    uint32 mac_port_speed;
    uint32 mac_port_en;
    uint32 mac_lane_num;
    uint32 mac_fec_mode;
    uint32 mac_txswrst;
    uint32 mac_rxswrst;
    uint32 mac_gmiilpbk;
    uint32 mac_linkupignlf;
    uint32 mac_linkupignrf;
    /* mac cfg */
    uint32 mac_txlfault;
    uint32 mac_txrfault;
    uint32 mac_rxlfault;
    uint32 mac_rxrfault;
    uint32 mac_rxidle;
    uint32 mac_force_linkup;
    /* sd cfg */
    uint32 mac_rxremap[DSH_MAX_HEX_NUM]; /* get all channel rx remap value */
    uint32 mac_txremap[DSH_MAX_HEX_NUM]; /* get all channel tx remap value */
    uint32 mac_serdeslpbk[CLX_PORT_LANE_MAX_NUM];
} hal_export_ifdiag_mac_cfg_tlv_t;

typedef struct hal_export_ifdiag_mac_sts_tlv_s {
    /* pcs status*/
    uint32 rxsigokall;
    uint32 blocklockall;
    uint32 amlockall;
    uint32 aligned;
    uint32 nohiber;
    uint32 nolocalfault;
    uint32 noremotefault;
    uint32 linkup;
    uint32 hiser;
    /* sd status */
    uint32 txclkrate[CLX_PORT_LANE_MAX_NUM];
    uint32 rxclkrate[CLX_PORT_LANE_MAX_NUM];
    uint32 sigok[CLX_PORT_LANE_MAX_NUM];
} hal_export_ifdiag_mac_sts_tlv_t;

typedef struct hal_export_ifdiag_phy_diag_tlv_s {
    clx_port_lane_speed_t lane_speed[CLX_PORT_LANE_MAX_NUM]; /* enum type, 4 bytes each */
    clx_port_phy_mode_t lane_mode[CLX_PORT_LANE_MAX_NUM];    /* enum type, 4 bytes each */
    int32 tx_lane_list[CLX_PORT_LANE_MAX_NUM];
    int32 rx_lane_list[CLX_PORT_LANE_MAX_NUM];
    int32 g_tx_lane_list[CLX_PORT_LANE_MAX_NUM];
    int32 g_rx_lane_list[CLX_PORT_LANE_MAX_NUM];
    int32 tx_swap[CLX_PORT_LANE_MAX_NUM];
    int32 rx_swap[CLX_PORT_LANE_MAX_NUM];
    int32 tx_pol[CLX_PORT_LANE_MAX_NUM];
    int32 rx_pol[CLX_PORT_LANE_MAX_NUM];
    int32 coeff_pre3[CLX_PORT_LANE_MAX_NUM];
    int32 coeff_pre2[CLX_PORT_LANE_MAX_NUM];
    int32 coeff_pre1[CLX_PORT_LANE_MAX_NUM];
    int32 coeff_main[CLX_PORT_LANE_MAX_NUM];
    int32 coeff_post1[CLX_PORT_LANE_MAX_NUM];
    int32 coeff_post2[CLX_PORT_LANE_MAX_NUM];
    int32 coeff_post3[CLX_PORT_LANE_MAX_NUM];
    uint32 pll_lock[CLX_PORT_LANE_MAX_NUM];
    uint32 cdr_lock[CLX_PORT_LANE_MAX_NUM];
    uint32 signal_detect[CLX_PORT_LANE_MAX_NUM];
    uint32 tx_state[CLX_PORT_LANE_MAX_NUM];
    uint32 rx_state[CLX_PORT_LANE_MAX_NUM];
    uint32 prbs_tx_en[CLX_PORT_LANE_MAX_NUM];
    clx_port_prbs_pattern_t prbs_tx_pattern[CLX_PORT_LANE_MAX_NUM]; /* enum type, 4 bytes each */
    uint32 prbs_rx_en[CLX_PORT_LANE_MAX_NUM];
    clx_port_prbs_pattern_t prbs_rx_pattern[CLX_PORT_LANE_MAX_NUM]; /* enum type, 4 bytes each */
    uint32 pma_status[CLX_PORT_LANE_MAX_NUM];
    uint32 an_enable;
    uint32 an_complete;
} hal_export_ifdiag_phy_diag_tlv_t;

typedef struct hal_export_ifdiag_fec_cnt_tlv_s {
    uint64 fec_cerr_codeword;
    uint64 fec_cerr_sym_err[16];
    uint64 fec_ucerr_codeword;
    uint64 fec_ch_sym_err;
    uint64 rsfec_lane_sym_err[32];
    uint64 rsfec_sd_lane_sym_err[8];
#define CLX_PORT_FEC_TYPE_COUNTERED_CODEWORDS            (1U << 0)
#define CLX_PORT_FEC_TYPE_COUNTERED_SYMBOL_ERROR_COUNTER (1U << 1)
#define CLX_PORT_FEC_TYPE_UNCOTTECTED_CODEWORDS          (1U << 2)
#define CLX_PORT_FEC_TYPE_CH_SYMBOL_ERROR_COUNTER        (1U << 3)
#define CLX_PORT_FEC_TYPE_SD_LANE_SYMBOL_ERROR_COUNTER   (1U << 4)
    uint32 fec_type_bmp;
} hal_export_ifdiag_fec_cnt_tlv_t;

typedef enum hal_export_ifdiag_notify_event_e {
    HAL_EXPORT_IFDIAG_EVT_INVALID = 0,
    HAL_EXPORT_IFDIAG_EVT_THREAD_EXIT = 1,
} hal_export_ifdiag_notify_event_t;

/* Interface diagnostic TLV type definitions */
#define HAL_EXPORT_TLV_TYPE_IFDIAG_PORT_COUNT (0x20) /* Port entry count, uint32_t */
#define HAL_EXPORT_TLV_TYPE_IFDIAG_PORT_ID    (0x21) /* Port ID, uint32_t */
#define HAL_EXPORT_TLV_TYPE_IFDIAG_PORT_CFG_BASE \
    (0x22) /* Port config base, hal_export_ifdiag_port_diag_base_tlv_t */
#define HAL_EXPORT_TLV_TYPE_IFDIAG_MAC_CFG \
    (0x23) /* MAC configuration, hal_export_ifdiag_mac_cfg_tlv_t */
#define HAL_EXPORT_TLV_TYPE_IFDIAG_MAC_STS                \
    (0x24) /* MAC status, hal_export_ifdiag_mac_sts_tlv_t \
            */
#define HAL_EXPORT_TLV_TYPE_IFDIAG_PHY_DIAG \
    (0x25) /* PHY diagnostic, hal_export_ifdiag_phy_diag_tlv_t */
#define HAL_EXPORT_TLV_TYPE_IFDIAG_FEC_CNT \
    (0x26) /* FEC counters, hal_export_ifdiag_fec_cnt_tlv_t */
#define HAL_EXPORT_TLV_TYPE_IFDIAG_MAC_DIAG_BASE \
    (0x27) /* MAC diagnostic base, hal_export_ifdiag_mac_diag_base_tlv_t */
#define HAL_EXPORT_TLV_TYPE_IFDIAG_LANE_MAP_INFO \
    (0x28) /* Lane map info, hal_export_ifdiag_lane_map_info_tlv_t */

/**
 * @brief This API is used to initialize the interface diagnostic export module.
 *
 * @param [in]    unit    - Chip unit number.
 * @return        CLX_E_OK    - Operation successful.
 */
clx_error_no_t
hal_export_ifdiag_init(uint32 unit);

/**
 * @brief This API is used to deinitialize the interface diagnostic export module.
 *
 * @param [in]    unit    - Chip unit number.
 * @return        CLX_E_OK        - Operation successful.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_export_ifdiag_deinit(uint32 unit);

/**
 * @brief This API is used to handle interface diagnostic export start request.
 *
 * @param [in]    unit        - Chip unit number.
 * @param [in]    msg_type    - Message type.
 * @param [in]    msg         - Message pointer.
 * @param [in]    length      - Message length.
 * @return        CLX_E_OK            - Operation successful.
 * @return        CLX_E_NOT_INITED    - Module not initialized.
 * @return        CLX_E_NO_MEMORY     - Memory allocation failed.
 * @return        CLX_E_OTHERS        - Operation failed.
 */
clx_error_no_t
hal_export_ifdiag_handle_start(uint32 unit,
                               hal_eparser_msg_type_t msg_type,
                               void *msg,
                               uint32_t length);

/**
 * @brief This API is used to process interface diagnostic module event.
 *
 * Handle eparser COMMON_NOTIFY events for IFDIAG module. Typically used to stop and
 * destroy export thread and clean up runtime state.
 *
 * @param [in]    unit        - Chip unit number.
 * @param [in]    data        - Event data pointer (can be NULL).
 * @param [in]    data_len    - Event data length in bytes.
 * @return        CLX_E_OK        - Operation successful.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_export_ifdiag_event_proc(uint32 unit, void *data, uint32_t data_len);

#ifdef __cplusplus
}
#endif
#endif /* __HAL_EXPORT_IFDIAG_H__ */
