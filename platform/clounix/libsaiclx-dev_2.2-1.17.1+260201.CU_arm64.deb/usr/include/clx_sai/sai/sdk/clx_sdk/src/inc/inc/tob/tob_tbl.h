/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME: tob_tbl.h
 * PURPOSE:
 *     This file is used to declare the common data types for
 *     the whole switch.
 *
 * NOTES:
 *
 */

#ifndef TOB_TBL_H
#define TOB_TBL_H
/*----------------------------------------------------------
 * Include Header File(s)
 *----------------------------------------------------------
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_port.h>
#include <osal/osal.h>
#include <tob/mt/tbl/nb/tob_mt_nb_tbl.h>
#include <tob/mt/tbl/kg/tob_mt_kg_tbl.h>

/*----------------------------------------------------------
 * STRUCT: Type Declaration
 *----------------------------------------------------------
 */

typedef enum {
    MEMORY_TYPE_TABLE_MAP = 0,
    MEMORY_TYPE_TABLE_TCAM,
    MEMORY_TYPE_TABLE_TCAM_COM,
    MEMORY_TYPE_TABLE_HASH,
    MEMORY_TYPE_TABLE_SHARE,
    MEMORY_TYPE_REG,
    MEMORY_TYPE_REG_MMIO,
    MEMORY_TYPE_TABLE_MAP_INDIRECT,
    TABLE_TYPE_LAST
} memory_type_t;

typedef enum {
    TOB_HW_DUP_TYPE_NONE = 0,
    TOB_HW_DUP_TYPE_DIE,
    TOB_HW_DUP_TYPE_BIN,
    TOB_HW_DUP_TYPE_PLANE,
    TOB_HW_DUP_TYPE_FPU,
    TOB_HW_DUP_TYPE_LAST,
} tob_hw_dup_type_t;

typedef enum { MEMORY_SPACE_INTERNAL = 0, MEMORY_SPACE_MMIO, MEMORY_SPACE_LAST } memory_space_t;

typedef enum reg_access_type_s {
    REG_ACCESS_TYPE_NONE = 0,
    REG_ACCESS_TYPE_READ_ONLY,
    REG_ACCESS_TYPE_READ_CLEAR,
    REG_ACCESS_TYPE_READ_WRITE,
    REG_ACCESS_TYPE_WRITE_ZERO_CLEAR,
    REG_ACCESS_TYPE_WRITE_ONE_CLEAR,
    REG_ACCESS_TYPE_LAST
} reg_access_type_t;

typedef struct _packing_info_t {
#define ACCESS_PROPERTY_2SC_FIELD    (0x1 << 4)
#define ACCESS_PROPERTY_SIGNED_FIELD (0x1 << 3)
#define ACCESS_PROPERTY_NON_TESTABLE (0x1 << 2)
#define ACCESS_PROPERTY_NON_WRITABLE (0x1 << 1)
#define ACCESS_PROPERTY_NON_READABLE (0x1 << 0)
    uint16 offset;
    uint16 length;
    uint16 access_property;
    uint8 int_len;  /* number of bit of integer part, only valid for signed fields */
    uint8 frac_len; /* number of bit of fraction part, only valid for signed fields */
    char *ptr_field_name;
} packing_info_t;

typedef struct table_access_addr_info_s {
    uint32 cmd;
    uint32 addr;
    uint32 status;
    uint32 rdata;
    uint32 wdata;
} table_access_addr_info_t;

#define CLX_TABLE_INFO_CHECK_REGISTER_SIZE 2
typedef struct _table_info_t {
    char *ptr_table_name;
    memory_type_t memory_type;
    reg_access_type_t reg_access_type;
    tob_hw_dup_type_t duplicate_type;
    uint32 table_addr;
    uint32 table_total_fields;
    uint32 slot_size;
    uint32 subinst_offset;
    uint32 subinst_count;
    uint32 entry_size;
    uint32 entry_msb;
    uint32 entry_offset;
    uint32 entry_max_number;
    uint32 shared_table_id;
    uint32 alt_addr;
    packing_info_t *ptr_table_entry;
    table_access_addr_info_t access_addr_info;
    uint32 reset_value[CLX_TABLE_INFO_CHECK_REGISTER_SIZE];
    uint32 flags;
} table_info_t;
#define CLX_TABLE_INFO_FLAGS_ECC_ENABLE      (1 << 0)
#define CLX_TABLE_INFO_FLAGS_ECC_FIELD_EXIST (1 << 1)
#define CLX_TABLE_INFO_FLAGS_ACCESS_IND      (1 << 2)

typedef struct _tcam_tbl_meta_s {
    uint32 width;
#ifdef ASICSIM_ACCESS
    uint32 com_tcam_width;
#endif
    uint32 tcell[4];
    uint32 ccell[4];
    uint32 tvalid[4];
    uint32 cvalid[4];
} tcam_tbl_meta_t;

typedef struct _hash_tbl_meta_s {
    uint32 indr_addr;
    uint32 trig_addr;
    uint16 view;
    uint16 width;
    uint32 max_num_to_power;
} hash_tbl_meta_t;

typedef struct tob_tbl_cb_s {
    table_info_t **pptr_tbl_info;        /* table information pointer */
    packing_info_t **pptr_tbl_key_info;  /* table key information pointer for hash */
    tcam_tbl_meta_t *ptr_tcam_meta_info; /* tcam meta info pointer */
    hash_tbl_meta_t *ptr_hash_meta_info; /* tcam hash info pointer */
    clx_semaphore_id_t *ptr_sema_id;     /* semaphore information pointer */
} tob_tbl_cb_t;

#define TOB_MAXIMUM_CHIPS_PER_SYSTEM (16) /* same as CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM */

extern tob_tbl_cb_t _ext_tob_control_block[TOB_MAXIMUM_CHIPS_PER_SYSTEM];

typedef table_info_t tob_table_t;
typedef packing_info_t tob_field_t;
typedef tcam_tbl_meta_t tob_tcam_t;
typedef hash_tbl_meta_t tob_hash_t;

#define TOB_TBL_INFO(unit, tbl_id)      _ext_tob_control_block[unit].pptr_tbl_info[tob_tbl_hw_id_get(unit, tbl_id)]
#define TOB_TBL_KEY_INFO(unit, tbl_id)  _ext_tob_control_block[unit].pptr_tbl_key_info[tob_tbl_hw_id_get(unit, tbl_id)]
#define TOB_TBL_SEMA_INFO(unit, tbl_id) &(_ext_tob_control_block[unit].ptr_sema_id[tob_tbl_hw_id_get(unit, tbl_id)])
#define TOB_TBL_TCAM_INFO(unit, idx)    _ext_tob_control_block[unit].ptr_tcam_meta_info[idx]
#define TOB_TBL_HASH_INFO(unit, idx)    _ext_tob_control_block[unit].ptr_hash_meta_info[idx]
#define TOB_TABLE                       TOB_TBL_INFO
#define TOB_TCAM                        TOB_TBL_TCAM_INFO
#define TOB_HASH                        TOB_TBL_HASH_INFO
#define TOB_TBL_INVALID_ID              0xFFFFFFFF /* TOB invalid table id */

/*----------------------------------------------------------
 * MACRO: Type Declaration
 *----------------------------------------------------------
 */
#define BITS_OF_UI32   (32)
#define MAX_ENTRY_SIZE (512) /* Byte */
#define MAX_FIELD_NUM  (512)
#define MAX_FIELD_SIZE (224) /* Byte */

#define TOB_BYTES_OF_WORD       (4)
#define TOB_MAX_ENTRY_WORD_SIZE (MAX_ENTRY_SIZE / TOB_BYTES_OF_WORD)

extern uint32 _ext_tob_zero_buf[TOB_MAX_ENTRY_WORD_SIZE];

/*----------------------------------------------------------
 * ENUM: Type Declaration
 *----------------------------------------------------------
 */

/**
 * @brief Hardware table id get by common software table id.
 *
 * Support_chip: all.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    sw_tbl_id    - Common software table id.
 * @return        uint32    - Hardware table id, if return TOB_TBL_INVALID_ID,
 *                            get failed.
 */
uint32
tob_tbl_hw_id_get(const uint32 unit, const uint32 sw_tbl_id);

/**
 * @brief Mask field with 0xFF to ptr_dst buffer.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     tbl_id      - Table ID.
 * @param [in]     field_id    - The field of this table(tbl_id).
 * @param [out]    ptr_dst     - The return packed hardware view mask shadow table entry.
 * @return         CLX_E_OK        - Pack field successfully.
 * @return         CLX_E_OTHERS    - Fail to pack field.
 */
clx_error_no_t
tob_tbl_field_mask(const uint32 unit, const uint32 tbl_id, const uint32 field_id, uint32 *ptr_dst);

/**
 * @brief Substitute the specified bits (field) in the entry buffer with the content in field
 *        buffer.
 *
 * @param [in]     unit         - Unit number.
 * @param [in]     table_id     - Table ID.
 * @param [in]     field_id     - Field ID.
 * @param [in]     offset       - Offset of the field.
 * @param [in]     length       - Length of the field.
 * @param [in]     ptr_entry    - Pointer to the entry buffer.
 * @param [in]     ptr_field    - Pointer to the field buffer.
 * @param [out]    ptr_entry    - Pointer to the entry buffer.
 */
void
tob_tbl_field_pack(const uint32 unit,
                   const uint32 table_id,
                   const uint32 field_id,
                   const uint32 offset,
                   const uint32 length,
                   uint32 *ptr_entry,
                   const uint32 *ptr_field);

/**
 * @brief Extract the specified field from an entry buffer info field buffer.
 *
 * @param [in]     unit         - Unit number.
 * @param [in]     table_id     - Table ID.
 * @param [in]     field_id     - Field ID.
 * @param [in]     offset       - Offset of the field.
 * @param [in]     length       - Length of the field.
 * @param [in]     ptr_entry    - Pointer to the entry buffer.
 * @param [out]    ptr_field    - Pointer to the field buffer.
 */
void
tob_tbl_field_unpack(const uint32 unit,
                     const uint32 table_id,
                     const uint32 field_id,
                     const uint32 offset,
                     const uint32 length,
                     const uint32 *ptr_entry,
                     uint32 *ptr_field);

/**
 * @brief Substitute the specified bits (field) in the entry buffer with the field value.
 *
 * @param [in]     unit         - Unit number.
 * @param [in]     table_id     - Table ID.
 * @param [in]     field_id     - Field ID.
 * @param [in]     offset       - Offset of the field.
 * @param [in]     length       - Length of the field.
 * @param [in]     ptr_entry    - Pointer to the entry buffer.
 * @param [in]     field        - Field value.
 * @param [out]    ptr_entry    - Pointer to the entry buffer.
 */
void
tob_tbl_ui32_field_pack(const uint32 unit,
                        const uint32 table_id,
                        const uint32 field_id,
                        const uint32 offset,
                        const uint32 length,
                        uint32 *ptr_entry,
                        const uint32 field);

/**
 * @brief Extract the specified field from an entry buffer.
 *
 * @param [in]    unit         - Unit number.
 * @param [in]    table_id     - Table ID.
 * @param [in]    field_id     - Field ID.
 * @param [in]    offset       - Offset of the field.
 * @param [in]    length       - Length of the field.
 * @param [in]    ptr_entry    - Pointer to the entry buffer.
 * @return        Field value.
 */
uint32
tob_tbl_ui32_field_unpack(const uint32 unit,
                          const uint32 table_id,
                          const uint32 field_id,
                          const uint32 offset,
                          const uint32 length,
                          const uint32 *ptr_entry);

/**
 * @brief Tob_tbl_sema_lock() is responsible for lock specific table.
 *
 * @param [in]    unit      - The unit number.
 * @param [in]    tbl_id    - The table id.
 * @return        CLX_E_OK        - Successfully read table.
 * @return        CLX_E_OTHERS    - Fail to read table.
 */
clx_error_no_t
tob_tbl_sema_lock(const uint32 unit, const uint32 tbl_id);

/**
 * @brief Tob_tbl_sema_unlock() is responsible for unlock specific table.
 *
 * @param [in]    unit      - The unit number.
 * @param [in]    tbl_id    - The table id.
 * @return        CLX_E_OK        - Successfully read table.
 * @return        CLX_E_OTHERS    - Fail to read table.
 */
clx_error_no_t
tob_tbl_sema_unlock(const uint32 unit, const uint32 tbl_id);

/**
 * @brief Get last table id.
 *
 * @param [in]     unit           - Device unit number.
 * @param [out]    last_tbl_id    - The return last table id.
 * @return         CLX_E_OK          - Get success.
 * @return         CLX_E_BAD_CASE    - Error chip family.
 */
clx_error_no_t
tob_tbl_last_tbl_id_get(const uint32 unit, uint32 *last_tbl_id);

/**
 * @brief Tob table init.
 *
 * Support_chip: all.
 *
 * @param [in]    unit    - Unit number.
 * @return        CLX_E_OK        - Init success.
 * @return        CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
tob_tbl_init(const uint32 unit);

/**
 * @brief Tob table deinit.
 *
 * Support_chip: all.
 *
 * @param [in]    unit    - Unit number.
 * @return        CLX_E_OK        - Deinit success.
 * @return        CLX_E_OTHERS    - Deinit fail.
 */
clx_error_no_t
tob_tbl_deinit(const uint32 unit);

#endif /* end of #ifndef TOB_TBL_H */
