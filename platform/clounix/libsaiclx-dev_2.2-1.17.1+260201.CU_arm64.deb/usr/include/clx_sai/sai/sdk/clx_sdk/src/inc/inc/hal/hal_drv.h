/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_drv.h
 * PURPOSE:
 *  Provide HAL driver structure and driver help APIs.
 *
 * NOTES:
 */

#ifndef HAL_DRV_H
#define HAL_DRV_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>
#include <clx/clx_bd.h>
#include <clx/clx_vlan.h>
#include <clx/clx_netif.h>
#include <clx/clx_pkt.h>
#include <clx/clx_cia.h>
#include <clx/clx_sec.h>
#include <clx/clx_l2.h>
#include <clx/clx_stp.h>
#include <clx/clx_lag.h>
#include <clx/clx_mir.h>
#include <clx/clx_l3.h>
#include <clx/clx_tnl.h>
#include <clx/clx_srv6.h>
#include <clx/clx_qos.h>
#include <clx/clx_swc.h>
#include <clx/clx_meter.h>
#include <clx/clx_stat.h>
#include <clx/clx_mpls.h>
#include <clx/clx_tm.h>
#include <clx/clx_init.h>
#include <clx/clx_stk.h>
#include <clx/clx_telm.h>
#include <clx/clx_ecc.h>
#include <clx/clx_ecpu.h>
#include <clx/clx_bfd.h>
#include <clx/clx_ptp.h>
#include <clx/clx_nfe.h>
#include <clx/clx_vm.h>
#include <clx/clx_wlan.h>
#include <drv/drv.h>
#include <hal/hal_intr.h>
#include <hal/hal_ecc.h>
#include <tob/tob_tbl.h>
#include <hal/hal_const.h>
#include <hal/hal_cmn_drv.h>
#include <hal/hal_pkt_rsrc.h>
#include <hal/hal_dflt.h>
#include <hal/hal_pkj.h>
#include <hal/hal_phy.h>
#include <hal/hal_d2d.h>
#include <hal/hal_ifmon.h>
#include <hal/hal_ecpu_ringbuffer.h>
#include <hal/hal_ecpu.h>
#include <hal/mt/ecpu/hal_mt_ecpu_bfd.h>
#include <hal/mt/ecpu/hal_mt_ecpu_ptp.h>
#include <hal/mt/hal_mt_telm.h>
#include <hal/mt/hal_mt_ifmon.h>
/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MAX_NUM_OF_PLANE   (8)
#define HAL_RIM_SW_TBL_BASE_ID (1U << 31)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef clx_error_no_t (*HAL_CHIP_MMIO_INIT_FUNC_T)(const uint32 unit);

typedef clx_error_no_t (*HAL_CHIP_INIT_FUNC_T)(const uint32 unit);

typedef clx_error_no_t (*HAL_CHIP_DEINIT_FUNC_T)(const uint32 unit);

/* bd multiplexing functions */

typedef clx_error_no_t (*HAL_BD_INIT)(const uint32 unit);

typedef clx_error_no_t (*HAL_BD_DEINIT)(const uint32 unit);

typedef clx_error_no_t (*HAL_BD_CREATE)(const uint32 unit, const clx_bridge_domain_t bdid);

typedef clx_error_no_t (*HAL_BD_DESTROY)(const uint32 unit, const clx_bridge_domain_t bdid);
typedef clx_error_no_t (*HAL_BD_CFG_SET)(const uint32 unit,
                                         const clx_bridge_domain_t bdid,
                                         const clx_bd_cfg_t *ptr_bd_cfg);

typedef clx_error_no_t (*HAL_BD_CFG_GET)(const uint32 unit,
                                         const clx_bridge_domain_t bdid,
                                         clx_bd_cfg_t *ptr_bd_cfg);

typedef clx_error_no_t (*HAL_BD_CREATED_PRINT)(const uint32 unit);

typedef clx_error_no_t (*HAL_BD_CAPACITY_GET)(const uint32 unit,
                                              const clx_swc_rsrc_t type,
                                              const uint32 param,
                                              uint32 *ptr_size);

typedef clx_error_no_t (*HAL_BD_USAGE_GET)(const uint32 unit,
                                           const clx_swc_rsrc_t type,
                                           const uint32 param,
                                           uint32 *ptr_cnt);

/* vlan multiplexing functions */

typedef clx_error_no_t (*HAL_VLAN_INIT_FUNC_T)(const uint32 unit);

typedef clx_error_no_t (*HAL_VLAN_DEINIT_FUNC_T)(const uint32 unit);

typedef clx_error_no_t (*HAL_VLAN_CREATE_FUNC_T)(const uint32 unit, const uint32 vid);

typedef clx_error_no_t (*HAL_VLAN_DESTROY_FUNC_T)(const uint32 unit, const uint32 vid);

typedef clx_error_no_t (*HAL_VLAN_IGR_HSH_PRINT_FUNC_T)(const uint32 unit,
                                                        const uint32 lcl_intf,
                                                        const clx_vlan_t s_vlan,
                                                        const clx_vlan_t c_vlan);

typedef clx_error_no_t (*HAL_VLAN_EGR_HSH_PRINT_FUNC_T)(const uint32 unit,
                                                        const uint32 lcl_intf,
                                                        const clx_bridge_domain_t bdi);

typedef clx_error_no_t (*HAL_VLAN_TRAV_FUNC_T)(const uint32 unit,
                                               const CLX_VLAN_TRAV_FUNC_T callback,
                                               void *ptr_cookie);

typedef clx_error_no_t (*HAL_VLAN_BD_BIND_FUNC_T)(const uint32 unit,
                                                  const clx_vlan_t vid,
                                                  const clx_bridge_domain_t bdid);

typedef clx_error_no_t (*HAL_VLAN_BD_UNBIND_FUNC_T)(const uint32 unit,
                                                    const clx_vlan_t vid,
                                                    const clx_bridge_domain_t bdid);

typedef clx_error_no_t (*HAL_VLAN_BD_GET_FUNC_T)(const uint32 unit,
                                                 const clx_vlan_t vid,
                                                 clx_bridge_domain_t *bdid);

typedef clx_error_no_t (*HAL_VLAN_PORT_GET_FUNC_T)(const uint32 unit,
                                                   const clx_vlan_t vid,
                                                   clx_port_bitmap_t port_bmp,
                                                   clx_port_bitmap_t ut_port_bmp);
typedef clx_error_no_t (*HAL_VLAN_TYPE_SET_FUNC_T)(const uint32 unit,
                                                   const clx_vlan_t vid,
                                                   const clx_vlan_type_t type);

typedef clx_error_no_t (*HAL_VLAN_TYPE_GET_FUNC_T)(const uint32 unit,
                                                   const clx_vlan_t vid,
                                                   clx_vlan_type_t *type);

typedef clx_error_no_t (*HAL_VLAN_PRIVATE_TPORT_ADD)(const uint32 unit,
                                                     const clx_vlan_t vid,
                                                     const clx_port_bitmap_t port_bmp);

typedef clx_error_no_t (*HAL_VLAN_PRIVATE_TPORT_DEL)(const uint32 unit,
                                                     const clx_vlan_t vid,
                                                     const clx_port_bitmap_t port_bmp);

typedef clx_error_no_t (*HAL_VLAN_PRIVATE_TPORT_GET)(const uint32 unit,
                                                     const clx_vlan_t vid,
                                                     clx_port_bitmap_t port_bmp);

typedef clx_error_no_t (*hal_chip_cfg_info_get_func_t)(const uint32 unit,
                                                       const clx_swc_chip_cfg_info_type_t type,
                                                       const uint32 para0,
                                                       const uint32 para1,
                                                       uint32 *ptr_value);

typedef clx_error_no_t (*HAL_VLAN_PORT_ADD_FUNC_T)(const uint32 unit,
                                                   const clx_vlan_t vid,
                                                   const clx_port_bitmap_t port_bmp,
                                                   const clx_port_bitmap_t ut_port_bmp);

typedef clx_error_no_t (*HAL_VLAN_PORT_DEL_FUNC_T)(const uint32 unit,
                                                   const clx_vlan_t vid,
                                                   const clx_port_bitmap_t port_bmp);

typedef clx_error_no_t (*HAL_VLAN_TAG_MODE_SET_FUNC_T)(const uint32 unit,
                                                       const clx_vlan_t vid,
                                                       const clx_port_bitmap_t port_bmp,
                                                       const clx_vlan_tag_mode_t mode);

typedef clx_error_no_t (*HAL_VLAN_EXT_TPID_ADD_FUNC_T)(const uint32 unit,
                                                       const clx_vlan_ext_tpid_type_t type,
                                                       const clx_vlan_ext_tpid_grp_t tpid_grp);

typedef clx_error_no_t (*HAL_VLAN_EXT_TPID_DEL_FUNC_T)(const uint32 unit,
                                                       const clx_vlan_ext_tpid_type_t type,
                                                       const clx_vlan_ext_tpid_grp_t tpid_grp);

typedef clx_error_no_t (*HAL_VLAN_EXT_TPID_GET_FUNC_T)(const uint32 unit,
                                                       const clx_vlan_ext_tpid_type_t type,
                                                       clx_vlan_ext_tpid_grp_t tpid_grp);

typedef clx_error_no_t (*HAL_VLAN_MAC_VLAN_ADD_FUNC_T)(const uint32 unit,
                                                       const clx_mac_t mac,
                                                       const clx_vlan_t vid,
                                                       const uint8 prio);

typedef clx_error_no_t (*HAL_VLAN_MAC_VLAN_DEL_FUNC_T)(const uint32 unit, const clx_mac_t mac);

typedef clx_error_no_t (*HAL_VLAN_MAC_VLAN_GET_FUNC_T)(const uint32 unit,
                                                       const clx_mac_t mac,
                                                       clx_vlan_t *ptr_vid,
                                                       uint8 *ptr_prio);

typedef clx_error_no_t (*HAL_VLAN_VLAN_CLASSIFY_PRIO_SET_FUNC_T)(
    const uint32 unit,
    const clx_vlan_classify_prio_type_t type,
    const uint32 prio);

typedef clx_error_no_t (*HAL_VLAN_VLAN_CLASSIFY_PRIO_GET_FUNC_T)(
    const uint32 unit,
    const clx_vlan_classify_prio_type_t type,
    uint32 *ptr_prio);

typedef clx_error_no_t (*HAL_VLAN_RANGE_MAPPING_SET_FUNC_T)(
    const uint32 unit,
    const uint32 index,
    const clx_vlan_range_mapping_cfg_t *ptr_cfg);

typedef clx_error_no_t (*HAL_VLAN_RANGE_MAPPING_GET_FUNC_T)(const uint32 unit,
                                                            const uint32 index,
                                                            clx_vlan_range_mapping_cfg_t *ptr_cfg);

/* Port multiplexing functions */
typedef clx_error_no_t (*hal_port_cfg_set_func_t)(const uint32 unit,
                                                  const uint32 port,
                                                  const clx_port_cfg_t *ptr_config);

typedef clx_error_no_t (*hal_port_cfg_get_func_t)(const uint32 unit,
                                                  const uint32 port,
                                                  clx_port_cfg_t *ptr_config);

typedef clx_error_no_t (*hal_port_speed_set_func_t)(const uint32 unit,
                                                    const uint32 port,
                                                    const clx_port_speed_t speed);

typedef clx_error_no_t (*hal_port_speed_get_func_t)(const uint32 unit,
                                                    const uint32 port,
                                                    clx_port_speed_t *ptr_speed);

typedef clx_error_no_t (*hal_port_speed_list_get_func_t)(const uint32 unit,
                                                         const uint32 port,
                                                         const uint32 max_len,
                                                         clx_port_speed_t *ptr_speed_list);

typedef clx_error_no_t (*hal_port_flow_ctrl_set_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        const clx_port_fc_dir_t fc);

typedef clx_error_no_t (*hal_port_flow_ctrl_get_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        clx_port_fc_dir_t *ptr_fc);

typedef clx_error_no_t (*hal_port_pri_flow_ctrl_set_func_t)(const uint32 unit,
                                                            const uint32 port,
                                                            const uint8 pri,
                                                            const clx_port_fc_dir_t pfc);

typedef clx_error_no_t (*hal_port_pri_flow_ctrl_get_func_t)(const uint32 unit,
                                                            const uint32 port,
                                                            const uint8 pri,
                                                            clx_port_fc_dir_t *ptr_pfc);

typedef clx_error_no_t (*hal_port_eee_mode_set_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const clx_port_eee_mode_t mode);

typedef clx_error_no_t (*hal_port_eee_mode_get_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       clx_port_eee_mode_t *ptr_mode);

typedef clx_error_no_t (*hal_port_local_adv_ability_set_func_t)(
    const uint32 unit,
    const uint32 port,
    const clx_port_ability_t *ptr_ability);

typedef clx_error_no_t (*hal_port_local_adv_ability_get_func_t)(const uint32 unit,
                                                                const uint32 port,
                                                                clx_port_ability_t *ptr_ability);

typedef clx_error_no_t (*hal_port_remote_adv_ability_get_func_t)(const uint32 unit,
                                                                 const uint32 port,
                                                                 clx_port_ability_t *ptr_ability);

typedef clx_error_no_t (*hal_port_ability_get_func_t)(const uint32 unit,
                                                      const uint32 port,
                                                      clx_port_ability_t *ptr_ability);

typedef clx_error_no_t (*hal_port_loopback_set_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const clx_port_loopback_t lbtype);

typedef clx_error_no_t (*hal_port_loopback_get_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       clx_port_loopback_t *ptr_lbtype);

typedef clx_error_no_t (*hal_port_probe_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_port_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_port_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_port_cfg_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_port_create_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_port_ext_create_func_t)(
    const uint32 unit,
    const uint32 port,
    const clx_port_create_config_t *ptr_create_config);

typedef clx_error_no_t (*hal_port_destroy_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_port_mac_addr_set_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const clx_mac_t mac);

typedef clx_error_no_t (*hal_port_mac_addr_get_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       clx_mac_t *ptr_mac);

typedef clx_error_no_t (*hal_port_link_get_func_t)(const uint32 unit,
                                                   const uint32 port,
                                                   uint32 *ptr_link);

typedef clx_error_no_t (*hal_port_fault_get_func_t)(const uint32 unit,
                                                    const uint32 port,
                                                    uint32 *ptr_fault);

typedef clx_error_no_t (*hal_port_temperature_get_func_t)(const uint32 unit,
                                                          const uint32 port,
                                                          int32 *ptr_temp);

typedef clx_error_no_t (*hal_port_medium_type_set_func_t)(const uint32 unit,
                                                          const uint32 port,
                                                          const clx_port_medium_t medium);

typedef clx_error_no_t (*hal_port_medium_type_get_func_t)(const uint32 unit,
                                                          const uint32 port,
                                                          clx_port_medium_t *ptr_medium);

typedef clx_error_no_t (*hal_port_phy_cfg_set_func_t)(const uint32 unit,
                                                      const uint32 port,
                                                      const clx_port_phy_cfg_t *ptr_config);

typedef clx_error_no_t (*hal_port_phy_cfg_get_func_t)(const uint32 unit,
                                                      const uint32 port,
                                                      clx_port_phy_cfg_t *ptr_config);

typedef clx_error_no_t (*hal_port_lane_map_set_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const clx_port_lane_map_info_t *ptr_lane_map);

typedef clx_error_no_t (*hal_port_lane_map_get_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       clx_port_lane_map_info_t *ptr_lane_map);

typedef clx_error_no_t (*hal_port_vlan_bd_bind_func_t)(const uint32 unit,
                                                       const clx_port_t port,
                                                       const uint32 svid,
                                                       const uint32 cvid,
                                                       const clx_bridge_domain_t bdid);

typedef clx_error_no_t (*hal_port_vlan_bd_unbind_func_t)(const uint32 unit,
                                                         const clx_port_t port,
                                                         const uint32 svid,
                                                         const uint32 cvid,
                                                         const clx_bridge_domain_t bdid);

typedef clx_error_no_t (*hal_port_vlan_bd_get_func_t)(const uint32 unit,
                                                      const clx_port_t port,
                                                      const uint32 svid,
                                                      const uint32 cvid,
                                                      clx_bridge_domain_t *ptr_bdid);

typedef clx_error_no_t (*hal_port_gport_create_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       clx_port_t *ptr_intf);

typedef clx_error_no_t (*hal_port_gport_destroy_func_t)(const uint32 unit, clx_port_t intf);

typedef clx_error_no_t (*hal_port_intf_cfg_set_func_t)(const uint32 unit,
                                                       const clx_port_t intf,
                                                       const clx_port_intf_cfg_t *ptr_property);

typedef clx_error_no_t (*hal_port_intf_cfg_get_func_t)(const uint32 unit,
                                                       const clx_port_t intf,
                                                       clx_port_intf_cfg_t *ptr_property);

typedef clx_error_no_t (*hal_port_ts_tx_entry_get_func_t)(const uint32 unit,
                                                          const uint32 port,
                                                          clx_port_ts_entry_t *ptr_ts_entry);

typedef clx_error_no_t (*hal_port_ts_rx_entry_get_func_t)(const uint32 unit,
                                                          const uint32 port,
                                                          clx_port_ts_entry_t *ptr_ts_entry);

typedef clx_error_no_t (*hal_port_type_get_func_t)(const uint32 unit,
                                                   const clx_port_t port,
                                                   clx_gport_type_t *ptr_type);

typedef clx_error_no_t (*hal_port_status_get_func_t)(const uint32 unit,
                                                     const clx_port_t port,
                                                     clx_port_status_t *ptr_status);

typedef clx_error_no_t (*hal_port_port_to_gport_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        clx_port_t *ptr_port);

typedef clx_error_no_t (*hal_port_gport_to_port_func_t)(const uint32 unit,
                                                        const clx_port_t clx_port,
                                                        uint32 *ptr_port);

typedef clx_error_no_t (*hal_port_mac_rxidle_set_func_t)(const uint32 unit,
                                                         const uint32 port,
                                                         const uint32 enable);

typedef clx_error_no_t (*hal_port_tx_coef_set_func_t)(const uint32 unit,
                                                      const uint32 port,
                                                      const uint32 lane_idx,
                                                      const clx_port_phy_location_t location,
                                                      clx_port_tx_coef_t *ptr_tx_coef);

typedef clx_error_no_t (*hal_port_tx_coef_get_func_t)(const uint32 unit,
                                                      const uint32 port,
                                                      const uint32 lane_idx,
                                                      const clx_port_phy_location_t location,
                                                      clx_port_tx_coef_t *ptr_tx_coef);

typedef clx_error_no_t (*hal_port_adv_intf_type_set_func_t)(const uint32 unit,
                                                            const uint32 port,
                                                            const uint32 intf_type);

typedef clx_error_no_t (*hal_port_vlan_tag_ctrl_get_func_t)(const uint32 unit,
                                                            const clx_port_t port,
                                                            const clx_bridge_domain_t bdid,
                                                            clx_port_vlan_tag_ctrl_t *ptr_port_tag);

typedef clx_error_no_t (*hal_port_vlan_tag_ctrl_set_func_t)(
    const uint32 unit,
    const clx_port_t port,
    const clx_bridge_domain_t bdid,
    const clx_port_vlan_tag_ctrl_t *ptr_port_tag);

typedef clx_error_no_t (*hal_port_intf_group_create_func_t)(const uint32 unit,
                                                            const clx_dir_t dir,
                                                            const uint32 *group_id);

typedef clx_error_no_t (*hal_port_intf_group_member_add_func_t)(const uint32 unit,
                                                                const clx_dir_t dir,
                                                                const uint32 group_id,
                                                                const clx_port_bitmap_t port_bitmap);

typedef clx_error_no_t (*hal_port_intf_group_member_del_func_t)(const uint32 unit,
                                                                const clx_dir_t dir,
                                                                const uint32 group_id,
                                                                const clx_port_bitmap_t port_bitmap);

typedef clx_error_no_t (*hal_port_intf_group_member_get_func_t)(const uint32 unit,
                                                                const clx_dir_t dir,
                                                                const uint32 group_id,
                                                                clx_port_bitmap_t port_bitmap);

typedef clx_error_no_t (*hal_port_intf_group_id_get_func_t)(const uint32 unit,
                                                            const clx_dir_t dir,
                                                            const clx_port_t port,
                                                            uint32 *group_id);

typedef clx_error_no_t (*hal_port_intf_group_destroy_func_t)(const uint32 unit,
                                                             const clx_dir_t dir,
                                                             const uint32 group_id);

typedef clx_error_no_t (*hal_port_egr_high_latency_threshold_set_func_t)(const uint32 unit,
                                                                         const uint32 threshold);

typedef clx_error_no_t (*hal_port_egr_high_latency_threshold_get_func_t)(const uint32 unit,
                                                                         uint32 *threshold);

typedef clx_error_no_t (*hal_port_intf_group_get_func_t)(const uint32 unit,
                                                         const clx_dir_t dir,
                                                         const clx_port_t port);

typedef clx_error_no_t (*hal_port_mburst_cfg_set_func_t)(const uint32 unit,
                                                         const clx_port_t port,
                                                         const clx_port_mburst_cfg_t *ptr_property);

typedef clx_error_no_t (*hal_port_mburst_cfg_get_func_t)(const uint32 unit,
                                                         const clx_port_t port,
                                                         clx_port_mburst_cfg_t *ptr_property);

typedef clx_error_no_t (*hal_port_mburst_stat_get_func_t)(const uint32 unit,
                                                          const clx_port_t port,
                                                          const clx_dir_t dir,
                                                          clx_port_mburst_stat_t *p_stat);

typedef clx_error_no_t (*hal_port_mburst_hist_cnt_get_func_t)(const uint32 unit,
                                                              const clx_port_t port,
                                                              const clx_dir_t dir,
                                                              const clx_port_t thrd_num,
                                                              uint32 *p_count);

typedef clx_error_no_t (*hal_port_mburst_cnt_clear_func_t)(const uint32 unit,
                                                           const clx_port_t port,
                                                           const clx_dir_t dir);

typedef clx_error_no_t (*hal_port_fec_clear_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_port_xoff_status_get_func_t)(const uint32 unit,
                                                          const uint32 port,
                                                          clx_port_xoff_status_t *ptr_xoff_status);

typedef clx_error_no_t (*hal_port_dbg_info_show_func_t)(const uint32 unit,
                                                        const clx_port_t port,
                                                        const uint32 module,
                                                        const uint32 type);

typedef clx_error_no_t (*hal_port_tx_signal_register_func_t)(const uint32 unit,
                                                             clx_port_phy_notify_func_t func,
                                                             void *ptr_cookie);
typedef clx_error_no_t (*hal_port_tx_state_set_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const uint32 enable);

typedef clx_error_no_t (*hal_port_pkt_drop_set_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const uint32 enable);

typedef clx_error_no_t (*HAL_PORT_DI_SET_FUNC_T)(const uint32 unit,
                                                 const uint32 port,
                                                 const uint32 di);

typedef clx_error_no_t (*hal_port_tc2q_map_set_func_t)(uint32 unit,
                                                       uint32 port,
                                                       clx_dir_t dir,
                                                       uint32 *tc2q_map);

typedef clx_error_no_t (*hal_port_tc2q_map_get_func_t)(uint32 unit,
                                                       uint32 port,
                                                       clx_dir_t dir,
                                                       uint32 *tc2q_map);

typedef clx_error_no_t (*hal_port_egress_xoff_mask_port_pltc_set_func_t)(const uint32 unit,
                                                                         const uint32 port,
                                                                         const uint32 pltc_bmp,
                                                                         uint32 enable);

typedef clx_error_no_t (*hal_port_q2tc_map_get_func_t)(uint32 unit,
                                                       uint32 port,
                                                       clx_dir_t dir,
                                                       uint32 *q2tc_map);

typedef clx_error_no_t (*hal_port_q2tc_map_set_func_t)(uint32 unit,
                                                       uint32 port,
                                                       clx_dir_t dir,
                                                       uint32 *q2tc_map);

typedef clx_error_no_t (*hal_port_ingress_fc_mode_get_func_t)(uint32 unit,
                                                              uint32 port,
                                                              uint32 *ptr_mode);

typedef clx_error_no_t (*hal_port_ingress_dscp_pltc_map_set_func_t)(uint32 unit,
                                                                    uint32 port,
                                                                    uint32 dscp,
                                                                    uint32 ptr_loss_idx);

typedef clx_error_no_t (*hal_port_ingress_dscp_pltc_map_get_func_t)(uint32 unit,
                                                                    uint32 port,
                                                                    uint32 dscp,
                                                                    uint32 *ptr_loss_idx);

typedef clx_error_no_t (*hal_port_ingress_vlan_pltc_map_get_func_t)(uint32 unit,
                                                                    uint32 port,
                                                                    uint32 pcp,
                                                                    uint32 dei,
                                                                    uint32 *ptr_loss_idx);

typedef clx_error_no_t (*hal_port_ingress_vlan_pltc_map_set_func_t)(uint32 unit,
                                                                    uint32 port,
                                                                    uint32 pcp,
                                                                    uint32 dei,
                                                                    uint32 ptr_loss_idx);

typedef clx_error_no_t (*hal_port_ingress_exp_pltc_map_get_func_t)(uint32 unit,
                                                                   uint32 port,
                                                                   uint32 exp,
                                                                   uint32 *ptr_loss_idx);

typedef clx_error_no_t (*hal_port_ingress_exp_pltc_map_set_func_t)(uint32 unit,
                                                                   uint32 port,
                                                                   uint32 exp,
                                                                   uint32 ptr_loss_idx);

typedef clx_error_no_t (*hal_port_dead_lock_set_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        const uint32 queue,
                                                        const uint32 mode);

typedef clx_error_no_t (*hal_port_dead_lock_th_set_func_t)(const uint32 unit,
                                                           const uint32 port,
                                                           uint32 threshold);

typedef clx_error_no_t (*hal_port_egress_que_flush_en_set_func_t)(const uint32 unit,
                                                                  const uint32 port,
                                                                  const uint32 queue_type,
                                                                  const uint32 enable);

typedef clx_error_no_t (*hal_port_egress_flow_ctrl_ignore_set_func_t)(const uint32 unit,
                                                                      const uint32 port,
                                                                      const uint32 queue_type,
                                                                      const uint32 enable);

typedef clx_error_no_t (*hal_port_reset_portlist_update_func_t)(const uint32 unit,
                                                                const uint32 init_lane_cnt,
                                                                const clx_port_speed_t init_speed,
                                                                clx_port_bitmap_t *ptr_portlist,
                                                                clx_port_bitmap_t *ptr_init_portlist,
                                                                uint32 *init_port_cnt);

typedef clx_error_no_t (*hal_port_laneswap_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_port_synce_process_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        const uint32 value);

typedef clx_error_no_t (*hal_port_intf_obj_vlan_act_add_func_t)(
    const uint32 unit,
    const clx_port_intf_obj_vlan_act_t *ptr_act_info);

typedef clx_error_no_t (*hal_port_intf_obj_vlan_act_del_func_t)(
    const uint32 unit,
    const clx_port_intf_obj_vlan_act_t *ptr_act_info);
typedef clx_error_no_t (*hal_port_intf_obj_vlan_act_update_func_t)(
    const uint32 unit,
    const clx_port_intf_obj_vlan_act_t *ptr_act_info);
typedef clx_error_no_t (*hal_port_intf_obj_vlan_act_get_func_t)(
    const uint32 unit,
    clx_port_intf_obj_vlan_act_t *ptr_act_info);
typedef clx_error_no_t (*hal_port_intf_obj_bd_bind_func_t)(
    const uint32 unit,
    const clx_port_intf_obj_bd_bind_t *ptr_bind_info);
typedef clx_error_no_t (*hal_port_intf_obj_bd_unbind_func_t)(
    const uint32 unit,
    const clx_port_intf_obj_bd_bind_t *ptr_bind_info);
typedef clx_error_no_t (*hal_port_intf_obj_bd_get_func_t)(
    const uint32 unit,
    clx_port_intf_obj_bd_bind_t *ptr_bind_info);

/* lag multiplexing functions */
typedef clx_error_no_t (*hal_lag_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_lag_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_lag_create_func_t)(const uint32 unit,
                                                const clx_lag_create_info_t *ptr_lag_create_info,
                                                uint32 *ptr_lag_id,
                                                clx_port_t *ptr_lag_port);

typedef clx_error_no_t (*hal_lag_destroy_func_t)(const uint32 unit, const uint32 lag_id);

typedef clx_error_no_t (*hal_lag_member_set_func_t)(const uint32 unit,
                                                    const uint32 lag_id,
                                                    const uint32 member_cnt,
                                                    const clx_lag_member_t *ptr_member);

typedef clx_error_no_t (*hal_lag_member_get_func_t)(const uint32 unit,
                                                    const uint32 lag_id,
                                                    const uint32 member_cnt,
                                                    clx_lag_member_t *ptr_member_info,
                                                    uint32 *ptr_actual_member_cnt);

typedef clx_error_no_t (*hal_lag_member_cnt_get_func_t)(const uint32 unit,
                                                        const uint32 lag_id,
                                                        uint32 *ptr_member_cnt);

typedef clx_error_no_t (*hal_lag_trav_func_t)(const uint32 unit,
                                              const clx_lag_trav_func_t callback,
                                              void *ptr_cookie);

typedef clx_error_no_t (*hal_lag_port_get_func_t)(const uint32 unit,
                                                  uint32 lag_id,
                                                  clx_port_t *ptr_lag_port);

typedef clx_error_no_t (*hal_lag_id_get_func_t)(const uint32 unit,
                                                clx_port_t lag_port,
                                                uint32 *ptr_lag_id);

typedef clx_error_no_t (*hal_lag_attr_set_func_t)(const uint32 unit,
                                                  const clx_port_t lag_id,
                                                  const clx_lag_attr_t *ptr_attr);

typedef clx_error_no_t (*hal_lag_attr_get_func_t)(const uint32 unit,
                                                  const clx_port_t lag_id,
                                                  clx_lag_attr_t *ptr_attr);

typedef clx_error_no_t (*hal_lag_fdl_create_func_t)(const uint32 unit,
                                                    const clx_lag_fdl_info_t *ptr_fdl_info,
                                                    uint32 *ptr_fdl_id);

typedef clx_error_no_t (*hal_lag_fdl_destroy_func_t)(const uint32 unit, const uint32 fdl_id);

typedef clx_error_no_t (*hal_lag_fdl_set_func_t)(const uint32 unit,
                                                 const clx_lag_fdl_info_t *ptr_fdl_info,
                                                 const uint32 fdl_id);

typedef clx_error_no_t (*hal_lag_fdl_get_func_t)(const uint32 unit,
                                                 const uint32 fdl_id,
                                                 clx_lag_fdl_info_t *ptr_fdl_info);
/*mirror multiplexing functions */
typedef clx_error_no_t (*hal_mir_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_mir_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_mir_session_add_func_t)(const uint32 unit,
                                                     const clx_mir_direct_t direction,
                                                     const uint32 mir_id,
                                                     const clx_mir_session_cfg_t *ptr_session_cfg);

typedef clx_error_no_t (*hal_mir_session_del_func_t)(const uint32 unit,
                                                     const clx_mir_direct_t direction,
                                                     const uint32 mir_id);

typedef clx_error_no_t (*hal_mir_session_get_func_t)(const uint32 unit,
                                                     const clx_mir_direct_t direction,
                                                     const uint32 mir_id,
                                                     clx_mir_session_cfg_t *ptr_session_cfg);

typedef clx_error_no_t (*hal_mir_erspan_decap_add_func_t)(
    const uint32 unit,
    const clx_mir_erspan_decap_key_t *ptr_decap_key,
    const uint32 mir_id);

typedef clx_error_no_t (*hal_mir_erspan_decap_del_func_t)(
    const uint32 unit,
    const clx_mir_erspan_decap_key_t *ptr_decap_key);

typedef clx_error_no_t (*hal_mir_erspan_decap_get_func_t)(
    const uint32 unit,
    const clx_mir_erspan_decap_key_t *ptr_decap_key,
    uint32 *ptr_mir_id);
typedef clx_error_no_t (*hal_mir_erspan_decap_trav_func_t)(
    const uint32 unit,
    const clx_mir_erspan_decap_trav_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_mir_selective_flow_mir_set_func_t)(
    const uint32 unit,
    const clx_swc_selective_flow_cfg_t *ptr_select_cfg);

typedef clx_error_no_t (*hal_mir_selective_flow_mir_get_func_t)(
    const uint32 unit,
    clx_swc_selective_flow_cfg_t *ptr_select_cfg);

typedef clx_error_no_t (*hal_mir_global_param_set_func_t)(const uint32 unit,
                                                          const uint32 property,
                                                          const uint32 param0);

typedef clx_error_no_t (*hal_mir_global_param_get_func_t)(const uint32 unit,
                                                          const uint32 property,
                                                          uint32 *ptr_param0);

/*l3 multiplexing functions */
typedef clx_error_no_t (*hal_l3_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_l3_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_l3_intf_add_func_t)(const uint32 unit, clx_l3_intf_t *ptr_l3_intf);

typedef clx_error_no_t (*hal_l3_intf_del_func_t)(const uint32 unit, const uint32 intf_id);

typedef clx_error_no_t (*hal_l3_intf_get_func_t)(const uint32 unit, clx_l3_intf_t *ptr_l3_intf);

typedef clx_error_no_t (*hal_l3_intf_trav_func_t)(const uint32 unit,
                                                  const clx_l3_intf_trav_func_t cb,
                                                  void *ptr_cookie);

typedef clx_error_no_t (*hal_l3_rmac_add_func_t)(const uint32 unit, const clx_l3_rmac_t *ptr_rmac);

typedef clx_error_no_t (*hal_l3_rmac_del_func_t)(const uint32 unit, const uint32 idx);

typedef clx_error_no_t (*hal_l3_rmac_get_func_t)(const uint32 unit, clx_l3_rmac_t *ptr_rmac);

typedef clx_error_no_t (*hal_l3_rmac_trav_func_t)(const uint32 unit,
                                                  const clx_l3_rmac_trav_func_t cb,
                                                  void *ptr_cookie);

typedef clx_error_no_t (*hal_l3_adj_add_func_t)(const uint32 unit, clx_l3_adj_t *ptr_adj_info);

typedef clx_error_no_t (*hal_l3_adj_del_func_t)(const uint32 unit, const uint32 adj_id);

typedef clx_error_no_t (*hal_l3_adj_get_func_t)(const uint32 unit, clx_l3_adj_t *ptr_adj_info);

typedef clx_error_no_t (*hal_l3_adj_trav_func_t)(const uint32 unit,
                                                 const clx_l3_adj_type_t type,
                                                 const clx_l3_adj_trav_func_t callback,
                                                 void *ptr_cookie);

typedef clx_error_no_t (*hal_l3_host_add_func_t)(const uint32 unit, const clx_l3_host_t *ptr_host);

typedef clx_error_no_t (*hal_l3_host_del_func_t)(const uint32 unit,
                                                 const clx_l3_addr_t *ptr_host_addr);

typedef clx_error_no_t (*hal_l3_host_get_func_t)(const uint32 unit, clx_l3_host_t *ptr_host);

typedef clx_error_no_t (*hal_l3_host_trav_func_t)(const uint32 unit,
                                                  const clx_l3_host_trav_func_t callback,
                                                  void *ptr_cookie);

typedef clx_error_no_t (*hal_l3_host_flush_func_t)(const uint32 unit,
                                                   const clx_l3_host_t *ptr_host);

typedef clx_error_no_t (*hal_l3_subnet_bcast_add_func_t)(const uint32 unit,
                                                         const clx_l3_subnet_bcast_t *ptr_subnet);

typedef clx_error_no_t (*hal_l3_subnet_bcast_del_func_t)(const uint32 unit,
                                                         const clx_l3_addr_t *ptr_subnet_addr);

typedef clx_error_no_t (*hal_l3_subnet_bcast_get_func_t)(const uint32 unit,
                                                         clx_l3_subnet_bcast_t *ptr_subnet);

typedef clx_error_no_t (*hal_l3_subnet_bcast_trav_func_t)(const uint32 unit,
                                                          const clx_l3_bcast_trav_func_t cb,
                                                          void *ptr_subnet);

typedef clx_error_no_t (*hal_l3_route_add_func_t)(const uint32 unit,
                                                  const clx_l3_route_t *ptr_route);
typedef clx_error_no_t (*hal_l3_route_del_func_t)(const uint32 unit,
                                                  const clx_l3_addr_t *ptr_route_addr);

typedef clx_error_no_t (*hal_l3_route_get_func_t)(const uint32 unit, clx_l3_route_t *ptr_route);

typedef clx_error_no_t (*hal_l3_route_trav_func_t)(const uint32 unit,
                                                   const clx_l3_route_trav_func_t cb,
                                                   void *ptr_cookie);

typedef clx_error_no_t (*hal_l3_bulk_route_add_func_t)(const uint32 unit,
                                                       const clx_bulk_op_mode_t mode,
                                                       clx_l3_bulk_route_t *ptr_bulk_route);

typedef clx_error_no_t (*hal_l3_bulk_route_del_func_t)(const uint32 unit,
                                                       const clx_bulk_op_mode_t mode,
                                                       clx_l3_bulk_route_t *ptr_bulk_route);

typedef clx_error_no_t (*hal_l3_bulk_route_get_func_t)(const uint32 unit,
                                                       clx_l3_route_t *ptr_route);

typedef clx_error_no_t (*hal_l3_route_usage_get_func_t)(const uint32 unit,
                                                        const uint32 param,
                                                        uint32 *ptr_cnt);

typedef clx_error_no_t (*hal_l3_bulk_route_dump_func_t)(const uint32 unit,
                                                        const uint32 v4_low_mask,
                                                        const uint32 v6_low_mask);

typedef clx_error_no_t (*hal_l3_ecmp_grp_add_func_t)(const uint32 unit,
                                                     clx_l3_ecmp_grp_t *ptr_ecmp);

typedef clx_error_no_t (*hal_l3_ecmp_grp_del_func_t)(const uint32 unit, uint32 ecmp_id);

typedef clx_error_no_t (*hal_l3_ecmp_grp_get_func_t)(const uint32 unit,
                                                     clx_l3_ecmp_grp_t *ptr_ecmp);

typedef clx_error_no_t (*hal_l3_ecmp_grp_trav_func_t)(const uint32 unit,
                                                      const clx_nhp_type_t type,
                                                      const clx_l3_ecmp_grp_trav_func_t cb,
                                                      void *ptr_cookie);

typedef clx_error_no_t (*hal_l3_ecmp_grp_sync_func_t)(const uint32 unit,
                                                      const uint32 ori_ecmp_id,
                                                      const uint32 cur_ecmp_id);

typedef clx_error_no_t (*hal_l3_ecmp_path_add_func_t)(const uint32 unit,
                                                      const clx_l3_ecmp_path_t *ptr_path);

typedef clx_error_no_t (*hal_l3_ecmp_path_del_func_t)(const uint32 unit,
                                                      const clx_l3_ecmp_path_t *ptr_path);

typedef clx_error_no_t (*hal_l3_ecmp_path_get_by_idx_func_t)(const uint32 unit,
                                                             const uint32 path_idx,
                                                             clx_l3_ecmp_path_t *ptr_path);

typedef clx_error_no_t (
    *hal_l3_ecmp_path_hsh_set_func_t)(const uint32 unit, const clx_l3_ecmp_path_hsh_t *ptr_hsh_set);

typedef clx_error_no_t (*hal_l3_ecmp_path_hsh_get_func_t)(const uint32 unit,
                                                          clx_l3_ecmp_path_hsh_t *ptr_hsh_get);

typedef clx_error_no_t (*hal_l3_ecmp_path_list_set_func_t)(const uint32 unit,
                                                           const boolean is_org,
                                                           const uint32 idx,
                                                           const clx_l3_ecmp_path_t *ptr_path);

typedef clx_error_no_t (
    *hal_l3_ecmp_all_path_list_get_func_t)(const uint32 unit, clx_l3_ecmp_all_path_t *allPatchInfo);

typedef clx_error_no_t (*hal_l3_ecmp_path_list_get_func_t)(const uint32 unit,
                                                           const boolean is_org,
                                                           const uint32 idx,
                                                           clx_l3_ecmp_path_t *ptr_path);
typedef clx_error_no_t (*hal_l3_ecmp_fdl_get_func_t)(const uint32 unit, clx_l3_fdl_t *ptr_fdl_info);
typedef clx_error_no_t (*hal_l3_ecmp_fdl_add_func_t)(const uint32 unit, clx_l3_fdl_t *ptr_fdl_info);
typedef clx_error_no_t (*hal_l3_ecmp_fdl_del_func_t)(const uint32 unit, const uint32 fdl_id);

typedef clx_error_no_t (*hal_l3_ecmp_ar_get_func_t)(const uint32 unit, clx_l3_ar_t *ptr_ar_info);
typedef clx_error_no_t (*hal_l3_ecmp_ar_add_func_t)(const uint32 unit, clx_l3_ar_t *ptr_ar_info);
typedef clx_error_no_t (*hal_l3_ecmp_ar_del_func_t)(const uint32 unit, const uint32 ar_id);

typedef clx_error_no_t (*hal_l3_vrf_set_func_t)(const uint32 unit, const clx_l3_vrf_t *ptr_vrf);

typedef clx_error_no_t (*hal_l3_vrf_get_func_t)(const uint32 unit, clx_l3_vrf_t *ptr_vrf);

typedef clx_error_no_t (*hal_l3_ecmp_path_hsh_calc_func_t)(
    const uint32 unit,
    const clx_swc_hsh_pkt_type_t hash_type,
    const clx_swc_flow_hsh_key_t *ptr_hash_key,
    const uint32 ecmp_grp_id,
    clx_l3_ecmp_path_hsh_rslt_t *ptr_rslt);

typedef clx_error_no_t (*hal_l3_ecmp_path_list_dump_func_t)(const uint32 unit,
                                                            const uint32 ecmp_grp_id);

/*l3 multicast multiplexing functions */
typedef clx_error_no_t (*hal_l3_mcast_grp_create_func_t)(const uint32 unit,
                                                         const uint32 flags,
                                                         uint32 *ptr_mcast_id);

typedef clx_error_no_t (*hal_l3_mcast_grp_destroy_func_t)(const uint32 unit, const uint32 mcast_id);

typedef clx_error_no_t (*hal_l3_mcast_port_bmp_get_func_t)(const uint32 unit,
                                                           const uint32 mcast_id,
                                                           clx_port_bitmap_t port_bitmap);

typedef clx_error_no_t (
    *hal_l3_mcast_route_add_func_t)(const uint32 unit, const clx_l3_mcast_route_t *ptr_mcast_route);

typedef clx_error_no_t (*hal_l3_mcast_route_del_func_t)(const uint32 unit,
                                                        const clx_l3_mcast_addr_t *ptr_mcast_addr);

typedef clx_error_no_t (*hal_l3_mcast_route_get_func_t)(const uint32 unit,
                                                        clx_l3_mcast_route_t *ptr_mcast_route);

typedef clx_error_no_t (*hal_l3_mcast_egr_intf_add_func_t)(const uint32 unit,
                                                           const clx_l3_mcast_egr_t *ptr_egr);

typedef clx_error_no_t (*hal_l3_mcast_egr_intf_del_func_t)(const uint32 unit,
                                                           const clx_l3_mcast_egr_t *ptr_egr);

typedef clx_error_no_t (*hal_l3_mcast_egr_intf_set_func_t)(const uint32 unit,
                                                           const clx_l3_mcast_egr_t *ptr_egr);

typedef clx_error_no_t (*hal_l3_mcast_egr_intf_cnt_get_func_t)(const uint32 unit,
                                                               const uint32 mcast_id,
                                                               const clx_port_t port_id,
                                                               uint32 *ptr_intf_cnt);

typedef clx_error_no_t (*hal_l3_mcast_egr_intf_get_func_t)(const uint32 unit,
                                                           const uint32 mcast_id,
                                                           const clx_port_t port_id,
                                                           uint32 *ptr_cnt,
                                                           clx_l3_mcast_egr_intf_t *ptr_intf);

typedef clx_error_no_t (
    *hal_l3_mcast_df_intf_add_func_t)(const uint32 unit, const clx_l3_mcast_df_intf_t *ptr_df_intf);

typedef clx_error_no_t (
    *hal_l3_mcast_df_intf_del_func_t)(const uint32 unit, const clx_l3_mcast_df_intf_t *ptr_df_intf);

typedef clx_error_no_t (*hal_l3_mcast_df_intf_get_func_t)(const uint32 unit,
                                                          clx_l3_mcast_df_intf_t *ptr_rslt);

typedef clx_error_no_t (*hal_l3_mcast_route_trav_func_t)(const uint32 unit,
                                                         const clx_l3_mcast_route_trav_func_t cb,
                                                         void *ptr_cookie);

typedef clx_error_no_t (*hal_l3_frr_create_func_t)(const uint32 unit, clx_l3_frr_t *ptr_frr);

typedef clx_error_no_t (*hal_l3_frr_destroy_func_t)(const uint32 unit, const uint32 frr_id);

typedef clx_error_no_t (*hal_l3_frr_path_add_func_t)(const uint32 unit,
                                                     const clx_l3_frr_path_t *ptr_path);

typedef clx_error_no_t (*hal_l3_frr_path_del_func_t)(const uint32 unit,
                                                     const clx_l3_frr_path_t *ptr_path);

typedef clx_error_no_t (*hal_l3_frr_state_set_func_t)(const uint32 unit,
                                                      const uint32 frr_id,
                                                      const boolean state);

typedef clx_error_no_t (*hal_l3_frr_state_get_func_t)(const uint32 unit,
                                                      const uint32 frr_id,
                                                      boolean *ptr_state);

/* tunnel multiplexing functions */
typedef clx_error_no_t (*hal_tnl_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_tnl_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_tnl_mac_add_func_t)(const uint32 unit,
                                                 const uint32 index,
                                                 const clx_tnl_mac_info_t *ptr_mac_info);

typedef clx_error_no_t (*hal_tnl_mac_del_func_t)(const uint32 unit, const uint32 index);

typedef clx_error_no_t (*hal_tnl_mac_get_func_t)(const uint32 unit,
                                                 const uint32 index,
                                                 clx_tnl_mac_info_t *ptr_mac_info);

typedef clx_error_no_t (*hal_tnl_mac_trav_func_t)(const uint32 unit,
                                                  const clx_tnl_mac_trav_t callback,
                                                  void *ptr_cookie);

typedef clx_error_no_t (*hal_tnl_entry_encap_add_func_t)(const uint32 unit,
                                                         const clx_tnl_info_t *ptr_tnl_info,
                                                         const clx_tnl_encap_info_t *ptr_encap_info);

typedef clx_error_no_t (*hal_tnl_entry_encap_del_func_t)(const uint32 unit,
                                                         const clx_tnl_info_t *ptr_tnl_info);

typedef clx_error_no_t (*hal_tnl_entry_encap_get_func_t)(const uint32 unit,
                                                         const clx_tnl_info_t *ptr_tnl_info,
                                                         clx_tnl_encap_info_t *ptr_encap_info);

typedef clx_error_no_t (*hal_tnl_entry_encap_trav_func_t)(const uint32 unit,
                                                          const clx_tnl_encap_trav_func_t cb,
                                                          void *ptr_cookie);

typedef clx_error_no_t (*hal_tnl_entry_decap_add_func_t)(const uint32 unit,
                                                         const clx_tnl_info_t *ptr_tnl_info,
                                                         const clx_tnl_decap_info_t *ptr_decap_info);

typedef clx_error_no_t (*hal_tnl_entry_decap_del_func_t)(const uint32 unit,
                                                         const clx_tnl_info_t *ptr_tnl_info);

typedef clx_error_no_t (*hal_tnl_entry_decap_get_func_t)(const uint32 unit,
                                                         const clx_tnl_info_t *ptr_tnl_info,
                                                         clx_tnl_decap_info_t *ptr_decap_info);

typedef clx_error_no_t (*hal_tnl_entry_decap_trav_func_t)(const uint32 unit,
                                                          const clx_tnl_decap_trav_func_t cb,
                                                          void *ptr_cookie);

typedef clx_error_no_t (*hal_tnl_nvo3_route_add_func_t)(
    const uint32 unit,
    const clx_tnl_info_t *ptr_tnl_info,
    const clx_tnl_nvo3_route_info_t *ptr_nvo3_route_info);

typedef clx_error_no_t (*hal_tnl_nvo3_route_del_func_t)(const uint32 unit,
                                                        const clx_tnl_info_t *ptr_tnl_info);

typedef clx_error_no_t (*hal_tnl_nvo3_route_get_func_t)(
    const uint32 unit,
    const clx_tnl_info_t *ptr_tnl_info,
    clx_tnl_nvo3_route_info_t *ptr_nvo3_route_info);

typedef clx_error_no_t (*hal_tnl_nvo3_route_trav_func_t)(const uint32 unit,
                                                         const clx_tnl_nvo3_route_trav_func_t cb,
                                                         void *ptr_cookie);

typedef clx_error_no_t (*hal_tnl_port_create_func_t)(const uint32 unit,
                                                     const uint32 flag,
                                                     const clx_tnl_info_t *ptr_tnl_info,
                                                     clx_port_t *ptr_port);

typedef clx_error_no_t (*hal_tnl_port_destroy_func_t)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*hal_tnl_port_get_func_t)(const uint32 unit,
                                                  const clx_tnl_info_t *ptr_tnl_info,
                                                  clx_port_t *ptr_tnl_port);

typedef clx_error_no_t (*hal_tnl_info_get_func_t)(const uint32 unit,
                                                  const clx_port_t tnl_port,
                                                  clx_tnl_info_t *ptr_tnl_info);

typedef clx_error_no_t (*hal_tnl_entry_trav_func_t)(const uint32 unit,
                                                    const clx_tnl_port_trav_func_t cb,
                                                    void *ptr_cookie);

typedef clx_error_no_t (*hal_tnl_flex_tnl_add_func_t)(
    const uint32 unit,
    const uint32 index,
    const clx_tnl_flex_tnl_info_t *ptr_flex_tnl_info);

typedef clx_error_no_t (*hal_tnl_flex_tnl_del_func_t)(const uint32 unit, const uint32 index);

typedef clx_error_no_t (*hal_tnl_flex_tnl_get_func_t)(const uint32 unit,
                                                      const uint32 index,
                                                      clx_tnl_flex_tnl_info_t *ptr_flex_tnl_info);

typedef clx_error_no_t (*hal_tnl_flex_tnl_udf_set_func_t)(const uint32 unit,
                                                          const uint32 index,
                                                          clx_tnl_flex_tnl_udf_prof_t *ptr_prof);

typedef clx_error_no_t (*hal_tnl_flex_tnl_udf_get_func_t)(const uint32 unit,
                                                          const uint32 index,
                                                          clx_tnl_flex_tnl_udf_prof_t *ptr_prof);

typedef clx_error_no_t (*hal_tnl_phy_port_set_func_t)(const uint32 unit,
                                                      const clx_port_t port,
                                                      const clx_tnl_port_info_t *ptr_port_info);

typedef clx_error_no_t (*hal_tnl_phy_port_get_func_t)(const uint32 unit,
                                                      const clx_port_t port,
                                                      clx_tnl_port_info_t *ptr_port_info);

typedef clx_error_no_t (*hal_tnl_es_grp_create_func_t)(const uint32 unit,
                                                       const uint32 flags,
                                                       uint32 *ptr_es_grp);

typedef clx_error_no_t (*hal_tnl_es_grp_destroy_func_t)(const uint32 unit, const uint32 es_grp);

typedef clx_error_no_t (*hal_tnl_es_grp_mbr_add_func_t)(const uint32 unit,
                                                        const uint32 es_grp,
                                                        const clx_port_t *ptr_port_mbr,
                                                        const uint32 port_num);

typedef clx_error_no_t (*hal_tnl_es_grp_mbr_del_func_t)(const uint32 unit,
                                                        const uint32 es_grp,
                                                        const clx_port_t *ptr_port_mbr,
                                                        const uint32 port_num);

typedef clx_error_no_t (*hal_tnl_es_grp_mbr_get_func_t)(const uint32 unit,
                                                        const uint32 es_grp,
                                                        clx_port_t *ptr_port_mbr,
                                                        uint32 *ptr_port_num);

typedef clx_error_no_t (*hal_tnl_seg_srv_add_func_t)(const uint32 unit,
                                                     const clx_tnl_info_t *ptr_tnl_info,
                                                     const clx_tnl_seg_key_t *ptr_segment,
                                                     const uint32 bdid);

typedef clx_error_no_t (*hal_tnl_seg_srv_del_func_t)(const uint32 unit,
                                                     const clx_tnl_info_t *ptr_tnl_info,
                                                     const clx_tnl_seg_key_t *ptr_segment);

typedef clx_error_no_t (*hal_tnl_seg_srv_get_func_t)(const uint32 unit,
                                                     const clx_tnl_info_t *ptr_tnl_info,
                                                     const clx_tnl_seg_key_t *ptr_segment,
                                                     uint32 *ptr_bdid);

/* srv6 tunnel multiplexing functions */
typedef clx_error_no_t (*hal_srv6_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_srv6_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_srv6_port_create_func_t)(const uint32 unit,
                                                      const uint32 flag,
                                                      clx_port_t *ptr_port);

typedef clx_error_no_t (*hal_srv6_port_destroy_func_t)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*hal_srv6_port_trav_func_t)(const uint32 unit,
                                                    const clx_srv6_port_trav_func_t callback,
                                                    void *ptr_cookie);

typedef clx_error_no_t (*hal_srv6_local_add_func_t)(const uint32 unit,
                                                    const clx_port_t port,
                                                    const clx_srv6_local_cfg_t *ptr_local_info);

typedef clx_error_no_t (*hal_srv6_local_del_func_t)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*hal_srv6_local_set_func_t)(const uint32 unit,
                                                    const clx_port_t port,
                                                    const clx_srv6_local_cfg_t *ptr_srv6_local);

typedef clx_error_no_t (*hal_srv6_local_get_func_t)(const uint32 unit,
                                                    const clx_port_t port,
                                                    clx_srv6_local_cfg_t *ptr_srv6_local);

typedef clx_error_no_t (*hal_srv6_local_trav_func_t)(const uint32 unit,
                                                     const clx_srv6_local_trav_func_t callback,
                                                     void *ptr_cookie);

typedef clx_error_no_t (*hal_srv6_encap_add_func_t)(const uint32 unit,
                                                    const clx_port_t port,
                                                    const clx_srv6_encap_cfg_t *ptr_encap_info);

typedef clx_error_no_t (*hal_srv6_encap_del_func_t)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*hal_srv6_encap_set_func_t)(const uint32 unit,
                                                    const clx_port_t port,
                                                    const clx_srv6_encap_cfg_t *ptr_encap_info);

typedef clx_error_no_t (*hal_srv6_encap_get_func_t)(const uint32 unit,
                                                    const clx_port_t port,
                                                    clx_srv6_encap_cfg_t *ptr_encap_info);

typedef clx_error_no_t (*hal_srv6_encap_trav_func_t)(const uint32 unit,
                                                     const clx_srv6_encap_trav_func_t callback,
                                                     void *ptr_cookie);

typedef clx_error_no_t (*hal_srv6_mysid_entry_add_func_t)(
    const uint32 unit,
    const clx_srv6_mysid_entry_t *ptr_mysid_entry,
    const clx_srv6_mysid_cfg_t *ptr_mysid_info);

typedef clx_error_no_t (*hal_srv6_mysid_entry_del_func_t)(
    const uint32 unit,
    const clx_srv6_mysid_entry_t *ptr_mysid_entry);

typedef clx_error_no_t (*hal_srv6_mysid_entry_set_func_t)(
    const uint32 unit,
    const clx_srv6_mysid_entry_t *ptr_mysid_entry,
    const clx_srv6_mysid_cfg_t *ptr_mysid_info);

typedef clx_error_no_t (*hal_srv6_mysid_entry_get_func_t)(
    const uint32 unit,
    const clx_srv6_mysid_entry_t *ptr_mysid_entry,
    clx_srv6_mysid_cfg_t *ptr_mysid_info);

typedef clx_error_no_t (*hal_srv6_mysid_entry_trav_func_t)(
    const uint32 unit,
    const clx_srv6_mysid_entry_trav_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_srv6_property_set_func_t)(const uint32 unit,
                                                       const clx_srv6_property_t *ptr_property);

typedef clx_error_no_t (*hal_srv6_property_get_func_t)(const uint32 unit,
                                                       clx_srv6_property_t *ptr_property);

typedef clx_error_no_t (*hal_srv6_nvo3_route_add_func_t)(
    const uint32 unit,
    const clx_port_t port,
    const clx_srv6_nvo3_route_info_t *ptr_nvo3_route_info);

typedef clx_error_no_t (*hal_srv6_nvo3_route_set_func_t)(
    const uint32 unit,
    const clx_port_t port,
    const clx_srv6_nvo3_route_info_t *ptr_nvo3_route_info);

typedef clx_error_no_t (*hal_srv6_nvo3_route_del_func_t)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*hal_srv6_nvo3_route_get_func_t)(
    const uint32 unit,
    const clx_port_t port,
    clx_srv6_nvo3_route_info_t *ptr_nvo3_route_info);

typedef clx_error_no_t (*hal_srv6_nvo3_route_trav_func_t)(
    const uint32 unit,
    const clx_srv6_nvo3_route_trav_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_srv6_endpoint_policy_add_func_t)(
    const uint32 unit,
    const clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

typedef clx_error_no_t (*hal_srv6_endpoint_policy_del_func_t)(
    const uint32 unit,
    const clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

typedef clx_error_no_t (*hal_srv6_endpoint_policy_set_func_t)(
    const uint32 unit,
    const clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

typedef clx_error_no_t (*hal_srv6_endpoint_policy_get_func_t)(
    const uint32 unit,
    clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

typedef clx_error_no_t (*hal_srv6_endpoint_policy_trav_func_t)(
    const uint32 unit,
    const clx_srv6_endpoint_policy_trav_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_srv6_seg_srv_add_func_t)(const uint32 unit,
                                                      const clx_port_t port,
                                                      const uint32 service_id,
                                                      const uint32 bdid);

typedef clx_error_no_t (*hal_srv6_seg_srv_del_func_t)(const uint32 unit,
                                                      const clx_port_t port,
                                                      const uint32 service_id);

typedef clx_error_no_t (*hal_srv6_seg_srv_set_func_t)(const uint32 unit,
                                                      const clx_port_t port,
                                                      const uint32 service_id,
                                                      const uint32 bdid);

typedef clx_error_no_t (*hal_srv6_seg_srv_get_func_t)(const uint32 unit,
                                                      const clx_port_t port,
                                                      const uint32 service_id,
                                                      uint32 *ptr_bdid);

typedef clx_error_no_t (*hal_srv6_hash_action_set_func_t)(
    const uint32 unit,
    const clx_srv6_hash_type_t hash_type,
    const clx_srv6_hash_action_t *ptr_hash_action);

typedef clx_error_no_t (*hal_srv6_hash_action_get_func_t)(const uint32 unit,
                                                          const clx_srv6_hash_type_t hash_type,
                                                          clx_srv6_hash_action_t *ptr_hash_action);

typedef clx_error_no_t (*hal_srv6_srv_sid_add_func_t)(const uint32 unit,
                                                      const clx_port_t port,
                                                      const clx_srv6_sid_map_t *ptr_sid_map);

typedef clx_error_no_t (*hal_srv6_srv_sid_del_func_t)(const uint32 unit,
                                                      const clx_port_t port,
                                                      const clx_srv6_sid_map_t *ptr_sid_map);

typedef clx_error_no_t (*hal_srv6_srv_sid_set_func_t)(const uint32 unit,
                                                      const clx_port_t port,
                                                      const clx_srv6_sid_map_t *ptr_sid_map);

typedef clx_error_no_t (*hal_srv6_srv_sid_get_func_t)(const uint32 unit,
                                                      const clx_port_t port,
                                                      clx_srv6_sid_map_t *ptr_sid_map);

/* ifmon multiplexing functions */
typedef clx_error_no_t (*hal_ifmon_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ifmon_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ifmon_register_func_t)(const uint32 unit,
                                                    const clx_port_ifmon_notify_func_t notify_func,
                                                    void *ptr_cookie);

typedef clx_error_no_t (*hal_ifmon_deregister_func_t)(const uint32 unit,
                                                      const clx_port_ifmon_notify_func_t notify_func,
                                                      void *ptr_cookie);

typedef clx_error_no_t (*hal_ifmon_mode_get_func_t)(const uint32 unit,
                                                    clx_port_ifmon_mode_t *ptr_mode,
                                                    clx_port_bitmap_t *ptr_port_bitmap,
                                                    uint32 *ptr_interval);

typedef clx_error_no_t (*hal_ifmon_mode_set_func_t)(const uint32 unit,
                                                    const clx_port_ifmon_mode_t mode,
                                                    const clx_port_bitmap_t port_bitmap,
                                                    const uint32 interval);

typedef clx_error_no_t (*hal_ifmon_monitor_state_get_func_t)(const uint32 unit,
                                                             boolean *ptr_enable);

typedef clx_error_no_t (*hal_ifmon_monitor_state_set_func_t)(const uint32 unit,
                                                             const boolean enable);

typedef clx_error_no_t (*hal_ifmon_callback_cnt_get_func_t)(const uint32 unit,
                                                            uint32 *ptr_callback_cnt);

typedef clx_error_no_t (*hal_ifmon_data_lock_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ifmon_data_unlock_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ifmon_flow_lock_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ifmon_flow_unlock_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ifmon_link_get_func_t)(const uint32 unit,
                                                    const uint32 port,
                                                    uint32 *ptr_link);

typedef clx_error_no_t (*hal_ifmon_fault_get_func_t)(const uint32 unit,
                                                     const uint32 port,
                                                     uint32 *ptr_fault);

typedef clx_error_no_t (*hal_ifmon_speed_get_func_t)(const uint32 unit,
                                                     const uint32 port,
                                                     clx_port_speed_t *ptr_speed);

typedef clx_error_no_t (*hal_ifmon_link_fault_get_func_t)(const uint32 unit,
                                                          const uint32 port,
                                                          uint32 *ptr_link,
                                                          uint32 *ptr_l_fault,
                                                          uint32 *ptr_r_fault,
                                                          uint32 *ptr_hiber);

typedef clx_error_no_t (*hal_ifmon_irq_get_func_t)(const uint32 unit,
                                                   const uint32 port,
                                                   uint32 *ptr_fault,
                                                   uint32 *ptr_lc);

typedef clx_error_no_t (*hal_ifmon_link_irq_en_set_func_t)(const uint32 unit,
                                                           const uint32 port,
                                                           const uint32 enable);

typedef clx_error_no_t (*hal_ifmon_link_irq_clear_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_ifmon_sw_fault_get_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        uint32 *ptr_fault);

typedef clx_error_no_t (*hal_ifmon_port_mon_add_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_ifmon_port_mon_get_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        uint32 *ptr_state);

typedef clx_error_no_t (*hal_ifmon_port_mon_del_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_ifmon_anlt_mon_add_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_ifmon_anlt_mon_get_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        uint32 *ptr_state);

typedef clx_error_no_t (*hal_ifmon_anlt_mon_del_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_ifmon_an_intr_set_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const uint32 enable);

typedef clx_error_no_t (*hal_ifmon_an_intr_stat_get_func_t)(const uint32 unit,
                                                            const uint32 port,
                                                            uint32 *status);

typedef clx_error_no_t (*hal_ifmon_anlt_process_func_t)(const uint32 unit,
                                                        HAL_MT_IFMON_ANLT_BITMAP_T anlt_np_bitmap);

typedef clx_error_no_t (*hal_ifmon_anlt_fsm_process_func_t)(
    const uint32 unit,
    HAL_MT_IFMON_ANLT_BITMAP_T anlt_fsm_bitmap,
    HAL_MT_IFMON_PORT_BITMAP_T hiber_bitmap);

typedef clx_error_no_t (*hal_ifmon_temp_protect_process_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ifmon_anlt_fsm_hang_cnt_get_func_t)(const uint32 unit,
                                                                 uint32 port,
                                                                 uint32 *fsm_hang_cnt);

typedef clx_error_no_t (*hal_ifmon_eqbk_hang_process_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_ifmon_time_record_func_t)(const uint32 unit,
                                                       const HAL_IFMON_TIME_T time_type);

typedef clx_error_no_t (*hal_ifmon_sw_state_update_func_t)(const uint32 unit,
                                                           const uint32 port,
                                                           uint32 *ptr_updated);

typedef clx_error_no_t (*hal_ifmon_link_state_dump_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ifmon_led_speed_set_func_t)(const uint32 unit,
                                                         const uint32 port,
                                                         const uint32 speed);

typedef clx_error_no_t (*hal_ifmon_lt_fail_mon_add_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_ifmon_lt_fail_mon_get_func_t)(const uint32 unit,
                                                           const uint32 port,
                                                           uint32 *valid);

typedef clx_error_no_t (*hal_ifmon_lt_fail_mon_del_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_ifmon_lt_fail_intr_set_func_t)(const uint32 unit,
                                                            const uint32 port,
                                                            const uint32 enable);

typedef clx_error_no_t (*hal_ifmon_lt_fail_intr_get_func_t)(const uint32 unit,
                                                            const uint32 port,
                                                            uint32 *status);

typedef clx_error_no_t (*hal_ifmon_lt_fail_process_func_t)(
    const uint32 unit,
    HAL_MT_IFMON_ANLT_BITMAP_T lt_fail_bitmap);

/*l2 multiplexing functions */
typedef clx_error_no_t (*hal_l2_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_l2_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_l2_addr_add_func_t)(const uint32 unit, const clx_l2_addr_t *ptr_addr);

typedef clx_error_no_t (*hal_l2_addr_del_func_t)(const uint32 unit,
                                                 const clx_bridge_domain_t bdid,
                                                 const clx_mac_t mac,
                                                 const uint32 flags);

typedef clx_error_no_t (*hal_l2_addr_get_func_t)(const uint32 unit, clx_l2_addr_t *ptr_addr);

typedef clx_error_no_t (*hal_l2_addr_flush_func_t)(const uint32 unit,
                                                   const uint32 flags,
                                                   const clx_l2_addr_flush_op_type_t flush_type,
                                                   const clx_l2_addr_flush_t *ptr_match_addr);

typedef clx_error_no_t (*hal_l2_addr_replace_func_t)(const uint32 unit,
                                                     const uint32 match_flags,
                                                     const clx_l2_addr_t *ptr_match_addr,
                                                     const uint32 replace_flags,
                                                     const clx_l2_addr_t *ptr_replace_addr);

typedef clx_error_no_t (*hal_l2_addr_trav_func_t)(const uint32 unit,
                                                  const clx_l2_entry_trav_mode_t mode,
                                                  const clx_l2_addr_trav_match_t *ptr_match_addr,
                                                  const clx_l2_addr_trav_func_t callback,
                                                  void *ptr_cookie);

typedef clx_error_no_t (*hal_l2_addr_trav_sw_func_t)(const uint32 unit,
                                                     const clx_l2_entry_trav_mode_t mode,
                                                     const clx_l2_addr_trav_match_t *ptr_match_addr,
                                                     const hal_l2_addr_trav_sw_callback_t callback,
                                                     void *ptr_cookie);

typedef clx_error_no_t (*hal_l2_addr_notify_cb_register_func_t)(
    const uint32 unit,
    const clx_l2_addr_notify_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_l2_addr_notify_cb_deregister_func_t)(
    const uint32 unit,
    const clx_l2_addr_notify_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_l2_addr_sw_learn_cb_register_func_t)(
    const uint32 unit,
    const clx_l2_addr_sw_learn_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_l2_addr_sw_learn_cb_deregister_func_t)(
    const uint32 unit,
    const clx_l2_addr_sw_learn_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_l2_age_status_get_func_t)(const uint32 unit,
                                                       const clx_bridge_domain_t bdid,
                                                       const clx_mac_t mac,
                                                       uint32 *ptr_age_status);

typedef clx_error_no_t (*hal_l2_mcast_grp_create_func_t)(const uint32 unit,
                                                         const uint32 flags,
                                                         uint32 *ptr_mcast_id);

typedef clx_error_no_t (*hal_l2_mcast_grp_destroy_func_t)(const uint32 unit, const uint32 mcast_id);

typedef clx_error_no_t (*hal_l2_mcast_intf_pbmp_get_func_t)(const uint32 unit,
                                                            const uint32 mcast_id,
                                                            uint32 *ptr_flags,
                                                            clx_port_bitmap_t port_bmp);

typedef clx_error_no_t (*hal_l2_mcast_egr_intf_add_func_t)(
    const uint32 unit,
    const uint32 mcast_id,
    const clx_l2_mcast_egr_mbr_t *ptr_egr_mbr);

typedef clx_error_no_t (*hal_l2_mcast_egr_intf_del_func_t)(
    const uint32 unit,
    const uint32 mcast_id,
    const clx_l2_mcast_egr_mbr_t *ptr_egr_mbr);

typedef clx_error_no_t (*hal_l2_mcast_egr_intf_cnt_get_func_t)(const uint32 unit,
                                                               const uint32 mcast_id,
                                                               uint32 *ptr_egr_intf_cnt);

typedef clx_error_no_t (*hal_l2_mcast_egr_intf_cnt_with_match_get_func_t)(const uint32 unit,
                                                                          const uint32 mcast_id,
                                                                          uint32 flag,
                                                                          uint32 *ptr_egr_intf_cnt);

typedef clx_error_no_t (*hal_l2_mcast_egr_intf_get_func_t)(const uint32 unit,
                                                           const uint32 mcast_id,
                                                           clx_l2_mcast_egr_mbr_t *ptr_egr_mbr);
typedef clx_error_no_t (*hal_l2_mcast_egr_intf_with_match_get_func_t)(
    const uint32 unit,
    const uint32 mcast_id,
    uint32 flag,
    clx_l2_mcast_egr_mbr_t *ptr_egr_mbr);
typedef clx_error_no_t (*hal_l2_mcast_egr_intf_check_func_t)(const uint32 unit,
                                                             const uint32 mcast_id,
                                                             const clx_l2_mcast_egr_intf_t egr_intf,
                                                             boolean *ptr_is_exist);
typedef clx_error_no_t (*hal_l2_mcast_addr_add_func_t)(const uint32 unit,
                                                       const clx_l2_mcast_addr_t *ptr_addr);

typedef clx_error_no_t (*hal_l2_mcast_addr_del_func_t)(const uint32 unit,
                                                       const clx_bridge_domain_t bdid,
                                                       const clx_mac_t mac);

typedef clx_error_no_t (*hal_l2_mcast_addr_get_func_t)(const uint32 unit,
                                                       clx_l2_mcast_addr_t *ptr_addr);

typedef clx_error_no_t (*hal_l2_mcast_addr_trav_func_t)(
    const uint32 unit,
    const clx_l2_entry_trav_mode_t mode,
    const clx_l2_mcast_addr_trav_match_t *ptr_match_addr,
    const clx_l2_mcast_addr_trav_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_l2_sw_mcast_addr_trav_func_t)(
    const uint32 unit,
    const clx_l2_entry_trav_mode_t mode,
    const clx_l2_mcast_addr_trav_match_t *ptr_match_addr,
    const hal_l2_sw_mcast_addr_trav_callback_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_l2_capacity_get_func_t)(const uint32 unit,
                                                     const clx_swc_rsrc_t type,
                                                     const uint32 param,
                                                     uint32 *ptr_size);
typedef clx_error_no_t (*hal_l2_usage_get_func_t)(const uint32 unit,
                                                  const clx_swc_rsrc_t type,
                                                  const uint32 param,
                                                  uint32 *ptr_cnt);
typedef clx_error_no_t (*hal_l2_aging_time_set_func_t)(const uint32 unit, const uint32 aging_time);
typedef clx_error_no_t (*hal_l2_aging_time_get_func_t)(const uint32 unit, uint32 *ptr_aging_time);
typedef clx_error_no_t (*hal_l2_sa_move_action_set_func_t)(const uint32 unit,
                                                           const clx_fwd_action_t action);
typedef clx_error_no_t (*hal_l2_sa_move_action_get_func_t)(const uint32 unit, uint32 *ptr_action);
typedef clx_error_no_t (*hal_l2_sa_miss_action_set_func_t)(const uint32 unit,
                                                           const clx_swc_cfg_t reason,
                                                           const clx_fwd_action_t action);
typedef clx_error_no_t (*hal_l2_sa_miss_action_get_func_t)(const uint32 unit,
                                                           const clx_swc_cfg_t reason,
                                                           uint32 *ptr_action);
typedef clx_error_no_t (*hal_l2_mcast_id_print_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_l2_mcast_grp_info_print_func_t)(const uint32 unit,
                                                             const uint32 logical_mc_id,
                                                             const uint32 phy_mc_id);
typedef clx_error_no_t (*hal_l2_mcast_lag_mbr_update_func_t)(const uint32 unit,
                                                             const uint32 lag_id,
                                                             const uint32 add_member_cnt,
                                                             const uint32 *ptr_add_member_di,
                                                             const uint32 del_member_cnt,
                                                             const uint32 *ptr_del_member_di);

typedef clx_error_no_t (*hal_l2_mcast_lag_del_func_t)(const uint32 unit, const uint32 lag_id);

/* L2 ECMP */
typedef clx_error_no_t (*hal_l2_ecmp_grp_add_func_t)(const uint32 unit,
                                                     clx_l2_ecmp_grp_t *ptr_ecmp_info,
                                                     clx_port_t *ptr_ecmp_port);

typedef clx_error_no_t (*hal_l2_ecmp_grp_del_func_t)(const uint32 unit, const clx_port_t ecmp_port);

typedef clx_error_no_t (*hal_l2_ecmp_grp_get_func_t)(const uint32 unit,
                                                     const clx_port_t ecmp_port,
                                                     clx_l2_ecmp_grp_t *ptr_ecmp_info);

typedef clx_error_no_t (*hal_l2_ecmp_path_add_func_t)(const uint32 unit,
                                                      const clx_port_t ecmp_port,
                                                      const clx_l2_ecmp_path_t *ptr_path_info);

typedef clx_error_no_t (*hal_l2_ecmp_path_del_func_t)(const uint32 unit,
                                                      const clx_port_t ecmp_port,
                                                      const clx_l2_ecmp_path_t *ptr_path_info);

typedef clx_error_no_t (*hal_l2_ecmp_path_get_by_idx_func_t)(const uint32 unit,
                                                             const clx_port_t ecmp_port,
                                                             const uint32 path_idx,
                                                             clx_l2_ecmp_path_t *ptr_path_info);

typedef clx_error_no_t (*hal_l2_ecmp_path_hsh_set_func_t)(const uint32 unit,
                                                          const clx_port_t ecmp_port,
                                                          uint32 *ptr_hash_val_list,
                                                          const uint32 hash_val_cnt,
                                                          const clx_l2_ecmp_path_t *ptr_path_info);

typedef clx_error_no_t (*hal_l2_ecmp_path_hsh_get_func_t)(const uint32 unit,
                                                          const clx_port_t ecmp_port,
                                                          const uint32 hash_val_cnt,
                                                          const clx_l2_ecmp_path_t *ptr_path_info,
                                                          uint32 *ptr_hash_val_list,
                                                          uint32 *ptr_actual_hash_val_cnt);

typedef clx_error_no_t (*hal_l2_grp_path_list_dump_func_t)(const uint32 unit,
                                                           const clx_port_t ecmp_port);

typedef clx_error_no_t (*hal_l2_multi_mcast_grp_create_func_t)(const uint32 unit,
                                                               const uint32 flags,
                                                               const uint32 mcast_id_cnt,
                                                               uint32 *ptr_mcast_id);
/* stp multiplexing functions */

typedef clx_error_no_t (*hal_stp_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_stp_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_stp_create_func_t)(const uint32 unit,
                                                const uint32 flag,
                                                uint32 *ptr_stgid);

typedef clx_error_no_t (*hal_stp_destroy_func_t)(const uint32 unit, const uint32 stgid);

typedef clx_error_no_t (*hal_stp_portstate_set_func_t)(const uint32 unit,
                                                       const uint32 stg,
                                                       const uint32 port,
                                                       const clx_stp_state_t stp_state);

typedef clx_error_no_t (*hal_stp_portstate_get_func_t)(const uint32 unit,
                                                       const uint32 stg,
                                                       const uint32 port,
                                                       clx_stp_state_t *ptr_stp_state);

typedef clx_error_no_t (*hal_stp_is_valid_func_t)(const uint32 unit, const uint32 stg_id);

/* Pkt multiplexing functions */

typedef clx_error_no_t (*hal_pkt_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_pkt_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_pkt_rx_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_pkt_rx_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_pkt_rx_cb_func_t)(const uint32 unit,
                                               const clx_pkt_rx_func_t cb,
                                               void *ptr_cookie,
                                               const clx_pkt_cb_op_t op_mode);

typedef clx_error_no_t (*HAL_PKT_RXMONITORENABLE_FUNC_T)(const uint32 unit,
                                                         const clx_pkt_rx_func_t cb,
                                                         void *ptr_cookie);

typedef clx_error_no_t (*HAL_PKT_RXMONITORDISABLE_FUNC_T)(const uint32 unit);

typedef clx_error_no_t (*HAL_PKT_SETPDMALOOPBACK_FUNC_T)(const uint32 unit, const boolean enabled);

typedef clx_error_no_t (*hal_pkt_tx_send_func_t)(const uint32 unit,
                                                 const clx_pkt_tx_pkt_t *ptr_pkt);

typedef clx_error_no_t (*hal_pkt_tx_prepare_func_t)(const uint32 unit,
                                                    clx_pkt_tx_pkt_t *ptr_pkt,
                                                    const uint8 *ptr_data_buf,
                                                    uint32 len);

typedef clx_error_no_t (*hal_pkt_queue_cfg_get_func_t)(const uint32 unit,
                                                       clx_pkt_rx_queue_cfg_t *ptr_queue_cfg);

typedef clx_error_no_t (*hal_pkt_queue_cfg_set_func_t)(const uint32 unit,
                                                       const clx_pkt_rx_queue_cfg_t *ptr_queue_cfg);

typedef clx_error_no_t (*hal_pkt_rx_udf_mem_cb_set_func_t)(const uint32 unit,
                                                           const clx_pkt_rx_alloc_func_t alloc_cb,
                                                           const clx_pkt_rx_free_func_t free_cb);

typedef clx_error_no_t (*hal_pkt_pdma_loopback_set_func_t)(const uint32 unit,
                                                           const boolean enabled);

typedef clx_error_no_t (*hal_pkt_mod_mac_set_func_t)(const uint32 unit, clx_mac_t mod_dmac);

typedef clx_error_no_t (*hal_pkt_mod_mac_get_func_t)(const uint32 unit, clx_mac_t mod_dmac);
typedef clx_error_no_t (*hal_pkt_ifa_cfg_set_func_t)(const uint32 unit,
                                                     const clx_netif_ifa_cfg_t *ptr_ifa_cfg);

typedef clx_error_no_t (*hal_pkt_ifa_cfg_get_func_t)(const uint32 unit,
                                                     clx_netif_ifa_cfg_t *ptr_ifa_cfg);

typedef clx_error_no_t (*hal_pkt_ctrl_to_cpu_entry_set_func_t)(
    const uint32 unit,
    const uint32 index,
    const clx_pkt_ctrl_to_cpu_entry_t *ptr_entry);

typedef clx_error_no_t (*hal_pkt_ctrl_to_cpu_entry_get_func_t)(
    const uint32 unit,
    const uint32 index,
    clx_pkt_ctrl_to_cpu_entry_t *ptr_entry);

typedef clx_error_no_t (*hal_pkt_ctrl_to_cpu_entry_all_clear_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_pkt_tx_cnt_get_func_t)(const uint32 unit,
                                                    const uint32 channel,
                                                    clx_pkt_tx_cnt_t *ptr_cnt);

typedef clx_error_no_t (*hal_pkt_rx_cnt_get_func_t)(const uint32 unit,
                                                    const uint32 channel,
                                                    clx_pkt_rx_cnt_t *ptr_cnt);

typedef clx_error_no_t (*hal_pkt_tx_cnt_clear_func_t)(const uint32 unit, const uint32 channel);

typedef clx_error_no_t (*hal_pkt_rx_cnt_clear_func_t)(const uint32 unit, const uint32 channel);

typedef clx_error_no_t (*hal_pkt_intf_create_func_t)(const uint32 unit,
                                                     const clx_netif_intf_t *ptr_net_intf,
                                                     uint32 *ptr_intf_id);

typedef clx_error_no_t (*hal_pkt_intf_destroy_func_t)(const uint32 unit, const uint32 id);

typedef clx_error_no_t (*hal_pkt_intf_get_func_t)(const uint32 unit,
                                                  const uint32 intf_id,
                                                  clx_netif_intf_t *ptr_net_intf);

typedef clx_error_no_t (*hal_pkt_intf_set_func_t)(const uint32 unit,
                                                  const uint32 intf_id,
                                                  const clx_netif_intf_t *ptr_net_intf);

typedef clx_error_no_t (*hal_pkt_prof_create_func_t)(const uint32 unit,
                                                     const clx_netif_prof_t *ptr_net_profile,
                                                     uint32 *ptr_profile_id);

typedef clx_error_no_t (*hal_pkt_prof_destroy_func_t)(const uint32 unit, const uint32 id);

typedef clx_error_no_t (*hal_pkt_prof_get_func_t)(const uint32 unit,
                                                  const uint32 profile_id,
                                                  clx_netif_prof_t *ptr_net_profile);

typedef clx_error_no_t (*hal_pkt_intf_cnt_get_func_t)(const uint32 unit,
                                                      const uint32 id,
                                                      clx_netif_intf_cnt_t *ptr_intf_cnt);

typedef clx_error_no_t (*hal_pkt_intf_cnt_clear_func_t)(const uint32 unit, const uint32 id);

typedef clx_error_no_t (*hal_pkt_tx_dbg_cnt_show_func_t)(const uint32 unit, const uint32 channel);

typedef clx_error_no_t (*hal_pkt_rx_dbg_cnt_show_func_t)(const uint32 unit, const uint32 channel);

typedef clx_error_no_t (*hal_pkt_pp_rsn_str_get_func_t)(const uint32 unit,
                                                        const uint32 pp_rsn,
                                                        const uint32 str_len,
                                                        char *str_pp_rsn);

typedef clx_error_no_t (*hal_pkt_pp_rsn_code_get_func_t)(const uint32 unit,
                                                         const char *str_pp_reason,
                                                         uint32 *pp_reason_code);

typedef clx_error_no_t (*hal_pkt_rsn_str_get_func_t)(const uint32 unit,
                                                     const clx_pkt_rx_reason_t rsn_code,
                                                     const uint32 str_len,
                                                     char *str_rsn);

typedef clx_error_no_t (*hal_pkt_rsn_code_get_func_t)(const uint32 unit,
                                                      const char *str_rx_reason,
                                                      clx_pkt_rx_reason_t *rx_reason_code);

typedef clx_error_no_t (*hal_pkt_drop_rsn_get_func_t)(const uint32 unit,
                                                      const clx_pkt_drop_reason_t drop_reason,
                                                      const uint32 str_len,
                                                      char *str_drop_reason);

typedef clx_error_no_t (*hal_pkt_pp_to_drop_rsn_func_t)(const uint32 unit,
                                                        const clx_pkt_drop_reason_t drop_reason,
                                                        uint32 *ptr_pp_reason_cnt,
                                                        uint32 *ptr_pp_reason_list);

typedef clx_error_no_t (*hal_pkt_netlink_create_func_t)(const uint32 unit,
                                                        const clx_netif_netlink_t *ptr_netlink,
                                                        uint32 *ptr_netlink_id);

typedef clx_error_no_t (*hal_pkt_netlink_destroy_func_t)(const uint32 unit,
                                                         const uint32 netlink_id);

typedef clx_error_no_t (*hal_pkt_netlink_get_func_t)(const uint32 unit,
                                                     const uint32 netlink_id,
                                                     clx_netif_netlink_t *ptr_netlink);

typedef clx_error_no_t (*hal_pkt_queue_cfg_get_func_t)(const uint32 unit,
                                                       clx_pkt_rx_queue_cfg_t *ptr_queue_cfg);

typedef clx_error_no_t (*hal_pkt_queue_cfg_set_func_t)(const uint32 unit,
                                                       const clx_pkt_rx_queue_cfg_t *ptr_queue_cfg);

/*cia multiplexing functions start*/

typedef clx_error_no_t (*hal_cia_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cia_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cia_select_key_prof_get_func_t)(
    const uint32 unit,
    const clx_cia_select_cfg_type_t type,
    const uint32 prof_id,
    clx_cia_select_key_prof_t *ptr_select_key_prof);

typedef clx_error_no_t (*hal_cia_select_key_prof_add_func_t)(
    const uint32 unit,
    const clx_cia_select_cfg_type_t type,
    const clx_cia_select_key_prof_t *ptr_select_key_prof,
    uint32 *ptr_prof_id);

typedef clx_error_no_t (*hal_cia_select_key_prof_del_func_t)(const uint32 unit,
                                                             const clx_cia_select_cfg_type_t type,
                                                             const uint32 prof_id);

typedef clx_error_no_t (*hal_cia_select_key_prof_trav_func_t)(
    const uint32 unit,
    const clx_cia_select_cfg_type_t type,
    const clx_cia_select_key_prof_trav_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_cia_grp_get_func_t)(const uint32 unit,
                                                 const clx_cia_stage_t stage,
                                                 const uint32 grp_id,
                                                 clx_cia_grp_prof_t *ptr_grp_prof);

typedef clx_error_no_t (*hal_cia_grp_add_func_t)(const uint32 unit,
                                                 const clx_cia_stage_t stage,
                                                 const clx_cia_grp_prof_t *ptr_grp_prof,
                                                 uint32 *ptr_grp_id);
typedef clx_error_no_t (*hal_cia_grp_del_func_t)(const uint32 unit,
                                                 const clx_cia_stage_t stage,
                                                 const uint32 grp_id);
typedef clx_error_no_t (*hal_cia_grp_trav_func_t)(const uint32 unit,
                                                  const clx_cia_stage_t stage,
                                                  const clx_cia_grp_trav_func_t callback,
                                                  void *ptr_cookie);
typedef clx_error_no_t (*hal_cia_exact_grp_get_func_t)(const uint32 unit,
                                                       const clx_cia_stage_t stage,
                                                       const uint32 grp_id,
                                                       clx_cia_exact_grp_prof_t *ptr_grp_prof);
typedef clx_error_no_t (*hal_cia_exact_grp_add_func_t)(const uint32 unit,
                                                       const clx_cia_stage_t stage,
                                                       const clx_cia_exact_grp_prof_t *ptr_grp_prof,
                                                       uint32 *ptr_grp_id);
typedef clx_error_no_t (*hal_cia_exact_grp_del_func_t)(const uint32 unit,
                                                       const clx_cia_stage_t stage,
                                                       const uint32 grp_id);
typedef clx_error_no_t (*hal_cia_exact_grp_trav_func_t)(const uint32 unit,
                                                        const clx_cia_stage_t stage,
                                                        const clx_cia_exact_grp_trav_func_t callback,
                                                        void *ptr_cookie);
typedef clx_error_no_t (*hal_cia_udf_entry_get_func_t)(const uint32 unit,
                                                       const clx_cia_stage_t stage,
                                                       const uint32 udf_entry_id,
                                                       clx_cia_udf_entry_t *ptr_entry_info);
typedef clx_error_no_t (*hal_cia_udf_entry_add_func_t)(const uint32 unit,
                                                       const clx_cia_stage_t stage,
                                                       const uint32 udf_entry_id,
                                                       const clx_cia_udf_entry_t *ptr_entry_info);
typedef clx_error_no_t (*hal_cia_udf_entry_del_func_t)(const uint32 unit,
                                                       const clx_cia_stage_t stage,
                                                       const uint32 udf_entry_id);
typedef clx_error_no_t (*hal_cia_udf_entry_trav_func_t)(const uint32 unit,
                                                        const clx_cia_stage_t stage,
                                                        const clx_cia_udf_entry_trav_func_t callback,
                                                        void *ptr_cookie);
typedef clx_error_no_t (*hal_cia_entry_id_info_get_func_t)(const uint32 unit,
                                                           const uint32 entry_id,
                                                           clx_cia_stage_t *ptr_stage,
                                                           uint32 *ptr_grp_id,
                                                           uint32 *ptr_entry_pri);
typedef clx_error_no_t (*hal_cia_entry_id_alloc_func_t)(const uint32 unit,
                                                        const clx_cia_stage_t stage,
                                                        const uint32 grp_id,
                                                        const uint32 entry_pri,
                                                        uint32 *ptr_entry_id);
typedef clx_error_no_t (*hal_cia_entry_id_free_func_t)(const uint32 unit, const uint32 entry_id);
typedef clx_error_no_t (*hal_cia_entry_get_func_t)(const uint32 unit,
                                                   const uint32 entry_id,
                                                   clx_cia_entry_t *ptr_entry_info);
typedef clx_error_no_t (*hal_cia_entry_add_func_t)(const uint32 unit,
                                                   const uint32 entry_id,
                                                   const clx_cia_entry_t *ptr_entry_info);
typedef clx_error_no_t (*hal_cia_entry_vld_set_func_t)(const uint32 unit,
                                                       const uint32 entry_id,
                                                       const boolean entry_vld);
typedef clx_error_no_t (*hal_cia_entry_del_func_t)(const uint32 unit, const uint32 entry_id);
typedef clx_error_no_t (*hal_cia_entry_trav_func_t)(const uint32 unit,
                                                    const clx_cia_stage_t stage,
                                                    const uint32 grp_id,
                                                    const clx_cia_entry_trav_func_t callback,
                                                    void *ptr_cookie);
typedef clx_error_no_t (*hal_cia_exact_entry_get_func_t)(const uint32 unit,
                                                         const clx_cia_stage_t stage,
                                                         const uint32 grp_id,
                                                         const uint32 entry_id,
                                                         clx_cia_exact_entry_t *ptr_entry_info);
typedef clx_error_no_t (*hal_cia_exact_entry_add_func_t)(const uint32 unit,
                                                         const clx_cia_stage_t stage,
                                                         const uint32 grp_id,
                                                         const clx_cia_exact_entry_t *ptr_entry_info,
                                                         uint32 *ptr_entry_id);
typedef clx_error_no_t (*hal_cia_exact_entry_del_func_t)(const uint32 unit,
                                                         const clx_cia_stage_t stage,
                                                         const uint32 grp_id,
                                                         const uint32 entry_id);
typedef clx_error_no_t (*hal_cia_exact_entry_trav_func_t)(
    const uint32 unit,
    const clx_cia_stage_t stage,
    const uint32 grp_id,
    const clx_cia_exact_entry_trav_func_t callback,
    void *ptr_cookie);
typedef clx_error_no_t (*hal_cia_exact_entry_id_info_get_func_t)(const uint32 unit,
                                                                 const uint32 entry_id,
                                                                 clx_cia_stage_t *ptr_stage,
                                                                 uint32 *ptr_grp_id);
typedef clx_error_no_t (*hal_cia_rim_alloc_func_t)(const uint32 unit,
                                                   const clx_cia_rim_alloc_t type,
                                                   uint32 *ptr_index);
typedef clx_error_no_t (*hal_cia_rim_free_func_t)(const uint32 unit,
                                                  const clx_cia_rim_alloc_t type,
                                                  const uint32 index);
typedef clx_error_no_t (*hal_cia_rim_act_set_func_t)(const uint32 unit,
                                                     const clx_cia_rim_alloc_t type,
                                                     const uint32 index,
                                                     const void *ptr_action);
typedef clx_error_no_t (*hal_cia_rim_act_get_func_t)(const uint32 unit,
                                                     const clx_cia_rim_alloc_t type,
                                                     const uint32 index,
                                                     void *ptr_action);
typedef clx_error_no_t (*hal_cia_rim_act_trav_func_t)(const uint32 unit,
                                                      const clx_cia_rim_alloc_t type,
                                                      const clx_cia_rim_trav_func_t callback,
                                                      void *ptr_cookie);
typedef clx_error_no_t (*hal_cia_range_add_func_t)(const uint32 unit,
                                                   const clx_cia_stage_t stage,
                                                   const uint32 range_id,
                                                   const clx_cia_range_cfg_t *ptr_range);
typedef clx_error_no_t (*hal_cia_range_del_func_t)(const uint32 unit,
                                                   const clx_cia_stage_t stage,
                                                   const uint32 range_id);
typedef clx_error_no_t (*hal_cia_range_get_func_t)(const uint32 unit,
                                                   const clx_cia_stage_t stage,
                                                   const uint32 range_id,
                                                   clx_cia_range_cfg_t *ptr_range);
typedef clx_error_no_t (*hal_cia_range_trav_func_t)(const uint32 unit,
                                                    const clx_cia_stage_t stage,
                                                    const clx_cia_range_trav_func_t callback,
                                                    void *ptr_cookie);

typedef clx_error_no_t (*hal_cia_range_union_set_func_t)(const uint32 unit,
                                                         const clx_cia_stage_t stage,
                                                         const uint32 union_id,
                                                         const uint32 range_bmp);

typedef clx_error_no_t (*hal_cia_range_union_get_func_t)(const uint32 unit,
                                                         const clx_cia_stage_t stage,
                                                         const uint32 union_id,
                                                         uint32 *ptr_range_bmp);

/*cia multiplexing functions end*/

/* security multiplexing functions end */

typedef clx_error_no_t (*hal_sec_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_sec_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_sec_dos_port_cfg_set_func_t)(const uint32 unit,
                                                          const uint32 port,
                                                          const clx_sec_dos_port_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_dos_port_cfg_get_func_t)(const uint32 unit,
                                                          const uint32 port,
                                                          clx_sec_dos_port_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_dos_cfg_set_func_t)(const uint32 unit,
                                                     const clx_sec_dos_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_dos_cfg_get_func_t)(const uint32 unit, clx_sec_dos_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_dos_status_get_func_t)(const uint32 unit,
                                                        clx_sec_dos_status_t *ptr_status);

typedef clx_error_no_t (*hal_sec_dos_status_clear_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_sec_dos_cnt_get_func_t)(const uint32 unit, clx_sec_dos_cnt_t *ptr_cnt);

typedef clx_error_no_t (*hal_sec_dos_cnt_clear_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_sec_storm_ctrl_cfg_set_func_t)(const uint32 unit,
                                                            const uint32 port,
                                                            const clx_sec_storm_ctrl_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_storm_ctrl_cfg_get_func_t)(const uint32 unit,
                                                            const uint32 port,
                                                            clx_sec_storm_ctrl_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_storm_ctrl_stats_get_func_t)(const uint32 unit,
                                                              const uint32 port,
                                                              clx_sec_storm_ctrl_stats_t *ptr_stats);

typedef clx_error_no_t (*hal_sec_storm_ctrl_stats_clear_func_t)(const uint32 unit,
                                                                const uint32 port);

typedef clx_error_no_t (*hal_sec_src_guard_cfg_set_func_t)(const uint32 unit,
                                                           const uint32 port,
                                                           const clx_sec_src_guard_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_src_guard_cfg_get_func_t)(const uint32 unit,
                                                           const uint32 port,
                                                           clx_sec_src_guard_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_src_guard_bd_cfg_set_func_t)(
    const uint32 unit,
    const clx_bridge_domain_t bdid,
    const clx_sec_src_guard_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_src_guard_bd_cfg_get_func_t)(const uint32 unit,
                                                              const clx_bridge_domain_t bdid,
                                                              clx_sec_src_guard_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_src_guard_entry_add_func_t)(
    const uint32 unit,
    const clx_sec_src_guard_entry_t *ptr_entry);

typedef clx_error_no_t (*hal_sec_src_guard_entry_del_func_t)(
    const uint32 unit,
    const clx_sec_src_guard_entry_t *ptr_entry);

typedef clx_error_no_t (*hal_sec_src_guard_entry_get_func_t)(const uint32 unit,
                                                             clx_sec_src_guard_entry_t *ptr_entry);

typedef clx_error_no_t (*hal_sec_isolation_grp_cfg_set_func_t)(
    const uint32 unit,
    const uint32 grp_id,
    const clx_sec_isolation_grp_cfg_t *ptr_grp_cfg);

typedef clx_error_no_t (*hal_sec_isolation_grp_cfg_get_func_t)(
    const uint32 unit,
    const uint32 grp_id,
    clx_sec_isolation_grp_cfg_t *ptr_grp_cfg);

typedef clx_error_no_t (*hal_sec_isolation_port_cfg_set_func_t)(
    const uint32 unit,
    const clx_port_t port,
    const clx_sec_isolation_port_cfg_t *ptr_port_cfg);

typedef clx_error_no_t (*hal_sec_isolation_port_cfg_get_func_t)(
    const uint32 unit,
    const clx_port_t port,
    clx_sec_isolation_port_cfg_t *ptr_port_cfg);

typedef clx_error_no_t (*hal_sec_property_set_func_t)(const uint32 unit,
                                                      const uint32 port,
                                                      const uint32 type,
                                                      const uint32 param0,
                                                      const uint32 param1);

typedef clx_error_no_t (*hal_sec_property_get_func_t)(const uint32 unit,
                                                      const uint32 port,
                                                      const uint32 type,
                                                      const uint32 *ptr_param0,
                                                      const uint32 *ptr_param1);

/* security multiplexing functions end */

/* sflow multiplexing functions start */

typedef clx_error_no_t (*hal_sflow_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_sflow_deinit_func_t)(const uint32 unit);

/* sflow multiplexing functions end */

/*switch control multiplexing functions start*/

typedef clx_error_no_t (*hal_swc_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_swc_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_swc_cfg_set_func_t)(const uint32 unit,
                                                 const clx_swc_cfg_t property,
                                                 const uint32 param0,
                                                 const uint32 param1);

typedef clx_error_no_t (*hal_swc_cfg_get_func_t)(const uint32 unit,
                                                 const clx_swc_cfg_t property,
                                                 uint32 *ptr_param0,
                                                 uint32 *ptr_param1);

typedef clx_error_no_t (*hal_swc_hsh_key_set_func_t)(const uint32 unit,
                                                     const clx_swc_hsh_pkt_type_t hash_type,
                                                     const clx_swc_hsh_key_bmp_t key_bitmap);

typedef clx_error_no_t (*hal_swc_hsh_key_get_func_t)(const uint32 unit,
                                                     const clx_swc_hsh_pkt_type_t hash_type,
                                                     clx_swc_hsh_key_bmp_t *ptr_key_bitmap);

typedef clx_error_no_t (*hal_swc_hsh_key_prof_set_func_t)(const uint32 unit,
                                                          const clx_swc_hsh_pkt_type_t hash_type,
                                                          const clx_swc_hsh_key_prof_t key_prof,
                                                          const clx_swc_hsh_key_bmp_t key_bitmap);

typedef clx_error_no_t (*hal_swc_hsh_key_prof_get_func_t)(const uint32 unit,
                                                          const clx_swc_hsh_pkt_type_t hash_type,
                                                          const clx_swc_hsh_key_prof_t key_prof,
                                                          clx_swc_hsh_key_bmp_t *ptr_key_bitmap);

typedef clx_error_no_t (*hal_swc_hsh_eng_set_func_t)(const uint32 unit,
                                                     const clx_swc_hsh_pkt_type_t hash_type,
                                                     const clx_swc_hsh_eng_t *hash_engine);

typedef clx_error_no_t (*hal_swc_hsh_eng_get_func_t)(const uint32 unit,
                                                     const clx_swc_hsh_pkt_type_t hash_type,
                                                     clx_swc_hsh_eng_t *hash_engine);

typedef clx_error_no_t (*hal_swc_ts_set_func_t)(const uint32 unit, const clx_swc_ts_t ts_val);

typedef clx_error_no_t (*hal_swc_ts_get_func_t)(const uint32 unit, clx_swc_ts_t *ptr_ts_val);

typedef clx_error_no_t (*hal_swc_ts_offset_set_func_t)(const uint32 unit, const int32 nsec);

typedef clx_error_no_t (*hal_swc_hsh_const_set_func_t)(const uint32 unit,
                                                       const clx_swc_hsh_pkt_type_t hash_type,
                                                       const uint32 hash_const);

typedef clx_error_no_t (*hal_swc_hsh_const_get_func_t)(const uint32 unit,
                                                       const clx_swc_hsh_pkt_type_t hash_type,
                                                       uint32 *ptr_hash_const);

typedef clx_error_no_t (*hal_swc_err_cb_register_func_t)(const uint32 unit,
                                                         const clx_swc_err_type_t error,
                                                         const clx_swc_err_func_t callback,
                                                         void *ptr_cookie);

typedef clx_error_no_t (*hal_swc_err_cb_deregister_func_t)(const uint32 unit,
                                                           const clx_swc_err_type_t error,
                                                           const clx_swc_err_func_t callback,
                                                           void *ptr_cookie);

typedef clx_error_no_t (*hal_swc_notify_cb_register_func_t)(const uint32 unit,
                                                            const clx_swc_notify_category_t category,
                                                            const clx_swc_notify_func_t callback,
                                                            void *ptr_cookie);

typedef clx_error_no_t (*hal_swc_notify_cb_deregister_func_t)(
    const uint32 unit,
    const clx_swc_notify_category_t category,
    const clx_swc_notify_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_swc_dev_info_get_func_t)(const uint32 unit,
                                                      clx_swc_device_info_t *ptr_device_info);

typedef clx_error_no_t (*hal_swc_port_cfg_get_func_t)(const uint32 unit,
                                                      clx_swc_port_cfg_t *ptr_port_config);

typedef clx_error_no_t (*hal_swc_capacity_get_func_t)(const uint32 unit,
                                                      const clx_swc_rsrc_t type,
                                                      const uint32 param,
                                                      uint32 *ptr_size);

typedef clx_error_no_t (*hal_swc_usage_get_func_t)(const uint32 unit,
                                                   const clx_swc_rsrc_t type,
                                                   const uint32 param,
                                                   uint32 *ptr_cnt);

typedef clx_error_no_t (*hal_swc_cso_mode_set_func_t)(const uint32 unit,
                                                      const clx_swc_cso_mode_t mode);

typedef clx_error_no_t (*hal_swc_cso_mode_get_func_t)(const uint32 unit,
                                                      clx_swc_cso_mode_t *ptr_mode);

typedef clx_error_no_t (*hal_swc_excpt_set_func_t)(const uint32 unit,
                                                   const uint32 enable,
                                                   const clx_fwd_action_t action);

typedef clx_error_no_t (*hal_swc_trap_all_set_func_t)(const uint32 unit, const uint32 enable);

typedef clx_error_no_t (*hal_swc_epg_pkt_init_func_t)(hal_swc_epg_pkt_t *ptr_pkt);

typedef clx_error_no_t (*hal_swc_epg_mac_hw_set_func_t)(const uint32 unit,
                                                        const hal_swc_epg_pkt_t *ptr_pkt);

typedef clx_error_no_t (*hal_swc_epg_mac_done_check_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_swc_epg_mac_pkt_stop_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_swc_rsn_act_set_func_t)(const uint32 unit,
                                                     const clx_pkt_rx_reason_t rx_reason_code,
                                                     const clx_swc_rsn_act_t *rx_reason_action);

typedef clx_error_no_t (*hal_swc_rsn_act_get_func_t)(const uint32 unit,
                                                     const clx_pkt_rx_reason_t rx_reason_code,
                                                     clx_swc_rsn_act_t *rx_reason_action);

typedef clx_error_no_t (*hal_swc_rsn_pri_set_func_t)(const uint32 unit,
                                                     const clx_pkt_rx_reason_t rx_reason_code,
                                                     const uint32 priority);

typedef clx_error_no_t (*hal_swc_rsn_pri_get_func_t)(const uint32 unit,
                                                     const clx_pkt_rx_reason_t rx_reason_code,
                                                     uint32 *priority);

typedef clx_error_no_t (*hal_swc_pp_rsn_pri_set_func_t)(const uint32 unit,
                                                        const uint32 pp_reason_code,
                                                        const uint32 priority);

typedef clx_error_no_t (*hal_swc_pp_rsn_pri_get_func_t)(const uint32 unit,
                                                        const uint32 pp_reason_code,
                                                        uint32 *priority);

typedef clx_error_no_t (*hal_swc_max_ts_sec_get_func_t)(const uint32 unit, uint32 *max_ts_sec);

typedef clx_error_no_t (*hal_swc_tod_info_get_func_t)(const uint32 unit, clx_swc_ts_t *ptr_ts_val);

typedef clx_error_no_t (*hal_swc_tbl_name_get_func_t)(const uint32 unit,
                                                      const uint32 tbl_id,
                                                      const uint32 tbl_name_len,
                                                      char *ptr_tbl_name);

typedef clx_error_no_t (*hal_swc_str_name_get_func_t)(const uint32 unit,
                                                      const clx_swc_data_type_t data_type,
                                                      const uint32 index,
                                                      const uint32 str_len,
                                                      char *str_name);

typedef clx_error_no_t (*hal_swc_chip_pll_status_get_func_t)(
    const uint32 unit,
    clx_swc_chip_pll_status_t *ptr_pll_status);

typedef clx_error_no_t (*hal_swc_skip_rx_crc_check_set_func_t)(const uint32 unit,
                                                               const uint32 enable);

typedef clx_error_no_t (*hal_swc_skip_rx_crc_check_get_func_t)(const uint32 unit,
                                                               uint32 *ptr_enable);

typedef clx_error_no_t (*hal_swc_runt_pkt_fwd_set_func_t)(const uint32 unit, const uint32 enable);

typedef clx_error_no_t (*hal_swc_runt_pkt_fwd_get_func_t)(const uint32 unit, uint32 *ptr_enable);

typedef clx_error_no_t (*hal_swc_hsh_path_get_func_t)(const uint32 unit,
                                                      const clx_swc_hsh_pkt_type_t hash_type,
                                                      const clx_swc_flow_hsh_key_t *ptr_hash_key,
                                                      const uint32 id,
                                                      clx_swc_hsh_path_rslt_info_t *ptr_rslt);

typedef clx_error_no_t (*hal_swc_hsh_path_key_get_func_t)(const uint32 unit,
                                                          const clx_swc_hsh_pkt_type_t hash_type,
                                                          const clx_swc_hsh_path_pkt_info_t pkt_info,
                                                          clx_swc_hsh_key_bmp_t *key_bitmap);

typedef clx_error_no_t (*hal_swc_fdl_thd_set_func_t)(const uint32 unit, const uint32 threshold);

typedef clx_error_no_t (*hal_swc_fdl_thd_get_func_t)(const uint32 unit, uint32 *ptr_threshold);

/*switch control multiplexing functions end*/

/* qos multiplexing functions start */

typedef clx_error_no_t (*hal_qos_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_qos_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_qos_prof_create_func_t)(const uint32 unit,
                                                     const clx_dir_t direction,
                                                     const clx_qos_mapping_type_t mapping_type,
                                                     const uint32 profileId);

typedef clx_error_no_t (*hal_qos_prof_destroy_func_t)(const uint32 unit,
                                                      const clx_dir_t direction,
                                                      const clx_qos_mapping_type_t mapping_type,
                                                      const uint32 profileId);

typedef clx_error_no_t (*hal_qos_prof_set_func_t)(const uint32 unit,
                                                  const clx_dir_t direction,
                                                  const clx_qos_mapping_type_t mapping_type,
                                                  const uint32 profileId,
                                                  const clx_qos_mapping_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_qos_prof_get_func_t)(const uint32 unit,
                                                  const clx_dir_t direction,
                                                  const clx_qos_mapping_type_t mapping_type,
                                                  const uint32 profileId,
                                                  clx_qos_mapping_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_qos_cosq_mapping_set_func_t)(const uint32 unit,
                                                          const uint32 port,
                                                          const uint32 tc,
                                                          const uint32 queue_id);

typedef clx_error_no_t (*hal_qos_cosq_mapping_get_func_t)(const uint32 unit,
                                                          const uint32 port,
                                                          const uint32 tc,
                                                          uint32 *ptr_queue_id);

typedef clx_error_no_t (*HAL_QOS_SETUSEINNERTCP_FUNC_T)(const uint32 unit, const uint32 use_inner);

typedef clx_error_no_t (*HAL_QOS_GETUSEINNERTCP_FUNC_T)(const uint32 unit, uint32 *ptr_use_inner);

/* qos multiplexing functions end */

/* meter multiplexing functions start */
typedef clx_error_no_t (*hal_meter_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_meter_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_meter_create_func_t)(const uint32 unit,
                                                  const clx_meter_cfg_t *ptr_cfg,
                                                  uint32 *ptr_meter_id);

typedef clx_error_no_t (*hal_meter_destroy_func_t)(const uint32 unit, const uint32 meter_id);

typedef clx_error_no_t (*hal_meter_get_func_t)(const uint32 unit,
                                               const uint32 meter_id,
                                               clx_meter_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_meter_param_set_func_t)(const uint32 unit,
                                                     const uint32 meter_id,
                                                     const clx_meter_param_t *ptr_param);

/* meter multiplexing functions end */

/* stat multiplexing functions start */
typedef clx_error_no_t (*hal_stat_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_stat_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_stat_port_cnt_get_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const clx_stat_port_t type,
                                                       uint64 *ptr_cnt);

typedef clx_error_no_t (*hal_stat_port_cnt_clear_func_t)(const uint32 unit,
                                                         const uint32 port,
                                                         const clx_stat_port_t type);

typedef clx_error_no_t (*hal_stat_tm_cnt_get_func_t)(const uint32 unit,
                                                     const uint32 port,
                                                     const clx_tm_handler_t handler,
                                                     const clx_stat_tm_t type,
                                                     clx_stat_tm_cnt_t *ptr_cnt);

typedef clx_error_no_t (*hal_stat_tm_cnt_clear_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const clx_tm_handler_t handler,
                                                       const clx_stat_tm_t type);

typedef clx_error_no_t (*hal_stat_queue_cnt_get_func_t)(const uint32 unit,
                                                        const clx_tm_handler_t handler,
                                                        clx_stat_tm_cnt_t *ptr_cnt);

typedef clx_error_no_t (*hal_stat_queue_cnt_clear_func_t)(const uint32 unit,
                                                          const clx_tm_handler_t handler);

typedef clx_error_no_t (*hal_stat_dist_cnt_create_func_t)(const uint32 unit, uint32 *ptr_cnt_id);

typedef clx_error_no_t (*hal_stat_dist_cnt_destroy_func_t)(const uint32 unit, const uint32 cnt_id);

typedef clx_error_no_t (*hal_stat_dist_cnt_get_func_t)(const uint32 unit,
                                                       const uint32 cnt_id,
                                                       clx_stat_dist_cnt_t *ptr_cnt);

typedef clx_error_no_t (*hal_stat_dist_cnt_clear_func_t)(const uint32 unit, const uint32 cnt_id);

typedef clx_error_no_t (*hal_stat_srv_cnt_create_func_t)(const uint32 unit,
                                                         const clx_stat_srv_cnt_cfg_t *ptr_cfg,
                                                         uint32 *ptr_cnt_id);

typedef clx_error_no_t (*hal_stat_srv_cnt_destroy_func_t)(const uint32 unit, uint32 cnt_id);

typedef clx_error_no_t (*hal_stat_srv_cnt_get_func_t)(const uint32 unit,
                                                      const uint32 cnt_id,
                                                      clx_stat_srv_cnt_t *ptr_cnt);

typedef clx_error_no_t (*hal_stat_srv_cnt_clear_func_t)(const uint32 unit, const uint32 cnt_id);

typedef clx_error_no_t (*hal_stat_srv_cnt_cfg_get_func_t)(const uint32 unit,
                                                          const uint32 cnt_id,
                                                          clx_stat_srv_cnt_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_stat_port_rate_get_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        const clx_stat_rate_type_t type,
                                                        uint64 *ptr_rate);

typedef clx_error_no_t (*hal_stat_port_rate_type_get_func_t)(const uint32 unit,
                                                             const clx_stat_port_t type,
                                                             clx_stat_rate_type_t *rate_type);

typedef clx_error_no_t (*hal_stat_cnt_refresh_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_stat_dbg_cnt_show_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const uint32 stage_bmp,
                                                       const uint32 flags);

typedef clx_error_no_t (*hal_stat_dbg_cnt_clear_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_stat_cnt_hw_idx_get_func_t)(const uint32 unit,
                                                         const uint32 sw_cnt_id,
                                                         const hal_stat_hw_type_t cnt_type,
                                                         const hal_stat_pp_obj_type_t pp_obj_type,
                                                         uint32 *ptr_hw_cnt_idx);

typedef clx_error_no_t (*hal_stat_pp_bank_id_get_func_t)(const uint32 unit,
                                                         const uint32 hw_cnt_id,
                                                         const clx_stat_srv_cnt_mode_t mode,
                                                         uint32 *ptr_bank_id,
                                                         uint32 *ptr_sw_bmap_idx_of_bank);

typedef clx_error_no_t (*hal_stat_cnt_hw_idx_free_func_t)(const uint32 unit,
                                                          const hal_stat_hw_type_t cnt_type,
                                                          const uint32 hw_cnt_idx);

typedef clx_error_no_t (*hal_stat_reason_cnt_get_func_t)(const uint32 unit,
                                                         const clx_pkt_rx_reason_t rx_reason_code,
                                                         uint64 *ptr_cnt);

typedef clx_error_no_t (
    *hal_stat_reason_cnt_clear_func_t)(const uint32 unit, const clx_pkt_rx_reason_t rx_reason_code);

typedef clx_error_no_t (*hal_stat_drop_reason_cnt_get_func_t)(const uint32 unit,
                                                              const uint32 rsn_code,
                                                              uint64 *ptr_cnt);

typedef clx_error_no_t (*hal_stat_drop_reason_cnt_clear_func_t)(const uint32 unit,
                                                                const uint32 rsn_code);

typedef clx_error_no_t (*hal_stat_hw_reason_cnt_get_func_t)(const uint32 unit,
                                                            const uint32 rsn_code,
                                                            uint64 *ptr_cnt);

typedef clx_error_no_t (*hal_stat_hw_reason_cnt_clear_func_t)(const uint32 unit,
                                                              const uint32 rsn_code);

#ifdef CLX_STAT_EN_HPC_CNT
typedef clx_error_no_t (*hal_stat_hpc_port_util_ratio_get_func_t)(const uint32 unit,
                                                                  const uint32 port,
                                                                  const clx_dir_t direction,
                                                                  const uint64 cnt,
                                                                  double *ptr_util_ratio);

typedef clx_error_no_t (*hal_stat_hpc_state_get_func_t)(const uint32 unit, boolean *ptr_state);

typedef clx_error_no_t (*hal_stat_hpc_state_set_func_t)(const uint32 unit, boolean state);

typedef clx_error_no_t (*hal_stat_hpc_polling_interval_get_func_t)(const uint32 unit,
                                                                   uint32 *ptr_polling_intvl);

typedef clx_error_no_t (*hal_stat_hpc_polling_interval_set_func_t)(const uint32 unit,
                                                                   uint32 polling_intvl);

typedef clx_error_no_t (*hal_stat_hpc_create_func_t)(const uint32 unit,
                                                     const clx_stat_hpc_cfg_t cfg);

typedef clx_error_no_t (*hal_stat_hpc_destroy_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_stat_hpc_dequeue_func_t)(const uint32 unit,
                                                      clx_stat_hpc_cnt_t *ptr_hpc_cnt_node);
#endif /* End of CLX_STAT_EN_HPC_CNT */

typedef clx_error_no_t (*hal_stat_hrm_watermark_get_func_t)(const uint32 unit,
                                                            const uint32 port,
                                                            const clx_tm_handler_t handler,
                                                            uint32 *ptr_cnt);

typedef clx_error_no_t (*hal_stat_hrm_watermark_clear_func_t)(const uint32 unit,
                                                              const uint32 port,
                                                              const clx_tm_handler_t handler);

typedef clx_error_no_t (*hal_stat_hrm_occupancy_get_func_t)(const uint32 unit,
                                                            const uint32 port,
                                                            const clx_tm_handler_t handler,
                                                            uint32 *ptr_occupancy);
/* stat multiplexing functions end */

/* tm multiplexing functions start */
typedef clx_error_no_t (*hal_tm_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_tm_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_tm_handler_create_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const clx_tm_handler_type_t handler_type,
                                                       const uint32 queue_id,
                                                       clx_tm_handler_t *ptr_handler);

typedef clx_error_no_t (*hal_tm_handler_destroy_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        const clx_tm_handler_t handler);

typedef clx_error_no_t (*hal_tm_sch_shaper_set_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const clx_tm_handler_t handler,
                                                       const clx_tm_shaper_t *ptr_bandwidth);

typedef clx_error_no_t (*hal_tm_sch_shaper_get_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const clx_tm_handler_t handler,
                                                       clx_tm_shaper_t *ptr_bandwidth);

typedef clx_error_no_t (*hal_tm_sch_sched_mode_set_func_t)(const uint32 unit,
                                                           const uint32 port,
                                                           const clx_tm_handler_t handler,
                                                           const clx_tm_sched_cfg_t sched_cfg);

typedef clx_error_no_t (*hal_tm_sch_sched_mode_get_func_t)(const uint32 unit,
                                                           const uint32 port,
                                                           const clx_tm_handler_t handler,
                                                           clx_tm_sched_cfg_t *ptr_sched_cfg);

typedef clx_error_no_t (*hal_tm_cfg_set_func_t)(const uint32 unit,
                                                const uint32 port,
                                                const clx_tm_handler_t handler,
                                                const clx_tm_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_tm_cfg_get_func_t)(const uint32 unit,
                                                const uint32 port,
                                                const clx_tm_handler_t handler,
                                                clx_tm_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_tm_pfc_mapping_set_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        const uint32 queue,
                                                        const clx_tm_pfc_mapping_cfg_t *ptr_pfc);

typedef clx_error_no_t (*hal_tm_pfc_mapping_get_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        const uint32 queue,
                                                        clx_tm_pfc_mapping_cfg_t *ptr_pfc);

typedef clx_error_no_t (*hal_tm_buf_usage_get_func_t)(const uint32 unit,
                                                      const uint32 port,
                                                      const clx_tm_handler_t handler,
                                                      const clx_tm_buf_stat_type_t buf_usage_type,
                                                      uint32 *ptr_usage);

typedef clx_error_no_t (*hal_tm_buf_watermark_get_func_t)(
    const uint32 unit,
    const uint32 port,
    const clx_tm_handler_t handler,
    const clx_tm_buf_stat_type_t buf_watermark_type,
    uint32 *ptr_watermark);

typedef clx_error_no_t (*hal_tm_buf_watermark_clear_func_t)(
    const uint32 unit,
    const uint32 port,
    const clx_tm_handler_t handler,
    const clx_tm_buf_stat_type_t buf_watermark_type);
typedef clx_error_no_t (*hal_pkt_reg_show_func_t)(const uint32 unit,
                                                  const uint32 flags,
                                                  const void *cookies);

typedef clx_error_no_t (*hal_tm_pfc_state_get_func_t)(const uint32 unit,
                                                      const uint32 port,
                                                      const clx_tm_handler_t handler,
                                                      clx_tm_pfc_state_t *ptr_state);

typedef clx_error_no_t (*hal_tm_pfcwd_cb_register_func_t)(
    const uint32 unit,
    const clx_tm_pfcwd_handle_func_t notify_function,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_tm_pfcwd_cb_deregister_func_t)(
    const uint32 unit,
    const clx_tm_pfcwd_handle_func_t notify_function,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_tm_pfcwd_set_func_t)(const uint32 unit,
                                                  const clx_port_t port,
                                                  const uint32 queue,
                                                  const clx_tm_pfcwd_cfg_t *ptr_entry);

typedef clx_error_no_t (*hal_tm_pfcwd_get_func_t)(const uint32 unit,
                                                  const clx_port_t port,
                                                  const uint32 queue,
                                                  clx_tm_pfcwd_cfg_t *ptr_entry);

typedef clx_error_no_t (*hal_tm_pfcwd_state_set_func_t)(const uint32 unit,
                                                        const clx_port_t port,
                                                        const uint32 queue,
                                                        const clx_tm_pfcwd_state_t state);

typedef clx_error_no_t (*hal_tm_pfcwd_state_get_func_t)(const uint32 unit,
                                                        const clx_port_t port,
                                                        const uint32 queue,
                                                        clx_tm_pfcwd_state_t *ptr_state);

typedef clx_error_no_t (*hal_tm_tc_prof_set_func_t)(const uint32 unit,
                                                    const uint32 profile_id,
                                                    const clx_tm_tc_prof_t *profile);

typedef clx_error_no_t (*hal_tm_tc_prof_get_func_t)(const uint32 unit,
                                                    const uint32 profile_id,
                                                    clx_tm_tc_prof_t *profile);

typedef clx_error_no_t (*HAL_TM_SETTCCUTTHROUGH_FUNC_T)(const uint32 unit,
                                                        const uint32 tc,
                                                        const boolean enable);

typedef clx_error_no_t (*HAL_TM_GETTCCUTTHROUGH_FUNC_T)(const uint32 unit,
                                                        const uint32 tc,
                                                        boolean *enable);

typedef clx_error_no_t (*hal_tm_buf_prof_create_func_t)(const uint32 unit,
                                                        const clx_tm_buf_prof_type_t buf_prof_type,
                                                        const uint32 profile_id);

typedef clx_error_no_t (*hal_tm_buf_prof_destroy_func_t)(const uint32 unit,
                                                         const clx_tm_buf_prof_type_t buf_prof_type,
                                                         const uint32 profile_id);

typedef clx_error_no_t (*hal_tm_buf_prof_set_func_t)(const uint32 unit,
                                                     const uint32 profile_id,
                                                     const clx_tm_buf_prof_t *profile);

typedef clx_error_no_t (*hal_tm_buf_prof_get_func_t)(const uint32 unit,
                                                     const uint32 profile_id,
                                                     clx_tm_buf_prof_t *profile);

typedef clx_error_no_t (*hal_tm_buf_cfg_set_func_t)(const uint32 unit,
                                                    const uint32 port,
                                                    const clx_tm_handler_t handler,
                                                    const clx_tm_buf_cfg_t *ptr_config);

typedef clx_error_no_t (*hal_tm_buf_cfg_get_func_t)(const uint32 unit,
                                                    const uint32 port,
                                                    const clx_tm_handler_t handler,
                                                    clx_tm_buf_cfg_t *ptr_config);

typedef clx_error_no_t (*hal_tm_wred_prof_create_func_t)(const uint32 unit,
                                                         const uint32 profile_id);

typedef clx_error_no_t (*hal_tm_wred_prof_destroy_func_t)(const uint32 unit,
                                                          const uint32 profile_id);
typedef clx_error_no_t (*hal_tm_wred_prof_set_func_t)(const uint32 unit,
                                                      const uint32 profile_id,
                                                      const clx_tm_wred_prof_t *ptr_wred_profile);

typedef clx_error_no_t (*hal_tm_wred_prof_get_func_t)(const uint32 unit,
                                                      const uint32 profile_id,
                                                      clx_tm_wred_prof_t *ptr_wred_profile);

typedef clx_error_no_t (*hal_tm_wred_cfg_set_func_t)(const uint32 unit,
                                                     const uint32 port,
                                                     const clx_tm_handler_t handler,
                                                     const clx_tm_wred_cfg_t *ptr_wred_cfg);

typedef clx_error_no_t (*hal_tm_wred_cfg_get_func_t)(const uint32 unit,
                                                     const uint32 port,
                                                     const clx_tm_handler_t handler,
                                                     clx_tm_wred_cfg_t *ptr_wred_cfg);

typedef clx_error_no_t (*hal_tm_histogram_cfg_set_func_t)(const uint32 unit,
                                                          const clx_tm_histogram_cfg_t *ptr_config);

typedef clx_error_no_t (*hal_tm_histogram_cfg_get_func_t)(const uint32 unit,
                                                          clx_tm_histogram_cfg_t *ptr_config);

typedef clx_error_no_t (*hal_tm_histogram_cb_register_func_t)(const uint32 unit,
                                                              const uint32 port,
                                                              const clx_tm_histogram_cb_t func,
                                                              void *ptr_cookie);

typedef clx_error_no_t (*hal_tm_histogram_cb_deregister_func_t)(const uint32 unit,
                                                                const uint32 port,
                                                                const clx_tm_histogram_cb_t func,
                                                                void *ptr_cookie);

typedef clx_error_no_t (*hal_tm_histogram_cnt_clear_func_t)(const uint32 unit,
                                                            const uint32 port,
                                                            const clx_tm_handler_t handler);
typedef clx_error_no_t (*hal_tm_tcb_match_set_func_t)(const uint32 unit,
                                                      const clx_tm_tcb_match_type_t type,
                                                      const clx_tm_tcb_match_t *ptr_match);

typedef clx_error_no_t (*hal_tm_tcb_match_get_func_t)(const uint32 unit,
                                                      const clx_tm_tcb_match_type_t type,
                                                      clx_tm_tcb_match_t *ptr_match);

typedef clx_error_no_t (*hal_tm_tcb_cfg_set_func_t)(const uint32 unit,
                                                    const clx_tm_tcb_cfg_type_t type,
                                                    const uint32 value);

typedef clx_error_no_t (*hal_tm_tcb_cfg_get_func_t)(const uint32 unit,
                                                    const clx_tm_tcb_cfg_type_t type,
                                                    uint32 *ptr_value);

typedef clx_error_no_t (*hal_tm_tcb_cb_register_func_t)(const uint32 unit,
                                                        const clx_tm_tcb_func_t func,
                                                        void *ptr_cookie);

typedef clx_error_no_t (*hal_tm_tcb_cb_deregister_func_t)(const uint32 unit,
                                                          const clx_tm_tcb_func_t func,
                                                          void *ptr_cookie);

typedef clx_error_no_t (*hal_tm_mburst_prof_create_func_t)(const uint32 unit, const uint32 prof_id);

typedef clx_error_no_t (*hal_tm_mburst_prof_destroy_func_t)(const uint32 unit,
                                                            const uint32 prof_id);

typedef clx_error_no_t (*hal_tm_mburst_prof_set_func_t)(const uint32 unit,
                                                        const uint32 prof_id,
                                                        const clx_tm_mburst_prof_t *ptr_prof);

typedef clx_error_no_t (*hal_tm_mburst_prof_get_func_t)(const uint32 unit,
                                                        const uint32 prof_id,
                                                        clx_tm_mburst_prof_t *ptr_prof);

typedef clx_error_no_t (*hal_tm_mburst_cfg_set_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const clx_tm_handler_t handler,
                                                       const clx_tm_mburst_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_tm_mburst_cfg_get_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const clx_tm_handler_t handler,
                                                       clx_tm_mburst_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_tm_mburst_cb_register_func_t)(const uint32 unit,
                                                           const clx_tm_mburst_func_t func,
                                                           void *ptr_cookie);

typedef clx_error_no_t (*hal_tm_mburst_cb_deregister_func_t)(const uint32 unit,
                                                             const clx_tm_mburst_func_t func,
                                                             void *ptr_cookie);
typedef clx_error_no_t (*hal_tm_tm_hqos_enable_get_func_t)(const uint32 unit,
                                                           const uint32 port,
                                                           boolean *ptr_enable);

typedef clx_error_no_t (*HAL_TM_REP_INSERTEMDB_FUNC_T)(const uint32 unit,
                                                       const uint32 mg_id,
                                                       const uint32 sn_num,
                                                       const uint32 mcdb_ptr,
                                                       uint32 *ptr_emdb_idx);

typedef clx_error_no_t (*HAL_TM_REP_SEARCHEMDB_FUNC_T)(const uint32 unit,
                                                       const uint32 mg_id,
                                                       const uint32 sn_num,
                                                       uint32 *ptr_mcdb_ptr,
                                                       uint32 *ptr_emdb_id,
                                                       uint32 *ptr_emdb_idx);

typedef clx_error_no_t (*HAL_TM_REP_DELETEEMDB_FUNC_T)(const uint32 unit,
                                                       const uint32 mg_id,
                                                       const uint32 sn_num,
                                                       const uint32 cp_index);

typedef clx_error_no_t (*HAL_TM_REP_GETEMDB_FUNC_T)(const uint32 unit,
                                                    const uint32 mg_id,
                                                    const uint32 sn_num,
                                                    uint32 *ptr_emdb_id);

typedef clx_error_no_t (*HAL_TM_REP_ALLOCMCDB_FUNC_T)(const uint32 unit,
                                                      const uint32 emdb_id,
                                                      uint32 *ptr_mcdb_idx);

typedef clx_error_no_t (*HAL_TM_REP_ADDMCDB_FUNC_T)(const uint32 unit,
                                                    const uint32 emdb_id,
                                                    const uint32 mcdb_id,
                                                    const uint32 is_even,
                                                    const uint32 is_fl,
                                                    const uint32 di,
                                                    const uint32 cud);
typedef clx_error_no_t (*HAL_TM_REP_DELETCMCDB_FUNC_T)(const uint32 unit,
                                                       const uint32 emdb_id,
                                                       const uint32 mcdb_id,
                                                       const uint32 is_even);

typedef clx_error_no_t (*HAL_TM_REP_GETCMCDB_FUNC_T)(const uint32 unit,
                                                     const uint32 emdb_id,
                                                     const uint32 mcdb_id,
                                                     const uint32 is_even,
                                                     uint32 *ptr_is_fl,
                                                     uint32 *ptr_di,
                                                     uint32 *ptr_cud);

typedef clx_error_no_t (*HAL_TM_REP_FREECMCDB_FUNC_T)(const uint32 unit,
                                                      const uint32 emdb_id,
                                                      const uint32 mcdb_id);

typedef clx_error_no_t (*HAL_TM_REP_DELETEMG_MEMBER_FUNC_T)(const uint32 unit,
                                                            const uint32 mg_id,
                                                            const uint32 mg_size,
                                                            const uint32 leave_sn,
                                                            const uint32 swap_sn,
                                                            const uint32 leave_mcdb_id,
                                                            const uint32 swap_mcdb_id,
                                                            const uint32 swap_emdb_idx);

typedef clx_error_no_t (*HAL_TM_REP_DELETEALLMG_MEMBER_FUNC_T)(const uint32 unit,
                                                               const uint32 mg_id,
                                                               const uint32 mg_size);
typedef clx_error_no_t (*HAL_TM_REP_UPDATEMG_MEMBER_FUNC_T)(const uint32 unit,
                                                            const uint32 mg_id,
                                                            const uint32 mg_size,
                                                            const uint32 sn,
                                                            const uint32 mcdb_idx,
                                                            const uint32 cud,
                                                            const uint32 di);
/* tm multiplexing functions end */

/* MPLS multiplexing functions */
typedef clx_error_no_t (*hal_mpls_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_mpls_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_mpls_vpn_id_create_fun_t)(const uint32 unit,
                                                       const clx_mpls_vpn_info_t *vpn_info,
                                                       uint32 *vpn_id);

typedef clx_error_no_t (*hal_mpls_vpn_id_destroy_fun_t)(const uint32 unit, const clx_port_t port);
typedef clx_error_no_t (*hal_mpls_vpn_id_get_fun_t)(const uint32 unit,
                                                    const clx_mpls_get_type_t type,
                                                    clx_mpls_vpn_info_t *ptr_key);
typedef clx_error_no_t (*hal_mpls_lsp_port_create_fun_t)(const uint32 unit,
                                                         clx_mpls_lsp_info_t *ptr_lsp_port);

typedef clx_error_no_t (*hal_mpls_lsp_port_destroy_fun_t)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*hal_mpls_lsp_port_get_fun_t)(const uint32 unit,
                                                      const clx_mpls_get_type_t type,
                                                      clx_mpls_lsp_info_t *ptr_lsp_port);

typedef clx_error_no_t (*hal_mpls_encap_add_fun_t)(const uint32 unit,
                                                   const clx_mpls_encap_info_t *ptr_init);

typedef clx_error_no_t (*hal_mpls_encap_del_fun_t)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*hal_mpls_encap_get_fun_t)(const uint32 unit,
                                                   clx_mpls_encap_info_t *ptr_init);

typedef clx_error_no_t (*hal_mpls_decap_add_fun_t)(const uint32 unit,
                                                   const clx_mpls_decap_info_t *ptr_term);

typedef clx_error_no_t (*hal_mpls_decap_del_fun_t)(const uint32 unit,
                                                   const clx_mpls_match_info_t *ptr_key);

typedef clx_error_no_t (*hal_mpls_decap_get_fun_t)(const uint32 unit,
                                                   clx_mpls_decap_info_t *ptr_term);

typedef clx_error_no_t (*hal_mpls_transit_add_fun_t)(const uint32 unit,
                                                     const clx_mpls_switch_info_t *ptr_nhlfe);

typedef clx_error_no_t (*hal_mpls_transit_del_fun_t)(const uint32 unit,
                                                     const clx_mpls_match_info_t *ptr_key);

typedef clx_error_no_t (*hal_mpls_transit_get_fun_t)(const uint32 unit,
                                                     clx_mpls_switch_info_t *ptr_nh_info);

typedef clx_error_no_t (*hal_mpls_pw_port_create_fun_t)(const uint32 unit,
                                                        clx_mpls_pw_port_t *ptr_pw_port);

typedef clx_error_no_t (*hal_mpls_pw_port_destroy_fun_t)(const uint32 unit,
                                                         const clx_port_t pw_port);

typedef clx_error_no_t (*hal_mpls_pw_port_get_fun_t)(const uint32 unit,
                                                     const clx_mpls_get_type_t type,
                                                     clx_mpls_pw_port_t *ptr_pw);

typedef clx_error_no_t (*hal_mpls_pw_add_fun_t)(const uint32 unit,
                                                const clx_mpls_pw_info_t *ptr_pw);

typedef clx_error_no_t (*hal_mpls_pw_del_fun_t)(const uint32 unit, const clx_port_t pw_port);

typedef clx_error_no_t (*hal_mpls_pw_get_fun_t)(const uint32 unit, clx_mpls_pw_info_t *ptr_pw);

typedef clx_error_no_t (*hal_mpls_vpws_add_fun_t)(const uint32 unit,
                                                  const clx_mpls_vpws_t *ptr_vpws);

typedef clx_error_no_t (*hal_mpls_vpws_del_fun_t)(const uint32 unit, const clx_port_t pw_port);

typedef clx_error_no_t (*hal_mpls_vpws_get_fun_t)(const uint32 unit, clx_mpls_vpws_t *ptr_vpws);

typedef clx_error_no_t (*hal_mpls_lbl_range_set_fun_t)(const uint32 unit,
                                                       const clx_mpls_lbl_range_t lbl_range);

typedef clx_error_no_t (*hal_mpls_lbl_range_get_fun_t)(const uint32 unit,
                                                       clx_mpls_lbl_range_t *lbl_range);

typedef clx_error_no_t (*hal_mpls_encap_trav_fun_t)(const uint32 unit,
                                                    const clx_mpls_encap_trav_fun_t cb,
                                                    void *ptr_cookie);

typedef clx_error_no_t (*hal_mpls_transit_trav_fun_t)(const uint32 unit,
                                                      const clx_mpls_transit_trav_func_t cb,
                                                      void *ptr_cookie);

typedef clx_error_no_t (*hal_mpls_decap_trav_fun_t)(const uint32 unit,
                                                    const clx_mpls_decap_trav_func_t cb,
                                                    void *ptr_cookie);

typedef clx_error_no_t (*hal_mpls_pw_trav_fun_t)(const uint32 unit,
                                                 const clx_mpls_pw_trav_func_t cb,
                                                 void *ptr_cookie);
/* MPLS multiplexing functions end */

/* Stacking multiplexing functions */
typedef clx_error_no_t (*hal_stk_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_stk_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_stk_my_chip_id_set_func_t)(const uint32 unit, const uint32 chip);

typedef clx_error_no_t (*hal_stk_my_chip_id_get_func_t)(const uint32 unit, uint32 *ptr_chip);

typedef clx_error_no_t (*hal_stk_neighbor_chip_id_set_func_t)(const uint32 unit,
                                                              const uint32 path,
                                                              const uint32 chip);

typedef clx_error_no_t (*hal_stk_neighbor_chip_id_get_func_t)(const uint32 unit,
                                                              const uint32 path,
                                                              uint32 *ptr_chip);

typedef clx_error_no_t (*hal_stk_cutoff_chip_id_set_func_t)(const uint32 unit,
                                                            const uint32 path,
                                                            const uint32 chip);

typedef clx_error_no_t (*hal_stk_cutoff_chip_id_get_func_t)(const uint32 unit,
                                                            const uint32 path,
                                                            uint32 *ptr_chip);

typedef clx_error_no_t (*hal_stk_stacking_port_add_func_t)(const uint32 unit,
                                                           const uint32 path,
                                                           const uint32 port);

typedef clx_error_no_t (*hal_stk_stacking_port_del_func_t)(const uint32 unit,
                                                           const uint32 path,
                                                           const uint32 port);

typedef clx_error_no_t (*hal_stk_stacking_port_get_func_t)(const uint32 unit,
                                                           const uint32 path,
                                                           clx_port_bitmap_t *ptr_port_list);

typedef clx_error_no_t (*hal_stk_path_to_remote_chip_set_func_t)(const uint32 unit,
                                                                 const uint32 path,
                                                                 const uint32 chip);
typedef clx_error_no_t (*hal_stk_stacking_port_to_cpu_add_func_t)(const uint32 unit,
                                                                  const uint32 cpu_path,
                                                                  const uint32 port);

typedef clx_error_no_t (*hal_stk_stacking_port_to_cpu_del_func_t)(const uint32 unit,
                                                                  const uint32 cpu_path,
                                                                  const uint32 port);

typedef clx_error_no_t (*hal_stk_stacking_port_to_cpu_get_func_t)(const uint32 unit,
                                                                  const uint32 cpu_path,
                                                                  clx_port_bitmap_t *ptr_port_list);

typedef clx_error_no_t (*hal_stk_cpu_path_to_remote_chip_set_func_t)(const uint32 unit,
                                                                     const uint32 cpu_path,
                                                                     const uint32 chip);

typedef clx_error_no_t (*hal_stk_dpi_port_get_func_t)(const uint32 unit,
                                                      clx_port_bitmap_t *ptr_port_list);

typedef clx_error_no_t (*hal_stk_dpi_port_add_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_stk_dpi_port_del_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_stk_dil_entry_set_func_t)(const uint32 unit,
                                                       const uint32 di,
                                                       const clx_stk_dil_t *ptr_dil_entry);

typedef clx_error_no_t (*hal_stk_dil_entry_get_func_t)(const uint32 unit,
                                                       const uint32 di,
                                                       clx_stk_dil_t *ptr_dil_entry);

typedef clx_error_no_t (*hal_stk_chip_mode_get_func_t)(const uint32 unit, uint32 *ptr_chip_mode);

typedef clx_error_no_t (*hal_stk_chip_cfg_set_func_t)(const uint32 unit,
                                                      const clx_stk_chip_cfg_type_t cfg_type,
                                                      const clx_stk_chip_cfg_t *ptr_chip_cfg);

typedef clx_error_no_t (*hal_stk_chip_cfg_get_func_t)(const uint32 unit,
                                                      const clx_stk_chip_cfg_type_t cfg_type,
                                                      clx_stk_chip_cfg_t *ptr_chip_cfg);

typedef clx_error_no_t (*hal_stk_fab_port_add_func_t)(const uint32 unit,
                                                      const clx_stk_port_cfg_type_t cfg_type,
                                                      const clx_stk_port_cfg_t *ptr_port_cfg);

typedef clx_error_no_t (*hal_stk_fab_port_del_func_t)(const uint32 unit,
                                                      const clx_stk_port_cfg_type_t cfg_type,
                                                      const clx_stk_port_cfg_t *ptr_port_cfg);

typedef clx_error_no_t (*hal_stk_fab_port_get_func_t)(const uint32 unit,
                                                      const clx_stk_port_cfg_type_t cfg_type,
                                                      clx_stk_port_cfg_t *ptr_port_cfg);

typedef clx_error_no_t (*hal_stk_path_remote_map_set_func_t)(const uint32 unit,
                                                             const clx_stk_path_cfg_type_t cfg_type,
                                                             const clx_stk_path_cfg_t *ptr_path_cfg);

typedef clx_error_no_t (*hal_stk_fl_member_update_func_t)(const uint32 unit,
                                                          const uint32 fl_id,
                                                          const uint32 port,
                                                          const uint32 link);

typedef clx_error_no_t (*hal_stk_fabric_panel_port_add_func_t)(const uint32 unit,
                                                               const uint32 path,
                                                               const uint32 port);

typedef clx_error_no_t (*hal_stk_fabric_panel_port_del_func_t)(const uint32 unit,
                                                               const uint32 path,
                                                               const uint32 port);

typedef clx_error_no_t (*hal_stk_fabric_panel_port_get_func_t)(const uint32 unit,
                                                               const uint32 path,
                                                               const uint32 port_cnt,
                                                               uint32 *ptr_port_list,
                                                               uint32 *ptr_actual_port_cnt);

typedef clx_error_no_t (*hal_stk_path_tc_profile_idx_set_func_t)(const uint32 unit,
                                                                 const uint32 path,
                                                                 const uint32 profile_idx);

typedef clx_error_no_t (*hal_stk_path_tc_profile_idx_get_func_t)(const uint32 unit,
                                                                 const uint32 path,
                                                                 uint32 *ptr_profile_idx);
/* Stacking multiplexing functions end */

/* TELM multiplexing functions */
typedef clx_error_no_t (*hal_telm_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_telm_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_telm_notify_cb_register_func_t)(const uint32 unit,
                                                             const clx_telm_irq_type_t irq_type,
                                                             const void *callback,
                                                             void *ptr_cookie);

typedef clx_error_no_t (*hal_telm_notify_cb_deregister_func_t)(const uint32 unit,
                                                               const clx_telm_irq_type_t irq_type,
                                                               const void *callback,
                                                               void *ptr_cookie);

typedef clx_error_no_t (*hal_telm_cfg_get_func_t)(const uint32 unit,
                                                  const clx_telm_cfg_t cfg,
                                                  clx_telm_cfg_param_t *ptr_param);

typedef clx_error_no_t (*hal_telm_cfg_set_func_t)(const uint32 unit,
                                                  const clx_telm_cfg_t cfg,
                                                  const clx_telm_cfg_param_t *ptr_param);

typedef clx_error_no_t (*hal_telm_int_prof_get_func_t)(const uint32 unit,
                                                       const uint32 profile_id,
                                                       clx_telm_int_prof_t *ptr_cfg);

typedef clx_error_no_t (*hal_telm_int_prof_set_func_t)(const uint32 unit,
                                                       const uint32 profile_id,
                                                       const clx_telm_int_prof_t *ptr_cfg);

typedef clx_error_no_t (*hal_telm_int_glb_get_func_t)(const uint32 unit,
                                                      clx_telm_int_domain_t *ptr_domain_cfg,
                                                      clx_telm_int_device_t *ptr_device_cfg);

typedef clx_error_no_t (*hal_telm_int_glb_set_func_t)(const uint32 unit,
                                                      const clx_telm_int_domain_t *ptr_domain_cfg,
                                                      const clx_telm_int_device_t *ptr_device_cfg);

typedef clx_error_no_t (*hal_telm_ioam_cfg_get_func_t)(const uint32 unit,
                                                       clx_telm_ioam_cfg_t *ptr_ioam_cfg);

typedef clx_error_no_t (*hal_telm_ioam_cfg_set_func_t)(const uint32 unit,
                                                       const clx_telm_ioam_cfg_t *ptr_ioam_cfg);

typedef clx_error_no_t (*hal_telm_mod_cfg_get_func_t)(const uint32 unit,
                                                      clx_telm_mod_cfg_t *ptr_mod_cfg);

typedef clx_error_no_t (*hal_telm_mod_cfg_set_func_t)(const uint32 unit,
                                                      const clx_telm_mod_cfg_t *ptr_mod_cfg);

typedef clx_error_no_t (*hal_telm_ifa_cfg_get_func_t)(const uint32 unit,
                                                      clx_telm_ifa_cfg_t *ptr_ifa_cfg);

typedef clx_error_no_t (*hal_telm_ifa_cfg_set_func_t)(const uint32 unit,
                                                      const clx_telm_ifa_cfg_t *ptr_ifa_cfg);

typedef clx_error_no_t (*hal_telm_tob_set_func_t)(const uint32 unit,
                                                  const hal_mt_telm_tob_type_t op_type,
                                                  const uint32 value);

typedef clx_error_no_t (*hal_telm_tob_get_func_t)(const uint32 unit,
                                                  const hal_mt_telm_tob_type_t op_type,
                                                  uint32 *ptr_value);

typedef clx_error_no_t (*hal_telm_mod_tm_en_set_func_t)(const uint32 unit, const boolean mod_en);
typedef clx_error_no_t (*hal_telm_mod_tm_en_get_func_t)(const uint32 unit, uint32 *ptr_mod_en);
typedef clx_error_no_t (*hal_telm_type_set_func_t)(const uint32 unit,
                                                   const clx_telm_type_t telm_type);
typedef clx_error_no_t (*hal_telm_type_get_func_t)(const uint32 unit, uint32 *ptr_telm_type);
typedef clx_error_no_t (*hal_telm_delay_cycle_set_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_telm_int_sampler_set_func_t)(const uint32 unit,
                                                          const uint32 profile_id,
                                                          const uint32 threshold);
typedef clx_error_no_t (*hal_telm_int_instr_set_func_t)(const uint32 unit,
                                                        const uint32 profile_id,
                                                        const uint16 instr_bmp);
typedef clx_error_no_t (*hal_telm_int_instr_get_func_t)(const uint32 unit,
                                                        const uint32 profile_id,
                                                        uint16 *ptr_instr_bmp);
typedef clx_error_no_t (*hal_telm_int_prof_max_hop_cnt_set_func_t)(const uint32 unit,
                                                                   const uint32 profile_id,
                                                                   const uint32 max_hop_cnt);
typedef clx_error_no_t (*hal_telm_int_prof_max_hop_cnt_get_func_t)(const uint32 unit,
                                                                   const uint32 profile_id,
                                                                   uint32 *ptr_max_hop_cnt);
typedef clx_error_no_t (*hal_telm_int_prof_clean_func_t)(const uint32 unit,
                                                         const uint32 profile_id);
typedef clx_error_no_t (*hal_telm_int_tm_lut_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_telm_int_clone_set_func_t)(const uint32 unit, const boolean int_clone);
typedef clx_error_no_t (*hal_telm_int_clone_get_func_t)(const uint32 unit, boolean *ptr_int_clone);
typedef clx_error_no_t (*hal_telm_int_edge_set_func_t)(const uint32 unit,
                                                       const clx_port_t egr_port,
                                                       const boolean is_edge);
typedef clx_error_no_t (*hal_telm_int_edge_get_func_t)(const uint32 unit,
                                                       const clx_port_t egr_port,
                                                       boolean *ptr_is_edge);
typedef clx_error_no_t (*hal_telm_mode_set_func_t)(const uint32 unit,
                                                   const clx_telm_mode_t telm_mode);
typedef clx_error_no_t (*hal_telm_mode_get_func_t)(const uint32 unit,
                                                   clx_telm_mode_t *ptr_telm_mode);
typedef clx_error_no_t (*hal_telm_qocc_unit_size_set_func_t)(
    const uint32 unit,
    const clx_swc_cfg_qocc_unit_size_t qocc_unit_size);
typedef clx_error_no_t (*hal_telm_qocc_unit_size_get_func_t)(const uint32 unit,
                                                             uint32 *ptr_qocc_unit_size);

typedef clx_error_no_t (*hal_telm_qsize_stat_mode_set_func_t)(const uint32 unit,
                                                              const uint32 qsize_stat_mode);
typedef clx_error_no_t (*hal_telm_qsize_stat_mode_get_func_t)(const uint32 unit,
                                                              uint32 *ptr_qsize_stat_mode);

typedef clx_error_no_t (*hal_telm_int_identifier_set_func_t)(
    const uint32 unit,
    const uint32 attr_bmp,
    const clx_telm_int_identifier_t *identifier);
typedef clx_error_no_t (*hal_telm_int_identifier_get_func_t)(
    const uint32 unit,
    clx_telm_int_identifier_t *ptr_identifier);

typedef clx_error_no_t (*hal_telm_tm_trunc_size_get_func_t)(
    const uint32 unit,
    const clx_telm_trunc_pkt_size_t telm_trunc_size,
    hal_tm_trunc_size_t *ptr_tm_trunc_size);
typedef clx_error_no_t (*hal_telm_mod_rep_tnl_cfg_set_func_t)(const uint32 unit,
                                                              const uint32 nvo3_encap_id,
                                                              const uint32 nvo3_adj_id);
typedef clx_error_no_t (*hal_telm_mod_rep_tnl_cfg_get_func_t)(const uint32 unit,
                                                              uint32 *ptr_nvo3_encap_id,
                                                              uint32 *ptr_nvo3_adj_id);
typedef clx_error_no_t (*hal_telm_int_rep_tnl_cfg_set_func_t)(const uint32 unit,
                                                              const uint32 nvo3_encap_id,
                                                              const uint32 nvo3_adj_id);
typedef clx_error_no_t (*hal_telm_int_rep_tnl_cfg_del_func_t)(const uint32 unit,
                                                              const uint32 nvo3_encap_id);
typedef clx_error_no_t (*hal_telm_int_rep_tnl_cfg_get_func_t)(const uint32 unit,
                                                              uint32 *ptr_nvo3_encap_id,
                                                              uint32 *ptr_nvo3_adj_id);
typedef clx_error_no_t (*hal_telm_int_meta_info_set_func_t)(
    const uint32 unit,
    const clx_telm_int_mata_info_t *meta_info);
typedef clx_error_no_t (
    *hal_telm_int_meta_info_get_func_t)(const uint32 unit, clx_telm_int_mata_info_t *ptr_meta_info);
typedef clx_error_no_t (*hal_telm_int_restore_dscp_set_func_t)(
    const uint32 unit,
    const clx_telm_restore_dscp_t *dscp_restore);
typedef clx_error_no_t (*hal_telm_int_restore_dscp_get_func_t)(
    const uint32 unit,
    clx_telm_restore_dscp_t *ptr_dscp_restore);
typedef clx_error_no_t (*hal_telm_ioam_rwi_fifo_cfg_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_telm_ioam_hw_cfg_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_telm_ioam_fifo_to_clx_entry_convert_func_t)(
    const uint32 unit,
    const uint32 *ptr_fifo_entry,
    clx_telm_ioam_fifo_entry_t *ptr_clx_entry);
typedef clx_error_no_t (*hal_telm_port_speed_set_func_t)(const uint32 unit,
                                                         const uint32 port,
                                                         const clx_port_speed_t speed);
typedef clx_error_no_t (*hal_telm_ifa_hw_cfg_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_telm_mod_hw_cfg_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_telm_ioam_diag_cfg_get_func_t)(
    uint32 unit,
    hal_mt_telm_ioam_diag_reg_cfg_t *ptr_ioam_diag_reg);
typedef clx_error_no_t (*hal_telm_ioam_diag_cfg_set_func_t)(
    uint32 unit,
    hal_mt_telm_ioam_diag_reg_cfg_t *ptr_ioam_diag_reg);
typedef clx_error_no_t (*hal_telm_mod_reg_set_func_t)(const uint32 unit,
                                                      const clx_telm_mod_cfg_t *ptr_mod_cfg);
typedef clx_error_no_t (*hal_telm_mod_reg_get_func_t)(const uint32 unit,
                                                      clx_telm_mod_cfg_t *ptr_mod_cfg);

typedef clx_error_no_t (*hal_telm_rwo_encap_ip_set_func_t)(
    const uint32 unit,
    const uint32 nvo3_encap_id,
    const uint32 src_ip_encap_id,
    const uint32 dst_ip_encap_id,
    const clx_telm_collector_cfg_info_t *ptr_clct_cfg_info);
typedef clx_error_no_t (*hal_telm_rwo_encap_ip_get_func_t)(
    const uint32 unit,
    const uint32 nvo3_encap_id,
    uint32 *ptr_src_ip_encap_id,
    uint32 *ptr_dst_ip_encap_id,
    clx_telm_collector_cfg_info_t *ptr_clct_cfg_info);
typedef clx_error_no_t (*hal_telm_rwo_encap_ip_clear_func_t)(const uint32 unit,
                                                             const uint32 nvo3_encap_id);
typedef clx_error_no_t (*hal_telm_encap_ip_id_get_func_t)(const uint32 unit,
                                                          const boolean ipv4,
                                                          const uint32 src_ip_id,
                                                          const uint32 dst_ip_id,
                                                          clx_ip_addr_t *ptr_src_ip,
                                                          clx_ip_addr_t *ptr_dst_ip);
typedef clx_error_no_t (*hal_telm_mod_oq_get_func_t)(const uint32 unit,
                                                     const uint32 port,
                                                     const uint32 queue_id,
                                                     uint32 *ptr_out_queue);

typedef clx_error_no_t (*hal_telm_sub_module_init_func_t)(const uint32 unit);

/* TELM multiplexing functions end */

/* ECC multiplexing functions start */

typedef clx_error_no_t (*hal_ecc_set_cfg_func_t)(const uint32 unit,
                                                 const clx_ecc_module_type_t module_type,
                                                 const uint32 tbl_type,
                                                 const clx_ecc_cfg_t *ptr_ecc_cfg);

typedef clx_error_no_t (*hal_ecc_get_cfg_func_t)(const uint32 unit,
                                                 const clx_ecc_module_type_t module_type,
                                                 const uint32 tbl_type,
                                                 clx_ecc_cfg_t *ptr_ecc_cfg);

/* Debug dump multiplexing functions */
typedef clx_error_no_t (*hal_db_dump_func_t)(const uint32 unit, const uint32 flags);  /* flags is
                                                                                         used to
                                                                                         indicate
                                                                                         which db */

typedef clx_error_no_t (*hal_reg_dump_func_t)(const uint32 unit, const uint32 flags); /* flags
                                                                                         is used to
                                                                                         indicate
                                                                                         which
                                                                                         reg/table
                                                                                       */

/* ECPU multiplexing functions */
typedef clx_error_no_t (*hal_ecpu_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_hwinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_reboot_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_stop_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_force_stop_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_start_func_t)(const uint32 unit, const uint32 index);

typedef clx_error_no_t (*hal_ecpu_binary_start_func_t)(const uint32 unit,
                                                       const void *pdata,
                                                       const uint32 size);

typedef clx_error_no_t (*hal_ecpu_readmem_func_t)(const uint32 unit,
                                                  const uint32 addr,
                                                  const uint32 len,
                                                  uint32 *pbuf);

typedef clx_error_no_t (*hal_ecpu_readflash_func_t)(const uint32 unit,
                                                    const uint32 addr,
                                                    const uint32 len,
                                                    uint32 *pbuf);

typedef clx_error_no_t (*hal_ecpu_diag_log_read_func_t)(const uint32 unit,
                                                        const uint32 core,
                                                        char **ppbuf);

typedef clx_error_no_t (*hal_ecpu_fw_flash_update_func_t)(const uint32 unit,
                                                          const char *path,
                                                          const hal_ecpu_flash_update_type_t type);

typedef clx_error_no_t (*hal_ecpu_updatesramfw_func_t)(const uint32 unit,
                                                       const uint32 core,
                                                       char *path);

typedef clx_error_no_t (*hal_ecpu_updatesramrawfw_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_headroom_watermark_clr_func_t)(const uint32 unit,
                                                                 const uint32 port,
                                                                 const uint32 queue);

typedef boolean (*hal_ecpu_headroom_is_running_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_intr_register_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_intr_unregister_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_intr_to_ecpu_trigger_func_t)(const uint32 unit,
                                                               const uint32 core);

typedef clx_error_no_t (*hal_ecpu_from_ecpu_intr_clr_func_t)(const uint32 unit, const uint32 core);

typedef clx_error_no_t (*hal_ecpu_from_ecpu_intr_enable_func_t)(const uint32 unit,
                                                                const uint32 core);

typedef clx_error_no_t (*hal_ecpu_diag_log_buf_info_get_func_t)(hal_ecpu_diag_buf_info_t *buf_info);

typedef clx_error_no_t (*hal_ecpu_dtcm_addr_get_func_t)(uint64 *addr);

typedef clx_error_no_t (*hal_ecpu_dtcm_on_chain_addr_get_func_t)(uint64 *addr);

typedef clx_error_no_t (*hal_ecpu_itcm_addr_get_func_t)(uint64 *addr);

typedef clx_error_no_t (*hal_ecpu_itcm_on_chain_addr_get_func_t)(uint64 *addr);

typedef clx_error_no_t (*hal_ecpu_fw_feature_is_supported_func_t)(
    const uint32 unit,
    const clx_ecpu_fw_feature_type_t feature_type);

typedef clx_error_no_t (*hal_ecpu_fw_dflt_set_func_t)(const uint32 unit, const uint32 index);

typedef clx_error_no_t (*hal_ecpu_fw_dflt_get_func_t)(const uint32 unit,
                                                      uint32 *index,
                                                      const uint32 core);

typedef clx_error_no_t (*hal_ecpu_fw_running_get_func_t)(const uint32 unit,
                                                         uint32 *index,
                                                         const uint32 core);

typedef clx_error_no_t (*hal_ecpu_fw_info_trav_func_t)(const uint32 unit,
                                                       const clx_ecpu_fw_trav_func_t callback,
                                                       void *ptr_cookie);

typedef clx_error_no_t (*hal_ecpu_port_limit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_ring_buf_handler_init_func_t)(
    const uint32 unit,
    const uint32 core,
    hal_ecpu_ring_buffer_control_t *pring);

typedef clx_error_no_t (*hal_ecpu_core_num_get_func_t)(const uint32 unit, uint32 *pnum);

/* TOD multiplexing functions */
typedef clx_error_no_t (*hal_tod_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_tod_deinit_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_tod_hw_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_tod_intr_register_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_tod_intr_unregister_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_tod_pps_intr_restart_func_t)(const uint32 unit, void *ptr);
typedef clx_error_no_t (*hal_tod_current_value_get_func_t)(const uint32 unit, uint32 *buf);

/* BFD multiplexing functions */
typedef clx_error_no_t (*hal_bfd_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_bfd_deinit_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_bfd_session_create_func_t)(const uint32 unit,
                                                        clx_bfd_session_cfg_info_t *cfg_session);
typedef clx_error_no_t (*hal_bfd_session_delete_func_t)(const uint32 unit, const uint32 session_id);
typedef clx_error_no_t (*hal_bfd_session_update_func_t)(const uint32 unit,
                                                        clx_bfd_session_cfg_info_t *cfg_session);
typedef clx_error_no_t (*hal_bfd_all_session_delete_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_bfd_session_cfg_info_get_func_t)(
    const uint32 unit,
    const uint32 session_id,
    clx_bfd_session_cfg_info_t *cfg_session);
typedef clx_error_no_t (*hal_bfd_session_next_cfg_get_func_t)(
    const uint32 unit,
    const uint32 session_id,
    clx_bfd_session_cfg_info_t *cfg_session);
typedef clx_error_no_t (*hal_bfd_session_pkt_stats_get_func_t)(const uint32 unit,
                                                               const uint32 session_id,
                                                               clx_bfd_session_stats_t *stats);
typedef clx_error_no_t (*hal_bfd_session_drop_pkt_stats_get_func_t)(const uint32 unit,
                                                                    clx_bfd_drop_stats_t *stats);
typedef clx_error_no_t (*hal_bfd_session_pkt_stats_clear_func_t)(const uint32 unit,
                                                                 const uint32 session_id,
                                                                 const uint32 flags);
typedef clx_error_no_t (*hal_bfd_session_drop_pkt_stats_clear_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_bfd_session_status_get_func_t)(const uint32 unit,
                                                            const uint32 session_id,
                                                            clx_bfd_session_status_t *status);
typedef clx_error_no_t (*hal_bfd_session_poll_trigger_func_t)(const uint32 unit,
                                                              const uint32 session_id);
typedef clx_error_no_t (*hal_bfd_session_admin_set_func_t)(const uint32 unit,
                                                           const uint32 session_id,
                                                           const clx_bfd_admin_status_t status);
typedef clx_error_no_t (*hal_bfd_session_event_cb_register_func_t)(const uint32 unit,
                                                                   const clx_bfd_event_cb_t cb,
                                                                   void *ptr_cookie);
typedef clx_error_no_t (*hal_bfd_session_event_cb_unregister_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_intr_enable_set_func_t)(const uint32 unit,
                                                     const uint32 intr_type,
                                                     const boolean enable);

typedef clx_error_no_t (*hal_intr_enable_get_func_t)(const uint32 unit,
                                                     const uint32 intr_type,
                                                     boolean *ptr_enable);
typedef clx_error_no_t (*hal_d2d_ddc_status_get_func_t)(const uint32 unit,
                                                        const uint32 ddc_idx,
                                                        void *ptr_ddc_status); /* get ddc status */

typedef clx_error_no_t (*hal_d2d_ddc_fec_cnt_get_func_t)(const uint32 unit,
                                                         const uint32 ddc_idx,
                                                         const HAL_D2D_FEC_CNT_TYPE_T cnt_type,
                                                         void *ptr_ddc_status); /* get ddc fec cnt
                                                                                 */
/* misc multiplexing functions */

typedef clx_error_no_t (*hal_misc_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_misc_deinit_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_misc_cpu2jtag_init_func_t)(const uint32 unit, const uint32 inst);
typedef clx_error_no_t (*hal_misc_cpu2jtag_trst_toggle_func_t)(const uint32 unit,
                                                               const uint32 inst);
typedef clx_error_no_t (*hal_misc_cpu2jtag_ir_check_func_t)(const uint32 unit,
                                                            const uint32 inst,
                                                            const char *ir_val,
                                                            const uint32 ir_len);
typedef clx_error_no_t (*hal_misc_cpu2jtag_dr_check_func_t)(const uint32 unit,
                                                            const uint32 inst,
                                                            const char *dr_val,
                                                            const uint32 dr_len,
                                                            const char *exp_dr_val,
                                                            const uint32 exp_dr_len);

typedef clx_error_no_t (*hal_misc_efuse_read_func_t)(const uint32 unit,
                                                     const uint32 inst,
                                                     const hal_efuse_page_t page,
                                                     const uint32 addr,
                                                     uint32 *ptr_val);

typedef clx_error_no_t (*hal_misc_efuse_write_func_t)(const uint32 unit,
                                                      const uint32 inst,
                                                      const hal_efuse_page_t page,
                                                      const uint32 addr,
                                                      const uint32 bit_offset,
                                                      const uint32 bit_len,
                                                      const uint32 value);

typedef clx_error_no_t (*hal_misc_efuse_dump_func_t)(const uint32 unit, const uint32 inst);

typedef clx_error_no_t (*hal_misc_chip_temp_get_func_t)(const uint32 unit,
                                                        int32 *ptr_chip_temperature);

typedef clx_error_no_t (*hal_misc_chip_temp_list_get_func_t)(
    const uint32 unit,
    clx_swc_thermal_list_t *ptr_chip_temperature_list);

typedef clx_error_no_t (*hal_misc_pvt_calib_info_get_func_t)(
    const uint32 unit,
    const uint32 inst,
    clx_swc_pvt_calib_info_t *ptr_calib_info);

typedef clx_error_no_t (*hal_misc_mdio_clk_rate_set_func_t)(const uint32 unit,
                                                            const uint32 bus,
                                                            const uint32 rate_khz);

typedef clx_error_no_t (*hal_misc_mdio_reg_set_func_t)(const uint32 unit,
                                                       const uint32 port_id,
                                                       const hal_phy_type_t phy_type,
                                                       const uint32 dev_type,
                                                       const uint32 reg_addr,
                                                       const uint32 reg);

typedef clx_error_no_t (*hal_misc_mdio_reg_get_func_t)(const uint32 unit,
                                                       const uint32 port_id,
                                                       const hal_phy_type_t phy_type,
                                                       const uint32 dev_type,
                                                       const uint32 reg_addr,
                                                       uint32 *ptr_reg);

/* PTP multiplexing functions */
typedef clx_error_no_t (*hal_ptp_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_ptp_deinit_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_ptp_clk_create_func_t)(const uint32 unit,
                                                    const clx_ptp_clk_cfg_t *cfg);
typedef clx_error_no_t (*hal_ptp_clk_destroy_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_ptp_clk_cfg_set_func_t)(const uint32 unit,
                                                     const clx_ptp_clk_cfg_t *cfg);
typedef clx_error_no_t (*hal_ptp_clk_cfg_get_func_t)(const uint32 unit, clx_ptp_clk_cfg_t *cfg);
typedef clx_error_no_t (*hal_ptp_port_add_func_t)(const uint32 unit,
                                                  const uint32 port_id,
                                                  const clx_ptp_port_cfg_t *cfg);
typedef clx_error_no_t (*hal_ptp_port_del_func_t)(const uint32 unit, const uint32 port_id);
typedef clx_error_no_t (*hal_ptp_port_cfg_set_func_t)(const uint32 unit,
                                                      const uint32 port_id,
                                                      const clx_ptp_port_cfg_t *cfg);
typedef clx_error_no_t (*hal_ptp_port_cfg_get_func_t)(const uint32 unit,
                                                      const uint32 port_id,
                                                      clx_ptp_port_cfg_t *cfg);
typedef clx_error_no_t (*hal_ptp_port_cnt_get_func_t)(const uint32 unit,
                                                      const uint32 port_id,
                                                      clx_ptp_port_cnt_t *cnt);
typedef clx_error_no_t (*hal_ptp_port_cnt_clr_func_t)(const uint32 unit, const uint32 port_id);
typedef clx_error_no_t (*hal_ptp_clk_rslt_get_func_t)(const uint32 unit, clx_ptp_clk_rslt_t *rslt);
typedef clx_error_no_t (*hal_ptp_port_wire_delay_get_func_t)(const uint32 unit,
                                                             const uint32 port_id,
                                                             clx_ptp_port_wire_delay_t *delay);
typedef clx_error_no_t (*hal_ptp_mon_enable_func_t)(const uint32 unit,
                                                    const clx_ptp_mon_cfg_t *cfg);
typedef clx_error_no_t (*hal_ptp_mon_disable_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_ptp_mon_cfg_set_func_t)(const uint32 unit,
                                                     const clx_ptp_mon_cfg_t *cfg);
typedef clx_error_no_t (*hal_ptp_mon_cfg_get_func_t)(const uint32 unit, clx_ptp_mon_cfg_t *cfg);
typedef clx_error_no_t (*hal_ptp_mon_stat_get_func_t)(const uint32 unit, clx_ptp_mon_stat_t *stats);
typedef clx_error_no_t (*hal_ptp_mon_stat_clr_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_ptp_masters_get_func_t)(const uint32 unit,
                                                     clx_ptp_masters_info_t *masters);
typedef clx_error_no_t (*hal_ptp_port_state_get_func_t)(const uint32 unit,
                                                        const uint32 port_id,
                                                        clx_ptp_port_state_t *state);

/* nfe multiplexing functions */
typedef clx_error_no_t (*hal_nfe_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_nfe_deinit_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_nfe_hw_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_nfe_hw_deinit_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_nfe_prof_create_func_t)(const uint32 unit,
                                                     const clx_nfe_prof_cfg_info_t *ptr_nfe_info,
                                                     uint32 *ptr_nfe_prof_id);
typedef clx_error_no_t (*hal_nfe_prof_destroy_func_t)(const uint32 unit, const uint32 prof_id);
typedef clx_error_no_t (*hal_nfe_prof_set_func_t)(const uint32 unit,
                                                  const uint32 prof_id,
                                                  const clx_nfe_prof_cfg_info_t *ptr_nfe_info);
typedef clx_error_no_t (*hal_nfe_prof_get_func_t)(const uint32 unit,
                                                  const uint32 prof_id,
                                                  clx_nfe_prof_cfg_info_t *ptr_nfe_info);
typedef clx_error_no_t (*hal_nfe_aging_interval_set_func_t)(const uint32 unit,
                                                            const uint32 interval);
typedef clx_error_no_t (*hal_nfe_aging_interval_get_func_t)(const uint32 unit,
                                                            uint32 *ptr_interval);
typedef clx_error_no_t (*hal_nfe_aging_force_set_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_nfe_thd_set_func_t)(const uint32 unit,
                                                 const clx_nfe_dir_t dir,
                                                 const clx_nfe_thd_cfg_t *ptr_thd_cfg);

typedef clx_error_no_t (*hal_nfe_thd_get_func_t)(const uint32 unit,
                                                 const clx_nfe_dir_t dir,
                                                 clx_nfe_thd_cfg_t *ptr_thd_cfg);
typedef clx_error_no_t (*hal_nfe_scan_status_get_func_t)(const uint32 unit,
                                                         const uint32 slc,
                                                         const clx_nfe_dir_t dir,
                                                         boolean *ptr_is_done);
typedef clx_error_no_t (*hal_nfe_current_flow_cnt_get_func_t)(const uint32 unit,
                                                              const clx_nfe_dir_t dir,
                                                              uint32 *ptr_cnt);
typedef clx_error_no_t (*hal_nfe_current_flow_max_cnt_get_func_t)(const uint32 unit,
                                                                  const clx_nfe_dir_t dir,
                                                                  uint32 *ptr_cnt);
typedef clx_error_no_t (*hal_nfe_conflict_flow_cnt_get_func_t)(const uint32 unit,
                                                               const clx_nfe_dir_t dir,
                                                               uint32 *ptr_cnt);
typedef clx_error_no_t (*hal_nfe_conflict_flow_cnt_clr_func_t)(const uint32 unit,
                                                               const clx_nfe_dir_t dir);
typedef clx_error_no_t (*hal_nfe_flow_data_notify_cb_set_func_t)(
    const uint32 unit,
    const clx_nfe_flow_data_notify_func_t notify_func,
    void *ptr_cookie);
typedef clx_error_no_t (*hal_nfe_hw_aging_start_func_t)(const uint32 unit, const clx_nfe_dir_t dir);
typedef clx_error_no_t (*hal_nfe_hw_scan_done_intr_set_func_t)(const uint32 unit,
                                                               const uint32 slc,
                                                               const clx_nfe_dir_t dir,
                                                               const boolean enable);
typedef clx_error_no_t (*hal_nfe_hw_yellow_thd_intr_set_func_t)(const uint32 unit,
                                                                const uint32 slc,
                                                                const clx_nfe_dir_t dir,
                                                                const boolean enable);
typedef clx_error_no_t (*hal_nfe_hw_red_thd_intr_set_func_t)(const uint32 unit,
                                                             const uint32 slc,
                                                             const clx_nfe_dir_t dir,
                                                             const boolean enable);
typedef clx_error_no_t (*hal_nfe_hw_aging_stop_func_t)(const uint32 unit, const clx_nfe_dir_t dir);
typedef clx_error_no_t (*hal_nfe_hw_aging_2x_start_func_t)(const uint32 unit,
                                                           const clx_nfe_dir_t dir);
typedef clx_error_no_t (*hal_nfe_hw_force_aging_start_func_t)(const uint32 unit,
                                                              const clx_nfe_dir_t dir);
typedef clx_error_no_t (*hal_nfe_hw_force_aging_2x_start_func_t)(const uint32 unit,
                                                                 const clx_nfe_dir_t dir);
typedef clx_error_no_t (*hal_nfe_hw_prof_cfg_set_func_t)(
    const uint32 unit,
    const uint32 prof_id,
    const clx_nfe_prof_cfg_info_t *ptr_nfe_info);
typedef clx_error_no_t (*hal_nfe_hw_prof_dflt_set_func_t)(const uint32 unit,
                                                          const uint32 nfe_prof_id);
typedef clx_error_no_t (*hal_nfe_hw_thd_set_func_t)(const uint32 unit,
                                                    const clx_nfe_dir_t dir,
                                                    const clx_nfe_thd_cfg_t *ptr_thd_cfg);
typedef clx_error_no_t (*hal_nfe_hw_long_flow_interval_set_func_t)(const uint32 unit,
                                                                   const clx_nfe_dir_t dir,
                                                                   const uint32 interval);
typedef clx_error_no_t (*hal_nfe_prof_key_psr_proc_func_t)(
    const uint32 unit,
    const uint32 nfe_prof_id,
    const clx_nfe_prof_cfg_info_t *ptr_nfe_cfg);
typedef uint32 (*hal_nfe_flow_data_len_get_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_nfe_flow_data_psr_proc_func_t)(const uint32 unit,
                                                            const uint64_t src_addr,
                                                            const void *flow_data,
                                                            uint8 *dst_addr,
                                                            uint32 *dst_len);
typedef clx_error_no_t (*hal_nfe_prof_ref_func_t)(const uint32 unit, const uint32 nfe_prof_id);
typedef clx_error_no_t (*hal_nfe_prof_unref_func_t)(const uint32 unit, const uint32 nfe_prof_id);
typedef clx_error_no_t (*hal_nfe_hw_need_batch_process_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_nfe_hw_scan_start_func_t)(const uint32 unit, const clx_nfe_dir_t dir);
typedef clx_error_no_t (*hal_nfe_hw_scan_2x_start_func_t)(const uint32 unit,
                                                          const clx_nfe_dir_t dir);

/* Export multiplexing functions start */
typedef clx_error_no_t (*hal_export_arp_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_export_arp_deinit_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_export_arp_data_get_func_t)(const uint32 unit,
                                                         uint8_t flags,
                                                         void *ptr_cb);
typedef clx_error_no_t (*hal_export_mac_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_export_mac_deinit_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_export_mac_data_get_func_t)(const uint32 unit,
                                                         uint32_t mac_type,
                                                         void *ptr_cb);
typedef clx_error_no_t (*hal_export_route_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_export_route_deinit_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_export_route_data_get_func_t)(const uint32 unit,
                                                           void *ptr_cb,
                                                           uint32_t *flags);
typedef clx_error_no_t (*hal_export_route_l3_dst_idx_get_func_t)(const uint32 unit,
                                                                 const clx_port_t port,
                                                                 uint32 *ptr_di);
/* Export multiplexing functions end */

/* VM multiplexing functions start */

typedef clx_error_no_t (*hal_vm_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_vm_deinit_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_vm_mode_set_func_t)(const uint32 unit, const clx_vm_mode_t mode);
typedef clx_error_no_t (*hal_vm_mode_get_func_t)(const uint32 unit, clx_vm_mode_t *ptr_mode);
typedef clx_error_no_t (*clx_vm_port_create_func_t)(const uint32 unit,
                                                    const clx_vm_info_t *ptr_vm_info,
                                                    clx_port_t *ptr_vm_port);
typedef clx_error_no_t (*clx_vm_port_destroy_func_t)(const uint32 unit, clx_port_t vm_port);
typedef clx_error_no_t (*clx_vm_port_get_func_t)(const uint32 unit,
                                                 const clx_port_t vm_port,
                                                 clx_vm_info_t *ptr_vm_info);
typedef clx_error_no_t (*hal_vm_port_cfg_set_func_t)(const uint32 unit,
                                                     const clx_port_t port,
                                                     const clx_vm_port_cfg_t *ptr_port_cfg);
typedef clx_error_no_t (*hal_vm_port_cfg_get_func_t)(const uint32 unit,
                                                     const clx_port_t port,
                                                     clx_vm_port_cfg_t *ptr_port_cfg);
typedef clx_error_no_t (*hal_vm_pe_downstream_entry_add_func_t)(
    const uint32 unit,
    const clx_vm_pe_downstream_entry_t *ptr_entry);
typedef clx_error_no_t (*hal_vm_pe_downstream_entry_del_func_t)(
    const uint32 unit,
    const clx_vm_pe_downstream_entry_t *ptr_entry);
typedef clx_error_no_t (*hal_vm_pe_downstream_entry_get_func_t)(
    const uint32 unit,
    clx_vm_pe_downstream_entry_t *ptr_entry);
typedef clx_error_no_t (*hal_vm_pe_upstream_entry_add_func_t)(
    const uint32 unit,
    const clx_vm_pe_upstream_entry_t *ptr_entry);
typedef clx_error_no_t (*hal_vm_pe_upstream_entry_del_func_t)(
    const uint32 unit,
    const clx_vm_pe_upstream_entry_t *ptr_entry);
typedef clx_error_no_t (
    *hal_vm_pe_upstream_entry_get_func_t)(const uint32 unit, clx_vm_pe_upstream_entry_t *ptr_entry);
/* VM multiplexing functions end */

/* wlan multiplexing functions */
typedef clx_error_no_t (*hal_wlan_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_wlan_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_wlan_capwap_prof_add_func_t)(
    const uint32 unit,
    const uint32 id,
    const clx_wlan_capwap_prof_t *ptr_property);

typedef clx_error_no_t (*hal_wlan_capwap_prof_del_func_t)(const uint32 unit, const uint32 id);

typedef clx_error_no_t (*hal_wlan_capwap_prof_get_func_t)(const uint32 unit,
                                                          const uint32 id,
                                                          clx_wlan_capwap_prof_t *ptr_property);

typedef clx_error_no_t (*hal_wlan_port_create_func_t)(const uint32 unit,
                                                      const clx_wlan_capwap_t *ptr_capwap,
                                                      clx_port_t *ptr_port);

typedef clx_error_no_t (*hal_wlan_port_destroy_func_t)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*hal_wlan_port_get_func_t)(const uint32 unit,
                                                   const clx_wlan_capwap_t *ptr_capwap,
                                                   clx_port_t *ptr_port);

typedef clx_error_no_t (*hal_wlan_port_hdr_get_func_t)(const uint32 unit,
                                                       const clx_port_t port,
                                                       clx_wlan_capwap_t *ptr_capwap);

typedef clx_error_no_t (*hal_wlan_port_trav_func_t)(const uint32 unit,
                                                    const clx_wlan_port_trav_func_t cb,
                                                    void *ptr_cookie);

typedef clx_error_no_t (*hal_wlan_decap_add_func_t)(const uint32 unit,
                                                    const clx_port_t port,
                                                    const clx_tnl_decap_info_t *ptr_decap_info);

typedef clx_error_no_t (*hal_wlan_decap_del_func_t)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*hal_wlan_decap_get_func_t)(const uint32 unit,
                                                    const clx_port_t port,
                                                    clx_tnl_decap_info_t *ptr_decap_info);

typedef clx_error_no_t (*hal_wlan_decap_trav_func_t)(const uint32 unit,
                                                     const clx_wlan_decap_trav_func_t cb,
                                                     void *ptr_cookie);

typedef clx_error_no_t (*hal_wlan_encap_add_func_t)(const uint32 unit,
                                                    const clx_port_t port,
                                                    const clx_tnl_encap_info_t *ptr_encap_info);

typedef clx_error_no_t (*hal_wlan_encap_del_func_t)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*hal_wlan_encap_get_func_t)(const uint32 unit,
                                                    const clx_port_t port,
                                                    clx_tnl_encap_info_t *ptr_encap_info);

typedef clx_error_no_t (*hal_wlan_encap_trav_func_t)(const uint32 unit,
                                                     const clx_wlan_encap_trav_func_t cb,
                                                     void *ptr_cookie);

typedef clx_error_no_t (*hal_wlan_station_add_func_t)(const uint32 unit,
                                                      const clx_wlan_station_t *ptr_sta_mac);

typedef clx_error_no_t (*hal_wlan_station_del_func_t)(const uint32 unit,
                                                      const clx_wlan_station_t *ptr_sta_mac);

typedef clx_error_no_t (*hal_wlan_station_set_func_t)(const uint32 unit,
                                                      const clx_wlan_station_t *ptr_sta_mac);

typedef clx_error_no_t (*hal_wlan_station_get_func_t)(const uint32 unit,
                                                      clx_wlan_station_t *ptr_sta_mac);

typedef clx_error_no_t (*hal_wlan_station_trav_func_t)(const uint32 unit,
                                                       const clx_wlan_station_trav_func_t cb,
                                                       void *ptr_cookie);

typedef struct hal_drv_chip_func_vec_s {
    HAL_CHIP_MMIO_INIT_FUNC_T hal_chip_mmio_init;
    HAL_CHIP_INIT_FUNC_T hal_chip_init;
    HAL_CHIP_DEINIT_FUNC_T hal_chip_deinit;
} hal_drv_chip_func_vec_t;

typedef struct hal_drv_bd_func_vec_s {
    HAL_BD_INIT hal_bd_init;
    HAL_BD_DEINIT hal_bd_deinit;
    HAL_BD_CREATE hal_bd_create;
    HAL_BD_DESTROY hal_bd_destroy;
    HAL_BD_CFG_SET hal_bd_cfg_set;
    HAL_BD_CFG_GET hal_bd_cfg_get;
    HAL_BD_CREATED_PRINT hal_bd_created_bd_print;
    HAL_BD_CAPACITY_GET hal_bd_capacity_get;
    HAL_BD_USAGE_GET hal_bd_usage_get;
    hal_chip_cfg_info_get_func_t hal_bd_chip_cfg_info_get;
} hal_drv_bd_func_vec_t;

typedef struct hal_drv_vlan_func_vec_s {
    HAL_VLAN_INIT_FUNC_T hal_vlan_init;
    HAL_VLAN_DEINIT_FUNC_T hal_vlan_deinit;
    hal_dflt_port_default_set_func_t hal_vlan_port_dflt_set;
    hal_dflt_port_default_set_func_t hal_vlan_port_dflt_reset;
    HAL_VLAN_CREATE_FUNC_T hal_vlan_create;
    HAL_VLAN_DESTROY_FUNC_T hal_vlan_destroy;
    HAL_VLAN_PORT_GET_FUNC_T hal_vlan_port_get;
    HAL_VLAN_PORT_ADD_FUNC_T hal_vlan_port_add;
    HAL_VLAN_PORT_DEL_FUNC_T hal_vlan_port_del;
    HAL_VLAN_TAG_MODE_SET_FUNC_T hal_vlan_tag_mode_set;
    HAL_VLAN_TYPE_SET_FUNC_T hal_vlan_type_set;
    HAL_VLAN_TYPE_GET_FUNC_T hal_vlan_type_get;
    HAL_VLAN_PRIVATE_TPORT_ADD hal_vlan_private_tport_add;
    HAL_VLAN_PRIVATE_TPORT_DEL hal_vlan_private_tport_del;
    HAL_VLAN_PRIVATE_TPORT_GET hal_vlan_private_tport_get;
    HAL_VLAN_BD_BIND_FUNC_T hal_vlan_bd_bind;
    HAL_VLAN_BD_UNBIND_FUNC_T hal_vlan_bd_unbind;
    HAL_VLAN_BD_GET_FUNC_T hal_vlan_bd_get;
    HAL_VLAN_TRAV_FUNC_T hal_vlan_trav;
    HAL_VLAN_IGR_HSH_PRINT_FUNC_T hal_vlan_igr_hsh_print;
    HAL_VLAN_EGR_HSH_PRINT_FUNC_T hal_vlan_egr_hsh_print;
    hal_chip_cfg_info_get_func_t hal_vlan_chip_cfg_info_get;
    HAL_VLAN_EXT_TPID_ADD_FUNC_T hal_vlan_ext_tpid_add;
    HAL_VLAN_EXT_TPID_DEL_FUNC_T hal_vlan_ext_tpid_del;
    HAL_VLAN_EXT_TPID_GET_FUNC_T hal_vlan_ext_tpid_get;
    HAL_VLAN_MAC_VLAN_ADD_FUNC_T hal_vlan_mac_vlan_add;
    HAL_VLAN_MAC_VLAN_DEL_FUNC_T hal_vlan_mac_vlan_del;
    HAL_VLAN_MAC_VLAN_GET_FUNC_T hal_vlan_mac_vlan_get;
    HAL_VLAN_VLAN_CLASSIFY_PRIO_SET_FUNC_T hal_vlan_classify_prio_set;
    HAL_VLAN_VLAN_CLASSIFY_PRIO_GET_FUNC_T hal_vlan_classify_prio_get;
    HAL_VLAN_RANGE_MAPPING_SET_FUNC_T hal_vlan_range_mapping_set;
    HAL_VLAN_RANGE_MAPPING_GET_FUNC_T hal_vlan_range_mapping_get;
} hal_drv_vlan_func_vec_t;

typedef struct hal_drv_port_func_vec_s {
    hal_port_init_func_t hal_port_init;
    hal_port_deinit_func_t hal_port_deinit;
    hal_port_cfg_init_func_t hal_port_cfg_init;
    hal_dflt_port_default_set_func_t hal_port_default_set;
    hal_dflt_port_default_set_func_t hal_port_default_reset;
    hal_port_cfg_set_func_t hal_port_cfg_set;
    hal_port_cfg_get_func_t hal_port_cfg_get;
    hal_port_speed_set_func_t hal_port_speed_set;
    hal_port_speed_get_func_t hal_port_speed_get;
    hal_port_speed_list_get_func_t hal_port_speed_list_get;
    hal_port_flow_ctrl_set_func_t hal_port_flow_ctrl_set;
    hal_port_flow_ctrl_get_func_t hal_port_flow_ctrl_get;
    hal_port_pri_flow_ctrl_set_func_t hal_port_pri_flow_ctrl_set;
    hal_port_pri_flow_ctrl_get_func_t hal_port_pri_flow_ctrl_get;
    hal_port_eee_mode_set_func_t hal_port_eee_mode_set;
    hal_port_eee_mode_get_func_t hal_port_eee_mode_get;
    hal_port_local_adv_ability_set_func_t hal_port_local_adv_ability_set;
    hal_port_local_adv_ability_get_func_t hal_port_local_adv_ability_get;
    hal_port_remote_adv_ability_get_func_t hal_port_remote_adv_ability_get;
    hal_port_ability_get_func_t hal_port_ability_get;
    hal_port_loopback_set_func_t hal_port_loopback_set;
    hal_port_loopback_get_func_t hal_port_loopback_get;
    hal_port_probe_func_t hal_port_probe;
    hal_port_create_func_t hal_port_create;
    hal_port_ext_create_func_t hal_port_ext_create;
    hal_port_destroy_func_t hal_port_destroy;
    hal_port_mac_addr_set_func_t hal_port_mac_addr_set;
    hal_port_mac_addr_get_func_t hal_port_mac_addr_get;
    hal_port_link_get_func_t hal_port_link_get;
    hal_port_fault_get_func_t hal_port_fault_get;
    hal_port_medium_type_set_func_t hal_port_medium_type_set;
    hal_port_medium_type_get_func_t hal_port_medium_type_get;
    hal_port_phy_cfg_set_func_t hal_port_phy_cfg_set;
    hal_port_phy_cfg_get_func_t hal_port_phy_cfg_get;
    hal_port_lane_map_set_func_t hal_port_lane_map_set;
    hal_port_lane_map_get_func_t hal_port_lane_map_get;
    hal_port_vlan_bd_bind_func_t hal_port_vlan_bd_bind;
    hal_port_vlan_bd_unbind_func_t hal_port_vlan_bd_unbind;
    hal_port_vlan_bd_get_func_t hal_port_vlan_bd_get;
    hal_port_gport_create_func_t hal_port_gport_create;
    hal_port_gport_destroy_func_t hal_port_gport_destroy;
    hal_port_intf_cfg_set_func_t hal_port_intf_cfg_set;
    hal_port_intf_cfg_get_func_t hal_port_intf_cfg_get;
    hal_port_ts_tx_entry_get_func_t hal_port_ts_tx_entry_get;
    hal_port_ts_rx_entry_get_func_t hal_port_ts_rx_entry_get;
    hal_port_type_get_func_t hal_port_port_type_get;
    hal_port_status_get_func_t hal_port_status_get;
    hal_db_dump_func_t hal_port_db_dump;
    hal_port_port_to_gport_func_t hal_port_port_to_gport_trans;
    hal_port_tx_coef_set_func_t hal_port_tx_coef_set;
    hal_port_tx_coef_get_func_t hal_port_tx_coef_get;
    hal_port_vlan_tag_ctrl_get_func_t hal_port_vlan_tag_ctrl_get;
    hal_port_vlan_tag_ctrl_set_func_t hal_port_vlan_tag_ctrl_set;
    hal_port_gport_to_port_func_t hal_port_gport_to_port_trans;
    hal_port_mac_rxidle_set_func_t hal_port_mac_rxidle_set;
    hal_port_egr_high_latency_threshold_set_func_t hal_port_egr_high_latency_threshold_set;
    hal_port_egr_high_latency_threshold_get_func_t hal_port_egr_high_latency_threshold_get;
    hal_port_mburst_cfg_set_func_t hal_port_mburst_cfg_set;
    hal_port_mburst_cfg_get_func_t hal_port_mburst_cfg_get;
    hal_port_mburst_stat_get_func_t hal_port_mburst_stat_get;
    hal_port_mburst_hist_cnt_get_func_t hal_port_mburst_hist_cnt_get;
    hal_port_mburst_cnt_clear_func_t hal_port_mburst_cnt_clear;
    hal_port_fec_clear_func_t hal_port_fec_clear;
    hal_port_xoff_status_get_func_t hal_port_xoff_status_get;
    hal_port_dbg_info_show_func_t hal_port_dbg_info_show;
    hal_port_tx_signal_register_func_t hal_port_tx_signal_register;
    hal_port_tx_state_set_func_t hal_port_tx_state_set;
    hal_port_pkt_drop_set_func_t hal_port_pkt_drop_set;
    HAL_PORT_DI_SET_FUNC_T hal_port_di_set;
    hal_port_tc2q_map_set_func_t hal_port_tc2q_map_set;
    hal_port_tc2q_map_get_func_t hal_port_tc2q_map_get;
    hal_port_egress_xoff_mask_port_pltc_set_func_t hal_port_egress_xoff_mask_port_pltc_set;
    hal_port_q2tc_map_get_func_t hal_port_q2tc_map_get;
    hal_port_q2tc_map_set_func_t hal_port_q2tc_map_set;
    hal_port_ingress_fc_mode_get_func_t hal_port_ingress_fc_mode_get;
    hal_port_ingress_dscp_pltc_map_set_func_t hal_port_ingress_dscp_pltc_map_set;
    hal_port_ingress_dscp_pltc_map_get_func_t hal_port_ingress_dscp_pltc_map_get;
    hal_port_ingress_vlan_pltc_map_get_func_t hal_port_ingress_vlan_pltc_map_get;
    hal_port_ingress_vlan_pltc_map_set_func_t hal_port_ingress_vlan_pltc_map_set;
    hal_port_ingress_exp_pltc_map_get_func_t hal_port_ingress_exp_pltc_map_get;
    hal_port_ingress_exp_pltc_map_set_func_t hal_port_ingress_exp_pltc_map_set;
    hal_port_dead_lock_set_func_t hal_port_dead_lock_set;
    hal_port_dead_lock_th_set_func_t hal_port_dead_lock_th_set;
    hal_port_egress_que_flush_en_set_func_t hal_port_egress_que_flush_en_set;
    hal_port_egress_flow_ctrl_ignore_set_func_t hal_port_egress_flow_ctrl_ignore_set;
    hal_port_reset_portlist_update_func_t hal_port_reset_portlist_update;
    hal_port_laneswap_deinit_func_t hal_port_laneswap_deinit;
    hal_port_synce_process_func_t hal_port_synce_process;
    hal_port_intf_obj_vlan_act_add_func_t hal_port_intf_obj_vlan_act_add;
    hal_port_intf_obj_vlan_act_del_func_t hal_port_intf_obj_vlan_act_del;
    hal_port_intf_obj_vlan_act_update_func_t hal_port_intf_obj_vlan_act_update;
    hal_port_intf_obj_vlan_act_get_func_t hal_port_intf_obj_vlan_act_get;
    hal_port_intf_obj_bd_bind_func_t hal_port_intf_obj_bd_bind;
    hal_port_intf_obj_bd_unbind_func_t hal_port_intf_obj_bd_unbind;
    hal_port_intf_obj_bd_get_func_t hal_port_intf_obj_bd_get;
} hal_drv_port_func_vec_t;

typedef struct hal_drv_ifmon_func_vec_s {
    hal_ifmon_init_func_t hal_ifmon_init;
    hal_ifmon_deinit_func_t hal_ifmon_deinit;
    hal_dflt_port_default_set_func_t hal_ifmon_port_default_set;
    hal_dflt_port_default_set_func_t hal_ifmon_port_default_reset;
    hal_ifmon_register_func_t hal_ifmon_register;
    hal_ifmon_deregister_func_t hal_ifmon_deregister;
    hal_ifmon_mode_get_func_t hal_ifmon_mode_get;
    hal_ifmon_mode_set_func_t hal_ifmon_mode_set;
    hal_ifmon_monitor_state_set_func_t hal_ifmon_monitor_state_set;
    hal_ifmon_monitor_state_get_func_t hal_ifmon_monitor_state_get;
    hal_db_dump_func_t hal_ifmon_db_dump;
    hal_ifmon_callback_cnt_get_func_t hal_ifmon_callback_cnt_get;
    hal_ifmon_data_lock_func_t hal_ifmon_data_lock;
    hal_ifmon_data_unlock_func_t hal_ifmon_data_unlock;
    hal_ifmon_flow_lock_func_t hal_ifmon_flow_lock;
    hal_ifmon_flow_unlock_func_t hal_ifmon_flow_unlock;
    hal_ifmon_link_get_func_t hal_ifmon_link_get;
    hal_ifmon_link_fault_get_func_t hal_ifmon_link_fault_get;
    hal_ifmon_link_irq_en_set_func_t hal_ifmon_link_irq_en_set;
    hal_ifmon_link_irq_clear_func_t hal_ifmon_link_irq_clear;
    hal_ifmon_irq_get_func_t hal_ifmon_irq_get;
    hal_ifmon_sw_fault_get_func_t hal_ifmon_sw_fault_get;
    hal_ifmon_speed_get_func_t hal_ifmon_speed_get;
    hal_ifmon_port_mon_add_func_t hal_ifmon_port_mon_add;
    hal_ifmon_port_mon_get_func_t hal_ifmon_port_mon_get;
    hal_ifmon_port_mon_del_func_t hal_ifmon_port_mon_del;
    hal_ifmon_anlt_mon_add_func_t hal_ifmon_anlt_mon_add;
    hal_ifmon_anlt_mon_get_func_t hal_ifmon_anlt_mon_get;
    hal_ifmon_anlt_mon_del_func_t hal_ifmon_anlt_mon_del;
    hal_ifmon_anlt_process_func_t hal_ifmon_anlt_process;
    hal_ifmon_anlt_fsm_process_func_t hal_ifmon_anlt_fsm_process;
    hal_ifmon_temp_protect_process_func_t hal_ifmon_temp_protect_process;
    hal_ifmon_anlt_fsm_hang_cnt_get_func_t hal_ifmon_anlt_fsm_hang_cnt_get;
    hal_ifmon_eqbk_hang_process_func_t hal_ifmon_eqbk_hang_process;
    hal_ifmon_an_intr_set_func_t hal_ifmon_an_intr_set;
    hal_ifmon_an_intr_stat_get_func_t hal_ifmon_an_intr_stat_get;
    hal_ifmon_time_record_func_t hal_ifmon_time_record;
    hal_ifmon_sw_state_update_func_t hal_ifmon_sw_state_update;
    hal_ifmon_link_state_dump_func_t hal_ifmon_link_state_dump;
    hal_ifmon_led_speed_set_func_t hal_ifmon_led_speed_set;
    hal_ifmon_lt_fail_mon_add_func_t hal_ifmon_lt_fail_mon_add;
    hal_ifmon_lt_fail_mon_get_func_t hal_ifmon_lt_fail_mon_get;
    hal_ifmon_lt_fail_mon_del_func_t hal_ifmon_lt_fail_mon_del;
    hal_ifmon_lt_fail_intr_set_func_t hal_ifmon_lt_fail_intr_set;
    hal_ifmon_lt_fail_intr_get_func_t hal_ifmon_lt_fail_intr_get;
    hal_ifmon_lt_fail_process_func_t hal_ifmon_lt_fail_process;
} hal_drv_ifmon_func_vec_t;

typedef struct hal_drv_l2_func_vec_s {
    hal_l2_init_func_t hal_l2_init;
    hal_l2_deinit_func_t hal_l2_deinit;
    hal_dflt_port_default_set_func_t hal_l2_setPortDefault;
    hal_dflt_port_default_set_func_t hal_l2_resetPortDefault;
    hal_l2_addr_add_func_t hal_l2_addr_add;
    hal_l2_addr_del_func_t hal_l2_addr_del;
    hal_l2_addr_get_func_t hal_l2_addr_get;
    hal_l2_addr_flush_func_t hal_l2_addr_flush;
    hal_l2_addr_replace_func_t hal_l2_addr_replace;
    hal_l2_addr_trav_func_t hal_l2_addr_trav;
    hal_l2_addr_trav_sw_func_t hal_l2_sw_addr_trav;
    hal_l2_addr_notify_cb_register_func_t hal_l2_addr_notify_cb_register;
    hal_l2_addr_notify_cb_deregister_func_t hal_l2_addr_notify_cb_deregister;
    hal_l2_addr_sw_learn_cb_register_func_t hal_l2_addr_sw_learn_cb_register;
    hal_l2_addr_sw_learn_cb_deregister_func_t hal_l2_addr_sw_learn_cb_deregister;
    hal_l2_age_status_get_func_t hal_l2_age_status_get;
    hal_l2_mcast_grp_create_func_t hal_l2_mcast_grp_create;
    hal_l2_mcast_grp_destroy_func_t hal_l2_mcast_grp_destroy;
    hal_l2_mcast_intf_pbmp_get_func_t hal_l2_mcast_intf_pbmp_get;
    hal_l2_mcast_egr_intf_add_func_t hal_l2_mcast_egr_intf_add;
    hal_l2_mcast_egr_intf_del_func_t hal_l2_mcast_egr_intf_del;
    hal_l2_mcast_egr_intf_cnt_get_func_t hal_l2_mcast_egr_intf_cnt_get;
    hal_l2_mcast_egr_intf_get_func_t hal_l2_mcast_egr_intf_get;
    hal_l2_mcast_egr_intf_cnt_with_match_get_func_t hal_l2_mcast_egr_intf_cnt_with_match_get;
    hal_l2_mcast_egr_intf_with_match_get_func_t hal_l2_mcast_egr_intf_with_match_get;
    hal_l2_mcast_egr_intf_check_func_t hal_l2_mcast_egr_intf_check;
    hal_l2_mcast_addr_add_func_t hal_l2_mcast_addr_add;
    hal_l2_mcast_addr_del_func_t hal_l2_mcast_addr_del;
    hal_l2_mcast_addr_get_func_t hal_l2_mcast_addr_get;
    hal_l2_mcast_addr_trav_func_t hal_l2_mcast_addr_trav;
    hal_l2_sw_mcast_addr_trav_func_t hal_l2_sw_mcast_addr_trav;
    hal_l2_capacity_get_func_t hal_l2_capacity_get;
    hal_l2_usage_get_func_t hal_l2_usage_get;
    hal_l2_aging_time_set_func_t hal_l2_aging_time_set;
    hal_l2_aging_time_get_func_t hal_l2_aging_time_get;
    hal_l2_sa_move_action_set_func_t hal_l2_sa_move_action_set;
    hal_l2_sa_move_action_get_func_t hal_l2_sa_move_action_get;
    hal_l2_sa_miss_action_set_func_t hal_l2_sa_miss_action_set;
    hal_l2_sa_miss_action_get_func_t hal_l2_sa_miss_action_get;
    hal_db_dump_func_t hal_l2_db_dump;
    hal_l2_mcast_id_print_func_t hal_l2_mcast_id_print;
    hal_l2_mcast_grp_info_print_func_t hal_l2_mcast_grp_info_print;
    hal_l2_mcast_lag_mbr_update_func_t hal_l2_mcast_lag_mbr_update;
    hal_l2_mcast_lag_del_func_t hal_l2_mcast_lag_del;
    hal_l2_ecmp_grp_add_func_t hal_l2_ecmp_grp_add;
    hal_l2_ecmp_grp_del_func_t hal_l2_ecmp_grp_del;
    hal_l2_ecmp_grp_get_func_t hal_l2_ecmp_grp_get;
    hal_l2_ecmp_path_add_func_t hal_l2_ecmp_path_add;
    hal_l2_ecmp_path_del_func_t hal_l2_ecmp_path_del;
    hal_l2_ecmp_path_get_by_idx_func_t hal_l2_ecmp_path_get_by_idx;
    hal_l2_ecmp_path_hsh_set_func_t hal_l2_ecmp_path_hsh_set;
    hal_l2_ecmp_path_hsh_get_func_t hal_l2_ecmp_path_hsh_get;
    hal_l2_grp_path_list_dump_func_t hal_l2_grp_path_list_dump;
    hal_l2_multi_mcast_grp_create_func_t hal_l2_multi_mcast_grp_create;
    hal_chip_cfg_info_get_func_t hal_l2_chip_cfg_info_get;
} hal_drv_l2_func_vec_t;

typedef struct hal_drv_mir_func_vec_s {
    hal_mir_init_func_t hal_mir_init;
    hal_mir_deinit_func_t hal_mir_deinit;
    hal_mir_session_add_func_t hal_mir_session_add;
    hal_mir_session_del_func_t hal_mir_session_del;
    hal_mir_session_get_func_t hal_mir_session_get;
    hal_mir_erspan_decap_add_func_t hal_mir_erspan_decap_add;
    hal_mir_erspan_decap_del_func_t hal_mir_erspan_decap_del;
    hal_mir_erspan_decap_get_func_t hal_mir_erspan_decap_get;
    hal_mir_erspan_decap_trav_func_t hal_mir_erspan_decap_trav;
    hal_mir_selective_flow_mir_set_func_t hal_mir_selective_flow_mir_set;
    hal_mir_selective_flow_mir_get_func_t hal_mir_selective_flow_mir_get;
    hal_mir_global_param_set_func_t hal_mir_global_param_set;
    hal_mir_global_param_get_func_t hal_mir_global_param_get;
} hal_drv_mir_func_vec_t;

typedef struct hal_drv_l3_func_vec_s {
    hal_l3_init_func_t hal_l3_init;
    hal_l3_deinit_func_t hal_l3_deinit;
    hal_l3_intf_add_func_t hal_l3_intf_add;
    hal_l3_intf_del_func_t hal_l3_intf_del;
    hal_l3_intf_get_func_t hal_l3_intf_get;
    hal_l3_intf_trav_func_t hal_l3_intf_trav;
    hal_l3_rmac_add_func_t hal_l3_rmac_add;
    hal_l3_rmac_del_func_t hal_l3_rmac_del;
    hal_l3_rmac_get_func_t hal_l3_rmac_get;
    hal_l3_rmac_trav_func_t hal_l3_rmac_trav;
    hal_l3_adj_add_func_t hal_l3_adj_add;
    hal_l3_adj_del_func_t hal_l3_adj_del;
    hal_l3_adj_get_func_t hal_l3_adj_get;
    hal_l3_adj_trav_func_t hal_l3_adj_trav;
    hal_l3_host_add_func_t hal_l3_host_add;
    hal_l3_host_del_func_t hal_l3_host_del;
    hal_l3_host_get_func_t hal_l3_host_get;
    hal_l3_host_trav_func_t hal_l3_host_trav;
    hal_l3_host_flush_func_t hal_l3_host_flush;
    hal_l3_subnet_bcast_add_func_t hal_l3_subnet_bcast_add;
    hal_l3_subnet_bcast_del_func_t hal_l3_subnet_bcast_del;
    hal_l3_subnet_bcast_get_func_t hal_l3_subnet_bcast_get;
    hal_l3_subnet_bcast_trav_func_t hal_l3_subnet_bcast_trav;
    hal_l3_route_add_func_t hal_l3_route_add;
    hal_l3_route_del_func_t hal_l3_route_del;
    hal_l3_route_get_func_t hal_l3_route_get;
    hal_l3_route_trav_func_t hal_l3_route_trav;
    hal_l3_bulk_route_add_func_t hal_l3_bulk_route_add;
    hal_l3_bulk_route_del_func_t hal_l3_bulk_route_del;
    hal_l3_bulk_route_get_func_t hal_l3_bulk_route_get;
    hal_l3_route_usage_get_func_t hal_l3_route_usage_get;
    hal_l3_bulk_route_dump_func_t hal_l3_bulk_route_dump;
    hal_l3_ecmp_grp_add_func_t hal_l3_ecmp_grp_add;
    hal_l3_ecmp_grp_del_func_t hal_l3_ecmp_grp_del;
    hal_l3_ecmp_grp_get_func_t hal_l3_ecmp_grp_get;
    hal_l3_ecmp_grp_trav_func_t hal_l3_ecmp_grp_trav;
    hal_l3_ecmp_grp_sync_func_t hal_l3_ecmp_grp_sync;
    hal_l3_ecmp_path_add_func_t hal_l3_ecmp_path_add;
    hal_l3_ecmp_path_del_func_t hal_l3_ecmp_path_del;
    hal_l3_ecmp_path_get_by_idx_func_t hal_l3_ecmp_path_get_by_idx;
    hal_l3_ecmp_path_hsh_set_func_t hal_l3_ecmp_path_hsh_set;
    hal_l3_ecmp_path_hsh_get_func_t hal_l3_ecmp_path_hsh_get;
    hal_l3_ecmp_path_list_set_func_t hal_l3_ecmp_path_list_set;
    hal_l3_ecmp_path_list_get_func_t hal_l3_ecmp_path_list_get;
    hal_l3_ecmp_all_path_list_get_func_t hal_l3_ecmp_all_path_list_get;
    hal_l3_vrf_set_func_t hal_l3_vrf_set;
    hal_l3_vrf_get_func_t hal_l3_vrf_get;
    hal_l3_mcast_grp_create_func_t hal_l3_mcast_grp_create;
    hal_l3_mcast_grp_destroy_func_t hal_l3_mcast_grp_destroy;
    hal_l3_mcast_port_bmp_get_func_t hal_l3_mcast_port_bmp_get;
    hal_l3_mcast_route_add_func_t hal_l3_mcast_route_add;
    hal_l3_mcast_route_del_func_t hal_l3_mcast_route_del;
    hal_l3_mcast_route_get_func_t hal_l3_mcast_route_get;
    hal_l3_mcast_egr_intf_add_func_t hal_l3_mcast_egr_intf_add;
    hal_l3_mcast_egr_intf_del_func_t hal_l3_mcast_egr_intf_del;
    hal_l3_mcast_egr_intf_set_func_t hal_l3_mcast_egr_intf_set;
    hal_l3_mcast_egr_intf_cnt_get_func_t hal_l3_mcast_egr_intf_cnt_get;
    hal_l3_mcast_egr_intf_get_func_t hal_l3_mcast_egr_intf_get;
    hal_l3_mcast_df_intf_add_func_t hal_l3_mcast_df_intf_add;
    hal_l3_mcast_df_intf_del_func_t hal_l3_mcast_df_intf_del;
    hal_l3_mcast_df_intf_get_func_t hal_l3_mcast_df_intf_get;
    hal_l3_mcast_route_trav_func_t hal_l3_mcast_route_trav;
    hal_l3_frr_create_func_t hal_l3_frr_create;
    hal_l3_frr_destroy_func_t hal_l3_frr_destroy;
    hal_l3_frr_path_add_func_t hal_l3_frr_path_add;
    hal_l3_frr_path_del_func_t hal_l3_frr_path_del;
    hal_l3_frr_state_set_func_t hal_l3_frr_state_set;
    hal_l3_frr_state_get_func_t hal_l3_frr_state_get;
    hal_db_dump_func_t hal_l3_db_dump;
#if 0
    HAL_L3_ADDFDLECMPGROUP_FUNC_T hal_l3_addFdlEcmpGroup;
    HAL_L3_DELFDLECMPGROUP_FUNC_T hal_l3_delFdlEcmpGroup;
    HAL_L3_GETFDLECMPGROUP_FUNC_T hal_l3_getFdlEcmpGroup;
#endif
    hal_l3_ecmp_path_hsh_calc_func_t hal_l3_ecmp_path_hsh_calc;
    hal_l3_ecmp_path_list_dump_func_t hal_l3_ecmp_path_list_dump;
    hal_l3_ecmp_fdl_get_func_t hal_l3_ecmp_fdl_get;
    hal_l3_ecmp_fdl_add_func_t hal_l3_ecmp_fdl_add;
    hal_l3_ecmp_fdl_del_func_t hal_l3_ecmp_fdl_del;
    hal_l3_ecmp_ar_get_func_t hal_l3_ecmp_ar_get;
    hal_l3_ecmp_ar_add_func_t hal_l3_ecmp_ar_add;
    hal_l3_ecmp_ar_del_func_t hal_l3_ecmp_ar_del;
} hal_drv_l3_func_vec_t;

typedef struct hal_drv_tnl_func_vec_s {
    hal_tnl_init_func_t hal_tnl_init;
    hal_tnl_deinit_func_t hal_tnl_deinit;
    hal_dflt_port_default_set_func_t hal_tnl_port_dflt_set;
    hal_dflt_port_default_set_func_t hal_tnl_resetPortDefault;
    hal_tnl_mac_add_func_t hal_tnl_mac_add;
    hal_tnl_mac_del_func_t hal_tnl_mac_del;
    hal_tnl_mac_get_func_t hal_tnl_mac_get;
    hal_tnl_mac_trav_func_t hal_tnl_mac_trav;
    hal_tnl_entry_encap_add_func_t hal_tnl_entry_encap_add;
    hal_tnl_entry_encap_del_func_t hal_tnl_entry_encap_del;
    hal_tnl_entry_encap_get_func_t hal_tnl_entry_encap_get;
    hal_tnl_entry_encap_trav_func_t hal_tnl_entry_encap_trav;
    hal_tnl_entry_decap_add_func_t hal_tnl_entry_decap_add;
    hal_tnl_entry_decap_del_func_t hal_tnl_entry_decap_del;
    hal_tnl_entry_decap_get_func_t hal_tnl_entry_decap_get;
    hal_tnl_entry_decap_trav_func_t hal_tnl_entry_decap_trav;
    hal_tnl_nvo3_route_add_func_t hal_tnl_nvo3_route_add;
    hal_tnl_nvo3_route_del_func_t hal_tnl_nvo3_route_del;
    hal_tnl_nvo3_route_get_func_t hal_tnl_nvo3_route_get;
    hal_tnl_nvo3_route_trav_func_t hal_tnl_nvo3_route_trav;
    hal_tnl_port_create_func_t hal_tnl_port_create;
    hal_tnl_port_destroy_func_t hal_tnl_port_destroy;
    hal_tnl_port_get_func_t hal_tnl_port_get;
    hal_tnl_info_get_func_t hal_tnl_info_get;
    hal_tnl_entry_trav_func_t hal_tnl_entry_trav;
    hal_tnl_flex_tnl_add_func_t hal_tnl_flex_tnl_add;
    hal_tnl_flex_tnl_del_func_t hal_tnl_flex_tnl_del;
    hal_tnl_flex_tnl_get_func_t hal_tnl_flex_tnl_get;
    hal_tnl_flex_tnl_udf_set_func_t hal_tnl_flex_tnl_udf_set;
    hal_tnl_flex_tnl_udf_get_func_t hal_tnl_flex_tnl_udf_get;
    hal_tnl_phy_port_set_func_t hal_tnl_phy_port_set;
    hal_tnl_phy_port_get_func_t hal_tnl_phy_port_get;
    hal_tnl_es_grp_create_func_t hal_tnl_es_grp_create;
    hal_tnl_es_grp_destroy_func_t hal_tnl_es_grp_destroy;
    hal_tnl_es_grp_mbr_add_func_t hal_tnl_es_grp_mbr_add;
    hal_tnl_es_grp_mbr_del_func_t hal_tnl_es_grp_mbr_del;
    hal_tnl_es_grp_mbr_get_func_t hal_tnl_es_grp_mbr_get;
    hal_tnl_seg_srv_add_func_t hal_tnl_seg_srv_add;
    hal_tnl_seg_srv_del_func_t hal_tnl_seg_srv_del;
    hal_tnl_seg_srv_get_func_t hal_tnl_seg_srv_get;
    hal_db_dump_func_t hal_tnl_db_dump;
} hal_drv_tnl_func_vec_t;

typedef struct hal_drv_srv6_func_vec_s {
    hal_srv6_init_func_t hal_srv6_init;
    hal_srv6_deinit_func_t hal_srv6_deinit;
    hal_dflt_port_default_set_func_t hal_srv6_port_dflt_set;
    hal_dflt_port_default_set_func_t hal_srv6_resetPortDefault;
    hal_srv6_port_create_func_t hal_srv6_port_create;
    hal_srv6_port_destroy_func_t hal_srv6_port_destroy;
    hal_srv6_port_trav_func_t hal_srv6_port_trav;
    hal_srv6_local_add_func_t hal_srv6_local_add;
    hal_srv6_local_del_func_t hal_srv6_local_del;
    hal_srv6_local_set_func_t hal_srv6_local_set;
    hal_srv6_local_get_func_t hal_srv6_local_get;
    hal_srv6_local_trav_func_t hal_srv6_local_trav;
    hal_srv6_encap_add_func_t hal_srv6_encap_add;
    hal_srv6_encap_del_func_t hal_srv6_encap_del;
    hal_srv6_encap_set_func_t hal_srv6_encap_set;
    hal_srv6_encap_get_func_t hal_srv6_encap_get;
    hal_srv6_encap_trav_func_t hal_srv6_encap_trav;
    hal_srv6_mysid_entry_add_func_t hal_srv6_mysid_entry_add;
    hal_srv6_mysid_entry_del_func_t hal_srv6_mysid_entry_del;
    hal_srv6_mysid_entry_set_func_t hal_srv6_mysid_entry_set;
    hal_srv6_mysid_entry_get_func_t hal_srv6_mysid_entry_get;
    hal_srv6_mysid_entry_trav_func_t hal_srv6_mysid_entry_trav;
    hal_srv6_nvo3_route_add_func_t hal_srv6_nvo3_route_add;
    hal_srv6_nvo3_route_set_func_t hal_srv6_nvo3_route_set;
    hal_srv6_nvo3_route_del_func_t hal_srv6_nvo3_route_del;
    hal_srv6_nvo3_route_get_func_t hal_srv6_nvo3_route_get;
    hal_srv6_nvo3_route_trav_func_t hal_srv6_nvo3_route_trav;
    hal_srv6_endpoint_policy_add_func_t hal_srv6_endpoint_policy_add;
    hal_srv6_endpoint_policy_del_func_t hal_srv6_endpoint_policy_del;
    hal_srv6_endpoint_policy_set_func_t hal_srv6_endpoint_policy_set;
    hal_srv6_endpoint_policy_get_func_t hal_srv6_endpoint_policy_get;
    hal_srv6_endpoint_policy_trav_func_t hal_srv6_endpoint_policy_trav;
    hal_srv6_property_set_func_t hal_srv6_property_set;
    hal_srv6_property_get_func_t hal_srv6_property_get;
    hal_srv6_seg_srv_add_func_t hal_srv6_seg_srv_add;
    hal_srv6_seg_srv_del_func_t hal_srv6_seg_srv_del;
    hal_srv6_seg_srv_set_func_t hal_srv6_seg_srv_set;
    hal_srv6_seg_srv_get_func_t hal_srv6_seg_srv_get;
    hal_srv6_hash_action_set_func_t hal_srv6_hash_action_set;
    hal_srv6_hash_action_get_func_t hal_srv6_hash_action_get;
    hal_srv6_srv_sid_add_func_t hal_srv6_srv_sid_add;
    hal_srv6_srv_sid_del_func_t hal_srv6_srv_sid_del;
    hal_srv6_srv_sid_set_func_t hal_srv6_srv_sid_set;
    hal_srv6_srv_sid_get_func_t hal_srv6_srv_sid_get;
    hal_db_dump_func_t hal_srv6_db_dump;
} hal_drv_srv6_func_vec_t;

typedef struct hal_drv_pkt_func_vec_s {
    hal_pkt_init_func_t hal_pkt_init;
    hal_pkt_deinit_func_t hal_pkt_deinit;
    hal_dflt_port_default_set_func_t hal_pkt_port_default_set;
    hal_dflt_port_default_set_func_t hal_pkt_port_default_reset;
    hal_pkt_rx_init_func_t hal_pkt_rx_init;
    hal_pkt_rx_deinit_func_t hal_pkt_rx_deinit;
    hal_pkt_rx_cb_func_t hal_pkt_rx_cb;
    hal_pkt_tx_send_func_t hal_pkt_tx_send;
    hal_pkt_tx_prepare_func_t hal_pkt_tx_prepare;
    hal_pkt_ctrl_to_cpu_entry_set_func_t hal_pkt_ctrl_to_cpu_entry_set;
    hal_pkt_ctrl_to_cpu_entry_get_func_t hal_pkt_ctrl_to_cpu_entry_get;
    hal_pkt_ctrl_to_cpu_entry_all_clear_func_t hal_pkt_ctrl_to_cpu_entry_all_clear;
    hal_pkt_tx_cnt_get_func_t hal_pkt_tx_cnt_get;
    hal_pkt_rx_cnt_get_func_t hal_pkt_rx_cnt_get;
    hal_pkt_tx_cnt_clear_func_t hal_pkt_tx_cnt_clear;
    hal_pkt_rx_cnt_clear_func_t hal_pkt_rx_cnt_clear;
    hal_pkt_intf_create_func_t hal_pkt_intf_create;
    hal_pkt_intf_destroy_func_t hal_pkt_intf_destroy;
    hal_pkt_intf_get_func_t hal_pkt_intf_get;
    hal_pkt_intf_set_func_t hal_pkt_intf_set;
    hal_pkt_prof_create_func_t hal_pkt_prof_create;
    hal_pkt_prof_destroy_func_t hal_pkt_prof_destroy;
    hal_pkt_prof_get_func_t hal_pkt_prof_get;
    hal_pkt_intf_cnt_get_func_t hal_pkt_intf_cnt_get;
    hal_pkt_intf_cnt_clear_func_t hal_pkt_intf_cnt_clear;
    hal_pkt_tx_dbg_cnt_show_func_t hal_pkt_tx_dbg_cnt_show;
    hal_pkt_rx_dbg_cnt_show_func_t hal_pkt_rx_dbg_cnt_show;
    hal_db_dump_func_t hal_pkt_db_dump;
    hal_reg_dump_func_t hal_pkt_reg_dump;
    hal_pkt_reg_show_func_t hal_pkt_reg_show;
    hal_pkt_pp_rsn_str_get_func_t hal_pkt_pp_rsn_str_get;
    hal_pkt_pp_to_drop_rsn_func_t hal_pkt_pp_to_drop_rsn;
    hal_pkt_pp_rsn_code_get_func_t hal_pkt_pp_rsn_code_get;
    hal_pkt_rsn_str_get_func_t hal_pkt_rsn_str_get;
    hal_pkt_rsn_code_get_func_t hal_pkt_rsn_code_get;
    hal_pkt_drop_rsn_get_func_t hal_pkt_drop_rsn_get;
    hal_pkt_netlink_create_func_t hal_pkt_netlink_create;
    hal_pkt_netlink_destroy_func_t hal_pkt_netlink_destroy;
    hal_pkt_netlink_get_func_t hal_pkt_netlink_get;
    hal_pkt_queue_cfg_get_func_t hal_pkt_queue_cfg_get;
    hal_pkt_queue_cfg_set_func_t hal_pkt_queue_cfg_set;
    hal_pkt_rx_udf_mem_cb_set_func_t hal_pkt_rx_udf_mem_cb_set;
    hal_pkt_pdma_loopback_set_func_t hal_pkt_pdma_loopback_set;
    hal_pkt_mod_mac_set_func_t hal_pkt_mod_mac_set;
    hal_pkt_mod_mac_get_func_t hal_pkt_mod_mac_get;
    hal_pkt_ifa_cfg_set_func_t hal_pkt_ifa_cfg_set;
    hal_pkt_ifa_cfg_get_func_t hal_pkt_ifa_cfg_get;
} hal_drv_pkt_func_vec_t;

typedef struct hal_drv_stat_func_vec_s {
    hal_stat_init_func_t hal_stat_init;
    hal_stat_deinit_func_t hal_stat_deinit;
    hal_dflt_port_default_set_func_t hal_stat_port_default_set;
    hal_dflt_port_default_set_func_t hal_stat_port_default_reset;
    hal_stat_port_cnt_get_func_t hal_stat_port_cnt_get;
    hal_stat_port_cnt_clear_func_t hal_stat_port_cnt_clear;
    hal_stat_tm_cnt_get_func_t hal_stat_tm_cnt_get;
    hal_stat_tm_cnt_clear_func_t hal_stat_tm_cnt_clear;
    hal_stat_queue_cnt_get_func_t hal_stat_queue_cnt_get;
    hal_stat_queue_cnt_clear_func_t hal_stat_queue_cnt_clear;
    hal_stat_dist_cnt_create_func_t hal_stat_dist_cnt_create;
    hal_stat_dist_cnt_destroy_func_t hal_stat_dist_cnt_destroy;
    hal_stat_dist_cnt_get_func_t hal_stat_dist_cnt_get;
    hal_stat_dist_cnt_clear_func_t hal_stat_dist_cnt_clear;
    hal_stat_srv_cnt_create_func_t hal_stat_srv_cnt_create;
    hal_stat_srv_cnt_destroy_func_t hal_stat_srv_cnt_destroy;
    hal_stat_srv_cnt_get_func_t hal_stat_srv_cnt_get;
    hal_stat_srv_cnt_clear_func_t hal_stat_srv_cnt_clear;
    hal_stat_srv_cnt_cfg_get_func_t hal_stat_srv_cnt_cfg_get;
    hal_stat_port_rate_get_func_t hal_stat_port_rate_get;
    hal_stat_port_rate_type_get_func_t hal_stat_port_rate_type_get;
    hal_stat_cnt_refresh_func_t hal_stat_cnt_refresh;
    hal_stat_dbg_cnt_show_func_t hal_stat_dbg_cnt_show;
    hal_stat_dbg_cnt_clear_func_t hal_stat_dbg_cnt_clear;
    hal_stat_cnt_hw_idx_get_func_t hal_stat_cnt_hw_idx_get;
    hal_stat_pp_bank_id_get_func_t hal_stat_pp_bank_id_get;
    hal_stat_cnt_hw_idx_free_func_t hal_stat_cnt_hw_idx_free;
    hal_stat_reason_cnt_get_func_t hal_stat_reason_cnt_get;
    hal_stat_reason_cnt_clear_func_t hal_stat_reason_cnt_clear;
    hal_stat_drop_reason_cnt_get_func_t hal_stat_drop_reason_cnt_get;
    hal_stat_drop_reason_cnt_clear_func_t hal_stat_drop_reason_cnt_clear;
    hal_stat_hw_reason_cnt_get_func_t hal_stat_hw_reason_cnt_get;
    hal_stat_hw_reason_cnt_clear_func_t hal_stat_hw_reason_cnt_clear;
#ifdef CLX_STAT_EN_HPC_CNT
    hal_stat_hpc_port_util_ratio_get_func_t hal_stat_hpc_port_util_ratio_get;
    hal_stat_hpc_state_get_func_t hal_stat_hpc_state_get;
    hal_stat_hpc_state_set_func_t hal_stat_hpc_state_set;
    hal_stat_hpc_polling_interval_get_func_t hal_stat_hpc_polling_interval_get;
    hal_stat_hpc_polling_interval_set_func_t hal_stat_hpc_polling_interval_set;
    hal_stat_hpc_create_func_t hal_stat_hpc_create;
    hal_stat_hpc_destroy_func_t hal_stat_hpc_destroy;
    hal_stat_hpc_dequeue_func_t hal_stat_hpc_dequeue;
#endif /* End of CLX_STAT_EN_HPC_CNT */
    hal_stat_hrm_watermark_get_func_t hal_stat_hrm_watermark_get;
    hal_stat_hrm_watermark_clear_func_t hal_stat_hrm_watermark_clear;
    hal_stat_hrm_occupancy_get_func_t hal_stat_hrm_occupancy_get;
} hal_drv_stat_func_vec_t;

typedef struct hal_drv_sec_func_vec_s {
    hal_sec_init_func_t hal_sec_init;
    hal_sec_deinit_func_t hal_sec_deinit;
    hal_dflt_port_default_set_func_t hal_sec_setPortDefault;
    hal_dflt_port_default_set_func_t hal_sec_resetPortDefault;
    hal_sec_dos_port_cfg_set_func_t hal_sec_dos_port_cfg_set;
    hal_sec_dos_port_cfg_get_func_t hal_sec_dos_port_cfg_get;
    hal_sec_dos_cfg_set_func_t hal_sec_dos_cfg_set;
    hal_sec_dos_cfg_get_func_t hal_sec_dos_cfg_get;
    hal_sec_dos_status_get_func_t hal_sec_dos_status_get;
    hal_sec_dos_status_clear_func_t hal_sec_dos_status_clear;
    hal_sec_dos_cnt_get_func_t hal_sec_dos_cnt_get;
    hal_sec_dos_cnt_clear_func_t hal_sec_dos_cnt_clear;
    hal_sec_storm_ctrl_cfg_set_func_t hal_sec_storm_ctrl_cfg_set;
    hal_sec_storm_ctrl_cfg_get_func_t hal_sec_storm_ctrl_cfg_get;
    hal_sec_storm_ctrl_stats_get_func_t hal_sec_storm_ctrl_stats_get;
    hal_sec_storm_ctrl_stats_clear_func_t hal_sec_storm_ctrl_stats_clear;
    hal_sec_src_guard_cfg_set_func_t hal_sec_src_guard_cfg_set;
    hal_sec_src_guard_cfg_get_func_t hal_sec_src_guard_cfg_get;
    hal_sec_src_guard_bd_cfg_set_func_t hal_sec_src_guard_bd_cfg_set;
    hal_sec_src_guard_bd_cfg_get_func_t hal_sec_src_guard_bd_cfg_get;
    hal_sec_src_guard_entry_add_func_t hal_sec_src_guard_entry_add;
    hal_sec_src_guard_entry_del_func_t hal_sec_src_guard_entry_del;
    hal_sec_src_guard_entry_get_func_t hal_sec_src_guard_entry_get;
    hal_sec_isolation_grp_cfg_set_func_t hal_sec_isolation_grp_cfg_set;
    hal_sec_isolation_grp_cfg_get_func_t hal_sec_isolation_grp_cfg_get;
    hal_sec_isolation_port_cfg_set_func_t hal_sec_isolation_port_cfg_set;
    hal_sec_isolation_port_cfg_get_func_t hal_sec_isolation_port_cfg_get;
} hal_drv_sec_func_vec_t;

typedef struct hal_drv_sflow_func_vec_s {
    hal_sflow_init_func_t hal_sflow_init;
    hal_sflow_deinit_func_t hal_sflow_deinit;
} hal_drv_sflow_func_vec_t;

typedef struct hal_drv_qos_func_vec_s {
    hal_qos_init_func_t hal_qos_init;
    hal_qos_deinit_func_t hal_qos_deinit;
    hal_dflt_port_default_set_func_t hal_qos_port_dflt_set;
    hal_dflt_port_default_set_func_t hal_qos_port_dflt_reset;
    hal_qos_prof_create_func_t hal_qos_prof_create;
    hal_qos_prof_destroy_func_t hal_qos_prof_destroy;
    hal_qos_prof_set_func_t hal_qos_prof_set;
    hal_qos_prof_get_func_t hal_qos_prof_get;
    hal_qos_cosq_mapping_set_func_t hal_qos_cosq_mapping_set;
    hal_qos_cosq_mapping_get_func_t hal_qos_cosq_mapping_get;
} hal_drv_qos_func_vec_t;

typedef struct hal_drv_stp_func_vec_s {
    hal_stp_init_func_t hal_stp_init;
    hal_stp_deinit_func_t hal_stp_deinit;
    hal_dflt_port_default_set_func_t hal_stp_port_default_set;
    hal_dflt_port_default_set_func_t hal_stp_port_default_reset;
    hal_stp_create_func_t hal_stp_create;
    hal_stp_destroy_func_t hal_stp_destroy;
    hal_stp_portstate_set_func_t hal_stp_portstate_set;
    hal_stp_portstate_get_func_t hal_stp_portstate_get;
    hal_stp_is_valid_func_t hal_stp_is_valid;
} hal_drv_stp_func_vec_t;

typedef struct hal_drv_swc_func_vec_s {
    hal_swc_init_func_t hal_swc_init;
    hal_swc_deinit_func_t hal_swc_deinit;
    hal_dflt_port_default_set_func_t hal_swc_setPortDefault;
    hal_dflt_port_default_set_func_t hal_swc_resetPortDefault;
    hal_swc_cfg_set_func_t hal_swc_cfg_set;
    hal_swc_cfg_get_func_t hal_swc_cfg_get;
    hal_swc_hsh_key_set_func_t hal_swc_hsh_key_set;
    hal_swc_hsh_key_get_func_t hal_swc_hsh_key_get;
    hal_swc_hsh_key_prof_set_func_t hal_swc_hsh_key_prof_set;
    hal_swc_hsh_key_prof_get_func_t hal_swc_hsh_key_prof_get;
    hal_swc_hsh_eng_set_func_t hal_swc_hsh_eng_set;
    hal_swc_hsh_eng_get_func_t hal_swc_hsh_eng_get;
    hal_swc_ts_set_func_t hal_swc_ts_set;
    hal_swc_ts_get_func_t hal_swc_ts_get;
    hal_swc_ts_offset_set_func_t hal_swc_ts_offset_set;
    hal_swc_hsh_const_set_func_t hal_swc_hsh_const_set;
    hal_swc_hsh_const_get_func_t hal_swc_hsh_const_get;
    hal_swc_err_cb_register_func_t hal_swc_err_cb_register;
    hal_swc_err_cb_deregister_func_t hal_swc_err_cb_deregister;
    hal_swc_dev_info_get_func_t hal_swc_dev_info_get;
    hal_swc_port_cfg_get_func_t hal_swc_port_cfg_get;
    hal_swc_capacity_get_func_t hal_swc_capacity_get;
    hal_swc_usage_get_func_t hal_swc_usage_get;
    hal_swc_cso_mode_set_func_t hal_swc_cso_mode_set;
    hal_swc_cso_mode_get_func_t hal_swc_cso_mode_get;
    hal_swc_excpt_set_func_t hal_swc_excpt_set;
    hal_swc_trap_all_set_func_t hal_swc_trap_all_set;
    hal_swc_epg_pkt_init_func_t hal_swc_epg_pkt_init;
    hal_swc_epg_mac_hw_set_func_t hal_swc_epg_mac_hw_set;
    hal_swc_epg_mac_done_check_func_t hal_swc_epg_mac_done_chk;
    hal_swc_epg_mac_pkt_stop_func_t hal_swc_epg_mac_pkt_stop;
    hal_swc_rsn_act_set_func_t hal_swc_rsn_act_set;
    hal_swc_rsn_act_get_func_t hal_swc_rsn_act_get;
    hal_swc_rsn_pri_set_func_t hal_swc_rsn_pri_set;
    hal_swc_rsn_pri_get_func_t hal_swc_rsn_pri_get;
    hal_swc_pp_rsn_pri_set_func_t hal_swc_pp_rsn_pri_set;
    hal_swc_pp_rsn_pri_get_func_t hal_swc_pp_rsn_pri_get;
    hal_swc_max_ts_sec_get_func_t hal_swc_max_ts_sec_get;
    hal_swc_tod_info_get_func_t hal_swc_tod_info_get;
    hal_chip_cfg_info_get_func_t hal_swc_chip_cfg_info_get;
    hal_swc_tbl_name_get_func_t hal_swc_tbl_name_get;
    hal_swc_str_name_get_func_t hal_swc_str_name_get;
    hal_swc_chip_pll_status_get_func_t hal_swc_chip_pll_status_get;
    hal_swc_hsh_path_get_func_t hal_swc_hsh_path_get;
    hal_swc_hsh_path_key_get_func_t hal_swc_hsh_path_key_get;
    hal_swc_skip_rx_crc_check_set_func_t hal_swc_skip_rx_crc_check_set;
    hal_swc_skip_rx_crc_check_get_func_t hal_swc_skip_rx_crc_check_get;
    hal_swc_runt_pkt_fwd_set_func_t hal_swc_runt_pkt_fwd_set;
    hal_swc_runt_pkt_fwd_get_func_t hal_swc_runt_pkt_fwd_get;
    hal_swc_fdl_thd_set_func_t hal_swc_fdl_thd_set;
    hal_swc_fdl_thd_get_func_t hal_swc_fdl_thd_get;
    hal_swc_notify_cb_register_func_t hal_swc_notify_cb_register;
    hal_swc_notify_cb_deregister_func_t hal_swc_notify_cb_deregister;
} hal_drv_swc_func_vec_t;

typedef struct hal_drv_meter_func_vec_s {
    hal_meter_init_func_t hal_meter_init;
    hal_meter_deinit_func_t hal_meter_deinit;
    hal_dflt_port_default_set_func_t hal_meter_setPortDefault;
    hal_dflt_port_default_set_func_t hal_meter_resetPortDefault;
    hal_meter_create_func_t hal_meter_create;
    hal_meter_destroy_func_t hal_meter_destroy;
    hal_meter_get_func_t hal_meter_get;
    hal_meter_param_set_func_t hal_meter_param_set;
} hal_drv_meter_func_vec_t;

typedef struct hal_drv_tm_func_vec_s {
    hal_tm_init_func_t hal_tm_init;
    hal_tm_deinit_func_t hal_tm_deinit;
    hal_dflt_port_default_set_func_t hal_tm_port_dflt_set;
    hal_dflt_port_default_set_func_t hal_tm_port_dflt_reset;
    hal_tm_handler_create_func_t hal_tm_handler_create;
    hal_tm_handler_destroy_func_t hal_tm_handler_destroy;
    hal_tm_sch_shaper_set_func_t hal_tm_shaper_set;
    hal_tm_sch_shaper_get_func_t hal_tm_shaper_get;
    hal_tm_sch_sched_mode_set_func_t hal_tm_sched_mode_set;
    hal_tm_sch_sched_mode_get_func_t hal_tm_sched_mode_get;
    hal_tm_cfg_set_func_t hal_tm_cfg_set;
    hal_tm_cfg_get_func_t hal_tm_cfg_get;
    hal_tm_pfc_mapping_set_func_t hal_tm_pfc_mapping_set;
    hal_tm_pfc_mapping_get_func_t hal_tm_pfc_mapping_get;
    hal_tm_pfc_state_get_func_t hal_tm_pfc_state_get;
    hal_tm_buf_usage_get_func_t hal_tm_buf_usage_get;
    hal_tm_buf_watermark_get_func_t hal_tm_buf_watermark_get;
    hal_tm_buf_watermark_clear_func_t hal_tm_buf_watermark_clear;
    hal_db_dump_func_t hal_tm_db_dump;
    hal_tm_pfcwd_cb_register_func_t hal_tm_pfcwd_cb_register;
    hal_tm_pfcwd_cb_deregister_func_t hal_tm_pfcwd_cb_deregister;
    hal_tm_pfcwd_set_func_t hal_tm_pfcwd_set;
    hal_tm_pfcwd_get_func_t hal_tm_pfcwd_get;
    hal_tm_pfcwd_state_set_func_t hal_tm_pfcwd_state_set;
    hal_tm_pfcwd_state_get_func_t hal_tm_pfcwd_state_get;
    hal_tm_tc_prof_set_func_t hal_tm_tc_prof_set;
    hal_tm_tc_prof_get_func_t hal_tm_tc_prof_get;
    hal_tm_buf_prof_create_func_t hal_tm_buf_prof_create;
    hal_tm_buf_prof_destroy_func_t hal_tm_buf_prof_destroy;
    hal_tm_buf_prof_set_func_t hal_tm_buf_prof_set;
    hal_tm_buf_prof_get_func_t hal_tm_buf_prof_get;
    hal_tm_buf_cfg_set_func_t hal_tm_buf_cfg_set;
    hal_tm_buf_cfg_get_func_t hal_tm_buf_cfg_get;
    hal_tm_wred_prof_create_func_t hal_tm_wred_prof_create;
    hal_tm_wred_prof_destroy_func_t hal_tm_wred_prof_destroy;
    hal_tm_wred_prof_set_func_t hal_tm_wred_prof_set;
    hal_tm_wred_prof_get_func_t hal_tm_wred_prof_get;
    hal_tm_wred_cfg_set_func_t hal_tm_wred_cfg_set;
    hal_tm_wred_cfg_get_func_t hal_tm_wred_cfg_get;
    hal_tm_histogram_cfg_set_func_t hal_tm_histogram_cfg_set;
    hal_tm_histogram_cfg_get_func_t hal_tm_histogram_cfg_get;
    hal_tm_histogram_cb_register_func_t hal_tm_histogram_cb_register;
    hal_tm_histogram_cb_deregister_func_t hal_tm_histogram_cb_unregister;
    hal_tm_histogram_cnt_clear_func_t hal_tm_histogram_count_clear;
    hal_tm_tcb_match_set_func_t hal_tm_tcb_match_set;
    hal_tm_tcb_match_get_func_t hal_tm_tcb_match_get;
    hal_tm_tcb_cfg_set_func_t hal_tm_tcb_cfg_set;
    hal_tm_tcb_cfg_get_func_t hal_tm_tcb_cfg_get;
    hal_tm_tcb_cb_register_func_t hal_tm_tcb_cb_register;
    hal_tm_tcb_cb_deregister_func_t hal_tm_tcb_cb_deregister;
    hal_tm_mburst_prof_create_func_t hal_tm_mburst_prof_create;
    hal_tm_mburst_prof_destroy_func_t hal_tm_mburst_prof_destroy;
    hal_tm_mburst_prof_set_func_t hal_tm_mburst_prof_set;
    hal_tm_mburst_prof_get_func_t hal_tm_mburst_prof_get;
    hal_tm_mburst_cfg_set_func_t hal_tm_mburst_cfg_set;
    hal_tm_mburst_cfg_get_func_t hal_tm_mburst_cfg_get;
    hal_tm_mburst_cb_register_func_t hal_tm_mburst_cb_register;
    hal_tm_mburst_cb_deregister_func_t hal_tm_mburst_cb_deregister;
    hal_tm_tm_hqos_enable_get_func_t hal_tm_hqos_enable_get;

} hal_drv_tm_func_vec_t;

typedef struct hal_drv_tm_rep_func_vec_s {
    HAL_TM_REP_INSERTEMDB_FUNC_T hal_tm_rep_insertEmdb;
    HAL_TM_REP_SEARCHEMDB_FUNC_T hal_tm_rep_searchEmdb;
    HAL_TM_REP_DELETEEMDB_FUNC_T hal_tm_rep_deleteEmdb;
    HAL_TM_REP_GETEMDB_FUNC_T hal_tm_rep_getEmdb;
    HAL_TM_REP_ALLOCMCDB_FUNC_T hal_tm_rep_allocMcdb;
    HAL_TM_REP_ADDMCDB_FUNC_T hal_tm_rep_addMcdb;
    HAL_TM_REP_DELETCMCDB_FUNC_T hal_tm_rep_deleteMcdb;
    HAL_TM_REP_GETCMCDB_FUNC_T hal_tm_rep_getMcdb;
    HAL_TM_REP_FREECMCDB_FUNC_T hal_tm_rep_freeMcdb;
    HAL_TM_REP_DELETEMG_MEMBER_FUNC_T hal_tm_rep_deleteMgMember;
    HAL_TM_REP_DELETEALLMG_MEMBER_FUNC_T hal_tm_rep_deleteAllMgMember;
    HAL_TM_REP_UPDATEMG_MEMBER_FUNC_T hal_tm_rep_updateMgMember;
} hal_drv_tm_rep_func_vec_t;

typedef struct hal_drv_lag_func_vec_s {
    hal_lag_init_func_t hal_lag_init;
    hal_lag_deinit_func_t hal_lag_deinit;
    hal_dflt_port_default_set_func_t hal_lag_port_default_set;
    hal_dflt_port_default_set_func_t hal_lag_port_default_reset;
    hal_lag_create_func_t hal_lag_create;
    hal_lag_destroy_func_t hal_lag_destroy;
    hal_lag_member_set_func_t hal_lag_member_set;
    hal_lag_member_get_func_t hal_lag_member_get;
    hal_lag_member_cnt_get_func_t hal_lag_member_cnt_get;
    hal_lag_trav_func_t hal_lag_trav;
    hal_lag_id_get_func_t hal_lag_id_get;
    hal_lag_port_get_func_t hal_lag_port_get;
    hal_lag_attr_set_func_t hal_lag_attr_set;
    hal_lag_attr_get_func_t hal_lag_attr_get;
    hal_chip_cfg_info_get_func_t hal_lag_chip_cfg_info_get;
    hal_lag_fdl_create_func_t hal_lag_fdl_create;
    hal_lag_fdl_destroy_func_t hal_lag_fdl_destroy;
    hal_lag_fdl_set_func_t hal_lag_fdl_set;
    hal_lag_fdl_get_func_t hal_lag_fdl_get;
} hal_drv_lag_func_vec_t;

typedef struct hal_drv_cia_func_vec_s {
    hal_cia_init_func_t hal_cia_init;
    hal_cia_deinit_func_t hal_cia_deinit;
    hal_dflt_port_default_set_func_t hal_cia_setPortDefault;
    hal_dflt_port_default_set_func_t hal_cia_resetPortDefault;
    hal_cia_select_key_prof_get_func_t hal_cia_select_key_prof_get;
    hal_cia_select_key_prof_add_func_t hal_cia_select_key_prof_add;
    hal_cia_select_key_prof_del_func_t hal_cia_select_key_prof_del;
    hal_cia_select_key_prof_trav_func_t hal_cia_select_key_prof_trav;
    hal_cia_grp_get_func_t hal_cia_grp_get;
    hal_cia_grp_add_func_t hal_cia_grp_add;
    hal_cia_grp_del_func_t hal_cia_grp_del;
    hal_cia_grp_trav_func_t hal_cia_grp_trav;
    hal_cia_exact_grp_get_func_t hal_cia_exact_grp_get;
    hal_cia_exact_grp_add_func_t hal_cia_exact_grp_add;
    hal_cia_exact_grp_del_func_t hal_cia_exact_grp_del;
    hal_cia_exact_grp_trav_func_t hal_cia_exact_grp_trav;
    hal_cia_udf_entry_get_func_t hal_cia_udf_entry_get;
    hal_cia_udf_entry_add_func_t hal_cia_udf_entry_add;
    hal_cia_udf_entry_del_func_t hal_cia_udf_entry_del;
    hal_cia_udf_entry_trav_func_t hal_cia_udf_entry_trav;
    hal_cia_entry_id_info_get_func_t hal_cia_entry_id_info_get;
    hal_cia_entry_id_alloc_func_t hal_cia_entry_id_alloc;
    hal_cia_entry_id_free_func_t hal_cia_entry_id_free;
    hal_cia_entry_get_func_t hal_cia_entry_get;
    hal_cia_entry_add_func_t hal_cia_entry_add;
    hal_cia_entry_vld_set_func_t hal_cia_entry_vld_set;
    hal_cia_entry_del_func_t hal_cia_entry_del;
    hal_cia_entry_trav_func_t hal_cia_entry_trav;
    hal_cia_exact_entry_get_func_t hal_cia_exact_entry_get;
    hal_cia_exact_entry_add_func_t hal_cia_exact_entry_add;
    hal_cia_exact_entry_del_func_t hal_cia_exact_entry_del;
    hal_cia_exact_entry_trav_func_t hal_cia_exact_entry_trav;
    hal_cia_exact_entry_id_info_get_func_t hal_cia_exact_entry_id_info_get;
    hal_cia_rim_alloc_func_t hal_cia_rim_alloc;
    hal_cia_rim_free_func_t hal_cia_rim_free;
    hal_cia_rim_act_set_func_t hal_cia_rim_act_set;
    hal_cia_rim_act_get_func_t hal_cia_rim_act_get;
    hal_cia_rim_act_trav_func_t hal_cia_rim_act_trav;
    hal_cia_range_add_func_t hal_cia_range_add;
    hal_cia_range_del_func_t hal_cia_range_del;
    hal_cia_range_get_func_t hal_cia_range_get;
    hal_cia_range_trav_func_t hal_cia_range_trav;
    hal_cia_range_union_set_func_t hal_cia_range_union_set;
    hal_cia_range_union_get_func_t hal_cia_range_union_get;
} hal_drv_cia_func_vec_t;

/* MPLS multiplexing functions */
typedef struct hal_drv_mpls_func_vec_s {
    hal_mpls_init_func_t hal_mpls_init;
    hal_mpls_deinit_func_t hal_mpls_deinit;
    hal_dflt_port_default_set_func_t hal_mpls_port_dflt_set;
    hal_dflt_port_default_set_func_t hal_mpls_port_dflt_reset;
    hal_mpls_vpn_id_create_fun_t hal_mpls_vpn_id_create;
    hal_mpls_vpn_id_destroy_fun_t hal_mpls_vpn_id_destroy;
    hal_mpls_vpn_id_get_fun_t hal_mpls_vpn_id_get;
    hal_mpls_lsp_port_create_fun_t hal_mpls_lsp_port_create;
    hal_mpls_lsp_port_destroy_fun_t hal_mpls_lsp_port_destroy;
    hal_mpls_lsp_port_get_fun_t hal_mpls_lsp_port_get;
    hal_mpls_encap_add_fun_t hal_mpls_encap_add;
    hal_mpls_encap_del_fun_t hal_mpls_encap_del;
    hal_mpls_encap_get_fun_t hal_mpls_encap_get;
    hal_mpls_decap_add_fun_t hal_mpls_decap_add;
    hal_mpls_decap_del_fun_t hal_mpls_decap_del;
    hal_mpls_decap_get_fun_t hal_mpls_decap_get;
    hal_mpls_transit_add_fun_t hal_mpls_transit_add;
    hal_mpls_transit_del_fun_t hal_mpls_transit_del;
    hal_mpls_transit_get_fun_t hal_mpls_transit_get;
    hal_mpls_pw_port_create_fun_t hal_mpls_pw_port_create;
    hal_mpls_pw_port_destroy_fun_t hal_mpls_pw_port_destroy;
    hal_mpls_pw_port_get_fun_t hal_mpls_pw_port_get;
    hal_mpls_pw_add_fun_t hal_mpls_pw_add;
    hal_mpls_pw_del_fun_t hal_mpls_pw_del;
    hal_mpls_pw_get_fun_t hal_mpls_pw_get;
    hal_mpls_vpws_add_fun_t hal_mpls_vpws_add;
    hal_mpls_vpws_del_fun_t hal_mpls_vpws_del;
    hal_mpls_vpws_get_fun_t hal_mpls_vpws_get;
    hal_mpls_lbl_range_set_fun_t hal_mpls_lbl_range_set;
    hal_mpls_lbl_range_get_fun_t hal_mpls_lbl_range_get;
    hal_mpls_encap_trav_fun_t hal_mpls_encap_trav;
    hal_mpls_transit_trav_fun_t hal_mpls_transit_trav;
    hal_mpls_decap_trav_fun_t hal_mpls_decap_trav;
    hal_mpls_pw_trav_fun_t hal_mpls_pw_trav;
    hal_db_dump_func_t hal_mpls_db_dump;
} hal_drv_mpls_func_vec_t;

typedef struct hal_drv_telm_func_vec_s {
    hal_telm_init_func_t hal_telm_init;
    hal_telm_deinit_func_t hal_telm_deinit;
    hal_dflt_port_default_set_func_t hal_telm_port_dflt_set;
    hal_dflt_port_default_set_func_t hal_telm_port_dflt_reset;
    hal_telm_notify_cb_register_func_t hal_telm_notify_cb_register;
    hal_telm_notify_cb_deregister_func_t hal_telm_notify_cb_deregister;
    hal_telm_cfg_set_func_t hal_telm_cfg_set;
    hal_telm_cfg_get_func_t hal_telm_cfg_get;

    /* int api */
    hal_telm_int_prof_set_func_t hal_telm_int_prof_set;
    hal_telm_int_prof_get_func_t hal_telm_int_prof_get;
    hal_telm_int_glb_set_func_t hal_telm_int_glb_set;
    hal_telm_int_glb_get_func_t hal_telm_int_glb_get;

    /* mod api */
    hal_telm_mod_cfg_set_func_t hal_telm_mod_cfg_set;
    hal_telm_mod_cfg_get_func_t hal_telm_mod_cfg_get;

    /* hal_mt_nb level api */
    hal_telm_ioam_cfg_set_func_t hal_telm_ioam_cfg_set;
    hal_telm_ioam_cfg_get_func_t hal_telm_ioam_cfg_get;
    hal_telm_ifa_cfg_set_func_t hal_telm_ifa_cfg_set;
    hal_telm_ifa_cfg_get_func_t hal_telm_ifa_cfg_get;
    hal_telm_mod_tm_en_set_func_t hal_telm_mod_tm_en_set;
    hal_telm_mod_tm_en_get_func_t hal_telm_mod_tm_en_get;
    hal_telm_tob_set_func_t hal_telm_tob_set;
    hal_telm_tob_get_func_t hal_telm_tob_get;
    hal_telm_type_set_func_t hal_telm_type_set;
    hal_telm_type_get_func_t hal_telm_type_get;
    hal_telm_delay_cycle_set_func_t hal_telm_delay_cycle_set;
    hal_telm_int_sampler_set_func_t hal_telm_int_sampler_set;
    hal_telm_int_instr_set_func_t hal_telm_int_instr_set;
    hal_telm_int_instr_get_func_t hal_telm_int_instr_get;
    hal_telm_int_prof_max_hop_cnt_set_func_t hal_telm_int_prof_max_hop_cnt_set;
    hal_telm_int_prof_max_hop_cnt_get_func_t hal_telm_int_prof_max_hop_cnt_get;
    hal_telm_int_prof_clean_func_t hal_telm_int_prof_clean;
    hal_telm_int_tm_lut_init_func_t hal_telm_int_tm_lut_init;
    hal_telm_int_clone_set_func_t hal_telm_int_clone_set;
    hal_telm_int_clone_get_func_t hal_telm_int_clone_get;
    hal_telm_int_edge_set_func_t hal_telm_int_edge_set;
    hal_telm_int_edge_get_func_t hal_telm_int_edge_get;
    hal_telm_mode_set_func_t hal_telm_mode_set;
    hal_telm_mode_get_func_t hal_telm_mode_get;
    hal_telm_qocc_unit_size_set_func_t hal_telm_qocc_unit_size_set;
    hal_telm_qocc_unit_size_get_func_t hal_telm_qocc_unit_size_get;
    hal_telm_qsize_stat_mode_set_func_t hal_telm_qsize_stat_mode_set;
    hal_telm_qsize_stat_mode_get_func_t hal_telm_qsize_stat_mode_get;
    hal_telm_int_identifier_set_func_t hal_telm_int_identifier_set;
    hal_telm_int_identifier_get_func_t hal_telm_int_identifier_get;
    hal_telm_tm_trunc_size_get_func_t hal_telm_tm_trunc_size_get;
    hal_telm_mod_rep_tnl_cfg_set_func_t hal_telm_mod_rep_tnl_cfg_set;
    hal_telm_mod_rep_tnl_cfg_get_func_t hal_telm_mod_rep_tnl_cfg_get;
    hal_telm_int_rep_tnl_cfg_set_func_t hal_telm_int_rep_tnl_cfg_set;
    hal_telm_int_rep_tnl_cfg_del_func_t hal_telm_int_rep_tnl_cfg_del;
    hal_telm_int_rep_tnl_cfg_get_func_t hal_telm_int_rep_tnl_cfg_get;
    hal_telm_int_meta_info_set_func_t hal_telm_int_meta_info_set;
    hal_telm_int_meta_info_get_func_t hal_telm_int_meta_info_get;
    hal_telm_int_restore_dscp_set_func_t hal_telm_int_restore_dscp_set;
    hal_telm_int_restore_dscp_get_func_t hal_telm_int_restore_dscp_get;
    hal_telm_ioam_rwi_fifo_cfg_init_func_t hal_telm_ioam_rwi_fifo_cfg_init;
    hal_telm_ioam_hw_cfg_init_func_t hal_telm_ioam_hw_cfg_init;
    hal_telm_ioam_fifo_to_clx_entry_convert_func_t hal_telm_ioam_fifo_to_clx_entry_convert;
    hal_telm_port_speed_set_func_t hal_telm_port_speed_set;
    hal_telm_ifa_hw_cfg_init_func_t hal_telm_ifa_hw_cfg_init;
    hal_telm_mod_hw_cfg_init_func_t hal_telm_mod_hw_cfg_init;
    hal_telm_ioam_diag_cfg_get_func_t hal_telm_ioam_diag_cfg_get;
    hal_telm_ioam_diag_cfg_set_func_t hal_telm_ioam_diag_cfg_set;
    hal_telm_mod_reg_set_func_t hal_telm_mod_reg_set;
    hal_telm_mod_reg_get_func_t hal_telm_mod_reg_get;

    hal_telm_rwo_encap_ip_set_func_t hal_telm_rwo_encap_ip_set;
    hal_telm_rwo_encap_ip_get_func_t hal_telm_rwo_encap_ip_get;
    hal_telm_rwo_encap_ip_clear_func_t hal_telm_rwo_encap_ip_clear;
    hal_telm_encap_ip_id_get_func_t hal_telm_encap_ip_id_get;
    hal_telm_mod_oq_get_func_t hal_telm_mod_oq_get;
    hal_telm_sub_module_init_func_t hal_telm_sub_module_init;
} hal_drv_telm_func_vec_t;

typedef struct hal_drv_ecc_func_vec_s {
    hal_ecc_set_cfg_func_t hal_ecc_cfg_set;
    hal_ecc_get_cfg_func_t hal_ecc_cfg_get;
    hal_ecc_err_cnt_get_func_t hal_ecc_err_cnt_get;
    hal_ecc_err_cnt_clear_func_t hal_ecc_err_cnt_clear;
} hal_drv_ecc_func_vec_t;

typedef struct hal_drv_stk_func_vec_s {
    hal_stk_init_func_t hal_stk_init;
    hal_stk_deinit_func_t hal_stk_deinit;
    hal_dflt_port_default_set_func_t hal_stk_setPortDefault;
    hal_dflt_port_default_set_func_t hal_stk_resetPortDefault;
    hal_stk_my_chip_id_set_func_t hal_stk_my_chip_id_set;
    hal_stk_my_chip_id_get_func_t hal_stk_my_chip_id_get;
    hal_stk_neighbor_chip_id_set_func_t hal_stk_neighbor_chip_id_set;
    hal_stk_neighbor_chip_id_get_func_t hal_stk_neighbor_chip_id_get;
    hal_stk_cutoff_chip_id_set_func_t hal_stk_cutoff_chip_id_set;
    hal_stk_cutoff_chip_id_get_func_t hal_stk_cutoff_chip_id_get;
    hal_stk_stacking_port_add_func_t hal_stk_stacking_port_add;
    hal_stk_stacking_port_del_func_t hal_stk_stacking_port_del;
    hal_stk_stacking_port_get_func_t hal_stk_stacking_port_get;
    hal_stk_path_to_remote_chip_set_func_t hal_stk_path_to_remote_chip_set;
    hal_stk_stacking_port_to_cpu_add_func_t hal_stk_stacking_port_to_cpu_add;
    hal_stk_stacking_port_to_cpu_del_func_t hal_stk_stacking_port_to_cpu_del;
    hal_stk_stacking_port_to_cpu_get_func_t hal_stk_stacking_port_to_cpu_get;
    hal_stk_cpu_path_to_remote_chip_set_func_t hal_stk_cpu_path_to_remote_chip_set;
    hal_stk_dpi_port_get_func_t hal_stk_dpi_port_get;
    hal_stk_dpi_port_add_func_t hal_stk_dpi_port_add;
    hal_stk_dpi_port_del_func_t hal_stk_dpi_port_del;
    hal_stk_dil_entry_set_func_t hal_stk_dil_entry_set;
    hal_stk_dil_entry_get_func_t hal_stk_dil_entry_get;
    hal_stk_chip_mode_get_func_t hal_stk_chip_mode_get;
    hal_stk_chip_cfg_set_func_t hal_stk_chip_cfg_set;
    hal_stk_chip_cfg_get_func_t hal_stk_chip_cfg_get;
    hal_stk_fab_port_add_func_t hal_stk_fab_port_add;
    hal_stk_fab_port_del_func_t hal_stk_fab_port_del;
    hal_stk_fab_port_get_func_t hal_stk_fab_port_get;
    hal_stk_path_remote_map_set_func_t hal_stk_path_remote_map_set;
    hal_stk_fl_member_update_func_t hal_stk_fl_member_update;
    hal_stk_fabric_panel_port_add_func_t hal_stk_fabric_panel_port_add;
    hal_stk_fabric_panel_port_del_func_t hal_stk_fabric_panel_port_del;
    hal_stk_fabric_panel_port_get_func_t hal_stk_fabric_panel_port_get;
    hal_stk_path_tc_profile_idx_set_func_t hal_stk_path_tc_profile_idx_set;
    hal_stk_path_tc_profile_idx_get_func_t hal_stk_path_tc_profile_idx_get;
} hal_drv_stk_func_vec_t;

typedef struct hal_drv_intr_func_vec_s {
    hal_intr_enable_set_func_t hal_intr_enable_set;
    hal_intr_enable_get_func_t hal_intr_enable_get;
} hal_drv_intr_func_vec_t;

typedef struct hal_drv_ecpu_func_vec_s {
    hal_ecpu_init_func_t hal_ecpu_init;
    hal_ecpu_deinit_func_t hal_ecpu_deinit;
    hal_ecpu_hwinit_func_t hal_ecpu_hw_init;
    hal_dflt_port_default_set_func_t hal_ecpu_port_dflt_set;
    hal_dflt_port_default_set_func_t hal_ecpu_port_dflt_reset;
    hal_ecpu_reboot_func_t hal_ecpu_reboot;
    hal_ecpu_start_func_t hal_ecpu_start;
    hal_ecpu_binary_start_func_t hal_ecpu_binary_start;
    hal_ecpu_stop_func_t hal_ecpu_stop;
    hal_ecpu_force_stop_func_t hal_ecpu_force_stop;
    hal_ecpu_readmem_func_t hal_ecpu_memory_read;
    hal_ecpu_readflash_func_t hal_ecpu_flash_read;
    hal_ecpu_diag_log_read_func_t hal_ecpu_diag_log_read;
    hal_ecpu_fw_flash_update_func_t hal_ecpu_flash_fw_update;
    hal_ecpu_updatesramfw_func_t hal_ecpu_sram_fw_update;
    hal_ecpu_updatesramrawfw_func_t hal_ecpu_sram_raw_fw_update;
    hal_ecpu_headroom_watermark_clr_func_t hal_ecpu_headroom_watermark_clr;
    hal_ecpu_headroom_is_running_func_t hal_ecpu_headroom_is_running;
    hal_ecpu_intr_register_func_t hal_ecpu_intr_register;
    hal_ecpu_intr_unregister_func_t hal_ecpu_intr_unregister;
    hal_ecpu_intr_to_ecpu_trigger_func_t hal_ecpu_intr_to_ecpu_trigger;
    hal_ecpu_from_ecpu_intr_clr_func_t hal_ecpu_from_ecpu_intr_clr;
    hal_ecpu_from_ecpu_intr_enable_func_t hal_ecpu_from_ecpu_intr_enable;
    hal_ecpu_diag_log_buf_info_get_func_t hal_ecpu_diag_log_buf_info_get;
    hal_ecpu_dtcm_addr_get_func_t hal_ecpu_dtcm_addr_get;
    hal_ecpu_dtcm_on_chain_addr_get_func_t hal_ecpu_dtcm_on_chain_addr_get;
    hal_ecpu_itcm_addr_get_func_t hal_ecpu_itcm_addr_get;
    hal_ecpu_itcm_on_chain_addr_get_func_t hal_ecpu_itcm_on_chain_addr_get;
    hal_ecpu_fw_feature_is_supported_func_t hal_ecpu_fw_feature_is_supported;
    hal_ecpu_fw_dflt_set_func_t hal_ecpu_fw_dflt_set;
    hal_ecpu_fw_dflt_get_func_t hal_ecpu_fw_dflt_get;
    hal_ecpu_fw_running_get_func_t hal_ecpu_fw_running_get;
    hal_ecpu_fw_info_trav_func_t hal_ecpu_fw_info_trav;
    hal_ecpu_port_limit_func_t hal_ecpu_port_limit;
    hal_ecpu_ring_buf_handler_init_func_t hal_ecpu_ring_buf_tx_init;
    hal_ecpu_ring_buf_handler_init_func_t hal_ecpu_ring_buf_rx_init;
    hal_ecpu_core_num_get_func_t hal_ecpu_core_num_get;
} hal_drv_ecpu_func_vec_t;

typedef struct hal_drv_tod_func_vec_s {
    hal_tod_init_func_t hal_tod_init;
    hal_tod_deinit_func_t hal_tod_deinit;
    hal_tod_hw_init_func_t hal_tod_hw_init;
    hal_tod_intr_register_func_t hal_tod_intr_register;
    hal_tod_intr_unregister_func_t hal_tod_intr_unregister;
    hal_tod_pps_intr_restart_func_t hal_tod_pps_intr_restart;
    hal_tod_current_value_get_func_t hal_tod_current_value_get;
    hal_dflt_port_default_set_func_t hal_tod_port_dflt_set;
    hal_dflt_port_default_set_func_t hal_tod_port_dflt_reset;
} hal_drv_tod_func_vec_t;

typedef struct hal_drv_bfd_func_vec_s {
    hal_bfd_init_func_t hal_bfd_init;
    hal_bfd_deinit_func_t hal_bfd_deinit;
    hal_bfd_session_create_func_t hal_bfd_session_create;
    hal_bfd_session_delete_func_t hal_bfd_session_delete;
    hal_bfd_all_session_delete_func_t hal_bfd_all_session_delete;
    hal_bfd_session_update_func_t hal_bfd_session_update;
    hal_bfd_session_cfg_info_get_func_t hal_bfd_session_cfg_info_get;
    hal_bfd_session_next_cfg_get_func_t hal_bfd_session_next_cfg_get;
    hal_bfd_session_pkt_stats_get_func_t hal_bfd_session_pkt_stats_get;
    hal_bfd_session_drop_pkt_stats_get_func_t hal_bfd_session_drop_pkt_stats_get;
    hal_bfd_session_pkt_stats_clear_func_t hal_bfd_session_pkt_stats_clear;
    hal_bfd_session_drop_pkt_stats_clear_func_t hal_bfd_session_drop_pkt_stats_clear;
    hal_bfd_session_status_get_func_t hal_bfd_session_status_get;
    hal_bfd_session_poll_trigger_func_t hal_bfd_session_poll_trigger;
    hal_bfd_session_admin_set_func_t hal_bfd_session_admin_set;
    hal_bfd_session_event_cb_register_func_t hal_bfd_session_event_cb_register;
    hal_bfd_session_event_cb_unregister_func_t hal_bfd_session_event_cb_unregister;
} hal_drv_bfd_func_vec_t;

typedef struct hal_drv_ptp_func_vec_s {
    hal_ptp_init_func_t hal_ptp_init;
    hal_ptp_deinit_func_t hal_ptp_deinit;
    hal_ptp_clk_create_func_t hal_ptp_clk_create;
    hal_ptp_clk_destroy_func_t hal_ptp_clk_destroy;
    hal_ptp_clk_cfg_set_func_t hal_ptp_clk_cfg_set;
    hal_ptp_clk_cfg_get_func_t hal_ptp_clk_cfg_get;
    hal_ptp_port_add_func_t hal_ptp_port_add;
    hal_ptp_port_del_func_t hal_ptp_port_del;
    hal_ptp_port_cfg_set_func_t hal_ptp_port_cfg_set;
    hal_ptp_port_cfg_get_func_t hal_ptp_port_cfg_get;
    hal_ptp_port_cnt_get_func_t hal_ptp_port_cnt_get;
    hal_ptp_port_cnt_clr_func_t hal_ptp_port_cnt_clr;
    hal_ptp_clk_rslt_get_func_t hal_ptp_clk_rslt_get;
    hal_ptp_port_wire_delay_get_func_t hal_ptp_port_wire_delay_get;
    hal_ptp_mon_enable_func_t hal_ptp_mon_enable;
    hal_ptp_mon_disable_func_t hal_ptp_mon_disable;
    hal_ptp_mon_cfg_set_func_t hal_ptp_mon_cfg_set;
    hal_ptp_mon_cfg_get_func_t hal_ptp_mon_cfg_get;
    hal_ptp_mon_stat_get_func_t hal_ptp_mon_stat_get;
    hal_ptp_mon_stat_clr_func_t hal_ptp_mon_stat_clr;
    hal_ptp_masters_get_func_t hal_ptp_masters_get;
    hal_ptp_port_state_get_func_t hal_ptp_port_state_get;
} hal_drv_ptp_func_vec_t;

typedef struct hal_drv_export_func_vec_s {
    hal_export_arp_init_func_t hal_export_arp_init;
    hal_export_arp_deinit_func_t hal_export_arp_deinit;
    hal_export_arp_data_get_func_t hal_export_arp_data_get;
    hal_export_mac_init_func_t hal_export_mac_init;
    hal_export_mac_deinit_func_t hal_export_mac_deinit;
    hal_export_mac_data_get_func_t hal_export_mac_data_get;
    hal_export_route_init_func_t hal_export_route_init;
    hal_export_route_deinit_func_t hal_export_route_deinit;
    hal_export_route_data_get_func_t hal_export_route_data_get;
    hal_export_route_l3_dst_idx_get_func_t hal_export_route_l3_dst_idx_get;
} hal_drv_export_func_vec_t;

typedef struct hal_drv_d2d_func_vec_s {
    hal_d2d_ddc_status_get_func_t hal_d2d_ddc_status_get;
    hal_d2d_ddc_fec_cnt_get_func_t hal_d2d_ddc_fec_cnt_get;
} hal_drv_d2d_func_vec_t;

/* misc multiplexing functions */
typedef struct hal_drv_misc_func_vec_s {
    hal_misc_init_func_t hal_misc_init;
    hal_misc_deinit_func_t hal_misc_deinit;
    hal_misc_cpu2jtag_init_func_t hal_misc_cpu2jtag_init;
    hal_misc_cpu2jtag_trst_toggle_func_t hal_misc_cpu2jtag_trst_toggle;
    hal_misc_cpu2jtag_ir_check_func_t hal_misc_cpu2jtag_ir_check;
    hal_misc_cpu2jtag_dr_check_func_t hal_misc_cpu2jtag_dr_check;
    hal_misc_efuse_read_func_t hal_misc_efuse_read;
    hal_misc_efuse_write_func_t hal_misc_efuse_write;
    hal_misc_efuse_dump_func_t hal_misc_efuse_dump;
    hal_misc_chip_temp_get_func_t hal_misc_chip_temp_get;
    hal_misc_chip_temp_list_get_func_t hal_misc_chip_temp_list_get;
    hal_misc_pvt_calib_info_get_func_t hal_misc_pvt_calib_info_get;
    hal_misc_mdio_reg_set_func_t hal_misc_mdio_reg_set;
    hal_misc_mdio_reg_get_func_t hal_misc_mdio_reg_get;
    hal_misc_mdio_clk_rate_set_func_t hal_misc_mdio_clk_rate_set;
} hal_drv_misc_func_vec_t;

/* nfe multiplexing functions */
typedef struct hal_drv_nfe_func_vec_s {
    hal_nfe_init_func_t hal_nfe_init;
    hal_nfe_deinit_func_t hal_nfe_deinit;
    hal_dflt_port_default_set_func_t hal_nfe_port_dflt_set;
    hal_dflt_port_default_set_func_t hal_nfe_port_dflt_reset;
    hal_nfe_hw_init_func_t hal_nfe_hw_init;
    hal_nfe_hw_deinit_func_t hal_nfe_hw_deinit;
    hal_nfe_prof_create_func_t hal_nfe_prof_create;
    hal_nfe_prof_destroy_func_t hal_nfe_prof_destroy;
    hal_nfe_prof_set_func_t hal_nfe_prof_set;
    hal_nfe_prof_get_func_t hal_nfe_prof_get;
    hal_nfe_aging_interval_set_func_t hal_nfe_aging_interval_set;
    hal_nfe_aging_interval_get_func_t hal_nfe_aging_interval_get;
    hal_nfe_aging_force_set_func_t hal_nfe_aging_force_set;
    hal_nfe_thd_set_func_t hal_nfe_thd_set;
    hal_nfe_thd_get_func_t hal_nfe_thd_get;
    hal_nfe_scan_status_get_func_t hal_nfe_hw_scan_status_get;
    hal_nfe_current_flow_cnt_get_func_t hal_nfe_hw_current_flow_cnt_get;
    hal_nfe_current_flow_max_cnt_get_func_t hal_nfe_hw_current_flow_max_cnt_get;
    hal_nfe_conflict_flow_cnt_get_func_t hal_nfe_hw_conflict_flow_cnt_get;
    hal_nfe_conflict_flow_cnt_clr_func_t hal_nfe_hw_conflict_flow_cnt_clr;
    hal_nfe_flow_data_notify_cb_set_func_t hal_nfe_flow_data_notify_cb_set;
    hal_nfe_hw_scan_done_intr_set_func_t hal_nfe_hw_scan_done_intr_set;
    hal_nfe_hw_yellow_thd_intr_set_func_t hal_nfe_hw_yellow_thd_intr_set;
    hal_nfe_hw_red_thd_intr_set_func_t hal_nfe_hw_red_thd_intr_set;
    hal_nfe_hw_aging_start_func_t hal_nfe_hw_aging_start;
    hal_nfe_hw_aging_stop_func_t hal_nfe_hw_aging_stop;
    hal_nfe_hw_aging_2x_start_func_t hal_nfe_hw_aging_2x_start;
    hal_nfe_hw_force_aging_start_func_t hal_nfe_hw_force_aging_start;
    hal_nfe_hw_force_aging_2x_start_func_t hal_nfe_hw_force_aging_2x_start;
    hal_nfe_hw_prof_cfg_set_func_t hal_nfe_hw_prof_cfg_set;
    hal_nfe_hw_prof_dflt_set_func_t hal_nfe_hw_prof_dflt_set;
    hal_nfe_hw_thd_set_func_t hal_nfe_hw_thd_set;
    hal_nfe_hw_long_flow_interval_set_func_t hal_nfe_hw_long_flow_interval_set;
    hal_nfe_prof_key_psr_proc_func_t hal_nfe_hw_prof_key_psr_proc;
    hal_nfe_flow_data_len_get_func_t hal_nfe_hw_flow_data_len_get;
    hal_nfe_flow_data_psr_proc_func_t hal_nfe_hw_flow_data_psr_proc;
    hal_nfe_prof_ref_func_t hal_nfe_prof_ref;
    hal_nfe_prof_unref_func_t hal_nfe_prof_unref;
    hal_nfe_hw_need_batch_process_func_t hal_nfe_hw_need_batch_process;
    hal_nfe_hw_scan_start_func_t hal_nfe_hw_scan_start;
    hal_nfe_hw_scan_2x_start_func_t hal_nfe_hw_scan_2x_start;
} hal_drv_nfe_func_vec_t;

/* VM multiplexing functions */
typedef struct hal_drv_vm_func_vec_s {
    hal_vm_init_func_t hal_vm_init;
    hal_vm_deinit_func_t hal_vm_deinit;
    hal_vm_mode_set_func_t hal_vm_mode_set;
    hal_vm_mode_get_func_t hal_vm_mode_get;
    clx_vm_port_create_func_t hal_vm_port_create;
    clx_vm_port_destroy_func_t hal_vm_port_destroy;
    clx_vm_port_get_func_t hal_vm_port_get;
    hal_vm_port_cfg_set_func_t hal_vm_port_cfg_set;
    hal_vm_port_cfg_get_func_t hal_vm_port_cfg_get;
    hal_vm_pe_downstream_entry_add_func_t hal_vm_pe_downstream_entry_add;
    hal_vm_pe_downstream_entry_del_func_t hal_vm_pe_downstream_entry_del;
    hal_vm_pe_downstream_entry_get_func_t hal_vm_pe_downstream_entry_get;
    hal_vm_pe_upstream_entry_add_func_t hal_vm_pe_upstream_entry_add;
    hal_vm_pe_upstream_entry_del_func_t hal_vm_pe_upstream_entry_del;
    hal_vm_pe_upstream_entry_get_func_t hal_vm_pe_upstream_entry_get;
} hal_drv_vm_func_vec_t;

typedef struct hal_drv_wlan_func_vec_s {
    hal_wlan_init_func_t hal_wlan_init;
    hal_wlan_deinit_func_t hal_wlan_deinit;
    hal_dflt_port_default_set_func_t hal_wlan_port_dflt_set;
    hal_dflt_port_default_set_func_t hal_wlan_port_dflt_reset;
    hal_wlan_capwap_prof_add_func_t hal_wlan_capwap_prof_add;
    hal_wlan_capwap_prof_del_func_t hal_wlan_capwap_prof_del;
    hal_wlan_capwap_prof_get_func_t hal_wlan_capwap_prof_get;
    hal_wlan_port_create_func_t hal_wlan_port_create;
    hal_wlan_port_destroy_func_t hal_wlan_port_destroy;
    hal_wlan_port_get_func_t hal_wlan_port_get;
    hal_wlan_port_hdr_get_func_t hal_wlan_port_hdr_get;
    hal_wlan_port_trav_func_t hal_wlan_port_trav;
    hal_wlan_decap_add_func_t hal_wlan_decap_add;
    hal_wlan_decap_del_func_t hal_wlan_decap_del;
    hal_wlan_decap_get_func_t hal_wlan_decap_get;
    hal_wlan_decap_trav_func_t hal_wlan_decap_trav;
    hal_wlan_encap_add_func_t hal_wlan_encap_add;
    hal_wlan_encap_del_func_t hal_wlan_encap_del;
    hal_wlan_encap_get_func_t hal_wlan_encap_get;
    hal_wlan_encap_trav_func_t hal_wlan_encap_trav;
    hal_wlan_station_add_func_t hal_wlan_station_add;
    hal_wlan_station_del_func_t hal_wlan_station_del;
    hal_wlan_station_set_func_t hal_wlan_station_set;
    hal_wlan_station_get_func_t hal_wlan_station_get;
    hal_wlan_station_trav_func_t hal_wlan_station_trav;
    hal_db_dump_func_t hal_wlan_db_dump;
} hal_drv_wlan_func_vec_t;

typedef struct hal_drv_func_vec_s {
    /* chip multiplexing functions */
    hal_drv_chip_func_vec_t *const chip_func_vec;

    /* bd multiplexing functions */
    hal_drv_bd_func_vec_t *const bd_func_vec;

    /* vlan multiplexing functions */
    hal_drv_vlan_func_vec_t *const vlan_func_vec;

    /* port multiplexing functions */
    hal_drv_port_func_vec_t *const port_func_vec;

    /* ifmon multiplexing functions */
    hal_drv_ifmon_func_vec_t *const ifmon_func_vec;

    /* l2 multiplexing functions */
    hal_drv_l2_func_vec_t *const l2_func_vec;

    /* stp multiplexing functions */
    hal_drv_stp_func_vec_t *const stp_func_vec;

    /* lag multiplexing functions */
    hal_drv_lag_func_vec_t *const lag_func_vec;

    /* mirr multiplexing functions */
    hal_drv_mir_func_vec_t *const mir_func_vec;

    /* l3 multiplexing functions */
    hal_drv_l3_func_vec_t *l3_func_vec;

    /* iptun multiplexing functions */
    hal_drv_tnl_func_vec_t *const tnl_func_vec;

    /* srv6 multiplexing functions */
    hal_drv_srv6_func_vec_t *const srv6_func_vec;

    /* swc multiplexing functions */

    /* qos multiplexing functions */
    hal_drv_qos_func_vec_t *const qos_func_vec;
    /* rate multiplexing functions */

    /* meter multiplexing functions */
    hal_drv_meter_func_vec_t *const meter_func_vec;

    /* pkt multiplexing functions */
    hal_drv_pkt_func_vec_t *const pkt_func_vec;

    /* acl multiplexing functions */
    hal_drv_cia_func_vec_t *cia_func_vec;

    /* stat multiplexing functions */
    hal_drv_stat_func_vec_t *const stat_func_vec;

    /* sec multiplexing functions */
    hal_drv_sec_func_vec_t *const sec_func_vec;

    /* sflow multiplexing functions */
    hal_drv_sflow_func_vec_t *const sflow_func_vec;

    /* tm multiplexing functions */
    hal_drv_tm_func_vec_t *const tm_func_vec;

    /* tm rep multiplexing functions */
    hal_drv_tm_rep_func_vec_t *const tm_rep_func_vec;

    /* swtich control multiplexing functions */
    hal_drv_swc_func_vec_t *swc_func_vec;

    /* MPLS multiplexing functions */
    hal_drv_mpls_func_vec_t *const mpls_func_vec;

    /* Stacking multiplexing functions */
    hal_drv_stk_func_vec_t *const stk_func_vec;

    /* TELM multiplexing functions */
    hal_drv_telm_func_vec_t *const telm_func_vec;

    /* ECC multiplexing functions */
    hal_drv_ecc_func_vec_t *const ecc_func_vec;

    /* intr multiplexing functions */
    hal_drv_intr_func_vec_t *const intr_func_vec;

    /* eCPU multiplexing functions */
    hal_drv_ecpu_func_vec_t *const ecpu_func_vec;

    /* eCPU multiplexing functions */
    hal_drv_tod_func_vec_t *const tod_func_vec;

    /* BFD multiplexing functions */
    hal_drv_bfd_func_vec_t *const bfd_func_vec;

    /* PTP multiplexing functions */
    hal_drv_ptp_func_vec_t *const ptp_func_vec;

    /* Export multiplexing functions */
    hal_drv_export_func_vec_t *const export_func_vec;

    /* D2D multiplexing functions */
    hal_drv_d2d_func_vec_t *const d2d_func_vec;

    /* PHY multiplexing functions */
    hal_phy_func_vec_t *const phy_func_vec;
    hal_phy_func_vec_t *const internal_phy_func_vec;

    /* misc multiplexing functions */
    hal_drv_misc_func_vec_t *const misc_func_vec;

    /* nfe multiplexing functions */
    hal_drv_nfe_func_vec_t *const nfe_func_vec;

    /* vm multiplexing functions */
    hal_drv_vm_func_vec_t *const vm_func_vec;

    /* wlan multiplexing functions */
    hal_drv_wlan_func_vec_t *const wlan_func_vec;

    /* diag multiplexing functions */
} hal_drv_func_vec_t;

typedef enum hal_drv_alloc_type_e {
    HAL_ALLOC_TYPE_INDEX = 0,
    HAL_ALLOC_TYPE_INDEX_SUB,
    HAL_ALLOC_TYPE_PROFILE,
    HAL_ALLOC_TYPE_FIELD,
    HAL_ALLOC_TYPE_LAST
} hal_drv_alloc_type_t;

typedef enum hal_drv_sw_tbl_e {
    HAL_SW_IFP_MULTI_DEST_0_ID = HAL_RIM_SW_TBL_BASE_ID,
    HAL_SW_IFP_MULTI_DEST_1_ID,
    HAL_SW_EFP_NVO3_L3IF_0_ID,
    HAL_SW_EFP_NVO3_L3IF_1_ID,
    HAL_SW_TBL_ITM_RSLT_MGID_0_ID,
    HAL_SW_TBL_ITM_RSLT_MGID_0_NON_PRUNE_ID,
    HAL_SW_TBL_ITM_RSLT_MGID_1_ID,
    HAL_SW_TBL_ITM_RSLT_MGID_1_NON_PRUNE_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_0_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_1_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_2_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_3_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_4_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_5_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_6_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_7_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_8_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_9_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_10_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_11_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_12_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_13_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_14_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_15_ID,
    HAL_SW_TBL_EMI_RSLT_0_ID,
    HAL_SW_TBL_EMI_RSLT_1_ID,
    HAL_SW_TBL_EMI_RSLT_2_ID,
    HAL_SW_TBL_EMI_RSLT_3_ID,
    HAL_SW_TBL_EMI_RSLT_4_ID,
    HAL_SW_TBL_EMI_RSLT_5_ID,
    HAL_SW_TBL_EMI_RSLT_6_ID,
    HAL_SW_TBL_EMI_RSLT_7_ID,
    HAL_SW_TBL_EMI_RSLT_8_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_0_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_1_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_2_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_3_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_4_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_5_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_6_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_7_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_8_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_9_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_10_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_11_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_12_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_13_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_14_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_15_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_16_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_17_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_18_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_19_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_20_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_21_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_22_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_23_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_24_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_25_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_26_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_27_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_28_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_29_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_30_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_31_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_32_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_33_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_34_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_35_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_36_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_37_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_38_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_39_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_40_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_41_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_42_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_43_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_44_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_45_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_46_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_47_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_48_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_49_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_50_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_51_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_52_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_53_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_54_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_55_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_56_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_57_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_58_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_59_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_60_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_61_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_62_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_63_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_64_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_65_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_66_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_67_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_68_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_69_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_70_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_71_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_72_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_73_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_74_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_75_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_76_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_77_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_78_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_79_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_80_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_81_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_82_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_83_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_84_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_85_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_86_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_87_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_88_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_89_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_90_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_91_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_92_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_93_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_94_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_95_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_96_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_97_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_98_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_99_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_100_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_101_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_102_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_103_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_104_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_105_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_106_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_107_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_108_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_109_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_110_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_111_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_112_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_113_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_114_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_115_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_116_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_117_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_118_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_119_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_120_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_121_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_122_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_123_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_124_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_125_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_126_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_127_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_128_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_129_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_130_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_131_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_132_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_133_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_134_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_135_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_136_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_137_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_138_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_139_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_140_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_141_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_142_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_143_ID,
    HAL_SW_TBL_EMI_RSLT_L2_LCL_INTF_ID,
    HAL_SW_TBL_EMI_RSLT_L2_LCL_INTF_DFLT_ID,
    HAL_SW_TBL_EME_RSLT_ENCAP_IP_0_ID,
    HAL_SW_TBL_EME_RSLT_ENCAP_IP_1_ID,
    HAL_SW_TBL_EME_RSLT_ENCAP_IP_2_ID,
    HAL_SW_TBL_EME_RSLT_ENCAP_IP_3_ID,
    HAL_SW_TBL_IDS_RSLT_PHB_PROF_0_ID,
    HAL_SW_TBL_IDS_RSLT_PHB_PROF_1_ID,
    HAL_SW_TBL_EME_RSLT_PHB_PROF_0_ID,
    HAL_SW_TBL_EME_RSLT_PHB_PROF_1_ID,
    HAL_SW_TBL_IEV_FDL_HSH_U_DBL_0_ID,
    HAL_SW_TBL_IEV_FDL_HSH_U_DBL_1_ID,
    HAL_SW_TBL_FPU_TCAM_L2_UC_ID,
    HAL_SW_TBL_FPU_TCAM_L2_MC_ID,
    HAL_SW_TBL_FPU_TCAM_L2_VPWS_ID,
    HAL_SW_TBL_RWO_SRAM_NVO3_ENCAP_0_ID,
    HAL_SW_TBL_RWO_SRAM_NVO3_ENCAP_1_ID,
    HAL_SW_TBL_RWO_SRAM_NVO3_ENCAP_2_ID,
    HAL_SW_TBL_RWO_SRAM_NVO3_ENCAP_3_ID,
    HAL_SW_TBL_RWO_SRAM_NVO3_ENCAP_4_ID,
    HAL_SW_TBL_DIS_RSLT_PHB_PROF_0_ID,
    HAL_SW_TBL_DIS_RSLT_PHB_PROF_1_ID,
    HAL_SW_TBL_ECIA_RSLT_PHB_PROF_0_ID,
    HAL_SW_TBL_ECIA_RSLT_PHB_PROF_1_ID,
    HAL_SW_TBL_RWI_RSLT_PHB_PROF_0_ID,
    HAL_SW_TBL_RWI_RSLT_PHB_PROF_1_ID,
    HAL_SW_TBL_REP_RSLT_MC_GRP_SZ_L2_ID,
    HAL_SW_TBL_REP_RSLT_MC_GRP_SZ_L3_ID,
    HAL_SW_TBL_REP_RSLT_MC_DB_ID,
    HAL_SW_TBL_FWR_RSLT_TNL_ECMP_MBR_0_ID,
    HAL_SW_TBL_FWR_RSLT_TNL_ECMP_MBR_1_ID,
    HAL_SW_TBL_FPU_TCAM_FIB_V4_DIP_ID,
    HAL_SW_TBL_FPU_TCAM_FIB_V4_SIP_ID,
    HAL_SW_TBL_FPU_TCAM_FIB_V6_DIP_ID,
    HAL_SW_TBL_FPU_TCAM_FIB_V6_SIP_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_0_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_1_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_2_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_3_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_4_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_5_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_6_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_7_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_8_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_9_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_10_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_11_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_12_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_13_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_14_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_15_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_16_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_17_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_18_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_19_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_20_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_21_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_22_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_23_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_24_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_25_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_26_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_27_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_28_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_29_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_30_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_31_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_32_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_33_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_34_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_35_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_36_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_37_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_38_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_39_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_40_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_41_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_42_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_43_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_44_ID,
    HAL_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_45_ID,
    MT_SW_REG_CIAT_SLV_TILE_IGR_REGION_32K_ID,
    MT_SW_REG_CIAT_SLV_TILE_IGR_REGION_28K_ID,
    MT_SW_REG_CIAT_SLV_TILE_IGR_REGION_24K_ID,
    MT_SW_REG_CIAT_SLV_TILE_IGR_REGION_20K_ID,
    MT_SW_REG_CIAT_SLV_TILE_IGR_REGION_16K_ID,
    MT_SW_REG_CIAT_SLV_TILE_IGR_REGION_12K_ID,
    MT_SW_REG_CIAT_SLV_TILE_IGR_REGION_8K_ID,
    MT_SW_REG_CIAT_SLV_TILE_IGR_REGION_4K_ID,
    MT_SW_REG_CIAT_SLV_TILE_IGR_REGION_0K_ID,
    MT_SW_REG_CIAT_SLV_TILE_EGR_REGION_0K_ID,
    MT_SW_REG_CIAT_SLV_TILE_EGR_REGION_4K_ID,
    MT_SW_REG_CIAT_SLV_TILE_EGR_REGION_8K_ID,
    MT_SW_REG_CIAT_SLV_TILE_EGR_REGION_12K_ID,
    MT_SW_REG_CIAT_SLV_TILE_EGR_REGION_16K_ID,
    MT_SW_REG_CIAT_SLV_TILE_EGR_REGION_20K_ID,
    MT_SW_REG_CIAT_SLV_TILE_EGR_REGION_24K_ID,
    MT_SW_REG_CIAT_SLV_TILE_EGR_REGION_28K_ID,
    MT_SW_REG_CIAT_SLV_TILE_EGR_REGION_32K_ID,
    MT_SW_REG_CIAT_SLV_TILE_IGR_PRE_REGION_ID,
    MT_SW_TBL_CIA_IGR_SELECT_KEY_PROF_ID,
    MT_SW_TBL_CIA_EGR_SELECT_KEY_PROF_ID,
    MT_SW_TBL_CIA_IGR_EXACT_SELECT_KEY_PROF_ID,
    MT_SW_TBL_CIA_IGR_PRE_SELECT_KEY_PROF_ID,
    MT_SW_TBL_CIA_RIM_NFS_IDX_ID,
    MT_SW_TBL_CIA_IGR_EXACT_UCP_PROF_ID,
    HAL_SW_TBL_FPU_RSLT_L2_ECMP_GRP_ID,
    HAL_SW_TBL_LAST
} hal_drv_sw_tbl_t;

typedef struct hal_drv_alloc_entry_s {
    hal_drv_alloc_type_t type;
    uint32 sw_tbl_id;
    uint32 hw_tbl_id;
    uint32 base_index;
    uint32 length;
    uint32 bc_type;
    union {
        uint32 *ptr_bitmap[HAL_MAX_NUM_OF_PLANE + 1];
        uint32 *ptr_refcnt[HAL_MAX_NUM_OF_PLANE + 1];
    };
} hal_drv_alloc_entry_t;

typedef struct hal_drv_alloc_info_s {
    hal_drv_alloc_entry_t *ptr_alloc_tbl;
    uint32 entry_num;
} hal_drv_alloc_info_t;

typedef struct hal_drv_eth_macro_map_s {
    int32 die;
    int32 bin;
    int32 plane;
    int32 hw_mac_macro;
    int32 tm_mac_macro;
} hal_drv_eth_macro_map_t;

typedef struct hal_drv_eth_macro_info_s {
    uint32 device_id;
    uint32 macro_num;
    hal_drv_eth_macro_map_t *ptr_macro_map;
} hal_drv_eth_macro_info_t;

typedef struct hal_drv_driver_s {
    const char *const driver_desc;             /* driver description */
    hal_drv_func_vec_t *const ptr_func_vector; /* function vector pointer */
    hal_intr_info_t *const ptr_intr_info;      /* INTR information pointer */
    table_info_t **const pptr_tbl_info;        /* chip register/table information */
    packing_info_t **const pptr_tbl_key_info;  /* chip table key information for hash */
    tcam_tbl_meta_t *const ptr_tbl_tcam_info;
    hash_tbl_meta_t *const ptr_tbl_hash_info;
    hal_drv_alloc_info_t *const ptr_alloc_info;
    hal_drv_eth_macro_info_t *const ptr_eth_macro_info; /* all mac macro information of this chip
                                                         * family
                                                         */
    hal_ecc_info_t *const ptr_ecc_info;
    hal_const_info_t *const ptr_const_info;
    hal_cmn_drv_func_vec_t *const ptr_cmn_func_vector; /* function vector pointer for HAL common */
    hal_pkj_info_t *const ptr_pkj_info;
} hal_drv_driver_t;

typedef clx_error_no_t (*hal_driver_init_func_t)(const uint32 device_id,
                                                 const uint32 revision_id,
                                                 hal_drv_driver_t **pptr_hal_driver);

typedef struct hal_drv_dev_driver_map_s {
    uint32 device_id;                      /* device ID */
    hal_driver_init_func_t hal_initDriver; /* driver handler function pointer */
} hal_drv_dev_driver_map_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Hal_drv_init_device_driver() is an API that will use device ID and revision ID to find
 *        correct device driver.
 *
 * @param [in]     device_id          - The device ID of this device. Currently,
 *                                      it will be PCIe's device ID.
 * @param [in]     revision_id        - The revision ID of this device.
 *                                      Currently, it will be PCIe's revision ID.
 * @param [out]    pptr_hal_driver    - The pointer (address) of the HAL device driver that used
 *                                      for this device with the device_id and revision_id.
 * @return         CLX_E_OK        - Initialize the device driver successfully.
 * @return         CLX_E_OTHERS    - Fail to initialize the device driver.
 */
clx_error_no_t
hal_drv_device_driver_init(const uint32 device_id,
                           const uint32 revision_id,
                           hal_drv_driver_t **pptr_hal_driver);

#endif /* #ifndef HAL_DRV_H */
