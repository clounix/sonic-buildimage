/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_port_intf.h
 * PURPOSE:
 *  It provide HAL PORT interface module API.
 *
 * NOTES:
 */

#ifndef HAL_MT_KG_PORT_INTF_H
#define HAL_MT_KG_PORT_INTF_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>
#include <hal/mt/hal_mt_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief This API is used to update the tad mode for a local interface.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    plane_id    - Plane ID.
 * @param [in]    lcl_intf    - Local interface.
 * @param [in]    tag_mode    - Tag mode.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_intf_tag_mode_update(const uint32 unit,
                                    const uint32 plane_id,
                                    const uint32 lcl_intf,
                                    const uint32 tag_mode);

/**
 * @brief This API is used to set the configs for a specific interface object.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     intf          - Interface object.
 * @param [out]    ptr_config    - The pointer of the interface configs.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_intf_cfg_set(const uint32 unit,
                            const clx_port_t intf,
                            const clx_port_intf_cfg_t *ptr_config);

/**
 * @brief This API is used to set the configs for a specific interface object.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     intf          - Interface object.
 * @param [out]    ptr_config    - The pointer of the interface configs.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_intf_cfg_get(const uint32 unit,
                            const clx_port_t intf,
                            clx_port_intf_cfg_t *ptr_config);

clx_error_no_t
hal_mt_kg_port_intf_port_dflt_init(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to bind port vlan and bridge domain.
 *
 * Support CLX_GPORT_TYPE_UNIT_PORT, CLX_GPORT_TYPE_SRV6 and CLX_GPORT_TYPE_WLAN.
 * if svid=CLX_INVALID_ID, cvid=CLX_INVALID_ID, port base derive bridge domain.
 * if svid=valid vid, cvid=CLX_INVALID_ID, port+single_vlan derive bridge domain.
 * if svid=valid vid, cvid=valid vid, port + double_vlan derive bridge domain.
 * Support_chip: all.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Interface object.
 * @param [in]    svid    - First layer VLAN.
 * @param [in]    cvid    - Second layer VLAN.
 * @param [in]    bdid    - Bridge domain id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_intf_vlan_bd_bind(const uint32 unit,
                                 const clx_port_t port,
                                 const uint32 svid,
                                 const uint32 cvid,
                                 const clx_bridge_domain_t bdid);

/**
 * @brief This API is used to unbind port vlan and bridge domain.
 *
 * Support CLX_GPORT_TYPE_UNIT_PORT, CLX_GPORT_TYPE_SRV6 and CLX_GPORT_TYPE_WLAN.
 * if svid=CLX_INVALID_ID, cvid=CLX_INVALID_ID, port base derive bridge domain.
 * if svid=valid vid, cvid=CLX_INVALID_ID, port+single_vlan derive bridge domain.
 * if svid=valid vid, cvid=valid vid, port + double_vlan derive bridge domain.
 * Support_chip: all.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Interface object.
 * @param [in]    svid    - First layer VLAN.
 * @param [in]    cvid    - Second layer VLAN.
 * @param [in]    bdid    - Bridge domain id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_intf_vlan_bd_unbind(const uint32 unit,
                                   const clx_port_t port,
                                   const uint32 svid,
                                   const uint32 cvid,
                                   const clx_bridge_domain_t bdid);

/**
 * @brief This API is used to get the bridge domain bound to the port vlan.
 *
 * Support CLX_GPORT_TYPE_UNIT_PORT, CLX_GPORT_TYPE_SRV6 and CLX_GPORT_TYPE_WLAN.
 * if svid=CLX_INVALID_ID, cvid=CLX_INVALID_ID, port base derive bridge domain.
 * if svid=valid vid, cvid=CLX_INVALID_ID, port+single_vlan derive bridge domain.
 * if svid=valid vid, cvid=valid vid, port + double_vlan derive bridge domain.
 * Support_chip: all.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Interface object.
 * @param [in]     svid        - First layer VLAN.
 * @param [in]     cvid        - Second layer VLAN.
 * @param [out]    ptr_bdid    - Bridge domain id.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_intf_vlan_bd_get(const uint32 unit,
                                const clx_port_t port,
                                const uint32 svid,
                                const uint32 cvid,
                                clx_bridge_domain_t *ptr_bdid);

/**
 * @brief This API is used to set port egress vlan tag control. number.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    intf            - Logical port ID.
 * @param [in]    bdid            - Bridge Domain ID.
 * @param [in]    ptr_port_tag    - Egress vlan tag control.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_intf_vlan_tag_ctrl_set(const uint32 unit,
                                      const clx_port_t intf,
                                      const clx_bridge_domain_t bdid,
                                      const clx_port_vlan_tag_ctrl_t *ptr_port_tag);

/**
 * @brief This API is used to get port egress vlan tag control. number.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     intf            - Logical port ID.
 * @param [in]     bdid            - Bridge Domain ID.
 * @param [out]    ptr_port_tag    - Egress vlan tag control.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_intf_vlan_tag_ctrl_get(const uint32 unit,
                                      const clx_port_t intf,
                                      const clx_bridge_domain_t bdid,
                                      clx_port_vlan_tag_ctrl_t *ptr_port_tag);

/**
 * @brief To initialize the default properties for the new created pp port.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Initialize port default fail.
 */
clx_error_no_t
hal_mt_kg_port_intf_dflt_init(const uint32 unit);

/**
 * @brief To clear default properties for the destroyed pp port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Reset port default fail.
 */
clx_error_no_t
hal_mt_kg_port_intf_dflt_reset(const uint32 unit, const uint32 port);

/**
 * @brief To apply default properties for the new created pp port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Set port default fail.
 */
clx_error_no_t
hal_mt_kg_port_intf_dflt_set(const uint32 unit, const uint32 port);

/**
 * @brief Get nvo3_encap_idx from l3t_port/lsp_port/srv6_port/wlan_port.
 *
 * For cl8400.
 *
 * @param [in]     unit                  - Device unit number.
 * @param [in]     port                  -  L3t_port/lsp_port/srv6_port/wlan_port.
 * @param [in]     ptr_key               - Tunnel key for mc tunnel.
 * @param [out]    ptr_nvo3_encap_idx    - Index to RWO_SRAM_NVO3_ENCAP (all planes equal value).
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameter.
 */
clx_error_no_t
hal_mt_kg_port_intf_port_encap_idx_get(const uint32 unit,
                                       const clx_port_t port,
                                       const clx_tnl_info_t *ptr_key,
                                       uint32 *ptr_nvo3_encap_idx);

/**
 * @brief Get l3t_port/lsp_port/srv6_port/wlan_port from nvo3_encap_idx.
 *
 * For cl8400.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     nvo3_encap_idx    - Index of RWO_SRAM_NVO3_ENCAP.
 * @param [out]    ptr_port          - L3t_port/lsp_port/srv6_port.
 * @param [out]    ptr_key           - Tunnel key for mc tunnel.
 * @param [out]    ptr_use_port      - Indicate output ptr_port or ptr_key.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameter.
 */
clx_error_no_t
hal_mt_kg_port_intf_encap_idx_port_get(const uint32 unit,
                                       const uint32 nvo3_encap_idx,
                                       clx_port_t *ptr_port,
                                       clx_tnl_info_t *ptr_key,
                                       boolean *ptr_use_port);
/**
 * @brief This API is used to bind interface obj and bridge domain.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    ptr_bind_info    - Interface object binding bridge domain information.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_ENTRY_EXISTS       - Entry already exists.
 * @return        CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
hal_mt_kg_port_intf_obj_bd_bind(const uint32 unit,
                                const clx_port_intf_obj_bd_bind_t *ptr_bind_info);

/**
 * @brief This API is used to unbind interface obj and bridge domain.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    ptr_bind_info    - Interface object binding bridge domain information.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_ENTRY_EXISTS       - Entry already exists.
 * @return        CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
hal_mt_kg_port_intf_obj_bd_unbind(const uint32 unit,
                                  const clx_port_intf_obj_bd_bind_t *ptr_bind_info);

/**
 * @brief This API is used to get port interface obj bound bridge domain.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     ptr_bind_info    - Interface object bound bridge domain key.
 * @param [out]    ptr_bind_info    - Interface object bound bridge domain.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_ENTRY_EXISTS       - Entry already exists.
 * @return         CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
hal_mt_kg_port_intf_obj_bd_get(const uint32 unit, clx_port_intf_obj_bd_bind_t *ptr_bind_info);

/**
 * @brief Add interface obj egress vlan action.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_act_info    - Interface obj VLAN action information.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_SUPPORT      - Not support.
 */
clx_error_no_t
hal_mt_kg_port_intf_obj_vlan_act_add(const uint32 unit,
                                     const clx_port_intf_obj_vlan_act_t *ptr_act_info);

/**
 * @brief Delete interface obj egress vlan action.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_act_info    - Interface obj VLAN action information.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
hal_mt_kg_port_intf_obj_vlan_act_del(const uint32 unit,
                                     const clx_port_intf_obj_vlan_act_t *ptr_act_info);

/**
 * @brief Update egress vlan action.
 *
 * This API can update the hash table entries of all module configurations.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_act_info    - Interface obj VLAN action information.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
hal_mt_kg_port_intf_obj_vlan_act_update(const uint32 unit,
                                        const clx_port_intf_obj_vlan_act_t *ptr_act_info);

/**
 * @brief Get interface obj egress vlan action.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_act_info    - Interface obj VLAN action information.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
hal_mt_kg_port_intf_obj_vlan_act_get(const uint32 unit, clx_port_intf_obj_vlan_act_t *ptr_act_info);

#endif /* HAL_MT_KG_PORT_INTF_H */