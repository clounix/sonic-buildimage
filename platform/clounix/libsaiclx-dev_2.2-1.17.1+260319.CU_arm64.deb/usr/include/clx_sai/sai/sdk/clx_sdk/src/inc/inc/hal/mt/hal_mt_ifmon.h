/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_ifmon.h
 * PURPOSE:
 *      It provide HAL PORT module API.
 * NOTES:
 */

#ifndef HAL_MT_IFMON_H
#define HAL_MT_IFMON_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <util/lib/util_lib_list.h>
#include <clx/clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define HAL_MT_IFMON_MODE_DFLT (CLX_PORT_IFMON_MODE_INTR)

#define HAL_MT_IFMON_INTERVAL_DFLT (500000)

#define HAL_MT_IFMON_STACK_SIZE (64 * 1024)
#define HAL_MT_IFMON_THREAD_PRI (85)

#define HAL_MT_IFMON_LANE_SHIFT_PER_MACRO (3)
#define HAL_MT_IFMON_LANE_NUM_PER_MACRO   (1U << HAL_MT_IFMON_LANE_SHIFT_PER_MACRO)
#define HAL_MT_IFMON_LANE_MASK_PER_MACRO  (HAL_MT_IFMON_LANE_NUM_PER_MACRO - 1)

/* plane equivalent to slice, 8 plane per die/chip */
#define HAL_MT_IFMON_PLANE_NUM              (8)
#define HAL_MT_IFMON_ETH_LANE_NUM_PER_PLANE (32)
#define HAL_MT_IFMON_CPX_LANE_NUM_PER_PLANE (3) /* cpi0/1 + cpu*/
#define HAL_MT_IFMON_LANE_NUM_PER_PLANE \
    (HAL_MT_IFMON_ETH_LANE_NUM_PER_PLANE + HAL_MT_IFMON_CPX_LANE_NUM_PER_PLANE)

#define HAL_MT_IFMON_LANE_NUM         (HAL_MT_IFMON_PLANE_NUM * HAL_MT_IFMON_LANE_NUM_PER_PLANE)
#define HAL_MT_IFMON_LANE_BITMAP_SIZE (CLX_BITMAP_SIZE(HAL_MT_IFMON_LANE_NUM))

#define HAL_MT_IFMON_SPEED_BIT         (4)
#define HAL_MT_IFMON_SPEED_BITMAP_SIZE (HAL_MT_IFMON_SPEED_BIT * HAL_MT_IFMON_LANE_BITMAP_SIZE)

#define HAL_MT_IFMON_NOTIFY_HANDLER_CNT (16)

#define HAL_MT_IFMON_DBG_ENTRY_NUM      (256)
#define HAL_MT_IFMON_CPU_PORT_IN_PLANE  (32)
#define HAL_MT_IFMON_CPI0_PORT_IN_PLANE (34)
#define HAL_MT_IFMON_CPI1_PORT_IN_PLANE (35)

#define HAL_MT_IFMON_DB_DUMP_FLAGS_STM     (1U << 0)
#define HAL_MT_IFMON_DB_DUMP_FLAGS_FLOW    (1U << 1)
#define HAL_MT_IFMON_DB_DUMP_FLAGS_WARN    (1U << 2)
#define HAL_MT_IFMON_DB_DUMP_FLAGS_LT_FAIL (1U << 3)
#define HAL_MT_IFMON_DB_DUMP_FLAGS_ANLT    (1U << 4)
/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_MT_IFMON_DATA_LOCK(unit)   hal_mt_ifmon_data_lock(unit)
#define HAL_MT_IFMON_DATA_UNLOCK(unit) hal_mt_ifmon_data_unlock(unit)

#define HAL_MT_IFMON_FLOW_LOCK(unit)   hal_mt_ifmon_flow_lock(unit)
#define HAL_MT_IFMON_FLOW_UNLOCK(unit) hal_mt_ifmon_flow_unlock(unit)

#define HAL_MT_IFMON_ANLT_DATA_LOCK(unit)   hal_mt_ifmon_anlt_data_lock(unit)
#define HAL_MT_IFMON_ANLT_DATA_UNLOCK(unit) hal_mt_ifmon_anlt_data_unlock(unit)

#define HAL_MT_IFMON_ANLT_FLOW_LOCK(unit)   hal_mt_ifmon_anlt_flow_lock(unit)
#define HAL_MT_IFMON_ANLT_FLOW_UNLOCK(unit) hal_mt_ifmon_anlt_flow_unlock(unit)

#define HAL_MT_IFMON_LT_FAIL_DATA_LOCK(unit)   hal_mt_ifmon_lt_fail_data_lock(unit)
#define HAL_MT_IFMON_LT_FAIL_DATA_UNLOCK(unit) hal_mt_ifmon_lt_fail_data_unlock(unit)

#define HAL_MT_IFMON_LT_FAIL_FLOW_LOCK(unit)   hal_mt_ifmon_lt_fail_flow_lock(unit)
#define HAL_MT_IFMON_LT_FAIL_FLOW_UNLOCK(unit) hal_mt_ifmon_lt_fail_flow_unlock(unit)

#define HAL_MT_IFMON_ANLT_FSM_DATA_LOCK(unit)   hal_mt_ifmon_anlt_fsm_data_lock(unit)
#define HAL_MT_IFMON_ANLT_FSM_DATA_UNLOCK(unit) hal_mt_ifmon_anlt_fsm_data_unlock(unit)

#define HAL_MT_IFMON_ANLT_FSM_FLOW_LOCK(unit)   hal_mt_ifmon_anlt_fsm_flow_lock(unit)
#define HAL_MT_IFMON_ANLT_FSM_FLOW_UNLOCK(unit) hal_mt_ifmon_anlt_fsm_flow_unlock(unit)

/* DATA TYPE DECLARATIONS
 */

typedef uint32 HAL_MT_IFMON_LANE_BITMAP_T[HAL_MT_IFMON_LANE_BITMAP_SIZE];
typedef uint32 HAL_MT_IFMON_SPEED_BITMAP_T[HAL_MT_IFMON_SPEED_BITMAP_SIZE];
typedef uint32 HAL_MT_IFMON_ANLT_BITMAP_T[CLX_PORT_BITMAP_SIZE];
typedef uint32 HAL_MT_IFMON_PORT_BITMAP_T[CLX_PORT_BITMAP_SIZE];

typedef enum hal_mt_ifmon_speed_bitmap_type_e {
    HAL_MT_IFMON_SPEED_BITMAP_DIS = 0,
    HAL_MT_IFMON_SPEED_BITMAP_10M = 1,
    HAL_MT_IFMON_SPEED_BITMAP_100M = 2,
    HAL_MT_IFMON_SPEED_BITMAP_1G = 3,
    HAL_MT_IFMON_SPEED_BITMAP_2P5G = 4,
    HAL_MT_IFMON_SPEED_BITMAP_5G = 5,
    HAL_MT_IFMON_SPEED_BITMAP_10G = 6,
    HAL_MT_IFMON_SPEED_BITMAP_25G = 7,
    HAL_MT_IFMON_SPEED_BITMAP_40G = 8,
    HAL_MT_IFMON_SPEED_BITMAP_50G = 9,
    HAL_MT_IFMON_SPEED_BITMAP_100G = 10,
    HAL_MT_IFMON_SPEED_BITMAP_200G = 11,
    HAL_MT_IFMON_SPEED_BITMAP_400G = 12,
    HAL_MT_IFMON_SPEED_BITMAP_800G = 13,
    HAL_MT_IFMON_SPEED_BITMAP_LAST = 14
} hal_mt_ifmon_speed_bitmap_type_t;

typedef enum hal_mt_ifmon_wbdb_id_e {
    HAL_MT_IFMON_WBDB_ID_MONITOR_STATE = 0,
    HAL_MT_IFMON_WBDB_ID_MODE,
    HAL_MT_IFMON_WBDB_ID_INTERVAL,
    HAL_MT_IFMON_WBDB_ID_CUR_STATUS,
    HAL_MT_IFMON_WBDB_ID_STM_STATE,
    HAL_MT_IFMON_WBDB_ID_SW_EN,
    HAL_MT_IFMON_WBDB_ID_SW_STATUS,
    HAL_MT_IFMON_WBDB_ID_CUR_SPEED,
    HAL_MT_IFMON_WBDB_ID_PREV_BITMAP,
    HAL_MT_IFMON_WBDB_ID_MONITOR_PORT,
    HAL_MT_IFMON_WBDB_ID_MONITOR_ANLT,
    HAL_MT_IFMON_WBDB_ID_MONITOR_ANLT_FSM,
    HAL_MT_IFMON_WBDB_ID_MONITOR_LT_FAIL,
    HAL_MT_IFMON_WBDB_ID_LAST
} hal_mt_ifmon_wbdb_id_t;

typedef enum hal_mt_ifmon_type_e {
    HAL_MT_IFMON_TYPE_DEV = 0,
    HAL_MT_IFMON_TYPE_HOST,
    HAL_MT_IFMON_TYPE_INTR,
    HAL_MT_IFMON_TYPE_LAST
} hal_mt_ifmon_type_t;

typedef enum hal_mt_ifmon_fault_type_e {
    HAL_MT_IFMON_FAULT_TYPE_LOCAL = 0,
    HAL_MT_IFMON_FAULT_TYPE_REMOTE,
    HAL_MT_IFMON_FAULT_TYPE_LAST
} hal_mt_ifmon_fault_type_t;

typedef struct hal_mt_ifmon_notify_handler_s {
    clx_port_ifmon_notify_func_t notify_func;
    void *ptr_cookie;
} hal_mt_ifmon_notify_handler_t;

typedef enum hal_mt_ifmon_stm_even_e {
    HAL_MT_IFMON_STM_EVENT_NA = 0,
    HAL_MT_IFMON_STM_EVENT_DN,
    HAL_MT_IFMON_STM_EVENT_MS,
    HAL_MT_IFMON_STM_EVENT_RF,
    HAL_MT_IFMON_STM_EVENT_UP,
    HAL_MT_IFMON_STM_EVENT_LAST

} hal_mt_ifmon_stm_even_t;

typedef enum hal_mt_ifmon_stm_state_e {
    HAL_MT_IFMON_STM_STATE_DN = 0,
    HAL_MT_IFMON_STM_STATE_RF,
    HAL_MT_IFMON_STM_STATE_UP,
    HAL_MT_IFMON_STM_STATE_LAST

} hal_mt_ifmon_stm_state_t;

typedef union hal_mt_ifmon_stm_status_u {
    uint32 value;

    struct {                    /* bit field (0: false, 1: true) */
        uint32 rx_link : 1;     /* receving link up      */
        uint32 rx_lf : 1;       /* receving local fault  */
        uint32 rx_rf : 1;       /* receving remote fault */
        uint32 link_change : 1; /* link change           */
    } field;
} hal_mt_ifmon_stm_status_t;

typedef struct hal_mt_ifmon_stm_db_s {
    hal_mt_ifmon_stm_state_t last_state;
    hal_mt_ifmon_stm_status_t status;
    hal_mt_ifmon_stm_even_t event;
    hal_mt_ifmon_stm_state_t cur_state;

    /* private data structure */
    clx_time_t time;
    uint32 port;

#define HAL_MT_IFMON_STM_DB_FLAGS_VALID  (1U << 0)
#define HAL_MT_IFMON_STM_DB_FLAGS_FORCED (1U << 1)
    uint32 flags;

} hal_mt_ifmon_stm_db_t;

typedef struct hal_mt_ifmon_stm_dbg_s {
    hal_mt_ifmon_stm_db_t db[HAL_MT_IFMON_DBG_ENTRY_NUM];
    uint32 idx;

} hal_mt_ifmon_stm_dbg_t;

typedef struct hal_mt_ifmon_cb_s {
    clx_semaphore_id_t sem_data;
    clx_semaphore_id_t sem_flow;
    boolean monitor_state;
    clx_thread_id_t thread_id;
    clx_port_ifmon_mode_t mode;
    uint32 interval_us;

    HAL_MT_IFMON_LANE_BITMAP_T monitor_port;
    HAL_MT_IFMON_SPEED_BITMAP_T dev_speed;
    HAL_MT_IFMON_LANE_BITMAP_T dev_link;
    HAL_MT_IFMON_LANE_BITMAP_T dev_lf;
    HAL_MT_IFMON_LANE_BITMAP_T dev_rf;
    HAL_MT_IFMON_LANE_BITMAP_T dev_lc;
    HAL_MT_IFMON_LANE_BITMAP_T dev_fault;
    HAL_MT_IFMON_PORT_BITMAP_T dev_hiber;

    HAL_MT_IFMON_SPEED_BITMAP_T cur_speed;
    hal_mt_ifmon_stm_status_t cur_status[CLX_PORT_NUM];

    uint32 sw_en[CLX_PORT_NUM];
    hal_mt_ifmon_stm_status_t sw_status[CLX_PORT_NUM];

    uint32 callback_cnt;
    hal_mt_ifmon_notify_handler_t notify_handler[HAL_MT_IFMON_NOTIFY_HANDLER_CNT];
    util_lib_list_t *ptr_callback_list;
    hal_mt_ifmon_stm_db_t stm_db[CLX_PORT_NUM];
    hal_mt_ifmon_stm_dbg_t dbg_flow;
    hal_mt_ifmon_stm_dbg_t dbg_warn;

    clx_semaphore_id_t anlt_sem_data;
    clx_semaphore_id_t anlt_sem_flow;
    clx_thread_id_t anlt_thread_id;
    clx_port_ifmon_mode_t anlt_mode;
    uint32 anlt_interval_us;
    HAL_MT_IFMON_ANLT_BITMAP_T anlt_mon_bitmap;
    HAL_MT_IFMON_ANLT_BITMAP_T anlt_np_bitmap;
    hal_mt_ifmon_stm_dbg_t dbg_anlt;

    clx_semaphore_id_t lt_fail_sem_data;
    clx_semaphore_id_t lt_fail_sem_flow;
    clx_thread_id_t lt_fail_thread_id;
    clx_port_ifmon_mode_t lt_fail_mode;
    uint32 lt_fail_interval_us;
    HAL_MT_IFMON_ANLT_BITMAP_T lt_fail_mon_bitmap;
    HAL_MT_IFMON_ANLT_BITMAP_T lt_fail_bitmap;
    hal_mt_ifmon_stm_dbg_t dbg_lt_fail;

    clx_semaphore_id_t anlt_fsm_sem_data;
    clx_semaphore_id_t anlt_fsm_sem_flow;
    clx_thread_id_t anlt_fsm_thread_id;
    clx_port_ifmon_mode_t anlt_fsm_mode;
    uint32 anlt_fsm_interval_us;
    HAL_MT_IFMON_ANLT_BITMAP_T anlt_fsm_mon_bitmap;
} hal_mt_ifmon_cb_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Initialize IfMon function.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_init(const uint32 unit);

/**
 * @brief Deinitialize IfMon function.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_deinit(const uint32 unit);

/**
 * @brief Lock the data of IfMon.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_data_lock(const uint32 unit);

clx_error_no_t
hal_mt_ifmon_anlt_data_lock(const uint32 unit);
clx_error_no_t
hal_mt_ifmon_anlt_data_unlock(const uint32 unit);
clx_error_no_t
hal_mt_ifmon_anlt_flow_lock(const uint32 unit);
clx_error_no_t
hal_mt_ifmon_anlt_flow_unlock(const uint32 unit);

clx_error_no_t
hal_mt_ifmon_lt_fail_data_lock(const uint32 unit);
clx_error_no_t
hal_mt_ifmon_lt_fail_data_unlock(const uint32 unit);
clx_error_no_t
hal_mt_ifmon_lt_fail_flow_lock(const uint32 unit);
clx_error_no_t
hal_mt_ifmon_lt_fail_flow_unlock(const uint32 unit);

clx_error_no_t
hal_mt_ifmon_anlt_fsm_data_lock(const uint32 unit);
clx_error_no_t
hal_mt_ifmon_anlt_fsm_data_unlock(const uint32 unit);
clx_error_no_t
hal_mt_ifmon_anlt_fsm_flow_lock(const uint32 unit);
clx_error_no_t
hal_mt_ifmon_anlt_fsm_flow_unlock(const uint32 unit);
/**
 * @brief Unlock the data of IfMon.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_data_unlock(const uint32 unit);

/**
 * @brief Lock the flow of IfMon.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_flow_lock(const uint32 unit);

/**
 * @brief Unlock the flow of IfMon.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_flow_unlock(const uint32 unit);

/**
 * @brief To get monitor state.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_enable    - Pointer for monitor state.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_monitor_state_get(const uint32 unit, boolean *ptr_enable);

/**
 * @brief To set monitor state.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    enable    - Monitor state.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_monitor_state_set(const uint32 unit, const boolean enable);

/**
 * @brief To handle interrupt service routine.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    isr_cookie    - ISR cookie.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_isr_handle(const uint32 unit, const uint32 isr_cookie);

/**
 * @brief To set speed bitmap.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     type            - Database type.
 * @param [out]    speed_bitmap    - Speed bitmap.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_speed_bitmap_set(const uint32 unit,
                              const hal_mt_ifmon_type_t type,
                              HAL_MT_IFMON_SPEED_BITMAP_T speed_bitmap);

/**
 * @brief To get speed bitmap.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     type            - Database type.
 * @param [out]    speed_bitmap    - Speed bitmap.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_speed_bitmap_get(const uint32 unit,
                              const hal_mt_ifmon_type_t type,
                              HAL_MT_IFMON_SPEED_BITMAP_T speed_bitmap);

/**
 * @brief To set link port bitmap.
 *
 * @param [in]     unit           - Device unit number.
 * @param [out]    link_bitmap    - Link port bitmap.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_link_bitmap_set(const uint32 unit, HAL_MT_IFMON_LANE_BITMAP_T link_bitmap);

/**
 * @brief To get link port bitmap.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     type           - Database type.
 * @param [out]    link_bitmap    - Link port bitmap.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_link_bitmap_get(const uint32 unit,
                             const hal_mt_ifmon_type_t type,
                             HAL_MT_IFMON_LANE_BITMAP_T link_bitmap);

/**
 * @brief To get local/remote fault port bitmap.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     type            - Database type.
 * @param [out]    fault_bitmap    - Local/Remote fault port bitmap.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_fault_type_bitmap_get(const uint32 unit,
                                   const hal_mt_ifmon_fault_type_t type,
                                   HAL_MT_IFMON_LANE_BITMAP_T fault_bitmap);

/**
 * @brief To record time for time type.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    time_type    - Time type.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_time_record(const uint32 unit, const HAL_IFMON_TIME_T time_type);

/**
 * @brief To get port speed.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port ID.
 * @param [out]    ptr_speed    - Pointer for port speed.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_speed_get(const uint32 unit, const uint32 port, clx_port_speed_t *ptr_speed);

/**
 * @brief To set port speed.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port ID.
 * @param [in]    speed    - Port speed.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_speed_set(const uint32 unit, const uint32 port, const clx_port_speed_t speed);

/**
 * @brief To get port link.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [out]    ptr_link    - Pointer for port link.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_link_get(const uint32 unit, const uint32 port, uint32 *ptr_link);

/**
 * @brief To get port fault.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port ID.
 * @param [out]    ptr_fault    - Pointer for port fault.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_sw_fault_get(const uint32 unit, const uint32 port, uint32 *ptr_fault);

/**
 * @brief To clear default ifmon cfg for the destroyed port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Reset port default fail.
 */
clx_error_no_t
hal_mt_ifmon_default_reset(const uint32 unit, const uint32 port);

/**
 * @brief To register a callback function to handle a port link change.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    notify_func    - Callback function.
 * @param [in]    ptr_cookie     - Cookie data of callback function.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_register(const uint32 unit,
                      const clx_port_ifmon_notify_func_t notify_func,
                      void *ptr_cookie);

/**
 * @brief To deregister a callback function from callback functions.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    notify_func    - Callback function.
 * @param [in]    ptr_cookie     - Cookie data of callback function.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_deregister(const uint32 unit,
                        const clx_port_ifmon_notify_func_t notify_func,
                        void *ptr_cookie);

/**
 * @brief To get callback function count.
 *
 * @param [in]     unit                - Device unit number.
 * @param [out]    ptr_callback_cnt    - Pointer for callback function count.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_cb_cnt_get(const uint32 unit, uint32 *ptr_callback_cnt);

/**
 * @brief This API is used to get interface monitor mode, interface monitor port bitmap and
 *        interface monitor interval.
 *
 * The polling interval is valid if and only if the interface monitor
 * polling mode is used.
 *
 * @param [in]     unit               - Device unit number.
 * @param [out]    ptr_mode           - Pointer for interface monitor mode.
 * @param [out]    ptr_port_bitmap    - Pointer for interface monitor port bitmap.
 * @param [out]    ptr_interval_us    - Pointer for interface monitor polling interval in
 *                                      microseconds.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_mode_get(const uint32 unit,
                      clx_port_ifmon_mode_t *ptr_mode,
                      clx_port_bitmap_t *ptr_port_bitmap,
                      uint32 *ptr_interval_us);

/**
 * @brief This API is used to set interface monitor mode, interface monitor port bitmap and
 *        interface monitor interval.
 *
 * The polling interval is valid if and only if the interface monitor
 * polling mode is used.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    mode           - Interface monitor mode.
 * @param [in]    port_bitmap    - Interface monitor port bitmap.
 * @param [in]    interval_us    - Interface monitor polling interval in microseconds.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_mode_set(const uint32 unit,
                      const clx_port_ifmon_mode_t mode,
                      const clx_port_bitmap_t port_bitmap,
                      const uint32 interval_us);

/**
 * @brief To get port eee mode.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [out]    ptr_mode    - Pointer for port eee mode.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_port_eee_mode_get(const uint32 unit, const uint32 port, clx_port_eee_mode_t *ptr_mode);

/**
 * @brief To set port eee mode.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @param [in]    mode    - Interface monitor mode.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_port_eee_mode_set(const uint32 unit,
                               const uint32 port,
                               const clx_port_eee_mode_t mode);

/**
 * @brief To update sw state if port is at mac loopback or at uni-directional link.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port ID.
 * @param [out]    ptr_updated    - State is updated or not.
 * @return         CLX_E_OK    - Operation is successfully. CLX_E_BAD_PARAMETER - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_sw_state_update(const uint32 unit, const uint32 port, uint32 *ptr_updated);

/**
 * @brief To dump device/host link state.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK    - Operation is successfully. CLX_E_BAD_PARAMETER - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_link_state_dump(const uint32 unit);

/**
 * @brief To add monitored port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_port_mon_add(const uint32 unit, const uint32 port);

/**
 * @brief To delete monitored port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_port_mon_del(const uint32 unit, const uint32 port);

/**
 * @brief Add port bit to anlt bitmap.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Device port id.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_ifmon_anlt_mon_add(const uint32 unit, const uint32 port);

/**
 * @brief Del the port bit from anlt bitmap.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Device port id.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_ifmon_anlt_mon_del(const uint32 unit, const uint32 port);

/**
 * @brief Add port bit to LT failure monitor bitmap.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Device port id.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_ifmon_lt_fail_mon_add(const uint32 unit, const uint32 port);

/**
 * @brief Del the port bit from LT failure monitor bitmap.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Device port id.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_ifmon_lt_fail_mon_del(const uint32 unit, const uint32 port);

/**
 * @brief Dump the database per physical port.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    flags    - Database type.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_ifmon_db_dump(const uint32 unit, const uint32 flags);

/**
 * @brief Add port bit to anlt fsm monitor bitmap.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Device port id.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_ifmon_anlt_fsm_mon_add(const uint32 unit, const uint32 port);

/**
 * @brief Del the port bit from anlt fsm monitor bitmap.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Device port id.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_ifmon_anlt_fsm_mon_del(const uint32 unit, const uint32 port);

clx_error_no_t
hal_mt_ifmon_port_mon_get(const uint32 unit, const uint32 port, uint32 *valid);
clx_error_no_t
hal_mt_ifmon_anlt_mon_get(const uint32 unit, const uint32 port, uint32 *valid);

clx_error_no_t
hal_mt_ifmon_lt_fail_mon_get(const uint32 unit, const uint32 port, uint32 *valid);

clx_error_no_t
hal_mt_ifmon_anlt_fsm_mon_get(const uint32 unit, const uint32 port, uint32 *valid);

clx_error_no_t
hal_mt_ifmon_lt_failure_intr_unmask(const uint32 unit, uint32 enable);
#endif /* #ifndef HAL_MT_IFMON_H */
