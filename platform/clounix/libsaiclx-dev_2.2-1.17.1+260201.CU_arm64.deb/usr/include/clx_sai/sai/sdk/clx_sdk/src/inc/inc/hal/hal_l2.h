/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_l2.h
 * PURPOSE:
 *    Provide HAL driver API functions of L2 module.
 *
 * NOTES:
 *
 */

#ifndef HAL_L2_H
#define HAL_L2_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_l2.h>
#include <hal/hal_const_cmn.h>
#include <hal/hal_lag.h>
#include <hal/hal_vlan.h>
#include <hal/hal_stk.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_L2_FDB_ENTRY_MCAST_CP_TO_CPU_IDX (1)
#define HAL_L2_FDB_ENTRY_UCAST_CP_TO_CPU_IDX (1)
#define HAL_L2_FDB_NOTIFY_HANDLER_NUM        (4)
#define HAL_L2_FDB_SW_LEARN_HANDLER_NUM      (4)

#define HAL_L2_FDB_ENTRY_WORDS_MAX (MT_NB_CDB_FPU_HSH_L2_WORDS)

#define HAL_L2_FDB_MUTEX_SEMA_NAME      ("FDB_MUTEX_SEMA")
#define HAL_L2_NOTIFY_MUTEX_SEMA_NAME   ("NOTIFY_MUTEX_SEMA")
#define HAL_L2_SW_LEARN_MUTEX_SEMA_NAME ("SW_LEARN_MUTEX_SEMA")
#define HAL_L2_TRAV_MUTEX_SEMA_NAME     ("TRAV_MUTEX_SEMA")
#define HAL_L2_CALLBACK_MUTEX_SEMA_NAME ("CALLBACK_MUTEX_SEMA")

#define HAL_L2_TRAV_FDB_DMA_ENTRY_NUM    (512)
#define HAL_L2_TRAV_FDB_SLEEP_USEC       (5 * 1000)
#define HAL_L2_TRAV_FDB_SLEEP_TH_DMA_NUM (16)

#define HAL_L2_FAST_CMD_DONE_POLLING_USEC (1000)
#define HAL_L2_FAST_CMD_ENTRY_WORDS       (6)
#define HAL_L2_FAST_CMD_TCAM_ENTRY_WORDS  (8)

#define HAL_L2_AGE_SEC_MIN     (3)
#define HAL_L2_AGE_SEC_MAX     (3145725) /* (2^20 - 1) * 3 */
#define HAL_L2_AGE_STEPS       (4)
#define HAL_L2_AGE_SEC_DEFAULT (300)

#define HAL_L2_MCAST_FDB_MUTEX_SEMA_NAME       ("MCAST_FDB_MUTEX_SEMA")
#define HAL_L2_MCAST_FDB_INDIR_RSLT_IDX_OFFSET (0x40000) /* (8 * 16k) */

#define HAL_L2_DEFAULT_MIR_KEEP_IGR_VLAN_TAGS (0)
#define HAL_L2_DI_FORWARD_DROP(unit)          (HAL_DROP_MIN(unit))

#define HAL_L2_OPERATING_MODE_FIFO (1)

#define HAL_L2_FIFO_TASK_NAME                 ("L2_FIFO_TASK")
#define HAL_L2_FIFO_READ_PTR_UPDATE_THRESHOLD (42)
#define HAL_L2_FIFO_TASK_SLEEP_USEC           (10 * 1000)
#define HAL_L2_FIFO_TASK_SLEEP_TH_ENTRY_NUM   (HAL_L2_FIFO_READ_PTR_UPDATE_THRESHOLD * 256)
#define HAL_L2_FIFO_RING_BUF_EXTRA_ENTRY_NUM  (16 * 1024)
#define HAL_L2_FIFO_ENTRY_BYTES               (32)
#define HAL_L2_FIFO_UPLOAD_TH_FILL_COUNT      (42)
#define HAL_L2_FIFO_UPLOAD_TH_TIME            (100)
#define HAL_L2_FIFO_MAX_RING_BUF_ENTRY_NUM    (65535)
#define HAL_L2_FIFO_FDB_AVL_NAME              ("FIFO_FDB_AVL")
#define HAL_L2_FIFO_MC_FDB_AVL_NAME           ("FIFO_MC_FDB_AVL")

#define HAL_L2_POLLING_TASK_NAME       ("POLLING_TASK")
#define HAL_L2_POLLING_TASK_SLEEP_USEC (10 * 1000)

#define HAL_L2_TRAV_TASK_NAME ("TRAV_TASK")

#define HAL_L2_MCAST_MBR_GET_FLAGS_MATCH_ENABLE         (1 << 0)
#define HAL_L2_MCAST_MBR_GET_FLAGS_FL_FROM_REMOTE_DB    (1 << 1)
#define HAL_L2_MCAST_MBR_GET_FLAGS_LAG_FROM_REMOTE_DB   (1 << 2)
#define HAL_L2_MCAST_MBR_GET_FLAGS_PORT_FROM_REMOTE_DB  (1 << 3)
#define HAL_L2_MCAST_MBR_GET_FLAGS_FL_FROM_LOCAL_DB     (1 << 4)
#define HAL_L2_MCAST_MBR_GET_FLAGS_NON_FL_FROM_LOCAL_DB (1 << 5)

#define HAL_L2_MCAST_MBR_GET_FLAGS_ALL_FROM_REMOTE_DB \
    (HAL_L2_MCAST_MBR_GET_FLAGS_FL_FROM_REMOTE_DB |   \
     HAL_L2_MCAST_MBR_GET_FLAGS_LAG_FROM_REMOTE_DB |  \
     HAL_L2_MCAST_MBR_GET_FLAGS_PORT_FROM_REMOTE_DB)
#define HAL_L2_MCAST_MBR_GET_FLAGS_ALL_FROM_LOCAL_DB \
    (HAL_L2_MCAST_MBR_GET_FLAGS_FL_FROM_LOCAL_DB | HAL_L2_MCAST_MBR_GET_FLAGS_NON_FL_FROM_LOCAL_DB)

#define HAL_L2_MCAST_MBR_GET_FLAGS_NON_LAG_FROM_REMOTE_DB \
    (HAL_L2_MCAST_MBR_GET_FLAGS_ALL_FROM_REMOTE_DB & ~HAL_L2_MCAST_MBR_GET_FLAGS_LAG_FROM_REMOTE_DB)

/* default: filter local_fl and remote_lag */
#define HAL_L2_MCAST_MBR_GET_FLAGS_DEFAULT                                                       \
    (HAL_L2_MCAST_MBR_GET_FLAGS_MATCH_ENABLE | HAL_L2_MCAST_MBR_GET_FLAGS_NON_FL_FROM_LOCAL_DB | \
     HAL_L2_MCAST_MBR_GET_FLAGS_NON_LAG_FROM_REMOTE_DB)

#define HAL_L2_MCAST_MBR_GET_FLAGS_FL_AUTO_ASSIGN \
    (HAL_L2_MCAST_MBR_GET_FLAGS_MATCH_ENABLE | HAL_L2_MCAST_MBR_GET_FLAGS_FL_FROM_LOCAL_DB)

/* port 256, tile 24, 16K per tile, notify node size is 28B */
#define HAL_L2_NOTIFY_LIST_DFLT_LEN ((256 * 24 * 16 * 1024) / 2)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_L2_LOG_ERR(...)  UTIL_LOG_PRINT(UTIL_LOG_L2, UTIL_LOG_ERR, ##__VA_ARGS__)
#define HAL_L2_LOG_WARN(...) UTIL_LOG_PRINT(UTIL_LOG_L2, UTIL_LOG_WARN, ##__VA_ARGS__)
#define HAL_L2_LOG_INFO(...) UTIL_LOG_PRINT(UTIL_LOG_L2, UTIL_LOG_INFO, ##__VA_ARGS__)

#define HAL_L2_TASK_LOG_ERR(...)  UTIL_LOG_PRINT(UTIL_LOG_L2_TASK, UTIL_LOG_ERR, ##__VA_ARGS__)
#define HAL_L2_TASK_LOG_WARN(...) UTIL_LOG_PRINT(UTIL_LOG_L2_TASK, UTIL_LOG_WARN, ##__VA_ARGS__)
#define HAL_L2_TASK_LOG_INFO(...) UTIL_LOG_PRINT(UTIL_LOG_L2_TASK, UTIL_LOG_INFO, ##__VA_ARGS__)

#define HAL_L2_FDB_LOCK(_unit_)                                           \
    HAL_COMMON_LOCK_RESOURCE(&_hal_l2_fdb_cb[(_unit_)].fdb_mutex_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_L2_FDB_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_l2_fdb_cb[(_unit_)].fdb_mutex_sema_id)
#define HAL_L2_NOTIFY_LOCK(_unit_)                                           \
    HAL_COMMON_LOCK_RESOURCE(&_hal_l2_fdb_cb[(_unit_)].notify_mutex_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_L2_NOTIFY_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_l2_fdb_cb[(_unit_)].notify_mutex_sema_id)
#define HAL_L2_SW_LEARN_LOCK(_unit_)                                           \
    HAL_COMMON_LOCK_RESOURCE(&_hal_l2_fdb_cb[(_unit_)].sw_learn_mutex_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_L2_SW_LEARN_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_l2_fdb_cb[(_unit_)].sw_learn_mutex_sema_id)
#define HAL_L2_MCAST_FDB_LOCK(_unit_)                                                 \
    HAL_COMMON_LOCK_RESOURCE(&_hal_l2_mcast_fdb_cb[(_unit_)].mcast_fdb_mutex_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_L2_MCAST_FDB_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_l2_mcast_fdb_cb[(_unit_)].mcast_fdb_mutex_sema_id)
#define HAL_L2_CALLBACK_LOCK(_unit_)                                            \
    HAL_COMMON_LOCK_RESOURCE(&_hal_l2_trav_cb[(_unit_)].callback_mutex_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_L2_CALLBACK_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_l2_trav_cb[(_unit_)].callback_mutex_sema_id)

#define HAL_L2_UI32_MSK(__bits__) (0xFFFFFFFF >> (32 - (__bits__)))
#define HAL_L2_UI32_FLD_MSK(__unit__, __tbl_id__, __fld_id__) \
    (HAL_L2_UI32_MSK((TOB_TABLE((__unit__), (__tbl_id__))->ptr_table_entry[(__fld_id__)].length)))

#define HAL_L2_PLANE_BMP_FOREACH(__unit__, __plane__)                           \
    for ((__plane__) = 0; (__plane__) < HAL_PLANE_NUM(__unit__); (__plane__)++) \
        if (UTIL_LIB_BMP_BIT_CHK((HAL_PLANE_BMP((__unit__))), (__plane__)))

#define HAL_L2_DP_PLANE_PORT_BMP_FOREACH(__dp_plane_port_bmp__, __dp_plane_port__)    \
    for ((__dp_plane_port__) = HAL_PLANE_ETH_DP_PORT_MIN;                             \
         (__dp_plane_port__) <= HAL_PLANE_ETH_DP_PORT_MAX_CMN; (__dp_plane_port__)++) \
        if (UTIL_LIB_BMP_BIT_CHK((__dp_plane_port_bmp__), (__dp_plane_port__)))

#define HAL_L2_PRINT_FDB_ENTRY(__flags__, __prefix_str__, __hw_fdb_entry__, __postfix_str__)    \
    do {                                                                                        \
        UTIL_LOG_PRINT(UTIL_LOG_L2, (__flags__), "%sfdb-entry=%08x.%08x.%08x.%08x.%08x.%08x%s", \
                       (__prefix_str__), (__hw_fdb_entry__)[5], (__hw_fdb_entry__)[4],          \
                       (__hw_fdb_entry__)[3], (__hw_fdb_entry__)[2], (__hw_fdb_entry__)[1],     \
                       (__hw_fdb_entry__)[0], (__postfix_str__));                               \
    } while (0)

#define HAL_L2_CHECK_FLD_RANGE_VALID(__unit__, __tbl_id__, __field_id__, __value__)        \
    do {                                                                                   \
        if (!HAL_IS_UI32_FLD_RANGE_VALID(__unit__, __tbl_id__, __field_id__, __value__)) { \
            HAL_L2_LOG_WARN("u=%u, invalid " #__value__ "=%d\n", __unit__, __value__);     \
            return CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                  \
    } while (0)

typedef enum hal_l2_perf_point_e {
    HAL_L2_PERF_POINT_FIFO_RX,
    HAL_L2_PERF_POINT_MAC_LEARN,
    HAL_L2_PERF_POINT_MAC_MOVE,
    HAL_L2_PERF_POINT_MAC_AGE_SCAN,
    HAL_L2_PERF_POINT_MAC_AGE_DEL,
    HAL_L2_PERF_POINT_UC_MAC_TRAV,
    HAL_L2_PERF_POINT_MC_MAC_TRAV,
    HAL_L2_PERF_POINT_MAC_REPLACE,
    HAL_L2_PERF_POINT_UC_MAC_HSH_ADD,
    HAL_L2_PERF_POINT_UC_MAC_TCAM_ADD,
    HAL_L2_PERF_POINT_UC_MAC_ENTRY_ADD,
    HAL_L2_PERF_POINT_UC_MAC_ENTRY_DEL,
    HAL_L2_PERF_POINT_LAST,
} hal_l2_perf_point_t;

typedef struct hal_l2_perf_info_s {
    uint64 start_num;
    uint64 end_num;
    uint64 first_time;
    clx_time_t start_time;
    clx_time_t end_time;
    clx_time_t total_time;
    clx_time_t max_cost_time;
    clx_time_t min_cost_time;
} hal_l2_perf_info_t;

#ifndef HAL_L2_DBG_PREF_EN
#define HAL_L2_DBG_PREF_EN
#endif

#ifdef HAL_L2_DBG_PREF_EN

extern hal_l2_perf_info_t _hal_l2_perf_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM][HAL_L2_PERF_POINT_LAST];

#define HAL_L2_PREF_START(__unit__, __point__)                                           \
    do {                                                                                 \
        clx_time_t time_us;                                                              \
        hal_l2_perf_info_t *ptr_perf_info = &(_hal_l2_perf_cb[(__unit__)][(__point__)]); \
                                                                                         \
        osal_time_get(&time_us);                                                         \
        if (!ptr_perf_info->first_time) {                                                \
            ptr_perf_info->first_time = time_us;                                         \
        }                                                                                \
        ptr_perf_info->start_time = time_us;                                             \
        ptr_perf_info->start_num++;                                                      \
    } while (0)

#define HAL_L2_PREF_END(__unit__, __point__)                                             \
    do {                                                                                 \
        clx_time_t time_us, cost_time;                                                   \
        hal_l2_perf_info_t *ptr_perf_info = &(_hal_l2_perf_cb[(__unit__)][(__point__)]); \
                                                                                         \
        osal_time_get(&time_us);                                                         \
        if (ptr_perf_info->start_time) {                                                 \
            ptr_perf_info->end_time = time_us;                                           \
            ptr_perf_info->end_num++;                                                    \
            cost_time = ptr_perf_info->end_time - ptr_perf_info->start_time;             \
            ptr_perf_info->total_time += cost_time;                                      \
            if (0 == ptr_perf_info->max_cost_time) {                                     \
                ptr_perf_info->max_cost_time = cost_time;                                \
            } else if (cost_time > ptr_perf_info->max_cost_time) {                       \
                ptr_perf_info->max_cost_time = cost_time;                                \
            }                                                                            \
            if (0 == ptr_perf_info->min_cost_time) {                                     \
                ptr_perf_info->min_cost_time = cost_time;                                \
            } else if (cost_time < ptr_perf_info->min_cost_time) {                       \
                ptr_perf_info->min_cost_time = cost_time;                                \
            }                                                                            \
        }                                                                                \
        ptr_perf_info->start_time = 0;                                                   \
    } while (0)
#else /* !HAL_L2_DBG_PREF_EN */

#define HAL_L2_PREF_START(__unit__, __point__)
#define HAL_L2_PREF_END(__unit__, __point__)

#endif

#define HAL_L2_GET_MCAST_EGR_PORT(_ptr_egr_intf_, _clx_port_) \
    do {                                                      \
        switch (_ptr_egr_intf_->type) {                       \
            case CLX_L2_MCAST_EGR_INTF_TYPE_PORT:             \
                _clx_port_ = _ptr_egr_intf_->port;            \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_L2:               \
                _clx_port_ = _ptr_egr_intf_->l2.port;         \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_TNL:              \
                _clx_port_ = _ptr_egr_intf_->tnl.port;        \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_SRV6:             \
                _clx_port_ = _ptr_egr_intf_->srv6.port;       \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_WLAN:             \
                _clx_port_ = _ptr_egr_intf_->wlan.port;       \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_MPLS:             \
                _clx_port_ = _ptr_egr_intf_->mpls.port;       \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_VM_ETAG:          \
            case CLX_L2_MCAST_EGR_INTF_TYPE_VM_VNTAG:         \
                _clx_port_ = _ptr_egr_intf_->vm.port;         \
                break;                                        \
            default:                                          \
                return CLX_E_BAD_PARAMETER;                   \
                break;                                        \
        }                                                     \
    } while (0)

#define HAL_L2_SET_MCAST_EGR_PORT(_ptr_egr_intf_, _clx_port_) \
    do {                                                      \
        switch (_ptr_egr_intf_->type) {                       \
            case CLX_L2_MCAST_EGR_INTF_TYPE_PORT:             \
                _ptr_egr_intf_->port = _clx_port_;            \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_L2:               \
                _ptr_egr_intf_->l2.port = _clx_port_;         \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_TNL:              \
                _ptr_egr_intf_->tnl.port = _clx_port_;        \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_SRV6:             \
                _ptr_egr_intf_->srv6.port = _clx_port_;       \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_WLAN:             \
                _ptr_egr_intf_->wlan.port = _clx_port_;       \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_MPLS:             \
                _ptr_egr_intf_->mpls.port = _clx_port_;       \
                break;                                        \
            default:                                          \
                return CLX_E_BAD_PARAMETER;                   \
                break;                                        \
        }                                                     \
    } while (0)

typedef struct hal_l2_cnt_s {
    /* add entry */
    uint32 add_entry_num;
    uint32 add_entry_llm_num;
    uint32 add_entry_search_err_num;
    uint32 add_entry_bad_param_num;
    uint32 add_entry_bmp_check_err_num;
    uint32 add_entry_hash_success_num;
    uint32 add_entry_hash_fail_num;
    uint32 add_entry_hash_full_num;
    uint32 add_entry_tcam_success_num;
    uint32 add_entry_tcam_fail_num;
    uint32 add_entry_tcam_full_num;
    uint32 add_entry_over_success_num;
    uint32 add_entry_over_del_hash_fail_num;
    uint32 add_entry_over_add_hash_fail_num;
    uint32 add_entry_llm_fail_num;
    uint32 update_entry_hash_fail_num;
    uint32 update_entry_tcam_fail_num;
    uint32 update_entry_hash_success_num;
    uint32 update_entry_tcam_success_num;

    /* del entry */
    uint32 del_entry_num;
    uint32 del_entry_llm_num;
    uint32 del_entry_bad_param_num;
    uint32 del_entry_search_err_num;
    uint32 del_entry_hash_success_num;
    uint32 del_entry_hash_fail_num;
    uint32 del_entry_tcam_success_num;
    uint32 del_entry_tcam_fail_num;
    uint32 del_entry_tcam_da_data_fail_num;
    uint32 del_entry_tcam_da_fpu_rslt_fail_num;
    uint32 del_entry_tcam_sa_data_fail_num;
    uint32 del_entry_tcam_sa_fpu_rslt_fail_num;

    /* fifo handle */
    uint32 fifo_entry_handle_num;
    uint32 fifo_entry_no_ptr_data_num;
    uint32 fifo_entry_no_ptr_src_addr_num;
    uint32 fifo_entry_data_size_err_num;
    uint32 fifo_entry_zero_data_num;
    uint32 fifo_entry_fabric_port_num;
    uint32 fifo_entry_invalid_plane_num;
    /* fifo add entry */
    uint32 fifo_add_entry_num;
    uint32 fifo_add_entry_trans_fail_num;
    uint32 fifo_add_entry_search_fail_num;
    uint32 fifo_add_entry_exit_num;

    /* fifo move entry */
    uint32 fifo_move_entry_num;
    uint32 fifo_move_entry_trans_fail_num;
    uint32 fifo_move_entry_search_fail_num;

    /* fifo del entry */
    uint32 fifo_del_entry_num;
    uint32 fifo_del_entry_tcam_num;
    uint32 fifo_del_entry_tcam_age_da_data_fail_num;
    uint32 fifo_del_entry_tcam_age_da_fpu_rslt_fail_num;
    uint32 fifo_del_entry_tcam_age_sa_data_fail_num;
    uint32 fifo_del_entry_tcam_age_sa_fpu_rslt_fail_num;
    uint32 fifo_del_entry_tcam_age_success_num;
    uint32 fifo_del_entry_tcam_no_age_num;
    uint32 fifo_del_entry_tcam_skip_num;
    uint32 fifo_del_entry_hash_num;
    uint32 fifo_del_entry_hash_skip_num;
    uint32 fifo_del_entry_hash_trans_fail_num;
    uint32 fifo_del_entry_hash_age_fail_num;
    uint32 fifo_del_entry_hash_age_success_num;
    uint32 fifo_del_entry_hash_no_age_num;

    /* fifo invalid entry */
    uint32 fifo_invalid_reason_num;

    /* notify */
    uint32 notify_back_pressure;
} hal_l2_cnt_t;
#ifndef HAL_L2_DBG_CNT_EN
#define HAL_L2_DBG_CNT_EN
#endif

#ifdef HAL_L2_DBG_CNT_EN
extern hal_l2_cnt_t _hal_l2_cnt_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

#define HAL_L2_CNT_ADD(unit, field)   \
    do {                              \
        _hal_l2_cnt_cb[unit].field++; \
    } while (0)
#else /* !HAL_L2_DBG_PREF_EN */

#define HAL_L2_CNT_ADD(unit, field)

#endif

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_l2_trav_action_e {
    HAL_L2_TRAV_ACTION_NOTIFY_CALLBACK = 0,
    HAL_L2_TRAV_ACTION_GET_COUNT = 1,
    HAL_L2_TRAV_ACTION_INIT_POLL = 2,
    HAL_L2_TRAV_ACTION_INIT_FIFO = 3,
} hal_l2_trav_action_t;

typedef enum hal_l2_fdb_hw_type_e {
    HAL_L2_FDB_HW_TYPE_HASH = 0,
    HAL_L2_FDB_HW_TYPE_TCAM,
    HAL_L2_FDB_HW_TYPE_HASH_2X,
} hal_l2_fdb_hw_type_t;
typedef enum hal_l2_type_e {
    HAL_L2_TYPE_UC = 0,
    HAL_L2_TYPE_MC,
} hal_l2_type_t;
typedef enum hal_l2_callback_reason_e {
    HAL_L2_CALLBACK_REASON_ADD = 0,
    HAL_L2_CALLBACK_REASON_MODIFY,
    HAL_L2_CALLBACK_REASON_DELETE,
    HAL_L2_CALLBACK_REASON_NEW_LEARN,
    HAL_L2_CALLBACK_REASON_MOVE,
    HAL_L2_CALLBACK_REASON_LAST,
} hal_l2_callback_reason_t;

typedef uint32 hal_l2_fast_cmd_entry_t[HAL_L2_FAST_CMD_ENTRY_WORDS];
typedef uint32 hal_l2_fast_cmd_tcam_entry_t[HAL_L2_FAST_CMD_TCAM_ENTRY_WORDS];

typedef uint32 hal_l2_fdb_entry_t[HAL_L2_FDB_ENTRY_WORDS_MAX];

typedef struct hal_l2_callback_info_s {
    hal_l2_callback_reason_t reason;
    clx_l2_addr_t addr;
} hal_l2_callback_info_t;

typedef struct hal_l2_bum_mc_id_s {
    uint32 bc;
    uint32 umc;
    uint32 uuc;
} hal_l2_bum_mc_id_t;

typedef struct hal_l2_grp_nbr_sn_info_s {
    uint32 sn;
    uint32 mel_id;
    clx_l2_mcast_egr_intf_t member_info;
} hal_l2_grp_nbr_sn_info_t;

typedef struct hal_l2_warm_grp_info_s {
    uint32 group_size;
    boolean not_allow_reuse;
    uint32 logical_mc_id_ref_cnt;
    union {
        clx_port_bitmap_t non_port_intf_pbm;
        uint32 logical_mc_id;
    };
} hal_l2_warm_grp_info_t;
typedef struct hal_l2_grp_info_s {
    uint32 group_size;       /* Number of group member. */
    uint32 group_size_fl;    /* Number of group member for FL. */
    boolean not_allow_reuse; /* Indicate this phy mcast id is not allowed to reuse.
                              * Only members with non replicate, non tnl and non fabric link
                              * mcast group can be reused.
                              */
    uint32 logical_mc_id_ref_cnt;
    union {
        clx_port_bitmap_t non_port_intf_pbm; /* Group member port bitmap. Used when not_allow_reuse
                                                is FALSE */
        uint32 logical_mc_id; /* The logical mcast id corresponding to this phy mcast id. Used when
                                 not_allow_reuse is TRUE */
    };
    util_lib_list_t *ptr_member_list; /* mcast group member list */
} hal_l2_grp_info_t;

typedef struct hal_l2_warm_grp_info_ext_s {
    uint32 group_size_fl;
    uint32 reserved_1;
    uint32 reserved_2;
    uint32 reserved_3;
} hal_l2_warm_grp_info_ext_t;

typedef struct hal_l2_mcast_fdb_cb_s {
    clx_semaphore_id_t mcast_fdb_mutex_sema_id; /* mcast group process sema */
    uint32 group_num;                           /* max mcast group number */
    uint32 **pptr_hsh_mc_sc_ref_cnt;            /* per plane db, not use */
    hal_l2_grp_info_t *ptr_group_info;          /* phy mcast group arry, index is phy mc id */
} hal_l2_mcast_fdb_cb_t;

typedef struct hal_l2_entry_idx_s {
    hal_l2_fdb_hw_type_t type;
    union {
        uint32 hash_idx; /* use for hash index,
                          * bit 0~14: idx, bit15~17: tile,
                          * bit 18~19: stage, bit 20~23: inst */
        uint32 tcam_id;  /* tcam allocate index */
    };
} hal_l2_entry_idx_t;
typedef struct hal_l2_fifo_sw_entry_s {
    uint32 fdid;                  /* avl key. NB */
    clx_mac_t clx_mac;            /* avl key. NB */
    uint32 is_valid;              /* Entry valid flag */
    uint32 is_new_learn;          /* NB not use */
    hal_l2_entry_idx_t entry_idx; /* NB, hw index include SW FPU info */
    uint32 age_event_bit;         /* NB, aging bitmap per HW FPU */
    uint32 logical_mc_id;         /* NB, For mc fdb */
    hal_l2_fdb_entry_t fdb_entry; /* HW entry info */
} hal_l2_fifo_sw_entry_t;

typedef struct hal_l2_fifo_cb_s {
    clx_thread_id_t fifo_task_id;

    hal_l2_fifo_sw_entry_t *ptr_sw_fdb;    /* SW buffer of UC address */
    hal_l2_fifo_sw_entry_t *ptr_sw_mc_fdb; /* SW buffer of MC address */
    uint8 *ptr_ring_buf_start_not_align;
    uint8 *ptr_ring_buf_start;
    uint8 *ptr_ring_buf_nxt_read;
    uint8 *ptr_ring_buf_desc_start_not_align; /* NB */
    uint8 *ptr_ring_buf_desc_start;           /* NB */
    uint32 ring_buf_entry_num;
    uint32 nxt_seq_num;                       /* work idx */
    util_lib_avl_head_t *ptr_fdb_avl;         /* NB, AVL tree of SW UC address */
    util_lib_avl_head_t *ptr_mc_fdb_avl;      /* NB, AVL tree of SW MC address */
} hal_l2_fifo_cb_t;

typedef struct hal_l2_fdb_notify_handler_s {
    clx_l2_addr_notify_func_t callback;
    void *ptr_cookie;
} hal_l2_fdb_notify_handler_t;
typedef struct hal_l2_fdb_sw_learn_handler_s {
    clx_l2_addr_sw_learn_func_t callback;
    void *ptr_cookie;
} hal_l2_fdb_sw_learn_handler_t;

typedef struct hal_l2_fdb_cb_s {
    uint32 operating_mode;    /* 0:POLL, 1:FIFO */
    uint32 thread_pri;        /* Priority of FIFO task */
    uint32 thread_stack_size; /* Stack size of FIFO task */
    hal_l2_fifo_cb_t fifo_cb; /* Control block of FIFO */

    clx_semaphore_id_t fdb_mutex_sema_id;
    clx_semaphore_id_t notify_mutex_sema_id;         /* Protect notify callback and reg/dereg */
    clx_semaphore_id_t sw_learn_mutex_sema_id;       /* Protect sw learn callback and reg/dereg */
    uint32 entry_num;                                /* Specification of the UC address */
    hal_l2_fdb_notify_handler_t *ptr_notify_handler; /* Hander for event notify */
    hal_l2_fdb_sw_learn_handler_t *ptr_sw_learn_handler; /* Hander for event notify */

    void *ptr_trav_dma_fdb_entry_not_align; /* Unaligned buffer for DMA hw FDB entries */
    void *ptr_trav_dma_fdb_entry;           /* Buffer for DMA hw FDB entries */
#if defined(CLX_MOCK)
    uint32 use_entry_num;                   /* tmp for get usage in asicsim */
    uint32 use_mc_entry_num;                /* tmp for get usage in asicsim */
#endif
} hal_l2_fdb_cb_t;
typedef struct hal_l2_trav_callback_node_s {
    clx_l2_addr_trav_func_t uc_callback;
    clx_l2_mcast_addr_trav_func_t mc_callback;
} hal_l2_trav_callback_node_t;
typedef struct hal_l2_trav_match_addr_s {
    clx_l2_addr_trav_match_t uc_addr;
    clx_l2_mcast_addr_trav_match_t mc_addr;
} hal_l2_trav_match_addr_t;
typedef struct hal_l2_trav_callback_info_s {
    hal_l2_type_t type;
    hal_l2_trav_callback_node_t callback;
    hal_l2_trav_match_addr_t match;
    void *cookie;
} hal_l2_trav_callback_info_t;

typedef clx_error_no_t (*hal_l2_addr_trav_sw_callback_t)(const uint32 unit,
                                                         const clx_l2_addr_t *ptr_addr,
                                                         const void *ptr_data,
                                                         void *ptr_cookie);

typedef clx_error_no_t (*hal_l2_sw_mcast_addr_trav_callback_t)(const uint32 unit,
                                                               const clx_l2_mcast_addr_t *ptr_addr,
                                                               const void *ptr_data,
                                                               void *ptr_cookie);
typedef union hal_l2_trav_sw_callback_node_u {
    hal_l2_addr_trav_sw_callback_t uc_callback;
    hal_l2_sw_mcast_addr_trav_callback_t mc_callback;
} hal_l2_trav_sw_callback_node_t;

typedef struct hal_l2_trav_sw_cookie_s {
    uint32 unit;
    hal_l2_type_t type;
    hal_l2_trav_sw_callback_node_t callback;
    hal_l2_trav_match_addr_t match;
    void *cookie;
} hal_l2_trav_sw_cookie_t;

typedef struct hal_l2_trav_non_blocking_cb_s {
    /* Thread control */
    clx_thread_id_t task_id;                   /* Task ID of the traverse thread */
    uint32 thread_pri;                         /* Priority of the traverse thread */
    uint32 thread_stack_size;                  /* Stack size of the traverse thread */
    clx_semaphore_id_t trav_mutex_sema_id;     /* Signal for traversing MAC entries */
    clx_semaphore_id_t callback_mutex_sema_id; /* Protect ptr_callback_list */

    /* User callback parameters */
    util_lib_list_t *ptr_callback_list; /* List for non-blocking traversal MAC entries */

} hal_l2_trav_non_blocking_cb_t;

typedef struct hal_l2_notify_s {
    uint32 len; /* default HAL_L2_NOTIFY_LIST_DFLT_LEN  */
    uint32 cur_node_num;
    uint32 not_enqueue_num;
} hal_l2_notify_t;

typedef struct hal_l2_mcast_remote_egr_intf_s {
    uint8 remote_type;
    uint32 di;
    union {
        uint32 lag_id;
        uint32 fl_id;
    };
    clx_l2_mcast_egr_intf_t egr_intf;
} hal_l2_mcast_remote_egr_intf_t;

typedef struct hal_l2_mcast_remote_egr_mbr_s {
    uint32 egr_intf_cnt;
    hal_l2_mcast_remote_egr_intf_t *ptr_remote_mbr_info;
} hal_l2_mcast_remote_egr_mbr_t;

typedef enum hal_l2_mcast_global_port_type_e {
    HAL_L2_MCAST_GLOBAL_PORT_TYPE_LOCAL = 0,
    HAL_L2_MCAST_GLOBAL_PORT_TYPE_REMOTE = 1,
    HAL_L2_MCAST_GLOBAL_PORT_TYPE_LAG = 2,
    HAL_L2_MCAST_GLOBAL_PORT_TYPE_FL = 3,
    HAL_L2_MCAST_GLOBAL_PORT_TYPE_LAST = 4,
} hal_l2_mcast_global_port_type_t;

typedef struct hal_l2_mcast_grp_fl_warm_info_s {
    uint32 fl_id_cnt;
    uint32 fl_refer_cnt[HAL_STK_PATH_GRP_NUM];
    uint32 remote_mbr_total_num;
    uint32 remote_mbr_num[HAL_L2_MCAST_GLOBAL_PORT_TYPE_LAST];
} hal_l2_mcast_grp_fl_warm_info_t;

typedef struct hal_l2_mcast_remote_egr_intf_node_s {
    uint32 unit;
    uint32 mcast_id;
    hal_l2_mcast_remote_egr_intf_t remote_info;
} hal_l2_mcast_remote_egr_intf_node_t;

typedef struct hal_l2_mcast_grp_fl_info_s {
    uint32 fl_id_cnt;
    uint32 fl_refer_cnt[HAL_STK_PATH_GRP_NUM];
    uint32 remote_mbr_total_num;
    uint32 remote_mbr_num[HAL_L2_MCAST_GLOBAL_PORT_TYPE_LAST];
    util_lib_list_t *ptr_remote_mbr_list;
} hal_l2_mcast_grp_fl_info_t;

typedef struct hal_l2_mcast_remote_fl_cb_s {
    uint32 group_num; /* max mcast group number */
    hal_l2_mcast_grp_fl_info_t *ptr_group_fl_info;
} hal_l2_mcast_remote_fl_cb_t;

typedef enum hal_l2_mcast_remote_action_e {
    HAL_L2_MCAST_REMOTE_ACTION_ADD = 0,
    HAL_L2_MCAST_REMOTE_ACTION_DEL = 1,
} hal_l2_mcast_remote_action_t;

typedef struct hal_l2_lag_remote_info_s {
    uint32 fl_id_cnt;
    uint32 fl_refer_cnt[HAL_STK_PATH_GRP_NUM];
    uint32 remote_mbr_num;
    uint32 remote_port[HAL_LAG_GROUP_MAX_MEMBER_NUM];
    uint32 remote_fl[HAL_LAG_GROUP_MAX_MEMBER_NUM];
} hal_l2_lag_remote_info_t;

typedef struct hal_l2_lag_local_info_s {
    uint32 local_mbr_num;
    uint32 local_port[HAL_LAG_GROUP_MAX_MEMBER_NUM];
} hal_l2_lag_local_info_t;

typedef struct hal_l2_lag_remote_mbr_fl_update_s {
    uint32 fl_id_cnt;
    uint32 fl_id_list[HAL_STK_PATH_GRP_NUM];
    int32 fl_refer_cnt[HAL_STK_PATH_GRP_NUM];
} hal_l2_lag_remote_mbr_fl_update_t;

typedef struct hal_l2_lag_info_mcast_id_node_s {
    uint32 mcast_id;
} hal_l2_lag_info_mcast_id_node_t;

typedef struct hal_l2_mcast_grp_lag_warm_info_s {
    hal_l2_lag_remote_info_t remote_info;
    hal_l2_lag_local_info_t local_info;
    uint32 mcast_grp_num;
} hal_l2_mcast_grp_lag_warm_info_t;

typedef struct hal_l2_mcast_grp_lag_info_s {
    hal_l2_lag_remote_info_t remote_info;
    hal_l2_lag_local_info_t local_info;
    uint32 mcast_grp_num;
    util_lib_list_t *ptr_mcast_grp_list;
} hal_l2_mcast_grp_lag_info_t;

typedef struct hal_l2_multi_fl_ref_s {
    uint32 di;
    uint32 fl_id_cnt;
    uint32 fl_id_list[HAL_STK_PATH_GRP_NUM];
    uint32 fl_refer_cnt[HAL_STK_PATH_GRP_NUM];
} hal_l2_multi_fl_ref_t;

typedef enum hal_l2_lag_remote_info_fl_opt_flag_e {
    HAL_L2_LAG_REMOTE_INFO_FL_OPT_FLAG_NONE = 0,
    HAL_L2_LAG_REMOTE_INFO_FL_OPT_FLAG_DEL = 1,
    HAL_L2_LAG_REMOTE_INFO_FL_OPT_FLAG_ADD = 2,
} hal_l2_lag_remote_info_fl_opt_flag_t;
/* STATIC VARIABLE DECLARATIONS
 */

/* GLOBAL VARIABLE DECLARATIONS
 */
extern hal_l2_fdb_cb_t _hal_l2_fdb_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
extern hal_l2_mcast_fdb_cb_t _hal_l2_mcast_fdb_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
extern hal_l2_trav_non_blocking_cb_t _hal_l2_trav_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
#define HAL_L2_NOTIFY_LIST_NUM (2)
extern hal_l2_notify_t _hal_l2_notify_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM][HAL_L2_NOTIFY_LIST_NUM];

extern hal_l2_mcast_remote_fl_cb_t _hal_l2_mcast_fl_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
extern hal_l2_mcast_grp_lag_info_t _hal_l2_mcast_grp_lag_info[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM]
                                                             [HAL_LAG_PORT_MAX_NUM];
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

int32
hal_l2_fdb_avl_node_cmp(void *ptr_user_param, void *ptr_user_data, void *ptr_node_data);

void
hal_l2_list_node_free(void *ptr_node_data);

void
hal_l2_avl_node_free(void *ptr_user_param, void *ptr_node_data);

void
hal_l2_addr_notify_cb(const uint32 unit,
                      const clx_l2_addr_notify_reason_t reason,
                      const clx_l2_addr_t *ptr_addr);

void
hal_l2_addr_sw_learn_cb(const uint32 unit,
                        const clx_l2_addr_sw_learn_reason_t reason,
                        const clx_l2_addr_t *ptr_addr);

void
hal_l2_notify_handle(const uint32 unit,
                     util_lib_list_t **ptr_cb_list,
                     util_lib_list_t *ptr_list_1,
                     util_lib_list_t *ptr_list_2);

void
hal_l2_notify_node_add(const uint32 unit,
                       const hal_l2_callback_reason_t reason,
                       const clx_l2_addr_t *ptr_addr,
                       const boolean is_list2,
                       util_lib_list_t *ptr_callback_list);

clx_error_no_t
hal_l2_trav_node_add(const uint32 unit,
                     const hal_l2_type_t type,
                     const hal_l2_trav_match_addr_t match,
                     const hal_l2_trav_callback_node_t callback,
                     void *ptr_cookie);

clx_error_no_t
hal_l2_addr_notify_cb_register(const uint32 unit,
                               const clx_l2_addr_notify_func_t callback,
                               void *ptr_cookie);

clx_error_no_t
hal_l2_addr_notify_cb_deregister(const uint32 unit,
                                 const clx_l2_addr_notify_func_t callback,
                                 void *ptr_cookie);

clx_error_no_t
hal_l2_addr_sw_learn_cb_register(const uint32 unit,
                                 const clx_l2_addr_sw_learn_func_t callback,
                                 void *ptr_cookie);

clx_error_no_t
hal_l2_addr_sw_learn_cb_deregister(const uint32 unit,
                                   const clx_l2_addr_sw_learn_func_t callback,
                                   void *ptr_cookie);

clx_error_no_t
hal_l2_port_is_my_chip_id_check(const uint32 unit,
                                const clx_port_t port,
                                boolean *ptr_is_my_chip_id);

void
hal_l2_sw_shadow_trav(const uint32 unit, const hal_l2_type_t type);

void
hal_l2_mc_mbr_trav(const uint32 unit, const uint32 mcast_id);

void
hal_l2_mcast_id_print(const uint32 unit, const uint32 tbl_id);

#if !defined(CLX_MOCK)
clx_error_no_t
hal_l2_dma_fifo_handle_register(uint32 unit, drv_dma_fifo_cb_t cb);

clx_error_no_t
hal_l2_dma_fifo_handle_deregister(uint32 unit);

#endif

#ifdef HAL_L2_DBG_PREF_EN

clx_error_no_t
hal_l2_perf_reset(const uint32 unit, const uint32 *ptr_point_bmp);

clx_error_no_t
hal_l2_perf_get(const uint32 unit, hal_l2_perf_info_t **ptr_perf_info, const char ***point_name);

#endif

#ifdef HAL_L2_DBG_CNT_EN

clx_error_no_t
hal_l2_cnt_reset(const uint32 unit);

clx_error_no_t
hal_l2_cnt_get(const uint32 unit, hal_l2_cnt_t **ptr_cnt_info);

#endif

clx_error_no_t
hal_l2_notify_print(const uint32 unit);

clx_error_no_t
hal_l2_notify_swc_cfg_set(const uint32 unit, const uint32 param0, const uint32 param1);

clx_error_no_t
hal_l2_notify_swc_cfg_get(const uint32 unit, uint32 *ptr_param0, uint32 *ptr_param1);

clx_port_t
hal_l2_mcast_egr_logical_port_get(const clx_l2_mcast_egr_intf_t *ptr_egr_intf);

clx_error_no_t
hal_l2_mcast_intf_local_port_check(const uint32 unit, const clx_port_t cl_port);

clx_error_no_t
hal_l2_unit_port_to_phy_port_trans(const uint32 unit, const clx_port_t port, clx_port_t *ptr_port);

clx_error_no_t
hal_l2_mcast_lag_port_bitmap_get(const uint32 unit,
                                 const clx_port_t lag_port,
                                 clx_port_bitmap_t lag_pbm);

clx_error_no_t
hal_l2_tob_entry_write(const tob_chip_info_t chip_info, const tob_entry_info_t *ptr_entry_info);

clx_error_no_t
hal_l2_tob_entry_read(const tob_chip_info_t chip_info, tob_entry_info_t *ptr_entry_info);

clx_error_no_t
hal_l2_tob_fields_write(const tob_chip_info_t chip_info,
                        const tob_entry_fields_info_t *ptr_fields_info);

/**
 * @brief This API is used to get egress interface count for a L2 multicast ID.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     mcast_id            - The L2 multicast ID.
 * @param [out]    ptr_egr_intf_cnt    - The egress interface count.
 * @return         CLX_E_OK        - Operation succeeded.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_l2_mcast_egr_intf_cnt_get(const uint32 unit, const uint32 mcast_id, uint32 *ptr_egr_intf_cnt);

/**
 * @brief This API is used to get egress interface for a L2 multicast ID.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     mcast_id       - The L2 multicast ID.
 * @param [out]    ptr_egr_mbr    - The egress interface list obtained.
 * @return         CLX_E_OK        - Operation succeeded.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_l2_mcast_egr_intf_get(const uint32 unit,
                          const uint32 mcast_id,
                          clx_l2_mcast_egr_mbr_t *ptr_egr_mbr);
boolean
hal_l2_mcast_remote_is_supported(const uint32 unit);

clx_error_no_t
hal_l2_mcast_fl_rsrc_init(const uint32 unit);

clx_error_no_t
hal_l2_mcast_fl_rsrc_deinit(const uint32 unit);

clx_error_no_t
hal_l2_mcast_fl_grp_info_destroy(const uint32 unit, const uint32 mcast_id);

clx_error_no_t
hal_l2_mcast_fl_grp_info_show(const uint32 unit,
                              const uint32 logical_mc_id,
                              const boolean ignore_null_member,
                              const boolean brief);

clx_error_no_t
hal_l2_mcast_local_group_info_show(const uint32 unit,
                                   const uint32 phy_mc_id,
                                   const boolean ignore_null_member,
                                   const boolean brief);

clx_error_no_t
hal_l2_mcast_lag_remote_info_show(const uint32 unit,
                                  const uint32 lag_id,
                                  const boolean ignore_null_member,
                                  const boolean brief);

clx_error_no_t
hal_l2_mcast_egr_intf_global_port_type_get(const uint32 unit,
                                           const clx_l2_mcast_egr_intf_t *ptr_egr_intf,
                                           hal_l2_mcast_global_port_type_t *ptr_port_type,
                                           clx_port_t *ptr_port);

clx_error_no_t
hal_l2_mcast_global_egr_intf_mbr_get(const uint32 unit,
                                     const uint32 mcast_id,
                                     const clx_l2_mcast_egr_mbr_t *ptr_egr_mbr,
                                     const hal_l2_mcast_remote_action_t action_flag,
                                     clx_l2_mcast_egr_mbr_t *ptr_egr_mbr_local,
                                     hal_l2_mcast_remote_egr_mbr_t *ptr_remote_info_mbr);

clx_error_no_t
hal_l2_mcast_remote_egr_intf_add(const uint32 unit,
                                 const uint32 mcast_id,
                                 const hal_l2_mcast_remote_egr_mbr_t *ptr_remote_info_mbr);

clx_error_no_t
hal_l2_mcast_remote_egr_intf_del(const uint32 unit,
                                 const uint32 mcast_id,
                                 const hal_l2_mcast_remote_egr_mbr_t *ptr_remote_info_mbr);

clx_error_no_t
hal_l2_mcast_remote_egr_intf_cnt_get(const uint32 unit,
                                     const uint32 mcast_id,
                                     uint32 match_flags,
                                     uint32 *ptr_cnt);

clx_error_no_t
hal_l2_mcast_remote_egr_intf_get(const uint32 unit,
                                 const uint32 mcast_id,
                                 const uint32 match_flags,
                                 clx_l2_mcast_egr_mbr_t *ptr_egr_mbr);

clx_error_no_t
hal_l2_mcast_remote_egr_intf_check(const uint32 unit,
                                   const uint32 mcast_id,
                                   const clx_l2_mcast_egr_intf_t egr_intf,
                                   boolean *ptr_is_exist);

clx_error_no_t
hal_l2_mcast_fl_grp_info_arr_get(const uint32 unit,
                                 hal_l2_mcast_grp_fl_warm_info_t **ptr_mc_group_info_arr);

void
hal_l2_mcast_fl_grp_info_restore(const uint32 unit,
                                 const uint32 group_num,
                                 const hal_l2_mcast_grp_fl_warm_info_t *ptr_mc_group_info_arr);

clx_error_no_t
hal_l2_mcast_grp_lag_info_arr_get(const uint32 unit,
                                  hal_l2_mcast_grp_lag_warm_info_t **ptr_mcast_group_lag_info_arr);

void
hal_l2_mcast_grp_lag_info_restore(
    const uint32 unit,
    const uint32 group_num,
    const hal_l2_mcast_grp_lag_warm_info_t *ptr_mcast_group_lag_info_arr);

clx_error_no_t
hal_l2_mcast_lag_rsrc_deinit(const uint32 unit);

clx_error_no_t
hal_l2_mcast_lag_rsrc_init(const uint32 unit);

clx_error_no_t
hal_l2_mcast_lag_member_update(const uint32 unit,
                               const uint32 lag_id,
                               const uint32 new_member_cnt,
                               const hal_lag_member_di_info_t *ptr_new_member_di);
#endif /* End of HAL_L2_H */
