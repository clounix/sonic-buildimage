/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_tm.h
 * PURPOSE: It provides Traffic Management Hardware Abstraction Layer for MT chip.
 * NOTES:
 *
 */

#ifndef HAL_MT_DIAG_H
#define HAL_MT_DIAG_H

#include <hal/hal.h>

/*****************************************************************************
 * NAMING CONSTANT DECLARATIONS
 *****************************************************************************
 */

#define MAX_TABLE_MATCHED_NAMES_COUNT 1024
#define MAX_TABLE_NAME_LENGTH         128

/* Stage type enumeration */
typedef enum hal_mt_diag_stage_type_e {
    HAL_MT_DIAG_STAGE_TYPE_CNT = 0,
    HAL_MT_DIAG_STAGE_TYPE_CNT_DROP,
    HAL_MT_DIAG_STAGE_TYPE_STA,
    HAL_MT_DIAG_STAGE_TYPE_CFG,
    HAL_MT_DIAG_STAGE_TYPE_FC,
    HAL_MT_DIAG_STAGE_TYPE_MAX
} hal_mt_diag_stage_type_t;

/* Keyword mapping structure */

typedef struct hal_mt_diag_keywords_base_s {
    const char **base_keywords;
    uint32_t base_keyword_count;
} hal_mt_diag_keywords_base_t;

typedef struct hal_mt_diag_keywords_sub_s {
    hal_mt_diag_keywords_base_t base;
    const char **sub_keywords;
    uint32_t sub_keyword_count;
} hal_mt_diag_keywords_sub_t;

typedef struct hal_mt_diag_stage_keyword_map_s {
    const char *stage_name;
    hal_mt_diag_keywords_sub_t stage_keywords;
} hal_mt_diag_stage_keyword_map_t;

/*****************************************************************************
 * FUNCTION DECLARATIONS
 *****************************************************************************
 */

clx_error_no_t
hal_mt_diag_init(const uint32 unit);

clx_error_no_t
hal_mt_diag_deinit(const uint32 unit);

clx_error_no_t
hal_mt_diag_reg_cfg_stage_get(const uint32 unit,
                              hal_diag_reg_stage_t **ptr_stage,
                              uint32 *ptr_stage_count);

clx_error_no_t
hal_mt_diag_reg_cnt_stage_get(const uint32 unit,
                              hal_diag_reg_stage_t **ptr_stage,
                              uint32 *ptr_stage_count);

clx_error_no_t
hal_mt_diag_reg_cnt_drop_stage_get(const uint32 unit,
                                   hal_diag_reg_stage_t **ptr_stage,
                                   uint32 *ptr_stage_count);

clx_error_no_t
hal_mt_diag_reg_sta_stage_get(const uint32 unit,
                              hal_diag_reg_stage_t **ptr_stage,
                              uint32 *ptr_stage_count);

clx_error_no_t
hal_mt_diag_reg_fc_stage_get(const uint32 unit,
                             hal_diag_reg_stage_t **ptr_stage,
                             uint32 *ptr_stage_count);
#endif /* End of HAL_MT_DIAG_H */
