/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  util_lib.h
 * PURPOSE:
 *  this file is used to provide public library operations to other users.
 * NOTES:
 */
#ifndef UTIL_LIB_H
#define UTIL_LIB_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <osal/osal.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define UTIL_LIB_NAME_LEN_MAX (32)

/* MACRO FUNCTION DECLARATIONS
 */

/**
 * @brief It is used to test if two 32-bit unsigned operand multiply will be overflow.
 *
 * @param [in]    ui32a    - Operand a.
 * @param [in]    ui32b    - Operand b.
 * @return        0    - Not overflow non 0 -- overflow.
 */
#define UTIL_LIB_MULTI_OVERFLOW_CHK(ui32a, ui32b) \
    ((ui32a) ? ((~0U / (uint32)(ui32a)) < (uint32)(ui32b)) : 0)

/**
 * @brief It is used to test if two operands add overflow.
 *
 * @param [in]    ui32a    - Operand a.
 * @param [in]    ui32b    - Operand b.
 * @return        0    - Not overflow non 0 -- overflow.
 */
#define UTIL_LIB_ADD_OVERFLOW_CHK(ui32a, ui32b) ((uint32)(ui32a) > ~((uint32)(ui32b)))

/**
 * @brief It is used to convert 2's complement to decimal.
 *
 * @param [in]    complement    - 2's complement.
 * @return        decimal    - Decimal.
 */
#define UTIL_LIB_COMPLEMENT_TO_DECIMAL(complement) \
    (((complement) & 0x80) == 0 ? (int)(complement) : -(int)(0x100 - (complement & 0xFF)))

/**
 * @brief It is used to convert decimal to 2's complement.
 *
 * @param [in]    decimal    - Decimal.
 * @return        complement    - 2's complement.
 */
#define UTIL_LIB_DECIMAL_TO_COMPLEMENT(decimal) \
    ((decimal) >= 0 ? (int32)(decimal) : (int32)(~((int32)(-(decimal))) + 1))

/* DATA TYPE DECLARATIONS
 */

typedef struct util_lib_dbg_list_node_s {
    void *ptr_data;
    struct util_lib_dbg_list_node_s *ptr_next;
} util_lib_dbg_list_node_t;

typedef struct util_lib_dbg_head_s {
    util_lib_dbg_list_node_t *ptr_front;
    clx_semaphore_id_t sem;
} util_lib_dbg_head_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

#endif /* End of UTIL_LIB_H */
