/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME: cdb.h
 * PURPOSE:
 *     Chip database (CDB) driver
 * NOTES:
 */

#ifndef CDB_H
#define CDB_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* special inst_idx for broadcast */
#define CDB_INST_IDX_BCAST               0xFFFFFFFF

/* MACRO FUNCTION DECLARATIONS
 */
/*
 * Example is as below.
 *  CLX_MAC_T clx_mac = {0x0, 0x1, 0x2, 0x3, 0x4, 0x5};
 *  UI32_T    hw_mac[2];
 *
 *  After CLX_MAC_TO_HW_MAC(hw_mac, clx_mac),
 *  hw_mac[0] = 0x02030405;
 *  hw_mac[1] = 0x0001;
 */
 #define CLX_MAC_TO_HW_MAC(__hw_mac__, __clx_mac__) do   \
        {                                                \
            (__hw_mac__)[0] = ((UI32_T)((__clx_mac__)[2]) << 24 |  \
                               (__clx_mac__)[3] << 16           |  \
                               (__clx_mac__)[4] << 8            |  \
                               (__clx_mac__)[5]);                  \
            (__hw_mac__)[1] = ((__clx_mac__)[0] << 8            |  \
                               (__clx_mac__)[1]);                  \
        } while (0)

/*
 * Example is as below.
 *  CLX_MAC_T clx_mac;
 *  UI32_T    hw_mac[2] = {0x02030405, 0x0001};
 *
 *  After HW_MAC_TO_CLX_MAC(clx_mac, hw_mac),
 *  clx_mac[2] = 0x02; clx_mac[3] = 0x03, clx_mac[4] = 0x4, clx_mac[5] = 0x5;
 *  clx_mac[0] = 0x00; clx_mac[1] = 0x01;
 */
#define HW_MAC_TO_CLX_MAC(__clx_mac__, __hw_mac__) do                   \
        {                                                               \
            (__clx_mac__)[0] = ((__hw_mac__)[1] & 0x0000FF00) >> 8;     \
            (__clx_mac__)[1] = ((__hw_mac__)[1] & 0x000000FF);          \
            (__clx_mac__)[2] = ((__hw_mac__)[0] & 0xFF000000) >> 24;    \
            (__clx_mac__)[3] = ((__hw_mac__)[0] & 0x00FF0000) >> 16;    \
            (__clx_mac__)[4] = ((__hw_mac__)[0] & 0x0000FF00) >> 8;     \
            (__clx_mac__)[5] = ((__hw_mac__)[0] & 0x000000FF);          \
        } while (0)
/*
 * Example is as below.
 *  CLX_IPV6_T clx_ipv6 = {0x3F, 0xFE, 0x0B, 0x80, 0x1F, 0x8D, 0x00, 0x01,
 *                         0x0A, 0x00, 0x20, 0xFF, 0xFE, 0xA7, 0x68, 0x6B};
 *  UI32_T     hw_ipv6[4];
 *
 *  After CLX_IPV6_TO_HW_IPV6(clx_mac, hw_mac),
 *  hw_ipv6[0] = 0xFEA7686B;
 *  hw_ipv6[1] = 0x0A0020FF;
 *  hw_ipv6[2] = 0x1F8D0001;
 *  hw_ipv6[3] = 0x3FFE0B80;
 */
#define CLX_IPV6_TO_HW_IPV6(__hw_ipv6__, __clx_ipv6__)              \
    do {                                                            \
        (__hw_ipv6__)[0] = (UI32_T)((__clx_ipv6__)[12]) << 24 |     \
                           (__clx_ipv6__)[13] << 16 |               \
                           (__clx_ipv6__)[14] <<  8 |               \
                           (__clx_ipv6__)[15];                      \
        (__hw_ipv6__)[1] = (UI32_T)((__clx_ipv6__)[ 8]) << 24 |     \
                           (__clx_ipv6__)[ 9] << 16 |               \
                           (__clx_ipv6__)[10] <<  8 |               \
                           (__clx_ipv6__)[11];                      \
        (__hw_ipv6__)[2] = (UI32_T)((__clx_ipv6__)[ 4]) << 24 |     \
                           (__clx_ipv6__)[ 5] << 16 |               \
                           (__clx_ipv6__)[ 6] <<  8 |               \
                           (__clx_ipv6__)[ 7];                      \
        (__hw_ipv6__)[3] = (UI32_T)((__clx_ipv6__)[ 0]) << 24 |     \
                           (__clx_ipv6__)[ 1] << 16 |               \
                           (__clx_ipv6__)[ 2] <<  8 |               \
                           (__clx_ipv6__)[ 3];                      \
    }while(0)
/*
 * Example is as below.
 *  CLX_IPV6_T clx_ipv6;
 *  UI32_T     hw_ipv6[4] = {0xFEA7686B, 0x0A0020FF, 0x1F8D0001, 0x3FFE0B80};
 *
 *  After HW_IPV6_TO_CLX_IPV6(__clx_ipv6__, __hw_ipv6__),
 *  hw_ipv6[0] = 0xFEA7686B;
 *  hw_ipv6[1] = 0x0A0020FF;
 *  hw_ipv6[2] = 0x1F8D0001;
 *  hw_ipv6[3] = 0x3FFE0B80;
 */
#define HW_IPV6_TO_CLX_IPV6(__clx_ipv6__, __hw_ipv6__)               \
    do {                                                             \
        (__clx_ipv6__)[ 0] = ((__hw_ipv6__)[3] & 0xFF000000) >> 24;  \
        (__clx_ipv6__)[ 1] = ((__hw_ipv6__)[3] & 0x00FF0000) >> 16;  \
        (__clx_ipv6__)[ 2] = ((__hw_ipv6__)[3] & 0x0000FF00) >>  8;  \
        (__clx_ipv6__)[ 3] = ((__hw_ipv6__)[3] & 0x000000FF);        \
        (__clx_ipv6__)[ 4] = ((__hw_ipv6__)[2] & 0xFF000000) >> 24;  \
        (__clx_ipv6__)[ 5] = ((__hw_ipv6__)[2] & 0x00FF0000) >> 16;  \
        (__clx_ipv6__)[ 6] = ((__hw_ipv6__)[2] & 0x0000FF00) >>  8;  \
        (__clx_ipv6__)[ 7] = ((__hw_ipv6__)[2] & 0x000000FF);        \
        (__clx_ipv6__)[ 8] = ((__hw_ipv6__)[1] & 0xFF000000) >> 24;  \
        (__clx_ipv6__)[ 9] = ((__hw_ipv6__)[1] & 0x00FF0000) >> 16;  \
        (__clx_ipv6__)[10] = ((__hw_ipv6__)[1] & 0x0000FF00) >>  8;  \
        (__clx_ipv6__)[11] = ((__hw_ipv6__)[1] & 0x000000FF);        \
        (__clx_ipv6__)[12] = ((__hw_ipv6__)[0] & 0xFF000000) >> 24;  \
        (__clx_ipv6__)[13] = ((__hw_ipv6__)[0] & 0x00FF0000) >> 16;  \
        (__clx_ipv6__)[14] = ((__hw_ipv6__)[0] & 0x0000FF00) >>  8;  \
        (__clx_ipv6__)[15] = ((__hw_ipv6__)[0] & 0x000000FF);        \
    }while(0)

/* DATA TYPE DECLARATIONS
 */

typedef struct
{
    UI32_T    field_id;
    union
    {
        UI32_T    *ptr_value;
        UI32_T    value;
    };
} CDB_FVP_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME: cdb_packField
 * PURPOSE:
 *      Substitute the specified bits (field) in the entry buffer with the
 *      content in field buffer.
 * INPUT:
 *      unit          -- Unit number.
 *      table_id      -- Table ID.
 *      field_id      -- Field ID.
 *      ptr_entry     -- Pointer to the entry buffer.
 *      ptr_field     -- Pointer to the field buffer
 * OUTPUT:
 *      ptr_entry     -- Pointer to the entry buffer.
 * RETURN:
 *      None.
 */
void
cdb_packField(
    const UI32_T unit,
    const UI32_T table_id,
    const UI32_T field_id,
    UI32_T *ptr_entry,
    const UI32_T *ptr_field);

/* FUNCTION NAME: cdb_unpackField
 * PURPOSE:
 *      Extract the specified field from an entry buffer info field buffer.
 * INPUT:
 *      unit          -- Unit number.
 *      table_id      -- Table ID.
 *      field_id      -- Field ID.
 *      ptr_entry     -- Pointer to the entry buffer.
 * OUTPUT:
 *      ptr_field     -- Pointer to the field buffer.
 * RETURN:
 *      None.
 */
void
cdb_unpackField(
    const UI32_T unit,
    const UI32_T table_id,
    const UI32_T field_id,
    const UI32_T *ptr_entry,
    UI32_T *ptr_field);

/* FUNCTION NAME: cdb_packUi32Field
 * PURPOSE:
 *      Substitute the specified bits (field) in the entry buffer with the
 *      field value.
 * INPUT:
 *      unit          -- Unit number.
 *      table_id      -- Table ID.
 *      field_id      -- Field ID.
 *      ptr_entry     -- Pointer to the entry buffer.
 *      field         -- Field value.
 * OUTPUT:
 *      ptr_entry     -- Pointer to the entry buffer.
 * RETURN:
 *      None.
 */
void
cdb_packUi32Field(
    const UI32_T unit,
    const UI32_T table_id,
    const UI32_T field_id,
    UI32_T *ptr_entry,
    const UI32_T field);

/* FUNCTION NAME: cdb_unpackUi32Field
 * PURPOSE:
 *      Extract the specified field from an entry buffer.
 * INPUT:
 *      unit          -- Unit number.
 *      table_id      -- Table ID.
 *      field_id      -- Field ID.
 *      ptr_entry     -- Pointer to the entry buffer.
 * OUTPUT:
 *      None.
 * RETURN:
 *      Field value.
 */
UI32_T
cdb_unpackUi32Field(
    const UI32_T unit,
    const UI32_T table_id,
    const UI32_T field_id,
    const UI32_T *ptr_entry);

/* FUNCTION NAME: cdb_readMmio
 * PURPOSE:
 *      Read a memory mapped location in hardware.
 * INPUT:
 *      unit          -- Unit number.
 *      inst_idx      -- Instance index.
 *      subinst_idx   -- Sub instance index.
 *      table_id      -- Table ID.
 *      entry_idx     -- Entry index in table.
 * OUTPUT:
 *      None.
 * RETURN:
 *      Entry value.
 */
UI32_T
cdb_readMmio(
    const UI32_T unit,
    const UI32_T inst_idx,
    const UI32_T subinst_idx,
    const UI32_T table_id,
    const UI32_T entry_idx);

/* FUNCTION NAME: cdb_readMmio
 * PURPOSE:
 *      Write a memory mapped location in hardware.
 * INPUT:
 *      unit          -- Unit number.
 *      inst_idx      -- Instance index.
 *      subinst_idx   -- Sub instance index.
 *      table_id      -- Table ID.
 *      entry_idx     -- Entry index in table.
 *      value         -- Entry value.
 * OUTPUT:
 *      None.
 * RETURN:
 *      None.
 */
void
cdb_writeMmio(
    const UI32_T unit,
    const UI32_T inst_idx,
    const UI32_T subinst_idx,
    const UI32_T table_id,
    const UI32_T entry_idx,
    const UI32_T value);

/* FUNCTION NAME: cdb_readEntry
 * PURPOSE:
 *      Read an entry from hardware to entry buffer.
 *      1. When reading TCAM table id, please use table id whose
 *         memory type is "MEMORY_TYPE_TABLE_TCAM_COM".
 * INPUT:
 *      unit          -- Unit number.
 *      inst_idx      -- Instance index.
 *      subinst_idx   -- Sub instance index.
 *      table_id      -- Table ID.
 *      entry_idx     -- Entry index in table.
 * OUTPUT:
 *      ptr_entry     -- Pointer to the entry buffer.
 * RETURN:
 *      CLX_E_OK      -- Read success.
 *      CLX_E_OTHERS  -- Read fail.
 */
CLX_ERROR_NO_T
cdb_readEntry(
    const UI32_T unit,
    const UI32_T inst_idx,
    const UI32_T subinst_idx,
    const UI32_T table_id,
    const UI32_T entry_idx,
    UI32_T *ptr_entry);

/* FUNCTION NAME: cdb_writeEntry
 * PURPOSE:
 *      Write an entry from entry buffer to hardware.
 *      1. When writing TCAM table id, please use table id whose
 *         memory type is "MEMORY_TYPE_TABLE_TCAM_COM".
 * INPUT:
 *      unit          -- Unit number.
 *      inst_idx      -- Instance index.
 *      subinst_idx   -- Sub instance index.
 *      table_id      -- Table ID.
 *      entry_idx     -- Entry index in table.
 *      ptr_entry     -- Pointer to the entry buffer.
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK      -- Write success.
 *      CLX_E_OTHERS  -- Write fail.
 */
CLX_ERROR_NO_T
cdb_writeEntry(
    const UI32_T unit,
    const UI32_T inst_idx,
    const UI32_T subinst_idx,
    const UI32_T table_id,
    const UI32_T entry_idx,
    const UI32_T *ptr_entry);

/* FUNCTION NAME: cdb_modifyField
 * PURPOSE:
 *      Modify the specified field of the specified entry in hardware with the
 *      content in field buffer.
 * INPUT:
 *      unit          -- Unit number.
 *      inst_idx      -- Instance index.
 *      subinst_idx   -- Sub instance index.
 *      table_id      -- Table ID.
 *      entry_idx     -- Entry index in table.
 *      field_id      -- Field ID.
 *      ptr_field     -- Pointer to the new value for the field.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK      -- Modify success.
 *      CLX_E_OTHERS  -- Read or write fail.
 */
CLX_ERROR_NO_T
cdb_modifyField(
    const UI32_T unit,
    const UI32_T inst_idx,
    const UI32_T subinst_idx,
    const UI32_T table_id,
    const UI32_T entry_idx,
    const UI32_T field_id,
    const UI32_T *ptr_field);

/* FUNCTION NAME: cdb_modifyUi32Field
 * PURPOSE:
 *      Modify the specified "short" field of the specified entry in hardware
 *      with field value, this can be used for field with width of 32-bit or
 *      less.
 * INPUT:
 *      unit          -- Unit number.
 *      inst_idx      -- Instance index.
 *      subinst_idx   -- Sub instance index.
 *      table_id      -- Table ID.
 *      entry_idx     -- Entry index in table.
 *      field_id      -- Field ID.
 *      field         -- New value for the field.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK      -- Modify success.
 *      CLX_E_OTHERS  -- Read or write fail.
 */
CLX_ERROR_NO_T
cdb_modifyUi32Field(
    const UI32_T unit,
    const UI32_T inst_idx,
    const UI32_T subinst_idx,
    const UI32_T table_id,
    const UI32_T entry_idx,
    const UI32_T field_id,
    const UI32_T field);

/* FUNCTION NAME: cdb_modifyMultiFields
 * PURPOSE:
 *      Modify multiple fields of the specified entry in hardware.
 * INPUT:
 *      unit          -- Unit number.
 *      inst_idx      -- Instance index.
 *      subinst_idx   -- Sub instance index.
 *      table_id      -- Table ID.
 *      entry_idx     -- Entry index in table.
 *      fvp_count     -- Number of valid entries in ptr_fvp array.
 *      ptr_fvp       -- Pointer to array of field-value pair (FVP)
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK      -- Modify success.
 *      CLX_E_OTHERS  -- Read or write fail.
 */
CLX_ERROR_NO_T
cdb_modifyMultiFields(
    const UI32_T unit,
    const UI32_T inst_idx,
    const UI32_T subinst_idx,
    const UI32_T table_id,
    const UI32_T entry_idx,
    const UI32_T fvp_count,
    const CDB_FVP_T *ptr_fvp);

/* FUNCTION NAME: cdb_addHashEntry
 * PURPOSE:
 *      Add a hash entry into hardware.
 * INPUT:
 *      unit          -- Unit number.
 *      inst_idx      -- Instance index.
 *      subinst_idx   -- Sub instance index.
 *      bank_bmp      -- The bank bitmap of hash engine.
 *      table_id      -- Table ID.
 *      ptr_entry     -- Pointer to the buffer of the new entry
 * OUTPUT:
 *      ptr_entry_idx -- The returned entry index.
 * RETURN:
 *      CLX_E_OK      -- Add success.
 *      CLX_E_OTHERS  -- Add fail.
 */
CLX_ERROR_NO_T
cdb_addHashEntry(
    const UI32_T unit,
    const UI32_T inst_idx,
    const UI32_T subinst_idx,
    const UI32_T bank_bmp,
    const UI32_T table_id,
    const UI32_T *ptr_entry,
    UI32_T *ptr_entry_idx);

/* FUNCTION NAME: cdb_lookupHashEntry
 * PURPOSE:
 *      Search a hash entry from hardware.
 * INPUT:
 *      unit          -- Unit number.
 *      inst_idx      -- Instance index.
 *      subinst_idx   -- Sub instance index.
 *      bank_bmp      -- The bank bitmap of hash engine.
 *      table_id      -- Table ID.
 *      ptr_entry     -- Pointer to the buffer of the entry
 * OUTPUT:
 *      ptr_entry_idx -- The returned entry index.
 * RETURN:
 *      CLX_E_OK      -- Search success.
 *      CLX_E_OTHERS  -- Search fail.
 */
CLX_ERROR_NO_T
cdb_lookupHashEntry(
    const UI32_T unit,
    const UI32_T inst_idx,
    const UI32_T subinst_idx,
    const UI32_T bank_bmp,
    const UI32_T table_id,
    UI32_T *ptr_entry,
    UI32_T *ptr_entry_idx);

/* FUNCTION NAME: cdb_delHashEntry
 * PURPOSE:
 *      Delete a hash entry from hardware.
 * INPUT:
 *      unit          -- Unit number.
 *      inst_idx      -- Instance index.
 *      subinst_idx   -- Sub instance index.
 *      bank_bmp      -- The bank bitmap of hash engine.
 *      table_id      -- Table ID.
 *      ptr_entry     -- Pointer to the buffer of the entry to be deleted
 * OUTPUT:
 *      ptr_entry_idx -- The returned entry index.
 * RETURN:
 *      CLX_E_OK      -- Delete success.
 *      CLX_E_OTHERS  -- Delete fail.
 */
CLX_ERROR_NO_T
cdb_delHashEntry(
    const UI32_T unit,
    const UI32_T inst_idx,
    const UI32_T subinst_idx,
    const UI32_T bank_bmp,
    const UI32_T table_id,
    const UI32_T *ptr_entry,
    UI32_T *ptr_entry_idx);

/* FUNCTION NAME:   cdb_resetTable
 * PURPOSE:
 *      Write whole table entries with initialized vlue.
 *
 * INPUT:
 *      unit          -- Unit number.
 *      inst_idx      -- Instance index.
 *      subinst_idx   -- Sub instance index.
 *      table_id      -- Table ID.
 *      ptr_entry     -- The entry with initialized value.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Reset success.
 *      CLX_E_OTHERS  -- Reset fail.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
cdb_resetTable(
    const UI32_T unit,
    const UI32_T inst_idx,
    const UI32_T subinst_idx,
    const UI32_T table_id,
    const UI32_T *ptr_entry);

/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */

#endif /* End of CDB_H */
