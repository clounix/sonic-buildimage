/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_swc.h
 * PURPOSE:
 *      API & special number for CL8570. For example: IEV, EMI.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_MT_KG_SWC_H
#define HAL_MT_KG_SWC_H

#include <clx/clx_cfg.h>
#include <clx/clx_swc.h>

#include <hal/hal_swc.h>
#include <hal/mt/hal_mt_swc.h>
#define HAL_MT_KG_SWC_HASH_STAGE_NUM              (10)
#define HAL_MT_KG_SWC_HASH_TILE_NUM_PER_STAGE     (2)
#define HAL_MT_KG_SWC_HASH_TILE_NUM               (20)
#define HAL_MT_KG_SWC_FIB_TCAM_NUM_PER_TYPE       (8)
#define HAL_MT_KG_SWC_L2_OR_FIB_TCAM_NUM_PER_TYPE (16)
#define HAL_MT_KG_SWC_TCAM_NUM \
    (HAL_MT_KG_SWC_FIB_TCAM_NUM_PER_TYPE + HAL_MT_KG_SWC_L2_OR_FIB_TCAM_NUM_PER_TYPE)
#define HAL_MT_KG_SWC_TCAM_ENTRY_NUM (HAL_MT_KG_SWC_TCAM_NUM * 1024)

#define HAL_MT_KG_SWC_HASH_TILE_PRI_NUM_PER_FPU (10)
#define HAL_MT_KG_SWC_HASH_TILE_PRI_NUM         (HAL_MT_KG_SWC_HASH_TILE_PRI_NUM_PER_FPU * 2)

#define HAL_MT_KG_SWC_EMI_BANK_NUM                (8)
#define HAL_MT_KG_SWC_EMI_NSH_BANK_BASE           (HAL_MT_KG_SWC_EMI_BANK_NUM - 1)
#define HAL_MT_KG_SWC_PAGE_NUM_PER_BANK           (4)
#define HAL_MT_KG_SWC_ILE_TCAM_BANK_NUM           (64)
#define HAL_MT_KG_SWC_ILE_TCAM_ENTRY_NUM_PER_BANK (256)
#define HAL_MT_KG_SWC_MASTER_DIE_ID               (4) /* t die */

#define HAL_MT_KG_SWC_TCAM_ENABLE_FIELD        0
#define HAL_MT_KG_SWC_TCAM_SA_OR_DA_FIELD      1
#define HAL_MT_KG_SWC_TCAM_L2_OR_FIB_FIELD     2
#define HAL_MT_KG_SWC_TCAM_IPV6_2X_OR_4X_FILED 3

#define HAL_MT_KG_SWC_TCAM_IS_SA           0
#define HAL_MT_KG_SWC_TCAM_IS_DA           1
#define HAL_MT_KG_SWC_TCAM_IS_L2           0
#define HAL_MT_KG_SWC_TCAM_IS_L3           1
#define HAL_MT_KG_SWC_TCAM_IS_L2L3_INVALID 0xFFFF
#define HAL_MT_KG_SWC_TCAM_IS_IPV6_2X      0
#define HAL_MT_KG_SWC_TCAM_IS_IPV6_4X      1

#define HAL_MT_KG_SWC_RSN_BF_EN         (1)
#define HAL_MT_KG_SWC_RSN_BF_DFLE_CTR   (10000)
#define HAL_MT_KG_SWC_RSN_BF_DFLT_TIMER (1000)

#define HAL_MT_KG_SWC_RSN_ATTR_UNSUPPORTED CLX_SWC_CPU_RSN_ATTR_DROP_RSN

static inline void
hal_mt_kg_swc_tcam_off_cfg(uint32 unit, uint32 tcam_table, uint32 *tcam_field, uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_ENABLE_FIELD], 0,
                        stage_cfg_buf);
}

static inline void
hal_mt_kg_swc_tcam_l3_sa_cfg(uint32 unit,
                             uint32 tcam_table,
                             uint32 *tcam_field,
                             uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_KG_SWC_TCAM_IS_SA, stage_cfg_buf);
    if (HAL_MT_KG_SWC_TCAM_IS_L2L3_INVALID != tcam_field[HAL_MT_KG_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_KG_SWC_TCAM_IS_L3, stage_cfg_buf);
    }
}

static inline void
hal_mt_kg_swc_tcam_l3_da_cfg(uint32 unit,
                             uint32 tcam_table,
                             uint32 *tcam_field,
                             uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_KG_SWC_TCAM_IS_DA, stage_cfg_buf);
    if (HAL_MT_KG_SWC_TCAM_IS_L2L3_INVALID != tcam_field[HAL_MT_KG_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_KG_SWC_TCAM_IS_L3, stage_cfg_buf);
    }
}

static inline void
hal_mt_kg_swc_tcam_l3_sa_4x_cfg(uint32 unit,
                                uint32 tcam_table,
                                uint32 *tcam_field,
                                uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_KG_SWC_TCAM_IS_SA, stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_IPV6_2X_OR_4X_FILED],
                        HAL_MT_KG_SWC_TCAM_IS_IPV6_4X, stage_cfg_buf);
    if (HAL_MT_KG_SWC_TCAM_IS_L2L3_INVALID != tcam_field[HAL_MT_KG_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_KG_SWC_TCAM_IS_L3, stage_cfg_buf);
    }
}

static inline void
hal_mt_kg_swc_tcam_l3_da_4x_cfg(uint32 unit,
                                uint32 tcam_table,
                                uint32 *tcam_field,
                                uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_KG_SWC_TCAM_IS_DA, stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_IPV6_2X_OR_4X_FILED],
                        HAL_MT_KG_SWC_TCAM_IS_IPV6_4X, stage_cfg_buf);
    if (HAL_MT_KG_SWC_TCAM_IS_L2L3_INVALID != tcam_field[HAL_MT_KG_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_KG_SWC_TCAM_IS_L3, stage_cfg_buf);
    }
}

static inline void
hal_mt_kg_swc_tcam_l2_uc_sa_cfg(uint32 unit,
                                uint32 tcam_table,
                                uint32 *tcam_field,
                                uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_KG_SWC_TCAM_IS_SA, stage_cfg_buf);
    if (HAL_MT_KG_SWC_TCAM_IS_L2L3_INVALID != tcam_field[HAL_MT_KG_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_KG_SWC_TCAM_IS_L2, stage_cfg_buf);
    }
}

static inline void
hal_mt_kg_swc_tcam_l2_uc_da_cfg(uint32 unit,
                                uint32 tcam_table,
                                uint32 *tcam_field,
                                uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_KG_SWC_TCAM_IS_DA, stage_cfg_buf);
    if (HAL_MT_KG_SWC_TCAM_IS_L2L3_INVALID != tcam_field[HAL_MT_KG_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_KG_SWC_TCAM_IS_L2, stage_cfg_buf);
    }
}

static inline void
hal_mt_kg_swc_tcam_l2_mc_da_cfg(uint32 unit,
                                uint32 tcam_table,
                                uint32 *tcam_field,
                                uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_KG_SWC_TCAM_IS_DA, stage_cfg_buf);
    if (HAL_MT_KG_SWC_TCAM_IS_L2L3_INVALID != tcam_field[HAL_MT_KG_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_KG_SWC_TCAM_IS_L2, stage_cfg_buf);
    }
}

static inline void
hal_mt_kg_swc_tcam_vpws_cfg(uint32 unit,
                            uint32 tcam_table,
                            uint32 *tcam_field,
                            uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_KG_SWC_TCAM_IS_DA, stage_cfg_buf);
    if (HAL_MT_KG_SWC_TCAM_IS_L2L3_INVALID != tcam_field[HAL_MT_KG_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_KG_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_KG_SWC_TCAM_IS_L2, stage_cfg_buf);
    }
}

#define HAL_MT_KG_SWC_HASH_MAC_ENTRIES_PER_TILE      (16 * 1024)
#define HAL_MT_KG_SWC_HASH_2X_MAC_ENTRIES_PER_TILE   (8 * 1024)
#define HAL_MT_KG_SWC_HASH_ARP_ENTRIES_PER_TILE      (16 * 1024)
#define HAL_MT_KG_SWC_HASH_AFIB_ENTRIES_PER_TILE     (64 * 1024)
#define HAL_MT_KG_SWC_HASH_L3_ENTRIES_PER_TILE       (16 * 1024)
#define HAL_MT_KG_SWC_HASH_ARP_DEFAULT_TILE_NUM      (4)
#define HAL_MT_KG_SWC_HASH_AFIB_DEFAULT_TILE_NUM     (5)
#define HAL_MT_KG_SWC_HASH_L3_DEFAULT_TILE_NUM       (5)
#define HAL_MT_KG_SWC_HASH_MPLS_DEFAULT_TILE_NUM     (1)
#define HAL_MT_KG_SWC_HASH_SRV6_DEFAULT_TILE_NUM     (1)
#define HAL_MT_KG_SWC_HASH_MGI_DEFAULT_TILE_NUM      (1)
#define HAL_MT_KG_SWC_HASH_MSGI_DEFAULT_TILE_NUM     (1)
#define HAL_MT_KG_SWC_HASH_ECMP_GRP_DEFAULT_TILE_NUM (1)
#define HAL_MT_KG_SWC_HASH_ECMP_MBR_DEFAULT_TILE_NUM (1)
#define HAL_MT_KG_SWC_HASH_RPFC_DEFAULT_TILE_NUM     (1)
#define HAL_MT_KG_SWC_HASH_MAC_DEFAULT_TILE_NUM      (0)

#define HAL_MT_KG_SWC_TCAM_TYPE_ONLY_L3        (0)
#define HAL_MT_KG_SWC_TCAM_TYPE_L2L3           (1)
#define HAL_MT_KG_SWC_DMAC_TCAM_START          (8)
#define HAL_MT_KG_SWC_DMAC_MAX_TCAM_NUM        (16)
#define HAL_MT_KG_SWC_DIP_DEFAULT_TCAM_NUM     (4)
#define HAL_MT_KG_SWC_MAX_TCAM_NUM             (24)
#define HAL_MT_KG_SWC_MAX_TILE_NUM             (20)
#define HAL_MT_KG_SWC_TILE_OFFSET              (15)
#define HAL_MT_KG_SWC_TILE_LEN                 (1)
#define HAL_MT_KG_SWC_STAGE_OFFSET             (16)
#define HAL_MT_KG_SWC_STAGE_LEN                (4)
#define HAL_MT_KAWAGARBO_ENTRIES_PER_TCAM      (1024)
#define HAL_MT_KAWAGARBO_ENTRIES_PER_TCAM_BIT  (10)
#define HAL_MT_KAWAGARBO_MAC_ENTRIES_PER_TCAM  (512)
#define HAL_MT_KAWAGARBO_L3_ENTRIES_PER_TCAM   (1024)
#define HAL_MT_KAWAGARBO_FDL_GRP_THRESHOLD_MAX (1 << 20)

#define HAL_MT_KG_SWC_HSH_KEY_ALL_KEY_0 (0xffffffff)
#define HAL_MT_KG_SWC_HSH_KEY_ALL_KEY_1 (0x3fff)

clx_error_no_t
hal_mt_kg_swc_cfg_init(const uint32 unit);

clx_error_no_t
hal_mt_kg_swc_hsh_tile_arp_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_kg_swc_hsh_tile_afib_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_kg_swc_hsh_tile_l3_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_kg_swc_hsh_tile_mpls_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_kg_swc_hash_tile_srv6_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_kg_swc_hsh_tile_l2uc_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_kg_swc_hsh_tile_l2mc_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_kg_swc_hash_tile_mgi_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_kg_swc_hsh_tile_msgi_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_kg_swc_hash_tile_ecmp_mbr_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_kg_swc_hash_tile_ecmp_grp_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_kg_swc_hsh_tile_rpfc_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_kg_swc_hsh_tile_policy_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_kg_swc_hsh_tile_l2_ecmp_grp_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_kg_swc_hsh_tile_l2_ecmp_mbr_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_kg_swc_tcam_l2_cfg(const uint32 unit, uint32 uc_entry_num, uint32 mc_entry_num);

clx_error_no_t
hal_mt_kg_swc_host_tcam_cfg(const uint32 unit,
                            uint32 entry_2x_num,
                            uint32 entry_4x_num,
                            uint32 sip_check);

clx_error_no_t
hal_mt_kg_swc_route_tcam_cfg(const uint32 unit,
                             uint32 entry_2x_num,
                             uint32 entry_4x_num,
                             uint32 sip_check);

clx_error_no_t
hal_mt_kg_swc_fdl_thd_set(const uint32 unit, const uint32 threshold);

clx_error_no_t
hal_mt_kg_swc_fdl_thd_get(const uint32 unit, uint32 *ptr_threshold);

/**
 * @brief Get chip PLL status.
 *
 * @param [in]     unit              - Device unit number.
 * @param [out]    ptr_pll_status    - Pointer to the status of chip PLL.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_chip_pll_status_get(const uint32 unit, clx_swc_chip_pll_status_t *ptr_pll_status);

/**
 * @brief Initialize the low level of the kg sram.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_low_lvl_init(const uint32 unit);

clx_error_no_t
hal_mt_kg_swc_epg_pkt_init(hal_swc_epg_pkt_t *ptr_pkt);

/**
 * @brief Set MAC EPG packet related configuration (header, payload, IPG,
 *        ...).
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_pkt    - Packet information to be sent.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_mt_kg_swc_epg_mac_hw_set(const uint32 unit, const hal_swc_epg_pkt_t *ptr_pkt);

/**
 * @brief Trigger MAC EPG to send packets.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - EPG ingress port.
 * @param [in]    lpbk    - 0: Traffic is sent to PP; 1: MAC loopback.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_mt_kg_swc_epg_mac_pkt_send(const uint32 unit, const uint32 port, const uint32 lpbk);

/**
 * @brief Trigger MAC EPG to send packets.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - EPG ingress port.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_mt_kg_swc_epg_mac_done_chk(const uint32 unit, const uint32 port);

/**
 * @brief Stop MAC EPG from sending packets.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - EPG ingress port.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_mt_kg_swc_epg_mac_pkt_stop(const uint32 unit, const uint32 port);

/**
 * @brief Set switch control hash keys.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    hsh_type    - Hash type.
 * @param [in]    key_bmp     - Hash key bitmap.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_hsh_key_set(const uint32 unit,
                          const clx_swc_hsh_pkt_type_t hsh_type,
                          const clx_swc_hsh_key_bmp_t key_bmp);

/**
 * @brief Get switch control hash keys.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     hsh_type    - Hash type.
 * @param [out]    key_bmp     - Hash key bitmap.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_hsh_key_get(const uint32 unit,
                          const clx_swc_hsh_pkt_type_t hsh_type,
                          clx_swc_hsh_key_bmp_t *key_bmp);

/**
 * @brief Set switch control hash keys by hash profile.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    hsh_type    - Hash type.
 * @param [in]    key_prof    - Hash key profile.
 * @param [in]    key_bmp     - Hash key bitmap.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_hsh_key_prof_set(const uint32 unit,
                               const clx_swc_hsh_pkt_type_t hsh_type,
                               const clx_swc_hsh_key_prof_t key_prof,
                               const clx_swc_hsh_key_bmp_t key_bmp);

/**
 * @brief Get switch control hash keys by hash profile.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     hsh_type       - Hash type.
 * @param [in]     key_prof       - Hash key profile.
 * @param [out]    ptr_key_bmp    - Pointer of hash key bitmap.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_hsh_key_prof_get(const uint32 unit,
                               const clx_swc_hsh_pkt_type_t hsh_type,
                               const clx_swc_hsh_key_prof_t key_prof,
                               clx_swc_hsh_key_bmp_t *ptr_key_bmp);

/**
 * @brief Set hash engine polynomial coefficients.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    hsh_type     - Hash engine to be config.
 * @param [in]    hsh_const    - Hash constant.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Config fail.
 */
clx_error_no_t
hal_mt_kg_swc_hsh_const_set(const uint32 unit,
                            const clx_swc_hsh_pkt_type_t hsh_type,
                            const uint32 hsh_const);

/**
 * @brief Get hash engine polynomial coefficients.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     hsh_type         - Hash engine to be config.
 * @param [out]    ptr_hsh_const    - Pointer to array of constants.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_hsh_const_get(const uint32 unit,
                            const clx_swc_hsh_pkt_type_t hsh_type,
                            uint32 *ptr_hsh_const);

/**
 * @brief Set hash engine configuration.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    hsh_type    - Hash type.
 * @param [in]    hsh_eng     - Hash engine attributes.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Config fail.
 */
clx_error_no_t
hal_mt_kg_swc_hsh_eng_set(const uint32 unit,
                          const clx_swc_hsh_pkt_type_t hsh_type,
                          const clx_swc_hsh_eng_t *hsh_eng);

/**
 * @brief Get hash engine configuration.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     hsh_type       - Hash type.
 * @param [out]    ptr_hsh_eng    - Pointer to hash engine attributes.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Config fail.
 */
clx_error_no_t
hal_mt_kg_swc_hsh_eng_get(const uint32 unit,
                          const clx_swc_hsh_pkt_type_t hsh_type,
                          clx_swc_hsh_eng_t *ptr_hsh_eng);

/**
 * @brief Set reason action.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    rsn_code    - Reason code.
 * @param [in]    rsn_act     - Reason action.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_rsn_act_set(const uint32 unit,
                          const clx_pkt_rx_reason_t rsn_code,
                          const clx_swc_rsn_act_t *rsn_act);

/**
 * @brief Get reason action.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     rsn_code    - Rx reason code.
 * @param [out]    rsn_act     - Rx reason action.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_rsn_act_get(const uint32 unit,
                          const clx_pkt_rx_reason_t rsn_code,
                          clx_swc_rsn_act_t *rsn_act);

/**
 * @brief This function is to set reason priority.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    rsn_code    - Reason code.
 * @param [in]    pri         - Reason priority.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_rsn_pri_set(const uint32 unit, const clx_pkt_rx_reason_t rsn_code, const uint32 pri);

/**
 * @brief This function is to get reason priority.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     rsn_code    - Reason code.
 * @param [out]    pri         - Reason priority.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_rsn_pri_get(const uint32 unit, const clx_pkt_rx_reason_t rsn_code, uint32 *pri);

/**
 * @brief To set PP reason priority.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    pp_rsn_code    - Pp reason code.
 * @param [in]    pri            - Reason priority.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_pp_rsn_pri_set(const uint32 unit, const uint32 pp_rsn_code, const uint32 pri);

/**
 * @brief To get PP reason priority.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     pp_rsn_code    - Pp reason code.
 * @param [out]    pri            - Reason priority.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_pp_rsn_pri_get(const uint32 unit, const uint32 pp_rsn_code, uint32 *pri);

/**
 * @brief This function is to set reason bloom filter configuration.
 *
 * @param [in]    unit                 - Device unit number.
 * @param [in]    bloom_filter_type    - Bloom filter type.
 * @param [in]    bloom_filter_val     - Bloom filter value.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_rsn_bloom_filter_set(const uint32 unit,
                                   const clx_swc_cfg_rsn_bloom_filter_type_t bloom_filter_type,
                                   const uint32 bloom_filter_val);

/**
 * @brief This function is to get reason bloom filter configuration.
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     bloom_filter_type    - Bloom filter type.
 * @param [out]    bloom_filter_val     - Bloom filter value.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_rsn_bloom_filter_get(const uint32 unit,
                                   const clx_swc_cfg_rsn_bloom_filter_type_t bloom_filter_type,
                                   uint32 *bloom_filter_val);

/**
 * @brief Set exceptions to drop, to CPU or forward.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    en      - Enable or restore exceptions.
 * @param [in]    act     - Drop, forward or send to the CPU.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_excpt_set(const uint32 unit, const uint32 en, const clx_fwd_action_t act);

/**
 * @brief Trap all packets to CPU.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    en      - Enable or disable.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_trap_all_set(const uint32 unit, const uint32 en);

/**
 * @brief Get device information.
 *
 * @param [in]     unit               - Device unit number.
 * @param [out]    ptr_device_info    - The device information.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_dev_info_get(const uint32 unit, clx_swc_device_info_t *ptr_device_info);

/**
 * @brief Set clock servo mode.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    mode    - Clock servo mode.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_swc_cso_mode_set(const uint32 unit, const clx_swc_cso_mode_t mode);

/**
 * @brief Set timestamp value of system.
 *
 * @param [in]     unit      - Chip id.
 * @param [out]    ts_val    - Timestamp value.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_swc_ts_set(const uint32 unit, const clx_swc_ts_t ts_val);

/**
 * @brief Get timestamp value of system.
 *
 * @param [in]     unit          - Chip id.
 * @param [out]    ptr_ts_val    - Pointer of timestamp value.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_swc_ts_get(const uint32 unit, clx_swc_ts_t *ptr_ts_val);

/**
 * @brief Set timestamp offset.
 *
 * @param [in]    unit    - Chip id.
 * @param [in]    nsec    - Signed nanoseconds for timestamp offset.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_swc_ts_offset_set(const uint32 unit, const int32 nsec);
#endif