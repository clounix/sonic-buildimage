/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_cia_sparse.h
 * PURPOSE:
 *    Provide HAL driver API functions of CIA SPARSE module.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NB_CIA_SPARSE_H
#define HAL_MT_NB_CIA_SPARSE_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_cia.h>
#include <hal/hal_cmn.h>
#include <hal/hal_sflow.h>
#include <hal/hal_cia.h>

clx_error_no_t
hal_mt_nb_cia_sparse_grp_get(const uint32 unit,
                             const clx_cia_stage_t stage,
                             const uint32 grp_id,
                             clx_cia_grp_prof_t *ptr_grp_prof);

clx_error_no_t
hal_mt_nb_cia_sparse_grp_add(const uint32 unit,
                             const clx_cia_stage_t stage,
                             const clx_cia_grp_prof_t *ptr_grp_prof,
                             uint32 *ptr_grp_id);

clx_error_no_t
hal_mt_nb_cia_sparse_grp_del(const uint32 unit, const clx_cia_stage_t stage, const uint32 grp_id);

clx_error_no_t
hal_mt_nb_cia_sparse_grp_trav(const uint32 unit,
                              const clx_cia_stage_t stage,
                              const clx_cia_grp_trav_func_t callback,
                              void *ptr_cookie);

clx_error_no_t
hal_mt_nb_cia_sparse_exact_grp_get(const uint32 unit,
                                   const clx_cia_stage_t stage,
                                   const uint32 grp_id,
                                   clx_cia_exact_grp_prof_t *ptr_grp_prof);

clx_error_no_t
hal_mt_nb_cia_sparse_exact_grp_add(const uint32 unit,
                                   const clx_cia_stage_t stage,
                                   const clx_cia_exact_grp_prof_t *ptr_grp_prof,
                                   uint32 *ptr_grp_id);

clx_error_no_t
hal_mt_nb_cia_sparse_exact_grp_del(const uint32 unit,
                                   const clx_cia_stage_t stage,
                                   const uint32 grp_id);

clx_error_no_t
hal_mt_nb_cia_sparse_exact_grp_trav(const uint32 unit,
                                    const clx_cia_stage_t stage,
                                    const clx_cia_exact_grp_trav_func_t callback,
                                    void *ptr_cookie);

clx_error_no_t
hal_mt_nb_cia_sparse_udf_entry_get(const uint32 unit,
                                   const clx_cia_stage_t stage,
                                   const uint32 udf_entry_id,
                                   clx_cia_udf_entry_t *ptr_entry_info);

clx_error_no_t
hal_mt_nb_cia_sparse_udf_entry_add(const uint32 unit,
                                   const clx_cia_stage_t stage,
                                   const uint32 udf_entry_id,
                                   const clx_cia_udf_entry_t *ptr_entry_info);

clx_error_no_t
hal_mt_nb_cia_sparse_udf_entry_del(const uint32 unit,
                                   const clx_cia_stage_t stage,
                                   const uint32 udf_entry_id);

clx_error_no_t
hal_mt_nb_cia_sparse_udf_entry_trav(const uint32 unit,
                                    const clx_cia_stage_t stage,
                                    const clx_cia_udf_entry_trav_func_t callback,
                                    void *ptr_cookie);

clx_error_no_t
hal_mt_nb_cia_sparse_entry_id_info_get(const uint32 unit,
                                       const uint32 entry_id,
                                       clx_cia_stage_t *ptr_stage,
                                       uint32 *ptr_grp_id,
                                       uint32 *ptr_entry_pri);

clx_error_no_t
hal_mt_nb_cia_sparse_entry_id_alloc(const uint32 unit,
                                    const clx_cia_stage_t stage,
                                    const uint32 grp_id,
                                    const uint32 entry_pri,
                                    uint32 *ptr_entry_id);

clx_error_no_t
hal_mt_nb_cia_sparse_entry_id_free(const uint32 unit, const uint32 entry_id);

clx_error_no_t
hal_mt_nb_cia_sparse_entry_add(const uint32 unit,
                               const uint32 entry_id,
                               const clx_cia_entry_t *ptr_entry_info);

clx_error_no_t
hal_mt_nb_cia_sparse_entry_get(const uint32 unit,
                               const uint32 entry_id,
                               clx_cia_entry_t *ptr_entry_info);

clx_error_no_t
hal_mt_nb_cia_sparse_entry_vld_set(const uint32 unit,
                                   const uint32 entry_id,
                                   const boolean entry_vld);

clx_error_no_t
hal_mt_nb_cia_sparse_entry_del(const uint32 unit, const uint32 entry_id);

clx_error_no_t
hal_mt_nb_cia_sparse_entry_trav(const uint32 unit,
                                const clx_cia_stage_t stage,
                                const uint32 grp_id,
                                const clx_cia_entry_trav_func_t callback,
                                void *ptr_cookie);

clx_error_no_t
hal_mt_nb_cia_sparse_exact_entry_get(const uint32 unit,
                                     const clx_cia_stage_t stage,
                                     const uint32 grp_id,
                                     const uint32 entry_id,
                                     clx_cia_exact_entry_t *ptr_entry_info);

clx_error_no_t
hal_mt_nb_cia_sparse_exact_entry_del(const uint32 unit,
                                     const clx_cia_stage_t stage,
                                     const uint32 grp_id,
                                     const uint32 entry_id);

clx_error_no_t
hal_mt_nb_cia_sparse_exact_entry_trav(const uint32 unit,
                                      const clx_cia_stage_t stage,
                                      const uint32 grp_id,
                                      const clx_cia_exact_entry_trav_func_t callback,
                                      void *ptr_cookie);

clx_error_no_t
hal_mt_nb_cia_sparse_exact_entry_id_info_get(const uint32 unit,
                                             const uint32 entry_id,
                                             clx_cia_stage_t *ptr_stage,
                                             uint32 *ptr_grp_id);

clx_error_no_t
hal_mt_nb_cia_sparse_rim_free(const uint32 unit,
                              const clx_cia_rim_alloc_t type,
                              const uint32 index);

clx_error_no_t
hal_mt_nb_cia_sparse_rim_act_set(const uint32 unit,
                                 const clx_cia_rim_alloc_t type,
                                 const uint32 index,
                                 const void *ptr_act);

clx_error_no_t
hal_mt_nb_cia_sparse_rim_act_get(const uint32 unit,
                                 const clx_cia_rim_alloc_t type,
                                 const uint32 index,
                                 void *ptr_act);

clx_error_no_t
hal_mt_nb_cia_sparse_rim_act_trav(const uint32 unit,
                                  const clx_cia_rim_alloc_t type,
                                  const clx_cia_rim_trav_func_t callback,
                                  void *ptr_cookie);

clx_error_no_t
hal_mt_nb_cia_sparse_capacity_get(const uint32 unit,
                                  const clx_swc_rsrc_t type,
                                  const uint32 param,
                                  uint32 *ptr_size);
clx_error_no_t
hal_mt_nb_cia_sparse_usage_get(const uint32 unit,
                               const clx_swc_rsrc_t type,
                               const uint32 param,
                               uint32 *ptr_cnt);

clx_error_no_t
hal_mt_nb_cia_sparse_swc_capacity_get(const uint32 unit,
                                      const clx_swc_rsrc_t type,
                                      const uint32 param,
                                      uint32 *ptr_size);

clx_error_no_t
hal_mt_nb_cia_sparse_swc_usage_get(const uint32 unit,
                                   const clx_swc_rsrc_t type,
                                   const uint32 param,
                                   uint32 *ptr_cnt);

#endif
