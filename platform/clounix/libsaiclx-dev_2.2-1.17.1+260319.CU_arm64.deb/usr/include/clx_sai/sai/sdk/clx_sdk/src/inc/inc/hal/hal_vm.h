/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_vm.h
 * PURPOSE:
 *  Define the declartion for VLAN module.
 *
 * NOTES:
 *
 */

#ifndef HAL_VM_H
#define HAL_VM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <util/util_log.h>
#include <hal/hal.h>

#define HAL_VM_ETAG_ETYPE  (0x893f)
#define HAL_VM_VNTAG_ETYPE (0x8926)

#define HAL_VM_LOG_ERR(...)  UTIL_LOG_PRINT(UTIL_LOG_VM, UTIL_LOG_ERR, ##__VA_ARGS__)
#define HAL_VM_LOG_WARN(...) UTIL_LOG_PRINT(UTIL_LOG_VM, UTIL_LOG_WARN, ##__VA_ARGS__)
#define HAL_VM_LOG_INFO(...) UTIL_LOG_PRINT(UTIL_LOG_VM, UTIL_LOG_INFO, ##__VA_ARGS__)

#define HAL_VM_MULTI_FVP_PACK(field, field_val, fvp_cnt, fvp_info)    \
    do {                                                              \
        fvp_info[fvp_cnt].field_id = field;                           \
        fvp_info[fvp_cnt].value_type = TOB_FVB_VALUE_TYPE_UI32_FIELD; \
        fvp_info[fvp_cnt].value = field_val;                          \
        fvp_cnt++;                                                    \
    } while (0)

#define HAL_VM_SINGLE_FVP_PACK(field, field_val, fvp_info)   \
    do {                                                     \
        fvp_info.field_id = field;                           \
        fvp_info.value_type = TOB_FVB_VALUE_TYPE_UI32_FIELD; \
        fvp_info.value = field_val;                          \
    } while (0)

#define HAL_VM_PLANE_PORT_TO_LCL_INTF(unit, port)                      \
    HAL_PLANE_PORT_TO_LCL_INTF(unit, HAL_CL_PORT_TO_PLANE(unit, port), \
                               HAL_CL_PORT_TO_PLANE_PORT(unit, port));

#define HAL_VM_CL_PORT_TO_DI(unit, port, di)                                    \
    do {                                                                        \
        if (HAL_OBJ_CHK((port))) {                                              \
            HAL_OBJ_DI_GET((port), (di));                                       \
        } else {                                                                \
            (di) = HAL_CL_PORT_TO_DI((unit), HAL_GBL_CHIP_IDX((unit)), (port)); \
        }                                                                       \
    } while (0)

#define HAL_VM_PE_PORT_CHK(unit, port)                                                         \
    do {                                                                                       \
        clx_gport_type_t port_type = CLX_GPORT_TYPE_LAST;                                      \
        HAL_OBJ_TYPE_GET((port), port_type);                                                   \
        uint32 port_unit = 0;                                                                  \
        uint32 lag_id;                                                                         \
        hal_intf_obj_info_t obj_info = {0};                                                    \
        switch (port_type) {                                                                   \
            case CLX_GPORT_TYPE_LOCAL:                                                         \
                HAL_CHECK_PP_PORT((unit), (port));                                             \
                break;                                                                         \
            case CLX_GPORT_TYPE_UNIT_PORT:                                                     \
                rc = hal_obj_port_info_get((unit), (port), &obj_info);                         \
                if (CLX_E_OK == rc) {                                                          \
                    port_unit = HAL_DI_TO_CHIP_ID((unit), obj_info.di);                        \
                    if (port_unit != HAL_GBL_CHIP_IDX((unit))) {                               \
                        HAL_VM_LOG_ERR("u=%u, port_unit=%u\n", (unit), (port_unit));           \
                        return CLX_E_BAD_PARAMETER;                                            \
                    }                                                                          \
                } else {                                                                       \
                    HAL_VM_LOG_ERR("u=%u, get obj=0x%x info failed\n", (unit), (port));        \
                    return rc;                                                                 \
                }                                                                              \
                break;                                                                         \
            case CLX_GPORT_TYPE_LAG:                                                           \
                rc = hal_lag_id_get(unit, port, &lag_id);                                      \
                if (CLX_E_OK != rc) {                                                          \
                    HAL_VM_LOG_ERR("get lag_id by port(0x%x) failed, rc=%u.\n", port, rc);     \
                    return CLX_E_BAD_PARAMETER;                                                \
                }                                                                              \
                /* check LAG */                                                                \
                rc = hal_lag_check(unit, lag_id);                                              \
                if (CLX_E_OK != rc) {                                                          \
                    HAL_VM_LOG_ERR("port=0x%x is invalid LAG, rc=%u.\n", port, rc);            \
                    return CLX_E_BAD_PARAMETER;                                                \
                }                                                                              \
                break;                                                                         \
            default:                                                                           \
                HAL_VM_LOG_ERR("u=%u port=0x%x type=%u invalid\n", (unit), (port), port_type); \
                return CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                      \
    } while (0)

/**
 * @brief Init VM module lock.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
hal_vm_lock_init(const uint32 unit);

/**
 * @brief Deinit VM module lock.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
hal_vm_lock_deinit(const uint32 unit);

/**
 * @brief Lock VM module.
 *
 * @param [in]    unit    - Device unit number.
 */
void
hal_vm_lock(const uint32 unit);

/**
 * @brief Unlock VM module.
 *
 * @param [in]    unit    - Device unit number.
 */
void
hal_vm_unlock(const uint32 unit);

/**
 * @brief Substitute the specified bits (field) in the entry buffer with the field value.
 *
 * @param [in]     unit           - Unit number.
 * @param [in]     tbl_id         - Table ID.
 * @param [in]     field_id       - Field ID.
 * @param [in]     field_value    - Field value.
 * @param [out]    ptr_buf        - Pointer to the entry buffer.
 */
void
hal_vm_hw_field_pack(const uint32 unit,
                     const uint32 tbl_id,
                     const uint32 field_id,
                     const uint32 field_value,
                     uint32 *ptr_buf);

/**
 * @brief Extract the specified field from an entry buffer.
 *
 * @param [in]    unit        - Unit number.
 * @param [in]    tbl_id      - Table ID.
 * @param [in]    field_id    - Field ID.
 * @param [in]    ptr_buf     - Pointer to the entry buffer.
 * @return        Field value.
 */
uint32
hal_vm_hw_field_unpack(const uint32 unit,
                       const uint32 tbl_id,
                       const uint32 field_id,
                       const uint32 *ptr_buf);

/**
 * @brief Read one hw entry.
 *
 * Not support sub_inst
 * just support one entry.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     inst        - Instance.
 * @param [in]     tbl_id      - HW table ID.
 * @param [in]     entry_id    - HW entry ID.
 * @param [out]    ptr_buf     - HW entry buf.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_vm_hw_entry_read(const uint32 unit,
                     const uint32 inst,
                     const uint32 tbl_id,
                     const uint32 entry_id,
                     uint32 *ptr_buf);

/**
 * @brief Write one hw entry.
 *
 * Not support sub_inst
 * just support one entry.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    inst        - Instance.
 * @param [in]    tbl_id      - HW table ID.
 * @param [in]    entry_id    - HW entry ID.
 * @param [in]    ptr_buf     - HW entry buf.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_vm_hw_entry_write(const uint32 unit,
                      const uint32 inst,
                      const uint32 tbl_id,
                      const uint32 entry_id,
                      uint32 *ptr_buf);

/**
 * @brief Read hw entry field.
 *
 * Not support sub_inst.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     inst         - Instance.
 * @param [in]     tbl_id       - HW table ID.
 * @param [in]     entry_id     - HW entry ID.
 * @param [in]     field_num    - HW field number.
 * @param [in]     ptr_fvp      - HW field name.
 * @param [out]    ptr_fvp      - HW field value.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_vm_hw_field_read(const uint32 unit,
                     const uint32 inst,
                     const uint32 tbl_id,
                     const uint32 entry_id,
                     const uint32 field_num,
                     tob_fvp_t *ptr_fvp);

/**
 * @brief Write hw entry field.
 *
 * Not support sub_inst.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    inst         - Instance.
 * @param [in]    tbl_id       - HW table ID.
 * @param [in]    entry_id     - HW entry ID.
 * @param [in]    field_num    - HW field number.
 * @param [in]    ptr_fvp      - HW field info.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_vm_hw_field_write(const uint32 unit,
                      const uint32 inst,
                      const uint32 tbl_id,
                      const uint32 entry_id,
                      const uint32 field_num,
                      tob_fvp_t *ptr_fvp);

/**
 * @brief Lookup hw hash entry.
 *
 * Not support inst and sub_inst.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    tbl_id          - HW table ID.
 * @param [in]    ptr_bank_bmp    - Bank bitmap, value 0 is not care.
 * @param [in]    ptr_buf         - HW buf.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_vm_hw_hsh_lookup(const uint32 unit, const uint32 tbl_id, uint32 *ptr_bank_bmp, uint32 *ptr_buf);

/**
 * @brief Add hw hash entry.
 *
 * Not support inst and sub_inst.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    tbl_id          - HW table ID.
 * @param [in]    ptr_bank_bmp    - Bank bitmap, value 0 is not care.
 * @param [in]    ptr_buf         - HW buf.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_vm_hw_hsh_add(const uint32 unit, const uint32 tbl_id, uint32 *ptr_bank_bmp, uint32 *ptr_buf);

/**
 * @brief Del hw hash entry.
 *
 * Not support inst and sub_inst.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    tbl_id          - HW table ID.
 * @param [in]    ptr_bank_bmp    - Bank bitmap, value 0 is not care.
 * @param [in]    ptr_buf         - HW buf.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_vm_hw_hsh_del(const uint32 unit, const uint32 tbl_id, uint32 *ptr_bank_bmp, uint32 *ptr_buf);

/**
 * @brief Translate DI to port.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     di          - Destination index.
 * @param [out]    ptr_port    - CLX port.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_vm_di_to_port_trans(const uint32 unit, const uint32 di, clx_port_t *ptr_port);

#endif
