/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_swc.h
 * PURPOSE:
 *    It provides HAL driver API functions for swc module.
 *
 * NOTES:
 *
 *
 */
#ifndef HAL_MT_SWC_H
#define HAL_MT_SWC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <math.h>
#include <clx/clx_pkt.h>
#include <hal/mt/hal_mt_pkt_rsrc.h>
#include <hal/hal.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_SWC_RSN_PRI_MIN         (0)
#define HAL_MT_SWC_RSN_PRI_MAX         (15)
#define HAL_MT_SWC_RSN_CLK_TO_NS(unit) (1000.0 / HAL_DEVICE_FREQ(unit))
#define HAL_MT_SWC_RSN_PRI_SPT         (12)
#define HAL_MT_SWC_RSN_PRI_SPT_HIGHT   (HAL_MT_SWC_RSN_PRI_SPT + 1)

#define HAL_MT_SWC_HSH_ID_ECMP_L3    (0)
#define HAL_MT_SWC_HSH_ID_ECMP_NVO3  (1)
#define HAL_MT_SWC_HSH_ID_MPLS       (1)
#define HAL_MT_SWC_HSH_ID_LAG        (2)
#define HAL_MT_SWC_HSH_ID_FABRIC_LAG (2)
#define HAL_MT_SWC_HSH_ID_ECMP_L2    (3)
#define HAL_MT_SWC_HSH_ENG_NUM       (4)

#define HAL_MT_SWC_CB(unit) (&_hal_mt_swc_cb[unit])
#define HAL_MT_SWC_LOCK(unit) \
    HAL_COMMON_LOCK_RESOURCE(&(_hal_mt_swc_cb[unit].sema_id), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_MT_SWC_UNLOCK(unit)          HAL_COMMON_FREE_RESOURCE(&(_hal_mt_swc_cb[unit].sema_id))
#define HAL_MT_CHIP_INIT_PP_TCAM_CHK_NUM (14)
#define HAL_MT_CHIP_INIT_PP_HSH_CHK_NUM  (12)

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_mt_swc_epp_rsn_act_e {
    HAL_MT_SWC_EPP_RSN_ACT_DISABLE = 0,
    HAL_MT_SWC_EPP_RSN_ACT_COPY,
    HAL_MT_SWC_EPP_RSN_ACT_REDIR,
    HAL_MT_SWC_EPP_RSN_ACT_DROP,
    HAL_MT_SWC_EPP_RSN_ACT_LAST
} hal_mt_swc_epp_rsn_act_t;

typedef enum hal_mt_swc_wbdb_obj_type_e {
    HAL_MT_SWC_WBDB_CFG_ID = 0,
    HAL_MT_SWC_WBDB_CB_ID,
    HAL_MT_SWC_WBDB_OBJ_LAST
} hal_mt_swc_wbdb_obj_type_t;

typedef struct hal_mt_swc_cb_s {
    clx_semaphore_id_t sema_id;
    boolean excpt_ctrl;
    clx_swc_rsn_act_t rx_reason_action[CLX_PKT_RX_REASON_LAST];
    clx_swc_rsn_act_t pp_rsn_act[HAL_MT_PKT_PP_RSN_NUM];
    clx_fwd_action_t excpt_act[CLX_PKT_RX_REASON_LAST];
    uint32 reason_prio[HAL_MT_PKT_PP_RSN_NUM];
} hal_mt_swc_cb_t;

typedef void (*hal_swc_tcam_cfg_func_t)(uint32 unit,
                                        uint32 tcam_table,
                                        uint32 *tcam_field,
                                        uint32 *stage_cfg_buf);
typedef struct hal_mt_swc_hal_tcam_cfg_s {
    clx_swc_tcam_type_t tcam_type;
    hal_swc_tcam_cfg_func_t tcam_cfg;
} hal_mt_swc_hal_tcam_cfg_t;

typedef struct hal_mt_swc_hal_tile_bmp_s {
    clx_swc_hsh_tile_type_t hash_tile;
    hal_hash_type_t hash_type;
} hal_mt_swc_hal_tile_bmp_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
clx_error_no_t
hal_mt_swc_hsh_tile_bmp_get(const uint32 unit,
                            const clx_swc_hsh_tile_type_t hash_tile_type,
                            hal_swc_hsh_tile_bmp_t ptr_bmp);

clx_error_no_t
hal_mt_swc_tcam_bmp_get(const uint32 unit,
                        const clx_swc_tcam_type_t tcam_type,
                        hal_swc_tcam_bmp_t ptr_bmp);

/**
 * @brief This function is to get max timestamp sec.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    max_ts_sec    - Max Timestamp sec.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_swc_max_ts_sec_get(const uint32 unit, uint32 *max_ts_sec);

/**
 * @brief To initialize switch control module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
hal_mt_swc_init(const uint32 unit);

/**
 * @brief To deinitialize switch control module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
hal_mt_swc_deinit(const uint32 unit);

#endif /* End of HAL_MT_SWC_H */
