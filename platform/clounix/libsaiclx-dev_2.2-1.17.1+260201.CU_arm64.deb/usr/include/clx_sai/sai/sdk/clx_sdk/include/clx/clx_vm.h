/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_vm.h
 * PURPOSE:
 *      It provides VM module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_VM_H
#define CLX_VM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum clx_vm_mode_e {
    CLX_VM_MODE_CB,      /* 802.1BR Controlling Bridge (CB mode)               */
    CLX_VM_MODE_BASE_PE, /* 802.1BR Base Port Extension (BASE PE mode)         */
    CLX_VM_MODE_LAST
} clx_vm_mode_t;

typedef enum clx_vm_port_type_e {
    CLX_VM_PORT_TYPE_N, /* CB default port type, PE not support */
    CLX_VM_PORT_TYPE_1BR_UPSTREAM,
    CLX_VM_PORT_TYPE_1BR_CASCADE,
    CLX_VM_PORT_TYPE_1BR_EXTEND, /* PE default port type */
    CLX_VM_PORT_TYPE_NIV_UPSTREAM,
    CLX_VM_PORT_TYPE_NIV_CASCADE,
    CLX_VM_PORT_TYPE_NIV_EXTEND,
    CLX_VM_PORT_TYPE_LAST
} clx_vm_port_type_t;

typedef struct clx_vm_port_cfg_s {
    clx_vm_port_type_t vm_port_type; /* Refer to CLX_VM_PORT_TYPE_XXX */
    uint32 dflt_vm_id;               /* Default VM ID */
    uint32 flags;                    /* Refer to CLX_VM_PORT_CFG_FLAGS_XXX */

    uint32 attr_bmp;                 /* Refer to CLX_VM_PORT_CFG_ATTR_XXX */
} clx_vm_port_cfg_t;
#define CLX_VM_PORT_CFG_FLAGS_FORCE_USE_DFLT_VM_ID \
    (1U << 0)                                       /* Force use default VM ID, CB support */

#define CLX_VM_PORT_CFG_ATTR_VM_PORT_TYPE (1U << 0) /* attr port_type */
#define CLX_VM_PORT_CFG_ATTR_DFLT_VM_ID \
    (1U << 1) /* attr dflt_vm_id and CLX_VM_PORT_CFG_FLAGS_FORCE_USE_DFLT_VM_ID */

typedef enum clx_vm_tag_type_e {
    CLX_VM_TAG_TYPE_ETAG,  /* 802.1BR E_Tag  */
    CLX_VM_TAG_TYPE_VNTAG, /* NIV VN_Tag */
    CLX_VM_TAG_TYPE_LAST
} clx_vm_tag_type_t;

typedef struct clx_vm_info_s {
    clx_vm_tag_type_t type;                     /* 802.1BR/VN-TAG */
    clx_port_t port;                            /* phy port/LAG */
    uint32 vm_id;                               /* UC 802.1BR ECID or VN-TAG VIF */
    uint32 flags;                               /* Refer to CLX_VM_INFO_FLAGS_XXX */
} clx_vm_info_t;
#define CLX_VM_INFO_FLAGS_NO_LCL_INTF (1U << 0) /* create port without local interface */

typedef enum clx_vm_pe_downstream_type_e {
    CLX_VM_PE_DOWNSTREAM_TYPE_UC,
    CLX_VM_PE_DOWNSTREAM_TYPE_MC,
    CLX_VM_PE_DOWNSTREAM_TYPE_LAST
} clx_vm_pe_downstream_type_t;

typedef struct clx_vm_pe_downstream_entry_s {
    clx_vm_pe_downstream_type_t downstream_type;
    clx_vm_tag_type_t vm_tag_type;
    uint32 vm_id;         /* UC/MC VM ID */
    union {
        clx_port_t dport; /* port/LAG */
        uint32 mcast_id;  /* Multicast group ID */
    };
} clx_vm_pe_downstream_entry_t;

typedef struct clx_vm_pe_upstream_entry_s {
    uint32 sport; /* Source port/LAG */
    uint32 dport; /* Destination port/LAG */
} clx_vm_pe_upstream_entry_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Set the chip's VM mode.
 *
 * Before modifying the mode, need to reset the all VM configuration to default values.
 * Support_chip: CLX84.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    mode    - VM mode of the chip.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_SUPPORT      - Not support.
 */
clx_error_no_t
clx_vm_mode_set(const uint32 unit, const clx_vm_mode_t mode);

/**
 * @brief Get the chip's VM mode.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit        - Device unit number.
 * @param [out]    ptr_mode    - VM mode of the chip.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_SUPPORT      - Not support.
 */
clx_error_no_t
clx_vm_mode_get(const uint32 unit, clx_vm_mode_t *ptr_mode);

/**
 * @brief Create a VM port.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     ptr_vm_info    - VM information.
 * @param [out]    ptr_vm_port    - VM port.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - No such entry.
 * @return         CLX_E_NOT_SUPPORT      - Not support.
 * @return         CLX_E_ENTRY_EXISTS     - Port existed.
 */
clx_error_no_t
clx_vm_port_create(const uint32 unit, const clx_vm_info_t *ptr_vm_info, clx_port_t *ptr_vm_port);

/**
 * @brief Destroy a VM port.
 *
 * Need to destroy the VM port of LAG before destroy LAG.
 * Support_chip: CLX84.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    vm_port    - VM port.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - No such entry.
 * @return        CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
clx_vm_port_destroy(const uint32 unit, clx_port_t vm_port);

/**
 * @brief Get VM port information.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     vm_port        - VM port.
 * @param [out]    ptr_vm_info    - VM information of VM port.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry.
 * @return         CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
clx_vm_port_get(const uint32 unit, const clx_port_t vm_port, clx_vm_info_t *ptr_vm_info);

/**
 * @brief Set property of VM port.
 *
 * Need to clear the VM property of LAG before destroy LAG.
 * Support_chip: CLX84.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Port/LAG.
 * @param [in]    ptr_port_cfg    - VM port property.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_SUPPORT      - Not support.
 */
clx_error_no_t
clx_vm_port_cfg_set(const uint32 unit,
                    const clx_port_t port,
                    const clx_vm_port_cfg_t *ptr_port_cfg);

/**
 * @brief Get property of VM port.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Port/LAG.
 * @param [out]    ptr_port_cfg    - VM port property.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_SUPPORT      - Not support.
 */
clx_error_no_t
clx_vm_port_cfg_get(const uint32 unit, const clx_port_t port, clx_vm_port_cfg_t *ptr_port_cfg);

/**
 * @brief Add downstream entry of PE.
 *
 * Support_chip: CLX84.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    ptr_entry    - Downstream entry.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Table full.
 * @return        CLX_E_NOT_SUPPORT      - Not support.
 */
clx_error_no_t
clx_vm_pe_downstream_entry_add(const uint32 unit, const clx_vm_pe_downstream_entry_t *ptr_entry);

/**
 * @brief Del downstream entry of PE.
 *
 * Need to delete the downstream entry of LAG before destroy LAG.
 * Support_chip: CLX84.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    ptr_entry    - Downstream entry, key is downstream_type,
 *                               vm_tag_type and vm_id.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Not found.
 * @return        CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
clx_vm_pe_downstream_entry_del(const uint32 unit, const clx_vm_pe_downstream_entry_t *ptr_entry);

/**
 * @brief Gel downstream entry of PE.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     ptr_entry    - Downstream entry, key is downstream_type,
 *                                vm_tag_type and vm_id.
 * @param [out]    ptr_entry    - Downstream entry, value is dport/mcast_id.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Not found.
 * @return         CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
clx_vm_pe_downstream_entry_get(const uint32 unit, clx_vm_pe_downstream_entry_t *ptr_entry);

/**
 * @brief Add/update upstream entry of PE.
 *
 * Support_chip: CLX84.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    ptr_entry    - Upstream entry.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_SUPPORT      - Not support.
 */
clx_error_no_t
clx_vm_pe_upstream_entry_add(const uint32 unit, const clx_vm_pe_upstream_entry_t *ptr_entry);

/**
 * @brief Delete upstream entry of PE.
 *
 * Need to delete the upstream entry of LAG before destroy LAG.
 * Support_chip: CLX84.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    ptr_entry    - Upstream entry, key is sport.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_SUPPORT      - Not support.
 */
clx_error_no_t
clx_vm_pe_upstream_entry_del(const uint32 unit, const clx_vm_pe_upstream_entry_t *ptr_entry);

/**
 * @brief Get upstream entry of PE.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     ptr_entry    - Upstream entry, key is sport.
 * @param [out]    ptr_entry    - Upstream entry, value is dport.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_NOT_SUPPORT        - Not support.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Not found entry.
 */
clx_error_no_t
clx_vm_pe_upstream_entry_get(const uint32 unit, clx_vm_pe_upstream_entry_t *ptr_entry);

#endif /* End of CLX_VM_H */
