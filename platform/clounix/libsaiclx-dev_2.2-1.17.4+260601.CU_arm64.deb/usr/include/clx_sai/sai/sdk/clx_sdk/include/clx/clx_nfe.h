/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_nfe.h
 * PURPOSE:
 *      Provide the interface for netflow module.
 *
 * NOTES:
 *
 */

#ifndef CLX_NFE_H
#define CLX_NFE_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>

/* NAMING DECLARATIONS
 */
#define CLX_NFE_PROFILE_INVALID_ID 0xFFFFFFFF

/* DATA TYPE DECLARATIONS
 */
/* Define the direction of nfe */
typedef enum clx_nfe_dir_e {
    CLX_NFE_DIR_IGR,  /* Ingress direction */
    CLX_NFE_DIR_EGR,  /* Egress direction */
    CLX_NFE_DIR_LAST, /* Last direction */
} clx_nfe_dir_t;

/* define nfe support forward status */
typedef enum clx_nfe_fwd_status_e {
    CLX_NFE_FWD_STATUS_FORWARD,
    CLX_NFE_FWD_STATUS_CP2CPU,
    CLX_NFE_FWD_STATUS_TRAP2CPU,
    CLX_NFE_FWD_STATUS_DROP,
    CLX_NFE_FWD_STATUS_LAST,
} clx_nfe_fwd_status_t;

/* define nfe support packet type */
typedef enum clx_nfe_pkt_type_e {
    CLX_NFE_PKT_TYPE_ALL,  /* All packet type */
    CLX_NFE_PKT_TYPE_IPV4, /* IPv4  */
    CLX_NFE_PKT_TYPE_IPV6, /* IPv6 */
    CLX_NFE_PKT_TYPE_L2,   /* L2 */
    CLX_NFE_PKT_TYPE_LAST, /* Last packet type */
} clx_nfe_pkt_type_t;

/* define nfe support packet length type */
typedef enum clx_nfe_pkt_len_type_e {
    CLX_NFE_PKT_LEN_TYPE_FRM,  /* Frame length */
    CLX_NFE_PKT_LEN_TYPE_IP,   /* IP length */
    CLX_NFE_PKT_LEN_TYPE_LAST, /* Last packet length type */
} clx_nfe_pkt_len_type_t;

/* define nfe support tunnel type */
typedef enum clx_nfe_tnl_type_e {
    CLX_NFE_TNL_TYPE_NONE,
    CLX_NFE_TNL_TYPE_GRE_WITH_KEY,
    CLX_NFE_TNL_TYPE_VXLAN_GBP,
    CLX_NFE_TNL_TYPE_GENEVE_OR_VXLAN_BAS,
    CLX_NFE_TNL_TYPE_LAST,
} clx_nfe_tnl_type_t;

/* define nfe support statistisc lantency mode */
typedef enum clx_nfe_latency_unit_e {
    CLX_NFE_LATENCY_UNIT_1NS,    /* 1ns */
    CLX_NFE_LATENCY_UNIT_2NS,    /* 2ns */
    CLX_NFE_LATENCY_UNIT_4NS,    /* 4ns */
    CLX_NFE_LATENCY_UNIT_8NS,    /* 8ns */
    CLX_NFE_LATENCY_UNIT_16NS,   /* 16ns */
    CLX_NFE_LATENCY_UNIT_32NS,   /* 32ns */
    CLX_NFE_LATENCY_UNIT_64NS,   /* 64ns */
    CLX_NFE_LATENCY_UNIT_128NS,  /* 128ns */
    CLX_NFE_LATENCY_UNIT_256NS,  /* 256ns */
    CLX_NFE_LATENCY_UNIT_512NS,  /* 512ns */
    CLX_NFE_LATENCY_UNIT_1024NS, /* 1024ns */
    CLX_NFE_LATENCY_UNIT_LAST,   /* Last latency unit */
} clx_nfe_latency_unit_t;

/* define nfe support flow data type */
typedef enum clx_nfe_flow_data_e {
    CLX_NFE_FLOW_DATA_IGR_INTF_IDX,
    CLX_NFE_FLOW_DATA_EGR_INTF_IDX,
    CLX_NFE_FLOW_DATA_IGR_BDI,
    CLX_NFE_FLOW_DATA_EGR_BDI,
    CLX_NFE_FLOW_DATA_L2_SA_LBL,
    CLX_NFE_FLOW_DATA_L2_DA_LBL,
    CLX_NFE_FLOW_DATA_L3_SA_LBL,
    CLX_NFE_FLOW_DATA_L3_DA_LBL,
    CLX_NFE_FLOW_DATA_QUEUE_ID,
    /* L3 */
    CLX_NFE_FLOW_DATA_L4_SRC_PORT,
    CLX_NFE_FLOW_DATA_L4_DST_PORT,
    CLX_NFE_FLOW_DATA_IP4_TOS,
    CLX_NFE_FLOW_DATA_IP4_FRAG,
    CLX_NFE_FLOW_DATA_IP_TTL_OR_HOP_LIM,
    CLX_NFE_FLOW_DATA_IP4_OPT0_TYPE,
    CLX_NFE_FLOW_DATA_IP4_OPT1_TYPE,
    CLX_NFE_FLOW_DATA_IP4_SRC_ADDR,
    CLX_NFE_FLOW_DATA_IP4_DST_ADDR,
    CLX_NFE_FLOW_DATA_IP6_SRC_ADDR,
    CLX_NFE_FLOW_DATA_IP6_DST_ADDR,
    CLX_NFE_FLOW_DATA_IP6_FLOW_LBL,
    CLX_NFE_FLOW_DATA_IP_TRANSPORT_PROTO,
    CLX_NFE_FLOW_DATA_IP_VRF,
    CLX_NFE_FLOW_DATA_IP_ECN,
    /* Tunnel */
    CLX_NFE_FLOW_DATA_TNL_VXLAN_GBP,
    CLX_NFE_FLOW_DATA_TNL_GENEVE_OR_VXLAN_BAS,
    CLX_NFE_FLOW_DATA_TNL_GRE_KEY,
    /* L2 */
    CLX_NFE_FLOW_DATA_L2_SRC_MAC,
    CLX_NFE_FLOW_DATA_L2_DST_MAC,
    CLX_NFE_FLOW_DATA_L2_ETH_TYPE,
    CLX_NFE_FLOW_DATA_L2_SVLAN_VID,
    CLX_NFE_FLOW_DATA_L2_SVLAN_PCP_DEI,
    CLX_NFE_FLOW_DATA_L2_CVLAN_VID,
    CLX_NFE_FLOW_DATA_L2_CVLAN_PCP_DEI,
    /* Flow stats */
    CLX_NFE_FLOW_DATA_START_TS, /* Start timestamp, msb 22bit is seconds, lsb 10bit is microseconds
                                 */
    CLX_NFE_FLOW_DATA_END_TS,   /* End timestamp, msb 22bit is seconds, lsb 10bit is microseconds */
    CLX_NFE_FLOW_DATA_PKT_CNT,  /* Packet count */
    CLX_NFE_FLOW_DATA_BYTE_CNT, /* Byte count */
    CLX_NFE_FLOW_DATA_TOTAL_LATENCY,
    CLX_NFE_FLOW_DATA_MAX_LATENCY,
    CLX_NFE_FLOW_DATA_TOTAL_OCCUPANCY,
    CLX_NFE_FLOW_DATA_MAX_OCCUPANCY,
    CLX_NFE_FLOW_DATA_LAST,
} clx_nfe_flow_data_t;

/* define nfe support event flag */
#define CLX_NFE_EVENT_FLAG_TCP_FIN                0x01
#define CLX_NFE_EVENT_FLAG_TCP_RST                0x02
#define CLX_NFE_EVENT_FLAG_NEW_LRN                0x04
#define CLX_NFE_EVENT_FLAG_BYTE_CNT_OVERFLOW      0x08
#define CLX_NFE_EVENT_FLAG_PKT_CNT_OVERFLOW       0x10
#define CLX_NFE_EVENT_FLAG_TOTAL_QUEUE_OVERFLOW   0x20
#define CLX_NFE_EVENT_FLAG_TOTAL_LATENCY_OVERFLOW 0x40
#define CLX_NFE_EVENT_FLAG_CONFLICT               0x80
#define CLX_NFE_EVENT_FLAG_REMOVE                 0x100
#define CLX_NFE_EVENT_FLAG_ALL                    0xFF

/* Modify nfe profile cfg flags */
#define CLX_NFE_PROF_CFG_FLAG_PKT_LEN_TYPE       0x0001
#define CLX_NFE_PROF_CFG_FLAG_PREFIX_LEN         0x0002
#define CLX_NFE_PROF_CFG_FLAG_SAMPLER_RATE       0x0004
#define CLX_NFE_PROF_CFG_FLAG_STATS_LATENCY_MODE 0x0008
#define CLX_NFE_PROF_CFG_FLAG_PKT_TYPE           0x0010
#define CLX_NFE_PROF_CFG_FLAG_EVENT              0x0020
#define CLX_NFE_PROF_CFG_FLAG_MATCH_KEY          0x0040
#define CLX_NFE_PROF_CFG_FLAG_ALL                0x00FF

/* define nfe support tcp flags */
#define CLX_NFE_TCP_FLAG_FIN 0x01
#define CLX_NFE_TCP_FLAG_SYN 0x02
#define CLX_NFE_TCP_FLAG_RST 0x04
#define CLX_NFE_TCP_FLAG_PSH 0x08
#define CLX_NFE_TCP_FLAG_ACK 0x10
#define CLX_NFE_TCP_FLAG_URG 0x20

/* The data structure is the flow data bitmap. */
typedef uint32 clx_nfe_flow_data_bmp_t[CLX_BITMAP_SIZE(CLX_NFE_FLOW_DATA_LAST)];

/* define nfe profile configuration information */
typedef struct clx_nfe_prof_cfg_info_s {
    uint32 flags;                          /* CLX_NFE_PROF_CFG_FLAG_XXX */
    clx_nfe_pkt_type_t pkt_type;           /* packet type */
    clx_nfe_pkt_len_type_t pkt_len_type;   /* packet length type */
    clx_nfe_latency_unit_t latency_unit;   /* latency unit */
    uint32 flow_event;                     /* The flow event cfg */
    uint32 sampler_rate;                   /* sampler rate */
    uint32 sip_prefix_mask;                /* sip prefix mask */
    uint32 dip_prefix_mask;                /* dip prefix mask */
    uint32 sip6_prefix_mask;               /* sip6 prefix mask */
    uint32 dip6_prefix_mask;               /* dip6 prefix mask */
    clx_nfe_flow_data_bmp_t flow_data_bmp; /* flow data bitmap */
} clx_nfe_prof_cfg_info_t;

#define CLX_NFE_THD_FLAGS_YELLOW 0x1
#define CLX_NFE_THD_FLAGS_RED    0x2
#define CLX_NFE_THD_FLAGS_ALL    0x3

/* define nfe threshold configuration */
typedef struct clx_nfe_thd_cfg_s {
    uint32 flags;      /* CLX_NFE_THD_FLAGS_XXX */
    uint32 yellow_thd; /* yellow threshold */
    uint32 red_thd;    /* red threshold */
} clx_nfe_thd_cfg_t;

/* define nfe flow information struct */
#pragma pack(1)
typedef struct clx_nfe_flow_data_tlv_s {
    uint8 type;
    uint8 len; /* Only including value length */
    uint8 value[];
} clx_nfe_flow_data_tlv_t;

typedef struct clx_nfe_flow_data_info_s {
    uint32 event;           /* event */
    uint8 direction;        /* direction, refer to CLX_NFE_DIR_XXX */
    uint8 fwd_status;       /* forward status */
    uint8 tcp_flags;        /* tcp flags */
    uint8 prof_idx;         /* profile index */
    uint8 pkt_type;         /* packet type */
    uint8 tnl_type;         /* tunnel type */
    uint8 reserved;         /* reserved */
    uint8 flow_data_cnt;    /* flow data count */
    uint8 flow_data_list[]; /* flow data list, ref to clx_nfe_flow_data_tlv_t */
} clx_nfe_flow_data_info_t;

/* define nfe flow data header */
typedef struct clx_nfe_flow_data_hdr_s {
    uint32 flow_cnt;                      /* flow data count */
    uint32 flow_len;                      /* flow data length */
    clx_nfe_flow_data_info_t flow_list[]; /* flow data list */
} clx_nfe_flow_data_hdr_t;
#pragma pack()

typedef clx_error_no_t (*clx_nfe_flow_data_notify_func_t)(uint32 unit,
                                                          clx_nfe_flow_data_hdr_t *flow,
                                                          void *cookie);

extern uint8 clx_nfe_flow_data_len[CLX_NFE_FLOW_DATA_LAST];

/* MACRO FUNCTION DECLARATIONS
 */
#define CLX_NFE_INDEX_OF_BMP(key)  ((key) / 32)
#define CLX_NFE_OFFSET_OF_BMP(key) (1UL << ((key) % 32))

#define CLX_NFE_FLOW_DATA_BMP_SET(flow_data_bmp, key) \
    (((uint32 *)(flow_data_bmp))[INDEX_OF_BMP(key)] |= OFFSET_OF_BMP(key))
#define CLX_NFE_FLOW_DATA_BMP_CLR(flow_data_bmp, key) \
    (((uint32 *)(flow_data_bmp))[INDEX_OF_BMP(key)] &= ~OFFSET_OF_BMP(key))
#define CLX_NFE_FLOW_DATA_BMP_CHK(flow_data_bmp, key) \
    (((uint32 *)(flow_data_bmp))[INDEX_OF_BMP(key)] & OFFSET_OF_BMP(key))

#define CLX_NFE_FLOW_DATA_BMP_FOREACH(flow_data_bmp, key) \
    for (key = 0; key < CLX_NFE_FLOW_DATA_LAST; key++)    \
        if (CLX_NFE_FLOW_DATA_BMP_CHK(flow_data_bmp, key))

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief This API is used to create nfe profile.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     ptr_nfe_info       - The pointer to nfe profile config info.
 * @param [out]    ptr_nfe_prof_id    - The pointer to nfe profile id which will be created.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_nfe_prof_create(const uint32 unit,
                    const clx_nfe_prof_cfg_info_t *ptr_nfe_info,
                    uint32 *ptr_nfe_prof_id);

/**
 * @brief This API is used to destroy nfe profile.
 *
 * Support_chip: CLX84.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    nfe_prof_id    - The pointer to nfe profile id which will be created.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_OTHERS           - Other errors.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 */
clx_error_no_t
clx_nfe_prof_destroy(const uint32 unit, const uint32 nfe_prof_id);

/**
 * @brief This API is used to set nfe profile configuration.
 *
 * Support_chip: CLX84.
 *
 * @param [in]    unit                 - Device unit number.
 * @param [in]    nfe_prof_id          - The pointer to nfe profile id which will be created.
 * @param [in]    ptr_nfe_prof_info    - The pointer to nfe profile config info.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_OTHERS           - Other errors.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 */
clx_error_no_t
clx_nfe_prof_set(const uint32 unit,
                 const uint32 nfe_prof_id,
                 const clx_nfe_prof_cfg_info_t *ptr_nfe_prof_info);

/**
 * @brief This API is used to get nfe profile configuration.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     nfe_prof_id          - The pointer to nfe profile id which will be created.
 * @param [out]    ptr_nfe_prof_info    - The pointer to nfe profile config info.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_nfe_prof_get(const uint32 unit,
                 const uint32 nfe_prof_id,
                 clx_nfe_prof_cfg_info_t *ptr_nfe_prof_info);

/**
 * @brief This API is used to set aging interval.
 *
 * Support_chip: CLX84.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    interval    - The aging interval.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_nfe_aging_interval_set(const uint32 unit, const uint32 interval);

/**
 * @brief This API is used to get aging interval.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit            - Device unit number.
 * @param [out]    ptr_interval    - The pointer to aging interval.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_nfe_aging_interval_get(const uint32 unit, uint32 *ptr_interval);

/**
 * @brief This API is used to set force aging.
 *
 * Support_chip: CLX84.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_nfe_aging_force_set(const uint32 unit);

/**
 * @brief This API is used to set threshold.
 *
 * Support_chip: CLX84.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    dir        - The direction of nfe.
 * @param [in]    ptr_cfg    - The pointer to threshold config.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_nfe_thd_set(const uint32 unit, const clx_nfe_dir_t dir, const clx_nfe_thd_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get threshold.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     dir        - The direction of nfe.
 * @param [out]    ptr_cfg    - The pointer to threshold config.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameter.
 */
clx_error_no_t
clx_nfe_thd_get(const uint32 unit, const clx_nfe_dir_t dir, clx_nfe_thd_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get current flow count.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     dir             - The direction of nfe.
 * @param [out]    ptr_flow_cnt    - The pointer to current flow count.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_nfe_current_flow_cnt_get(const uint32 unit, const clx_nfe_dir_t dir, uint32 *ptr_flow_cnt);

/**
 * @brief This API is used to get conflict flow count.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     dir             - The direction of nfe.
 * @param [out]    ptr_flow_cnt    - The pointer to conflict flow count.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_nfe_conflict_flow_cnt_get(const uint32 unit, const clx_nfe_dir_t dir, uint32 *ptr_flow_cnt);

/**
 * @brief This API is used to clear conflict flow count.
 *
 * Support_chip: CLX84.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    dir     - The direction of nfe.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_nfe_conflict_flow_cnt_clr(const uint32 unit, const clx_nfe_dir_t dir);

/**
 * @brief This API is used to set flow data notify callback.
 *
 * Support_chip: CLX84.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    notify_func    - The pointer to flow data notify callback.
 * @param [in]    ptr_cookie     - The pointer to flow data notify cookie.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_nfe_flow_data_notify_cb_set(const uint32 unit,
                                const clx_nfe_flow_data_notify_func_t notify_func,
                                void *ptr_cookie);
#endif /* End of CLX_NFE_H */
