/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained therein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_const.h
 * PURPOSE:
 *      KG HAL compile-time / boot-time constant helpers (narrow public surface).
 * NOTES:
 */

#ifndef HAL_MT_KG_CONST_H
#define HAL_MT_KG_CONST_H

#include <clx/clx_types.h>

void
hal_mt_kg_const_l2_mcast_set(uint32 l2_mgid_num);

void
hal_mt_kg_const_l3_mcast_group_set(uint32 l3_mcast_group_num);

#endif /* HAL_MT_KG_CONST_H */
