/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_sec.h
 * PURPOSE:
 *    Provide HAL driver API functions for namchabarwa.
 *
 * NOTES:
 *    None
 */

#ifndef HAL_MT_KG_SEC_H
#define HAL_MT_KG_SEC_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_sec.h>
#include <hal/hal_sec.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* storm control offset */
#define HAL_MT_KG_SEC_STORM_CTRL_OFFSET_UUC (0)   /* uuc */
#define HAL_MT_KG_SEC_STORM_CTRL_OFFSET_UMC (84)  /* umc */
#define HAL_MT_KG_SEC_STORM_CTRL_OFFSET_BC  (168) /* bc */

#define HAL_MT_KG_SEC_ISOLATION_GRP_MAX(unit) (PTR_HAL_CONST_INFO(unit, sec)->max_isolation_grp)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Initialize security configure.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation succeeded.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_kg_sec_cfg_init(const uint32 unit);

/**
 * @brief Set port DoS configuration. (add profile or record reference counter).
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Physical port ID.
 * @param [in]    ptr_cfg    - DoS per port configuration.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_dos_port_cfg_set(const uint32 unit,
                               const uint32 port,
                               const clx_sec_dos_port_cfg_t *ptr_cfg);

/**
 * @brief Get port DoS configuration. (get the port DoS profile id, and get dos profile entry).
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port ID.
 * @param [out]    ptr_cfg    - DoS per port configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_dos_port_cfg_get(const uint32 unit,
                               const uint32 port,
                               clx_sec_dos_port_cfg_t *ptr_cfg);

/**
 * @brief Get port DoS profile information.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port              - Port id.
 * @param [out]    ptr_profile_id    - Profile id.
 * @param [out]    ptr_ref_cnt       - Reference count.
 * @return         CLX_E_OK        - Operation succeeded.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_kg_sec_dos_port_prof_info_get(const uint32 unit,
                                     const uint32 port,
                                     uint32 *ptr_profile_id,
                                     uint32 *ptr_ref_cnt);
/**
 * @brief Free Dos Port profile.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port id.
 * @return        CLX_E_OK        - Operation succeeded.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_kg_sec_dos_port_prof_free(const uint32 unit, const uint32 port);

/**
 * @brief Set global DoS configuration. (update all profile).
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_cfg    - DoS global configuration.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_dos_cfg_set(const uint32 unit, const clx_sec_dos_cfg_t *ptr_cfg);

/**
 * @brief Get global DoS configuration. (get profile 0).
 *
 * @param [in]     unit       - Device unit number.
 * @param [out]    ptr_cfg    - DoS global configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_dos_cfg_get(const uint32 unit, clx_sec_dos_cfg_t *ptr_cfg);

/**
 * @brief Get DoS status.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_status    - DoS status.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_dos_status_get(const uint32 unit, clx_sec_dos_status_t *ptr_status);

/**
 * @brief Clear DoS status.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_dos_status_clear(const uint32 unit);

/**
 * @brief Set storm control properties on a physical port.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Physical port ID.
 * @param [in]    ptr_cfg    - The storm control properties for the physical port.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_storm_ctrl_cfg_set(const uint32 unit,
                                 const uint32 port,
                                 const clx_sec_storm_ctrl_cfg_t *ptr_cfg);
/**
 * @brief Get storm control properties on a physical port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port ID.
 * @param [out]    ptr_cfg    - The storm control properties for the physical port.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_storm_ctrl_cfg_get(const uint32 unit,
                                 const uint32 port,
                                 clx_sec_storm_ctrl_cfg_t *ptr_cfg);
/**
 * @brief Set source guard properties on a physical port.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Physical port ID.
 * @param [in]    ptr_cfg    - The source guard properties for the physical port.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_src_guard_cfg_set(const uint32 unit,
                                const clx_port_t port,
                                const clx_sec_src_guard_cfg_t *ptr_cfg);

/**
 * @brief Get source guard properties on a physical port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port ID.
 * @param [out]    ptr_cfg    - The source guard properties for the physical port.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_src_guard_cfg_get(const uint32 unit,
                                const clx_port_t port,
                                clx_sec_src_guard_cfg_t *ptr_cfg);

/**
 * @brief Set source guard bridge domain properties.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    bdid       - Bridge Domain Id.
 * @param [in]    ptr_cfg    - The source guard properties for the Bridge Domain.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NO_MEMORY        - No available memory for this operation.
 * @return        CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_src_guard_bd_cfg_set(const uint32 unit,
                                   const clx_bridge_domain_t bdid,
                                   const clx_sec_src_guard_cfg_t *ptr_cfg);

/**
 * @brief Get source guard bridge domain properties.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     bdid       - Bridge Domain Id.
 * @param [out]    ptr_cfg    - The source guard properties for the bridge domain.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_src_guard_bd_cfg_get(const uint32 unit,
                                   const clx_bridge_domain_t bdid,
                                   clx_sec_src_guard_cfg_t *ptr_cfg);

/**
 * @brief Add a source guard entry.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    ptr_entry    - Source guard entry.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_src_guard_entry_add(const uint32 unit, const clx_sec_src_guard_entry_t *ptr_entry);

/**
 * @brief Delete a source guard entry.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    ptr_entry    - Source guard entry.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_src_guard_entry_del(const uint32 unit, const clx_sec_src_guard_entry_t *ptr_entry);

/**
 * @brief Get a source guard entry.
 *
 * @param [in]     unit         - Device unit number.
 * @param [out]    ptr_entry    - Source guard entry.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_src_guard_entry_get(const uint32 unit, clx_sec_src_guard_entry_t *ptr_entry);

/**
 * @brief Get the isolation group config.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     grp_id         - Group id.
 * @param [out]    ptr_grp_cfg    - Isolation group config.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_isola_grp_cfg_get(const uint32 unit,
                                const uint32 grp_id,
                                clx_sec_isolation_grp_cfg_t *ptr_grp_cfg);

/**
 * @brief Set the isolation group config.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    grp_id         - Group id.
 * @param [in]    ptr_grp_cfg    - Isolation group config.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_isola_grp_cfg_set(const uint32 unit,
                                const uint32 grp_id,
                                const clx_sec_isolation_grp_cfg_t *ptr_grp_cfg);

/**
 * @brief Set isolation port config.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Port id.
 * @param [in]    ptr_port_cfg    - Isolation port config information.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_isola_port_cfg_set(const uint32 unit,
                                 const clx_port_t port,
                                 const clx_sec_isolation_port_cfg_t *ptr_port_cfg);

/**
 * @brief Get isolation port config.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Port id.
 * @param [out]    ptr_port_cfg    - Isolation port config information.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_kg_sec_isola_port_cfg_get(const uint32 unit,
                                 const clx_port_t port,
                                 clx_sec_isolation_port_cfg_t *ptr_port_cfg);

/**
 * @brief Set isolation group.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    lcl_intf_idx    - Local interface index.
 * @param [in]    dir             - Direction.
 * @param [in]    grp             - Group ID.
 * @param [in]    enable          - Enable.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_sec_isola_grp_set(const uint32 unit,
                            const uint32 lcl_intf_idx,
                            const clx_dir_t dir,
                            const uint32 grp,
                            const boolean enable);

/**
 * @brief Get isolation group.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     lcl_intf_idx    - Local interface index.
 * @param [in]     dir             - Direction.
 * @param [out]    ptr_grp         - Group ID.
 * @param [out]    ptr_enable      - Enable.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_sec_isola_grp_get(const uint32 unit,
                            const uint32 lcl_intf_idx,
                            const clx_dir_t dir,
                            uint32 *ptr_grp,
                            boolean *ptr_enable);

#endif /* End of HAL_MT_KG_SEC_H */
