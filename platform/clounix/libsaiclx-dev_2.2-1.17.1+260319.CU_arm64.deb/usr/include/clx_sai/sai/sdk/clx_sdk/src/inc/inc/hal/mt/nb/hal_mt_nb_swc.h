/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_swc.h
 * PURPOSE:
 *      API & special number for CL8570. For example: IEV, EMI.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_MT_NAMCHABARWA_SWC_H
#define HAL_MT_NAMCHABARWA_SWC_H

#include <clx/clx_cfg.h>
#include <clx/clx_swc.h>

#include <hal/hal_swc.h>
#include <hal/mt/hal_mt_swc.h>
#include <hal/mt/nb/hal_mt_nb_pkt_rsrc.h>
#define HAL_MT_NAMCHABARWA_SWC_HASH_STAGE_NUM          (3)
#define HAL_MT_NAMCHABARWA_SWC_HASH_TILE_NUM_PER_STAGE (8)
#define HAL_MT_NAMCHABARWA_SWC_HASH_TILE_NUM           (24)
#define HAL_MT_NAMCHABARWA_SWC_TCAM_NUM_PER_TYPE       (16)
#define HAL_MT_NAMCHABARWA_SWC_TCAM_NUM \
    (HAL_SWC_TCAM_TYPE * HAL_MT_NAMCHABARWA_SWC_TCAM_NUM_PER_TYPE)
#define HAL_MT_NAMCHABARWA_SWC_TCAM_ENTRY_NUM (HAL_MT_NAMCHABARWA_SWC_TCAM_NUM * 1024)

#define HAL_MT_NAMCHABARWA_SWC_HASH_TILE_PRI_NUM_PER_FPU (12)
#define HAL_MT_NAMCHABARWA_SWC_HASH_TILE_PRI_NUM \
    (HAL_MT_NAMCHABARWA_SWC_HASH_TILE_PRI_NUM_PER_FPU * 2)

#define HAL_MT_NAMCHABARWA_SWC_REASON_BF_ENABLE          (1)
#define HAL_MT_NAMCHABARWA_SWC_REASON_BF_DEFAULT_COUNTER (10000)
#define HAL_MT_NAMCHABARWA_SWC_REASON_BF_DEFAULT_TIMER   (1000)

#define HAL_MT_NAMCHABARWA_SWC_EMI_BANK_NUM                (8)
#define HAL_MT_NAMCHABARWA_SWC_EMI_NSH_BANK_BASE           (HAL_MT_NAMCHABARWA_SWC_EMI_BANK_NUM - 1)
#define HAL_MT_NAMCHABARWA_SWC_PAGE_NUM_PER_BANK           (4)
#define HAL_MT_NAMCHABARWA_SWC_ILE_TCAM_BANK_NUM           (64)
#define HAL_MT_NAMCHABARWA_SWC_ILE_TCAM_ENTRY_NUM_PER_BANK (256)
#define HAL_MT_NAMCHABARWA_SWC_MASTER_DIE_ID               (4) /* t die */

#define HAL_MT_NAMCHABARWA_SWC_EPG_MAC_HDR_LEN (60)            /* bytes */
#define HAL_MT_NAMCHABARWA_SWC_EPG_MAC_MAX_IPG (1024)          /* register 10 bits */

#define HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD        0
#define HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD      1
#define HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD     2
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IPV6_2X_OR_4X_FILED 3

#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_SA           0
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_DA           1
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2           0
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L3           1
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID 0xFFFF
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_IPV6_2X      0
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_IPV6_4X      1

#define HAL_MT_NAMCHABARWA_SWC_MAC_PER_PLANE (4)
#if defined(CLX_ASICSIM)
#define HAL_MT_NAMCHABARWA_SWC_DEFAULT_DROP_REASON 63
#endif

#define HAL_MT_NB_SWC_HSH_KEY_ALL (0x3ffffff)

static inline void
hal_mt_nb_swc_tcam_off_cfg(uint32 unit, uint32 tcam_table, uint32 *tcam_field, uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD], 0,
                        stage_cfg_buf);
}

static inline void
hal_mt_nb_swc_tcam_l3_sa_cfg(uint32 unit,
                             uint32 tcam_table,
                             uint32 *tcam_field,
                             uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_NAMCHABARWA_SWC_TCAM_IS_SA, stage_cfg_buf);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table,
                            tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L3, stage_cfg_buf);
    }
}

static inline void
hal_mt_nb_swc_tcam_l3_da_cfg(uint32 unit,
                             uint32 tcam_table,
                             uint32 *tcam_field,
                             uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_NAMCHABARWA_SWC_TCAM_IS_DA, stage_cfg_buf);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table,
                            tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L3, stage_cfg_buf);
    }
}

static inline void
hal_mt_nb_swc_tcam_l3_sa_4x_cfg(uint32 unit,
                                uint32 tcam_table,
                                uint32 *tcam_field,
                                uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_NAMCHABARWA_SWC_TCAM_IS_SA, stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table,
                        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_IPV6_2X_OR_4X_FILED],
                        HAL_MT_NAMCHABARWA_SWC_TCAM_IS_IPV6_4X, stage_cfg_buf);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table,
                            tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L3, stage_cfg_buf);
    }
}

static inline void
hal_mt_nb_swc_tcam_l3_da_4x_cfg(uint32 unit,
                                uint32 tcam_table,
                                uint32 *tcam_field,
                                uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_NAMCHABARWA_SWC_TCAM_IS_DA, stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table,
                        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_IPV6_2X_OR_4X_FILED],
                        HAL_MT_NAMCHABARWA_SWC_TCAM_IS_IPV6_4X, stage_cfg_buf);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table,
                            tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L3, stage_cfg_buf);
    }
}

static inline void
hal_mt_nb_swc_tcam_l2_uc_sa_cfg(uint32 unit,
                                uint32 tcam_table,
                                uint32 *tcam_field,
                                uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_NAMCHABARWA_SWC_TCAM_IS_SA, stage_cfg_buf);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table,
                            tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2, stage_cfg_buf);
    }
}

static inline void
hal_mt_nb_swc_tcam_l2_uc_da_cfg(uint32 unit,
                                uint32 tcam_table,
                                uint32 *tcam_field,
                                uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_NAMCHABARWA_SWC_TCAM_IS_DA, stage_cfg_buf);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table,
                            tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2, stage_cfg_buf);
    }
}

static inline void
hal_mt_nb_swc_tcam_l2_mc_da_cfg(uint32 unit,
                                uint32 tcam_table,
                                uint32 *tcam_field,
                                uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_NAMCHABARWA_SWC_TCAM_IS_DA, stage_cfg_buf);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table,
                            tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2, stage_cfg_buf);
    }
}

#define HAL_MT_NAMCHABARWA_SWC_HASH_MAC_ENTRIES_PER_TILE      (16 * 1024)
#define HAL_MT_NAMCHABARWA_SWC_HASH_ARP_ENTRIES_PER_TILE      (16 * 1024)
#define HAL_MT_NAMCHABARWA_SWC_HASH_AFIB_ENTRIES_PER_TILE     (64 * 1024)
#define HAL_MT_NAMCHABARWA_SWC_HASH_L3_ENTRIES_PER_TILE       (16 * 1024)
#define HAL_MT_NAMCHABARWA_SWC_HASH_ARP_DEFAULT_TILE_NUM      (4)
#define HAL_MT_NAMCHABARWA_SWC_HASH_AFIB_DEFAULT_TILE_NUM     (5)
#define HAL_MT_NAMCHABARWA_SWC_HASH_L3_DEFAULT_TILE_NUM       (5)
#define HAL_MT_NAMCHABARWA_SWC_HASH_MPLS_DEFAULT_TILE_NUM     (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_SRV6_DEFAULT_TILE_NUM     (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_MGI_DEFAULT_TILE_NUM      (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_MSGI_DEFAULT_TILE_NUM     (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_ECMP_GRP_DEFAULT_TILE_NUM (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_ECMP_MBR_DEFAULT_TILE_NUM (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_RPFC_DEFAULT_TILE_NUM     (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_MAC_DEFAULT_TILE_NUM      (0)

#define HAL_MT_NAMCHABARWA_SWC_TCAM_TYPE_ONLY_L3    (0)
#define HAL_MT_NAMCHABARWA_SWC_TCAM_TYPE_L2L3       (1)
#define HAL_MT_NAMCHABARWA_SWC_DMAC_TCAM_START      (16)
#define HAL_MT_NAMCHABARWA_SWC_DMAC_MAX_TCAM_NUM    (16)
#define HAL_MT_NAMCHABARWA_SWC_DIP_DEFAULT_TCAM_NUM (10)
#define HAL_MT_NAMCHABARWA_SWC_MAX_TCAM_NUM         (32)
#define HAL_MT_NAMCHABARWA_SWC_MAX_TILE_NUM         (24)
#define HAL_MT_NAMCHABARWA_SWC_TILE_OFFSET          (15)
#define HAL_MT_NAMCHABARWA_SWC_TILE_LEN             (3)
#define HAL_MT_NAMCHABARWA_SWC_STAGE_OFFSET         (18)
#define HAL_MT_NAMCHABARWA_SWC_STAGE_LEN            (2)
#define HAL_MT_NAMCHABARWA_ENTRIES_PER_TCAM         (1024)
#define HAL_MT_NAMCHABARWA_ENTRIES_PER_TCAM_BIT     (10)
#define HAL_MT_NAMCHABARWA_MAC_ENTRIES_PER_TCAM     (512)
#define HAL_MT_NB_L3_ENTRIES_PER_TCAM               (1024)
#define HAL_MT_NAMCHABARWA_SWC_DUAL_MAX_TCAM_NUM    (64)
#define HAL_MT_NAMCHABARWA_SWC_DUAL_MAX_TILE_NUM    (48)

clx_error_no_t
hal_mt_nb_swc_cfg_init(const uint32 unit);

clx_error_no_t
hal_mt_nb_swc_epg_pkt_init(hal_swc_epg_pkt_t *ptr_pkt);

/**
 * @brief Set MAC EPG packet related configuration (header, payload, ipg,
 *        ...).
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_pkt    - Packet information to be sent.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_swc_epg_mac_hw_set(const uint32 unit, const hal_swc_epg_pkt_t *ptr_pkt);

/**
 * @brief Trigger MAC EPG to send packets.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - EPG ingress port.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_swc_epg_mac_done_chk(const uint32 unit, const uint32 port);

/**
 * @brief Stop MAC EPG from sending packets.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - EPG ingress port.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_swc_epg_mac_pkt_stop(const uint32 unit, const uint32 port);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_arp_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_afib_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_l3_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_mpls_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_srv6_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_l2uc_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_l2mc_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_mgi_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_msgi_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_ecmp_mbr_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_ecmp_grp_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_rpfc_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_policy_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_l2_ecmp_grp_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_l2_ecmp_mbr_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_tcam_l2_cfg(const uint32 unit, uint32 uc_entry_num, uint32 mc_entry_num);

clx_error_no_t
hal_mt_nb_swc_host_tcam_cfg(const uint32 unit,
                            uint32 entry_2x_num,
                            uint32 entry_4x_num,
                            uint32 sip_check);

clx_error_no_t
hal_mt_nb_swc_route_tcam_cfg(const uint32 unit,
                             uint32 entry_2x_num,
                             uint32 entry_4x_num,
                             uint32 sip_check);

clx_error_no_t
hal_mt_nb_swc_tile_type_get(const uint32 unit,
                            const uint32 slice_id,
                            const uint32 stage_id,
                            const uint32 tile_id,
                            uint32 *ptr_tile_type);

clx_error_no_t
hal_mt_nb_swc_ts_set(const uint32 unit, const clx_swc_ts_t ts_val);

clx_error_no_t
hal_mt_nb_swc_ts_get(const uint32 unit, clx_swc_ts_t *ptr_ts_val);

clx_error_no_t
hal_mt_nb_swc_dev_info_get(const uint32 unit, clx_swc_device_info_t *ptr_device_info);

clx_error_no_t
hal_mt_nb_swc_ts_offset_set(const uint32 unit, const int32 nsec);

clx_error_no_t
hal_mt_nb_swc_cso_mode_set(const uint32 unit, const clx_swc_cso_mode_t mode);

/**
 * @brief Get chip PLL status.
 *
 * @param [in]     unit              - Device unit number.
 * @param [out]    ptr_pll_status    - Pointer to the status of chip PLL.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_chip_pll_status_get(const uint32 unit, clx_swc_chip_pll_status_t *ptr_pll_status);

/**
 * @brief Set the ipl runt pkt fwd action.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    enable    - Enable or disable runt pkt fwd.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_skip_rx_crc_check_set(const uint32 unit, const uint32 enable);

/**
 * @brief Get the ipl runt pkt fwd action.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_enable    - Enable or disable runt pkt fwd.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_skip_rx_crc_check_get(const uint32 unit, uint32 *ptr_enable);

/**
 * @brief Set the rwo runt pkt fwd action.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    enable    - Enable or disable runt pkt fwd.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_runt_pkt_fwd_set(const uint32 unit, const uint32 enable);

/**
 * @brief Get the rwo runt pkt fwd action.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_enable    - Enable or disable runt pkt fwd.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_runt_pkt_fwd_get(const uint32 unit, uint32 *ptr_enable);

/**
 * @brief Initialize the low level of the nb sram.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_low_lvl_init(const uint32 unit);

/**
 * @brief Get switch control bitmap of all hash keys.
 *
 * @param [in]     unit       - Device unit number.
 * @param [out]    key_bmp    - Hash key bitmap.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_all_hsh_key_bmp_get(const uint32 unit, clx_swc_hsh_key_bmp_t *key_bmp);

/**
 * @brief Set switch control hash keys.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    hash_type    - Hash type.
 * @param [in]    key_bmp      - Hash key bitmap.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_hsh_key_set(const uint32 unit,
                          const clx_swc_hsh_pkt_type_t hash_type,
                          const clx_swc_hsh_key_bmp_t key_bmp);

/**
 * @brief Get switch control hash keys.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     hash_type    - Hash type.
 * @param [out]    key_bmp      - Hash key bitmap.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_hsh_key_get(const uint32 unit,
                          const clx_swc_hsh_pkt_type_t hash_type,
                          clx_swc_hsh_key_bmp_t *key_bmp);

/**
 * @brief Set hash engine configuration.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    hash_type      - Hash engine.
 * @param [in]    hash_engine    - Hash engine attributes.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Config fail.
 */
clx_error_no_t
hal_mt_nb_swc_hsh_eng_set(const uint32 unit,
                          const clx_swc_hsh_pkt_type_t hash_type,
                          const clx_swc_hsh_eng_t *hash_engine);

/**
 * @brief Get hash engine configuration.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     hash_type      - Hash engine.
 * @param [out]    hash_engine    - Pointer to hash engine attributes.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Config fail.
 */
clx_error_no_t
hal_mt_nb_swc_hsh_eng_get(const uint32 unit,
                          const clx_swc_hsh_pkt_type_t hash_type,
                          clx_swc_hsh_eng_t *hash_engine);

/**
 * @brief Set hash engine polynominal coefficients.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    hash_type     - Hash engine to be config.
 * @param [in]    hash_const    - Hash constant.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Config fail.
 */
clx_error_no_t
hal_mt_nb_swc_hsh_const_set(const uint32 unit,
                            const clx_swc_hsh_pkt_type_t hash_type,
                            const uint32 hash_const);

/**
 * @brief Get hash engine polynominal coefficients.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     hash_type         - Hash engine to be config.
 * @param [out]    ptr_hash_const    - Pointer to array of constants.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_hsh_const_get(const uint32 unit,
                            const clx_swc_hsh_pkt_type_t hash_type,
                            uint32 *ptr_hash_const);

/**
 * @brief To set table reason_code_act_x and field actx in each stage.
 *
 * @param [in]    unit               - Device unit number.
 * @param [in]    epp_reason_code    - Epp reason code.
 * @param [in]    cpu_vld            - Cpu cpoy or not.
 * @param [in]    fwd_vld            - Fwd copy or not.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_epp_rsn_act_tbl_set(const uint32 unit,
                                  const hal_mt_nb_pkt_rsrc_pp_rsn_t epp_reason_code,
                                  const uint32 cpu_vld,
                                  const uint32 fwd_vld);

/**
 * @brief Set RX reason action. Asign drop reason code if fowarding action is dropping.
 *        Asign CPU qeueu if fowarding action is copy to CPU or redirect to CPU.
 *
 * @param [in]    unit                - Device unit number.
 * @param [in]    rx_reason_code      - Rx reason code.
 * @param [in]    rx_reason_action    - Rx reason aciton.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_rsn_act_set(const uint32 unit,
                          const clx_pkt_rx_reason_t rx_reason_code,
                          const clx_swc_rsn_act_t *rx_reason_action);

/**
 * @brief Get RX reason action. Get drop reason code or cpu queue.
 *
 * @param [in]    unit                - Device unit number.
 * @param [in]    rx_reason_code      - Rx reason code.
 * @param [in]    rx_reason_action    - Rx reason aciton.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_rsn_act_get(const uint32 unit,
                          const clx_pkt_rx_reason_t rx_reason_code,
                          clx_swc_rsn_act_t *rx_reason_action);

/**
 * @brief This function is to set reason priority.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    rx_reason_code    - Rx reason code.
 * @param [in]    priority          - Reason priority.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_rsn_pri_set(const uint32 unit,
                          const clx_pkt_rx_reason_t rx_reason_code,
                          const uint32 priority);

/**
 * @brief This function is to get reason priority.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     rx_reason_code    - Rx reason code.
 * @param [out]    priority          - Reason priority.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_rsn_pri_get(const uint32 unit,
                          const clx_pkt_rx_reason_t rx_reason_code,
                          uint32 *priority);

/**
 * @brief To set PP reason priority.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    pp_reason_code    - Pp reason code.
 * @param [in]    priority          - Reason priority.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_pp_rsn_pri_set(const uint32 unit, const uint32 pp_reason_code, const uint32 priority);

/**
 * @brief To get PP reason priority.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     pp_reason_code    - Pp reason code.
 * @param [out]    priority          - Reason priority.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_pp_rsn_pri_get(const uint32 unit, const uint32 pp_reason_code, uint32 *priority);

/**
 * @brief This function is to set reason bloom filter configuration.
 *
 * @param [in]    unit                  - Device unit number.
 * @param [in]    bloom_filter_type     - Bloom filter type.
 * @param [in]    bloom_filter_value    - Bloom filter value.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_rsn_bloom_filter_set(const uint32 unit,
                                   const clx_swc_cfg_rsn_bloom_filter_type_t bloom_filter_type,
                                   const uint32 bloom_filter_value);

/**
 * @brief This function is to get reason bloom filter configuration.
 *
 * @param [in]    unit                  - Device unit number.
 * @param [in]    bloom_filter_type     - Bloom filter type.
 * @param [in]    bloom_filter_value    - Bloom filter value.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_rsn_bloom_filter_get(const uint32 unit,
                                   const clx_swc_cfg_rsn_bloom_filter_type_t bloom_filter_type,
                                   uint32 *bloom_filter_value);

/**
 * @brief Set exceptions to drop, to CPU or foward.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    en      - Enable or restore exceptions.
 * @param [in]    act     - Drop, forward or send to the CPU.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_excpt_set(const uint32 unit, const uint32 en, const clx_fwd_action_t act);

/**
 * @brief Trap all packets to CPU.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    en      - Enable or disable.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_trap_all_set(const uint32 unit, const uint32 en);

/**
 * @brief Set the EPP action based on the MOD's status.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    enable    - MOD enable.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
hal_mt_nb_swc_mod_epp_rsn_set(const uint32 unit, boolean enable);

/**
 * @brief Set the drop reason based on the MOD's status.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    enable    - MOD enable.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
hal_mt_nb_swc_mod_drop_rsn_set(const uint32 unit, boolean enable);

/**
 * @brief Set global cut through state.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    state    - Cut through state.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_nb_swc_cut_through_set(const uint32 unit, uint32 state);

/**
 * @brief Get global cut through state.
 *
 * @param [in]     unit         - Device unit number.
 * @param [out]    ptr_state    - Cut through state.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_nb_swc_cut_through_get(const uint32 unit, uint32 *ptr_state);
#endif
