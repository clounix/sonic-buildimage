/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   hal_mt_kg_tm.h
 * PURPOSE:
 *      It provide HAL TM module API.
 * NOTES:
 */

#ifndef HAL_MT_KG_TM_H
#define HAL_MT_KG_TM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_init.h>
#include <clx/clx_port.h>
#include <clx/clx_swc.h>
#include <clx/clx_tm.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define HAL_MT_KG_TM_PLANE_NUM (2)

#define HAL_MT_KG_TM_CPU_QUEUE_NUM     (48)
#define HAL_MT_KG_TM_UNICAST_QUEUE_NUM (8) // not include hqos queue

#define HAL_MT_KG_TM_MAX_DIE_NUM         (2)
#define HAL_MT_KG_TM_MULTICAST_QUEUE_NUM (4)
#define HAL_MT_KG_TM_LEGACY_QUEUE_NUM    (8)
#define HAL_MT_KG_TM_HQOS_QP_ID          (8)
#define HAL_MT_KG_TM_FP_QP_NUM           (HAL_MT_KG_TM_LEGACY_QUEUE_NUM + 1) // Front port includes hqos qp8

#define HAL_MT_KG_TM_DIE_PORT_NUM       (89)
#define HAL_MT_KG_TM_DELETE_PPID        (88)
#define HAL_MT_KG_TM_DELETE_QP          (828)
#define HAL_MT_KG_TM_1D_DELETE_OQ       (2047)
#define HAL_MT_KG_TM_D2D_DELETE_OQ      (4095)
#define HAL_MT_KG_TM_PLANE_QUEUE_OFFSET (512)

#define HAL_MT_KG_CPU_PLANE_PORT       (84)
#define HAL_MT_KG_ECPU_PLANE_PORT      (85)
#define HAL_MT_KG_RC0_PLANE_PORT       (86)
#define HAL_MT_KG_RC1_PLANE_PORT       (87)
#define HAL_MT_KG_TM_CPU_QUEUE_NUM     (48)
#define HAL_MT_KG_TM_HQOS_QUEUE_NUM    (16)
#define HAL_MT_KG_TM_OQ_NUM_DIE        (2048)
#define HAL_MT_KG_TM_MAX_HQOS_PORT_NUM (60)

#define HAL_MT_KG_TM_TC_PROFILE_NUM (8)

/*schedule node handler id valid check, root node is exculde*/
#define HAL_MT_KG_TM_QP_VALID(queue) ((queue) < HAL_MT_KG_TM_QP_NUM)

#define HAL_MT_KG_TM_LEGACY_QUEUE_VALID(queue) ((queue) < HAL_MT_KG_TM_LEGACY_QUEUE_NUM)

#define HAL_MT_KG_TM_UC_QUEUE_VALID(queue) ((queue) < HAL_MT_KG_TM_UNICAST_QUEUE_NUM)

#define HAL_MT_KG_TM_MC_QUEUE_VALID(queue) ((queue) < HAL_MT_KG_TM_MULTICAST_QUEUE_NUM)

#define HAL_MT_KG_TM_TC_BITMAP_ALL_MASK (0xff)

#define HAL_MT_KG_TM_MAX_PORT_SPEED (400000) // 400000M
/*schedule node handler id valid check, root node is exculde*/
#define HAL_MT_KG_TM_FT_QP_VALID(queue) ((queue) < HAL_MT_KG_TM_FP_QP_NUM)

#define HAL_MT_KG_TM_LEGACY_QUEUE_VALID(queue) ((queue) < HAL_MT_KG_TM_LEGACY_QUEUE_NUM)

#define HAL_MT_KG_TM_UC_QUEUE_VALID(queue) ((queue) < HAL_MT_KG_TM_UNICAST_QUEUE_NUM)

#define HAL_MT_KG_TM_MC_QUEUE_VALID(queue) ((queue) < HAL_MT_KG_TM_MULTICAST_QUEUE_NUM)

#define HAL_MT_KG_TM_CPU_QUEUE_VALID(queue) ((queue) < HAL_MT_KG_TM_CPU_QUEUE_NUM)

#define HAL_MT_KG_TM_DEFAULT_PD_FIFO (0)
/* IQC OQ_PORT_MAP_MEM has 7 oq in every entry */
#define HAL_MT_KG_TM_OQ_INFO_GET_FIELD_OFFSET(_value_) (_value_ % 8)

/* DQC OQ_PORT_MAP_MEM table entry number is 512, total 4k oq */
#define HAL_MT_KG_TM_OQ_INFO_GET_ENTRY_IDX(_value_) (_value_ / 8)

#define HAL_MT_KG_TM_PORT_SPEED(unit, port) _hal_mt_kg_tm_port_speed[unit][port]

#define HAL_MT_KG_TM_ADD_HQOS_PORT(unit, die, port)                                  \
    do {                                                                             \
        hal_activate_hqos_port_bit_map[unit][die][port / 32] |= (1U << (port % 32)); \
        hal_activate_hqos_port_num[unit][die]++;                                     \
    } while (0)

#define HAL_MT_KG_TM_DELETE_HQOS_PORT(unit, die, port)                                \
    do {                                                                              \
        hal_activate_hqos_port_bit_map[unit][die][port / 32] &= ~(1U << (port % 32)); \
        hal_activate_hqos_port_num[unit][die]--;                                      \
    } while (0)

typedef enum hal_mt_kg_tm_port_type_e {
    HAL_MT_KG_TM_PORT_FP = 0,
    HAL_MT_KG_TM_PORT_CPU,
    HAL_MT_KG_TM_PORT_ECPU,
    HAL_MT_KG_TM_PORT_CPI,
    HAL_MT_KG_TM_PORT_RC,
    HAL_MT_KG_TM_PORT_LAST
} hal_mt_kg_tm_port_type_t;

typedef enum hal_mt_kg_tm_wbdb_e {
    HAL_MT_KG_TM_WBDB_SCH_WEIGHT,
    HAL_MT_KG_TM_WBDB_BUF_PROFILE,
    HAL_MT_KG_TM_WBDB_PFC,
    HAL_MT_KG_TM_WBDB_MISC,
    HAL_MT_KG_TM_WBDB_PFCWD,
    HAL_MT_KG_TM_WBDB_LAST
} hal_mt_kg_tm_wbdb_t;

typedef struct hal_mt_kg_tm_oq_info_s {
    uint32 uc_oq_min;
    uint32 uc_oq_cnt;
    uint32 mc_oq_min;
    uint32 mc_oq_cnt;
    uint32 hqos_oq_min;
    uint32 hqos_oq_cnt;
} hal_mt_kg_tm_oq_info_t;

typedef enum hal_mt_kg_tm_oq_type_e {
    HAL_MT_KG_TM_OQ_TYPE_UC,
    HAL_MT_KG_TM_OQ_TYPE_MC,
    HAL_MT_KG_TM_OQ_TYPE_HQOS,
    HAL_MT_KG_TM_OQ_TYPE_LAST
} hal_mt_kg_tm_oq_type_t;

typedef enum hal_mt_kg_tm_oq_prof_e {
    HAL_MT_KG_TM_OQ_PROF_0, // for 400G port
    HAL_MT_KG_TM_OQ_PROF_1, // for 200G port
    HAL_MT_KG_TM_OQ_PROF_2, // for 100G port
    HAL_MT_KG_TM_OQ_PROF_3, // for 50G port
    HAL_MT_KG_TM_OQ_PROF_4, // for 25G port
    HAL_MT_KG_TM_OQ_PROF_5, // for 10G port
    HAL_MT_KG_TM_OQ_PROF_6, // for 1G port
    HAL_MT_KG_TM_OQ_PROF_7, // for hqos oq
    HAL_MT_KG_TM_OQ_PROF_LAST
} hal_mt_kg_tm_oq_prof_t;

typedef enum hal_mt_kg_tm_iqc_dport_prof_e {
    HAL_MT_KG_TM_IQC_DPORT_PROF_0, // for >=200G port
    HAL_MT_KG_TM_IQC_DPORT_PROF_1, // for >=100 && <200G port
    HAL_MT_KG_TM_IQC_DPORT_PROF_2, // for >=50 && <100G port
    HAL_MT_KG_TM_IQC_DPORT_PROF_3, // for <50G port
    HAL_MT_KG_TM_IQC_DPORT_PROF_LAST
} hal_mt_kg_tm_iqc_dport_prof_t;

typedef enum hal_mt_kg_tm_eqc_dport_prof_e {
    HAL_MT_KG_TM_EQC_DPORT_PROF_0, // for >200G port
    HAL_MT_KG_TM_EQC_DPORT_PROF_1, // for <=200 && >100G port
    HAL_MT_KG_TM_EQC_DPORT_PROF_2, // for <=100 && >50G port
    HAL_MT_KG_TM_EQC_DPORT_PROF_3, // for <=50 && >25G port
    HAL_MT_KG_TM_EQC_DPORT_PROF_4, // for <=25 && >10G port
    HAL_MT_KG_TM_EQC_DPORT_PROF_5, // for <=10  port
    HAL_MT_KG_TM_EQC_DPORT_PROF_LAST
} hal_mt_kg_tm_eqc_dport_prof_t;
/*the number of hqos activated port. range is 0~60 of each die*/
extern uint32 hal_activate_hqos_port_num[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM][HAL_MT_KG_TM_MAX_DIE_NUM];
/*the bit map of hqos activated port, 1 bit per port, 60 bits per die*/
extern uint32 hal_activate_hqos_port_bit_map[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM]
                                            [HAL_MT_KG_TM_MAX_DIE_NUM][2];
uint32
hal_mt_kg_tm_port_speed_valid_check(const clx_port_speed_t speed);
clx_error_no_t
hal_mt_kg_tm_speed_get(const uint32 unit, const uint32 port, clx_port_speed_t *speed);
clx_error_no_t
hal_mt_kg_tm_all_subinst_entry_write(const uint32 unit,
                                     const uint32 inst_idx,
                                     const uint32 table_id,
                                     const uint32 entry_idx,
                                     uint32 *ptr_entry);
clx_error_no_t
hal_mt_kg_tm_init(const uint32 unit);
clx_error_no_t
hal_mt_kg_tm_deinit(const uint32 unit);
clx_error_no_t
hal_mt_kg_tm_port_dflt_set(const uint32 unit, const uint32 port);
clx_error_no_t
hal_mt_kg_tm_port_dflt_reset(const uint32 unit, const uint32 port);
boolean
hal_mt_kg_tm_port_type_check(const uint32 unit,
                             const uint32 port,
                             const hal_mt_kg_tm_port_type_t type);
clx_error_no_t
hal_mt_kg_tm_oq_info_get(const uint32 unit, const uint32 port, hal_mt_kg_tm_oq_info_t *ptr_oq_info);
clx_error_no_t
hal_mt_kg_tm_speed_set(const uint32 unit, const uint32 port, const clx_port_speed_t speed);
clx_error_no_t
hal_mt_kg_tm_port_flush(const uint32 unit, const uint32 port, const uint32 enable);

clx_error_no_t
hal_mt_kg_tm_handler_create(const uint32 unit,
                            const uint32 port,
                            const clx_tm_handler_type_t handler_type,
                            const uint32 queue_id,
                            clx_tm_handler_t *ptr_handler);
clx_error_no_t
hal_mt_kg_tm_handler_destroy(const uint32 unit, const uint32 port, const clx_tm_handler_t handler);

clx_error_no_t
hal_mt_kg_tm_cfg_set(const uint32 unit,
                     const uint32 port,
                     const clx_tm_handler_t handler,
                     const clx_tm_cfg_t *ptr_cfg);
clx_error_no_t
hal_mt_kg_tm_cfg_get(const uint32 unit,
                     const uint32 port,
                     const clx_tm_handler_t handler,
                     clx_tm_cfg_t *ptr_cfg);

clx_error_no_t
hal_mt_kg_tm_tc_prof_set(const uint32 unit, const uint32 prof_id, const clx_tm_tc_prof_t *prof);
clx_error_no_t
hal_mt_kg_tm_tc_prof_get(const uint32 unit, const uint32 prof_id, clx_tm_tc_prof_t *prof);

clx_error_no_t
hal_mt_kg_tm_trunc_prof_set(const uint32 unit, const hal_tm_trunc_prof_t *prof);

clx_error_no_t
hal_mt_kg_tm_trunc_prof_get(const uint32 unit, hal_tm_trunc_prof_t *prof);
clx_error_no_t
hal_mt_kg_tm_trunc_set(const uint32 unit, const hal_tm_trunc_cfg_t *config);
clx_error_no_t
hal_mt_kg_tm_trunc_get(const uint32 unit, hal_tm_trunc_cfg_t *config);
clx_error_no_t
hal_mt_kg_tm_cpa_set(const uint32 unit, const clx_swc_cfg_cpa_type_t type, const uint32 value);
clx_error_no_t
hal_mt_kg_tm_cpa_get(const uint32 unit, const clx_swc_cfg_cpa_type_t type, uint32 *ptr_value);
clx_error_no_t
hal_mt_kg_tm_all_chip_traffic_flush(const uint32 unit, const uint32 enable);
clx_error_no_t
hal_mt_kg_tm_iqc_oq_port_map_set(const uint32 unit,
                                 const uint32 ppid,
                                 const uint32 oq,
                                 const uint32 pd_fifo,
                                 const boolean is_fabric);

clx_error_no_t
hal_mt_kg_tm_xoff_mask_set(const uint32 unit, const uint32 port);

#endif /* #ifndef HAL_MT_KG_TM_H */