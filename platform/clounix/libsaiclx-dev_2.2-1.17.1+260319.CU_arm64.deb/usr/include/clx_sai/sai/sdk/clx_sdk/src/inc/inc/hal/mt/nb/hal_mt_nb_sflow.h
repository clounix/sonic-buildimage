/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_sflow.h
 * PURPOSE:
 *      Provide sflow hal layer api.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_MT_NB_SFLOW_H
#define HAL_MT_NB_SFLOW_H

/**
 * @brief This API is used to register the impl into API layer, please note that the parameter
 *        should keep availablity during the code runtime, in another word,
 *        stack variable is not accepted, you should use a global variable for that.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_nb_sflow_cfg_init(const uint32 unit);

/**
 * @brief This API is used to initialize the hardware related functions.
 *        If there is no hw related component needs to initialize, we can put this function as a
 *        stub function.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    threshold      - Threshold.
 * @param [in]    sflw_lat_en    - Sflw_lat_en.
 * @return        CLX_E_OK            - Operate success.
 * @return        CLX_E_NOT_INITED    - Error happens, the impl will porvides more detail.
 */
clx_error_no_t
hal_mt_nb_sflow_high_latency_cfg_set(const uint32 unit,
                                     const uint32 threshold,
                                     const uint32 sflw_lat_en);

/**
 * @brief This API is used to deinitialize the hardware related functions.
 *
 * @param [in]    unit                 - Device unit number.
 * @param [in]    profile_id           - Profile_id.
 * @param [in]    ptr_sflw_mir_en      - Ptr_sflw_mir_en.
 * @param [in]    ptr_sflw_mir_bidx    - Ptr_sflw_mir_bidx.
 * @return        CLX_E_OK            - Operate success.
 * @return        CLX_E_NOT_INITED    - Error happens, the impl will porvides more detail.
 */
clx_error_no_t
hal_mt_nb_sflow_igr_cfg_sflow_mir_get(const uint32 unit,
                                      const uint32 profile_id,
                                      uint32 *ptr_sflw_mir_en,
                                      uint32 *ptr_sflw_mir_bidx);

/**
 * @brief This API is used to return the shared memory info in the purpose of communication bwtween
 *        eCPU and host CPU. The shared memory includes the tx and rx shared memory,
 *        the upper layer code should be resonsible for manage the control part,
 *        data part etc.
 *
 * @param [in]    unit                 - Device unit number.
 * @param [in]    profile_id           - Profile_id.
 * @param [in]    ptr_sflw_mir_en      - Ptr_sflw_mir_en.
 * @param [in]    ptr_sflw_mir_bidx    - Ptr_sflw_mir_bidx.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
clx_error_no_t
hal_mt_nb_sflow_egr_cfg_sflow_mir_get(const uint32 unit,
                                      const uint32 profile_id,
                                      uint32 *ptr_sflw_mir_en,
                                      uint32 *ptr_sflw_mir_bidx);

clx_error_no_t
hal_mt_nb_sflow_igr_cfg_sflow_set(const uint32 unit,
                                  const uint32 profile_id,
                                  const uint32 sflw_splr_threshold);

/**
 * @brief This API is used to issue an itnerrupt to eCPU.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    profile_id       - Profile_id.
 * @param [in]    sflw_mir_en      - Sflw_mir_en.
 * @param [in]    sflw_mir_bidx    - Sflw_mir_bidx.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
clx_error_no_t
hal_mt_nb_sflow_igr_cfg_sflow_mir_set(const uint32 unit,
                                      const uint32 profile_id,
                                      const uint32 sflw_mir_en,
                                      const uint32 sflw_mir_bidx);

/**
 * @brief This API is used to clear the interrupt from eCPU.
 *
 * @param [in]    unit                   - Device unit number.
 * @param [in]    profile_id             - Profile_id.
 * @param [in]    sflw_splr_threshold    - Sflw_splr_threshold.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
clx_error_no_t
hal_mt_nb_sflow_egr_cfg_sflow_set(const uint32 unit,
                                  const uint32 profile_id,
                                  const uint32 sflw_splr_threshold);

/**
 * @brief This API is used to enable the interrupt from eCPU.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    profile_id       - Profile_id.
 * @param [in]    sflw_mir_en      - Sflw_mir_en.
 * @param [in]    sflw_mir_bidx    - Sflw_mir_bidx.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
clx_error_no_t
hal_mt_nb_sflow_egr_cfg_sflow_mir_set(const uint32 unit,
                                      const uint32 profile_id,
                                      const uint32 sflw_mir_en,
                                      const uint32 sflw_mir_bidx);

/**
 * @brief This API is used to trigger message sync.
 *
 * @param [in]    unit                   - Device unit number.
 * @param [in]    src_type               - Src_type.
 * @param [in]    dst_type               - Dst_type.
 * @param [in]    mir_session_id         - Mir_session_id.
 * @param [in]    profile_id             - Profile_id.
 * @param [in]    sampling_rate          - Sampling_rate.
 * @param [in]    sample_high_latency    - Sample_high_latency.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
clx_error_no_t
hal_mt_nb_sflow_profile_alloc(const uint32 unit,
                              const hal_sflow_src_type_t src_type,
                              const hal_sflow_dst_type_t dst_type,
                              const uint32 mir_session_id,
                              const uint32 profile_id,
                              const uint32 sampling_rate,
                              const boolean sample_high_latency);

clx_error_no_t
hal_mt_nb_sflow_parameter_check(const uint32 unit,
                                const hal_sflow_profile_t *ptr_profile,
                                uint32 *ptr_profile_id);

#endif
