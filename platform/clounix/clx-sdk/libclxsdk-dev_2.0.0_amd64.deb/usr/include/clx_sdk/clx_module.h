/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:   clx_module.h
 * PURPOSE:
 *      Define the software modules in CLX SDK.
 * NOTES:
 */

#ifndef CLX_MODULE_H
#define CLX_MODULE_H

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define CLX_MODULE_MAX_LENGTH_OF_NAME (8)
#define MODULE_LIST(maker) \
        maker(IFMAP, ifmap) \
        maker(VLAN, vlan) \
        maker(PORT, port) \
        maker(IFMON, ifmon) \
        maker(L2, l2) \
        maker(STP, stp) \
        maker(LAG, lag) \
        maker(MIR, mir) \
        maker(L3, l3) \
        maker(L3T, l3t) \
        maker(SWC, swc) \
        maker(QOS, qos) \
        maker(METER, meter) \
        maker(PKT, pkt) \
        maker(ACL, acl) \
        maker(STAT, stat) \
        maker(SEC, sec) \
        maker(SFLOW, sflow) \
        maker(TM, tm) \
        maker(VM, vm) \
        maker(FCOE, fcoe) \
        maker(TRILL, trill) \
        maker(SDN, sdn) \
        maker(DIAG, diag) \
        maker(CLI, cli) \
        maker(LOG, log) \
        maker(OSAL, osal) \
        maker(DCC, dcc) \
        maker(AML, aml) \
        maker(HAL, hal) \
        maker(PHY, phy) \
        maker(INIT, init) \
        maker(CMLIB, cmlib) \
        maker(NV, nv) \
        maker(MPLS, mpls) \
        maker(SFC, sfc) \
        maker(CHIP, chip) \
        maker(DCC_CH, dcc-channel) \
        maker(MISC, misc) \
        maker(STK, stacking) \
        maker(PPPOE, pppoe) \
        maker(DTEL, dtel) \
        maker(ALL, all) \
        maker(LAST, )
#define MODULE_ENUM(module, module_name) CLX_MODULE_##module,
#define MODULE_STRING(module, module_name) #module_name,
#define MOULDE_DBG_FLAG(module, module_name) 0x0,

/* DATA TYPE DECLARATIONS
 */
#if 0
typedef enum CLX_MODULE_E
{
    CLX_MODULE_IFMAP = 0,
    CLX_MODULE_VLAN,
    CLX_MODULE_PORT,
    CLX_MODULE_IFMON,
    CLX_MODULE_L2,
    CLX_MODULE_STP,
    CLX_MODULE_LAG,
    CLX_MODULE_MIR,
    CLX_MODULE_L3,
    CLX_MODULE_L3T,
    CLX_MODULE_SWC,
    CLX_MODULE_QOS,
    CLX_MODULE_METER,
    CLX_MODULE_PKT,
    CLX_MODULE_ACL,
    CLX_MODULE_STAT,
    CLX_MODULE_SEC,
    CLX_MODULE_SFLOW,
    CLX_MODULE_TM,
    CLX_MODULE_VM,
    CLX_MODULE_FCOE,
    CLX_MODULE_TRILL,
    CLX_MODULE_DIAG,
    CLX_MODULE_CLI,
    CLX_MODULE_LOG,
    CLX_MODULE_OSAL,
    CLX_MODULE_DCC,
    CLX_MODULE_AML,
    CLX_MODULE_HAL,
    CLX_MODULE_PHY,
    CLX_MODULE_INIT,
    CLX_MODULE_CMLIB,
    CLX_MODULE_NV,
    CLX_MODULE_MPLS,
    CLX_MODULE_SFC,
    CLX_MODULE_CHIP,
    CLX_MODULE_DCC_CH,
    CLX_MODULE_MISC,
    CLX_MODULE_STK,
    CLX_MODULE_PPPOE,
    CLX_MODULE_DTEL,
    CLX_MODULE_LAST
} CLX_MODULE_T;
#else
typedef enum CLX_MODULE_E {
    MODULE_LIST(MODULE_ENUM)
}CLX_MODULE_T;
#endif

#define CLX_MODULE_NUMER_OF_MODULES (CLX_MODULE_LAST)

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/* FUNCTION NAME:   clx_module_getModuleName
 * PURPOSE:
 *      This API returns the module name by given module ID. All modules could
 *      invoke this API.
 *
 * INPUT:
 *      const UI32_T module_id  -- Module ID, range from 0 to
 *                                 (CLX_MODULE_LAST - 1)
 * OUTPUT:
 *      UI8_T *ptr_module_name      -- Point to module name. The caller should
 *                                  prepare memory to receive this output. The
 *                                  maximum length of module name is
 *                                  CLX_MODULE_MAX_LENGTH_OF_NAME.
 * RETURN:
 *      CLX_E_OK             -- Successfully get module name.
 *      CLX_E_BAD_PARAMETER  -- Invalid parameter.
 *
 * NOTES:
 */

const C8_T *
clx_module_getModuleName(
    const UI32_T module_id );
#endif  /* CLX_MODULE_H */
