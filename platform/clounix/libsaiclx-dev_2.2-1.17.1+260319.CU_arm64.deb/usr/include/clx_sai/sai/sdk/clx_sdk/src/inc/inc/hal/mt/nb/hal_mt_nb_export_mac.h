/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_export_arp.h
 * PURPOSE:
 *  Provide HAL driver API functions of export arp module.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NB_EXPORT_MAC_H
#define HAL_MT_NB_EXPORT_MAC_H
/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <hal/hal_export_mac.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO  DECLARATIONS
 */
/* TOB hash offset definitions from tob_mt.h */
#define HAL_MT_NB_EXPORT_MAC_HASH_TILE_OFFSET  (15)
#define HAL_MT_NB_EXPORT_MAC_HASH_STAGE_OFFSET (18)

/* MAC export type definitions */
typedef enum hal_mt_nb_export_mac_type_e {
    HAL_MT_NB_EXPORT_MAC_TYPE_FDB = 0, /* Export FDB MAC entries from L2UC tiles */
    HAL_MT_NB_EXPORT_MAC_TYPE_ARP = 1, /* Export ARP MAC entries from ARP tiles */
    HAL_MT_NB_EXPORT_MAC_TYPE_MAX
} hal_mt_nb_export_mac_type_t;

/* DATA TYPE DECLARATIONS
 */

/* FUNCTION MACRO DECLARATIONS
 */
/**
 * @brief Initialize MAC export module.
 *
 * @param [in]    unit    - Chip unit number.
 * @return        CLX_E_OK        - Operation successful.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_nb_export_mac_init(uint32_t unit);

/**
 * @brief Export MAC HSH table data from hardware to DMA memory. This is the external interface for
 *        exporting MAC data to a buffer. Can be used by ARP module to get raw MAC data.
 *
 * @param [in]    unit           - Chip unit number.
 * @param [in]    dma_buffer     - Pre-allocated DMA buffer.
 * @param [in]    buffer_size    - DMA buffer size.
 * @param [in]    mac_type       - MAC export type (FDB or ARP).
 * @return        CLX_E_OK        - Operation successful.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_nb_export_mac_data_export(uint32 unit,
                                 uint8_t *dma_buffer,
                                 uint32_t buffer_size,
                                 hal_export_mac_type_t mac_type);

/**
 * @brief Calculate HSH buffer size for ARP export from valid ARP tiles.
 *
 * @param [in]     unit        - Chip unit number.
 * @param [out]    hsh_size    - HSH buffer size in bytes for ARP tiles.
 * @return         CLX_E_OK               - Operation successful.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters.
 */
clx_error_no_t
hal_mt_nb_export_mac_arp_hsh_size_calc(uint32 unit, uint32_t *hsh_size);

/**
 * @brief Get MAC data list for asic data.
 *
 * @param [in]     unit         - Chip unit number.
 * @param [in]     mac_type     - MAC export type (FDB or ARP).
 * @param [out]    data_list    - - Data list pointer.
 * @return         CLX_E_OK        - Operation successful.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_nb_export_mac_data_get(uint32_t unit, uint32_t mac_type, void *data_list);
#endif