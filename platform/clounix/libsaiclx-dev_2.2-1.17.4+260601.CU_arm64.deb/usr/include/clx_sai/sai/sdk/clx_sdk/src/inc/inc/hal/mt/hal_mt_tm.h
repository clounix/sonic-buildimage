/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_tm.h
 * PURPOSE: It provides Traffic Management Hardware Abstraction Layer for MT chip.
 * NOTES:
 *
 */

#ifndef HAL_MT_TM_H
#define HAL_MT_TM_H

#include <hal/hal.h>

/*****************************************************************************
 * NAMING CONSTANT DECLARATIONS
 *****************************************************************************
 */
#define HAL_MT_TM_TC_NUM (8)

/* The number of cpu queue */
#define HAL_MT_TM_CPU_QUEUE_NUM (48)
/* The number of unicast queue */
#define HAL_MT_TM_UNICAST_QUEUE_NUM (8)
/* The number of multicast queue */
#define HAL_MT_TM_MULTICAST_QUEUE_NUM (4)
/* The number of HQOS queue */
#define HAL_MT_TM_HQOS_QUEUE_NUM (16)

#define HAL_MT_TM_PFC_WD_DETECT_TIMER_BY_FREQ(unit) (1000000 / HAL_DEVICE_FREQ(unit))
/*****************************************************************************
 * FUNCTION DECLARATIONS
 *****************************************************************************
 */

typedef enum hal_mt_tm_wbdb_e { HAL_MT_TM_WBDB_BUF, HAL_MT_TM_WBDB_LAST } hal_mt_tm_wbdb_t;

clx_error_no_t
hal_mt_tm_tc_prof_para_chk(const uint32 unit, const uint32 prof_id, const clx_tm_tc_prof_t *prof);

clx_error_no_t
hal_mt_tm_trunc_prof_param_chk(const hal_tm_trunc_prof_t *prof);

clx_error_no_t
hal_mt_tm_trunc_cfg_param_check(const uint32 unit,
                                const hal_tm_trunc_cfg_t *config,
                                const boolean is_set);

uint32
hal_mt_tm_value_from_cfg_get(const uint32 unit,
                             const uint32 cfg,
                             const uint32 param0,
                             const uint32 param1,
                             uint32 value);

clx_error_no_t
hal_mt_tm_rsrc_init(const uint32 unit);

clx_error_no_t
hal_mt_tm_rsrc_deinit(const uint32 unit);

clx_error_no_t
hal_mt_tm_task_init(const uint32 unit);

clx_error_no_t
hal_mt_tm_task_deinit(const uint32 unit);

#endif /* End of HAL_MT_TM_H */
