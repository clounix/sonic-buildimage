/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_vlan.h
 * PURPOSE:
 *  Define the declartion for VLAN module.
 *
 * NOTES:
 *
 */

#ifndef HAL_VLAN_H
#define HAL_VLAN_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <hal/hal_const_cmn.h>

typedef struct hal_vlan_vid_ctl_s {
    hal_vid_ctl_typ_enum_t vid_ctl;
    uint16 vid_1st;
    uint16 vid_2nd;
} hal_vlan_vid_ctl_t;

typedef enum hal_vlan_tpid_type_e {
    CLX_VLAN_TPID_TYPE_INNER,
    CLX_VLAN_TPID_TYPE_OUTER,
    CLX_VLAN_TPID_TYPE_LAST
} hal_vlan_tpid_type_t;

#define HAL_VLAN_TPID_NUM (8)
typedef clx_vlan_tpid_t hal_vlan_tpid_grp_t[HAL_VLAN_TPID_NUM];

/**
 * @brief Init VLAN module lock.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK    - Operate success.
 * @return        others      - Init fail.
 */
clx_error_no_t
hal_vlan_lock_init(const uint32 unit);

/**
 * @brief Deinit VLAN module lock.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK    - Operate success.
 * @return        others      - Init fail.
 */
clx_error_no_t
hal_vlan_lock_deinit(const uint32 unit);

/**
 * @brief Lock VLAN module.
 *
 * @param [in]    unit    - Device unit number.
 */
void
hal_vlan_lock(const uint32 unit);

/**
 * @brief Unlock VLAN module.
 *
 * @param [in]    unit    - Device unit number.
 */
void
hal_vlan_unlock(const uint32 unit);

#endif
