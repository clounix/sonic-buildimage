/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_telm.h
 * PURPOSE:
 *      Provide telm hal layer api.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_MT_NB_TELM_H
#define HAL_MT_NB_TELM_H

#include <hal/mt/hal_mt_telm.h>

typedef enum hal_mt_nb_telm_cud_type_e {
    HAL_MT_NB_TELM_CUD_UC = 0x0,
    HAL_MT_NB_TELM_CUD_MC,
    HAL_MT_NB_TELM_CUD_MIR,
    HAL_MT_NB_TELM_CUD_CPU,
    HAL_MT_NB_TELM_CUD_MOD,
    HAL_MT_NB_TELM_CUD_INT_ENCAP_SHIM, // 5
    HAL_MT_NB_TELM_CUD_INT_DECAP_SHIM,
    HAL_MT_NB_TELM_CUD_INT_ENCAP_SHIM_META,
    HAL_MT_NB_TELM_CUD_INT_ENCAP_META,
    HAL_MT_NB_TELM_CUD_INT_DECAP_SHIM_META, // 9
    HAL_MT_NB_TELM_CUD_INT_ENCAP_REPORT,    // a
    HAL_MT_NB_TELM_CUD_INT_ENCAP_SHIM_TRUNC,
    HAL_MT_NB_TELM_CUD_INT_ENCAP_SHIM_META_TRUNC,
    HAL_MT_NB_TELM_CUD_INT_NO_DECAP_TRUNC,
    HAL_MT_NB_TELM_CUD_INT_MASK,
    HAL_MT_NB_TELM_CUD_INT_DECAP_SHIM_AND_MASK,
    HAL_MT_NB_TELM_CUD_LAST
} hal_mt_nb_telm_cud_type_t;

typedef enum hal_mt_nb_telm_mod_compress_rate_e {
    HAL_MT_NB_TELM_MOD_COMPRESS_RATE_10_TO_1 = 0, /* 0-> 10:1 */
    HAL_MT_NB_TELM_MOD_COMPRESS_RATE_100_TO_1,
    HAL_MT_NB_TELM_MOD_COMPRESS_RATE_1000_TO_1,
    HAL_MT_NB_TELM_MOD_COMPRESS_RATE_10000_TO_1,
    HAL_MT_NB_TELM_MOD_COMPRESS_RATE_LAST
} hal_mt_nb_telm_mod_compress_rate_t;
/* 10_TO_1 ~ 10000_TO_1 range middle value */
typedef enum hal_mt_nb_telm_mod_rate_range_mid_e {
    HAL_MT_NB_TELM_MOD_RATE_RANGE_MID_10_TO_100 = 55,
    HAL_MT_NB_TELM_MOD_RATE_RANGE_MID_100_TO_1000 = 550,
    HAL_MT_NB_TELM_MOD_RATE_RANGE_MID_1000_TO_10000 = 5500,
    HAL_MT_NB_TELM_MOD_RATE_RANGE_MID_LAST
} hal_mt_nb_telm_mod_rate_range_mid_t;

/*
 * INT LUT ENTRY
 * % # [17:13]  int_r_cud - INT report CUD type
 * % # [12]     int_r_act - INT report action
 * % # [11:07]  int_c_cud - INT clone  CUD type
 * % # [06]     int_c_act - INT clone  action
 * % # [05:01]  int_o_cud - INT origin CUD type
 * % # [00]     int_o_act - INT origin action
 */
typedef struct hal_mt_nb_telm_lut_entry_s {
    boolean rep_o_act;
    hal_mt_nb_telm_cud_type_t rep_o_cud;
    boolean rep_c_act;
    hal_mt_nb_telm_cud_type_t rep_c_cud;
    boolean rep_r_act;
    hal_mt_nb_telm_cud_type_t rep_r_cud;
} hal_mt_nb_telm_lut_entry_t;

typedef struct hal_mt_nb_telm_prof_tbl_fld_s {
    uint32 lfsr_tbl_id;
    uint32 lfsr_fld;
    uint32 instr_tbl_id;
    uint32 instr_fld;
} hal_mt_nb_telm_prof_tbl_fld_t;

#define HAL_MT_TELM_NB_TOB_WRITE_PSR_SLV_ENTRY(__unit__, __inst_idx__, __subinst_idx__,            \
                                               __table_id__, __entry_idx__, __ptr_entry__)         \
    ({                                                                                             \
        TOB_CHIP_INFO_SET(chip_info, unit, __inst_idx__, __subinst_idx__);                         \
        TOB_ENTRY_INFO_SET(tob_entry_info, MT_NB_REG_TDS_PSR_SLV_##__table_id__, 0, __entry_idx__, \
                           1, NULL, __ptr_entry__);                                                \
        rc += tob_entry_write(chip_info, &tob_entry_info);                                         \
        TOB_ENTRY_INFO_SET(tob_entry_info, MT_NB_REG_DIS_PSR_SLV_##__table_id__, 0, __entry_idx__, \
                           1, NULL, __ptr_entry__);                                                \
        rc += tob_entry_write(chip_info, &tob_entry_info);                                         \
        TOB_ENTRY_INFO_SET(tob_entry_info, MT_NB_REG_RWI_PSR_SLV_INNER_##__table_id__, 0,          \
                           __entry_idx__, 1, NULL, __ptr_entry__);                                 \
        rc += tob_entry_write(chip_info, &tob_entry_info);                                         \
        TOB_ENTRY_INFO_SET(tob_entry_info, MT_NB_REG_RWI_PSR_SLV_OUTER_##__table_id__, 0,          \
                           __entry_idx__, 1, NULL, __ptr_entry__);                                 \
        rc += tob_entry_write(chip_info, &tob_entry_info);                                         \
    })

#define HAL_MT_TELM_TM_LUT_ENTRY_PACK(r_cud, r_act, c_cud, c_act, o_cud, o_act)          \
    ((r_cud << HAL_MT_TELM_REP_R_CUD_OFFSET) | (r_act << HAL_MT_TELM_REP_R_ACT_OFFSET) | \
     (c_cud << HAL_MT_TELM_REP_C_CUD_OFFSET) | (c_act << HAL_MT_TELM_REP_C_ACT_OFFSET) | \
     (o_cud << HAL_MT_TELM_REP_O_CUD_OFFSET) | o_act)

clx_error_no_t
hal_mt_nb_telm_tob_set(const uint32 unit, const hal_mt_telm_tob_type_t op_type, const uint32 value);
clx_error_no_t
hal_mt_nb_telm_tob_get(const uint32 unit, const hal_mt_telm_tob_type_t op_type, uint32 *ptr_value);
clx_error_no_t
hal_mt_nb_telm_mod_tm_en_set(const uint32 unit, const boolean mod_en);
clx_error_no_t
hal_mt_nb_telm_mod_tm_en_get(const uint32 unit, uint32 *ptr_mod_en);
clx_error_no_t
hal_mt_nb_telm_type_set(const uint32 unit, const clx_telm_type_t telm_type);
clx_error_no_t
hal_mt_nb_telm_type_get(const uint32 unit, uint32 *ptr_telm_type);
clx_error_no_t
hal_mt_nb_telm_delay_cycle_set(const uint32 unit);
clx_error_no_t
hal_mt_nb_telm_int_sampler_set(const uint32 unit, const uint32 profile_id, const uint32 threshold);
clx_error_no_t
hal_mt_nb_telm_int_instr_set(const uint32 unit, const uint32 profile_id, const uint16 instr_bmp);
clx_error_no_t
hal_mt_nb_telm_int_instr_get(const uint32 unit, const uint32 profile_id, uint16 *ptr_instr_bmp);
clx_error_no_t
hal_mt_nb_telm_int_prof_clean(const uint32 unit, const uint32 profile_id);
clx_error_no_t
hal_mt_nb_telm_int_tm_lut_init(const uint32 unit);
clx_error_no_t
hal_mt_nb_telm_int_clone_set(const uint32 unit, const boolean int_clone);
clx_error_no_t
hal_mt_nb_telm_int_clone_get(const uint32 unit, boolean *ptr_int_clone);
clx_error_no_t
hal_mt_nb_telm_int_role_set(const uint32 unit, const uint32 port, const uint32 int_role);
clx_error_no_t
hal_mt_nb_telm_int_role_get(const uint32 unit, const uint32 port, uint32 *ptr_int_role);
clx_error_no_t
hal_mt_nb_telm_force_en_set(const uint32 unit, const uint32 port, const boolean enable);
clx_error_no_t
hal_mt_nb_telm_force_en_get(const uint32 unit, const uint32 port, boolean *ptr_enable);
clx_error_no_t
hal_mt_nb_telm_int_edge_set(const uint32 unit, const clx_port_t egr_port, const boolean is_edge);
clx_error_no_t
hal_mt_nb_telm_int_edge_get(const uint32 unit, const clx_port_t egr_port, boolean *ptr_is_edge);
clx_error_no_t
hal_mt_nb_telm_mode_set(const uint32 unit, const clx_telm_mode_t telm_mode);
clx_error_no_t
hal_mt_nb_telm_mode_get(const uint32 unit, clx_telm_mode_t *ptr_telm_mode);
clx_error_no_t
hal_mt_nb_telm_qocc_unit_size_set(const uint32 unit,
                                  const clx_swc_cfg_qocc_unit_size_t qocc_unit_size);
clx_error_no_t
hal_mt_nb_telm_qocc_unit_size_get(const uint32 unit, uint32 *ptr_qocc_unit_size);

clx_error_no_t
hal_mt_nb_telm_qsize_stat_mode_set(const uint32 unit, const uint32 qsize_stat_mode);
clx_error_no_t
hal_mt_nb_telm_qsize_stat_mode_get(const uint32 unit, uint32 *ptr_qsize_stat_mode);

clx_error_no_t
hal_mt_nb_telm_int_identifier_set(const uint32 unit,
                                  const uint32 attr_bmp,
                                  const clx_telm_int_identifier_t *identifier);
clx_error_no_t
hal_mt_nb_telm_int_identifier_get(const uint32 unit, clx_telm_int_identifier_t *ptr_identifier);
clx_error_no_t
hal_mt_nb_telm_tm_trunc_size_get(const uint32 unit,
                                 const clx_telm_trunc_pkt_size_t telm_trunc_size,
                                 hal_tm_trunc_size_t *ptr_tm_trunc_size);
clx_error_no_t
hal_mt_nb_telm_mod_rep_tnl_cfg_set(const uint32 unit,
                                   const uint32 nvo3_encap_id,
                                   const uint32 nvo3_adj_id);
clx_error_no_t
hal_mt_nb_telm_mod_rep_tnl_cfg_get(const uint32 unit,
                                   uint32 *ptr_nvo3_encap_id,
                                   uint32 *ptr_nvo3_adj_id);
clx_error_no_t
hal_mt_nb_telm_int_rep_tnl_cfg_set(const uint32 unit,
                                   const uint32 nvo3_encap_id,
                                   const uint32 nvo3_adj_id);
clx_error_no_t
hal_mt_nb_telm_int_rep_tnl_cfg_del(const uint32 unit, const uint32 nvo3_encap_id);
clx_error_no_t
hal_mt_nb_telm_int_rep_tnl_cfg_get(const uint32 unit,
                                   uint32 *ptr_nvo3_encap_id,
                                   uint32 *ptr_nvo3_adj_id);
clx_error_no_t
hal_mt_nb_telm_int_meta_info_set(const uint32 unit, const clx_telm_int_mata_info_t *meta_info);
clx_error_no_t
hal_mt_nb_telm_int_meta_info_get(const uint32 unit, clx_telm_int_mata_info_t *ptr_meta_info);
clx_error_no_t
hal_mt_nb_telm_int_restore_dscp_set(const uint32 unit, const clx_telm_restore_dscp_t *dscp_restore);
clx_error_no_t
hal_mt_nb_telm_int_restore_dscp_get(const uint32 unit, clx_telm_restore_dscp_t *ptr_dscp_restore);
clx_error_no_t
hal_mt_nb_telm_ioam_rwi_fifo_cfg_init(const uint32 unit);
clx_error_no_t
hal_mt_nb_telm_ioam_hw_cfg_init(const uint32 unit);
clx_error_no_t
hal_mt_nb_telm_ioam_fifo_to_clx_entry_convert(const uint32 unit,
                                              const uint32 *ptr_fifo_entry,
                                              clx_telm_ioam_fifo_entry_t *ptr_clx_entry);
clx_error_no_t
hal_mt_nb_telm_port_dci_set(const uint32 unit, const uint32 port, const boolean dci_en);
clx_error_no_t
hal_mt_nb_telm_port_dci_get(const uint32 unit, const uint32 port, boolean *ptr_dci_en);
clx_error_no_t
hal_mt_nb_telm_port_speed_set(const uint32 unit, const uint32 port, const clx_port_speed_t speed);
clx_error_no_t
hal_mt_nb_telm_ifa_hw_cfg_init(const uint32 unit);
clx_error_no_t
hal_mt_nb_telm_mod_hw_cfg_init(const uint32 unit);
clx_error_no_t
hal_mt_nb_telm_ioam_cfg_set(const uint32 unit, const clx_telm_ioam_cfg_t *ptr_ioam_cfg);
clx_error_no_t
hal_mt_nb_telm_ioam_cfg_get(const uint32 unit, clx_telm_ioam_cfg_t *ptr_ioam_cfg);
clx_error_no_t
hal_mt_nb_telm_ioam_diag_cfg_get(uint32 unit, hal_mt_telm_ioam_diag_reg_cfg_t *ptr_ioam_diag_reg);
clx_error_no_t
hal_mt_nb_telm_ioam_diag_cfg_set(uint32 unit, hal_mt_telm_ioam_diag_reg_cfg_t *ptr_ioam_diag_reg);
clx_error_no_t
hal_mt_nb_telm_ifa_cfg_set(const uint32 unit, const clx_telm_ifa_cfg_t *ptr_ifa_cfg);
clx_error_no_t
hal_mt_nb_telm_ifa_cfg_get(const uint32 unit, clx_telm_ifa_cfg_t *ptr_ifa_cfg);
clx_error_no_t
hal_mt_nb_telm_mod_reg_set(const uint32 unit, const clx_telm_mod_cfg_t *ptr_mod_cfg);
clx_error_no_t
hal_mt_nb_telm_mod_reg_get(const uint32 unit, clx_telm_mod_cfg_t *ptr_mod_cfg);
clx_error_no_t
hal_mt_nb_telm_irq_hop_cnt_zero_status_get(const uint32 unit,
                                           const uint32 inst_idx,
                                           boolean *ptr_hop_cnt_zero);
clx_error_no_t
hal_mt_nb_telm_irq_ifa_len_exceed_status_get(const uint32 unit,
                                             const uint32 inst_idx,
                                             boolean *ptr_ifa_len_exceed);
clx_error_no_t
hal_mt_nb_telm_rwo_encap_ip_set(const uint32 unit,
                                const uint32 nvo3_encap_id,
                                const uint32 src_ip_encap_id,
                                const uint32 dst_ip_encap_id,
                                const clx_telm_collector_cfg_info_t *ptr_clct_cfg_info);
clx_error_no_t
hal_mt_nb_telm_rwo_encap_ip_get(const uint32 unit,
                                const uint32 nvo3_encap_id,
                                uint32 *ptr_src_ip_encap_id,
                                uint32 *ptr_dst_ip_encap_id,
                                clx_telm_collector_cfg_info_t *ptr_clct_cfg_info);
clx_error_no_t
hal_mt_nb_telm_rwo_encap_ip_clear(const uint32 unit, const uint32 nvo3_encap_id);

clx_error_no_t
hal_mt_nb_telm_encap_ip_id_get(const uint32 unit,
                               const boolean ipv4,
                               const uint32 src_ip_id,
                               const uint32 dst_ip_id,
                               clx_ip_addr_t *ptr_src_ip,
                               clx_ip_addr_t *ptr_dst_ip);

clx_error_no_t
hal_mt_nb_telm_hdr_event_handle(const uint32 unit, void *ptr_cookie);

clx_error_no_t
hal_mt_nb_telm_mod_oq_get(const uint32 unit,
                          const uint32 port,
                          const uint32 queue_id,
                          uint32 *ptr_out_queue);
#endif
