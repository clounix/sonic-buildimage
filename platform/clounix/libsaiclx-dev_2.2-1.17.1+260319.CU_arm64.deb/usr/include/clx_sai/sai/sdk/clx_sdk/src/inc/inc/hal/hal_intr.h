/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_intr.h
 * PURPOSE:
 *      1. hal_intr.h provides HAL ISR manipulation APIs.
 *
 * NOTES:
 *
 */

#ifndef HAL_INTR_H
#define HAL_INTR_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_intr.h>
#include <drv/drv.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_INTR_SUBSYS_MAX_NUM (16)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_INTR_GET_INTR_INFO_PTR(unit) \
    (_ext_chip_control_block[unit].ptr_driver_info->ptr_intr_info)

typedef uint32 hal_intr_type_t;

typedef struct hal_intr_info_s {
    uint32 intr_num;

    drv_dev_isr_func_t intr_init;
    drv_dev_isr_func_t intr_deinit;
    drv_dev_isr_func_t intr_init_cfg;
    drv_dev_isr_func_t intr_deinit_cfg;
    drv_dev_isr_func_t intr_dispatcher;
} hal_intr_info_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* -------------------------------------- Init and deinit */
clx_error_no_t
hal_intr_init(const uint32 unit);

clx_error_no_t
hal_intr_deinit(const uint32 unit);

/* -------------------------------------- API and callbacks */
clx_error_no_t
hal_intr_event_cnt_get(const uint32 unit, const hal_intr_type_t intr_type, uint32 *ptr_cnt);

clx_error_no_t
hal_intr_event_cnt_incr(const uint32 unit, const hal_intr_type_t intr_type);

clx_error_no_t
hal_intr_event_cnt_clear(const uint32 unit, const hal_intr_type_t intr_type);

const char *
hal_intr_event_string_get(const uint32 unit, const hal_intr_type_t intr_type);

clx_error_no_t
hal_intr_intr_status_dump(const uint32 unit);

#endif /* #ifndef HAL_INTR_H */
