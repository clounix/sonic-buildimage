/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws, and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_port.h
 * PURPOSE:
 *      It provides HAL PORT module API.
 * NOTES:
 */

#ifndef HAL_MT_NB_PORT_H
#define HAL_MT_NB_PORT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>
// #include <hal/mt/hal_mt_mac.h>
#include <hal/mt/nb/hal_mt_nb_serdes.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_NB_ETH_SLICE_MAX_NUM           (8)
#define HAL_MT_NB_ETH_MACRO_MAX_NUM_PER_SLICE (4)
#define HAL_MT_NB_ETH_MACRO_TOTAL_NUM \
    (HAL_MT_NB_ETH_SLICE_MAX_NUM * HAL_MT_NB_ETH_MACRO_MAX_NUM_PER_SLICE)
#define HAL_MT_NB_L256_ETH_MACRO_MAX_NUM_PER_SLICE   (8)
#define HAL_MT_NB_ETH_MACRO_LANES_PER_MACRO          (8)
#define HAL_MT_NB_PORT_DROP_PKT_DISABLE              (0)
#define HAL_MT_NB_PORT_DROP_PKT_UNTAGGED             (1)
#define HAL_MT_NB_PORT_DROP_PKT_TAGGED               (2)
#define HAL_MT_NB_PORT_DROP_PKT_TAGGED_EXPT_DFLT_VID (3)
#define HAL_MT_NB_PORT_MACRO_INVALID                 (0xFFFFFFFF)

#define HAL_MT_NB_PORT_DERICTION_INGRESS (0)
#define HAL_MT_NB_PORT_DERICTION_EGRESS  (1)

#define HAL_MT_NB_PORT_MBURST_CNT_TX_BYTE       (0)
#define HAL_MT_NB_PORT_MBURST_CNT_TX_PKT        (1)
#define HAL_MT_NB_PORT_MBURST_CNT_TX_MATCH_BYTE (2)
#define HAL_MT_NB_PORT_MBURST_CNT_TX_MATCH_PKT  (3)

typedef enum hal_mt_nb_port_fc_e {
    HAL_MT_NB_PORT_FC_DISABLE,
    HAL_MT_NB_PORT_FC_PAUSE,
    HAL_MT_NB_PORT_FC_PFC,
    HAL_MT_NB_PORT_FC_LAST
} hal_mt_nb_port_fc_t;

#define HAL_MT_NB_PORT_DBG_TOTAL_REG_NUM_MAX (700)

typedef struct hal_mt_nb_port_reg_info_s {
    uint32 reg_type;
    uint32 module_type;
    uint32 based;
    uint32 *reg_list;
    uint32 reg_cnt;
} hal_mt_nb_port_reg_info_t;

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS */
/**
 * @brief To apply default properties for the new created port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Set port default fail.
 */
clx_error_no_t
hal_mt_nb_port_default_set(const uint32 unit, const uint32 port);

/**
 * @brief To clear default properties for the destroyed port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Reset port default fail.
 */
clx_error_no_t
hal_mt_nb_port_default_reset(const uint32 unit, const uint32 port);

/**
 * @brief To get the administrative state for a specific port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [out]    ptr_enable    - To enable/disable the port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_phy_admin_state_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief This API is used to set the mapping between unit/port and mac/lane number.
 *
 * This API is suggested to be used during SDK initialization.
 * Support_chip: CLX8600.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Physical port ID.
 * @param [in]    ptr_lane_map    - Lane map info pointer.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_lane_map_set(const uint32 unit,
                            const uint32 port,
                            const clx_port_lane_map_info_t *ptr_lane_map);

/**
 * @brief This API is used to get the mapping between unit/port and mac/lane number.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Physical port ID.
 * @param [out]    ptr_lane_map    - Lane map info pointer.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_lane_map_get(const uint32 unit,
                            const uint32 port,
                            clx_port_lane_map_info_t *ptr_lane_map);

/**
 * @brief This API is used to set port egress vlan tag control.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    intf            - Logical port ID.
 * @param [in]    bdid            - Bridge Domain ID.
 * @param [in]    ptr_port_tag    - Egress vlan tag control.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_vlan_tag_ctrl_set(const uint32 unit,
                                 const clx_port_t intf,
                                 const clx_bridge_domain_t bdid,
                                 const clx_port_vlan_tag_ctrl_t *ptr_port_tag);

/**
 * @brief This API is used to get port egress vlan tag control.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     intf            - Logical port ID.
 * @param [in]     bdid            - Bridge Domain ID.
 * @param [out]    ptr_port_tag    - Egress vlan tag control.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_vlan_tag_ctrl_get(const uint32 unit,
                                 const clx_port_t intf,
                                 const clx_bridge_domain_t bdid,
                                 clx_port_vlan_tag_ctrl_t *ptr_port_tag);

/**
 * @brief To get fec from umac channel mode.
 *
 * @param [in]    unit       - Chip id.
 * @param [in]    port       - Port id.
 * @param [in]    ptr_fec    - Fec mode.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_hal_fec_get(const uint32 unit, const uint32 port, uint32 *ptr_fec);

/**
 * @brief To set eth port deadlock.
 *
 * @param [in]    unit     - Chip id.
 * @param [in]    port     - Port id.
 * @param [in]    queue    - Queue id.
 * @param [in]    mode     - Deadlock state.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_dead_lock_set(const uint32 unit,
                             const uint32 port,
                             const uint32 queue,
                             const uint32 mode);

/**
 * @brief To set eth port deadlock.
 *
 * Set  based on 0.74ns unit. For example 100ms 1.35*10^8 (80B EFCO);.
 * Support_chip: CLX8600.
 *
 * @param [in]    unit         - Chip id.
 * @param [in]    port         - Port id.
 * @param [in]    threshold    - Deadlock threshold.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_dead_lock_th_set(const uint32 unit, const uint32 port, const uint32 threshold);

/**
 * @brief To set tx flush state.
 *
 * Tx flush is a write-only feature.
 * Support_chip: CLX8600.
 *
 * @param [in]    unit      - Chip id.
 * @param [in]    port      - Port id.
 * @param [in]    enable    - Flush state.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_tx_flush_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief To set tx queue flush state.
 *
 * Tx queue flush is a write-only feature.
 * Support_chip: CLX8600.
 *
 * @param [in]    unit      - Chip id.
 * @param [in]    port      - Port id.
 * @param [in]    queue     - Flush queue.
 * @param [in]    enable    - Mac tx flush enable/disable.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_tx_que_flush_set(const uint32 unit,
                                const uint32 port,
                                const uint32 queue,
                                const uint32 enable);

/**
 * @brief To set per queue Flow Control ignore.
 *
 * @param [in]    unit      - Chip id.
 * @param [in]    port      - Port id.
 * @param [in]    queue     - Queue id.
 * @param [in]    enable    - Fc ignore state.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_flow_ctrl_ignore_set(const uint32 unit,
                                    const uint32 port,
                                    const uint32 queue,
                                    const uint32 enable);

/**
 * @brief To get per queue Flow Control ignore.
 *
 * @param [in]    unit      - Chip id.
 * @param [in]    port      - Port id.
 * @param [in]    queue     - Queue id.
 * @param [in]    enable    - Fc ignore state.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_flow_ctrl_ignore_get(const uint32 unit,
                                    const uint32 port,
                                    const uint32 queue,
                                    uint32 *enable);
/**
 * @brief Set epl xoff mask.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - 1: enable epl xoff mask 0: disable epl xoff mask.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_tx_xoff_mask_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Check buffer empty.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port id.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_buf_empty_check(const uint32 unit, const uint32 port);

/**
 * @brief Set rx port status.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - 1: enable 0: disable.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_rx_admin_state_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Set tx port status.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - 1: enable 0: disable.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_tx_admin_state_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Config cpx port pl.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Cpx port id(256,257,259).
 * @param [in]    speed    - Cpi speed, max 100g.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_cpx_pl_cfg(const uint32 unit, const uint32 port, clx_port_speed_t speed);

/**
 * @brief To set pkt drop for tm module.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - Drop flag.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_pkt_drop_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief This API is used to set the medium type for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port ID.
 * @param [in]    medium    - Medium type.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_medium_type_set(const uint32 unit,
                               const uint32 port,
                               const clx_port_medium_t medium);

/**
 * @brief This API is used to get the medium type for a specific port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port ID.
 * @param [out]    ptr_medium    - Medium type.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_medium_type_get(const uint32 unit, const uint32 port, clx_port_medium_t *ptr_medium);

/**
 * @brief This API is used to set counter clear.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_SUPPORT      - This API is not supported in this chip.
 */
clx_error_no_t
hal_mt_nb_port_fec_clear(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to get xoff status.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     port               - Physical port.
 * @param [out]    ptr_xoff_status    - Xoff status.
 * @return         CLX_E_OK             - Success.
 * @return         CLX_E_NOT_SUPPORT    - This API is not supported in this chip.
 */
clx_error_no_t
hal_mt_nb_port_xoff_status_get(const uint32 unit,
                               const uint32 port,
                               clx_port_xoff_status_t *ptr_xoff_status);
/**
 * @brief This API is used to show debug info.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port.
 * @param [in]    module    - Debug module.
 * @param [in]    type      - Debug info type.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_NOT_SUPPORT      - This API is not supported in this chip.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_dbg_info_show(const uint32 unit,
                             const uint32 port,
                             const uint32 module,
                             const uint32 type);

/**
 * @brief Set tx pkt ENA per physical port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - 1: enable tx state 0: disable tx state.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_tx_pkt_ena_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Set tx state per physical port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - 1: enable tx state 0: disable tx state.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_tx_state_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief To get the auto-negotiation status for a specific port.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port id.
 * @param [out]    ptr_anlt    - Toggle status of auto-negotiation per port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_phy_anlt_get(const uint32 unit, const uint32 port, uint32 *ptr_anlt);

/**
 * @brief Set Port config.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Port ID.
 * @param [in]    ptr_config    - Port config.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_cfg_set(const uint32 unit, const uint32 port, const clx_port_cfg_t *ptr_config);

/**
 * @brief Get port config.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Port ID.
 * @param [out]    ptr_config    - Port config.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_cfg_get(const uint32 unit, const uint32 port, clx_port_cfg_t *ptr_config);

/**
 * @brief This API is used to init port config.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK            - Success.
 * @return        CLX_E_NOT_INITED    - Module is not initialized.
 */
clx_error_no_t
hal_mt_nb_port_cfg_init(uint32 unit);

clx_error_no_t
hal_mt_nb_port_mac_config_update(uint32 unit, uint32 port, uint32 an_speed, uint32 an_fec);

/**
 * @brief To set the speed for a specific port.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port id.
 * @param [in]    speed    - The speed of the physical port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_speed_set(const uint32 unit, const uint32 port, const clx_port_speed_t speed);

/**
 * @brief To get the speed list for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port              - Physical port id.
 * @param [in]     max_len           - The max length of speed list.
 * @param [out]    ptr_speed_list    - The supported speed list of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_speed_list_get(const uint32 unit,
                              const uint32 port,
                              const uint32 max_len,
                              clx_port_speed_t *ptr_speed_list);

/**
 * @brief To get the speed for a specific port.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port id.
 * @param [out]    ptr_speed    - The speed of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_speed_get(const uint32 unit, const uint32 port, clx_port_speed_t *ptr_speed);

/**
 * @brief To set the flow control configuration for a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port id.
 * @param [in]    fc      - The flow control configuration of the physical port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_flow_ctrl_set(const uint32 unit, const uint32 port, const clx_port_fc_dir_t fc);

/**
 * @brief To get the flow control configuration for a specific port.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Physical port id.
 * @param [out]    ptr_fc    - The flow control configuration of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_flow_ctrl_get(const uint32 unit, const uint32 port, clx_port_fc_dir_t *ptr_fc);

/**
 * @brief To set the PFC configuration for a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port id.
 * @param [in]    pri     - The priority number 0~7.
 * @param [in]    pfc     - The PFC configuration of the physical port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_pri_flow_ctrl_set(const uint32 unit,
                                 const uint32 port,
                                 const uint8 pri,
                                 const clx_port_fc_dir_t pfc);

/**
 * @brief To get the PFC configuration for a specific port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port id.
 * @param [in]     pri        - The priority number 0~7.
 * @param [out]    ptr_pfc    - The PFC configuration of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_pri_flow_ctrl_get(const uint32 unit,
                                 const uint32 port,
                                 const uint8 pri,
                                 clx_port_fc_dir_t *ptr_pfc);

/**
 * @brief To get the EEE mode for a specific port.
 *
 * NB umac does not support EEE.
 * Support_chip: CLX8600.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port id.
 * @param [out]    ptr_mode    - The EEE mode of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_eee_mode_get(const uint32 unit, const uint32 port, clx_port_eee_mode_t *ptr_mode);

/**
 * @brief This API is used to get the ability for a specific port.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port ID.
 * @param [out]    ptr_ability    - Port ability.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_ability_get(const uint32 unit, const uint32 port, clx_port_ability_t *ptr_ability);

/**
 * @brief To set the auto-negotiation advertisement for a specific port.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port           - Physical port id.
 * @param [in]    ptr_ability    - Auto-negotiation ability setting per port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_local_adv_ability_set(const uint32 unit,
                                     const uint32 port,
                                     const clx_port_ability_t *ptr_ability);

/**
 * @brief To get the auto-negotiation advertisement for a specific port.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port           - Physical port id.
 * @param [in]    ptr_ability    - Auto-negotiation ability setting per port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_local_adv_ability_get(const uint32 unit,
                                     const uint32 port,
                                     clx_port_ability_t *ptr_ability);

/**
 * @brief This API is used to get the auto-negotiation remote advertisement for a specific port.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port ID.
 * @param [out]    ptr_ability    - Auto-negotiation ability setting per port.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_remote_adv_ability_get(const uint32 unit,
                                      const uint32 port,
                                      clx_port_ability_t *ptr_ability);

/**
 * @brief This API is used to set the loopback for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port ID.
 * @param [in]    lbtype    - Loopback type: CLX_PORT_LOOPBACK_DISABLE: disable loopback.
 *                            CLX_PORT_LOOPBACK_PHY: local PHY loopback.
 *                             CLX_PORT_LOOPBACK_PHY_NEAR_END_PARALLEL: local PHY parallel loopback.
 *                            CLX_PORT_LOOPBACK_PHY_FAR_END_SERIAL: remote serial loopback.
 *                            CLX_PORT_LOOPBACK_PHY_FAR_END_PARALLEL: remote parallel loopback
 *                            external phy. CLX_PORT_LOOPBACK_MAC: local MAC loopback.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_lb_set(const uint32 unit, const uint32 port, const clx_port_loopback_t lbtype);

/**
 * @brief This API is used to get the loopback for a specific port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port ID.
 * @param [out]    ptr_lbtype    - Loopback type: CLX_PORT_LOOPBACK_DISABLE: disable loopback.
 *                                 CLX_PORT_LOOPBACK_PHY: local PHY loopback.
 *                                  CLX_PORT_LOOPBACK_PHY_NEAR_END_PARALLEL: local PHY parallel
 *                                 loopback. CLX_PORT_LOOPBACK_PHY_FAR_END_SERIAL: remote serial
 *                                 loopback. CLX_PORT_LOOPBACK_PHY_FAR_END_PARALLEL: remote
 *                                 parallel loopback external phy. CLX_PORT_LOOPBACK_MAC: local MAC
 *                                 loopback.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_lb_get(const uint32 unit, const uint32 port, clx_port_loopback_t *ptr_lbtype);

/**
 * @brief This API is used to initialize a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_create(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to initialize a specific port.
 *
 * @param [in]    unit                 - Device unit number.
 * @param [in]    port                 - Physical port ID.
 * @param [in]    ptr_create_config    - Port create config.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_ext_create(const uint32 unit,
                          const uint32 port,
                          const clx_port_create_config_t *ptr_create_config);

/**
 * @brief This API is used to deinitialize a specific port.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_destroy(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to set the PHY configuration for a specific port.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port ID.
 * @param [in]    ptr_config    - PHY config.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_phy_cfg_set(const uint32 unit,
                           const uint32 port,
                           const clx_port_phy_cfg_t *ptr_config);

/**
 * @brief This API is used to get the PHY configuration for a specific port.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port ID.
 * @param [in]    ptr_config    - PHY config.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_phy_cfg_get(const uint32 unit, const uint32 port, clx_port_phy_cfg_t *ptr_config);

/**
 * @brief This API is used to set the egress TPID0 as TPID1 value for RSPAN port.
 *
 * Called by mirror module.
 * Support_chip: CLX8600.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    port             - Port Number.
 * @param [in]    is_rspan_port    - Port is RSPAN port.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_egr_port_tpid_for_rspan_set(const uint32 unit,
                                           const uint32 port,
                                           const boolean is_rspan_port);
/**
 * @brief This API is used to get the bridge domain bound to the port vlan.
 *
 * Support CLX_GPORT_TYPE_UNIT_PORT and CLX_GPORT_TYPE_SRV6.
 * If svid=CLX_INVALID_ID, cvid=CLX_INVALID_ID, port base derive bridge domain.
 * If svid=valid vid, cvid=CLX_INVALID_ID, port+single_vlan derive bridge domain.
 * If svid=valid vid, cvid=valid vid, port + double_vlan derive bridge domain.
 * Support_chip: all.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Interface object.
 * @param [in]     svid        - First layer VLAN.
 * @param [in]     cvid        - Second layer VLAN.
 * @param [out]    ptr_bdid    - Bridge domain id.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_vlan_bd_get(const uint32 unit,
                           const clx_port_t port,
                           const uint32 svid,
                           const uint32 cvid,
                           clx_bridge_domain_t *ptr_bdid);
/**
 * @brief This API is used to bind port vlan and bridge domain.
 *
 * Support CLX_GPORT_TYPE_UNIT_PORT and CLX_GPORT_TYPE_SRV6.
 * If svid=CLX_INVALID_ID, cvid=CLX_INVALID_ID, port base derive bridge domain.
 * If svid=valid vid, cvid=CLX_INVALID_ID, port+single_vlan derive bridge domain.
 * If svid=valid vid, cvid=valid vid, port + double_vlan derive bridge domain.
 * Support_chip: all.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Interface object.
 * @param [in]    svid    - First layer VLAN.
 * @param [in]    cvid    - Second layer VLAN.
 * @param [in]    bdid    - Bridge domain id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_vlan_bd_bind(const uint32 unit,
                            const clx_port_t port,
                            const uint32 svid,
                            const uint32 cvid,
                            const clx_bridge_domain_t bdid);

/**
 * @brief This API is used to unbind port vlan and bridge domain.
 *
 * Support CLX_GPORT_TYPE_UNIT_PORT and CLX_GPORT_TYPE_SRV6.
 * If svid=CLX_INVALID_ID, cvid=CLX_INVALID_ID, port base derive bridge domain.
 * If svid=valid vid, cvid=CLX_INVALID_ID, port+single_vlan derive bridge domain.
 * If svid=valid vid, cvid=valid vid, port + double_vlan derive bridge domain.
 * Support_chip: all.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Interface object.
 * @param [in]    svid    - First layer VLAN.
 * @param [in]    cvid    - Second layer VLAN.
 * @param [in]    bdid    - Bridge domain id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_vlan_bd_unbind(const uint32 unit,
                              const clx_port_t port,
                              const uint32 svid,
                              const uint32 cvid,
                              const clx_bridge_domain_t bdid);

/**
 * @brief Get port tx timestamp entry information.
 *
 * @param [in]     unit            - Chip id.
 * @param [in]     port            - Port id.
 * @param [out]    ptr_ts_entry    - Timestamp entry information.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_ts_tx_entry_get(const uint32 unit,
                               const uint32 port,
                               clx_port_ts_entry_t *ptr_ts_entry);

/**
 * @brief Set high latency threshold.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    threshold    - High latency threshold.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_nb_port_egr_high_latency_thd_set(const uint32 unit, const uint32 threshold);

/**
 * @brief Get high latency threshold.
 *
 * @param [in]     unit         - Device unit number.
 * @param [out]    threshold    - High latency threshold.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_nb_port_egr_high_latency_thd_get(const uint32 unit, uint32 *threshold);

/**
 * @brief Set Mburst property.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Physical port ID.
 * @param [in]    ptr_cfg    - Property type.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_mburst_cfg_set(const uint32 unit,
                              const uint32 port,
                              const clx_port_mburst_cfg_t *ptr_cfg);

/**
 * @brief Get Mburst property.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port ID.
 * @param [in]     ptr_cfg    - Property type.
 * @param [out]    ptr_cfg    - Property type.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_mburst_cfg_get(const uint32 unit, const uint32 port, clx_port_mburst_cfg_t *ptr_cfg);

/**
 * @brief Get mburst statistic.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [in]     dir         - Direction.
 * @param [out]    ptr_stat    - Mburst stat.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_mburst_stat_get(const uint32 unit,
                               const uint32 port,
                               const clx_dir_t dir,
                               clx_port_mburst_stat_t *ptr_stat);

/**
 * @brief Get Mburst Histogram threshold.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port ID.
 * @param [in]     dir          - IPL or EPL.
 * @param [in]     thrd_num     - Threshold num.
 * @param [out]    ptr_count    - Mburst Histogram count.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_mburst_hist_cnt_get(const uint32 unit,
                                   const uint32 port,
                                   const clx_dir_t dir,
                                   const uint32 thrd_num,
                                   uint32 *ptr_count);

/**
 * @brief Clear Mburst count.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @param [in]    dir     - IPL or EPL.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_mburst_cnt_clear(const uint32 unit, const uint32 port, const clx_dir_t dir);

/**
 * @brief This API is used to update the tad mode for a local interface.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    plane_id    - Plane ID.
 * @param [in]    lcl_intf    - Local interface.
 * @param [in]    tag_mode    - Tag mode.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_intf_tag_mode_update(const uint32 unit,
                                    const uint32 plane_id,
                                    const uint32 lcl_intf,
                                    const uint32 tag_mode);

/**
 * @brief This API is used to set the configs for a specific interface object.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     intf          - Interface object.
 * @param [out]    ptr_config    - The pointer of the interface configs.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_intf_cfg_set(const uint32 unit,
                            const clx_port_t intf,
                            const clx_port_intf_cfg_t *ptr_config);

/**
 * @brief This API is used to set the configs for a specific interface object.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     intf          - Interface object.
 * @param [out]    ptr_config    - The pointer of the interface configs.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_intf_cfg_get(const uint32 unit,
                            const clx_port_t intf,
                            clx_port_intf_cfg_t *ptr_config);

/**
 * @brief This API is used to set destination index.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port.
 * @param [in]    di      - Destination index.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_di_set(const uint32 unit, const uint32 port, const uint32 di);

/**
 * @brief Get capacity of port-related resource.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     type        - Resource type.
 * @param [in]     param       - Parameter if necessary.
 * @param [out]    ptr_size    - Size of capacity.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_capacity_get(const uint32 unit,
                            const clx_swc_rsrc_t type,
                            const uint32 param,
                            uint32 *ptr_size);

/**
 * @brief Get usage of port-related resource.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     type       - Resource type.
 * @param [in]     param      - Parameter if necessary.
 * @param [out]    ptr_cnt    - Count of usage.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_usage_get(const uint32 unit,
                         const clx_swc_rsrc_t type,
                         const uint32 param,
                         uint32 *ptr_cnt);

/**
 * @brief This API is used to update the init portlist for port reset command.
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     lane_cnt             - Lane count.
 * @param [in]     speed                - Speed.
 * @param [in]     ptr_portlist         - Port list.
 * @param [in]     ptr_init_portlist    - Initial port list.
 * @param [out]    init_port_cnt        - Initial port count.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_nb_port_reset_portlist_update(const uint32 unit,
                                     const uint32 lane_cnt,
                                     const clx_port_speed_t speed,
                                     clx_port_bitmap_t *ptr_portlist,
                                     clx_port_bitmap_t *ptr_init_portlist,
                                     uint32 *init_port_cnt);

/**
 * @brief Get nvo3_encap_idx from l3t_port/lsp_port/srv6_port.
 *
 * For cl8600.
 *
 * @param [in]     unit                  - Device unit number.
 * @param [in]     port                  -  L3t_port/lsp_port/srv6_port.
 * @param [in]     ptr_key               - Tunnel key for mc tunnel.
 * @param [out]    ptr_nvo3_encap_idx    - Index to RWO_SRAM_NVO3_ENCAP (all planes equal value).
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameter.
 */
clx_error_no_t
hal_mt_nb_port_port_encap_idx_get(const uint32 unit,
                                  const clx_port_t port,
                                  const clx_tnl_info_t *ptr_key,
                                  uint32 *ptr_nvo3_encap_idx);

/**
 * @brief Get l3t_port/lsp_port/srv6_port from nvo3_encap_idx.
 *
 * For cl8600.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     nvo3_encap_idx    - Index of RWO_SRAM_NVO3_ENCAP.
 * @param [out]    ptr_port          - L3t_port/lsp_port/srv6_port.
 * @param [out]    ptr_key           - Tunnel key for mc tunnel.
 * @param [out]    ptr_use_port      - Indicate output ptr_port or ptr_key.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameter.
 */
clx_error_no_t
hal_mt_nb_port_encap_idx_port_get(const uint32 unit,
                                  const uint32 nvo3_encap_idx,
                                  clx_port_t *ptr_port,
                                  clx_tnl_info_t *ptr_key,
                                  boolean *ptr_use_port);

/*
 * @brief Process SyncE for a specific port.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     port               - Physical port id.
 * @param [in]     link_status        - Link status.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_synce_process(const uint32 unit, const uint32 port, const uint32 link_status);

/**
 * @brief Deinit lane swap. Called in port deinit.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_nb_port_laneswap_deinit(uint32 unit);

/**
 * @brief This API is used to get signal OK.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - Physical port.
 * @param [out]    ptr_signal_ok    - Signal OK value.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_signal_get(const uint32 unit, const uint32 port, uint32 *ptr_signal_ok);

/**
 * @brief This API is used to bind interface obj and bridge domain.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    ptr_bind_info    - Interface object binding bridge domain information.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_ENTRY_EXISTS       - Entry already exists.
 * @return        CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
hal_mt_nb_port_intf_obj_bd_bind(const uint32 unit,
                                const clx_port_intf_obj_bd_bind_t *ptr_bind_info);

/**
 * @brief This API is used to unbind interface obj and bridge domain.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    ptr_bind_info    - Interface object binding bridge domain information.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_ENTRY_EXISTS       - Entry already exists.
 * @return        CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
hal_mt_nb_port_intf_obj_bd_unbind(const uint32 unit,
                                  const clx_port_intf_obj_bd_bind_t *ptr_bind_info);

/**
 * @brief This API is used to get port interface obj bound bridge domain.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     ptr_bind_info    - Interface object bound bridge domain key.
 * @param [out]    ptr_bind_info    - Interface object bound bridge domain.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_ENTRY_EXISTS       - Entry already exists.
 * @return         CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
hal_mt_nb_port_intf_obj_bd_get(const uint32 unit, clx_port_intf_obj_bd_bind_t *ptr_bind_info);

/**
 * @brief Add interface obj egress vlan action.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_act_info    - Interface obj VLAN action information.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_SUPPORT      - Not support.
 */
clx_error_no_t
hal_mt_nb_port_intf_obj_vlan_act_add(const uint32 unit,
                                     const clx_port_intf_obj_vlan_act_t *ptr_act_info);

/**
 * @brief Delete interface obj egress vlan action.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_act_info    - Interface obj VLAN action information.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
hal_mt_nb_port_intf_obj_vlan_act_del(const uint32 unit,
                                     const clx_port_intf_obj_vlan_act_t *ptr_act_info);

/**
 * @brief Delete interface obj egress vlan action.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_act_info    - Interface obj VLAN action information.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
hal_mt_nb_port_intf_obj_vlan_act_update(const uint32 unit,
                                        const clx_port_intf_obj_vlan_act_t *ptr_act_info);

/**
 * @brief Get interface obj egress vlan action.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_act_info    - Interface obj VLAN action information.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
hal_mt_nb_port_intf_obj_vlan_act_get(const uint32 unit, clx_port_intf_obj_vlan_act_t *ptr_act_info);

/**
 * @brief Set skip rx crc check mask.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    plane       - Plane number.
 * @param [in]    macro_id    - Macro id.
 * @param [in]    mask_en     - Disable/Enable error mask.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_skip_rx_crc_check_set(const uint32 unit,
                                     const uint32 plane,
                                     const uint32 macro_id,
                                     const uint32 mask_en);

/**
 * @brief Get skip rx crc check mask.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     plane          - Plane number.
 * @param [in]     macro_id       - Macro id.
 * @param [out]    ptr_mask_en    - Skip rx crc check mask.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_skip_rx_crc_check_get(const uint32 unit,
                                     const uint32 plane,
                                     const uint32 macro_id,
                                     uint32 *ptr_mask_en);

#endif /* #ifndef HAL_MT_NB_PORT_H */
