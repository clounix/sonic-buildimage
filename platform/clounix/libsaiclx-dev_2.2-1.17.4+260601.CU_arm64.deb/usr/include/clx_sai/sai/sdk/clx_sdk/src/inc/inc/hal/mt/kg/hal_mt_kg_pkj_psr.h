/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_pkj_psr.h
 * PURPOSE:
 *     It provides packet journal parser trigger APIs for kawagarbo.
 *
 * NOTES:
 *
 */
#ifndef HAL_MT_KG_PKJ_PSR_H
#define HAL_MT_KG_PKJ_PSR_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <hal/hal_pkj.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MT_KG_PKJ_PSR_MAX_TCAM       (24)
#define HAL_MT_KG_PKJ_PSR_MAX_SLC        (2)
#define HAL_MT_KG_PKJ_PSR_MAX_HASH_STATE (10)
#define HAL_MT_KG_PKJ_PSR_MAX_HASH_TILE  (2)

#define HAL_MT_KG_PKJ_PSR_SW_K_FPU_HSH_POLICY_0_ID (0xffff)
#define HAL_MT_KG_PKJ_PSR_SW_K_FPU_HSH_POLICY_1_ID (0xfffe)

/*
 * Usage: pkj egress filter clx dmac address to hardware mac address.
 * Example is as below.
 *  clx_mac_t clx_mac = {0x11, 0x22, 0x33, 0x44, 0x55, 0x66};
 *  uint32    hw_mac[2];
 *
 *  After HAL_MT_KG_PKJ_PSR_EGR_FILTER_DMAC_CLX_TO_HW(clx_mac, hw_mac),
 *  hw_mac[0] = 0x11223344;
 *  hw_mac[1] = 0x5566;
 */
#define HAL_MT_KG_PKJ_PSR_EGR_FILTER_DMAC_CLX_TO_HW(__clx_mac__, __hw_mac__)                  \
    do {                                                                                      \
        hw_mac[0] = (__clx_mac__[0] << 24) | (__clx_mac__[1] << 16) | (__clx_mac__[2] << 8) | \
            __clx_mac__[3];                                                                   \
        hw_mac[1] = (__clx_mac__[4] << 8) | __clx_mac__[5];                                   \
    } while (0)

/*
 * Usage: pkj egress filter hardware dmac address to clx mac address.
 * Example is as below.
 *  clx_mac_t clx_mac;
 *  uint32    hw_mac[2] = {0x11223344, 0x5566};
 *
 *  After HAL_MT_KG_PKJ_PSR_EGR_FILTER_DMAC_HW_TO_CLX(hw_mac, clx_mac),
 *  clx_mac = {0x11, 0x22, 0x33, 0x44, 0x55, 0x66};
 */
#define HAL_MT_KG_PKJ_PSR_EGR_FILTER_DMAC_HW_TO_CLX(__hw_mac__, __clx_mac__) \
    do {                                                                     \
        __clx_mac__[0] = (__hw_mac__[0] >> 24) & 0xFF;                       \
        __clx_mac__[1] = (__hw_mac__[0] >> 16) & 0xFF;                       \
        __clx_mac__[2] = (__hw_mac__[0] >> 8) & 0xFF;                        \
        __clx_mac__[3] = __hw_mac__[0] & 0xFF;                               \
        __clx_mac__[4] = (__hw_mac__[1] >> 8) & 0xFF;                        \
        __clx_mac__[5] = __hw_mac__[1] & 0xFF;                               \
    } while (0)

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_mt_kg_pkj_psr_key_egr_filter_mac_field_e {
    HAL_MT_KG_PKJ_KEY_EGR_FILTER_DMAC_MSK_0_FIELD_ID,
    HAL_MT_KG_PKJ_KEY_EGR_FILTER_DMAC_MSK_1_FIELD_ID,
    HAL_MT_KG_PKJ_KEY_EGR_FILTER_SMAC_MSK_0_FIELD_ID,
    HAL_MT_KG_PKJ_KEY_EGR_FILTER_SMAC_MSK_1_FIELD_ID,
    HAL_MT_KG_PKJ_KEY_EGR_FILTER_DMAC_VAL_0_FIELD_ID,
    HAL_MT_KG_PKJ_KEY_EGR_FILTER_DMAC_VAL_1_FIELD_ID,
    HAL_MT_KG_PKJ_KEY_EGR_FILTER_SMAC_VAL_0_FIELD_ID,
    HAL_MT_KG_PKJ_KEY_EGR_FILTER_SMAC_VAL_1_FIELD_ID,
    HAL_MT_KG_PKJ_KEY_EGR_FILTER_MAC_LAST_FIELD_ID
} hal_mt_kg_pkj_psr_key_egr_filter_mac_field_t;

/* GLOBAL VARIABLE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM DECLARATIONS
 */
clx_error_no_t
hal_mt_kg_pkj_psr_init(const uint32 unit);

clx_error_no_t
hal_mt_kg_pkj_psr_deinit(const uint32 unit);

clx_error_no_t
hal_mt_kg_pkj_psr_property_set(const uint32 unit,
                               const hal_pkj_property_t property,
                               const uint32 value);

clx_error_no_t
hal_mt_kg_pkj_psr_property_get(const uint32 unit,
                               const hal_pkj_property_t property,
                               uint32 *ptr_value);

clx_error_no_t
hal_mt_kg_pkj_psr_trigger_key_set(const uint32 unit,
                                  const uint32 flags,
                                  const hal_pkj_trig_key_t *ptr_trig_key);

clx_error_no_t
hal_mt_kg_pkj_psr_trigger_key_get(const uint32 unit, hal_pkj_trig_key_t *ptr_trig_key);

clx_error_no_t
hal_mt_kg_pkj_psr_tm_capture_sel_set(const uint32 unit, const hal_pkj_tm_capture_sel_t *ptr_tm_sel);

clx_error_no_t
hal_mt_kg_pkj_psr_tm_capture_sel_get(const uint32 unit, hal_pkj_tm_capture_sel_t *ptr_tm_sel);

clx_error_no_t
hal_mt_kg_pkj_psr_fpu_tcam_cb_id_get(const uint32 unit, const uint32 tcam_id, uint32 *ptr_cbid);

clx_error_no_t
hal_mt_kg_pkj_psr_fpu_hash_cb_id_get(const uint32 unit,
                                     const uint32 stage_id,
                                     const uint32 tile_id,
                                     uint32 *ptr_cbid);
#endif /* End of hal_mt_kg_PKJ_PSR_H */