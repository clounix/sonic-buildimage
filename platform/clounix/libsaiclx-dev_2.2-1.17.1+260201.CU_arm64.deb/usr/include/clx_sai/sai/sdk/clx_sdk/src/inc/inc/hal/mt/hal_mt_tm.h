/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_tm.h
 * PURPOSE: It provides Traffic Management Hardware Abstraction Layer for MT chip.
 * NOTES:
 *
 */

#ifndef HAL_MT_TM_H
#define HAL_MT_TM_H

#include <hal/hal.h>

/*****************************************************************************
 * NAMING CONSTANT DECLARATIONS
 *****************************************************************************
 */
#define HAL_MT_TM_TC_NUM (8)
/* The number of ingress queue buf prof */
#define HAL_MT_TM_BUF_IGR_QUEUE_PROF_NUM (16)
/* The number of egress queue buf prof */
#define HAL_MT_TM_BUF_EGR_QUEUE_PROF_NUM (16)
/* egress pool number */
#define HAL_MT_TM_BUF_POOL_NUM (4)
/* The number of cpu queue */
#define HAL_MT_TM_CPU_QUEUE_NUM (48)
/* The number of unicast queue */
#define HAL_MT_TM_UNICAST_QUEUE_NUM (8)
/* The number of multicast queue */
#define HAL_MT_TM_MULTICAST_QUEUE_NUM (4)
/* The number of HQOS queue */
#define HAL_MT_TM_HQOS_QUEUE_NUM (16)
/* The invalid index of buf prof */
#define HAL_MT_TM_BUF_PROF_INVALID_INDEX (0xFFFFFFFF)

/* The calculation method of table OQ_COUNTER_MEM index and offset */
#define HAL_MT_NB_TM_BUF_OQ_COUNTER_MEM_INDEX(oq_index)  (oq_index) >> 3
#define HAL_MT_NB_TM_BUF_OQ_COUNTER_MEM_OFFSET(oq_index) ((oq_index) & 0x7)

typedef struct hal_mt_tm_buf_prof_entry_s {
    boolean is_valid; /* The prof is valid or not */
    uint32 ref_cnt;   /* The prof reference counter */
} hal_mt_tm_buf_prof_entry_t;

typedef struct hal_mt_tm_buf_port_cfg_s {
    uint32 igr_queue_prof_id[HAL_MT_TM_TC_NUM];
    uint32 igr_queue_hw_prof_id[HAL_MT_TM_TC_NUM];
    uint32 *egr_uc_queue_td_prof_id;
    uint32 *egr_uc_queue_wred_prof_id;
    uint32 *egr_uc_queue_hw_prof_id;
    uint32 egr_mc_queue_td_prof_id[HAL_TM_MULTICAST_QUEUE_NUM];
    uint32 egr_mc_queue_wred_prof_id[HAL_TM_MULTICAST_QUEUE_NUM];
    uint32 egr_mc_queue_hw_prof_id[HAL_TM_MULTICAST_QUEUE_NUM];
} hal_mt_tm_buf_port_cfg_t; /* Buf configure struct of port*/

typedef struct hal_mt_tm_egr_td_buf_s {
    clx_tm_buf_egr_prof_t prof;
} hal_mt_tm_egr_td_buf_t;

typedef struct hal_mt_tm_egr_wred_buf_s {
    clx_tm_wred_prof_t prof;
} hal_mt_tm_egr_wred_buf_t;

typedef struct hal_mt_tm_igr_buf_s {
    clx_tm_buf_igr_prof_t prof;
} hal_mt_tm_igr_buf_t;

typedef struct hal_mt_tm_buf_cb_s {
    hal_mt_tm_buf_port_cfg_t port_buf_cfg[CLX_PORT_NUM];
    hal_mt_tm_buf_prof_entry_t igr_queue_prof[HAL_MT_TM_BUF_IGR_QUEUE_PROF_NUM];
    hal_mt_tm_buf_prof_entry_t igr_queue_hw_prof[HAL_MT_TM_BUF_IGR_QUEUE_PROF_NUM];
    hal_mt_tm_buf_prof_entry_t egr_queue_td_prof[HAL_MT_TM_BUF_EGR_QUEUE_PROF_NUM];
    hal_mt_tm_buf_prof_entry_t egr_queue_wred_prof[HAL_MT_TM_BUF_EGR_QUEUE_PROF_NUM];
    hal_mt_tm_buf_prof_entry_t egr_queue_hw_prof[HAL_MT_TM_BUF_EGR_QUEUE_PROF_NUM];
    hal_mt_tm_igr_buf_t sq_prof[HAL_MT_TM_BUF_IGR_QUEUE_PROF_NUM];
    hal_mt_tm_egr_td_buf_t oq_td_prof[HAL_MT_TM_BUF_EGR_QUEUE_PROF_NUM];
    hal_mt_tm_egr_wred_buf_t oq_wred_prof[HAL_MT_TM_BUF_EGR_QUEUE_PROF_NUM];
} hal_mt_tm_buf_cb_t;

typedef struct hal_mt_tm_buf_egr_pool_th_s {
    uint32 min;    /* Minimum guarantee threshold */
    uint32 mid_th; /* Middle threshold for wred drop or ecn */
    uint32 max_th; /* Maximum threshold for wred drop or ecn */
} hal_mt_tm_buf_egr_pool_th_t;

/* buf prof data info */
extern hal_mt_tm_buf_cb_t _hal_mt_tm_buf_prof_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/* Macro definitions for accessing buf prof data */
#define HAL_MT_TM_BUF_PROF_CB_PTR(unit) &(_hal_mt_tm_buf_prof_cb[unit])

#define HAL_MT_TM_BUF_PORT_CFG_PTR(unit, port) &(_hal_mt_tm_buf_prof_cb[unit].port_buf_cfg[port])

#define HAL_MT_TM_BUF_SQ_PROF_PTR(unit, prof_id) \
    &(_hal_mt_tm_buf_prof_cb[unit].sq_prof[prof_id].prof)

#define HAL_MT_TM_BUF_OQ_TD_PROF_PTR(unit, prof_id) \
    &(_hal_mt_tm_buf_prof_cb[unit].oq_td_prof[prof_id].prof)

#define HAL_MT_TM_BUF_OQ_WRED_PROF_PTR(unit, prof_id) \
    &(_hal_mt_tm_buf_prof_cb[unit].oq_wred_prof[prof_id].prof)

#define HAL_MT_TM_PFC_WD_DETECT_TIMER_BY_FREQ(unit) (1000000 / HAL_DEVICE_FREQ(unit))
/*****************************************************************************
 * FUNCTION DECLARATIONS
 *****************************************************************************
 */
clx_error_no_t
hal_mt_tm_init(const uint32 unit);

clx_error_no_t
hal_mt_tm_deinit(const uint32 unit);

clx_error_no_t
hal_mt_tm_tc_prof_para_chk(const uint32 unit, const uint32 prof_id, const clx_tm_tc_prof_t *prof);

clx_error_no_t
hal_mt_tm_trunc_prof_param_chk(const hal_tm_trunc_prof_t *prof);

clx_error_no_t
hal_mt_tm_trunc_cfg_param_check(const uint32 unit,
                                const hal_tm_trunc_cfg_t *config,
                                const boolean is_set);

uint32
hal_mt_tm_value_from_cfg_get(const uint32 unit,
                             const uint32 cfg,
                             const uint32 param0,
                             const uint32 param1,
                             uint32 value);
#endif /* End of HAL_MT_TM_H */
