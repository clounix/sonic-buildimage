/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_UDF_H__)
#define __CLX_SAI_UDF_H__

/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_UDF_STAGE_IGR                    (1 << 0)
#define CLXS_UDF_STAGE_EGR                    (1 << 1)
#define CLXS_UDF_V4_TYPE                      (1 << 2)
#define CLXS_UDF_V6_TYPE                      (1 << 3)

#define CLXS_UDF_PROFILE_ID_FOR_IPV6_VXLAN_VNI             (58)
#define CLXS_UDF_PROFILE_ID_FOR_IPV4_VXLAN_VNI             (59)

#define CLXS_UDF_BTH_OFFSET                         (8)
#define CLXS_UDF_AETH_OFFSET                        (20)
#define CLXS_UDF_RD_AETH_OFFSET                     (28)
#define CLXS_UDF_ROCE_RESERVED_OFFSET               (16)
#define CLXS_UDF_IPV6_FLOW_LABEL_OFFSET             (1)
#define CLXS_UDF_ECN_OFFSET                         (1)
#define CLXS_UDF_TAM_INT_IFA2_PROTOCOL_OFFSET       (9)
#define CLXS_UDF_TAM_INT_IFA2_DEVICEID_OFFSET       (36)
#define CLXS_UDF_TUNNEL_VNI_OFFSET                  (8)

#define CLXS_UDF_ECN_3                              (0x3)
#define CLXS_UDF_ECN_MASK                           (0x3)
#define CLXS_UDF_ECN_3_IPV6                         (0x30)
#define CLXS_UDF_ECN_MASK_IPV6                      (0x30)

#define CLXS_UDF_TCP_PROFILE_PKT_CNT                (14)
#define CLXS_UDF_PROFILE_PKT_CNT_FOR_INT            (16)

#define CLXS_UDF_INFINI_BAND_LEN                    (14)
#define CLXS_UDF_RSVD_PROFILE_NUM                   (16)

#define CLXS_UDF_PROFILE_BMP_WORDS(__unit__)     CLX_BITMAP_SIZE(CLXS_UDF_PROFILE_NUM(__unit__))

#define CLXS_UDF_PROF_BMP_FOREACH(_unit_,_udf_prof_bmp_, _prof_idx_)                                              \
    for ((_prof_idx_) = 0; (_prof_idx_) < CLXS_UDF_PROFILE_NUM(_unit_); (_prof_idx_)++)                           \
    if (UTIL_LIB_BMP_BIT_CHK((_udf_prof_bmp_), (_prof_idx_)))

#define CLXS_UDF_CUSTOM_RANGE       (0x30)
#define CLXS_SINGLE_UDF_PKG_NUM     ((CLX_CIA_PKG_NUM) / 2)

#define CLXS_UDF_GROUP_MAX_NUM       (6)

#define UDF_ENTRY_DB(_unit_,_db_idx_)      _clxs_udf_db[_unit_]->entry[_db_idx_]
#define UDF_GROUP_DB(_unit_,_db_idx_)      _clxs_udf_db[_unit_]->group[_db_idx_]
#define UDF_MATCH_DB(_unit_,_db_idx_)      _clxs_udf_db[_unit_]->match[_db_idx_]

/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/

 typedef struct clxs_udf_match_entry_s
 {
     bool valid;
     uint32_t idx;
 } clxs_udf_match_entry_t;

typedef struct clxs_udf_entry_info_s
{
    uint32_t base;
    uint32_t offset;
    uint32_t match_index;
    uint32_t group_index;
    sai_object_id_t object_id;
    bool valid;
} clxs_udf_entry_info_t;

typedef struct clxs_udf_match_l2_s
{
    bool     is_valid;
    uint16_t data;
} clxs_udf_match_l2_t;

typedef struct clxs_udf_match_l3_s
{
    bool     is_valid;
    uint8_t  data;
} clxs_udf_match_l3_t;

typedef struct clxs_udf_match_l4_s
{
    bool     is_valid;
    uint16_t data;
} clxs_udf_match_l4_t;

typedef struct clxs_udf_match_pkg_info_s
{
    uint32_t igr_base_index;     /*The index of the first available TLV in the ing udf prof*/
    uint32_t igr_index_bitmap;
    uint32_t egr_base_index;     /*The index of the first available TLV in the egr udf prof*/
    uint32_t egr_index_bitmap;
} clxs_udf_match_pkg_info_t;

typedef struct clxs_udf_match_info_s
{
    uint32_t ref_cnt;
    clxs_udf_match_l2_t l2_type;
    clxs_udf_match_l3_t l3_type;
    clxs_udf_match_l4_t l4_type;
    uint8_t priority;
    sai_object_id_t object_id;
    clxs_udf_match_pkg_info_t pkg_info;
    bool valid;
} clxs_udf_match_info_t;

typedef enum
 {
     CLXS_UDF_TYPE_START = 0,
     CLXS_UDF_TYPE_L4_UDF_ROCE = CLXS_UDF_TYPE_START,
     CLXS_UDF_TYPE_BTH_OPCODE,
     CLXS_UDF_TYPE_AETH_SYNDROME,
     CLXS_UDF_TYPE_BTH_RESERVED,
     CLXS_UDF_TYPE_RD_AETH_SYNDROME,
     CLXS_UDF_TYPE_IPV6_FLOW_LABEL,
     CLXS_UDF_TYPE_ECN_MARK_STATS,
     CLXS_UDF_TYPE_IPV6_ECN_MARK_STATS,
     CLXS_UDF_TYPE_TAM_INT_IFA2_COUNT,
     CLXS_UDF_TYPE_TAM_INT_IFA2_REWRITE_PKT,
     CLXS_UDF_TYPE_LAST,
     CLXS_UDF_TYPE_CUSTOM_START,    /*for user udf*/
     CLXS_UDF_TYPE_CUSTOM_END = CLXS_UDF_TYPE_CUSTOM_START + CLXS_UDF_CUSTOM_RANGE
 } clxs_udf_type_t;

 typedef enum
 {
    CLXS_UDF_PKG_INDEX_TYPE_START = 0,
    CLXS_UDF_INDEX_TYPE_IGR_V4 = CLXS_UDF_PKG_INDEX_TYPE_START,
    CLXS_UDF_INDEX_TYPE_EGR_V4,
    CLXS_UDF_INDEX_TYPE_IGR_V6,
    CLXS_UDF_INDEX_TYPE_EGR_V6,
    CLXS_UDF_INDEX_TYPE_ING_USER,
    CLXS_UDF_INDEX_TYPE_EGR_USER,
    CLXS_UDF_INDEX_TYPE_LAST
 } clxs_udf_pkg_index_type_t;

 typedef struct clxs_udf_pkg_info_s
 {
     clx_cia_pkg_base_t type;
     uint32_t offset;
     uint32_t msk;
     uint32_t flags;     /*o or CLX_CIA_PKG_FLAGS_CONSECUTIVE_BYTE*/
 } clxs_udf_pkg_info_t;

 typedef struct clxs_udf_prof_s
 {
     bool valid;
     clxs_udf_type_t type;
     uint32_t flags;     /*CLXS_ACL_STAGE_IGR, CLXS_ACL_STAGE_EGR, CLXS_ACL_V4_TYPE, CLXS_ACL_V6_TYPE*/
     clxs_udf_pkg_info_t pkg_info[CLX_CIA_PKG_NUM];
     uint32_t pkg_index[CLXS_UDF_INDEX_TYPE_LAST];
 } clxs_udf_prof_t;

 typedef struct clxs_udf_group_info_s
{
    uint32_t type;
    uint32_t length;
    uint32_t ref_cnt;
    uint32_t count;
    sai_object_id_t object_id;
    clxs_udf_prof_t *prof_info;
    bool valid;
} clxs_udf_group_info_t;

typedef struct clxs_udf_db_s
{
    clxs_udf_group_info_t  *group[CLXS_UDF_GROUP_MAX_NUM];
    clxs_udf_entry_info_t  *entry;
    clxs_udf_match_info_t  *match;
    uint32_t               *udf_prof_bmp;
} clxs_udf_db_t;

/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_udf_api_t         udf_api;
extern clxs_udf_db_t*              _clxs_udf_db[CLXS_MAX_CHIP_NUM];
extern clxs_udf_prof_t             _clxs_udf_rsvd_cfg_info[CLXS_UDF_TYPE_LAST];

/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t clxs_udf_group_get_match_list(
    _In_ sai_object_id_t    udf_group_id,
    _Out_ uint32_t          *ptr_count,
    _Out_ clxs_udf_match_info_t *ptr_match_list);

sai_status_t clxs_udf_get_entry_list(
    _In_ sai_object_id_t    udf_group_id,
    _In_ sai_object_id_t    udf_match_id,
    _Out_ uint32_t          *ptr_count,
    _Out_ uint32_t          *ptr_list);

sai_status_t clxs_udf_init(_In_ uint32_t unit);

sai_status_t clxs_udf_deinit(_In_ uint32_t unit);

sai_status_t clxs_udf_get_group_obj(
    _In_ uint32_t         unit,
    _In_ uint32_t         udf_group_id,
    _Out_ sai_object_id_t *ptr_udf_group_id);

sai_status_t clxs_udf_get_match_id(
    _In_ sai_object_id_t    udf_match_obj,
    _Out_ uint32_t          *ptr_match_id);

sai_status_t clxs_udf_get_db_size(
    _In_ uint32_t           unit,
    _In_ sai_object_type_t  udf_type,
    _Out_ uint32_t         *size);

sai_status_t clxs_udf_get_db_count(
    _In_ uint32_t unit, _In_ sai_object_type_t udf_type,
    _Out_ uint32_t *count);

bool clxs_udf_is_db_created(
    _In_ uint32_t unit,
    _In_ uint32_t index,
    _In_ sai_object_type_t udf_type);

sai_status_t clxs_udf_get_udf_pkg_index(
    _In_ uint32_t           unit,
    _In_ sai_acl_stage_t    stage,
    _In_ sai_object_id_t    udf_group_id,
    _In_ sai_object_id_t    udf_match_id,
    _Out_ uint32_t          *ptr_pkg_index);

sai_status_t
clxs_udf_get_rsvd_udf_pkg_index(
    _In_ const uint32_t    unit,
    _In_ const clxs_udf_type_t udf_type,
    _In_ const sai_acl_stage_t    stage,
    _In_ const bool is_v6,
    _Out_ uint32_t    *ptr_index);

uint32_t
clxs_udf_get_rsvd_ip_prof_id(
    _In_ const uint32_t    unit,
    _In_ const bool is_v6);

sai_status_t
clxs_udf_create_udf_for_tunnel_vni(
    _In_ const uint32_t    unit);

sai_status_t
clxs_udf_update_udf_exact_config(
    _In_ const uint32_t unit,
    _In_ const clx_cia_pkg_cfg_t *exact_pkg_cfg,
    _In_ const uint32_t exact_pkg_cnt,
    _In_ const bool is_v6,
    _In_ const bool is_create);
#endif /* __CLX_SAI_UDF_H__ */
