/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_cia.h
 * PURPOSE:
 *      Define the declaration for CIA module in CLX SDK.
 *
 * NOTES:
 */

#ifndef CLX_CIA_H
#define CLX_CIA_H

#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>
#include <clx/clx_pkt.h>
#include <clx/clx_swc.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define CLX_CIA_PKG_NUM       (48) /* Maximum CIA PKG key byte number for CIA */
#define CLX_CIA_EXACT_PKG_NUM (31) /* Maximum CIA PKG key byte number for hash */
#define CLX_CIA_RANGE_NUM     (16) /* Maximum range number  */
#define CLX_CIA_FCM_NUM       (9)  /* Maximum FCM fcm profile number */
#define CLX_CIA_FCM_DATA_NUM  (16) /* Maximum FCM fcm byte number */
#define CLX_CIA_EXACT_WORDS   (5)  /* Maximum exact word number */
#define CLX_CIA_UNION_NUM     (8)  /* Maximum union number */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef enum clx_cia_stage_e {
    CLX_CIA_STAGE_IGR_EXACT = 0, /* stage ingress exact */
    CLX_CIA_STAGE_IGR,           /* stage ingress */
    CLX_CIA_STAGE_IGR_POST,      /* stage ingress post [CLX86 only]*/
    CLX_CIA_STAGE_EGR,           /* stage egress */
    CLX_CIA_STAGE_EGR_POST,      /* stage egress post [CLX86 only]*/
    CLX_CIA_STAGE_IGR_PRE,       /* stage ingress pre [CLX84 only]*/
    CLX_CIA_STAGE_LAST
} clx_cia_stage_t;

typedef enum clx_cia_select_cfg_type_e {
    CLX_CIA_SELECT_CFG_TYPE_PRE_IGR,   /* type pre-ingress */
    CLX_CIA_SELECT_CFG_TYPE_IGR,       /* type ingress */
    CLX_CIA_SELECT_CFG_TYPE_EGR,       /* type egress */
    CLX_CIA_SELECT_CFG_TYPE_IGR_EXACT, /* type ingress exact */
    CLX_CIA_SELECT_CFG_TYPE_LAST
} clx_cia_select_cfg_type_t;

typedef enum clx_cia_l2_frm_e {
    CLX_CIA_L2_FRM_ETHERNET = 0, /* Ethernet frame */
    CLX_CIA_L2_FRM_RFC1042,      /* RFC1042 */
    CLX_CIA_L2_FRM_LLC_OTHER,    /* L2 has LLC header but not SNAP */
    CLX_CIA_L2_FRM_LAST
} clx_cia_l2_frm_t;

typedef enum clx_cia_tnl_e {
    CLX_CIA_TNL_IPV4 = 0, /* IPv4 tunnel type */
    CLX_CIA_TNL_MPLS,     /* MPLS tunnel type */
    CLX_CIA_TNL_IPV6,     /* IPv6 tunnel type */
    CLX_CIA_TNL_IP_RAW,   /* IP raw tunnel type */
    CLX_CIA_TNL_VXLAN,    /* VXLAN tunnel type [CLX84 only]*/
    CLX_CIA_TNL_GENEVE,   /* GENEVE tunnel type [CLX84 only]*/
    CLX_CIA_TNL_GTPU,     /* GTPU tunnel type [CLX84 only]*/
    CLX_CIA_TNL_GRE,      /* GRE tunnel type [CLX84 only]*/
    CLX_CIA_TNL_FLEX,     /* Flex tunnel type [CLX84 only]*/
    CLX_CIA_TNL_UNKNOWN,  /* Unknown tunnel type */
    CLX_CIA_TNL_LAST
} clx_cia_tnl_t;

typedef enum clx_cia_vm_type_e {
    CLX_CIA_VM_TYPE_NA = 0,    /* not a vm type */
    CLX_CIA_VM_TYPE_ETAG = 1,  /* etag */
    CLX_CIA_VM_TYPE_VNTAG = 2, /* vntag */
    CLX_CIA_VM_TYPE_LAST
} clx_cia_vm_type_t;

typedef enum clx_cia_frg_e {
    CLX_CIA_FRG_NONE = 0, /* None fragment packet */
    CLX_CIA_FRG_FIRST,    /* First fragment packet, fragment offset field is zero */
    CLX_CIA_FRG_MIDDLE,   /* Middle fragment packet, fragment offset and more fragments flag fields
                             are not zero [not support CLX84] */
    CLX_CIA_FRG_END,      /* Final fragment packet, more fragments flag is 0 in the flags field,[not
                             support CLX84] */
    CLX_CIA_FRG_FIRST_NONE, /* First fragment packet and None fragment packet, fragment offset is
                               zero [not support CLX84] */
    CLX_CIA_FRG_MIDDLE_END, /* Middle fragment and final fragment packet, also not first fragment
                               packet, fragment offset is not zero */
    CLX_CIA_FRG_ALL,        /* All fragment packet [CLX84 only] */
    CLX_CIA_FRG_LAST
} clx_cia_frg_t;

typedef enum clx_cia_ttl_e {
    CLX_CIA_TTL_ZERO = 0, /* TTL is 0 */
    CLX_CIA_TTL_ONE,      /* TTL is 1 */
    CLX_CIA_TTL_GT_ONE,   /* TTL is grater than 1 */
    CLX_CIA_TTL_LAST
} clx_cia_ttl_t;

typedef enum clx_cia_arp_frm_type_e {
    CLX_CIA_ARP_FRM_TYPE_REQUEST = 0, /* ARP frame type is ARP request */
    CLX_CIA_ARP_FRM_TYPE_RESPONSE,    /* ARP frame type is ARP response */
    CLX_CIA_ARP_FRM_TYPE_LAST,
} clx_cia_arp_frm_type_t;

typedef enum clx_cia_pkt_vlan_type_e {
    CLX_CIA_PKT_VLAN_TYPE_NO_VLAN = 0,    /* no vlan tag packet */
    CLX_CIA_PKT_VLAN_TYPE_SINGLE_VLAN,    /* match svid in 1ad; match cvid in 1q
                                           * treat cvid as 1st vid if s_tpid is the same as c_tpid */
    CLX_CIA_PKT_VLAN_TYPE_DOUBLE_VLAN,    /* double vlan tag packet */
    CLX_CIA_PKT_VLAN_TYPE_TRIPLE_VLAN,    /* triple vlan tag packet */
    CLX_CIA_PKT_VLAN_TYPE_QUADRUPLE_VLAN, /* quadruple vlan tag packet */
    CLX_CIA_PKT_VLAN_TYPE_VLAN_LAST,
} clx_cia_pkt_vlan_type_t;

typedef enum clx_cia_src_idx_type_e {
    CLX_CIA_SRC_IDX_TYPE_RAW,   /* raw source index */
    CLX_CIA_SRC_IDX_TYPE_GPORT, /* gport source index */
    CLX_CIA_SRC_IDX_TYPE_LAST
} clx_cia_src_idx_type_t;

typedef struct clx_cia_src_idx_s {
    clx_cia_src_idx_type_t type; /* source index type */
    uint32 src_idx;              /* source index, valid when type is CLX_CIA_SRC_IDX_TYPE_RAW */
    clx_port_t gport;            /* gport, valid when type is CLX_CIA_SRC_IDX_TYPE_GPORT */
} clx_cia_src_idx_t;

typedef enum clx_cia_dst_idx_type_e {
    CLX_CIA_DST_IDX_TYPE_RAW,   /* raw destination index */
    CLX_CIA_DST_IDX_TYPE_GPORT, /* gport destination index, unicast only */
    CLX_CIA_DST_IDX_TYPE_L2_MC, /* l2 multicast destination index */
    CLX_CIA_DST_IDX_TYPE_L3_MC, /* l3 multicast destination index */
    CLX_CIA_DST_IDX_TYPE_LAST
} clx_cia_dst_idx_type_t;

typedef struct clx_cia_dst_idx_s {
    clx_cia_dst_idx_type_t type; /* destination index type */
    uint32 dst_idx;     /* destination index, valid when type is CLX_CIA_DST_IDX_TYPE_RAW */
    clx_port_t gport;   /* gport, valid when type is CLX_CIA_DST_IDX_TYPE_GPORT */
    uint32 l2_mcast_id; /* l2 multicast id, valid when type is CLX_CIA_DST_IDX_TYPE_L2_MC */
    uint32 l3_mcast_id; /* l3 multicast id, valid when type is CLX_CIA_DST_IDX_TYPE_L3_MC */
} clx_cia_dst_idx_t;

typedef enum clx_cia_rim_alloc_e {
    CLX_CIA_RIM_ALLOC_FCM = 0,            /* frame content modify */
    CLX_CIA_RIM_ALLOC_REDIR_TYPE_L2_UC,   /* redirect l2_uc */
    CLX_CIA_RIM_ALLOC_REDIR_TYPE_L2_ECMP, /* redirect l2_ecmp */
    CLX_CIA_RIM_ALLOC_REDIR_TYPE_L3_UC,   /* redirect l3_uc */
    CLX_CIA_RIM_ALLOC_REDIR_TYPE_L3_ECMP, /* redirect l3_ecmp */
    CLX_CIA_RIM_ALLOC_REDIR_TYPE_L2_MC,   /* redirect l2_mc */
    CLX_CIA_RIM_ALLOC_REDIR_TYPE_L3_MC,   /* redirect l3_mc */
    CLX_CIA_RIM_ALLOC_REDIR_TYPE_L3_MPLS, /* redirect L3 mpls */
    CLX_CIA_RIM_ALLOC_NFS,                /* nfs [CLX84 only]*/
    CLX_CIA_RIM_ALLOC_LAST
} clx_cia_rim_alloc_t;

typedef enum clx_cia_ipv6_opt_hdr_type_e {
    CLX_CIA_IPV6_OPT_HDR_TYPE_NONE = 0,
    CLX_CIA_IPV6_OPT_HDR_TYPE_AUTH,       /* Authentication header */
    CLX_CIA_IPV6_OPT_HDR_TYPE_HOP_BY_HOP, /* Hop-by-hop header */
    CLX_CIA_IPV6_OPT_HDR_TYPE_FRAG,       /* Fragment header */
    CLX_CIA_IPV6_OPT_HDR_TYPE_RTE,        /* Routing header */
    CLX_CIA_IPV6_OPT_HDR_TYPE_EXT_0,      /* Extension header 0 */
    CLX_CIA_IPV6_OPT_HDR_TYPE_EXT_1,      /* Extension header 1 */
    CLX_CIA_IPV6_OPT_HDR_TYPE_EXT_2,      /* Extension header 2 */
    CLX_CIA_IPV6_OPT_HDR_TYPE_EXT_3,      /* Extension header 3 */
    CLX_CIA_IPV6_OPT_HDR_TYPE_LAST,
} clx_cia_ipv6_opt_hdr_type_t;

typedef enum clx_cia_cfg_l3_proto_type_e {
    CLX_CIA_CFG_L3_PROTO_TYPE_ALL = 0,
    CLX_CIA_CFG_L3_PROTO_TYPE_IPV6_HOPOPT, /* Hop-by-hop option header */
    CLX_CIA_CFG_L3_PROTO_TYPE_IPV6_RTE,    /* Routing header */
    CLX_CIA_CFG_L3_PROTO_TYPE_IPV6_FRG,    /* Fragment header */
    CLX_CIA_CFG_L3_PROTO_TYPE_AH,          /* AH header */
    CLX_CIA_CFG_L3_PROTO_TYPE_IFA,         /* IFA header */
    CLX_CIA_CFG_L3_PROTO_TYPE_IOAM,        /* IOAM header */
    CLX_CIA_CFG_L3_PROTO_TYPE_LAST
} clx_cia_cfg_l3_proto_type_t;

typedef enum clx_cia_select_key_prof_key_e {
    CLX_CIA_SELECT_KEY_PROF_KEY_MAC_KEY_VLD_START = 0,
    CLX_CIA_SELECT_KEY_PROF_KEY_MAC_DST_MAC_VLD =
        CLX_CIA_SELECT_KEY_PROF_KEY_MAC_KEY_VLD_START, /* destination mac address valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MAC_SRC_MAC_VLD,       /* source mac address valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MAC_ETHER_TYPE_VLD,    /* ether type valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MAC_PKT_VLAN_TYPE_VLD, /* packet vlan type valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MAC_L2_SWAP_VLD,       /* l2 swap valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MAC_L2_IS_BC,          /* l2 is broadcast valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MAC_PCP_DEI,           /* pcp dei valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MAC_OUTER_VLAN_TAG,    /* outer vlan tag valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MAC_INNER_VLAN_TAG,    /* inner vlan tag valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MAC_L2_FRAME_TYPE_VLD, /* l2 frame type valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MAC_VM_SEL_VLD,        /* vm tag valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MAC_SKIP0_SEL_VLD,     /* skip0 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MAC_SKIP1_SEL_VLD,     /* skip1 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MAC_KEY_VLD_LAST,
    CLX_CIA_SELECT_KEY_PROF_KEY_ARP_KEY_VLD_START = 64,
    CLX_CIA_SELECT_KEY_PROF_KEY_ARP_TPA_VLD =
        CLX_CIA_SELECT_KEY_PROF_KEY_ARP_KEY_VLD_START,  /* target ip address valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_ARP_SPA_VLD,            /* sender ip address valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_ARP_SHA_VLD,            /* sender hardware address valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_ARP_THA_VLD,            /* target hardware address valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_ARP_ARP_FRAME_TYPE_VLD, /* arp frame opcode valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_ARP_SHA_EQ_SA_VLD, /* sender hardware address equals smac valid flag
                                                    */
    CLX_CIA_SELECT_KEY_PROF_KEY_ARP_THA_EQ_DA_VLD, /* target hardware address equals dmac valid flag
                                                    */
    CLX_CIA_SELECT_KEY_PROF_KEY_ARP_REQ_VLD,       /* arp request valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_ARP_RES_VLD,       /* arp response valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_ARP_KEY_VLD_LAST,
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_KEY_VLD_START = 128,
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_SRC_IP_VLD =
        CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_KEY_VLD_START, /* ipv4 source ip address valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_DST_IP_VLD,        /* ipv4 destination ip address valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_L4_SRC_PORT_VLD,   /* ipv4 l4 source port valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_L4_DST_PORT_VLD,   /* ipv4 l4 destination port valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_PROTO_VLD,         /* ipv4 protocol valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_TTL_VLD,
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_TTL_TYPE_VLD,      /* ipv4 ttl type valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_TCP_FLAGS_VLD,     /* ipv4 tcp flags valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_ICMP_TYPE_VLD,     /* ipv4 icmp type valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_ICMP_CODE_VLD,     /* ipv4 icmp code valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_IGMP_TYPE_VLD,     /* ipv4 igmp type valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_FRG_TYPE_VLD,      /* ipv4 fragment type valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_L3_SWAP_VLD,       /* ipv4 l3 swap valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_L4_SWAP_VLD,       /* ipv4 l4 swap valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_AUTH_HDR_VLD,      /* ipv4 authentication header valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_OPT_HDR_VLD,       /* ipv4 option header valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_IP_RANGE_VLD,      /* ipv4 ip range valid flag [unused]*/
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV4_DSCP_ECN_VLD,      /* ipv4 dscp ecn valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_SRC_IP_VLD = 192,  /* ipv6 source ip address valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_SRC_IP_SEG0_VLD, /* ipv6 source ip address segment 0 valid flag
                                                       */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_SRC_IP_SEG1_VLD, /* ipv6 source ip address segment 1 valid flag
                                                       */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_SRC_IP_SEG2_VLD, /* ipv6 source ip address segment 2 valid flag
                                                       */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_SRC_IP_SEG3_VLD, /* ipv6 source ip address segment 3 valid flag
                                                       */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_DST_IP_VLD,      /* ipv6 destination ip address valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_DST_IP_SEG0_VLD, /* ipv6 destination ip address segment 0 valid
                                                         flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_DST_IP_SEG1_VLD, /* ipv6 destination ip address segment 1 valid
                                                         flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_DST_IP_SEG2_VLD, /* ipv6 destination ip address segment 2 valid
                                                         flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_DST_IP_SEG3_VLD, /* ipv6 destination ip address segment 3 valid
                                                         flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_PROTO_VLD,       /* ipv6 protocol valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_L4_SRC_PORT_VLD, /* ipv6 l4 source port valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_L4_DST_PORT_VLD, /* ipv6 l4 destination port valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_TCP_FLAGS_VLD,   /* ipv6 tcp flags valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_ICMP_TYPE_VLD,   /* ipv6 icmp type valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_ICMP_CODE_VLD,   /* ipv6 icmp code valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_IGMP_TYPE_VLD,   /* ipv6 igmp type valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_FRG_TYPE_VLD,    /* ipv6 fragment type valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_TTL_VLD,
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_TTL_TYPE_VLD,    /* ipv6 ttl type valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_L3_SWAP_VLD,     /* ipv6 l3 swap valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_L4_SWAP_VLD,     /* ipv6 l4 swap valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_FLOW_LABEL_VLD,  /* ipv6 flow label valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_TRAFFIC_CLASS_VLD, /* ipv6 traffic class valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_OPT0_HDR_VLD,      /* ipv6 option 0 header valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_OPT1_HDR_VLD,      /* ipv6 option 1 header valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_IPV6_KEY_VLD_LAST,
    CLX_CIA_SELECT_KEY_PROF_KEY_MPLS_KEY_VLD_START = 256,
    CLX_CIA_SELECT_KEY_PROF_KEY_MPLS_KEY_LABEL0_VLD =
        CLX_CIA_SELECT_KEY_PROF_KEY_MPLS_KEY_VLD_START, /* label 0 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MPLS_KEY_LABEL1_VLD,    /* label 1 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MPLS_KEY_LABEL2_VLD,    /* label 2 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MPLS_KEY_LABEL3_VLD,    /* label 3 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MPLS_KEY_TTL_TYPE_VLD,  /* mpls ttl type valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MPLS_KEY_LABEL_NUM_VLD, /* mpls label number valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MPLS_KEY_EXP_VLD,       /* mpls exp valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MPLS_KEY_TTL_VLD,       /* mpls ttl value flag*/
    CLX_CIA_SELECT_KEY_PROF_KEY_MPLS_KEY_LBL_BOS_VLD,   /* mpls bottom of stack detected flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_MPLS_KEY_NIBBLE_VLD,    /* mpls nibble value */
    CLX_CIA_SELECT_KEY_PROF_KEY_MPLS_KEY_VLD_LAST,
    CLX_CIA_SELECT_KEY_PROF_KEY_L3_OTHER_KEY_VLD_START = 320,
    CLX_CIA_SELECT_KEY_PROF_KEY_L3_OTHER_KEY_PLD0_VLD =
        CLX_CIA_SELECT_KEY_PROF_KEY_L3_OTHER_KEY_VLD_START, /* payload 0 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_L3_OTHER_KEY_PLD1_VLD,      /* payload 1 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_L3_OTHER_KEY_PLD2_VLD,      /* payload 2 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_L3_OTHER_KEY_PLD3_VLD,      /* payload 3 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_L3_OTHER_KEY_PLD4_VLD,      /* payload 4 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_L3_OTHER_KEY_PLD5_VLD,      /* payload 5 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_L3_OTHER_KEY_PLD6_VLD,      /* payload 6 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_L3_OTHER_KEY_PLD7_VLD,      /* payload 7 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_L3_OTHER_KEY_PLD8_VLD,      /* payload 8 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_L3_OTHER_KEY_PLD9_VLD,      /* payload 9 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_L3_OTHER_KEY_VLD_LAST,
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_KEY_VLD_START = 384,
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF0_VLD =
        CLX_CIA_SELECT_KEY_PROF_KEY_UDF_KEY_VLD_START, /* udf 0 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF1_VLD,          /* udf 1 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF2_VLD,          /* udf 2 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF3_VLD,          /* udf 3 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF4_VLD,          /* udf 4 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF5_VLD,          /* udf 5 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF6_VLD,          /* udf 6 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF7_VLD,          /* udf 7 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF8_VLD,          /* udf 8 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF9_VLD,          /* udf 9 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF10_VLD,         /* udf 10 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF11_VLD,         /* udf 11 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF12_VLD,         /* udf 12 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF13_VLD,         /* udf 13 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF14_VLD,         /* udf 14 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF15_VLD,         /* udf 15 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF16_VLD,         /* udf 16 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF17_VLD,         /* udf 17 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF18_VLD,         /* udf 18 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF19_VLD,         /* udf 19 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF20_VLD,         /* udf 20 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF21_VLD,         /* udf 21 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF22_VLD,         /* udf 22 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_UDF23_VLD,         /* udf 23 valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_TYPE,              /* udf type valid flag [unused] */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_INNER_IDX,         /* udf inner index valid flag  [unused]*/
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_OUTER_IDX,         /* udf outer index valid flag  [unused]*/
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_PKG_HIT_IDX_VLD,   /* udf package hit index valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_PKG0_HIT_IDX_VLD,  /* udf package 0 hit index valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_UDF_KEY_VLD_LAST,
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_VLD_START = 448,
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_INTF_GRP_LBL_VLD =
        CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_VLD_START, /* pp info interface group label valid flag
                                                        */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_ICIA_GRP_LBL_VLD, /* pp info icia group label valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_PRECIA_GRP_LBL_VLD, /* pp info pre cia group label valid
                                                               flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_L2_DA_GRP_LBL_VLD,  /* pp info l2 da group label valid flag
                                                             */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_L2_SA_GRP_LBL_VLD,  /* pp info l2 sa group label valid flag
                                                             */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_L3_SA_GRP_LBL_VLD,  /* pp info l3 sa group label valid flag
                                                             */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_L3_DA_GRP_LBL_VLD,  /* pp info l3 da group label valid flag
                                                             */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_BDID_VLD,           /* pp info bdid valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_VRFID_VLD,          /* pp info vrfid valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_VNI_VLD,            /* pp info vni valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_HIT_STATUS_VLD,     /* pp info hit status valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_PORT_VLD,           /* pp info port valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_SRC_IDX_VLD, /* pp info src index valid flag, ingress only
                                                      */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_DST_IDX_VLD, /* pp info dst index valid flag, egress only */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_PORT_GROUP_VLD,    /* pp info port group valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_PKT_TNL_TYPE_VLD,  /* pp info packet tnl type valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_L3_FRAME_TYPE_VLD, /* l3 frame type valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_L3_ROUTE_VLD, /* pp info l3 route valid flag [unused] */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_TNL_TERM_VLD, /* pp info tnl term valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_PBM_VLD,      /* pp info pbm valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_BD_LBL_VLD,   /* bridge domain label valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_PP_INFO_VLD_LAST,
    CLX_CIA_SELECT_KEY_PROF_KEY_QOS_VLD_START = 512,
    CLX_CIA_SELECT_KEY_PROF_KEY_QOS_TC_VLD = CLX_CIA_SELECT_KEY_PROF_KEY_QOS_VLD_START, /* tc color
                                                                                           valid
                                                                                           flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_QOS_COLOR_VLD, /* color valid flag, replaced with tc_vld [unused]*/
    CLX_CIA_SELECT_KEY_PROF_KEY_QOS_ECN_MARK_VLD, /* ecn mark valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_QOS_TNL_DSCP_VLD, /* tunnel dscp valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_QOS_LAST_VLD,     /* last valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_RANGE_VLD_START = 576,
    CLX_CIA_SELECT_KEY_PROF_KEY_RANGE_VLD =
        CLX_CIA_SELECT_KEY_PROF_KEY_RANGE_VLD_START, /* range valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_RANGE_UNION_VLD,     /* range union valid flag */
    CLX_CIA_SELECT_KEY_PROF_KEY_LAST,
} clx_cia_select_key_prof_key_t;

#define CLX_CIA_SELECT_KEY_PROF_BMP_SIZE (CLX_BITMAP_SIZE(CLX_CIA_SELECT_KEY_PROF_KEY_LAST))
typedef uint32_t clx_cia_select_key_prof_key_bmp_t[CLX_CIA_SELECT_KEY_PROF_BMP_SIZE];

typedef struct clx_cia_select_key_prof_s {
    clx_cia_select_key_prof_key_bmp_t key_prof_bmp; /* select key profile bitmap */
    uint32 exact_range_en;                          /* exact range enable */
} clx_cia_select_key_prof_t;

typedef enum clx_cia_l3_frm_type_e {
    CLX_CIA_L3_FRM_TYPE_L3_OTHER = 0, /* l3 other frame type */
    CLX_CIA_L3_FRM_TYPE_IPV4,         /* ipv4 frame type */
    CLX_CIA_L3_FRM_TYPE_IPV6,         /* ipv6 frame type */
    CLX_CIA_L3_FRM_TYPE_ARP,          /* arp frame type */
    CLX_CIA_L3_FRM_TYPE_MPLS,         /* mpls frame type */
    CLX_CIA_L3_FRM_TYPE_LAST,
} clx_cia_l3_frm_type_t;

typedef enum clx_cia_grp_key_width_e {
    CLX_CIA_GRP_KEY_WIDTH_NONE = 0,
    CLX_CIA_GRP_KEY_WIDTH_1X, /* 1x key width */
    CLX_CIA_GRP_KEY_WIDTH_2X, /* 2x key width */
    CLX_CIA_GRP_KEY_WIDTH_4X, /* 4x key width */
    CLX_CIA_GRP_KEY_WIDTH_LAST,
} clx_cia_grp_key_width_t;
typedef struct clx_cia_grp_key_info_s {
    clx_cia_grp_key_width_t key_width[CLX_CIA_L3_FRM_TYPE_LAST]; /* key width of each l3 frame type
                                                                  */
    uint32 flags; /* CLX_CIA_GRP_KEY_INFO_XXX flags */
} clx_cia_grp_key_info_t;

#define CLX_CIA_GRP_KEY_INFO_FLAGS_KEY_WIDTH_VLD (1U << 0) /* key width valid flag */

typedef struct clx_cia_grp_prof_s {
    uint32 pri;                   /* group priority */
    uint32 mac_pkt_format_flags;  /* CLX_CIA_GRP_FORMAT_XXX, CIA search only */
    uint32 arp_pkt_format_flags;  /* CLX_CIA_GRP_FORMAT_XXX, CIA search only */
    uint32 ipv4_pkt_format_flags; /* CLX_CIA_GRP_FORMAT_XXX, CIA search only */
    uint32 ipv6_pkt_format_flags; /* CLX_CIA_GRP_FORMAT_XXX, CIA search only */
    uint32 mpls_pkt_format_flags; /* CLX_CIA_GRP_FORMAT_XXX, CIA search only. */
    uint32 select_key_prof_id[CLX_CIA_L3_FRM_TYPE_LAST]; /* select key profile id [CLX84 only]*/
    uint32 grp_size;                                     /* Fixed grp size,
                                                          * 512 for mt series. Not support auto-extend if assign grp_size */
    uint32 flags;                                        /* CLX_CIA_GRP_PROF_XXX flags */
} clx_cia_grp_prof_t;
#define CLX_CIA_GRP_FORMAT_UDF_KEY_SINGLE (1U << 0)      /* single udf key [CLX86 only] */
#define CLX_CIA_GRP_FORMAT_UDF_KEY_DOUBLE (1U << 1)      /* double udf key [CLX86 only] */
#define CLX_CIA_GRP_FORMAT_UDF_L3_GRP_LBL_ENABLE                                            \
    (1U << 2)                                    /* replace lsb 32bits as L3 da/sa label of \
                                                  udf key. deprecated [CLX86 only]*/
#define CLX_CIA_GRP_FORMAT_TC_COLOR                                                                      \
    (1U << 3)                                    /* for BASE_L2 KEY/BASE L3 KEY,                         \
                                                  * if use tc_color as key, can not use pcp/dei/dscp/ecn \
                                                  * as key [CLX86 only] */
#define CLX_CIA_GRP_FORMAT_L2_SWAP     (1U << 4) /* l2 sa/da swap-direction [CLX86 only] */
#define CLX_CIA_GRP_FORMAT_L3_SWAP     (1U << 5) /* l3 sa/da swap-direction [CLX86 only] */
#define CLX_CIA_GRP_FORMAT_L4_SWAP     (1U << 6) /* l4 dp/sp swap-direction [CLX86 only] */
#define CLX_CIA_GRP_FORMAT_BASE_KEY_L2 (1U << 7) /* l2 base key [CLX86 only] */
#define CLX_CIA_GRP_FORMAT_BASE_KEY_L3 (1U << 8) /* l3 base key [CLX86 only] */

#define CLX_CIA_GRP_FORMAT_BASE_LBL_REPLACE_DA                                                   \
    (1U << 9)                                           /* replace BASE IP DA addr by flow_label \
                                                         [CLX86 only] */
#define CLX_CIA_GRP_FORMAT_BASE_LBL_REPLACE_SA                                                   \
    (1U << 10)                                          /* replace BASE IP SA addr by flow_label \
                                                         [CLX86 only] */
#define CLX_CIA_GRP_FORMAT_SELECT_KEY_ENABLE (1U << 11) /* select key enable [CLX84 only]*/
#define CLX_CIA_GRP_PROF_FLAGS_PORT_BMP                                                                  \
    (1U << 0)                                           /* CIA search only.                              \
                                                         * for pure BASE_L2/L3_KEY, if use port bitmap   \
                                                         * as key, can not use intf_grp_lbl,             \
                                                         * l2/l3_da/sa_grp_lbl, igr_cia_grp_lbl, arp.tpa \
                                                         * as key.                                       \
                                                         [CLX86 only] */
#define CLX_CIA_GRP_PROF_FLAGS_RANGE                                                                    \
    (1U << 1)                                           /* Select range                                 \
                                                         * available only if                            \
                                                         * CLX_CIA_GRP_PROF_FLAGS_PORT_BMP and          \
                                                         * CLX_CIA_GRP_PROF_FLAGS_GRP_LBL       are not \
                                                         * selected.                                    \
                                                         [CLX86 only] */
#define CLX_CIA_GRP_PROF_FLAGS_GRP_LBL                                                      \
    (1U << 2)                                           /* IGR: da/sa grp label; EGR:       \
                                                         * igr_grp_lbl.     conflict with   \
                                                         * CLX_CIA_GRP_PROF_FLAGS_PORT_BMP. \
                                                         [CLX86 only] */
#define CLX_CIA_GRP_PROF_FLAGS_ARP_TPA                                               \
    (1U << 3) /* Arp pkt_format only, conflict with CLX_CIA_GRP_PROF_FLAGS_PORT_BMP, \
               * CLX_CIA_GRP_PROF_FLAGS_GRP_LBL and CLX_CIA_GRP_PROF_FLAGS_RANGE.    \
               [CLX86 only] */
#define CLX_CIA_GRP_PROF_FLAGS_SIZE                                  \
    (1U << 4) /* CIA only, not support auto-extend if enable this    \
               * flag for mountain series should be multiples of 512 \
               [CLX86 only] */
#define CLX_CIA_GRP_PROF_FLAGS_PREEMPT_BY_EXACT                                             \
    (1U << 5) /* CIA only, indicate CIA exact entry could use action pointer to CIA result. \
               * Not allow to add CIA entry into this group anymore */

typedef struct clx_cia_exact_grp_prof_s {
    uint32 pri;                                                          /* group priority */
    uint32 exact_ignore_msk[CLX_SWC_HSH_TILE_LAST][CLX_CIA_EXACT_WORDS]; /* set to 1 to mask out
                            corresponding bit as don't care on flw_key,
                            flags &
                            CLX_CIA_EXACT_GRP_PROF_FLAGS_EXACT_IGNORE_MSK -
                            use tile 0 to config all mask, flags &
                            CLX_CIA_EXACT_GRP_PROF_FLAGS_EXACT_IGNORE_MSK_WITH_TILE
                            - use tile array to config tile mask */
    uint32 select_key_prof_id; /* default select key prof id [CLX84 only]*/
    uint32 flags;              /* CLX_CIA_EXACT_GRP_PROF_XXX flags */
} clx_cia_exact_grp_prof_t;

#define CLX_CIA_EXACT_GRP_PROF_FLAGS_EXACT_IGNORE_MSK (1U << 1)
#define CLX_CIA_EXACT_GRP_PROF_FLAGS_EXACT_DA_LBL \
    (1U << 2) /* Exact only, replace lsb 16 bits  \
            as da_lbl of udf key. [CLX86 only]*/
#define CLX_CIA_EXACT_GRP_PROF_FLAGS_EXACT_SA_LBL \
    (1U << 3) /* Exact only, replace lsb 16 bits  \
               as sa_lbl of udf key. [CLX86 only]*/
#define CLX_CIA_EXACT_GRP_PROF_FLAGS_EXACT_IGNORE_MSK_WITH_TILE (1U << 4)
#define CLX_CIA_EXACT_GRP_PROF_FLAGS_SELECT_KEY_ENABLE \
    (1U << 5) /* default select key prof id enable [CLX84 only]*/

typedef struct clx_cia_pkt_format_s {
    uint16 ethertype;             /* ethertype key */
    uint16 ethertype_msk;         /* ethertype key mask */
    uint8 proto;                  /* ip protocol */
    uint8 proto_msk;              /* ip protocol mask */
    uint16 src_port;              /* l4 source port */
    uint16 src_port_msk;          /* l4 source port mask */
    uint16 dst_port;              /* l4 destination port */
    uint16 dst_port_msk;          /* l4 destination port mask */
    uint8 vid_num;                /* vid number */
    clx_cia_vm_type_t vm_type;    /* vm type  [not support]*/
    clx_cia_l2_frm_t l2_frm_type; /* l2 frame type */
    clx_cia_tnl_t tnl_type;       /* tunnel type and decap pass = 1, ingress only */

    uint32 flags;                 /* CLX_CIA_PKT_FORMAT_XXX flags*/
    uint32 flags_msk;             /* CLX_CIA_PKT_FORMAT_XXX flags*/
} clx_cia_pkt_format_t;

#define CLX_CIA_PKT_FORMAT_FLAGS_L2_FRM_TYPE_VLD (1U << 0) /* l2 frame type flag */
#define CLX_CIA_PKT_FORMAT_FLAGS_TNL_TYPE_VLD    (1U << 1) /* tunnel type flag, ingress only */
#define CLX_CIA_PKT_FORMAT_FLAGS_STAG_VLD        (1U << 2) /* service vlan tag valid flag */
#define CLX_CIA_PKT_FORMAT_FLAGS_CTAG_VLD        (1U << 3) /* custom vlan tag valid flag */
/* indicates ctag_vld is in 1'st or 2'nd vlan */
#define CLX_CIA_PKT_FORMAT_FLAGS_VLAN_TAG_MODE_1Q                                          \
    (1U << 4)                                              /* vlan tag mode 1q flag [CLX86 \
                                                                  only]*/
#define CLX_CIA_PKT_FORMAT_FLAGS_L2_SKIP_0_VLD   (1U << 5) /* l2 skip 0 flag */
#define CLX_CIA_PKT_FORMAT_FLAGS_L2_SKIP_1_VLD   (1U << 6) /* l2 skip 1 flag */
#define CLX_CIA_PKT_FORMAT_FLAGS_L2_IS_BACST     (1U << 7) /* l2 is broadcast flag */
#define CLX_CIA_PKT_FORMAT_FLAGS_L2_IS_MULTICAST (1U << 8) /* l2 is multicast flag */

typedef enum clx_cia_pkg_base_e {
    CLX_CIA_PKG_BASE_NONE = 0,
    CLX_CIA_PKG_BASE_START_L2_HDR,    /* l2 header start */
    CLX_CIA_PKG_BASE_START_L3_HDR,    /* l3 header start, for CLX84, it starts from ethertype.*/
    CLX_CIA_PKG_BASE_START_L4_HDR,    /* l4 header start */
    CLX_CIA_PKG_BASE_START_INNER_HDR, /* inner header start, ingress only */
    CLX_CIA_PKG_BASE_START_L2_SKIP0,  /* l2 skip0 start [CLX84 only] */
    CLX_CIA_PKG_BASE_START_L2_SKIP1,  /* l2 skip1 start [CLX84 only] */
    CLX_CIA_PKG_BASE_START_L3_OPTION, /* l3 header option start [CLX84 only] */
    CLX_CIA_PKG_BASE_END_L3_HDR,      /* l3 header end [CLX84 fcm only] */
    CLX_CIA_PKG_BASE_END_L4_HDR,      /* l4 header end [CLX84 only] */
    CLX_CIA_PKG_BASE_START_TNL_HDR,   /* tunnel header start [CLX84 only] */
    CLX_CIA_PKG_BASE_END_TNL_HDR,     /* tunnel header end [CLX84 only] */
    CLX_CIA_PKG_BASE_LAST
} clx_cia_pkg_base_t;

typedef struct clx_cia_pkg_cfg_s {
    clx_cia_pkg_base_t type; /* pkg type */
    uint32 offset;           /* byte offset */
    uint32 msk;              /* pkg data mask, cia search only */
    uint32 flags;            /* CLX_CIA_PKG_FLAGS_XXX */
} clx_cia_pkg_cfg_t;
/* Both first and second must select this flag.
 * For consecutive byte, type, offset mask must be zero.
 * for CLX86 it means to get two consecutive bytes.
 */
#define CLX_CIA_PKG_FLAGS_CONSECUTIVE_BYTE (1U << 0)

typedef struct clx_cia_udf_prof_s {
    clx_cia_pkg_cfg_t pkg_cfg[CLX_CIA_PKG_NUM]; /* pkg key config */
    uint32 pkg_cnt;                             /* 48 for consecutive mode.*/
    uint32 internal_key_bmp;                    /* CLX_CIA_UDF_INTERNAL_KEY_XXX, [CLX86 only]*/

    clx_cia_pkg_cfg_t exact_pkg_cfg[CLX_CIA_EXACT_PKG_NUM]; /* ingress only */
    uint32 exact_pkg_cnt;                                   /* ingress only */
    uint32 exact_internal_key_bmp;                          /* CLX86 ingress only */
    uint32 exact_range_en;                                  /* exact range enable, [CLX86 only]*/

    uint32 select_key_prof_id; /* exact entry select key index, [CLX84 only] ingress only */
    uint32 flags;              /* ingress only */

    uint32 outer_pkg_num; /* pre_cia udf hit and cia udf hit at the same time, use outer pkg number,
                             range: 0-12, ingress only [CLX84 only] */
    uint32 udf0_pkg_rsh;  /* UDF0 pkg right shift bits, 0-15, 0 means no shift [CLX84 only] */
    uint32 udf0_pkg_lsh;  /* UDF0 pkg left shift bits, 0-15, 0 means no shift [CLX84 only] */
    uint32 udf1_pkg_rsh;  /* UDF1 pkg right shift bits, 0-15, 0 means no shift [CLX84 only] */
    uint32 udf1_pkg_lsh;  /* UDF1 pkg left shift bits, 0-15, 0 means no shift [CLX84 only] */
} clx_cia_udf_prof_t;
/* l2 sa group label; mt: ingress exact only */
#define CLX_CIA_UDF_INTERNAL_KEY_L2_SA_GRP_LBL (1U << 0)
/* l2 da group label; mt: ingress exact only */
#define CLX_CIA_UDF_INTERNAL_KEY_L2_DA_GRP_LBL (1U << 1)
/* l3 sa group label, need to enable
 * CLX_CFG_TYPE_TCAM_L3_SIP_ENABLE
 * for Tcam search; mt: ingress exact only */
#define CLX_CIA_UDF_INTERNAL_KEY_L3_SA_GRP_LBL (1U << 2)
/* l3 da group label; mt: ingress exact only */
#define CLX_CIA_UDF_INTERNAL_KEY_L3_DA_GRP_LBL (1U << 3)
#define CLX_CIA_UDF_INTERNAL_KEY_INTF_GRP_LBL  (1U << 4) /* interface group label */
#define CLX_CIA_UDF_INTERNAL_KEY_RANGE         (1U << 5) /* range key.*/
#define CLX_CIA_UDF_INTERNAL_KEY_PORT_BMP      (1U << 6) /* port bmp key, not support exact entry */
#define CLX_CIA_UDF_INTERNAL_KEY_BDID          (1U << 7) /* bridge domain id, ingress only */
#define CLX_CIA_UDF_INTERNAL_KEY_VRF                             \
    (1U << 8) /* virtual routing and forwarding id, ingress only \
               */
/* service vlan id, ingress only */
#define CLX_CIA_UDF_INTERNAL_KEY_STAG_VID (1U << 9)
/* custom vlan id, ingress only */
#define CLX_CIA_UDF_INTERNAL_KEY_CTAG_VID (1U << 10)
/* service vlan pcp/dei, ingress only */
#define CLX_CIA_UDF_INTERNAL_KEY_STAG_PCP_DEI (1U << 11)
/* custom vlan pcp/dei, ingress only */
#define CLX_CIA_UDF_INTERNAL_KEY_CTAG_PCP_DEI (1U << 12)
/* vlan tag mode 802.1q, ingress only,
   indicates ctag_vid/pcp_dei is in 1'st or 2'nd vlan */
#define CLX_CIA_UDF_INTERNAL_KEY_VLAN_TAG_MODE_1Q (1U << 13)
#define CLX_CIA_UDF_INTERNAL_KEY_L3_ROUTE         (1U << 14) /* is l3 routing, ingress only */
#define CLX_CIA_UDF_INTERNAL_KEY_TCP_FLAGS        (1U << 15) /* 12 bits TCP flags */
/* 16 bits ingress cia group label, egr only */
#define CLX_CIA_UDF_INTERNAL_KEY_IGR_CIA_GRP_LBL (1U << 16)
#define CLX_CIA_UDF_INTERNAL_KEY_L3_ROUTE_EN     (1U << 17) /* is l3 routing, ingress only */

#define CLX_CIA_UDF_FLAGS_CIA_AND_EXACT_WITH_SAME_PKG_CFG \
    (1U << 0) /* use pkg_cfg for both cia and exact [CLX84 only] */
#define CLX_CIA_UDF_FLAGS_EXACT_SELECT_KEY_ENABLE \
    (1U << 1) /* use exact_select_key_prof_id for exact [CLX84 only] */

typedef enum clx_cia_range_e {
    CLX_CIA_RANGE_NONE = 0,     /* No range*/
    CLX_CIA_RANGE_SVID,         /* service vlan range */
    CLX_CIA_RANGE_CVID,         /* custom vlan range */
    CLX_CIA_RANGE_IP_TTL,       /* ip ttl range */
    CLX_CIA_RANGE_L4_SRC_PORT,  /* l4 source port range */
    CLX_CIA_RANGE_L4_DST_PORT,  /* l4 destination port range */
    CLX_CIA_RANGE_PKG,          /* pkg key range */
    CLX_CIA_RANGE_IP_TOTAL_LEN, /* IP packet total length range */
    CLX_CIA_RANGE_VID_NUM,      /* VID number, ingress only*/
    CLX_CIA_RANGE_IP_TOS,       /* IP TOS range */
    CLX_CIA_RANGE_FRM_LEN,      /* L2 frame length range, ingress only*/
    CLX_CIA_RANGE_VRF,          /* L3 VRF range, ingress only */
    CLX_CIA_RANGE_BDID,         /* Bridge domain range */
    CLX_CIA_RANGE_IGR_CIA_LBL,  /* ingress cia group label, egress only */
    CLX_CIA_RANGE_PORT,         /* port range [CLX84 only]*/
    CLX_CIA_RANGE_L3_DA_LSB,    /* l3 da lsb range [CLX84 only]*/
    CLX_CIA_RANGE_L3_SA_LSB,    /* l3 sa lsb range [CLX84 only]*/
    CLX_CIA_RANGE_L2_DA_LSB,    /* l2 da lsb range [CLX84 only]*/
    CLX_CIA_RANGE_L2_SA_LSB,    /* l2 sa lsb range [CLX84 only]*/
    CLX_CIA_RANGE_LAST
} clx_cia_range_t;

typedef struct clx_cia_range_cfg_s {
    clx_cia_range_t type;                         /* range type */
    clx_cia_pkg_base_t pkg_base_type;             /* pkg base type if select CLX_CIA_RANGE_PKG */
    uint32 pkg_offset;                            /* pkg byte offset */
    uint16 val_msk;                               /* value mask */
    uint16 val_max;                               /* range value maximum */
    uint16 val_min;                               /* range value minimum */
    uint32 flags;                                 /* CLX_CIA_RANGE_CFG_XXX flags*/
} clx_cia_range_cfg_t;
#define CLX_CIA_RANGE_CFG_FLAGS_INVERSE (1U << 0) /* range inverse */
/* indicates range_cvid is in 1'st or 2'nd vlan */
#define CLX_CIA_RANGE_CFG_FLAGS_VLAN_TAG_MODE_1Q (1U << 1) /*[CLX86 only] */
typedef enum clx_cia_classify_key_e {
    CLX_CIA_CLASSIFY_KEY_MAC = 0,                          /* mac frame classify key */
    CLX_CIA_CLASSIFY_KEY_ARP,                              /* arp frame classify key */
    CLX_CIA_CLASSIFY_KEY_IPV4,                             /* ipv4 frame classify key */
    CLX_CIA_CLASSIFY_KEY_IPV6,                             /* ipv6 frame classify key */
    CLX_CIA_CLASSIFY_KEY_MPLS,                             /* mpls frame classify key */
    CLX_CIA_CLASSIFY_KEY_UDF,                              /* udf frame classify key [CLX86 only]*/
    CLX_CIA_CLASSIFY_KEY_LAST
} clx_cia_classify_key_t;

typedef struct clx_cia_mac_key_s {
    clx_mac_t dmac;                        /* destination mac */
    clx_mac_t dmac_msk;                    /* destination mac mask */
    clx_mac_t smac;                        /* source mac */
    clx_mac_t smac_msk;                    /* source mac mask */
    uint16 ether_type;                     /* ether type */
    uint16 ether_type_msk;                 /* ether type mask */
    clx_cia_pkt_vlan_type_t pkt_vlan_type; /* packet vlan tag type */
    uint16 outvlan_id;                     /* outer vlan id */
    uint16 outvlan_id_msk;                 /* outer vlan id mask */
    uint16 invlan_id;                      /* inner vlan id */
    uint16 invlan_id_msk;                  /* inner vlan id mask */
    uint32 vm_tag;                         /* vm_tag vm_type:2bit, svif:20bit CLX84 only */
    uint32 vm_tag_msk;                     /* vm_tag mask CLX84 only*/
    uint8 skip0_tag;                       /* skip0_tag {vld, idx} CLX84 only */
    uint8 skip0_tag_msk;                   /* skip0_tag mask CLX84 only*/
    uint8 skip1_tag;                       /* skip1_tag {vld, idx} CLX84 only */
    uint8 skip1_tag_msk;                   /* skip1_tag mask CLX84 only*/
    uint32 flags;                          /* CLX_CIA_MAC_KEY_FLAGS_XXX flags */
    uint32 flags_msk;                      /* CLX_CIA_MAC_KEY_FLAGS_XXX flags mask */
} clx_cia_mac_key_t;

#define CLX_CIA_MAC_KEY_FLAGS_PKT_VLAN_TYPE_VLD (1U << 0) /* packet vlan tag type flag */
/* indicates ctag_valid is in 1'st or 2'nd vlan [CLX86 only] */
#define CLX_CIA_MAC_KEY_FLAGS_VLAN_TAG_MODE_1Q (1U << 1)
#define CLX_CIA_MAC_KEY_FLAGS_L2_IS_BC         (1U << 2) /* l2 is broadcast flag [CLX84 only] */
#define CLX_CIA_MAC_KEY_FLAGS_L2_ADDR_SWAP     (1U << 3) /* l2 address swap flag [CLX84 only] */

typedef struct clx_cia_arp_key_s {
    clx_mac_t sender_mac;                /* sender mac */
    clx_mac_t sender_mac_msk;            /* sender mac mask */
    clx_mac_t target_mac;                /* target mac */
    clx_mac_t target_mac_msk;            /* target mac mask*/
    clx_ipv4_t sender_ip;                /* sender ip address */
    clx_ipv4_t sender_ip_msk;            /* sender ip address mask */
    clx_ipv4_t target_ip;                /* target ip address */
    clx_ipv4_t target_ip_msk;            /* target ip address mask */
    uint16 opcode;                       /* arp opcode [CLX84 only]*/
    uint16 opcode_msk;                   /* arp opcode mask [CLX84 only] */
    clx_cia_arp_frm_type_t arp_frm_type; /* arp frame type */
    uint32 flags;                        /* clx_cia_arp_key_flags_t flags */
    uint32 flags_msk;                    /* clx_cia_arp_key_flags_t flags mask */
} clx_cia_arp_key_t;

#define CLX_CIA_ARP_FRM_TYPE_VLD (1U << 0) /* arp frame valid flag */
#define CLX_CIA_ARP_KEY_FLAGS_SENDER_MAC_EQ_SMAC \
    (1U << 0)                              /* sender mac equals smac flag [CLX84 only] */
#define CLX_CIA_ARP_KEY_FLAGS_TARGET_MAC_EQ_DMAC \
    (1U << 1)                              /* target mac equals dmac flag [CLX84 only] */

typedef struct clx_cia_ipv4_key_s {
    clx_ipv4_t dip;         /* destination ip address */
    clx_ipv4_t dip_msk;     /* destination ip address mask */
    clx_ipv4_t sip;         /* source ip address */
    clx_ipv4_t sip_msk;     /* source ip address mask*/
    uint8 proto;            /* ip protocol */
    uint8 proto_msk;        /* ip protocol mask */
    uint16 dst_port;        /* l4 destination port */
    uint16 dst_port_msk;    /* l4 destination port mask */
    uint16 src_port;        /* l4 source port */
    uint16 src_port_msk;    /* l4 source port mask */
    uint16 tcp_flag;        /* tcp flag, mt: 12bits */
    uint16 tcp_flag_msk;    /* tcp flag mask */
    uint8 icmp_type;        /* icmp type value */
    uint8 icmp_type_msk;    /* icmp type mask */
    uint8 icmp_code;        /* icmp code value */
    uint8 icmp_code_msk;    /* icmp code value mask */
    uint8 igmp_type;        /* igmp type value */
    uint8 igmp_type_msk;    /* igmp type value mask */
    uint8 ttl;              /* ttl */
    uint8 ttl_msk;          /* ttl mask */
    clx_cia_frg_t frg_type; /* ip fragment type */
    clx_cia_ttl_t ttl_type; /* ttl type */
    uint32 flags;           /* CLX_CIA_IPV4_KEY_XXX flags */
    uint32 flags_msk;       /* CLX_CIA_IPV4_KEY_XXX flags mask */
} clx_cia_ipv4_key_t;

#define CLX_CIA_IPV4_KEY_FLAGS_FRG_TYPE_VLD   (1U << 0) /* ip fragment type valid flag */
#define CLX_CIA_IPV4_KEY_FLAGS_TTL_TYPE_VLD   (1U << 1) /* ttl type valid flag */
#define CLX_CIA_IPV4_KEY_FLAGS_AUTH_HDR_EXIST (1U << 2) /* Authentication header exist flag */
#define CLX_CIA_IPV4_KEY_FLAGS_OPT_HDR_EXIST  (1U << 3) /* option header exist flag */
#define CLX_CIA_IPV4_KEY_FLAGS_L3_ADDR_SWAP   (1U << 4) /* l3 address swap flag [CLX84 only] */
#define CLX_CIA_IPV4_KEY_FLAGS_L4_ADDR_SWAP   (1U << 5) /* l4 address swap flag [CLX84 only] */

typedef struct clx_cia_ipv6_key_s {
    clx_ipv6_t dip;                            /* destination ip address */
    clx_ipv6_t dip_msk;                        /* destination ip address mask */
    clx_ipv6_t sip;                            /* source ip address */
    clx_ipv6_t sip_msk;                        /* source ip address mask */
    uint8 proto;                               /* ip protocol */
    uint8 proto_msk;                           /* ip protocol mask */
    uint16 dst_port;                           /* l4 destination port */
    uint16 dst_port_msk;                       /* l4 destination port mask */
    uint16 src_port;                           /* l4 source port */
    uint16 src_port_msk;                       /* l4 source port mask */
    uint16 tcp_flag;                           /* tcp flag, mt: 12bits */
    uint16 tcp_flag_msk;                       /* tcp flag mask */
    uint8 icmp_type;                           /* icmp type value */
    uint8 icmp_type_msk;                       /* icmp type value mask */
    uint8 icmp_code;                           /* icmp code value */
    uint8 icmp_code_msk;                       /* icmp code value mask */
    uint8 igmp_type;                           /* igmp type value */
    uint8 igmp_type_msk;                       /* igmp type value mask */
    uint8 ttl;                                 /* ttl CLX84 only*/
    uint8 ttl_msk;                             /* ttl mask CLX84 only*/
    uint32 flow_label;                         /* flow label value */
    uint32 flow_label_msk;                     /* flow label mask */
    clx_cia_frg_t frg_type;                    /* ip fragment type */
    clx_cia_ttl_t ttl_type;                    /* ttl type */
    clx_cia_ipv6_opt_hdr_type_t opt0_hdr_type; /* option 0 header type */
    clx_cia_ipv6_opt_hdr_type_t opt1_hdr_type; /* option 1 header type */

    uint32 flags;                              /* CLX_CIA_IPV6_KEY_XXX flags */
    uint32 flags_msk;                          /* CLX_CIA_IPV6_KEY_XXX flags mask */
} clx_cia_ipv6_key_t;

#define CLX_CIA_IPV6_KEY_FLAGS_FRG_TYPE_VLD (1U << 0) /* ip fragment type valid flag */
#define CLX_CIA_IPV6_KEY_FLAGS_TTL_TYPE_VLD (1U << 1) /* ttl type valid flag */
#define CLX_CIA_IPV6_KEY_FLAGS_AUTH_HDR_EXIST \
    (1U << 2) /* Authentication header exist flag, CLX86 only */
#define CLX_CIA_IPV6_KEY_FLAGS_OPT0_HDR_TYPE_VLD \
    (1U << 3) /* Option 0 header exist flag, CLX84 only */
#define CLX_CIA_IPV6_KEY_FLAGS_OPT1_HDR_TYPE_VLD \
    (1U << 4) /* Option 1 header exist flag, CLX84 only */
#define CLX_CIA_IPV6_KEY_FLAGS_L3_ADDR_SWAP (1U << 5) /* l3 address swap flag CLX84 only*/
#define CLX_CIA_IPV6_KEY_FLAGS_L4_ADDR_SWAP (1U << 6) /* l4 address swap flag CLX84 only*/

typedef struct clx_cia_mpls_key_s {
    uint32 lbl0;            /* MPLS label 0 */
    uint32 lbl0_msk;        /* MPLS label 0 mask */
    uint32 lbl1;            /* MPLS label 1 */
    uint32 lbl1_msk;        /* MPLS label 1 mask */
    uint32 lbl2;            /* MPLS label 2 */
    uint32 lbl2_msk;        /* MPLS label 2 mask */
    uint32 lbl3;            /* MPLS label 3 */
    uint32 lbl3_msk;        /* MPLS label 3 mask */
    clx_cia_ttl_t ttl_type; /* ttl type */
    uint8 ttl;              /* ttl value [CLX84 only]*/
    uint8 ttl_msk;          /* ttl mask [CLX84 only]*/
    uint8 lbl_num;          /* label number [CLX84 only]*/
    uint8 lbl_num_msk;      /* label number mask [CLX84 only]*/
    uint8 nibble;           /* nibble value [CLX84 only]*/
    uint8 nibble_msk;       /* nibble mask [CLX84 only]*/
    uint32 flags;           /* CLX_CIA_MPLS_KEY_XXX flags */
    uint32 flags_msk;       /* CLX_CIA_MPLS_KEY_XXX flags mask */
} clx_cia_mpls_key_t;

#define CLX_CIA_MPLS_KEY_FLAGS_TTL_TYPE_VLD (1U << 1) /* ttl type valid flag */
#define CLX_CIA_MPLS_KEY_FLAGS_LBL_BOS      (1U << 2) /* bottom of stack detected flag [CLX84 only] */

typedef struct clx_cia_l3_other_key_s {
    uint32 pld_0;     /* L3 other payload 0  */
    uint32 pld_0_msk; /* L3 other payload 0 mask */
    uint32 pld_1;     /* L3 other payload 1 */
    uint32 pld_1_msk; /* L3 other payload 1 mask */
    uint32 pld_2;     /* L3 other payload 2 */
    uint32 pld_2_msk; /* L3 other payload 2 mask */
    uint32 pld_3;     /* L3 other payload 3 */
    uint32 pld_3_msk; /* L3 other payload 3 mask */
    uint32 pld_4;     /* L3 other payload 4 */
    uint32 pld_4_msk; /* L3 other payload 4 mask */
    uint32 pld_5;     /* L3 other payload 5 */
    uint32 pld_5_msk; /* L3 other payload 5 mask */
    uint32 pld_6;     /* L3 other payload 6 */
    uint32 pld_6_msk; /* L3 other payload 6 mask */
    uint32 pld_7;     /* L3 other payload 7 */
    uint32 pld_7_msk; /* L3 other payload 7 mask */
    uint32 pld_8;     /* L3 other payload 8 */
    uint32 pld_8_msk; /* L3 other payload 8 mask */
    uint32 pld_9;     /* L3 other payload 9 */
    uint32 pld_9_msk; /* L3 other payload 9 mask */
    uint32 flags;     /* CLX_CIA_L3_OTHER_KEY_XXX flags, unused for now */
} clx_cia_l3_other_key_t;

typedef struct clx_cia_qos_key_s {
    uint8 pcp;      /* 1q:cvlan pcp, 1ad: svlan pcp if svlan exists; otherwise, cvlan pcp.*/
    uint8 pcp_msk;  /* 1q:cvlan pcp mask, 1ad: svlan pcp mask if svlan exists; otherwise, cvlan pcp
                       mask.*/
    uint8 dei;      /* 1q:cvlan dei, 1ad: svlan dei if svlan exists; otherwise, cvlan dei.*/
    uint8 dei_msk;  /* 1q:cvlan dei mask, 1ad: svlan dei mask if svlan exists; otherwise, cvlan dei
                       mask.*/
    uint8 dscp;     /* dscp for l3 packet */
    uint8 dscp_msk; /* dscp mask for l3 packet */
    uint8 exp;      /* exp for mpls packet  */
    uint8 exp_msk;  /* exp mask for mpls packet  */
    uint8 ecn;      /* ecn for l3 packet */
    uint8 ecn_msk;  /* ecn mask for l3 packet */
    uint8 tc;       /* tc */
    uint8 tc_msk;   /* tc mask */
    clx_color_t color;  /* color type */
    uint8 tnl_dscp;     /* tunnel dscp [CLX84 only] */
    uint8 tnl_dscp_msk; /* tunnel dscp mask [CLX84 only] */
    uint32 flags;       /* clx_cia_qos_key_flags_XXX */
} clx_cia_qos_key_t;

#define CLX_CIA_QOS_KEY_FLAGS_PCP_DEI   (1U << 0) /* vlan pcp/dei */
#define CLX_CIA_QOS_KEY_FLAGS_DSCP_ECN  (1U << 1) /* dscp/ecn flag */
#define CLX_CIA_QOS_KEY_FLAGS_TC_COLOR  (1U << 2) /* enable both tc and color flag */
#define CLX_CIA_QOS_KEY_FLAGS_COLOR_VLD (1U << 3) /* color valid flag */
#define CLX_CIA_QOS_KEY_FLAGS_EXP       (1U << 4) /* mpls exp flag  */

typedef struct clx_cia_pp_info_key_s {
    uint32 intf_grp_lbl;          /* mt: 16 bits, local interface group label*/
    uint32 intf_grp_lbl_msk;      /* mt: 16 bits, local interface group label mask */
    uint32 igr_cia_grp_lbl;       /* mt: 16 bits, ingress cia search group label,
                                            egress match only */
    uint32 igr_cia_grp_lbl_msk;   /* mt: 16 bits, ingress cia search group label
                                              mask, egress match only */
    uint32 l2_da_grp_lbl;         /* mt: 16 bits, l2 destination address group label */
    uint32 l2_da_grp_lbl_msk;     /* mt: 16 bits, l2 destination address group label
                                          mask */
    uint32 l2_sa_grp_lbl;         /* mt: 16 bits, l2 source address group label */
    uint32 l2_sa_grp_lbl_msk;     /* mt: 16 bits, l2 source address group label mask
                                   */
    uint32 l3_da_grp_lbl;         /* mt: 16 bits need to enable
                                   * CLX_CIA_GRP_FORMAT_BASE_LBL_REPLACE_DA, l3 destination
                                   * address group label */
    uint32 l3_da_grp_lbl_msk;     /* mt: 16 bits, l3 destination address group label
                                          mask */
    uint32 l3_sa_grp_lbl;         /* mt: 16 bits need to enable
                                   * CLX_CIA_GRP_FORMAT_BASE_LBL_REPLACE_SA, l3 source
                                   * address group label */
    uint32 l3_sa_grp_lbl_msk;     /* mt: 16 bits, l3 source address group label mask */
    uint32 bdid;                  /* Ingress : match ingress fdid
                                     Egress  : match egress bdid, must match flags_l3_route=0 simultaneously */
    uint32 bdid_msk;
    clx_cia_l2_frm_t l2_frm_type; /* l2 frame type */
    clx_cia_tnl_t tnl_type;       /* tunnel type */
    uint32 port;                  /* port id [CLX84 only] */
    uint32 port_grp_id;           /* port group id [CLX84 only] */
    uint32 port_grp_id_msk;       /* port group id mask [CLX84 only] */

    uint32 pre_cia_grp_lbl;       /* mt: 16 bits, pre cia search group label [CLX84 only]*/
    uint32 pre_cia_grp_lbl_msk;   /* mt: 16 bits, pre cia search group label mask [CLX84 only]*/

    uint32 bd_lbl;                /* mt: 16 bits, bridge domain label [CLX84 only] */
    uint32 bd_lbl_msk;            /* mt: 16 bits, bridge domain label mask [CLX84 only] */
    uint32 vrf_id; /* mt: 13 bits, virtual routing forwarding index, ingress only [CLX84 only] */
    uint32 vrf_id_msk; /* mt: 13 bits, virtual routing forwarding index mask, ingress only [CLX84
                          only] */
    uint32 vni;        /* mt: 25 bits, vxlan vni ingress only [CLX84 only] */
    uint32 vni_msk;    /* mt: 25 bits, vxlan vni mask ingress only [CLX84 only] */
    uint32 hit_status; /* mt: 9 bits, ingress only, hit status refer to
                          CLX_CIA_PP_INFO_KEY_HIT_STATUS_XXX [CLX84 only] */
    uint32 hit_status_msk;     /* mt: 9 bits, ingress only, hit status mask refer to
                                  CLX_CIA_PP_INFO_KEY_HIT_STATUS_XXX [CLX84 only] */
    uint32 ecn_mark;           /* mt: 8 bits, egress only [CLX84 only] */
    uint32 ecn_mark_msk;       /* mt: 8 bits, egress only [CLX84 only] */
    clx_cia_src_idx_t src_idx; /* source index, ingress only [CLX84 only]*/
    clx_cia_dst_idx_t dst_idx; /* destination index, egress only [CLX84 only] */

    uint32 flags;              /* clx_cia_pp_info_key_flags_xxx */
    uint32 flags_msk;          /* clx_cia_pp_info_key_flags_xxx */
} clx_cia_pp_info_key_t;

/* hit status */
#define CLX_CIA_PP_INFO_KEY_HIT_STATUS_DROP     (1U << 0) /* drop hit [CLX84 only]*/
#define CLX_CIA_PP_INFO_KEY_HIT_STATUS_CPU_DI   (1U << 1) /* cpu di hit [CLX84 only] */
#define CLX_CIA_PP_INFO_KEY_HIT_STATUS_IS_ROUTE (1U << 2) /* route mac hit [CLX84 only] */
#define CLX_CIA_PP_INFO_KEY_HIT_STATUS_L3_DIP   (1U << 3) /* l3 dip hit [CLX84 only] */
#define CLX_CIA_PP_INFO_KEY_HIT_STATUS_L3_SIP   (1U << 4) /* l3 sip hit [CLX84 only] */
#define CLX_CIA_PP_INFO_KEY_HIT_STATUS_L2_DMAC  (1U << 5) /* l2 dmac hit [CLX84 only] */
#define CLX_CIA_PP_INFO_KEY_HIT_STATUS_L2_SMAC  (1U << 6) /* l2 smac hit [CLX84 only] */
#define CLX_CIA_PP_INFO_KEY_HIT_STATUS_VLAN_FILTER_DROP \
    (1U << 7)                                             /* vlan filter drop hit [CLX84 only] */
#define CLX_CIA_PP_INFO_KEY_HIT_STATUS_STP_DROP \
    (1U << 8) /* stp drop hit [icia only] [CLX84 only] */
#define CLX_CIA_PP_INFO_KEY_HIT_STATUS_ECN_MARK \
    (1U << 9) /* ecn mark hit [ecia only] [CLX84 only] */

/* pp info key flags */
#define CLX_CIA_PP_INFO_KEY_FLAGS_L2_FRM_TYPE_VLD (1U << 0) /* l2 frame type valid flag */
#define CLX_CIA_PP_INFO_KEY_FLAGS_L3_ROUTE        (1U << 1) /* is l3 route flag [CLX86 only] */
#define CLX_CIA_PP_INFO_KEY_FLAGS_TNL_TERM        (1U << 2) /* is tunnel decap pass flag */
/* indicates cvid/ctag_valid is in 1'st or 2'nd vlan [CLX86 only] */
#define CLX_CIA_PP_INFO_KEY_FLAGS_VLAN_TAG_MODE_1Q (1U << 3)
#define CLX_CIA_PP_INFO_KEY_FLAGS_STAG_VLD         (1U << 4) /* stag valid */
#define CLX_CIA_PP_INFO_KEY_FLAGS_CTAG_VLD         (1U << 5) /* ctag valid */
#define CLX_CIA_PP_INFO_KEY_FLAGS_TNL_TYPE_VLD     (1U << 6) /* tunnel type valid flag [CLX84 only] */
#define CLX_CIA_PP_INFO_KEY_FLAGS_PORT_VLD         (1U << 7) /* port valid flag [CLX84 only] */
#define CLX_CIA_PP_INFO_KEY_FLAGS_SRC_IDX_VLD      (1U << 8) /* source index valid flag [CLX84 only] */
#define CLX_CIA_PP_INFO_KEY_FLAGS_DST_IDX_VLD \
    (1U << 9) /* destination index valid flag [CLX84 only] */

typedef struct clx_cia_pkg_key_s {
    uint32 l2_sa_grp_lbl;     /* mt:10 bits, l2 source address group label [CLX86 only] */
    uint32 l2_sa_grp_lbl_msk; /* mt:10 bits, l2 source address group label mask [CLX86 only] */
    uint32 l2_da_grp_lbl;     /* mt:10 bits, l2 destination address group label [CLX86 only] */
    uint32 l2_da_grp_lbl_msk; /* mt:10 bits, l2 destination address group label mask [CLX86 only] */
    uint32 l3_sa_grp_lbl;     /* mt:16 bits, l3 source address group label [CLX86 only] */
    uint32 l3_sa_grp_lbl_msk; /* mt:16 bits, l3 source address group label mask [CLX86 only] */
    uint32 l3_da_grp_lbl;     /* mt:16 bits, l3 destination address group label [CLX86 only] */
    uint32 l3_da_grp_lbl_msk; /* mt:16 bits, l3 destination address group label mask [CLX86 only] */
    uint32 intf_grp_lbl;      /* mt:16 bits, local interface group label [CLX86 only] */
    uint32 intf_grp_lbl_msk;  /* mt:16 bits, local interface group label mask [CLX86 only] */
    uint32 igr_cia_grp_lbl;   /* 12 bits, ingress cia search group label [CLX86 only] */
    uint32 igr_cia_grp_lbl_msk;   /* 12 bits, ingress cia search group label mask [CLX86 only] */
    uint32 vrf;                   /* 13 bits, virtual routing forwarding index [CLX86 only] */
    uint32 vrf_msk;               /* 13 bits, virtual routing forwarding index mask [CLX86 only] */
    uint32 bdid;                  /* 14 bits, bridge domain index [CLX86 only] */
    uint32 bdid_msk;              /* 14 bits, bridge domain index mask [CLX86 only] */
    uint32 tcp_flag;              /* 12 bits, tcp flag [CLX86 only] */
    uint32 tcp_flag_msk;          /* 12 bits, tcp flag mask [CLX86 only] */

    uint16 svid;                  /* service vlan id [CLX86 only] */
    uint16 svid_msk;              /* service vlan id mask [CLX86 only] */
    uint8 spcp;                   /* service vlan pcp [CLX86 only] */
    uint8 spcp_msk;               /* service vlan pcp mask [CLX86 only] */
    uint8 sdei;                   /* service vlan dei [CLX86 only] */
    uint8 sdei_msk;               /* service vlan dei mask [CLX86 only] */
    uint16 cvid;                  /* custom vlan id [CLX86 only] */
    uint16 cvid_msk;              /* custom vlan id mask [CLX86 only] */
    uint8 cpcp;                   /* custom vlan pcp [CLX86 only] */
    uint8 cpcp_msk;               /* custom vlan pcp mask [CLX86 only] */
    uint8 cdei;                   /* custom vlan dei [CLX86 only] */
    uint8 cdei_msk;               /* custom vlan dei mask [CLX86 only] */

    uint32 pkg_cnt;               /* pkg key byte count */
    uint32 data[CLX_CIA_PKG_NUM]; /* pkg key data */
    uint32 msk[CLX_CIA_PKG_NUM];  /* pkg key data mask */

    uint32 flags;                 /* clx_cia_pkg_key_flags_xxx */
    uint32 flags_msk;             /* clx_cia_pkg_key_flags_xxx */
} clx_cia_pkg_key_t;

/* indicates cvid/cpcp/cdei is in 1'st or 2'nd vlan */
#define CLX_CIA_PKG_KEY_FLAGS_VLAN_TAG_MODE_1Q (1U << 0) /* [CLX86 only] */
#define CLX_CIA_PKG_KEY_FLAGS_L3_ROUTE         (1U << 1) /* is l3 route [CLX86 only] */
#define CLX_CIA_PKG_KEY_FLAGS_L3_ROUTE_EN      (1U << 2) /* is l3 route enable [CLX86 only] */

typedef struct clx_cia_classify_s {
    clx_cia_classify_key_t classify_key_type; /* CLX_CIA_CLASSIFY_KEY_MAC  :
                                                 mac/qos/pp_info/pkg/range_key
                                                 CLX_CIA_CLASSIFY_KEY_ARP  :
                                                 mac/arp/qos/pp_info/pkg/range_key
                                                 CLX_CIA_CLASSIFY_KEY_IPV4 :
                                                 mac/ipv4/qos/pp_info/pkg/range_key
                                                 CLX_CIA_CLASSIFY_KEY_IPV6 :
                                                 mac/ipv6/qos/pp_info/pkg/range_key
                                                 CLX_CIA_CLASSIFY_KEY_MPLS :
                                                 mac/mpls/qos/pp_info/pkg/range_key
                                                 CLX_CIA_CLASSIFY_KEY_UDF  : pkg/range_key */
    clx_port_bitmap_t port_bmp;               /* port bitmap */
    clx_cia_mac_key_t mac_key;                /* mac key */
    clx_cia_arp_key_t arp_key;                /* arp key */
    clx_cia_ipv4_key_t ipv4_key;              /* ipv4 key */
    clx_cia_ipv6_key_t ipv6_key;              /* ipv6 key */
    clx_cia_mpls_key_t mpls_key;              /* mpls key */
    clx_cia_l3_other_key_t l3_other_key;      /* l3 other key [CLX84 only] */
    clx_cia_qos_key_t qos_key;                /* qos key */
    clx_cia_pp_info_key_t pp_info_key;        /* pp info key */
    clx_cia_pkg_key_t pkg_key;                /* pkg key */
    uint32 udf_key_prof_id;                   /* udf key profile id */
    uint32 udf_key_prof_id_msk;               /* udf key profile id mask */
    uint32 range_bmp;                         /* range bitmap */
    uint32 range_bmp_msk;                     /* range bitmap mask */
    uint32 range_union_bmp;                   /* range union bitmap, [CLX84 only] */
    uint32 range_union_bmp_msk;               /* range union bitmap mask, [CLX84 only] */
    uint32 flags;                             /* clx_cia_classify_flags_t */
} clx_cia_classify_t;

#define CLX_CIA_CLASSIFY_FLAGS_MAC_KEY (1U << 0) /* mac key flag, depends on classify_key_type */
#define CLX_CIA_CLASSIFY_FLAGS_ARP_KEY (1U << 1) /* arp key flag, depends on classify_key_type */
#define CLX_CIA_CLASSIFY_FLAGS_IPV4_KEY                                                         \
    (1U << 2)                                    /* ipv4 key flag, depends on classify_key_type \
                                                  */
#define CLX_CIA_CLASSIFY_FLAGS_IPV6_KEY                                                         \
    (1U << 3)                                    /* ipv6 key flag, depends on classify_key_type \
                                                  */
#define CLX_CIA_CLASSIFY_FLAGS_MPLS_KEY                                                         \
    (1U << 4)                                    /* mpls key flag, depends on classify_key_type \
                                                  */
#define CLX_CIA_CLASSIFY_FLAGS_QOS_KEY (1U << 5) /* qos key flag, depends on classify_key_type */
#define CLX_CIA_CLASSIFY_FLAGS_PP_INFO_KEY                                       \
    (1U << 6)                                    /* pp info key flag, depends on \
                                               classify_key_type */
#define CLX_CIA_CLASSIFY_FLAGS_PKG_KEY (1U << 7) /* pkg key flag, depends on classify_key_type */
#define CLX_CIA_CLASSIFY_FLAGS_RANGE_KEY \
    (1U << 8)                                    /* range key flag, depends on classify_key_type */
#define CLX_CIA_CLASSIFY_FLAGS_UDF_VLD (1U << 9) /* udf key flag, depends on classify_key_type */
#define CLX_CIA_CLASSIFY_FLAGS_PORT_BMP_VLD                                          \
    (1U << 10)                                   /* port bitmap key flag, depends on \
                                                       classify_key_type */
#define CLX_CIA_CLASSIFY_FLAGS_L3_OTHER_KEY    (1U << 11) /* l3 other key flag [CLX84 only] */
#define CLX_CIA_CLASSIFY_FLAGS_RANGE_UNION_KEY (1U << 12) /* range union key flag, [CLX84 only]*/
typedef struct clx_cia_exact_pkg_key_s {
    boolean l2_sa_grp_lbl_vld;
    uint32 l2_sa_grp_lbl;   /* mt:10 bits, l2 source address group label */
    boolean l2_da_grp_lbl_vld;
    uint32 l2_da_grp_lbl;   /* mt:10 bits, l2 destination address group label */
    boolean l3_sa_grp_lbl_vld;
    uint32 l3_sa_grp_lbl;   /* mt:16 bits, l3 source address group label */
    boolean l3_da_grp_lbl_vld;
    uint32 l3_da_grp_lbl;   /* mt:16 bits, l3 destination address group label */
    boolean intf_grp_lbl_vld;
    uint32 intf_grp_lbl;    /* mt:16 bits, local interface group label*/
    boolean igr_cia_grp_lbl_vld;
    uint32 igr_cia_grp_lbl; /* 12 bits, ingress cia search group label */
    boolean vrf_vld;
    uint32 vrf;             /* 13 bits, virtual routing forwarding index */
    boolean bdid_vld;
    uint32 bdid;            /* 14 bits, bridge domain index */
    boolean tcp_flag_vld;
    uint32 tcp_flag;        /* 12 bits, tcp flag */

    boolean svid_vld;
    uint16 svid;                        /* service vlan id */
    boolean spcp_vld;
    uint8 spcp;                         /* service vlan pcp */
    boolean sdei_vld;
    uint8 sdei;                         /* service vlan dei */
    boolean cvid_vld;
    uint16 cvid;                        /* custom vlan id */
    boolean cpcp_vld;
    uint8 cpcp;                         /* custom vlan pcp */
    boolean cdei_vld;
    uint8 cdei;                         /* custom vlan dei */

    uint32 pkg_cnt;                     /* pkg key byte count */
    uint32 data[CLX_CIA_EXACT_PKG_NUM]; /* pkg key data */

    uint32 flags_vld;                   /* clx_cia_exact_pkg_key_flags_xxx */
    uint32 flags;                       /* clx_cia_exact_pkg_key_flags_xxx */
} clx_cia_exact_pkg_key_t;

#define CLX_CIA_EXACT_PKG_KEY_FLAGS_VLAN_TAG_MODE_1Q \
    (1U << 0) /* indicates cvid/cpcp/cdei is in 1'st or 2'nd vlan */
#define CLX_CIA_EXACT_PKG_KEY_FLAGS_L3_ROUTE    (1U << 1) /* is l3 route */
#define CLX_CIA_EXACT_PKG_KEY_FLAGS_L3_ROUTE_EN (1U << 2) /* is l3 route enable */

typedef struct clx_cia_exact_arp_key_s {
    boolean sender_mac_vld;
    clx_mac_t sender_mac;                /* sender mac */
    boolean target_mac_vld;
    clx_mac_t target_mac;                /* target mac */
    boolean sender_ip_vld;
    clx_ipv4_t sender_ip;                /* sender ip address */
    boolean target_ip_vld;
    clx_ipv4_t target_ip;                /* target ip address */
    boolean arp_frm_type_vld;
    clx_cia_arp_frm_type_t arp_frm_type; /* arp frame type */
    uint16 opcode;                       /* arp opcode [CLX84 only]*/
    boolean opcode_vld;                  /* arp opcode valid [CLX84 only] */
    boolean sender_mac_eq_smac;          /* sender mac equals smac [CLX84 only] */
    boolean sender_mac_eq_smac_vld;      /* sender mac equals smac valid [CLX84 only] */
    boolean target_mac_eq_dmac;          /* target mac equals dmac [CLX84 only] */
    boolean target_mac_eq_dmac_vld;      /* target mac equals dmac valid [CLX84 only] */
} clx_cia_exact_arp_key_t;

typedef struct clx_cia_exact_mac_key_s {
    clx_mac_t dmac;                        /* destination mac */
    boolean dmac_vld;                      /* destination mac valid */
    clx_mac_t smac;                        /* source mac */
    boolean smac_vld;                      /* source mac valid */
    uint16 ether_type;                     /* ether type */
    boolean ether_type_vld;                /* ether type valid */
    uint16 outvlan_id;                     /* outer vlan id */
    boolean outvlan_vld;                   /* outer vlan id valid */
    uint16 invlan_id;                      /* inner vlan id */
    boolean invlan_vld;                    /* inner vlan id valid */
    clx_cia_pkt_vlan_type_t pkt_vlan_type; /* packet vlan tag type */
    uint8 skip0_tag;                       /* skip0_tag {vld, idx} */
    boolean skip0_tag_vld;                 /* skip0_tag valid */
    uint8 skip1_tag;                       /* skip1_tag {vld, idx} */
    boolean skip1_tag_vld;                 /* skip1_tag valid */
    uint32 vm_tag;                         /* vm_tag vm_type:2bit, svif:20bit */
    boolean vm_tag_vld;                    /* vm_tag valid */
    uint32 flags;                          /* CLX_CIA_MAC_KEY_FLAGS_XXX flags */
} clx_cia_exact_mac_key_t;

#define CLX_CIA_EXACT_MAC_KEY_FLAGS_PKT_VLAN_TYPE_VLD (1U << 0) /* packet vlan tag type flag */
/* indicates ctag_valid is in 1'st or 2'nd vlan [CLX86 only] */
#define CLX_CIA_EXACT_MAC_KEY_FLAGS_VLAN_TAG_MODE_1Q (1U << 1)

typedef struct clx_cia_exact_ipv4_key_s {
    boolean dip_vld;
    clx_ipv4_t dip;         /* destination ip address */
    boolean sip_vld;
    clx_ipv4_t sip;         /* source ip address */
    boolean proto_vld;
    uint8 proto;            /* ip protocol */
    boolean dst_port_vld;
    uint16 dst_port;        /* l4 destination port */
    boolean src_port_vld;
    uint16 src_port;        /* l4 source port */
    boolean tcp_flag_vld;
    uint16 tcp_flag;        /* tcp flag, mt: 12bits */
    boolean icmp_type_vld;
    uint8 icmp_type;        /* icmp type value */
    boolean icmp_code_vld;
    uint8 icmp_code;        /* icmp code value */
    boolean igmp_type_vld;
    uint8 igmp_type;        /* igmp type value */
    boolean ttl_vld;
    uint8 ttl;              /* ttl value CLX84 only*/
    boolean frg_type_vld;
    clx_cia_frg_t frg_type; /* ip fragment type */
    boolean ttl_type_vld;
    clx_cia_ttl_t ttl_type; /* ttl type */

    uint32 flags;           /* CLX_CIA_IPV4_KEY_XXX flags */
} clx_cia_exact_ipv4_key_t;

#define CLX_CIA_EXACT_IPV4_KEY_FLAGS_AUTH_HDR_EXIST                                              \
    (1U << 0)                                                /* Authentication header exist flag \
                                                              */
#define CLX_CIA_EXACT_IPV4_KEY_FLAGS_OPT_HDR_EXIST (1U << 1) /* option header exist flag */
#define CLX_CIA_EXACT_IPV4_KEY_FLAGS_L3_ADDR_SWAP  (1U << 2) /* l3 address swap flag CLX84 only*/
#define CLX_CIA_EXACT_IPV4_KEY_FLAGS_L4_ADDR_SWAP  (1U << 3) /* l4 address swap flag CLX84 only*/
typedef struct clx_cia_exact_ipv6_key_s {
    boolean dip_vld;
    clx_ipv6_t dip;                            /* destination ip address */
    boolean sip_vld;
    clx_ipv6_t sip;                            /* source ip address */
    boolean proto_vld;
    uint8 proto;                               /* ip protocol */
    boolean dst_port_vld;
    uint16 dst_port;                           /* l4 destination port */
    boolean src_port_vld;
    uint16 src_port;                           /* l4 source port */
    boolean tcp_flag_vld;
    uint16 tcp_flag;                           /* tcp flag, mt: 12bits */
    boolean icmp_type_vld;
    uint8 icmp_type;                           /* icmp type value */
    boolean icmp_code_vld;
    uint8 icmp_code;                           /* icmp code value */
    boolean igmp_type_vld;
    uint8 igmp_type;                           /* igmp type value */
    boolean ttl_vld;
    uint8 ttl;                                 /* ttl value CLX84 only*/
    boolean frg_type_vld;
    clx_cia_frg_t frg_type;                    /* ip fragment type */
    boolean ttl_type_vld;
    clx_cia_ttl_t ttl_type;                    /* ttl type */
    boolean flow_label_vld;
    uint16 flow_label;                         /* flow label */
    boolean opt0_hdr_type_vld;                 /* option 0 header type valid */
    clx_cia_ipv6_opt_hdr_type_t opt0_hdr_type; /* option 0 header type */
    boolean opt1_hdr_type_vld;                 /* option 1 header type valid */
    clx_cia_ipv6_opt_hdr_type_t opt1_hdr_type; /* option 1 header type */

    uint32 flags;                              /* CLX_CIA_IPV6_KEY_XXX flags */
} clx_cia_exact_ipv6_key_t;
#define CLX_CIA_EXACT_IPV6_KEY_FLAGS_OPT0_HDR_TYPE_VLD \
    (1U << 0) /* Option 0 header exist flag, CLX84 only */
#define CLX_CIA_EXACT_IPV6_KEY_FLAGS_OPT1_HDR_TYPE_VLD \
    (1U << 1) /* Option 1 header exist flag, CLX84 only */
#define CLX_CIA_EXACT_IPV6_KEY_FLAGS_L3_ADDR_SWAP (1U << 2) /* l3 address swap flag CLX84 only*/
#define CLX_CIA_EXACT_IPV6_KEY_FLAGS_L4_ADDR_SWAP (1U << 3) /* l4 address swap flag CLX84 only*/
typedef struct clx_cia_exact_mpls_key_s {
    boolean lbl0_vld;
    uint32 lbl0;            /* MPLS label 0 */
    boolean lbl1_vld;
    uint32 lbl1;            /* MPLS label 1 */
    boolean lbl2_vld;
    uint32 lbl2;            /* MPLS label 2 */
    boolean lbl3_vld;
    uint32 lbl3;            /* MPLS label 3 */
    boolean ttl_type_vld;
    clx_cia_ttl_t ttl_type; /* ttl type */
    uint8 ttl;              /* ttl value [CLX84 only]*/
    boolean ttl_vld;
    uint8 lbl_num;          /* label number [CLX84 only]*/
    boolean lbl_num_vld;
    uint8 nibble;           /* nibble value [CLX84 only]*/
    boolean nibble_vld;
    boolean bos;            /* bottom of stack detected flag [CLX84 only]*/
    boolean bos_vld;
} clx_cia_exact_mpls_key_t;

typedef struct clx_cia_exact_qos_key_s {
    boolean pcp_vld;
    uint8 pcp;         /* 1q:cvlan pcp, 1ad: svlan pcp if svlan exists; otherwise, cvlan pcp.*/
    boolean dei_vld;
    uint8 dei;         /* 1q:cvlan dei, 1ad: svlan dei if svlan exists; otherwise, cvlan dei.*/
    boolean dscp_vld;
    uint8 dscp;        /* dscp for l3 packet */
    boolean ecn_vld;
    uint8 ecn;         /* ecn for l3 packet */
    boolean tc_vld;
    uint8 tc;          /* tc */
    boolean color_vld;
    clx_color_t color; /* color type */
    uint32 flags;
} clx_cia_exact_qos_key_t;

#define CLX_CIA_EXACT_QOS_KEY_FLAGS_PCP_DEI  (1U << 0) /* vlan pcp/dei */
#define CLX_CIA_EXACT_QOS_KEY_FLAGS_DSCP_ECN (1U << 1) /* dscp/ecn flag */
#define CLX_CIA_EXACT_QOS_KEY_FLAGS_TC_COLOR (1U << 2) /* enable both tc and color flag */

typedef struct clx_cia_exact_pp_info_key_s {
    uint32 intf_grp_lbl;    /* mt: 16 bits, local interface group label*/
    boolean intf_grp_lbl_vld;
    uint32 igr_cia_grp_lbl; /* mt: 16 bits, ingress cia search group label, egress match only */
    boolean igr_cia_grp_lbl_vld;
    uint32 l2_da_grp_lbl;   /* mt: 10 bits, l2 destination address group label */
    boolean l2_da_grp_lbl_vld;
    uint32 l2_sa_grp_lbl;   /* mt: 10 bits, l2 source address group label */
    boolean l2_sa_grp_lbl_vld;
    uint32 l3_da_grp_lbl;   /* mt: 10 bits need to enable
                             * CLX_CIA_GRP_FORMAT_BASE_LBL_REPLACE_DA, l3 destination
                             * address group label */
    boolean l3_da_grp_lbl_vld;
    uint32 l3_sa_grp_lbl;   /* mt: 10 bits need to enable
                             * CLX_CIA_GRP_FORMAT_BASE_LBL_REPLACE_SA, l3 source
                             * address group label */
    boolean l3_sa_grp_lbl_vld;
    uint32 bdid;            /* Ingress : match ingress fdid
                               Egress  : match egress bdid, must match flags_l3_route=0 simultaneously */
    boolean bdid_vld;

    uint32 vrf_id; /* mt: 13 bits, virtual routing forwarding index, ingress only [CLX84 only] */
    boolean vrf_id_vld;

    uint32 port; /* port id [CLX84 only] */
    boolean port_vld;

    clx_cia_src_idx_t src_idx; /* source index, ingress only [CLX84 only]*/
    boolean src_idx_vld;

    uint32 flags; /* clx_cia_pp_info_key_flags_xxx */
} clx_cia_exact_pp_info_key_t;

#define CLX_CIA_EXACT_PP_INFO_KEY_FLAGS_L3_ROUTE (1U << 1) /* is l3 route flag */
#define CLX_CIA_EXACT_PP_INFO_KEY_FLAGS_TNL_TERM (1U << 2) /* is tunnel decap pass flag */
/* indicates cvid/ctag_valid is in 1'st or 2'nd vlan */
#define CLX_CIA_EXACT_PP_INFO_KEY_FLAGS_VLAN_TAG_MODE_1Q (1U << 3)
#define CLX_CIA_EXACT_PP_INFO_KEY_FLAGS_STAG_VLD         (1U << 4) /* stag valid */
#define CLX_CIA_EXACT_PP_INFO_KEY_FLAGS_CTAG_VLD         (1U << 5) /* ctag valid */

typedef struct clx_cia_exact_l3_other_key_s {
    boolean pld_0_vld;
    uint32 pld_0; /* L3 other payload 0 */
    boolean pld_1_vld;
    uint32 pld_1; /* L3 other payload 1 */
    boolean pld_2_vld;
    uint32 pld_2; /* L3 other payload 2 */
    boolean pld_3_vld;
    uint32 pld_3; /* L3 other payload 3 */
    boolean pld_4_vld;
    uint32 pld_4; /* L3 other payload 4 */
    boolean pld_5_vld;
    uint32 pld_5; /* L3 other payload 5 */
    boolean pld_6_vld;
    uint32 pld_6; /* L3 other payload 6 */
    boolean pld_7_vld;
    uint32 pld_7; /* L3 other payload 7 */
    boolean pld_8_vld;
    uint32 pld_8; /* L3 other payload 8 */
    boolean pld_9_vld;
    uint32 pld_9; /* L3 other payload 9 */
    uint32 flags; /* CLX_CIA_L3_OTHER_KEY_XXX flags, unused for now */
} clx_cia_exact_l3_other_key_t;
typedef struct clx_cia_exact_classify_s {
    clx_cia_classify_key_t classify_key_type;  /* CLX_CIA_CLASSIFY_KEY_MAC  :
                                                  mac/qos/pp_info/pkg/range_key
                                                  CLX_CIA_CLASSIFY_KEY_ARP  :
                                                  mac/arp/qos/pp_info/pkg/range_key
                                                  CLX_CIA_CLASSIFY_KEY_IPV4 :
                                                  mac/ipv4/qos/pp_info/pkg/range_key
                                                  CLX_CIA_CLASSIFY_KEY_IPV6 :
                                                  mac/ipv6/qos/pp_info/pkg/range_key
                                                  CLX_CIA_CLASSIFY_KEY_MPLS :
                                                  mac/mpls/qos/pp_info/pkg/range_key
                                                  CLX_CIA_CLASSIFY_KEY_UDF  : pkg/range_key
                                                  [CLX84 only]*/
    uint32 udf_key_prof_id;                    /* udf entry id */
    clx_cia_exact_pkg_key_t pkg_key;           /* pkg key */
    clx_cia_exact_mac_key_t mac_key;           /* mac key, [CLX84 only] */
    clx_cia_exact_arp_key_t arp_key;           /* arp key, [CLX84 only] */
    clx_cia_exact_ipv4_key_t ipv4_key;         /* ipv4 key, [CLX84 only] */
    clx_cia_exact_ipv6_key_t ipv6_key;         /* ipv6 key, [CLX84 only] */
    clx_cia_exact_mpls_key_t mpls_key;         /* mpls key, [CLX84 only] */
    clx_cia_exact_qos_key_t qos_key;           /* qos key, [CLX84 only] */
    clx_cia_exact_pp_info_key_t pp_info_key;   /* pp info key, [CLX84 only] */
    clx_cia_exact_l3_other_key_t l3_other_key; /* l3 other key, [CLX84 only] */
    uint32 range_bmp;
    uint32 range_union_bmp;                    /* range union bitmap, [CLX84 only]*/
    uint32 flags;                              /* clx_cia_exact_classify_flags_xxx */
    uint32 logic_tile;
    uint32 select_key_prof_id;                 /* exact entry select key profile id [CLX84 only] */
} clx_cia_exact_classify_t;

#define CLX_CIA_EXACT_CLASSIFY_FLAGS_RANGE_KEY      (1U << 0)
#define CLX_CIA_EXACT_CLASSIFY_FLAGS_ADD_LOGIC_TILE (1U << 1)
#define CLX_CIA_EXACT_CLASSIFY_FLAGS_PORT_BMP_VLD   (1U << 2) /* CLX86 unsupport */
#define CLX_CIA_EXACT_CLASSIFY_FLAGS_SELECT_KEY_VLD \
    (1U << 3) /* exact entry select key profile id valid [CLX84 only] */
#define CLX_CIA_EXACT_CLASSIFY_FLAGS_UDF_VLD (1U << 4)       /* udf profile valid [CLX84 only] */

#define CLX_CIA_EXACT_CLASSIFY_FLAGS_MAC_KEY      (1U << 5)  /* mac key flag , [CLX84 only]*/
#define CLX_CIA_EXACT_CLASSIFY_FLAGS_ARP_KEY      (1U << 6)  /* arp key flag , [CLX84 only]*/
#define CLX_CIA_EXACT_CLASSIFY_FLAGS_IPV4_KEY     (1U << 7)  /* ipv4 key flag , [CLX84 only]*/
#define CLX_CIA_EXACT_CLASSIFY_FLAGS_IPV6_KEY     (1U << 8)  /* ipv6 key flag , [CLX84 only]*/
#define CLX_CIA_EXACT_CLASSIFY_FLAGS_MPLS_KEY     (1U << 9)  /* mpls key flag , [CLX84 only]*/
#define CLX_CIA_EXACT_CLASSIFY_FLAGS_QOS_KEY      (1U << 10) /* qos key flag , [CLX84 only]*/
#define CLX_CIA_EXACT_CLASSIFY_FLAGS_PP_INFO_KEY  (1U << 11) /* pp info key flag , [CLX84 only]*/
#define CLX_CIA_EXACT_CLASSIFY_FLAGS_L3_OTHER_KEY (1U << 12) /* l3 other key flag , [CLX84 only]*/
#define CLX_CIA_EXACT_CLASSIFY_FLAGS_RANGE_UNION_KEY \
    (1U << 13)                                               /* range union key flag, [CLX84 only]*/

typedef struct clx_cia_qos_act_s {
    uint8 pcp;         /* remark pcp */
    uint8 dei;         /* remark dei */
    uint8 dscp;        /* remark dscp */
    uint8 ecn;         /* remark ecn */
    uint8 exp;         /* remark exp */
    uint8 tc;          /* remark tc */
    clx_color_t color; /* remark color */
    uint32 flags;      /* CLX_CIA_QOS_ACT_FLAGS_XXX */
} clx_cia_qos_act_t;

#define CLX_CIA_QOS_ACT_FLAGS_REMARK_PCP (1U << 0) /* remark pcp flag [pre cia, ecia]*/
#define CLX_CIA_QOS_ACT_FLAGS_REMARK_DEI (1U << 1) /* remark dei flag [pre cia, ecia]*/
#define CLX_CIA_QOS_ACT_FLAGS_REMARK_DSCP \
    (1U << 2) /* remark dscp flag, egress only [CLX84 exp = dscp] */
#define CLX_CIA_QOS_ACT_FLAGS_REMARK_ECN   (1U << 3) /* remark ecn flag */
#define CLX_CIA_QOS_ACT_FLAGS_REMARK_EXP   (1U << 4) /* remark exp flag, egress only [CLX86 only] */
#define CLX_CIA_QOS_ACT_FLAGS_REMARK_TC    (1U << 5) /* remark tc flag [icia, pre cia]*/
#define CLX_CIA_QOS_ACT_FLAGS_REMARK_COLOR (1U << 6) /* remark color flag [icia, pre cia]*/
#define CLX_CIA_QOS_ACT_FLAGS_DROP         (1U << 7) /* per qos color decision drop forward flag */
/* qos do not modify, ingress only */
#define CLX_CIA_QOS_ACT_FLAGS_QOS_DO_NOT_MODIFY (1U << 9)

typedef enum clx_cia_redir_e {
    CLX_CIA_REDIR_L2_UC,   /* redirect to L2 unicast */
    CLX_CIA_REDIR_L3_UC,   /* redirect to L3 unicast */
    CLX_CIA_REDIR_L3_ECMP, /* redirect to L3 ecmp group */
    CLX_CIA_REDIR_L2_MC,   /* redirect to L2 multicast group */
    CLX_CIA_REDIR_L3_MC,   /* redirect to L3 multicast group */
    CLX_CIA_REDIR_L3_MPLS, /* redirect to L25 mpls */
    CLX_CIA_REDIR_CPU,     /* redirect to cpu port, use cpu reason to redirect */
    CLX_CIA_REDIR_DROP_DI, /* redirect to drop di */
    CLX_CIA_REDIR_LAST
} clx_cia_redir_t;

typedef struct clx_cia_redir_act_s {
    clx_cia_redir_t redir_type;
    clx_port_t port;                  /* used for L2_UC */
    clx_bridge_domain_t bdid;         /* used for L2_UC(nv) */
    uint32 adj_id;                    /* used for L3_UC */
    uint32 ecmp_grp_id;               /* used for L3_ECMP */
    uint32 mcast_id;                  /* used for L2/L3_MC */
    uint32 swap_lbl;                  /* used for L25 MPLS */
    clx_pkt_rx_rsn_bmp_t cpu_rsn_bmp; /* used for CPU */
    uint32 redir_idx;                 /* redirect idx */
    uint32 flags;                     /* CLX_CIA_REDIR_ACT_FLAGS_XXX */
} clx_cia_redir_act_t;

#define CLX_CIA_REDIR_ACT_FLAGS_BYPASS_PRUNE (1U << 0) /* used for L2_UC */
#define CLX_CIA_REDIR_ACT_FLAGS_SWAP_LBL     (1U << 1) /* used for L25 */
/* used for index mode, if the index contains the behavior of redirecting BDID,
need to set flag CLX_ACL_REDIRECT_ACTION_FLAGS_REDIR_WITH_BDID */
#define CLX_CIA_REDIR_ACT_FLAGS_INDEX_MODE (1U << 2)
/* redirect with bdid assigned, valid on L2_UC/L2_MC/L3_MC */
#define CLX_CIA_REDIR_ACT_FLAGS_REDIR_WITH_BDID (1U << 3)
/*
 * Instruction Sequencing Guidelines:
 * 1. ADD should precede DEL when modifying the same offset.
 * 2. The offsets of ADD and DEL operations should be in ascending order.
 *    Example:
 *      ADD 12, DEL 16, ADD 16, DEL 20, ADD 20
 * 3. REP operation windows cannot overlap.
 *    Example:
 *      {REP 12, length 4} and {REP 14, length 4} are not allowed.
 */
typedef enum clx_cia_fcm_act_e {
    CLX_CIA_FCM_DEL = 1,      /* del packet info */
    CLX_CIA_FCM_ADD,          /* add packet info */
    CLX_CIA_FCM_SET,          /* replace packet info */
    CLX_CIA_FCM_SET_WITH_MSK, /* replace packet info with mask */
    CLX_CIA_FCM_LAST
} clx_cia_fcm_act_t;

typedef enum clx_cia_fcm_type_e {
    CLX_CIA_FCM_TYPE_UDF = 0,     /* User define tlv format */
    CLX_CIA_FCM_TYPE_CVLAN,       /* CLX_CIA_FCM_SET_WITH_MSK 2Bytes, custom vlan */
    CLX_CIA_FCM_TYPE_SVLAN,       /* CLX_CIA_FCM_SET_WITH_MSK 2Bytes, service vlan */
    CLX_CIA_FCM_TYPE_SRC_MAC_HI,  /* CLX_CIA_FCM_SET 2Bytes, source mac address
                                         high */
    CLX_CIA_FCM_TYPE_SRC_MAC_LO,  /* CLX_CIA_FCM_SET 4Bytes, source mac address low */
    CLX_CIA_FCM_TYPE_DST_MAC_HI,  /* CLX_CIA_FCM_SET 2Bytes, destination mac
                                         address high */
    CLX_CIA_FCM_TYPE_DST_MAC_LO,  /* CLX_CIA_FCM_SET 4Bytes, destination mac address low */
    CLX_CIA_FCM_TYPE_SRC_IPV4,    /* CLX_CIA_FCM_SET 4Bytes, source IPv4 address */
    CLX_CIA_FCM_TYPE_DST_IPV4,    /* CLX_CIA_FCM_SET 4Bytes, destination IPv4 address */
    CLX_CIA_FCM_TYPE_SRC_IPV6_0,  /* CLX_CIA_FCM_SET 4Bytes, source IPv6 address 0 */
    CLX_CIA_FCM_TYPE_SRC_IPV6_1,  /* CLX_CIA_FCM_SET 4Bytes, source IPv6 address 1*/
    CLX_CIA_FCM_TYPE_SRC_IPV6_2,  /* CLX_CIA_FCM_SET 4Bytes, source IPv6 address 2*/
    CLX_CIA_FCM_TYPE_SRC_IPV6_3,  /* CLX_CIA_FCM_SET 4Bytes, source IPv6 address 3*/
    CLX_CIA_FCM_TYPE_DST_IPV6_0,  /* CLX_CIA_FCM_SET 4Bytes, destination IPv6 address 0 */
    CLX_CIA_FCM_TYPE_DST_IPV6_1,  /* CLX_CIA_FCM_SET 4Bytes, destination IPv6 address 1 */
    CLX_CIA_FCM_TYPE_DST_IPV6_2,  /* CLX_CIA_FCM_SET 4Bytes, destination IPv6 address 2 */
    CLX_CIA_FCM_TYPE_DST_IPV6_3,  /* CLX_CIA_FCM_SET 4Bytes, destination IPv6 address 3 */
    CLX_CIA_FCM_TYPE_TOS_IPV4,    /* CLX_CIA_FCM_SET_WITH_MSK 1Byte, IPv4 TOS */
    CLX_CIA_FCM_TYPE_TOS_IPV6,    /* CLX_CIA_FCM_SET_WITH_MSK 1Byte, IPv6 TOS */
    CLX_CIA_FCM_TYPE_L4_SRC_PORT, /* CLX_CIA_FCM_SET 2Bytes, l4 source port */
    CLX_CIA_FCM_TYPE_L4_DST_PORT, /* CLX_CIA_FCM_SET 2Bytes, l4 destination port */
    CLX_CIA_FCM_TYPE_SI,          /* CLX_CIA_FCM_ADD/SET 2Bytes/4Bytes, source index [CLX84 only] */
    CLX_CIA_FCM_TYPE_SRC_BD,      /* CLX_CIA_FCM_ADD/SET 2Bytes/4Bytes, source bd [CLX84 only] */
    CLX_CIA_FCM_TYPE_MIR_DIR, /* CLX_CIA_FCM_ADD/SET 2Bytes/4Bytes, mirror direction [CLX84 only] */
    CLX_CIA_FCM_TYPE_ITS_H_32, /* CLX_CIA_FCM_ADD/SET 2Bytes/4Bytes, igress timestamp high 32 [CLX84
                                  only] */
    CLX_CIA_FCM_TYPE_ITS_L_32, /* CLX_CIA_FCM_ADD/SET 2Bytes/4Bytes, igress timestamp low 32 [CLX84
                                  only] */
    CLX_CIA_FCM_TYPE_ETS_H_32, /* CLX_CIA_FCM_ADD/SET 2Bytes/4Bytes, egress timestamp high 32 [CLX84
                                  only] */
    CLX_CIA_FCM_TYPE_ETS_L_32, /* CLX_CIA_FCM_ADD/SET 2Bytes/4Bytes, egress timestamp low 32 [CLX84
                                  only] */
    CLX_CIA_FCM_TYPE_LATENCY,  /* CLX_CIA_FCM_ADD/SET 2Bytes/4Bytes, latency [CLX84 only] */
    CLX_CIA_FCM_TYPE_TAP_STRIP, /* CLX_CIA_FCM_DEL 0Byte, tap strip, remove outer but keep l2 [CLX84
                                 * only]
                                 */
    CLX_CIA_FCM_TYPE_MODIFY, /* CLX_CIA_FCM_SET 1/2/3/4Bytes, modify packet data at specified offset
                                [CLX84 only] */
    CLX_CIA_FCM_TYPE_REPAIR, /* CLX_CIA_FCM_ADD/SET/SET_WITH_MSK 2/4Bytes, repair packet data
                              * according to data from other offset [CLX84 only]
                              */
    CLX_CIA_FCM_TYPE_LAST
} clx_cia_fcm_type_t;

typedef enum clx_cia_fcm_data_op_type_e {
    CLX_CIA_FCM_DATA_OP_TYPE_NONE = 0, /* none */
    CLX_CIA_FCM_DATA_OP_TYPE_ADD,      /* add */
    CLX_CIA_FCM_DATA_OP_TYPE_MINUS,    /* minus */
    CLX_CIA_FCM_DATA_OP_TYPE_R_SHIFT,  /* right shift */
    CLX_CIA_FCM_DATA_OP_TYPE_L_SHIFT,  /* left shift */
    CLX_CIA_FCM_DATA_OP_TYPE_OR,       /* or */
    CLX_CIA_FCM_DATA_OP_TYPE_AND,      /* and */
    CLX_CIA_FCM_DATA_OP_TYPE_LAST
} clx_cia_fcm_data_op_type_t;

typedef struct clx_cia_fcm_modify_s {
    clx_cia_fcm_data_op_type_t op_type; /* packet data do operation with op_val */
    uint8 op_val;                       /* operated value */
} clx_cia_fcm_modify_t;

typedef struct clx_cia_fcm_repair_s {
    clx_cia_pkg_base_t src_pkg_base_type; /* source packet base type */
    uint32 src_byte_offset;               /* value should be multiple of two bytes */
    uint32 src_byte_cnt;                  /* value should be 1/2/3/4 bytes */
    clx_cia_fcm_data_op_type_t op_type;   /* packet data do operation with op_val */
    uint8 op_val;                         /* operated value */
} clx_cia_fcm_repair_t;

typedef struct clx_cia_fcm_cfg_s {
    clx_cia_fcm_type_t fcm_type;      /* udf or internal pre-define offset*/
    clx_cia_fcm_act_t type;           /* fcm action type */
    clx_cia_pkg_base_t pkg_base_type; /* fcm base type */
    uint32 byte_offset; /* value should be multiple of two bytes, and offsets must maintain
                         * ascending sequence when deleting or adding packet information
                         */
    uint32 byte_cnt;    /* value should be multiple of two bytes; 1/2/3/4 bytes when modify;
                         * value can be 8 bytes when delete [CLX84 only] */
    uint8 data[CLX_CIA_FCM_DATA_NUM];     /* fcm data */
    uint8 msk[CLX_CIA_FCM_DATA_NUM];      /* fcm data mask */
    union {
        clx_cia_fcm_modify_t modify_data; /* Data modification parameters for packet modification
                                             operations [CLX84 only] */
        clx_cia_fcm_repair_t repair_data; /* Data repair parameters for packet repair operations
                                             [CLX84 only] */
    };
    uint32 flags;                         /* CLX_CIA_FCM_CFG_FLAGS_XXX */
} clx_cia_fcm_cfg_t;

#define CLX_CIA_FCM_CFG_FLAGS_DEL_8_BYTES \
    (1U << 0) /* delete 8 bytes, valid on delete action [CLX84 only] */

typedef struct clx_cia_pkt_fcm_s {
    clx_cia_fcm_cfg_t fcm_cfg[CLX_CIA_FCM_NUM]; /* fcm config array, repair action occupies two fcm
                                                   resources */
    uint32 fcm_cnt;                             /* fcm config count */
    uint32 fcm_idx;                             /* index mode */
    uint32 flags;
} clx_cia_pkt_fcm_t;

#define CLX_CIA_PKT_FCM_FLAGS_IDX_MODE (1U << 0) /* FCM index mode */
#define CLX_CIA_PKT_FCM_FLAGS_NOP      (1U << 1) /* FCM NOP, used to conflict with other fcm */

typedef struct clx_cia_cmcc_ioam_s {
    uint8 delay;        /* 2 bits delay */
    uint8 color_enable; /* 1 bit color */
    uint16 flow_id;     /* flow id */
} clx_cia_cmcc_ioam_t;

typedef enum clx_cia_telm_type_e {
    CLX_CIA_TELM_TYPE_INT = 0,   /* INT */
    CLX_CIA_TELM_TYPE_CMCC_IOAM, /* CMCC IOAM */
    CLX_CIA_TELM_TYPE_LAST
} clx_cia_telm_type_t;

typedef struct clx_cia_telm_s {
    boolean enable;                  /* telemetry enable */
    clx_cia_telm_type_t type;        /* telemetry type */
    clx_cia_cmcc_ioam_t ioam_config; /* cmcc ioam config */
    uint8 int_prof_id;               /* int profile index */
} clx_cia_telm_t;

typedef enum clx_cia_mir_policer_type_e {
    CLX_CIA_MIR_POLICER_TYPE_MIR = 0, /* mirror policer type mirror */
    CLX_CIA_MIR_POLICER_TYPE_COPP,    /* mirror policer type copp */
    CLX_CIA_MIR_POLICER_TYPE_LAST
} clx_cia_mir_policer_type_t;

typedef enum clx_cia_mir_policer_act_e {
    CLX_CIA_MIR_POLICER_ACT_NONE = 0, /* No policer action */
    CLX_CIA_MIR_POLICER_ACT_DROP,     /* policer action drop */
    CLX_CIA_MIR_POLICER_ACT_LAST
} clx_cia_mir_policer_act_t;

typedef struct clx_cia_mir_policer_s {
    clx_cia_mir_policer_type_t type;      /* mirror policer type */
    clx_cia_mir_policer_act_t yellow_act; /* policer yellow action */
    uint32 meter_id;                      /* meter id */
} clx_cia_mir_policer_t;

typedef enum clx_cia_vid_ctrl_type_e {
    CLX_CIA_VID_TRY_POP_1, /* try to pop 1 tag [CLX86 only]*/
    CLX_CIA_VID_TRY_POP_2, /* try to pop 2 tags [CLX86 only]*/
    CLX_CIA_VID_TRY_POP_3, /* try to pop 3 tags [CLX86 only]*/
    CLX_CIA_VID_TRY_POP_4, /* try to pop 4 tags [CLX86 only]*/
    CLX_CIA_VID_KEEP_1,    /* keep 1 tag  [pre cia, icia]*/
    CLX_CIA_VID_KEEP_2,    /* keep 2 tags [pre cia, icia]*/
    CLX_CIA_VID_KEEP_ALL,  /* keep all tags [CLX86 only]*/
    CLX_CIA_VID_LAST
} clx_cia_vid_ctrl_type_t;

typedef enum clx_cia_vid_edit_type_e {
    CLX_CIA_VID_EDIT_TYPE_ASSIGN_VID = 0,      /* assign vid */
    CLX_CIA_VID_EDIT_TYPE_ASSIGN_VID_ADD_SVID, /* assign (vid + svid) */
    CLX_CIA_VID_EDIT_TYPE_ASSIGN_VID_ADD_CVID, /* assign (vid + cvid) */
    CLX_CIA_VID_EDIT_TYPE_LAST
} clx_cia_vid_edit_type_t;

typedef struct clx_cia_vid_edit_s {
    uint32 vid;                   /* vid */
    clx_cia_vid_edit_type_t type; /* edit type */
} clx_cia_vid_edit_t;

typedef struct clx_cia_vid_act_s {
    clx_cia_vid_ctrl_type_t vid_ctrl_type;
    boolean dflt_vid;        /*  default vlan set/clear [pre cia]*/
    clx_cia_vid_edit_t svid; /* svid edit [pre cia]*/
    clx_cia_vid_edit_t cvid; /* cvid edit [pre cia]*/
    uint32 flags;
} clx_cia_vid_act_t;

#define CLX_CIA_VID_ACT_FLAGS_PUSH_TRACING_VLAN (1U << 0) /* [ CLX86 only] */
#define CLX_CIA_VID_ACT_FLAGS_PUSH_RULE_VLAN    (1U << 1) /* [ CLX86 only] */
#define CLX_CIA_VID_ACT_FLAGS_VID_CTRL_VLD      (1U << 2) /* vid ctrl valid */
#define CLX_CIA_VID_ACT_FLAGS_DFLT_VID          (1U << 3) /* add default vid [pre cia, CLX84 only] */
#define CLX_CIA_VID_ACT_FLAGS_SVID              (1U << 4) /* svid [pre cia, CLX84 only] */
#define CLX_CIA_VID_ACT_FLAGS_CVID              (1U << 5) /* cvid [pre cia, CLX84 only] */

typedef enum clx_cia_assign_type_e {
    CLX_CIA_ASSIGN_TYPE_DI,  /* destination index */
    CLX_CIA_ASSIGN_TYPE_VNI, /* vni */
    CLX_CIA_ASSIGN_TYPE_BD,  /* bridge domain */
    CLX_CIA_ASSIGN_TYPE_VRF, /* vrf */
    CLX_CIA_ASSIGN_TYPE_LAST
} clx_cia_assign_type_t;

typedef struct clx_cia_pkg_val_s {
    uint32 pkg_idx;     /* pkg_idx 0-11, vni gets two consecutive UDF values from the pkg_idx. */
    uint32 pkg_val_rsh; /* pkg value right shift bits, 0-15, 0 means no shift, value is 32 bit */
    uint32 pkg_val_lsh; /* pkg value left shift bits, 0-15, 0 means no shift, value is 32 bit */
} clx_cia_pkg_val_t;

typedef struct clx_cia_assign_act_s {
    clx_cia_assign_type_t type;    /* assign type */
    union {
        clx_cia_pkg_val_t pkg_val; /* pkg value */
        uint32 val;                /* assign value */
    };
    uint32 flags;                  /* refer to CLX_CIA_ASSIGN_ACT_FLAGS_XXX */
} clx_cia_assign_act_t;

#define CLX_CIA_ASSIGN_ACT_FLAGS_PKG_AS_VAL (1U << 0) /* pkg as value */

typedef enum clx_cia_ecmp_type_e {
    CLX_CIA_ECMP_TYPE_AR,  /* AR */
    CLX_CIA_ECMP_TYPE_RR,  /* RR */
    CLX_CIA_ECMP_TYPE_FDL, /* FDL */
    CLX_CIA_ECMP_TYPE_LAST
} clx_cia_ecmp_type_t;

typedef enum clx_cia_gbp_sel_e {
    CLX_CIA_GBP_SEL_PRE_CIA_GRP_LBL = 1, /* pre cia group label */
    CLX_CIA_GBP_SEL_INTF_GRP_LBL,        /* interface group label */
    CLX_CIA_GBP_SEL_BD_GRP_LBL,          /* bridge domain group label */
    CLX_CIA_GBP_SEL_L2_SA_GRP_LBL,       /* l2 source address group label */
    CLX_CIA_GBP_SEL_L2_DA_GRP_LBL,       /* l2 destination address group label */
    CLX_CIA_GBP_SEL_L3_SA_GRP_LBL,       /* l3 source address group label */
    CLX_CIA_GBP_SEL_L3_DA_GRP_LBL,       /* l3 destination address group label */
    CLX_CIA_GBP_SEL_IGR_CIA_GRP_LBL,     /* ingress cia group label */
    CLX_CIA_GBP_SEL_LAST
} clx_cia_gbp_sel_t;

typedef struct clx_cia_hash_act_s {
    uint32 prof_id; /* hash profile id */
} clx_cia_hash_act_t;

typedef enum clx_cia_nfs_ipv6_addr_key_type_e {
    CLX_CIA_NFS_IPV6_ADDR_KEY_TYPE_WORD0, /* word0 [31:0] */
    CLX_CIA_NFS_IPV6_ADDR_KEY_TYPE_WORD1, /* word1 [63:32] */
    CLX_CIA_NFS_IPV6_ADDR_KEY_TYPE_WORD2, /* word2 [95:64] */
    CLX_CIA_NFS_IPV6_ADDR_KEY_TYPE_WORD3, /* word3 [127:96] */
    CLX_CIA_NFS_IPV6_ADDR_KEY_TYPE_LAST
} clx_cia_nfs_ipv6_addr_key_type_t;

typedef struct clx_cia_nfs_s {
    uint32 allow_num;                         /* allow number */
    clx_cia_nfs_ipv6_addr_key_type_t ipv6_sa; /* ipv6 sa key type */
    clx_cia_nfs_ipv6_addr_key_type_t ipv6_da; /* ipv6 da key type */
    uint32 nfs_key;                           /* nfs select key, refer to CLX_CIA_NFS_KEY_XX */
    uint32 mirror_id;                         /* mirror id */
    boolean act_to_mirror;                    /* action to mirror */
} clx_cia_nfs_t;

#define CLX_CIA_NFS_KEY_IP_DA             (1U << 0) /* dst ip key */
#define CLX_CIA_NFS_KEY_IP_SA             (1U << 1) /* src ip key */
#define CLX_CIA_NFS_KEY_DST_PORT          (1U << 2) /* dst port key */
#define CLX_CIA_NFS_KEY_SRC_PORT          (1U << 3) /* src port key */
#define CLX_CIA_NFS_KEY_L3_PROTO          (1U << 4) /* l3 proto key */
#define CLX_CIA_NFS_KEY_HASH0_TO_IP_DA    (1U << 5) /* hash0 to ip da key */
#define CLX_CIA_NFS_KEY_HASH1_TO_IP_SA    (1U << 6) /* hash1 to ip sa key */
#define CLX_CIA_NFS_KEY_HASH2_TO_DST_PORT (1U << 7) /* hash2 to dst port key */
#define CLX_CIA_NFS_KEY_HASH3_TO_SRC_PORT (1U << 8) /* hash3 to src port key */

typedef struct clx_cia_act_s {
    uint32 pri;                             /* value :
                                                    mt: 0-15, can only set to 0 for exact
                                                    1-15 for cia */
    boolean mod_en;                         /* mirror on drop enable, ingress only */
    uint32 mir_session_bmp;                 /* Mirror session ID bitmap */
    clx_sample_t sample;                    /* sample packet */
    uint32 meter_id;                        /* meter index */
    uint32 counter_id;                      /* counter index */
    uint32 dist_counter_id;                 /* distribution counter index */
    uint32 igr_cia_grp_lbl;                 /* write ingress cia group label */
    uint32 pre_cia_grp_lbl;                 /* write pre-cia group label [CLX84 only]*/
    uint32 nfs_id;                          /* nfs index [CLX84 only]*/
    uint32 nfe_id;                          /* nfe index [CLX84 only]*/
    uint32 hqos_queue_id;                   /* hqos queue id [CLX84 only]*/
    clx_cia_qos_act_t qos_act_color_blind;  /* color blind qos action */
    clx_cia_qos_act_t qos_act_color_yellow; /* color yellow qos action */
    clx_cia_qos_act_t qos_act_color_red;    /* color red qos action */
    clx_cia_qos_act_t qos_act_color_green;  /* color green qos action [CLX84 only] */
    clx_pkt_rx_rsn_bmp_t cpu_rsn_bmp;       /* can only set one bit of the bitmap */
    clx_cia_redir_act_t redir_act;          /* redirect action */
    clx_cia_pkt_fcm_t pkt_fcm;              /* packet fcm action */
    clx_cia_telm_t telm_act;                /* int/cmcc-ioam action */
    clx_cia_mir_policer_t mir_policer;      /* mirror policer */
    clx_cia_vid_act_t vid_act;              /* vid control action */
    clx_cia_assign_act_t assign;            /* assign action [pre cia, CLX84 only]*/
    clx_cia_ecmp_type_t ecmp_type;          /* ecmp type [pre cia, icia, CLX84 only]*/
    clx_cia_hash_act_t hash;                /* hash action [pre cia, CLX84 only]*/
    clx_cia_gbp_sel_t gbp_sel;              /* gbp select [CLX84 only]*/
    uint64 flags;                           /* refer to CLX_CIA_ACT_FLAGS_XX */
} clx_cia_act_t;

#define CLX_CIA_ACT_FLAGS_METER_VLD             (1ULL << 0) /* meter valid flag */
#define CLX_CIA_ACT_FLAGS_COUNTER_VLD           (1ULL << 1) /* counter valid flag */
#define CLX_CIA_ACT_FLAGS_DIST_COUNTER_VLD      (1ULL << 2) /* distribution counter valid flag */
#define CLX_CIA_ACT_FLAGS_CANCEL_LEARN          (1ULL << 3) /* ingress only */
#define CLX_CIA_ACT_FLAGS_BYPASS_RPF_CHECK_FAIL (1ULL << 4) /* ingress only */
#define CLX_CIA_ACT_FLAGS_COPY_TO_CPU           (1ULL << 5) /* copy to cpu action valid flag */
#define CLX_CIA_ACT_FLAGS_REDIR                 (1ULL << 6) /* redirect action, ingress only */
#define CLX_CIA_ACT_FLAGS_DROP                  (1ULL << 7) /* drop normal port/redirect to cpu packet */
#define CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_BLIND                                               \
    (1ULL << 8)                                             /* color blind qos action valid \
                                                             flag */
#define CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_YELLOW                                               \
    (1ULL << 9)                                             /* color yellow qos action valid \
                                                             flag */
#define CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_RED                                                    \
    (1ULL << 10)                                            /* color red qos action valid flag \
                                                             */
#define CLX_CIA_ACT_FLAGS_PKT_FCM                                                            \
    (1ULL << 11)                                    /* packet fcm action valid flag, ingress \
                                                     only */
#define CLX_CIA_ACT_FLAGS_BYPASS_TTL_CHECK_FAIL                                       \
    (1ULL << 12)                                    /* bypass ttl check fail, ingress \
                                               only */
#define CLX_CIA_ACT_FLAGS_KEEP_TTL                                                            \
    (1ULL << 13)                                    /* ingress only. If this flag is set, not \
                                                support redirect action */
#define CLX_CIA_ACT_FLAGS_TELM_ACT_VLD (1ULL << 14) /* telemetry action config valid flag */
#define CLX_CIA_ACT_FLAGS_XOR_LFSR                                                          \
    (1ULL << 15)                                    /* xor LFSR to final hash, ingress only \
                                                     */
#define CLX_CIA_ACT_FLAGS_ALLOW_TRUNCATE                                                \
    (1ULL << 16)                                    /* allow tm to do truncate, ingress \
                                                  only */
#define CLX_CIA_ACT_FLAGS_FORCE_DECAP                                                      \
    (1ULL << 17)                                    /* force remove outer IP/MPLS, ingress \
                                                 only */
#define CLX_CIA_ACT_FLAGS_MIR_POLICER_VLD                                         \
    (1ULL << 18)                                    /* Mirror policer valid, only \
                                                     */
#define CLX_CIA_ACT_FLAGS_VID_ACT_VLD                             \
    (1ULL << 19) /* Vid action valid, ingress only [pre cia,icia] \
                  */
#define CLX_CIA_ACT_FLAGS_ASSIGN \
    (1ULL << 20) /* assign action valid, pre cia only [pre cia, CLX84 only] */
#define CLX_CIA_ACT_FLAGS_ECMP_TYPE \
    (1ULL << 21) /* ecmp type action valid [pre cia, icia, CLX84 only]*/
#define CLX_CIA_ACT_FLAGS_HASH                                      \
    (1ULL << 22) /* hash action valid, pre cia only [pre cia, CLX84 \
                  only]*/
#define CLX_CIA_ACT_FLAGS_TCP_CPA_EN     (1ULL << 23) /* tcp cpa enable, [CLX84 only]*/
#define CLX_CIA_ACT_FLAGS_DI_TO_CPU_ONLY (1ULL << 24) /* di to cpu only, [CLX84 only]*/
#define CLX_CIA_ACT_FLAGS_ECN_EN         (1ULL << 25) /* ecn enable, [CLX84 only]*/
#define CLX_CIA_ACT_FLAGS_LAG_AR_EN      (1ULL << 26) /* lag ar enable, [CLX84 only]*/
#define CLX_CIA_ACT_FLAGS_NFE            (1ULL << 27) /* nfe valid, [CLX84 only]*/
#define CLX_CIA_ACT_FLAGS_NFS            (1ULL << 28) /* nfs valid, [CLX84 only]*/
#define CLX_CIA_ACT_FLAGS_HQOS_QUEUE     (1ULL << 29) /* hqos queue valid, [CLX84 only]*/
#define CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_GREEN \
    (1ULL << 30) /* color green qos action valid, [CLX84 only]*/
#define CLX_CIA_ACT_FLAGS_DROP_FORCE         (1ULL << 31) /* drop force, [CLX84 only]*/
#define CLX_CIA_ACT_FLAGS_DROP_CANCEL        (1ULL << 32) /* drop cancel, [CLX84 only]*/
#define CLX_CIA_ACT_FLAGS_COPY_TO_CPU_FORCE  (1ULL << 33) /* copy to cpu force, [CLX84 only]*/
#define CLX_CIA_ACT_FLAGS_COPY_TO_CPU_CANCEL (1ULL << 34) /* copy to cpu cancel, [CLX84 only]*/
#define CLX_CIA_ACT_FLAGS_UDF_RSN_VLD        (1ULL << 35) /* udf reason valid */
#define CLX_CIA_ACT_FLAGS_GBP_SEL            (1ULL << 36) /* gbp select valid, [CLX84 only]*/
#define CLX_CIA_ACT_FLAGS_MOD_STATE          (1ULL << 37) /* mod state */

typedef struct clx_cia_grp_info_s {
    clx_cia_stage_t stage;           /* cia group stage type */
    uint32 grp_id;                   /* cia group index */
    clx_cia_grp_prof_t grp_prof;     /* group profile */
    clx_cia_grp_key_info_t key_info; /* key info */
} clx_cia_grp_info_t;

typedef struct clx_cia_exact_grp_info_s {
    clx_cia_stage_t stage;             /* cia exact group stage type */
    uint32 grp_id;                     /* cia exact group index */
    clx_cia_exact_grp_prof_t grp_prof; /* group profile */
} clx_cia_exact_grp_info_t;

typedef struct clx_cia_exact_entry_hash_info_s {
    uint32 hash_idx; /* TOB hash entry index */
    uint32 key_tbl;  /* exact key table id */
} clx_cia_exact_entry_hash_info_t;

typedef struct clx_cia_select_key_prof_info_s {
    clx_cia_select_cfg_type_t type;     /* select key profile type */
    uint32 prof_id;                     /* select key profile index */
    clx_cia_select_key_prof_t key_prof; /* select key profile */
} clx_cia_select_key_prof_info_t;

typedef struct clx_cia_entry_s {
    boolean entry_vld;           /* entry valid bit */
    clx_cia_classify_t classify; /* entry classify */
    clx_cia_act_t act;           /* entry action */
} clx_cia_entry_t;

typedef struct clx_cia_entry_info_s {
    clx_cia_stage_t stage;      /* group stage type */
    uint32 grp_id;              /* group index */
    uint32 entry_id;            /* entry index */
    uint32 pri;                 /* entry priority */
    uint32 hw_entry_id;         /* hardware entry index */
    uint32 norm_width;          /* key width of entry */
    clx_cia_entry_t entry_info; /* classify and action */
} clx_cia_entry_info_t;

typedef struct clx_cia_exact_entry_s {
    clx_cia_exact_classify_t classify; /* entry classify */
    clx_cia_act_t act;                 /* entry action */
} clx_cia_exact_entry_t;

typedef struct clx_cia_exact_entry_info_s {
    clx_cia_stage_t stage;            /* group stage type */
    uint32 grp_id;                    /* group index */
    uint32 entry_id;                  /* entry index */
    uint32 hw_entry_id;               /* hardware entry index */
    clx_cia_exact_entry_t entry_info; /* exact entry info */
} clx_cia_exact_entry_info_t;

typedef struct clx_cia_udf_entry_s {
    clx_cia_pkt_format_t pkt_format; /* packet format */
    clx_cia_udf_prof_t prof;         /* udf profile */
} clx_cia_udf_entry_t;

typedef struct clx_cia_udf_info_s {
    clx_cia_stage_t stage;     /* cia stage */
    uint32 udf_key_prof_id;    /* udf key profile id */
    clx_cia_udf_entry_t entry; /* udf entry */
} clx_cia_udf_info_t;

typedef struct clx_cia_range_info_s {
    clx_cia_stage_t stage;         /* group stage */
    uint32 range_id;               /* range index, 0-15 */
    clx_cia_range_cfg_t range_cfg; /* range config */
} clx_cia_range_info_t;

typedef clx_error_no_t (*clx_cia_rim_trav_func_t)(const uint32 unit,
                                                  const void *ptr_act,
                                                  void *ptr_cookie);

typedef clx_error_no_t (*clx_cia_grp_trav_func_t)(const uint32 unit,
                                                  const clx_cia_grp_info_t *ptr_grp_info,
                                                  void *ptr_cookie);

typedef clx_error_no_t (*clx_cia_exact_grp_trav_func_t)(const uint32 unit,
                                                        const clx_cia_exact_grp_info_t *ptr_grp_info,
                                                        void *ptr_cookie);

typedef clx_error_no_t (*clx_cia_entry_trav_func_t)(const uint32 unit,
                                                    const clx_cia_entry_info_t *ptr_entry_info,
                                                    void *ptr_cookie);
typedef clx_error_no_t (*clx_cia_select_key_prof_trav_func_t)(
    const uint32 unit,
    const clx_cia_select_key_prof_info_t *ptr_select_key_prof_info,
    void *ptr_cookie);

typedef clx_error_no_t (*clx_cia_exact_entry_trav_func_t)(
    const uint32 unit,
    const clx_cia_exact_entry_info_t *ptr_entry_info,
    void *ptr_cookie);

typedef clx_error_no_t (*clx_cia_udf_entry_trav_func_t)(const uint32 unit,
                                                        const clx_cia_udf_info_t *ptr_entry_info,
                                                        void *ptr_cookie);

typedef clx_error_no_t (*clx_cia_range_trav_func_t)(const uint32 unit,
                                                    const clx_cia_range_info_t *ptr_range_info,
                                                    void *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief The API is used to get the configuration information of select key profile.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit                   - Device unit number.
 * @param [in]     type                   - Select type.
 * @param [in]     prof_id                - The select key profile id to be got.
 * @param [out]    ptr_select_key_prof    - The select key profile to be returned.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_NOT_SUPPORT        - Feature is not supported.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_cia_select_key_prof_get(const uint32 unit,
                            const clx_cia_select_cfg_type_t type,
                            const uint32 prof_id,
                            clx_cia_select_key_prof_t *ptr_select_key_prof);

/**
 * @brief The API is used to add a select key profile.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit                   - Device unit number.
 * @param [in]     type                   - Select type.
 * @param [in]     ptr_select_key_prof    - The select key profile to be added.
 * @param [out]    ptr_prof_id            - The select key profile id to be returned.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Table is full.
 * @return         CLX_E_NOT_SUPPORT      - Feature is not supported.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_select_key_prof_add(const uint32 unit,
                            const clx_cia_select_cfg_type_t type,
                            const clx_cia_select_key_prof_t *ptr_select_key_prof,
                            uint32 *ptr_prof_id);

/**
 * @brief The API is used to delete a select key profile.
 *
 * Support_chip: CLX84.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    type       - Select type.
 * @param [in]    prof_id    - The select key profile id to be deleted.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_NOT_SUPPORT        - Feature is not supported.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_cia_select_key_prof_del(const uint32 unit,
                            const clx_cia_select_cfg_type_t type,
                            const uint32 prof_id);

/**
 * @brief The API is used to traverse select key profiles.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     type          - Select type.
 * @param [in]     callback      - The callback function of type
 *                                 clx_cia_select_key_prof_trav_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_SUPPORT      - Feature is not supported.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_select_key_prof_trav(const uint32 unit,
                             const clx_cia_select_cfg_type_t type,
                             const clx_cia_select_key_prof_trav_func_t callback,
                             void *ptr_cookie);

/**
 * @brief The API is used to get the configuration information of UCP group.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     stage           - UCP group stage type.
 * @param [in]     grp_id          - The UCP group id to be deleted.
 * @param [out]    ptr_grp_prof    - UCP group profile to be returned.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_NOT_SUPPORT        - Feature is not supported.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_cia_grp_get(const uint32 unit,
                const clx_cia_stage_t stage,
                const uint32 grp_id,
                clx_cia_grp_prof_t *ptr_grp_prof);

/**
 * @brief The API is used to add an UCP group.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     stage           - UCP group stage type.
 * @param [in]     ptr_grp_prof    - UCP group profile.
 * @param [out]    ptr_grp_id      - UCP group id.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_grp_add(const uint32 unit,
                const clx_cia_stage_t stage,
                const clx_cia_grp_prof_t *ptr_grp_prof,
                uint32 *ptr_grp_id);

/**
 * @brief The API is used to delete an UCP group.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    stage     - UCP group stage type.
 * @param [in]    grp_id    - The UCP group id to be deleted.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_cia_grp_del(const uint32 unit, const clx_cia_stage_t stage, const uint32 grp_id);

/**
 * @brief The API is used to traverse UCP groups.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     stage         - UCP group stage type.
 * @param [in]     callback      - The callback function of type clx_cia_grp_trav_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_grp_trav(const uint32 unit,
                 const clx_cia_stage_t stage,
                 const clx_cia_grp_trav_func_t callback,
                 void *ptr_cookie);

/**
 * @brief The API is used to get the configuration information of exact UCP group.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     stage           - UCP group stage type.
 * @param [in]     grp_id          - The UCP group id to be deleted.
 * @param [out]    ptr_grp_prof    - UCP group profile to be returned.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_cia_exact_grp_get(const uint32 unit,
                      const clx_cia_stage_t stage,
                      const uint32 grp_id,
                      clx_cia_exact_grp_prof_t *ptr_grp_prof);

/**
 * @brief The API is used to add an exact UCP group.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     stage           - UCP group stage type.
 * @param [in]     ptr_grp_prof    - UCP group profile.
 * @param [out]    ptr_grp_id      - UCP group id.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Table is full.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_exact_grp_add(const uint32 unit,
                      const clx_cia_stage_t stage,
                      const clx_cia_exact_grp_prof_t *ptr_grp_prof,
                      uint32 *ptr_grp_id);

/**
 * @brief The API is used to delete an exact UCP group.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    stage     - UCP group stage type.
 * @param [in]    grp_id    - The UCP group id to be deleted.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_cia_exact_grp_del(const uint32 unit, const clx_cia_stage_t stage, const uint32 grp_id);

/**
 * @brief The API is used to traverse exact UCP groups.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     stage         - UCP group stage type.
 * @param [in]     callback      - The callback function of type CLX_CIA_GRP_TRAVERSE_FUNC_T.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_exact_grp_trav(const uint32 unit,
                       const clx_cia_stage_t stage,
                       const clx_cia_exact_grp_trav_func_t callback,
                       void *ptr_cookie);

/**
 * @brief The API is used to get the configuration information of udf key profile.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     stage             - Udf key profile stage type.
 * @param [in]     udf_entry_id      - The udf key profile id to be got.
 * @param [out]    ptr_entry_info    - The output udf entry info.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_cia_udf_entry_get(const uint32 unit,
                      const clx_cia_stage_t stage,
                      const uint32 udf_entry_id,
                      clx_cia_udf_entry_t *ptr_entry_info);

/**
 * @brief The API is used to add an udf key profile.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    stage             - Udf key profile stage type.
 * @param [in]    udf_entry_id      - The udf key profile id to be added.
 * @param [in]    ptr_entry_info    - The UDF info.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_SUPPORT      - Feature is not supported.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_udf_entry_add(const uint32 unit,
                      const clx_cia_stage_t stage,
                      const uint32 udf_entry_id,
                      const clx_cia_udf_entry_t *ptr_entry_info);

/**
 * @brief The API is used to delete an udf key profile.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    stage           - Udf key profile stage type.
 * @param [in]    udf_entry_id    - Udf key profile id to be deleted.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_cia_udf_entry_del(const uint32 unit, const clx_cia_stage_t stage, const uint32 udf_entry_id);

/**
 * @brief The API is used to traverse udf key profile.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     stage         - Udf key profile stage type.
 * @param [in]     callback      - The callback function of type clx_cia_udf_entry_trav_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_udf_entry_trav(const uint32 unit,
                       const clx_cia_stage_t stage,
                       const clx_cia_udf_entry_trav_func_t callback,
                       void *ptr_cookie);

/**
 * @brief The API is used to get logic id information for UCP entry.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     entry_id         - Entry id.
 * @param [out]    ptr_stage        - The UCP group type of the entry id to be returned.
 * @param [out]    ptr_grp_id       - The group id of the entry id to be returned.
 * @param [out]    ptr_entry_pri    - The entry priority of the entry id to be returned.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_cia_entry_id_info_get(const uint32 unit,
                          const uint32 entry_id,
                          clx_cia_stage_t *ptr_stage,
                          uint32 *ptr_grp_id,
                          uint32 *ptr_entry_pri);

/**
 * @brief The API is used to allocate a logic id for UCP entry.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     stage           - UCP group type.
 * @param [in]     grp_id          - Allocate an entry id from UCP group.
 * @param [in]     entry_pri       - Entry priority.
 * @param [out]    ptr_entry_id    - The entry id to be returned.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_entry_id_alloc(const uint32 unit,
                       const clx_cia_stage_t stage,
                       const uint32 grp_id,
                       const uint32 entry_pri,
                       uint32 *ptr_entry_id);

/**
 * @brief The API is used to free the logic id for UCP entry.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    entry_id    - Entry id.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_cia_entry_id_free(const uint32 unit, const uint32 entry_id);

/**
 * @brief The API is used to get an UCP entry from HW.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     entry_id          - Entry id.
 * @param [out]    ptr_entry_info    - The entry information returned.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry not found.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_cia_entry_get(const uint32 unit, const uint32 entry_id, clx_cia_entry_t *ptr_entry_info);

/**
 * @brief The API is used to add a Tcam entry to HW.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    entry_id          - Entry id.
 * @param [in]    ptr_entry_info    - The entry information.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_entry_add(const uint32 unit, const uint32 entry_id, const clx_cia_entry_t *ptr_entry_info);

/**
 * @brief The API is used to set valid bit of Tcam entry to HW.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    entry_id     - Entry id.
 * @param [in]    entry_vld    - The valid bit of entry.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */

clx_error_no_t
clx_cia_entry_vld_set(const uint32 unit, const uint32 entry_id, const boolean entry_vld);

/**
 * @brief The API is used to delete a Tcam entry from HW.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    entry_id    - Entry id.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_cia_entry_del(const uint32 unit, const uint32 entry_id);

/**
 * @brief The API is used to traverse UCP entries.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     stage         - UCP group stage.
 * @param [in]     grp_id        - Group id.
 * @param [in]     callback      - The callback function of type CLX_CIA_ENTRY_TRAVERSE_FUNC_T.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_entry_trav(const uint32 unit,
                   const clx_cia_stage_t stage,
                   const uint32 grp_id,
                   const clx_cia_entry_trav_func_t callback,
                   void *ptr_cookie);

/**
 * @brief The API is used to get an exact match entry from HW.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     stage             - UCP group stage type.
 * @param [in]     grp_id            - Group id.
 * @param [in]     entry_id          - Entry id.
 * @param [out]    ptr_entry_info    - The entry information.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_exact_entry_get(const uint32 unit,
                        const clx_cia_stage_t stage,
                        const uint32 grp_id,
                        const uint32 entry_id,
                        clx_cia_exact_entry_t *ptr_entry_info);

/**
 * @brief The API is used to add an exact match entry to HW.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     stage             - UCP group stage type.
 * @param [in]     grp_id            - Group id.
 * @param [in]     ptr_entry_info    - The entry information.
 * @param [out]    ptr_entry_id      - The returned entry id from HW.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_exact_entry_add(const uint32 unit,
                        const clx_cia_stage_t stage,
                        const uint32 grp_id,
                        const clx_cia_exact_entry_t *ptr_entry_info,
                        uint32 *ptr_entry_id);

/**
 * @brief The API is used to delete an exact match entry from HW.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    stage       - UCP group stage type.
 * @param [in]    grp_id      - Group id.
 * @param [in]    entry_id    - Entry id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_exact_entry_del(const uint32 unit,
                        const clx_cia_stage_t stage,
                        const uint32 grp_id,
                        const uint32 entry_id);

/**
 * @brief The API is used to traverse UCP entries.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     stage         - UCP group stage type.
 * @param [in]     grp_id        - Group id.
 * @param [in]     callback      - The callback function of type CLX_CIA_ENTRY_TRAVERSE_FUNC_T.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_exact_entry_trav(const uint32 unit,
                         const clx_cia_stage_t stage,
                         const uint32 grp_id,
                         const clx_cia_exact_entry_trav_func_t callback,
                         void *ptr_cookie);

/**
 * @brief The API is used to get logic id information for UCP entry.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     entry_id      - Flow entry id.
 * @param [out]    ptr_stage     - The UCP group stage type of the entry id to be returned.
 * @param [out]    ptr_grp_id    - The group id of the entry id to be returned.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_cia_exact_entry_id_info_get(const uint32 unit,
                                const uint32 entry_id,
                                clx_cia_stage_t *ptr_stage,
                                uint32 *ptr_grp_id);

/**
 * @brief Get hardware hash index for an exact (flow) ACL entry by software entry id.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     entry_id         - Software flow / exact entry id.
 * @param [out]    ptr_hash_info    - Exact entry hash information.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_cia_exact_entry_hash_info_get(const uint32 unit,
                                  const uint32 entry_id,
                                  clx_cia_exact_entry_hash_info_t *ptr_hash_info);

/**
 * @brief The API is used to alloc resource index.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     type         - Resource index type.
 * @param [out]    ptr_index    - Alloc index.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Table is full.
 * @return         CLX_E_NOT_SUPPORT      - Feature is not supported.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
clx_cia_rim_alloc(const uint32 unit, const clx_cia_rim_alloc_t type, uint32 *ptr_index);

/**
 * @brief The API is used to free resource index.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    type     - Resource index type.
 * @param [in]    index    - Free index.
 * @return        CLX_E_OK                 - Operate success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Other error.
 * @return        CLX_E_NOT_SUPPORT        - Feature is not supported.
 */
clx_error_no_t
clx_cia_rim_free(const uint32 unit, const clx_cia_rim_alloc_t type, const uint32 index);

/**
 * @brief The API is used to set index action.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    type       - Resource index type.
 * @param [in]    index      - Set index.
 * @param [in]    ptr_act    - Set index action.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
clx_cia_rim_act_set(const uint32 unit,
                    const clx_cia_rim_alloc_t type,
                    const uint32 index,
                    const void *ptr_act);

/**
 * @brief The API is used to get index action.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     type       - Resource index type.
 * @param [in]     index      - Get index.
 * @param [out]    ptr_act    - Get index action.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
clx_cia_rim_act_get(const uint32 unit,
                    const clx_cia_rim_alloc_t type,
                    const uint32 index,
                    void *ptr_act);

/**
 * @brief The API is used to traverse rim resource.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     type          - Resource index type.
 * @param [in]     callback      - The callback function of type CLX_CIA_RIM_TRAVERSE_FUNC_T.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_SUPPORT      - Feature is not supported.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
clx_cia_rim_act_trav(const uint32 unit,
                     const clx_cia_rim_alloc_t type,
                     const clx_cia_rim_trav_func_t callback,
                     void *ptr_cookie);

/**
 * @brief The API is used to add/set the range configuration information.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    stage        - UCP stage type: Ingress/Egress.
 * @param [in]    range_id     - The range id to be added/set.
 * @param [in]    ptr_range    - The range configuration information.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_ENTRY_EXISTS     - Entry already exists.
 * @return        CLX_E_NOT_SUPPORT      - Feature is not supported.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_range_add(const uint32 unit,
                  const clx_cia_stage_t stage,
                  const uint32 range_id,
                  const clx_cia_range_cfg_t *ptr_range);

/**
 * @brief The API is used to delete the range configuration information.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    stage       - UCP stage type: Ingress/Egress.
 * @param [in]    range_id    - The range id to be deleted.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_cia_range_del(const uint32 unit, const clx_cia_stage_t stage, const uint32 range_id);

/**
 * @brief The API is used to get the range configuration information.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     stage        - UCP stage type: Ingress/Egress.
 * @param [in]     range_id     - The range id to be got.
 * @param [out]    ptr_range    - The range configuration information to be returned.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_cia_range_get(const uint32 unit,
                  const clx_cia_stage_t stage,
                  const uint32 range_id,
                  clx_cia_range_cfg_t *ptr_range);

/**
 * @brief The API is used to traverse range.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     stage         - UCP stage type: Ingress/Egress.
 * @param [in]     callback      - The callback function of type clx_cia_range_trav_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_range_trav(const uint32 unit,
                   const clx_cia_stage_t stage,
                   const clx_cia_range_trav_func_t callback,
                   void *ptr_cookie);

/**
 * @brief The API is used to set range_or_bitmap.
 *
 * Range_or_bitmap, each bit set to 1 indicates the corresponding range participates in the logical
 * "OR" operation of bit map profile, range_or_bitmap is zero means logical "AND" within 16 range of
 * udf profile.
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    stage        - UCP stage type: Ingress/Egress.
 * @param [in]    union_id     - The union id.
 * @param [in]    range_bmp    - The range bitmap.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_range_union_set(const uint32 unit,
                        const clx_cia_stage_t stage,
                        const uint32 union_id,
                        const uint32 range_bmp);

/**
 * @brief The API is used to get range_or_bitmap.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     stage            - UCP stage type: Ingress/Egress.
 * @param [in]     union_id         - The union id.
 * @param [out]    ptr_range_bmp    - The range bitmap.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_range_union_get(const uint32 unit,
                        const clx_cia_stage_t stage,
                        const uint32 union_id,
                        uint32 *ptr_range_bmp);

#endif
