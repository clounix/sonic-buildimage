/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_TAM_H__)
#define __CLX_SAI_TAM_H__


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_TAM_TAM_MAX_NUM                (128)
#define CLXS_TAM_MATH_FUNC_MAX_NUM          (128)
#define CLXS_TAM_EVENT_THRESHOLD_MAX_NUM    (128)
#define CLXS_TAM_TEL_TYPE_MAX_NUM           (128)
#define CLXS_TAM_REPORT_MAX_NUM             (128)
#define CLXS_TAM_TELEMETRY_MAX_NUM          (128)
#define CLXS_TAM_TRANSPORT_MAX_NUM          (128)
#define CLXS_TAM_COLLECTOR_MAX_NUM          (128)
#define CLXS_TAM_EVENT_ACTION_MAX_NUM       (128)
#define CLXS_TAM_EVENT_MAX_NUM              (128)
#define CLXS_TAM_MAX_HOP_CNT_CFG_MODE_PROFILE           (SHAL_TAM_MAX_HOP_CNT_CFG_MODE_PROFILE)
#define CLXS_TAM_MAX_HOP_CNT_CFG_MODE_GLOBAL            (SHAL_TAM_MAX_HOP_CNT_CFG_MODE_GLOBAL)

#ifdef CLX_TAM_MOD_EXTEND_ENABLE
#define CLXS_TAM_MOD_QUEUE_BINDWIDTH   (2048)
#define CLXS_TAM_MOD_NETIF_TYPE        (1)
#define CLXS_TAM_MOD_NETIF_ID_SET(id)   ((CLXS_TAM_MOD_NETIF_TYPE << 16) + id)
#define CLXS_TAM_MOD_NETIF_ID_GET(id)   (id & 0xffff)
#endif

#define CLXS_TAM_MOD_FAMILY_NAME     "NET_DM"

#define CLXS_TAM_EVENT_MONITOR_THREAD_PRI                (50)
#define CLXS_TAM_EVENT_MONITOR_THREAD_NAME               "TAM_EVENT_MONITOR"
#define CLXS_TAM_EVENT_MONITOR_THREAD_STACK_SIZE         (32 * 1024)
#define CLXS_TAM_EVENT_MONITOR_THREAD_DEFAULT_INTERVAL   (1*1000*1000) //1s

#define CLXS_TAM_EVENT_REPORT_THREAD_PRI                (50)
#define CLXS_TAM_EVENT_REPORT_THREAD_NAME               "TAM_EVENT_REPORT"
#define CLXS_TAM_EVENT_REPORT_THREAD_STACK_SIZE         (32 * 1024)
#define CLXS_TAM_EVENT_REPORT_THREAD_DEFAULT_INTERVAL   (1*1000*1000) //1s

#define CLXS_TAM_TELEMETRY_THREAD_PRI               (50)
#define CLXS_TAM_TELEMETRY_THREAD_NAME              "TAM_TELEMETRY"
#define CLXS_TAM_TELEMETRY_THREAD_STACK_SIZE        (32 * 1024)
#define CLXS_TAM_TELEMETRY_THREAD_DEFAULT_INTERVAL  (1*1000*1000) //1s

#define CLXS_TAM_EVENT_REPORT_MAX_NUM_PER_EVENT (4 * 1024)

#define CLXS_TAM_INT_SUPPORT_IFA2_MODIFY_DEVICE_ID(__unit__)      (clxs_cfg_get_value_by_type(__unit__, CLXS_CFG_EXTEND_TAM_INT_IFA2_MODIFY_DEVICE_ID))


#define CLXS_TAM_LOCK(unit)                     sai_osal_mutex_lock(g_clxs_tam_db[unit].sema)
#define CLXS_TAM_UNLOCK(unit)                   sai_osal_mutex_unlock(g_clxs_tam_db[unit].sema)
#define CLXS_TAM_DB(__unit__)                   (g_clxs_tam_db[__unit__])

#define CLXS_TAM_TAM_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_tam_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_TAM].ptr_obj + __id__)
#define CLXS_TAM_MATH_FUNC_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_math_func_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_MATH_FUNC].ptr_obj + __id__)
#define CLXS_TAM_EVENT_THRESHOLD_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_event_threshold_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_EVENT_THRESHOLD].ptr_obj + __id__)
#define CLXS_TAM_TEL_TYPE_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_tel_type_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_TEL_TYPE].ptr_obj + __id__)
#define CLXS_TAM_REPORT_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_report_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_REPORT].ptr_obj + __id__)
#define CLXS_TAM_TELEMETRY_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_telemetry_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_TELEMETRY].ptr_obj + __id__)
#define CLXS_TAM_TRANSPORT_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_transport_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_TRANSPORT].ptr_obj + __id__)
#define CLXS_TAM_COLLECTOR_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_collector_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_COLLECTOR].ptr_obj + __id__)
#define CLXS_TAM_EVENT_ACTION_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_event_action_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_EVENT_ACTION].ptr_obj + __id__)
#define CLXS_TAM_EVENT_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_event_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_EVENT].ptr_obj + __id__)


/*******************************************************************************
 * Data Type Declarations 
 *******************************************************************************/
typedef enum _clxs_tam_ifa2_modify_device_id_mode_t
{
    CLXS_TAM_IFA2_MODIFY_DEVICE_ID_MODE_DEFAULT = 0,
    CLXS_TAM_IFA2_MODIFY_DEVICE_ID_MODE_32_BIT,
    CLXS_TAM_IFA2_MODIFY_DEVICE_ID_MODE_32_BIT_AND_ACL_BASED,
    CLXS_TAM_IFA2_MODIFY_DEVICE_ID_MODE_LAST
} clxs_tam_ifa2_modify_device_id_mode_t;

typedef enum _clxs_tam_type_t
{
    CLXS_TAM_TYPE_START = 0,
    CLXS_TAM_TYPE_TAM = CLXS_TAM_TYPE_START,
    CLXS_TAM_TYPE_MATH_FUNC,
    CLXS_TAM_TYPE_EVENT_THRESHOLD,
    CLXS_TAM_TYPE_TEL_TYPE,
    CLXS_TAM_TYPE_REPORT,
    CLXS_TAM_TYPE_TELEMETRY,
    CLXS_TAM_TYPE_TRANSPORT,
    CLXS_TAM_TYPE_COLLECTOR,
    CLXS_TAM_TYPE_EVENT_ACTION,
    CLXS_TAM_TYPE_EVENT,
    CLXS_TAM_TYPE_MAX
} clxs_tam_type_t;

typedef enum _clxs_tam_mod_type_t
{
    CLXS_TAM_MOD_TYPE_TM,
    CLXS_TAM_MOD_TYPE_IPP,
    CLXS_TAM_MOD_TYPE_EPP,
    CLXS_TAM_MOD_TYPE_ALL
}clxs_tam_mod_type_t;

typedef enum _clxs_tam_event_type_t
{
    CLXS_TAM_EVENT_TYPE_INVALID,
    CLXS_TAM_EVENT_TYPE_UBURST,
    CLXS_TAM_EVENT_TYPE_ALERT_IPG,
    CLXS_TAM_EVENT_TYPE_ALERT_XOFFROOM,
    CLXS_TAM_EVENT_TYPE_ALERT_QUEUE,
    CLXS_TAM_EVENT_TYPE_ALERT_BSP_IGR,
    CLXS_TAM_EVENT_TYPE_ALERT_BSP_EGR
} clxs_tam_event_type_t;

typedef enum _clxs_tam_event_status_t
{
    CLXS_TAM_EVENT_STATUS_INIT,
    CLXS_TAM_EVENT_STATUS_START,
    CLXS_TAM_EVENT_STATUS_END
} clxs_tam_event_status_t;

typedef struct _clxs_tam_netlink_t
{
    uint32_t    family_id;
    uint32_t    group_id;
    int32_t     sockfd;
} clxs_tam_netlink_t;

typedef struct _clxs_tam_event_status_info_t
{
    clxs_tam_event_status_t status;
    uint32                  watermark;
    clx_timestamp_t         watermark_ts;
} clxs_tam_event_status_info_t;

typedef struct _clxs_tam_bp_queue_t
{
    uint32_t    port_id;
    uint32_t    handler_type;
    uint32_t    queue_id;
} clxs_tam_bp_queue_t;

typedef struct _clxs_tam_bp_ipg_t
{
    uint32_t                        port_id;
    uint32_t                        pg_id;
    clxs_tam_event_status_info_t    ipg_status_info;/*not need recover in warmboot proto*/
    clxs_tam_event_status_info_t    xoff_room_status_info;/*not need recover in warmboot proto*/
} clxs_tam_bp_ipg_t;

typedef struct _clxs_tam_bp_bsp_t
{
    sai_buffer_pool_type_t          pool_type;
    sai_object_id_t                 pool_oid;
    clxs_tam_event_status_info_t    status_info;/*not need recover in warmboot proto*/
} clxs_tam_bp_bsp_t;

typedef struct _clxs_tam_bind_info_t
{
    sai_object_id_t switch_oid;
    util_lib_list_t *ptr_port_list;
    util_lib_list_t *ptr_queue_list;
    util_lib_list_t *ptr_ipg_list;
    util_lib_list_t *ptr_bsp_list;
} clxs_tam_bind_info_t;

typedef struct _clxs_tam_tam_obj_t
{
    sai_object_id_t         tam_oid;
    clxs_tam_attrs_t        attr_info;
    clxs_tam_bind_info_t    bind_info;
} clxs_tam_tam_obj_t;

typedef struct _clxs_tam_math_func_obj_t
{
    sai_object_id_t             tam_math_func_oid;
    clxs_tam_math_func_attrs_t  attr_info;
} clxs_tam_math_func_obj_t;

typedef struct _clxs_tam_event_threshold_obj_t
{
    sai_object_id_t                     tam_event_threshold_oid;
    clxs_tam_event_threshold_attrs_t    attr_info;
} clxs_tam_event_threshold_obj_t;

typedef struct _clxs_tam_tel_type_obj_t
{
    sai_object_id_t             tam_tel_type_oid;
    clxs_tam_tel_type_attrs_t   attr_info;
} clxs_tam_tel_type_obj_t;

typedef struct _clxs_tam_report_obj_t
{
    sai_object_id_t         tam_report_oid;
    clxs_tam_report_attrs_t attr_info;
} clxs_tam_report_obj_t;

typedef struct _clxs_tam_telemetry_hpc_t
{
    uint32_t    polling_intvl;
    uint64_t    fifo_size;
    uint32_t    netlink_msg_count;/*not need recover in warmboot proto*/
} clxs_tam_telemetry_hpc_t;

typedef struct _clxs_tam_telemetry_obj_t
{
    sai_object_id_t             tam_telemetry_oid;
    clxs_tam_telemetry_attrs_t  attr_info;
    clxs_tam_telemetry_hpc_t    hpc_info;
} clxs_tam_telemetry_obj_t;

typedef struct _clxs_tam_transport_obj_t
{
    sai_object_id_t             tam_transport_oid;
    clxs_tam_transport_attrs_t  attr_info;
} clxs_tam_transport_obj_t;

typedef struct _clxs_tam_collector_obj_t
{
    sai_object_id_t             tam_collector_oid;
    clxs_tam_collector_attrs_t  attr_info;
    clxs_tam_netlink_t          netlink_info;/*not need recover in warmboot proto*/
} clxs_tam_collector_obj_t;

typedef struct _clxs_tam_event_action_obj_t
{
    sai_object_id_t                 tam_event_action_oid;
    clxs_tam_event_action_attrs_t   attr_info;
} clxs_tam_event_action_obj_t;

typedef struct _clxs_tam_notified_event_t {
    clxs_tam_event_type_t   type;
    clxs_tam_event_status_t status;
    sai_object_id_t         bp_oid;
    clx_timestamp_t         ts;
    uint32                  watermark;
    clx_timestamp_t         watermark_ts;
} clxs_tam_notified_event_t;

typedef struct _clxs_tam_event_info_t
{
    clxs_tam_event_type_t   type;
    uint32_t                prof_id;
    uint32_t                prof_ref_cnt;
    uint32_t                sn;/*not need recover in warmboot proto*/
    util_lib_list_t         *ptr_notified_event_list;/*member is clxs_tam_notified_event_t,not need recover in warmboot proto*/
} clxs_tam_event_info_t;

typedef struct _clxs_tam_event_obj_t
{
    sai_object_id_t         tam_event_oid;
    clxs_tam_event_attrs_t  attr_info;
#ifdef CLX_TAM_MOD_EXTEND_ENABLE
    uint32_t                netlink_id;
    uint32_t                netlink_profile_id;
    uint32_t                out_port;
#endif
    clxs_tam_event_info_t   event_info; 
} clxs_tam_event_obj_t;

typedef struct _clxs_tam_type_map_t
{
    clxs_tam_type_t tam_type;
    uint32_t        obj_max_num;
    uint32_t        bytes_per_obj;
} clxs_tam_type_map_t;

typedef struct _clxs_tam_obj_table_t
{
    uint32_t    size;
    uint32_t    count;
    void        *ptr_obj;
    uint32_t    *ptr_obj_valid;
} clxs_tam_obj_table_t;

typedef struct _clxs_tam_db_t
{
    clxs_tam_obj_table_t            tam_obj_table[CLXS_TAM_TYPE_MAX];
    clx_semaphore_id_t              sema;
    clx_thread_id_t                 event_monitor_thread_id;/*not need recover in warmboot proto*/
    clx_thread_id_t                 event_report_thread_id;/*not need recover in warmboot proto*/
    clx_thread_id_t                 telemetry_thread_id;/*not need recover in warmboot proto*/
    uint32_t                        queue_prof_cnt;
    uint32_t                        egr_pool_prof_cnt;
    sai_tam_event_notification_fn   event_cb_func;/*not need recover in warmboot proto*/
    uint32_t                        *ptr_mburst_prof_valid;
} clxs_tam_db_t;


/*******************************************************************************
 * Global Variable Declarations 
 *******************************************************************************/
extern clxs_tam_db_t g_clxs_tam_db[CLXS_MAX_CHIP_NUM];
extern const sai_tam_api_t  tam_api;


/*******************************************************************************
 * Function Declarations 
 *******************************************************************************/ 
sai_status_t clxs_tam_get_obj(
    _In_    const   uint32_t        unit,
    _In_    const   clxs_tam_type_t tam_type,
    _In_    uint32_t                obj_id,
    _Out_   void                    **pptr_obj);
sai_status_t clxs_tam_init(
    _In_ const uint32_t unit);
sai_status_t clxs_tam_deinit(
    _In_ const uint32_t unit);
#if SAI_API_VERSION >= SAI_VERSION(1,5,0)
sai_status_t clxs_tam_update_tam_obj_list(
    _In_ const uint32_t             unit,
    _In_ sai_object_id_t            bind_obj,
    _In_ const sai_object_list_t    *ptr_old_tam_obj_list,
    _In_ const sai_object_list_t    *ptr_new_tam_obj_list);

#endif
sai_status_t clxs_tam_event_register_cb(
    _In_    const uint32_t  unit,
    _In_    void            *ptr_func);
sai_status_t clxs_tam_set_collector_cfg_info(
    _In_  sai_object_id_t                   collector_oid,
    _Out_  clx_telm_collector_cfg_info_t    *ptr_clx_collector_cfg);
sai_status_t clxs_tam_get_transport_object_id(
    _In_ const sai_object_id_t              collector_oid,
    _Out_ sai_object_id_t                   *ptr_transport_oid);

#endif /*__CLX_SAI_TAM_H__*/