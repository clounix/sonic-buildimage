/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_SCHDULERGROUP_H__)
#define __CLX_SAI_SCHDULERGROUP_H__

/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_SCH_GRP_MAX_SCH_NUM         (9)
#define CLXS_SCH_GRP_MAX_SCH_LEVELS      (3)


/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/
typedef enum
{
    CLXS_SCH_GRP_ADD_GROUP_CHILD_COUNT = 0,
    CLXS_SCH_GRP_REMOVE_GROUP_CHILD_COUNT,
    CLXS_SCH_GRP_ADD_QUEUE_CHILD_COUNT,
    CLXS_SCH_GRP_REMOVE_QUEUE_CHILD_COUNT,
    CLXS_SCH_GRP_CHILD_COUNT_ACTION_LAST
}  CLXS_SCH_GRP_CHILD_COUNT_ACTION_TYPE_T;

typedef struct clxs_sch_grp_db_s{
    clxs_scheduler_group_attrs_t    *clxs_scheduler_group[CLXS_MAX_PORT_NUM][CLXS_SCH_GRP_MAX_SCH_LEVELS][CLXS_SCH_GRP_MAX_SCH_NUM];
} clxs_sch_grp_db_t;


/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_scheduler_group_api_t  schedulergroup_api;
extern clxs_sch_grp_db_t *_clxs_sch_grp_db[CLXS_MAX_CHIP_NUM];


/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t
clxs_sch_grp_update_queue_child(
    _In_ uint32_t    unit,
    _In_ uint32_t    port,
    _In_ sai_object_id_t parent_oid,
    _In_ CLXS_SCH_GRP_CHILD_COUNT_ACTION_TYPE_T action);

sai_status_t
clxs_sch_grp_get_group_num(
    _In_ sai_object_id_t     port_object_id,
    _Out_ uint32_t            *ptr_num);

sai_status_t
clxs_sch_grp_get_group_list(
    _In_ sai_object_id_t     port_object_id,
    _Out_ sai_object_id_t     *ptr_list);

sai_status_t
clxs_sch_grp_init(
    _In_ uint32_t unit);

sai_status_t
clxs_sch_grp_deinit(
    _In_ uint32_t unit);

sai_status_t
clxs_sch_grp_port_remove(
    _In_ uint32_t            unit,
    _In_ uint32_t            port,
    _In_ sai_object_id_t     *ptr_port_queues);

sai_status_t
clxs_sch_grp_port_create(
    _In_ uint32_t            unit,
    _In_ uint32_t            port);

uint32_t
clxs_sch_grp_get_max_child_num(
    _In_ uint32_t                unit,
    _In_ uint32_t                level);

uint32_t
clxs_sch_grp_get_max_node_num(
    _In_ uint32_t                unit,
    _In_ uint32_t                level);

sai_status_t
clxs_sch_grp_apply_scheduler(
    _In_ uint32_t unit,
    _In_ uint32_t port,
    _In_ sai_object_id_t object_id);

sai_status_t
clxs_sch_grp_get_scheduler(
    _In_ uint32_t unit,
    _In_ uint32_t port,
    _In_ sai_object_id_t parent_id,
    _Out_ sai_object_id_t *scheduler_id);

#endif /* __CLX_SAI_SCHDULERGROUP_H__ */
