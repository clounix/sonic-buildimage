/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_pma.h
 * PURPOSE:
 *      It provide HAL PMA module API.
 * NOTES:
 */
#ifndef HAL_MT_KG_PMA_H
#define HAL_MT_KG_PMA_H

/* INCLUDE FILE DECLARATIONS */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ========================================================================== */
/* TYPES AND CONSTANTS (from hal_mt_kg_pma_types.h) */
/* ========================================================================== */

/* Error Code Types */
typedef enum hal_mt_kg_pma_error_e {
    HAL_KG_PMA_SUCCESS = 0,
    HAL_KG_PMA_OK = 0,
    HAL_KG_PMA_FAIL = -1,
    HAL_KG_PMA_PHY_FW_DOWNLOAD_FAIL = -3,
    HAL_KG_PMA_FW_TIMEOUT = -4,
    HAL_KG_PMA_NOT_READY = -5,
    HAL_KG_PMA_OUT_OF_MEMORY = -6,
    HAL_KG_PMA_HAL_LOAD_FAIL = -7,
    HAL_KG_PMA_HAL_NOT_FOUND = -8,
    HAL_KG_PMA_INVALID_ARGS = -9,
    HAL_KG_PMA_MUTEX_TIMEOUT = -10,
    HAL_KG_PMA_TIMEOUT = -11,
    HAL_KG_PMA_CANCEL = -12,
    HAL_KG_PMA_UNSUPPORTED = -99,
    HAL_KG_PMA_NOTIMPLEMENTED = -100,
    HAL_KG_PMA_NOTIMPLEMENTED_HAL = -101,
} hal_mt_kg_pma_error_t;

/* Opaque Handle Types */
typedef struct hal_mt_kg_pma_sdk hal_mt_kg_pma_sdk_t;
typedef struct hal_mt_kg_pma_device hal_mt_kg_pma_device_t;
typedef struct hal_mt_kg_pma_slice hal_mt_kg_pma_slice_t;

/* Lane Mode Types */
typedef enum hal_mt_kg_pma_lane_mode_e {
    HAL_KG_PMA_LMODE_OFF = 0,
    HAL_KG_PMA_LMODE_NRZ = 1,
    HAL_KG_PMA_LMODE_PAM4 = 2,
    HAL_KG_PMA_LMODE_AN = 3,
    HAL_KG_PMA_LMODE_PAM3 = 4,
    HAL_KG_PMA_LMODE_DISABLE = 0xff
} hal_mt_kg_pma_lane_mode_t;

/* Side Types */
typedef enum hal_mt_kg_pma_side_e {
    HAL_KG_PMA_SIDE_HOST = 0,
    HAL_KG_PMA_SIDE_SYSTEM = 0,
    HAL_KG_PMA_SIDE_LINE = 1
} hal_mt_kg_pma_side_t;

/* Device Types */
typedef enum hal_mt_kg_pma_device_type_e {
    HAL_KG_PMA_DEV_ETH = 0x007004,
    HAL_KG_PMA_DEV_D2D = 0x00D005,
} hal_mt_kg_pma_device_type_t;

/* Slice Init Types */
typedef enum hal_mt_kg_pma_slice_init_type_e {
    HAL_KG_PMA_INIT_FULL = 0,        //!< full reset, load firmware, initialize any sensible default
                                     //!< settings
    HAL_KG_PMA_INIT_NO_FIRMWARE = 1, //!< fully reset, do not load firmware, initialize any sensible
                                     //!< default settings
    HAL_KG_PMA_INIT_WARM = 2, //!< do not change any setting, fetch any settings from firmware 'warm
                              //!< boot'
    HAL_KG_PMA_INIT_NONE = 3, //!< do nothing, except setup the data structure (reg read/write
                              //!< setup)
    HAL_KG_PMA_INIT_SPIFLASH = 4,    //!< full reset, load firmware from SPI flash, initialize any
                                     //!< sensible default settings
    HAL_KG_PMA_INIT_FULL_VERIFY = 5, //!< same as full but goes through additional checks to ensure
                                     //!< setup is good
    HAL_KG_PMA_INIT_NOOP = 0xFF      //!< debug that performs no initialization operation except for
                                     //!< setting slice id and context
} hal_mt_kg_pma_slice_init_type_t;

/* Parameter Value Types */
typedef enum hal_mt_kg_pma_param_value_e {
    HAL_KG_PMA_PARAM_VAL_INT = 0,
    HAL_KG_PMA_PARAM_VAL_UINT = 1,
    HAL_KG_PMA_PARAM_VAL_FLOAT = 2,
} hal_mt_kg_pma_param_value_t;

/* Parameter Data Buffer Union */
typedef union hal_mt_kg_pma_param_data_buf_u {
    unsigned *u;
    int *i;
    double *d;
} hal_mt_kg_pma_param_data_buf_t;

/* Parameter Data Structure */
typedef struct hal_mt_kg_pma_param_data_s {
    hal_mt_kg_pma_param_data_buf_t value;
    hal_mt_kg_pma_param_value_t type;
    size_t count;
} hal_mt_kg_pma_param_data_t;

/* Loopback Mode Types */
typedef enum hal_mt_kg_pma_loopback_mode_e {
    HAL_KG_PMA_LB_DISABLED = 0,
    HAL_KG_PMA_LB_TX_TO_RX = 1,
    HAL_KG_PMA_LB_RX_TO_TX = 2
} hal_mt_kg_pma_loopback_mode_t;

/* Lane Flags */
typedef enum hal_mt_kg_pma_lane_flags_e {
    HAL_KG_PMA_LFLAG_TX = (1 << 0),
    HAL_KG_PMA_LFLAG_RX = (1 << 1),
    HAL_KG_PMA_LFLAG_AN = (1 << 8),
    HAL_KG_PMA_LFLAG_LT = (1 << 9),
    HAL_KG_PMA_LFLAG_FLEXSPEED = (1 << 12),
    HAL_KG_PMA_LFLAG_LOOPBACK = (1 << 16),
    HAL_KG_PMA_LFLAG_ALL = (1 << 17),
    HAL_KG_PMA_LFLAG_PLL_CAL = (1 << 31)
} hal_mt_kg_pma_lane_flags_t;

/* PRBS Pattern Types */
typedef enum hal_mt_kg_pma_prbs_pattern_e {
    HAL_KG_PMA_PRBS_UNKNOWN = -1,
    HAL_KG_PMA_PRBS7 = 0,
    HAL_KG_PMA_PRBS9 = 1,
    HAL_KG_PMA_PRBS11 = 2,
    HAL_KG_PMA_PRBS13 = 3,
    HAL_KG_PMA_PRBS15 = 4,
    HAL_KG_PMA_PRBS23 = 5,
    HAL_KG_PMA_PRBS31 = 6,
    HAL_KG_PMA_PRBS19 = 7,
    HAL_KG_PMA_SSPRQ = 8
} hal_mt_kg_pma_prbs_pattern_t;

/* Log Level Types */
typedef enum hal_mt_kg_pma_log_level_e {
    HAL_KG_PMA_LOG_TRACE = 0,
    HAL_KG_PMA_LOG_DEBUG = 1,
    HAL_KG_PMA_LOG_INFO = 2,
    HAL_KG_PMA_LOG_WARN = 3,
    HAL_KG_PMA_LOG_ERROR = 4,
    HAL_KG_PMA_LOG_OFF = 5
} hal_mt_kg_pma_log_level_t;

/* Log Callback Function Type */
typedef void (*hal_mt_kg_pma_log_t)(void *slice_context,
                                    void *user_data,
                                    hal_mt_kg_pma_log_level_t level,
                                    const char *scope,
                                    const char *message);

/* Lane TX State Types */
typedef enum hal_mt_kg_pma_lane_tx_state_e {
    HAL_KG_PMA_TX_UNKNOWN = 0,
    HAL_KG_PMA_TX_LOWPOWER = 1,
    HAL_KG_PMA_TX_TRAFFIC = 2,
    HAL_KG_PMA_TX_SQUELCH = 3,
    HAL_KG_PMA_TX_PRBS_PAM4 = 4,
    HAL_KG_PMA_TX_PRBS_NRZ = 5,
    HAL_KG_PMA_TX_FORCE_DISABLE = 6,
    HAL_KG_PMA_TX_FORCE_PRBSS_PAM4 = 7,
    HAL_KG_PMA_TX_FORCE_PRBS_NRZ = 8,
    HAL_KG_PMA_TX_FORCE_TRAFFIC = 9,
    HAL_KG_PMA_TX_FORCE_TEST_PATT = 10
} hal_mt_kg_pma_lane_tx_state_t;

/* Lane Coupling Types */
typedef enum hal_mt_kg_pma_lane_coupling_e {
    HAL_KG_PMA_LANE_COUPLING_AC = 0,
    HAL_KG_PMA_LANE_COUPLING_DC = 1
} hal_mt_kg_pma_lane_coupling_t;

/* Driver Function Pointer Types */
typedef hal_mt_kg_pma_error_t (*hal_mt_kg_pma_read_register_t)(void *slice_context,
                                                               unsigned reg_addr,
                                                               unsigned *val);
typedef hal_mt_kg_pma_error_t (*hal_mt_kg_pma_write_register_t)(void *slice_context,
                                                                unsigned reg_addr,
                                                                unsigned val);
typedef hal_mt_kg_pma_error_t (*hal_mt_kg_pma_read_register_burst_t)(void *slice_context,
                                                                     unsigned first_addr,
                                                                     unsigned val[],
                                                                     unsigned count);
typedef hal_mt_kg_pma_error_t (*hal_mt_kg_pma_write_register_burst_t)(void *slice_context,
                                                                      unsigned first_addr,
                                                                      const unsigned val[],
                                                                      unsigned count);

/* SDK Configuration Structure */
typedef struct hal_mt_kg_pma_sdk_config_s {
    void *log;
    hal_mt_kg_pma_read_register_t read_register;
    hal_mt_kg_pma_write_register_t write_register;
    hal_mt_kg_pma_log_level_t max_log_level;
} hal_mt_kg_pma_sdk_config_t;

/* Slice Configuration Structure */
typedef struct hal_mt_kg_pma_slice_config_s {
    hal_mt_kg_pma_slice_init_type_t init_type;
    const char *firmware_filename;
    uint32_t slice_id;
    void *slice_context;
} hal_mt_kg_pma_slice_config_t;

/* Firmware Status Types (from hal_mt_kg_pma_firmware.h) */
typedef enum hal_mt_kg_pma_firmware_status_e {
    HAL_KG_PMA_FW_STATUS_UNKNOWN = 0,
    HAL_KG_PMA_FW_STATUS_LOADING = 1,
    HAL_KG_PMA_FW_STATUS_READY = 2,
    HAL_KG_PMA_FW_STATUS_ERROR = 3,
    HAL_KG_PMA_FW_STATUS_NOT_LOADED = 4
} hal_mt_kg_pma_firmware_status_t;

/* Shell Stream Types (from hal_mt_kg_pma_shell.h) */
typedef enum hal_mt_kg_pma_shell_stream_e {
    HAL_KG_PMA_SHELL_STDOUT = 0,
    HAL_KG_PMA_SHELL_STDERR = 1
} hal_mt_kg_pma_shell_stream_t;

/* Shell Constants */
#define HAL_KG_PMA_CMDLINE_SIZE 1024

typedef struct hal_mt_kg_pma_eye_monitor_data_s {
    int32_t **data;     //!< 2d array of data (single malloc)
    size_t rows;        //!< number of rows
    size_t cols;        //!< number of columns
    uint32_t extent_mv; //!< vertical scale
} hal_mt_kg_pma_eye_monitor_data_t;

/* ========================================================================== */
/* SDK FUNCTIONS (from hal_mt_kg_pma_sdk.h) */
/* ========================================================================== */

/**
 * @brief Create SDK handle.
 *
 * @param [in]     config    - SDK configuration.
 * @param [out]    sdk       - SDK handle.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_sdk_create(const hal_mt_kg_pma_sdk_config_t *config, hal_mt_kg_pma_sdk_t **sdk);

/**
 * @brief Destroy SDK handle.
 *
 * @param [in]    sdk    - SDK handle.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_sdk_destroy(hal_mt_kg_pma_sdk_t *sdk);

/**
 * @brief Get SDK version.
 *
 * @return        Encoded SDK version.
 */
uint32_t
hal_mt_kg_pma_sdk_version_get(void);

/**
 * @brief Get SDK version string.
 *
 * @return        Version string.
 */
const char *
hal_mt_kg_pma_sdk_version_str_get(void);

/**
 * @brief Set burst read function.
 *
 * @param [in]    sdk                - SDK handle.
 * @param [in]    burst_read_func    - Burst read function.
 */
void
hal_mt_kg_pma_sdk_set_burst_read(hal_mt_kg_pma_sdk_t *sdk,
                                 hal_mt_kg_pma_read_register_burst_t burst_read_func);

/**
 * @brief Set burst write function.
 *
 * @param [in]    sdk                 - SDK handle.
 * @param [in]    burst_write_func    - Burst write function.
 */
void
hal_mt_kg_pma_sdk_set_burst_write(hal_mt_kg_pma_sdk_t *sdk,
                                  hal_mt_kg_pma_write_register_burst_t burst_write_func);

/**
 * @brief Set the logger @param logger - Logger callback function.
 *
 */
void
hal_mt_kg_pma_logger_set(hal_mt_kg_pma_log_t logger);

/**
 * @brief Set the log level @param loglevel - Log level to set.
 *
 */
void
hal_mt_kg_pma_logger_level_set(hal_mt_kg_pma_log_level_t loglevel);

/**
 * @brief Get the log level.
 *
 * @return        Current log level.
 */
hal_mt_kg_pma_log_level_t
hal_mt_kg_pma_logger_level_get(void);

void
hal_mt_kg_pma_eth_phy_register(void);

void
hal_mt_kg_pma_d2d_phy_register(void);

/* ========================================================================== */
/* DEVICE FUNCTIONS (from hal_mt_kg_pma_device.h) */
/* ========================================================================== */

/**
 * @brief Create device handle.
 *
 * @param [in]     sdk            - SDK handle.
 * @param [in]     device_type    - Device type.
 * @param [out]    device         - Device handle.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_device_create(hal_mt_kg_pma_sdk_t *sdk,
                            hal_mt_kg_pma_device_type_t device_type,
                            hal_mt_kg_pma_device_t **device);

/**
 * @brief Destroy device handle.
 *
 * @param [in]    device    - Device handle.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_device_destroy(hal_mt_kg_pma_device_t *device);

/**
 * @brief Get slice count for device.
 *
 * @param [in]     device         - Device handle.
 * @param [out]    slice_count    - Number of slices.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_device_slice_count_get(hal_mt_kg_pma_device_t *device, int *slice_count);

/**
 * @brief Get slice handle from device.
 *
 * @param [in]     device         - Device handle.
 * @param [in]     slice_index    - Slice index.
 * @param [out]    slice          - Slice handle.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_device_slice_get(hal_mt_kg_pma_device_t *device,
                               int slice_index,
                               hal_mt_kg_pma_slice_t **slice);

/**
 * @brief Register device type (used for device discovery).
 *
 * @param [in]    device_def    - Device definition structure.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_device_register(const void *device_def);

/* ========================================================================== */
/* SLICE FUNCTIONS (from hal_mt_kg_pma_slice.h) */
/* ========================================================================== */

/**
 * @brief Initialize slice.
 *
 * @param [in]    slice     - Slice handle.
 * @param [in]    config    - Slice configuration.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_slice_init(hal_mt_kg_pma_slice_t *slice, const hal_mt_kg_pma_slice_config_t *config);

/**
 * @brief Re-initialize slice.
 *
 * @param [in]    slice        - Slice handle.
 * @param [in]    init_type    - Initialization type.
 * @param [in]    firmware     - Firmware path.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_slice_reinit(hal_mt_kg_pma_slice_t *slice,
                           hal_mt_kg_pma_slice_init_type_t init_type,
                           const char *firmware);

/**
 * @brief Set slice option.
 *
 * @param [in]    slice          - Slice handle.
 * @param [in]    option_name    - Option name.
 * @param [in]    value          - Option value.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_slice_option_set(hal_mt_kg_pma_slice_t *slice, const char *option_name, int value);

/**
 * @brief Get slice parameter.
 *
 * @param [in]    slice    - Slice handle.
 * @param [in]    name     - Parameter name.
 * @param [in]    index    - Parameter index @param [in,out] data - Parameter data.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_slice_param_set(hal_mt_kg_pma_slice_t *slice,
                              const char *name,
                              int index,
                              hal_mt_kg_pma_param_data_t *data);

/* ========================================================================== */
/* FIRMWARE FUNCTIONS (from hal_mt_kg_pma_firmware.h) */
/* ========================================================================== */

/**
 * @brief Load firmware onto slice.
 *
 * @param [in]    slice         - Slice handle.
 * @param [in]    image_file    - File path to firmware.
 * @param [in]    force         - Force if firmware is already loaded.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_fw_load(hal_mt_kg_pma_slice_t *slice, const char *image_file, int force);

/**
 * @brief Load firmware onto slice from buffer.
 *
 * @param [in]    slice    - Slice handle.
 * @param [in]    buf      - Buffer to load from.
 * @param [in]    size     - Size of the buffer.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_fw_buf_load(hal_mt_kg_pma_slice_t *slice, void *buf, size_t size);

/**
 * @brief Firmware load onto multiple slices simultaneously.
 *
 * @param [in]    slices           - Slices to load to.
 * @param [in]    slice_count      - How many slices to load.
 * @param [in]    image_file       - File path to firmware binary.
 * @param [in]    delay_time_us    - Delay between write frames before writing the next frame.
 * @param [in]    force            - Force if firmware is already loaded.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_fw_bcst_load(hal_mt_kg_pma_slice_t *slices[],
                           int slice_count,
                           const char *image_file,
                           unsigned delay_time_us,
                           int force);

/**
 * @brief Firmware load onto multiple slices simultaneously with a buffer.
 *
 * @param [in]    slices           - Slices to load to.
 * @param [in]    slice_count      - Slice count.
 * @param [in]    buf              - Buffer to load firmware.
 * @param [in]    size             - Size of buffer.
 * @param [in]    delay_time_us    - Delay between write frames before writing the next frame.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_fw_buf_bcast_load(hal_mt_kg_pma_slice_t *slices[],
                                int slice_count,
                                void *buf,
                                size_t size,
                                unsigned delay_time_us);

/**
 * @brief Get firmware running status.
 *
 * @param [in]     slice     - Slice handle.
 * @param [out]    status    - Firmware status.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_fw_status_get(hal_mt_kg_pma_slice_t *slice, unsigned *status);

/**
 * @brief Get the firmware version.
 *
 * @param [in]     slice      - Slice handle.
 * @param [out]    version    - Firmware version encoded.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_fw_version_get(hal_mt_kg_pma_slice_t *slice, unsigned *version);

/**
 * @brief Get the firmware version as a human readable string.
 *
 * @param [in]     slice      - Slice handle.
 * @param [out]    version    - Firmware version string (must be at least 32 bytes).
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_fw_version_str_get(hal_mt_kg_pma_slice_t *slice, char *version);

/**
 * @brief Get the firmware capability.
 *
 * @param [in]    slice        - Slice handle.
 * @param [in]    file_path    - Path to save file.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_fw_capability_get(hal_mt_kg_pma_slice_t *slice, const char *file_path);

/**
 * @brief Execute firmware debug command.
 *
 * @param [in]     slice     - Slice handle.
 * @param [in]     lane      - Lane index.
 * @param [in]     cmd       - Command.
 * @param [in]     arg       - Argument.
 * @param [out]    result    - Result.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_fw_debug_cmd_set(hal_mt_kg_pma_slice_t *slice,
                               int lane,
                               uint32_t cmd,
                               uint32_t arg,
                               uint32_t *result);

/**
 * @brief Get firmware hash.
 *
 * @param [in]     slice    - Slice handle.
 * @param [out]    hash     - Firmware hash.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_fw_hash_get(hal_mt_kg_pma_slice_t *slice, uint32_t *hash);

/**
 * @brief Read firmware register.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     addr     - Register address.
 * @param [out]    value    - Register value.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_fw_reg_read(hal_mt_kg_pma_slice_t *slice, uint32_t addr, uint32_t *value);

/**
 * @brief Write firmware register.
 *
 * @param [in]    slice    - Slice handle.
 * @param [in]    addr     - Register address.
 * @param [in]    value    - Register value.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_fw_reg_write(hal_mt_kg_pma_slice_t *slice, uint32_t addr, uint32_t value);

/**
 * @brief Read firmware register extended.
 *
 * @param [in]     slice      - Slice handle.
 * @param [in]     addr       - Register address.
 * @param [in]     section    - Register section.
 * @param [out]    value      - Register value.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_fw_reg_extend_read(hal_mt_kg_pma_slice_t *slice,
                                 uint32_t addr,
                                 uint32_t section,
                                 uint32_t *value);

/**
 * @brief Write firmware register extended.
 *
 * @param [in]    slice      - Slice handle.
 * @param [in]    addr       - Register address.
 * @param [in]    section    - Register section.
 * @param [in]    value      - Register value.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_fw_reg_extend_write(hal_mt_kg_pma_slice_t *slice,
                                  uint32_t addr,
                                  uint32_t section,
                                  uint32_t value);

/* ========================================================================== */
/* PHY FUNCTIONS (from hal_mt_kg_pma_phy.h) */
/* ========================================================================== */

/**
 * @brief Configure PHY.
 *
 * @param [in]    slice        - Slice handle.
 * @param [in]    lane         - Lane index.
 * @param [in]    lane_mode    - Lane mode.
 * @param [in]    speed        - Speed in kbps.
 * @param [in]    flags        - Configuration flags.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_phy_cfg(hal_mt_kg_pma_slice_t *slice,
                      int lane,
                      hal_mt_kg_pma_lane_mode_t lane_mode,
                      unsigned speed,
                      uint32_t flags);

/**
 * @brief Configure shallow retimer.
 *
 * @param [in]    slice        - Slice handle.
 * @param [in]    lane         - Lane index.
 * @param [in]    lane_mode    - Lane mode.
 * @param [in]    speed        - Speed in kbps.
 * @param [in]    flags        - Configuration flags.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_phy_shallow_retimer_cfg(hal_mt_kg_pma_slice_t *slice,
                                      int lane,
                                      hal_mt_kg_pma_lane_mode_t lane_mode,
                                      unsigned speed,
                                      uint32_t flags);

/**
 * @brief Destroy PHY configuration.
 *
 * @param [in]    slice    - Slice handle.
 * @param [in]    lane     - Lane index.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_phy_destroy(hal_mt_kg_pma_slice_t *slice, int lane);

/**
 * @brief Check if PHY link is up.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     lane     - Lane index.
 * @param [out]    up       - Link up status.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_phy_is_link_up(hal_mt_kg_pma_slice_t *slice, int lane, bool *up);

/* ========================================================================== */
/* LANE FUNCTIONS (from hal_mt_kg_pma_lane.h) */
/* ========================================================================== */

/**
 * @brief Set lane mode.
 *
 * @param [in]    slice        - Slice handle.
 * @param [in]    lane         - Lane index.
 * @param [in]    lane_mode    - Lane mode.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_lane_mode_set(hal_mt_kg_pma_slice_t *slice,
                            int lane,
                            hal_mt_kg_pma_lane_mode_t lane_mode);

/**
 * @brief Get lane mode.
 *
 * @param [in]     slice        - Slice handle.
 * @param [in]     lane         - Lane index.
 * @param [out]    lane_mode    - Lane mode.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_lane_mode_get(hal_mt_kg_pma_slice_t *slice,
                            int lane,
                            hal_mt_kg_pma_lane_mode_t *lane_mode);

/**
 * @brief Get lane speed.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     lane     - Lane index.
 * @param [out]    speed    - Lane speed in kbps.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_lane_speed_get(hal_mt_kg_pma_slice_t *slice, int lane, unsigned *speed);

/**
 * @brief Set lane parameter.
 *
 * @param [in]    slice    - Slice handle.
 * @param [in]    name     - Parameter name.
 * @param [in]    lane     - Lane index.
 * @param [in]    data     - Parameter data.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_lane_param_set(hal_mt_kg_pma_slice_t *slice,
                             const char *name,
                             int lane,
                             const hal_mt_kg_pma_param_data_t *data);

/**
 * @brief Get lane parameter.
 *
 * @param [in]    slice    - Slice handle.
 * @param [in]    name     - Parameter name.
 * @param [in]    lane     - Lane index @param [in,out] data - Parameter data.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_lane_param_get(hal_mt_kg_pma_slice_t *slice,
                             const char *name,
                             int lane,
                             hal_mt_kg_pma_param_data_t *data);

/**
 * @brief Set lane option.
 *
 * @param [in]    slice          - Slice handle.
 * @param [in]    lane           - Lane index.
 * @param [in]    option_name    - Option name.
 * @param [in]    value          - Option value.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_lane_option_set(hal_mt_kg_pma_slice_t *slice,
                              int lane,
                              const char *option_name,
                              int value);

/**
 * @brief Force TX squelch.
 *
 * @param [in]    slice     - Slice handle.
 * @param [in]    lane      - Lane index.
 * @param [in]    enable    - Enable/disable squelch.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_lane_tx_force_squelch_set(hal_mt_kg_pma_slice_t *slice, int lane, uint32_t enable);

/**
 * @brief Force RX squelch.
 *
 * @param [in]    slice     - Slice handle.
 * @param [in]    lane      - Lane index.
 * @param [in]    enable    - Enable/disable squelch.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_lane_rx_force_squelch_set(hal_mt_kg_pma_slice_t *slice, int lane, uint32_t enable);

/**
 * @brief Set loopback mode.
 *
 * @param [in]    slice    - Slice handle.
 * @param [in]    lane     - Lane index.
 * @param [in]    mode     - Loopback mode.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_lane_lb_mode_set(hal_mt_kg_pma_slice_t *slice,
                               int lane,
                               hal_mt_kg_pma_loopback_mode_t mode);

/**
 * @brief Get loopback mode.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     lane     - Lane index.
 * @param [out]    mode     - Loopback mode.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_lane_lb_mode_get(hal_mt_kg_pma_slice_t *slice,
                               int lane,
                               hal_mt_kg_pma_loopback_mode_t *mode);

/**
 * @brief Get lane TX status.
 *
 * @param [in]     slice     - Slice handle.
 * @param [in]     lane      - Lane index.
 * @param [out]    status    - TX status.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_lane_tx_status_get(hal_mt_kg_pma_slice_t *slice,
                                 int lane,
                                 hal_mt_kg_pma_lane_tx_state_t *status);

/* ========================================================================== */
/* PRBS FUNCTIONS (from hal_mt_kg_pma_prbs.h) */
/* ========================================================================== */

/**
 * @brief Set TX PRBS generator.
 *
 * @param [in]    slice      - Slice handle.
 * @param [in]    lane       - Lane index.
 * @param [in]    enable     - Enable/disable.
 * @param [in]    pattern    - PRBS pattern.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_prbs_tx_generator_set(hal_mt_kg_pma_slice_t *slice,
                                    int lane,
                                    int32_t enable,
                                    hal_mt_kg_pma_prbs_pattern_t pattern);

/**
 * @brief Get TX PRBS generator.
 *
 * @param [in]     slice      - Slice handle.
 * @param [in]     lane       - Lane index.
 * @param [out]    enable     - Enable/disable status.
 * @param [out]    pattern    - PRBS pattern.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_prbs_tx_generator_get(hal_mt_kg_pma_slice_t *slice,
                                    int lane,
                                    int32_t *enable,
                                    hal_mt_kg_pma_prbs_pattern_t *pattern);

/**
 * @brief Set RX PRBS checker.
 *
 * @param [in]    slice      - Slice handle.
 * @param [in]    lane       - Lane index.
 * @param [in]    enable     - Enable/disable.
 * @param [in]    pattern    - PRBS pattern.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_prbs_rx_checker_set(hal_mt_kg_pma_slice_t *slice,
                                  int lane,
                                  int32_t enable,
                                  hal_mt_kg_pma_prbs_pattern_t pattern);

/**
 * @brief Get RX PRBS checker.
 *
 * @param [in]     slice      - Slice handle.
 * @param [in]     lane       - Lane index.
 * @param [out]    enable     - Enable/disable status.
 * @param [out]    pattern    - PRBS pattern.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_prbs_rx_checker_get(hal_mt_kg_pma_slice_t *slice,
                                  int lane,
                                  int32_t *enable,
                                  hal_mt_kg_pma_prbs_pattern_t *pattern);

/**
 * @brief Get RX PRBS lock status.
 *
 * @param [in]     slice     - Slice handle.
 * @param [in]     lane      - Lane index.
 * @param [out]    locked    - Lock status.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_prbs_get_rx_lock(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *locked);

/**
 * @brief Get RX PRBS error count.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     lane     - Lane index.
 * @param [out]    count    - Error count.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_prbs_rx_count_get(hal_mt_kg_pma_slice_t *slice, int lane, uint64_t *count);

/**
 * @brief Get RX PRBS BER.
 *
 * @param [in]     slice      - Slice handle.
 * @param [in]     lane       - Lane index.
 * @param [in]     time_ms    - Measurement time in ms.
 * @param [out]    ber        - BER value.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_prbs_rx_ber_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t time_ms, double *ber);

/**
 * @brief Generate TX PRBS error.
 *
 * @param [in]    slice    - Slice handle.
 * @param [in]    lane     - Lane index.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_prbs_tx_error_gen(hal_mt_kg_pma_slice_t *slice, int lane);

/**
 * @brief Reset RX PRBS error count.
 *
 * @param [in]    slice    - Slice handle.
 * @param [in]    lane     - Lane index.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_prbs_rx_count_reset(hal_mt_kg_pma_slice_t *slice, int lane);

/* ========================================================================== */
/* SERDES FUNCTIONS (from hal_mt_kg_pma_serdes.h) */
/* ========================================================================== */

/* Status APIs */

/**
 * @brief Get RX signal detect status.
 *
 * @param [in]     slice            - Slice handle.
 * @param [in]     lane             - Lane index.
 * @param [out]    signal_detect    - Signal detect status.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_get_rx_signal_detect(hal_mt_kg_pma_slice_t *slice,
                                          int lane,
                                          int32_t *signal_detect);

/**
 * @brief Get RX ready status.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     lane     - Lane index.
 * @param [out]    ready    - Ready status.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_get_rx_ready(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *ready);

/**
 * @brief Get PHY ready status.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     lane     - Lane index.
 * @param [out]    ready    - Ready status.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_get_phy_ready(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *ready);

/**
 * @brief Get all PHY ready status.
 *
 * @param [in]     slice    - Slice handle.
 * @param [out]    ready    - Ready status.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_get_all_phy_ready(hal_mt_kg_pma_slice_t *slice, int32_t *ready);

/* Gray Code APIs */

/**
 * @brief Set TX gray code.
 *
 * @param [in]    slice     - Slice handle.
 * @param [in]    lane      - Lane index.
 * @param [in]    enable    - Enable/disable.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_tx_gray_code_set(hal_mt_kg_pma_slice_t *slice, int lane, int32_t enable);

/**
 * @brief Set RX gray code.
 *
 * @param [in]    slice     - Slice handle.
 * @param [in]    lane      - Lane index.
 * @param [in]    enable    - Enable/disable.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_rx_gray_code_set(hal_mt_kg_pma_slice_t *slice, int lane, int32_t enable);

/**
 * @brief Get TX gray code.
 *
 * @param [in]     slice     - Slice handle.
 * @param [in]     lane      - Lane index.
 * @param [out]    enable    - Enable/disable status.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_tx_gray_code_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *enable);

/**
 * @brief Get RX gray code.
 *
 * @param [in]     slice     - Slice handle.
 * @param [in]     lane      - Lane index.
 * @param [out]    enable    - Enable/disable status.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_rx_gray_code_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *enable);

/* Precoder APIs */

/**
 * @brief Set TX precoder.
 *
 * @param [in]    slice     - Slice handle.
 * @param [in]    lane      - Lane index.
 * @param [in]    enable    - Enable/disable.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_tx_precoder_set(hal_mt_kg_pma_slice_t *slice, int lane, int32_t enable);

/**
 * @brief Set RX precoder.
 *
 * @param [in]    slice     - Slice handle.
 * @param [in]    lane      - Lane index.
 * @param [in]    enable    - Enable/disable.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_rx_precoder_set(hal_mt_kg_pma_slice_t *slice, int lane, int32_t enable);

/**
 * @brief Get TX precoder.
 *
 * @param [in]     slice     - Slice handle.
 * @param [in]     lane      - Lane index.
 * @param [out]    enable    - Enable/disable status.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_tx_precoder_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *enable);

/**
 * @brief Get RX precoder.
 *
 * @param [in]     slice     - Slice handle.
 * @param [in]     lane      - Lane index.
 * @param [out]    enable    - Enable/disable status.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_rx_precoder_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *enable);

/* Polarity APIs */

/**
 * @brief Set TX polarity.
 *
 * @param [in]    slice       - Slice handle.
 * @param [in]    lane        - Lane index.
 * @param [in]    polarity    - Polarity setting.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_tx_polarity_set(hal_mt_kg_pma_slice_t *slice, int lane, int32_t polarity);

/**
 * @brief Set RX polarity.
 *
 * @param [in]    slice       - Slice handle.
 * @param [in]    lane        - Lane index.
 * @param [in]    polarity    - Polarity setting.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_rx_polarity_set(hal_mt_kg_pma_slice_t *slice, int lane, int32_t polarity);

/**
 * @brief Get TX polarity.
 *
 * @param [in]     slice       - Slice handle.
 * @param [in]     lane        - Lane index.
 * @param [out]    polarity    - Polarity setting.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_tx_polarity_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *polarity);

/**
 * @brief Get RX polarity.
 *
 * @param [in]     slice       - Slice handle.
 * @param [in]     lane        - Lane index.
 * @param [out]    polarity    - Polarity setting.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_rx_polarity_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *polarity);

/* TX Taps APIs */

/**
 * @brief Set TX taps.
 *
 * @param [in]    slice    - Slice handle.
 * @param [in]    lane     - Lane index.
 * @param [in]    taps     - Tap values array.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_tx_taps_set(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *taps);

/**
 * @brief Get TX taps.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     lane     - Lane index.
 * @param [out]    taps     - Tap values array.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_tx_taps_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *taps);

/* Eye Measurement APIs */

/**
 * @brief Get eye measurement.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     lane     - Lane index.
 * @param [out]    eyes     - Eye measurement values.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_eye_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *eyes);

/**
 * @brief Get raw eye measurement.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     lane     - Lane index.
 * @param [out]    eyes     - Raw eye measurement values.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_raw_eye_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *eyes);

/* Calibration and Tuning APIs */

/**
 * @brief Get TX cap.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     lane     - Lane index.
 * @param [out]    cap      - TX cap value.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_tx_cap_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *cap);

/**
 * @brief Get RX cap.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     lane     - Lane index.
 * @param [out]    cap      - RX cap value.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_rx_cap_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *cap);

/**
 * @brief Get RX DAC.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     lane     - Lane index.
 * @param [out]    dac      - RX DAC value.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_rx_dac_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *dac);

/**
 * @brief Get CTLE values.
 *
 * @param [in]     slice       - Slice handle.
 * @param [in]     lane        - Lane index.
 * @param [out]    ctle_val    - CTLE values array.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_ctle_get(hal_mt_kg_pma_slice_t *slice, int lane, uint32_t *ctle_val);

/**
 * @brief Get AGC gain.
 *
 * @param [in]     slice      - Slice handle.
 * @param [in]     lane       - Lane index.
 * @param [out]    agcgain    - AGC gain values array.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_agcgain_get(hal_mt_kg_pma_slice_t *slice, int lane, uint32_t *agcgain);

/**
 * @brief Get RX attenuator.
 *
 * @param [in]     slice            - Slice handle.
 * @param [in]     lane             - Lane index.
 * @param [out]    atten_en         - Attenuator enable.
 * @param [out]    atten_agcgain    - Attenuator AGC gain.
 * @param [out]    atten_val        - Attenuator value.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_rx_attenuator_get(hal_mt_kg_pma_slice_t *slice,
                                       int lane,
                                       int32_t *atten_en,
                                       int32_t *atten_agcgain,
                                       int32_t *atten_val);

/**
 * @brief Get OF value.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     lane     - Lane index.
 * @param [out]    of       - OF value.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_of_get(hal_mt_kg_pma_slice_t *slice, int lane, uint32_t *of);

/**
 * @brief Get HF value.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     lane     - Lane index.
 * @param [out]    hf       - HF value.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_hf_get(hal_mt_kg_pma_slice_t *slice, int lane, uint32_t *hf);

/**
 * @brief Get DFE taps.
 *
 * @param [in]     slice       - Slice handle.
 * @param [in]     lane        - Lane index.
 * @param [out]    dfe_taps    - DFE tap values array.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_dfe_get(hal_mt_kg_pma_slice_t *slice, int lane, double *dfe_taps);

/**
 * @brief Get F1/F3 value.
 *
 * @param [in]     slice      - Slice handle.
 * @param [in]     lane       - Lane index.
 * @param [out]    f13_val    - F1/F3 value.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_f1over3_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *f13_val);

/**
 * @brief Get delta phase.
 *
 * @param [in]     slice        - Slice handle.
 * @param [in]     lane         - Lane index.
 * @param [out]    delta_val    - Delta phase value.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_delta_phase_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *delta_val);

/**
 * @brief Get edge values.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     lane     - Lane index.
 * @param [out]    edge     - Edge values array.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_edge_get(hal_mt_kg_pma_slice_t *slice, int lane, uint32_t *edge);

/**
 * @brief Get RX SKEF parameters.
 *
 * @param [in]     slice          - Slice handle.
 * @param [in]     lane           - Lane index.
 * @param [out]    skef_en        - SKEF enable.
 * @param [out]    skef_val       - SKEF value.
 * @param [out]    skef_addcap    - SKEF additional cap.
 * @param [out]    skef_gain      - SKEF gain.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_rx_skef_get(hal_mt_kg_pma_slice_t *slice,
                                 int lane,
                                 int32_t *skef_en,
                                 int32_t *skef_val,
                                 int32_t *skef_addcap,
                                 int32_t *skef_gain);

/**
 * @brief Get FFE taps.
 *
 * @param [in]     slice       - Slice handle.
 * @param [in]     lane        - Lane index.
 * @param [out]    ffe_taps    - FFE tap values array.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_ffe_taps_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *ffe_taps);

/**
 * @brief Get RX PPM.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     lane     - Lane index.
 * @param [out]    ppm      - PPM value.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_rx_ppm_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *ppm);

/**
 * @brief Get TX MSB.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     lane     - Lane index.
 * @param [out]    msb      - TX MSB value.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_tx_msb_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *msb);

/**
 * @brief Get RX MSB.
 *
 * @param [in]     slice    - Slice handle.
 * @param [in]     lane     - Lane index.
 * @param [out]    msb      - RX MSB value.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_rx_msb_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *msb);

/**
 * @brief Get RX coupling.
 *
 * @param [in]     slice       - Slice handle.
 * @param [in]     lane        - Lane index.
 * @param [out]    coupling    - RX coupling mode.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_rx_coupling_get(hal_mt_kg_pma_slice_t *slice,
                                     int lane,
                                     hal_mt_kg_pma_lane_coupling_t *coupling);

/**
 * @brief Get ISI values.
 *
 * @param [in]     slice      - Slice handle.
 * @param [in]     lane       - Lane index.
 * @param [out]    isi_val    - ISI values array.
 * @return         Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_serdes_isi_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *isi_val);

/* ========================================================================== */
/* SHELL FUNCTIONS (from hal_mt_kg_pma_shell.h) */
/* ========================================================================== */

/**
 * @brief Shell.
 *
 * @param [in]    slices         - Slices to spawn shell. Use NULL to use current slices.
 * @param [in]    slice_count    - How many slices to spawn shell. Pass 0 for current slices.
 * @return        Error Code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_shell_spawn_start(hal_mt_kg_pma_slice_t *slices[], int slice_count);

/**
 * @brief Spawn shell with battery included tools.
 *
 * @return        Error Code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_shell_spawn_enhanced_start(void);

/**
 * @brief Run a shell socket server.
 *
 * @return        Error Code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_shell_spawn_server_start(void);

/**
 * @brief Run a shell socket server with custom socket path.
 *
 * @param [in]    socket_path    - Path to set socket. Pass NULL to use the default path.
 * @return        Error Code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_shell_spawn_server_with_path_start(const char *socket_path);

/**
 * @brief Set shell slices.
 *
 * @param [in]    slices         - Slices to set.
 * @param [in]    slice_count    - How many slices.
 * @return        Error Code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_shell_slices_set(hal_mt_kg_pma_slice_t *slices[], int slice_count);

/**
 * @brief Set the shell logger callback.
 *
 * @param [in]    shell_log_cb    - Shell log call back function.
 * @return        Error Code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_shell_logger_set(hal_mt_kg_pma_log_t shell_log_cb);

/**
 * @brief Set if the shell should stop the world (STW) for all its slices.
 *
 * @param [in]    stw    - Set stop the world.
 * @return        Error Code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_shell_stw_set(bool stw);

/**
 * @brief Set a tee file to additionaly print stdout.
 *
 * @param [in]    file    - File path to tee, can be NULL to disable teeing.
 * @param [in]    mode    - Mode to open tee file, Recommend "a" to append to the file.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_shell_teefile_set(const char *file, const char *mode);

#ifdef __cplusplus
}
#endif

/* ========================================================================== */
/* EYE FUNCTIONS (from hal_mt_kg_pma_eye.h) */
/* ========================================================================== */
/**
 * @brief Start eye monitor.
 *
 * @param [in]    slice      - Slice handle.
 * @param [in]    lane       - Lane index.
 * @param [in]    ber_exp    - Ber_exp.
 * @param [in]    flag       - Flag.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_eye_monitor_start(hal_mt_kg_pma_slice_t *slice,
                                int lane,
                                int32_t ber_exp,
                                int32_t flag);

/**
 * @brief Stop eye monitor.
 *
 * @param [in]    slice    - Slice handle.
 * @param [in]    lane     - Lane index.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_eye_monitor_stop(hal_mt_kg_pma_slice_t *slice, int lane);

/**
 * @brief Get eye monitor progress.
 *
 * @param [in]    slice      - Slice handle.
 * @param [in]    lane       - Lane index.
 * @param [in]    percent    - Percent 100 means data ready.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_eye_monitor_step_get(hal_mt_kg_pma_slice_t *slice, int lane, int32_t *percent);

/**
 * @brief Capture eye data on the heap.
 *
 * @param [in]    slice    - Slice handle.
 * @param [in]    lane     - Lane index.
 * @param [in]    data     - Eye data. Must free data.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_eye_monitor_data_get(hal_mt_kg_pma_slice_t *slice,
                                   int lane,
                                   hal_mt_kg_pma_eye_monitor_data_t *data);

/**
 * @brief Get eye monitor vertical and horizontal range.
 *
 * @param [in]    slice         - Slice handle.
 * @param [in]    lane          - Lane index.
 * @param [in]    vstep_side    - Vstep_side is defined in firmware.
 * @param [in]    hstep_side    - Hstep_side is defined in firmware, return 0 if bathtub mode.
 * @return        Error code.
 */
hal_mt_kg_pma_error_t
hal_mt_kg_pma_eye_monitor_range_get(hal_mt_kg_pma_slice_t *slice,
                                    int lane,
                                    int32_t *vstep_side,
                                    int32_t *hstep_side);

#endif /* HAL_MT_KG_PMA_H */
