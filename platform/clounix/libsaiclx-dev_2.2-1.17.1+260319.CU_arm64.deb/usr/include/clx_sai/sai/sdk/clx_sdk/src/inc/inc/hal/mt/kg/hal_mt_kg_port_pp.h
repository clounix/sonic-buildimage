/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_port_pp.h
 * PURPOSE:
 *      It provide HAL PORT PP module API.
 * NOTES:
 */

#ifndef HAL_MT_KG_PORT_PP_H
#define HAL_MT_KG_PORT_PP_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>
#include <hal/mt/hal_mt_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
clx_error_no_t
hal_mt_kg_port_pp_init(const uint32 unit);

clx_error_no_t
hal_mt_kg_port_pp_port_poc_init(const uint32 unit, const uint32 port);

clx_error_no_t
hal_mt_kg_port_pp_port_type_init(const uint32 unit,
                                 const uint32 port,
                                 const hal_mt_port_type_t port_type);
/**
 * @brief This API is used to set destination index.
 *
 * Support_chip: CLX8400.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port.
 * @param [in]    di      - Destination index.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_pp_di_set(const uint32 unit, const uint32 port, const uint32 di);

/**
 * @brief Set pp Port config.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Port ID.
 * @param [in]    ptr_config    - Port config.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_pp_cfg_set(const uint32 unit, const uint32 port, const clx_port_cfg_t *ptr_config);

/**
 * @brief Get pp port config.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Port ID.
 * @param [out]    ptr_config    - Port config.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_pp_cfg_get(const uint32 unit, const uint32 port, clx_port_cfg_t *ptr_config);

/**
 * @brief Set replace mac Enable per physical port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    type      - Refer to hal_mt_port_ts_replace_type_t.
 * @param [in]    enable    - 1: enable timestamp replace mac 0: disable timestamp replace mac.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_pp_ts_replace_mac_en_set(const uint32 unit,
                                        const uint32 port,
                                        const hal_mt_port_ts_replace_type_t type,
                                        const boolean enable);

/**
 * @brief Get replace mac Enable per physical port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [in]     type          - Refer to hal_mt_port_ts_replace_type_t.
 * @param [out]    ptr_enable    - 0/1: disable/enable timestamp replace mac,
 *                                 .
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_pp_ts_replace_mac_en_get(const uint32 unit,
                                        const uint32 port,
                                        const hal_mt_port_ts_replace_type_t type,
                                        boolean *ptr_enable);

/**
 * @brief Set egress high latency per physical port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - Enable/Disable high latency.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_pp_egr_high_latency_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Get high latency per physical port.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Physical port id.
 * @param [out]    enable    - Enable/Disable high latency.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_pp_egr_high_latency_get(const uint32 unit, const uint32 port, boolean *enable);

/**
 * @brief Set high latency threshold.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    threshold    - High latency threshold.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_pp_egr_high_latency_thd_set(const uint32 unit, const uint32 threshold);

/**
 * @brief Get high latency threshold.
 *
 * @param [in]     unit         - Device unit number.
 * @param [out]    threshold    - High latency threshold.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_pp_egr_high_latency_thd_get(const uint32 unit, uint32 *threshold);

/**
 * @brief Get port timestamp state.
 *
 * @param [in]     unit          - Chip id.
 * @param [in]     port          - Port id.
 * @param [out]    ptr_enable    - Timestamp state.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_pp_ts_state_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

#endif /* HAL_MT_KG_PORT_PP_H */