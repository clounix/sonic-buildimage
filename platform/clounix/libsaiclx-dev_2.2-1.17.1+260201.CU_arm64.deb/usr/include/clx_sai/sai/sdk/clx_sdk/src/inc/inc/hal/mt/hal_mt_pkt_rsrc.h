/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_pkt_rsrc.h
 * PURPOSE:
 *      It provides hal pkt module API.
 * NOTES:
 *
 */

#ifndef HAL_MT_PKT_RSRC_H
#define HAL_MT_PKT_RSRC_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_pkt.h>

#include <hal/hal_pkt_rsrc.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
#define HAL_MT_PKT_PP_RSN_NUM   512
#define HAL_MT_PKT_RSN_BMP_SIZE (CLX_BITMAP_SIZE(HAL_MT_PKT_PP_RSN_NUM))
typedef uint32 hal_mt_pkt_pp_rsn_bmp_t[HAL_MT_PKT_RSN_BMP_SIZE];

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MT_PKT_FOREACH_RSN_BIT(pp_reason_bitmap, pp_reason)         \
    for (pp_reason = 0; pp_reason < HAL_MT_PKT_PP_RSN_NUM; pp_reason++) \
        if (CLX_PKT_RSN_BMP_CHK(pp_reason_bitmap, pp_reason))

/* INTERNAL SUBPROGRAM SPECIFICATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief To configure the mapping from user-view reason to the RX CPU queue.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    queue            - The specified queue.
 * @param [in]    reason_bitmap    - The reason bitmap.
 * @return        CLX_E_OK        - Successfully configure the mapping.
 * @return        CLX_E_OTHERS    - Configure the mapping failed.
 */
clx_error_no_t
hal_mt_pkt_rsrc_que_rsn_mapping_set(const uint32 unit,
                                    const uint32 queue,
                                    const clx_pkt_rx_rsn_bmp_t reason_bitmap);

/**
 * @brief To get the mapping from user-view reason to the CPU queue.
 *
 * @param [in]    unit                 - Device unit number.
 * @param [in]    queue                - The specified queue.
 * @param [in]    ptr_reason_bitmap    - Pointer of the reason bitmap.
 * @return        CLX_E_OK        - Successfully get the mapping.
 * @return        CLX_E_OTHERS    - Get the mapping failed.
 */
clx_error_no_t
hal_mt_pkt_rsrc_que_rsn_mapping_get(const uint32 unit,
                                    const uint32 queue,
                                    clx_pkt_rx_rsn_bmp_t *ptr_reason_bitmap);

#endif
