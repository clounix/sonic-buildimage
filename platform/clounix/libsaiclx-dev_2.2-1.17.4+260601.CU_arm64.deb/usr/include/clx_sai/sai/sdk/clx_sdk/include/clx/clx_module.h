/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   clx_module.h
 * PURPOSE:
 *      Define the software modules in CLX SDK.
 * NOTES:
 */

#ifndef CLX_MODULE_H
#define CLX_MODULE_H

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define CLX_MODULE_MAX_LENGTH_OF_NAME (8)
/*
 * +--------------+------------------------------------+
 * | Abbreviation | Description                        |
 * +--------------+------------------------------------+
 * | BD           | Bridge Domain                      |
 * | CFG          | Configuration                      |
 * | CIA          | Content Inspection Agent           |
 * | DSH          | Diagnostic Shell                   |
 * | ECC          | Error Checking and Correcting      |
 * | ECPU         | Embedded CPU                       |
 * | EPG          | EPL Packet Genarate                |
 * | IFMON        | Interface Monitor                  |
 * | L2           | Layer 2                            |
 * | L3           | Layer 3                            |
 * | LAG          | Link Aggregation Group             |
 * | MIR          | Mirror                             |
 * | MPLS         | Multi-Protocol Label Switching     |
 * | NETIF        | Network Interface                  |
 * | PHY          | Physical                           |
 * | PKJ          | Packet Journal                     |
 * | PKT          | Packet                             |
 * | QOS          | Quality of Service                 |
 * | SEC          | Security                           |
 * | SRV6         | Segment Routing over IPv6          |
 * | STAT         | Statistic                          |
 * | STK          | Stacking                           |
 * | STP          | Spanning Tree Protocol             |
 * | SWC          | Switch Control                     |
 * | TECH         | Technical                          |
 * | TELM         | Telemetry                          |
 * | TM           | Traffic Management                 |
 * | TNL          | Tunnel                             |
 * | VLAN         | Virtual Local Area Network         |
 * | MISC         | Miscellaneous                      |
 * | WLAN         | Wireless Local Area Network        |
 * | SFLOW        | Sampled Flow                       |
 * | DIAG         | Diagnostic                         |
 * | OSAL         | OS Abstraction Layer               |
 * | DRV          | Driver                             |
 * | HAL          | Hardware Abstraction Layer         |
 * | TOD          | Time of Day                        |
 * | INTR         | Interrupt                          |
 * | TOB          | Table Operation Bus                |
 * | BFD          | Bidirectional Forwarding Detection |
 * | PTP          | Precision Time Protocol            |
 * | D2D          | Die to Die                         |
 * | VM           | Virtual Machine                    |
 * | NFE          | Network Flow Engine                |
 * +--------------+------------------------------------+
 */
#define MODULE_LIST(maker)                                                                        \
    maker(BD, bd) maker(VLAN, vlan) maker(PORT, port) maker(IFMON, ifmon) maker(L2, l2)           \
        maker(STP, stp) maker(LAG, lag) maker(MIR, mir) maker(L3, l3) maker(TNL, tnl)             \
            maker(SWC, swc) maker(QOS, qos) maker(METER, meter) maker(PKT, pkt) maker(CIA, acl)   \
                maker(STAT, stat) maker(SEC, sec) maker(SFLOW, sflow) maker(TM, tm)               \
                    maker(DIAG, diag) maker(LOG, log) maker(OSAL, osal) maker(DRV, drv)           \
                        maker(HAL, hal) maker(PHY, phy) maker(INIT, init) maker(MPLS, mpls)       \
                            maker(CHIP, chip) maker(MISC, misc) maker(STK, stk) maker(TELM, telm) \
                                maker(SRV6, srv6) maker(ECC, ecc) maker(ECPU, ecpu)               \
                                    maker(TOD, tod) maker(INTR, intr) maker(CFG, cfg)             \
                                        maker(UTIL, util) maker(TOB, tob) maker(BFD, bfd)         \
                                            maker(PTP, ptp) maker(D2D, d2d) maker(VM, vm)         \
                                                maker(WLAN, wlan) maker(NFE, nfe) maker(ALL, all) \
                                                    maker(LAST, )
#define MODULE_ENUM(module, module_name)   CLX_MODULE_##module,
#define MODULE_STRING(module, module_name) #module_name,

/* DATA TYPE DECLARATIONS
 */
typedef enum clx_module_e { MODULE_LIST(MODULE_ENUM) } clx_module_t;

#define CLX_MODULE_NUMER_OF_MODULES (CLX_MODULE_LAST)

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief This API returns the module name by given module ID. All modules could invoke this API.
 *
 * Prepare memory to receive this output. The maximum length of module name is
 * CLX_MODULE_MAX_LENGTH_OF_NAME.
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    module_id    - Module ID, range from 0 to (CLX_MODULE_LAST - 1).
 * @return        char *    - Pointer of output module name.
 */
const char *
clx_module_name_get(const uint32 module_id);
#endif /* CLX_MODULE_H */
