/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
/* FILE NAME:  hal_mt_port.h
 * PURPOSE:
 *      It provide HAL PORT module API.
 * NOTES:
 */
#ifndef HAL_MT_PORT_H
#define HAL_MT_PORT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>
#include <hal/hal_port.h>
#include <util/lib/util_lib_avl.h>
#include <hal/mt/nb/hal_mt_nb_mac.h>
#include <hal/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_NB_PTP_MSG_ONE_STEP      (0x1)
#define HAL_MT_NB_PTP_MSG_TWO_STEP      (0x2)
#define HAL_MT_NB_PTP_MSG_DELAY         (0x1)
#define HAL_MT_NB_PTP_MSG_PDELAY        (0x2)
#define HAL_MT_PORT_REG_FIELDS_MAX_SIZE (32 + 1)
/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MT_PORT_CHK_BITMAP(bitmap, bit) ((bitmap) & (bit))

#define HAL_MT_PORT_LOCK(unit)   hal_mt_port_rsc_lock(unit)
#define HAL_MT_PORT_UNLOCK(unit) hal_mt_port_rsc_unlock(unit)

#define HAL_MT_PORT_GET_SHIFT(__VALUE__)   ((__VALUE__) > 1 ? (31 - __builtin_clz((__VALUE__))) : 0)
#define HAL_MT_PORT_NUM_TO_ONES(__VALUE__) ((1ULL << (__VALUE__)) - 1)

#define HAL_MT_PORT_DBG_MODULE_TYPE_MAC (1)
#define HAL_MT_PORT_DBG_MODULE_TYPE_IPL (2)
#define HAL_MT_PORT_DBG_MODULE_TYPE_EPL (3)

#define HAL_MT_PORT_PHY_WBDB_CFG_MAX_SIZE (140000)
/* EXPORTED SUBPROGRAM SPECIFICATIONS */

typedef enum hal_mt_port_type_e {
    HAL_MT_PORT_TYPE_NOR = 0,
    HAL_MT_PORT_TYPE_REC = 1,
    HAL_MT_PORT_TYPE_CPU = 2,
    HAL_MT_PORT_TYPE_FAB = 3
} hal_mt_port_type_t;

typedef enum hal_mt_port_flow_ctrl_type_e {
    HAL_MT_PORT_FLOW_CTRL_TYPE_LFC = 0,
    HAL_MT_PORT_FLOW_CTRL_TYPE_PFC = 1,
    HAL_MT_PORT_FLOW_CTRL_TYPE_LAST
} hal_mt_port_flow_ctrl_type_t;

/* Synce mode */
typedef enum hal_mt_port_synce_mode_e {
    HAL_MT_PORT_SYNCE_MODE_DISABLE = 0x0,             /* Synce mode disable */
    HAL_MT_PORT_SYNCE_MODE_0 = CLX_PORT_SYNCE_MODE_0, /* Synce mode 0 */
    HAL_MT_PORT_SYNCE_MODE_1 = CLX_PORT_SYNCE_MODE_1, /* Synce mode 1 */
    HAL_MT_PORT_SYNCE_MODE_LAST
} hal_mt_port_synce_mode_t;

typedef enum hal_mt_port_speed_code_e {
    HAL_MT_PORT_SPEED_CODE_DEFAULT = 0x0,
    HAL_MT_PORT_SPEED_CODE_10M = 0x1,
    HAL_MT_PORT_SPEED_CODE_100M = 0x2,
    HAL_MT_PORT_SPEED_CODE_1G = 0x3,
    HAL_MT_PORT_SPEED_CODE_2P5G = 0x4,
    HAL_MT_PORT_SPEED_CODE_5G = 0x5,
    HAL_MT_PORT_SPEED_CODE_10G = 0x6,
    HAL_MT_PORT_SPEED_CODE_25G = 0x7,
    HAL_MT_PORT_SPEED_CODE_40G = 0x8,
    HAL_MT_PORT_SPEED_CODE_50G = 0x9,
    HAL_MT_PORT_SPEED_CODE_100G = 0xa,
    HAL_MT_PORT_SPEED_CODE_200G = 0xb,
    HAL_MT_PORT_SPEED_CODE_400G = 0xc,
    HAL_MT_PORT_SPEED_CODE_800G = 0xd,
    HAL_MT_PORT_SPEED_CODE_LAST
} hal_mt_port_speed_code_t;

typedef enum hal_mt_port_ptp_mode_e {
    HAL_PORT_PTP_MODE_DISABLE = 0,
    HAL_PORT_PTP_MODE_MASTER,
    HAL_PORT_PTP_MODE_SLAVE,
    HAL_PORT_PTP_MODE_TRANSPARENT,
    HAL_PORT_PTP_MODE_LAST
} hal_mt_port_ptp_mode_t;

typedef enum hal_mt_port_wbdb_id_e {
    HAL_MT_PORT_WBDB_ID_PBM = 0,
    HAL_MT_PORT_WBDB_ID_TOTAL_PBM,
    HAL_MT_PORT_WBDB_ID_TXS,
    HAL_MT_PORT_WBDB_ID_RXS,
    HAL_MT_PORT_WBDB_ID_LANE_CNT,
    HAL_MT_PORT_WBDB_ID_LFC_TX,
    HAL_MT_PORT_WBDB_ID_PFC_TX,
    HAL_MT_PORT_WBDB_ID_PORT_MAP,
    HAL_MT_PORT_WBDB_ID_PLANE_PORT_MAP,
    HAL_MT_PORT_WBDB_ID_CPI_PORT,
    HAL_MT_PORT_WBDB_ID_CPI_PORT_MODE,
    HAL_MT_PORT_WBDB_ID_LAST
} hal_mt_port_wbdb_id_t;

typedef enum hal_mt_port_phy_wbdb_id_e {
    HAL_MT_PHY_WBDB_ID_PHY_CFG = 0,
    HAL_MT_PHY_WBDB_ID_LAST
} hal_mt_port_phy_wbdb_id_t;

typedef enum hal_mt_port_ts_replace_type_e {
    HAL_MT_PORT_TS_REPLACE_TPYE_MAC = 0,
    HAL_MT_PORT_IGR_TS_REPLACE_SRC_MAC,
    HAL_MT_PORT_EGR_TS_REPLACE_DST_MAC,
} hal_mt_port_ts_replace_type_t;

typedef enum hal_mt_port_dbg_type_e {
    HAL_MT_PORT_DBG_TYPE_CNT = 1,
    HAL_MT_PORT_DBG_TYPE_REG_CFG = 2,
    HAL_MT_PORT_DBG_TYPE_REG_STA = 3,
    HAL_MT_PORT_DBG_TYPE_REG_CNT = 4,
    HAL_MT_PORT_DBG_TYPE_REG_IRQ = 5,
    HAL_MT_PORT_DBG_TYPE_BUF_CFG = 6,
    HAL_MT_PORT_DBG_TYPE_BUF_USAGE = 7,
    HAL_MT_PORT_DBG_TYPE_TDM2SLOT = 8,
    HAL_MT_PORT_DBG_TYPE_XOFF_STATUS = 9,
    HAL_MT_PORT_DBG_TYPE_AVERAGE_RATE = 10,
    HAL_MT_PORT_DBG_TYPE_LAST
} hal_mt_port_dbg_type_t;

typedef enum hal_mt_port_dead_lock_mode_e {
    HAL_MT_PORT_DEAD_LOCK_PAUSE_MODE = 1,
    HAL_MT_PORT_DEAD_LOCK_PFC_MODE = 2,
    HAL_MT_PORT_DEAD_LOCK_FC_DIS_MODE = 3,
    HAL_MT_PORT_DEAD_LOCK_PFC_DIS_MODE = 4,
    HAL_MT_PORT_DEAD_LOCK_PAUSE_MODE_LAST
} hal_mt_port_dead_lock_mode_t;

typedef enum hal_mt_port_queue_type_e {
    HAL_MT_PORT_LOSSY_QUEUE = 0,
    HAL_MT_PORT_LOSSLESS_QUEUE = 1,
    HAL_MT_PORT_QUEUE_TYPE_LAST
} hal_mt_port_queue_type_t;

clx_error_no_t
hal_mt_port_sw_state_update(const uint32 unit,
                            const uint32 port,
                            const clx_dir_t dir,
                            const uint32 enable);

clx_error_no_t
hal_mt_port_fc_tx_update(const uint32 unit,
                         const uint32 port,
                         const hal_mt_port_flow_ctrl_type_t fc_type,
                         const uint32 flow_ctrl);

clx_error_no_t
hal_mt_port_fc_tx_get(const uint32 unit,
                      const uint32 port,
                      const hal_mt_port_flow_ctrl_type_t fc_type,
                      uint32 *flow_ctrl);

clx_error_no_t
hal_mt_port_default_speed_get(const uint32 unit, const uint32 port, clx_port_speed_t *ptr_speed);

/**
 * @brief Get the index for the specify speed.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port id.
 * @param [in]     speed      - Port speed.
 * @param [out]    ptr_idx    - Default medium type.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_speed_idx_get(const uint32 unit,
                          const uint32 port,
                          const clx_port_speed_t speed,
                          uint32 *ptr_idx);

/**
 * @brief Get the index for the specify lane cnt.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port id.
 * @param [in]     lane_cnt    - Port speed.
 * @param [out]    ptr_idx     - Default medium type.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_lane_cnt_idx_get(const uint32 unit,
                             const uint32 port,
                             const uint32 lane_cnt,
                             uint32 *ptr_idx);

/**
 * @brief To update default lane count for a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port id.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_default_lane_cnt_update(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to set the medium type for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port ID.
 * @param [in]    medium    - Medium type.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_medium_type_set(const uint32 unit,
                                const uint32 port,
                                const clx_port_medium_t medium);

clx_error_no_t
hal_mt_port_rsc_lock(const uint32 unit);

clx_error_no_t
hal_mt_port_rsc_unlock(const uint32 unit);

/**
 * @brief Get port speed and lane cnt combination.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     speed             - Port speed,clx_port_speed_t.
 * @param [in]     lane_cnt          - Lane cnt.
 * @param [out]    ptr_speed_lane    - Pointer to speed_lane_cnt.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_port_speed_lane_cnt_trans(const uint32 unit,
                                 const clx_port_speed_t speed,
                                 const uint32 lane_cnt,
                                 hal_port_speed_lane_t *ptr_speed_lane);
/**
 * @brief Check if the port speed is valid.
 *
 * ETHL port supports 10g/25g/40g/50g/100g/200g/400g/800g and
 * ETHX port supports 10g/25g/40g/50g/100g only.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port id.
 * @param [in]    speed    - Port speed.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_speed_check(const uint32 unit, const uint32 port, const clx_port_speed_t speed);

/**
 * @brief Get the default fec for the specify medium type.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port id.
 * @param [in]     speed       - Port speed.
 * @param [in]     lane_cnt    - Port lane cnt.
 * @param [out]    ptr_fec     - Default fec type.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_default_fec_get(const uint32 unit,
                            const uint32 port,
                            const clx_port_speed_t speed,
                            const uint32 lane_cnt,
                            uint32 *ptr_fec);
/**
 * @brief Get the default medium type for the specify speed.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [in]     speed         - Port speed.
 * @param [in]     lane_cnt      - Port lane cnt.
 * @param [out]    ptr_medium    - Default medium type.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_default_medium_get(const uint32 unit,
                               const uint32 port,
                               const clx_port_speed_t speed,
                               const uint32 lane_cnt,
                               clx_port_medium_t *ptr_medium);

/**
 * @brief This API is used to set the lane count for a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @param [in]    cnt     - Lane count.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_lane_cnt_set(const uint32 unit, const uint32 port, const uint32 cnt);

/**
 * @brief This API is used to get the lane count for a specific port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port ID.
 * @param [out]    ptr_cnt    - Lane count.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_lane_cnt_get(const uint32 unit, const uint32 port, uint32 *ptr_cnt);

/**
 * @brief This API is used to set the AN ability for a specific port.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port           - Physical port ID.
 * @param [in]    ptr_ability    - Auto-negotiation ability setting per port.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_adv_ability_check(const uint32 unit,
                              const uint32 port,
                              const clx_port_ability_t *ptr_ability);
/**
 * @brief To initialize port module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK                - Operate success.
 * @return        CLX_E_ALREADY_INITED    - Module is reinitialized.
 * @return        CLX_E_OTHERS            - Init fail.
 */
clx_error_no_t
hal_mt_port_init(const uint32 unit);

/**
 * @brief To deinitialize the port module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK            - Success.
 * @return        CLX_E_NOT_INITED    - Module is not initialized.
 * @return        CLX_E_OTHERS        - Deinitialization failed for other reasons.
 */
clx_error_no_t
hal_mt_port_deinit(const uint32 unit);

/**
 * @brief Set port timestamp state.
 *
 * @param [in]    unit      - Chip id.
 * @param [in]    port      - Port id.
 * @param [in]    enable    - Timestamp state.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_port_ts_state_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Set port rx/tx TS latency based on clock, port speed and FEC.
 *
 * @param [in]    unit    - Chip id.
 * @param [in]    port    - Port id.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_port_ts_latency_update(const uint32 unit, const uint32 port);

/**
 * @brief Get tx rs rstate per physical port.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port id.
 * @param [in]    ptr_enable    - 1: tx state is enalbed 0: tx state is disabled.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_tx_rs_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief Get rx state per physical port.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port id.
 * @param [in]    ptr_enable    - 1: rx state is enalbed 0: rx state is disabled.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_rx_rs_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief Dump the database per physical port.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    flags    - Database type.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_db_dump(const uint32 unit, const uint32 flags);

/**
 * @brief This API is used to enable hub logic memory interrupt.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port ID.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_hub_lm_intr_enable(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to get link database for a specific port.
 *
 * There are 8 bits for 8 priority flow control state in pfc_tx.
 * Tx flow control state for priority x (x = 0~7) = pfc_tx & (1 << x).
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Physical port id.
 * @param [out]    ptr_tx_state    - Tx state.
 * @param [out]    ptr_rx_state    - Rx state.
 * @param [out]    ptr_lfc_tx      - Local flow control state.
 * @param [out]    ptr_pfc_tx      - Priority flow control state.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_mt_port_link_db_get(const uint32 unit,
                        const uint32 port,
                        uint32 *ptr_tx_state,
                        uint32 *ptr_rx_state,
                        uint32 *ptr_lfc_tx,
                        uint32 *ptr_pfc_tx);

/**
 * @brief This API is used to trans clx port speed to hal port speed code.
 *
 * @param [in]    speed         - Physical port speed.
 * @param [in]    speed_code    - Physical port speed code.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_speed_trans(const uint32 speed, uint32 *speed_code);

#if 0
/**
 * @brief Set phy prbs error inject.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Physical port ID.
 * @param [in]    num_err    - Parameter if necessary.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_prbs_err_inject(const uint32 unit, const uint32 port, const uint32 num_err);

/**
 * @brief Set port prbs error bits clear.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port ID.
 * @param [in]    lane_bmp    - Lane bitmap.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_prbs_err_cnt_clear_set(const uint32 unit, const uint32 port, const uint32 lane_bmp);

/**
 * @brief Get phy firmware version.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     port               - Physical port ID.
 * @param [out]    ptr_version_eth    - Eth phy firmware version.
 * @param [out]    ptr_version_cpi    - Cpi phy firmware version.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_fw_version_get(const uint32 unit,
                               const uint32 port,
                               uint32 *ptr_version_eth,
                               uint32 *ptr_version_cpi);

/**
 * @brief Get phy rate code.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [out]    pma_rate    - Phy rate code: 0: 10P3125 1: 25P78125 2: 26P5625 3: 53P125_NRZ 4:
 *                               53P125_PAM4 5: 56P25_PAM4 6: 106P25 7: 112P5.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_rate_get(const uint32 unit, const uint32 port, uint32 *pma_rate);

/**
 * @brief Set phy to isolation mode.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port ID.
 * @param [in]    lane_bmp    - Lane bitmap.
 * @param [in]    enable      - Enable/disable isolation mode.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_isola_mode_set(const uint32 unit,
                               const uint32 port,
                               const uint32 lane_bmp,
                               const uint32 enable);

/**
 * @brief Set phy tx or rx powerup.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port ID.
 * @param [in]    lane_bmp      - Lane bitmap.
 * @param [in]    module        - Tx or rx.
 * @param [in]    lane_speed    - Serdes lane speed.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_txrx_powerup_set(const uint32 unit,
                                 const uint32 port,
                                 const uint32 lane_bmp,
                                 const clx_dir_t module,
                                 const clx_port_lane_speed_t lane_speed);

/**
 * @brief Set phy tx elecidle.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port ID.
 * @param [in]    enable    - Enable or disable.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_tx_elecidle_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Get phy tx elecidle.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port ID.
 * @param [out]    ptr_enable    - Phy tx elecidle.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_tx_elecidle_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief Set phy rx termination mode.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port ID.
 * @param [in]    lane_bmp    - Lane bitmap.
 * @param [in]    mode        - Termination mode.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_rx_term_set(const uint32 unit,
                            const uint32 port,
                            const uint32 lane_bmp,
                            const clx_port_acc_term_mode_t mode);

/**
 * @brief Get phy rx termination mode.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [out]    ptr_mode    - Phy rx termination mode.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_rx_term_get(const uint32 unit, const uint32 port, uint32 *ptr_mode);

/**
 * @brief Get phy Atest or Pmon data.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port ID.
 * @param [in]    lane_bmp    - Lane bitmap.
 * @param [in]    mode        - Atest mode.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_atest_pmon_get(const uint32 unit,
                               const uint32 port,
                               const uint32 lane_bmp,
                               const uint32 mode);

/**
 * @brief Get phy rx snr.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port ID.
 * @param [out]    ptr_snr_int    - Snr calculate integer value.
 * @param [out]    ptr_snr_dec    - Snr calculate decimal value.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_rx_snr_get(const uint32 unit,
                           const uint32 port,
                           uint32 *ptr_snr_int,
                           uint32 *ptr_snr_dec);
#endif
/**
 * @brief Get port rx timestamp entry information.
 *
 * @param [in]     unit            - Chip id.
 * @param [in]     port            - Port id.
 * @param [out]    ptr_ts_entry    - Timestamp entry information.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_port_ts_rx_entry_get(const uint32 unit,
                            const uint32 port,
                            clx_port_ts_entry_t *ptr_ts_entry);

/**
 * @brief This API is used to probe a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_probe(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to get the physical link status for a specific port.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [out]    ptr_link    - Link status (Reference to CLX_PORT_LINK_XXX).
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_link_get(const uint32 unit, const uint32 port, uint32 *ptr_link);

/**
 * @brief This API is used to get the physical fault status for a specific port.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port ID.
 * @param [out]    ptr_fault    - Fault status (Reference to CLX_PORT_FAULT_XXX).
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_fault_get(const uint32 unit, const uint32 port, uint32 *ptr_fault);

/**
 * @brief Get the status per physical port.
 *
 * There is 8 bits for 8 RX priority flow control status in rx_pfc.
 * RX flow control status for priority x (x = 0~7) =
 * rx_pfc & (CLX_PORT_FC_STATUS_ON << x).
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [out]    ptr_status    - Port status speed - reference to clx_port_speed_t link -
 *                                 reference to CLX_PORT_LINK_XXX fault - reference to
 *                                 CLX_PORT_FAULT_XXX rx_fc - reference to CLX_PORT_FC_STATUS_XXX
 *                                 rx_pfc - reference to CLX_PORT_FC_STATUS_XXX.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_status_get(const uint32 unit, const uint32 port, clx_port_status_t *ptr_status);

/**
 * @brief Set all tx coefficients (CN3, CN2, CN1, C0, C1, C2, C3) for a specific lane Note 1:
 *        different switch family supports different coefficient number Note 2: when summation of
 *        coefficient is overflow, C0 got reduction Note 3: partial coefficients configuration is
 *        allowed (flags within struct config is necessary).
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port           - Physical port ID.
 * @param [in]    lane_idx       - Lane offset within th port.
 * @param [in]    location       - PHY location.
 * @param [in]    ptr_tx_coef    - The tx coefficients applied to the specific lane.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_tx_coef_set(const uint32 unit,
                        const uint32 port,
                        const uint32 lane_idx,
                        const clx_port_phy_location_t location,
                        clx_port_tx_coef_t *ptr_tx_coef);

/**
 * @brief Set all tx coefficients (CN3, CN2, CN1, C0, C1, C2, C3) for a specific lane Note 1:
 *        different switch family supports different coefficient number Note 2: flags within the
 *        struct indicates the coefficients supported in this switch family.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port ID.
 * @param [in]     lane_idx       - Lane offset within th port.
 * @param [in]     location       - PHY location.
 * @param [out]    ptr_tx_coef    - The tx coefficients applied to the specific lane.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_tx_coef_get(const uint32 unit,
                        const uint32 port,
                        const uint32 lane_idx,
                        const clx_port_phy_location_t location,
                        clx_port_tx_coef_t *ptr_tx_coef);

/**
 * @brief Get phy tx signal.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port ID.
 * @param [out]    ptr_enable    - Phy tx signal.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_tx_signal_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief Register/deregister phy tx signal callback.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    func          - Callback function.
 * @param [in]    ptr_cookie    - Cookie data of callback function.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_tx_signal_register(const uint32 unit,
                               clx_port_phy_notify_func_t func,
                               void *ptr_cookie);

/**
 * @brief Write a whole register table.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    port         - Physical port ID.
 * @param [in]    reg_id       - Register ID.
 * @param [in]    entry_id     - Entry ID.
 * @param [in]    entry_num    - Entry number.
 * @param [in]    buff         - Buffer to write.
 * @return        CLX_E_OK               - Operation successful.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameters provided.
 * @return        CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_mt_port_reg_entry_write(uint32 unit,
                            uint32 port,
                            uint32 reg_id,
                            uint32 entry_id,
                            uint32 entry_num,
                            uint32 *buff);

/**
 * @brief Read data from register field.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port ID.
 * @param [in]     reg_id       - Register ID.
 * @param [in]     entry_id     - Entry ID.
 * @param [in]     entry_num    - Entry number.
 * @param [out]    data         - Data read from register.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_port_reg_entry_read(uint32 unit,
                           uint32 port,
                           uint32 reg_id,
                           uint32 entry_id,
                           uint32 entry_num,
                           uint32 *data);

/**
 * @brief Write single field to a register(32bit or longer) in a single operation.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port ID.
 * @param [in]    reg_id      - Register ID.
 * @param [in]    field_id    - Field ID.
 * @param [in]    data        - Data to write.
 * @return        CLX_E_OK               - Operation successful.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameters provided.
 * @return        CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_mt_port_reg_field_write(uint32 unit, uint32 port, uint32 reg_id, uint32 field_id, uint32 *data);

/**
 * @brief Read single field from a register(32bit or longer) in a single operation.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [in]     reg_id      - Register ID.
 * @param [in]     field_id    - Field ID.
 * @param [out]    data        - Data read from register field.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_port_reg_field_read(uint32 unit, uint32 port, uint32 reg_id, uint32 field_id, uint32 *data);

/**
 * @brief Write multiple fields to a register(only 32bit) in a single operation.
 *
 * @param [in]    unit               - Device unit number.
 * @param [in]    port               - Physical port ID.
 * @param [in]    reg_id             - Register ID.
 * @param [in]    field_list_size    - Number of fields to write.
 * @param [in]    field_list         - Array of field IDs to write.
 * @param [in]    data_list          - Array of data values corresponding to each field.
 * @return        CLX_E_OK               - Operation successful.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameters provided.
 * @return        CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_mt_port_reg_fields_write(uint32 unit,
                             uint32 port,
                             uint32 reg_id,
                             uint32 field_list_size,
                             uint32 *field_list,
                             uint32 *data_list);

/**
 * @brief Read multiple fields from a register(only 32bit) in a single operation.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     port               - Physical port ID.
 * @param [in]     reg_id             - Register ID.
 * @param [in]     field_list_size    - Number of fields to read.
 * @param [in]     field_list         - Array of field IDs to read.
 * @param [out]    data_list          - Array of data values corresponding to each field.
 * @return         CLX_E_OK               - Operation successful.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters provided.
 * @return         CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_mt_port_reg_fields_read(uint32 unit,
                            uint32 port,
                            uint32 reg_id,
                            uint32 field_list_size,
                            uint32 *field_list,
                            uint32 *data_list);

/**
 * @brief Write multiple fields to masked inst/sub_inst register(only 32bit).
 *
 * @param [in]    unit               - Device unit number.
 * @param [in]    inst_msk           - Instance mask.
 * @param [in]    sub_inst_msk       - Sub instance mask.
 * @param [in]    reg_id             - Register ID.
 * @param [in]    entry_id           - Entry ID.
 * @param [in]    field_list_size    - Number of fields to write.
 * @param [in]    field_list         - Array of field IDs to write.
 * @param [in]    data_list          - Array of data values corresponding to each field.
 * @return        CLX_E_OK               - Operation successful.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameters provided.
 * @return        CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_mt_port_reg_fields_bcast_write(uint32 unit,
                                   uint32 inst_msk,
                                   uint32 sub_inst_msk,
                                   uint32 reg_id,
                                   uint32 entry_id,
                                   uint32 field_list_size,
                                   uint32 *field_list,
                                   uint32 *data_list);

/**
 * @brief Write single entry to a register(32bit or longer) in a single operation.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port ID.
 * @param [in]    reg_id      - Register ID.
 * @param [in]    field_id    - Field ID.
 * @param [in]    entry_id    - Entry ID.
 * @param [in]    data        - Data to write.
 * @return        CLX_E_OK               - Operation successful.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameters provided.
 * @return        CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_mt_port_reg_field_entry_write(uint32 unit,
                                  uint32 port,
                                  uint32 reg_id,
                                  uint32 field_id,
                                  uint32 entry_id,
                                  uint32 *data);

/**
 * @brief Read single entry from a register(32bit or longer) in a single operation.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [in]     reg_id      - Register ID.
 * @param [in]     field_id    - Field ID.
 * @param [in]     entry_id    - Entry ID.
 * @param [out]    data        - Data read from register field.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_port_reg_field_entry_read(uint32 unit,
                                 uint32 port,
                                 uint32 reg_id,
                                 uint32 field_id,
                                 uint32 entry_id,
                                 uint32 *data);

/**
 * @brief To initialize port resource.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
hal_mt_port_rsrc_init(const uint32 unit);

/**
 * @brief To deinitialize port resource.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Deinit fail.
 */
clx_error_no_t
hal_mt_port_rsrc_deinit(const uint32 unit);

/**
 * @brief To initialize port warm.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
hal_mt_port_warm_init(const uint32 unit);

/**
 * @brief To initialize port phy warm.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
hal_mt_port_phy_warm_init(const uint32 unit);

/**
 * @brief To deinitialize port warm.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Deinit fail.
 */
clx_error_no_t
hal_mt_port_warm_deinit(const uint32 unit);
/**
 * @brief To probe port phy.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Probe fail.
 */
clx_error_no_t
hal_mt_port_phy_probe(const uint32 unit);

/**
 * @brief Check if the port link status is expected.
 *
 * @param [in]    unit               - Device unit number.
 * @param [in]    port               - Physical port ID.
 * @param [in]    expected_status    - Expected link status (CLX_PORT_LINK_XXX).
 * @param [in]    timeout_us         - Timeout in microseconds.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_TIMEOUT          - Link did not reach expected status in time.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_link_status_check(const uint32 unit,
                              const uint32 port,
                              const uint32 expected_status,
                              uint32 timeout_us);

#endif /* #ifndef HAL_MT_PORT_H */
