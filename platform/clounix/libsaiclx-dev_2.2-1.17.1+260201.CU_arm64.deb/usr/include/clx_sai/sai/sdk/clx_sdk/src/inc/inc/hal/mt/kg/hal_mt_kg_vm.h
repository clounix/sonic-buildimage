/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_vm.h
 * PURPOSE:
 *  Define the declartion for VM module for CL8400.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_KG_VM_H
#define HAL_MT_KG_VM_H

#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_vm.h>

/**
 * @brief Set the chip's VM mode.
 *
 * Support_chip: CLX84.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    mode    - VM mode of the chip.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_SUPPORT      - Not support.
 */
clx_error_no_t
hal_mt_kg_vm_mode_set(const uint32 unit, const clx_vm_mode_t mode);

/**
 * @brief Get the chip's VM mode.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit        - Device unit number.
 * @param [out]    ptr_mode    - VM mode of the chip.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_SUPPORT      - Not support.
 */
clx_error_no_t
hal_mt_kg_vm_mode_get(const uint32 unit, clx_vm_mode_t *ptr_mode);

/**
 * @brief Create a VM port.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     ptr_vm_info    - VM information.
 * @param [out]    ptr_vm_port    - VM port.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - No such entry.
 * @return         CLX_E_NOT_SUPPORT      - Not support.
 */
clx_error_no_t
hal_mt_kg_vm_port_create(const uint32 unit,
                         const clx_vm_info_t *ptr_vm_info,
                         clx_port_t *ptr_vm_port);

/**
 * @brief Destroy a VM port.
 *
 * Support_chip: CLX84.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    vm_port    - VM port.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - No such entry.
 * @return        CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
hal_mt_kg_vm_port_destroy(const uint32 unit, clx_port_t vm_port);

/**
 * @brief Get VM port information.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     vm_port        - VM port.
 * @param [out]    ptr_vm_info    - VM information of VM port.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry.
 * @return         CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
hal_mt_kg_vm_port_get(const uint32 unit, const clx_port_t vm_port, clx_vm_info_t *ptr_vm_info);

/**
 * @brief Set property of VM port.
 *
 * Support_chip: CLX84.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Port/LAG.
 * @param [in]    ptr_port_cfg    - VM port property.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_SUPPORT      - Not support.
 */
clx_error_no_t
hal_mt_kg_vm_port_cfg_set(const uint32 unit,
                          const clx_port_t port,
                          const clx_vm_port_cfg_t *ptr_port_cfg);

/**
 * @brief Get property of VM port.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Port/LAG.
 * @param [out]    ptr_port_cfg    - VM port property.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_vm_port_cfg_get(const uint32 unit,
                          const clx_port_t port,
                          clx_vm_port_cfg_t *ptr_port_cfg);

/**
 * @brief Add downstream entry of PE.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    ptr_entry    - Downstream entry.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Table full.
 * @return        CLX_E_NOT_SUPPORT      - Not support.
 */
clx_error_no_t
hal_mt_kg_vm_pe_downstream_entry_add(const uint32 unit,
                                     const clx_vm_pe_downstream_entry_t *ptr_entry);

/**
 * @brief Del downstream entry of PE.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    ptr_entry    - Downstream entry, key is downstream_type,
 *                               vm_tag_type and vm_id.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Not found.
 * @return        CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
hal_mt_kg_vm_pe_downstream_entry_del(const uint32 unit,
                                     const clx_vm_pe_downstream_entry_t *ptr_entry);

/**
 * @brief Gel downstream entry of PE.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     ptr_entry    - Downstream entry, key is downstream_type,
 *                                vm_tag_type and vmid.
 * @param [out]    ptr_entry    - Downstream entry, value is dport/mcast_id.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Not found.
 * @return         CLX_E_NOT_SUPPORT        - Not support.
 */
clx_error_no_t
hal_mt_kg_vm_pe_downstream_entry_get(const uint32 unit, clx_vm_pe_downstream_entry_t *ptr_entry);

/**
 * @brief Add upstream entry of PE.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    ptr_entry    - Upstream entry.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_SUPPORT      - Not support.
 */
clx_error_no_t
hal_mt_kg_vm_pe_upstream_entry_add(const uint32 unit, const clx_vm_pe_upstream_entry_t *ptr_entry);

/**
 * @brief Del upstream entry of PE.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    ptr_entry    - Upstream entry, key is sport.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_SUPPORT      - Not support.
 */
clx_error_no_t
hal_mt_kg_vm_pe_upstream_entry_del(const uint32 unit, const clx_vm_pe_upstream_entry_t *ptr_entry);

/**
 * @brief Get upstream entry of PE.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     ptr_entry    - Upstream entry, key is sport.
 * @param [out]    ptr_entry    - Upstream entry, value is dport.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_NOT_SUPPORT        - Not support.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Not found entry.
 */
clx_error_no_t
hal_mt_kg_vm_pe_upstream_entry_get(const uint32 unit, clx_vm_pe_upstream_entry_t *ptr_entry);

/**
 * @brief Set VM parser.
 *
 * Support_chip: CLX84.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    type      - Property type.
 * @param [in]    param0    - First parameter.
 * @param [in]    param1    - Second parameter.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_vm_swc_cfg_set(const uint32 unit,
                         const clx_swc_cfg_t type,
                         const uint32 param0,
                         const uint32 param1);

/**
 * @brief Get VM parser.
 *
 * Support_chip: CLX84.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     type          - Property type.
 * @param [out]    ptr_param0    - First parameter.
 * @param [out]    ptr_param1    - Second parameter.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_vm_swc_cfg_get(const uint32 unit,
                         const clx_swc_cfg_t type,
                         uint32 *ptr_param0,
                         uint32 *ptr_param1);

/**
 * @brief Add mcast group hash entry to derive mcast VM ID.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    mcast_id      - Phy mcast ID, key.
 * @param [in]    port          - Phy port or LAG, key.
 * @param [in]    alt_mc_vld    - Alternate multicast vld or not, key.
 * @param [in]    mc_vm_id      - Mcast VM ID, value.
 * @return        CLX_E_OK              - Operate success.
 * @return        CLX_E_ENTRY_EXISTS    - Entry exist.
 * @return        CLX_E_OTHERS          - Other fail.
 */
clx_error_no_t
hal_mt_kg_vm_mcg_hsh_add(const uint32 unit,
                         const uint32 mcast_id,
                         const clx_port_t port,
                         const boolean alt_mc_vld,
                         const uint32 mc_vm_id);

/**
 * @brief Delete mcast group hash entry for derive mcast VM ID.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    mcast_id      - Phy mcast ID, key.
 * @param [in]    port          - Phy port or LAG, key.
 * @param [in]    alt_mc_vld    - Alternate multicast vld or not, key.
 * @return        CLX_E_OK              - Operate success.
 * @return        CLX_E_ENTRY_EXISTS    - Entry exist.
 * @return        CLX_E_OTHERS          - Other fail.
 */
clx_error_no_t
hal_mt_kg_vm_mcg_hsh_del(const uint32 unit,
                         const uint32 mcast_id,
                         const clx_port_t port,
                         const boolean alt_mc_vld);

/**
 * @brief Get mcast group hash entry derived mcast VM ID.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     mcast_id        - Phy mcast ID, key.
 * @param [in]     port            - Phy port or LAG, key.
 * @param [in]     alt_mc_vld      - Alternate multicast vld or not, key.
 * @param [out]    ptr_mc_vm_id    - Mcast VM ID, value.
 * @return         CLX_E_OK              - Operate success.
 * @return         CLX_E_ENTRY_EXISTS    - Entry exist.
 * @return         CLX_E_OTHERS          - Other fail.
 */
clx_error_no_t
hal_mt_kg_vm_mcg_hsh_get(const uint32 unit,
                         const uint32 mcast_id,
                         const clx_port_t port,
                         const boolean alt_mc_vld,
                         uint32 *ptr_mc_vm_id);

/**
 * @brief Process LAG member update.
 *
 * @param [in]    unit                - Device unit number.
 * @param [in]    lag_id              - LAG ID.
 * @param [in]    add_mbr_cnt         - New add member count.
 * @param [in]    ptr_add_mbr_list    - New add member list.
 * @param [in]    del_mbr_cnt         - Delete member count.
 * @param [in]    ptr_del_mbr_list    - Delete member list.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Other fail.
 */
clx_error_no_t
hal_mt_kg_vm_lag_mbr_update_handle(const uint32 unit,
                                   const uint32 lag_id,
                                   const uint32 add_mbr_cnt,
                                   const uint32 *ptr_add_mbr_list,
                                   const uint32 del_mbr_cnt,
                                   const uint32 *ptr_del_mbr_list);

/**
 * @brief Init VM module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK                - Operate success.
 * @return        CLX_E_ALREADY_INITED    - Unexpected init.
 * @return        CLX_E_OTHERS            - Init fail.
 */
clx_error_no_t
hal_mt_kg_vm_init(const uint32 unit);

/**
 * @brief Deinit VM module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK            - Operate success.
 * @return        CLX_E_NOT_INITED    - Unexpected deinit.
 * @return        CLX_E_OTHERS        - Init fail.
 */
clx_error_no_t
hal_mt_kg_vm_deinit(const uint32 unit);

#endif
