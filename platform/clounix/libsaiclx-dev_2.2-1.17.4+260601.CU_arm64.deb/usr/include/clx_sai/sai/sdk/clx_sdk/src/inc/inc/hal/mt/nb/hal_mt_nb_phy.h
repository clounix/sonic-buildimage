/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_phy.h
 * PURPOSE:
 *      It provide CL8600 API.
 * NOTES:
 *
 */
#ifndef HAL_MT_NB_PHY_H
#define HAL_MT_NB_PHY_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <hal/hal.h>
#include <hal/hal_phy.h>
#include <hal/hal_mdio.h>
#include <tob/tob_tbl.h>
#include <drv/drv_io.h>
#include <osal/osal.h>
#include <util/util_cfg.h>
#include <hal/mt/nb/hal_mt_nb_serdes.h>
#include <hal/mt/nb/hal_mt_nb_led.h>
#include <hal/mt/nb/hal_mt_nb_mac.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
/* For each plane(slice), max macro number = 8 */
#define HAL_MT_NB_PHY_MAX_MACRO           (33) /*contains CPI ports macro*/
#define HAL_MT_NB_PHY_MAX_LANES_PER_MACRO (8)
#define HAL_MT_NB_PHY_MAX_PPID_PER_MACRO  (4)
#define HAL_MT_NB_PHY_MAX_INACTIVED_PPID  (255)
#define HAL_MT_NB_PHY_MAX_INACTIVED_LANE  (255)
#define HAL_MT_NB_PHY_MAX_UP_NUM          (8)
#define HAL_MT_NB_PHY_CPI_ETH_MACRO       (32)
#define HAL_MT_NB_PHY_CPI_MAX_LANES_NUM   (4)

#define HAL_MT_NB_PHY_TX_ACK_TIMEOUT           (12000)
#define HAL_MT_NB_PHY_RX_ACK_TIMEOUT           (90000)
#define HAL_MT_NB_PHY_RX_LINKEVAL_FULL_TIMEOUT (6200000)

/* DATA TYPE DECLARATIONS
 */
#define HAL_MT_NB_PHY_TX_COEFFICIENT_C0_MAX  (60)
#define HAL_MT_NB_PHY_TX_COEFFICIENT_C1_MAX  (24)
#define HAL_MT_NB_PHY_TX_COEFFICIENT_CN1_MAX (24)
#define HAL_MT_NB_PHY_TX_COEFFICIENT_CN2_MAX (7)
#define HAL_MT_NB_PHY_TX_COEFFICIENT_CN3_MAX (4)
#define HAL_MT_NB_PHY_TX_COEFFICIENT_TOTAL   (63)

/**
 * @brief Set MDIO register.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port_id     - Port ID.
 * @param [in]    phy_type    - PHY type.
 * @param [in]    dev_type    - Device type.
 * @param [in]    reg_addr    - Register address.
 * @param [in]    reg         - Register value.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_phy_mdio_reg_set(const uint32 unit,
                           const uint32 port_id,
                           const hal_phy_type_t phy_type,
                           const uint32 dev_type,
                           const uint32 reg_addr,
                           const uint32 reg);

/**
 * @brief Get MDIO register.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port_id     - Port ID.
 * @param [in]     phy_type    - PHY type.
 * @param [in]     dev_type    - Device type.
 * @param [in]     reg_addr    - Register address.
 * @param [out]    ptr_reg     - Register value.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_phy_mdio_reg_get(const uint32 unit,
                           const uint32 port_id,
                           const hal_phy_type_t phy_type,
                           const uint32 dev_type,
                           const uint32 reg_addr,
                           uint32 *ptr_reg);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
#endif

/* FUNCTION PROTOTYPE */