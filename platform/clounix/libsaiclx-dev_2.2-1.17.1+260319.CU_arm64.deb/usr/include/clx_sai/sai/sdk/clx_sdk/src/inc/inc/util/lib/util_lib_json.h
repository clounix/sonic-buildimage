/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/**
 * @brief A lightweight JSON parser implementation.
 *
 */

#ifndef _UTIL_LIB_JSON_H_
#define _UTIL_LIB_JSON_H_

#include <clx/clx_types.h>

/* JSON value types */
typedef enum util_lib_json_value_type_e {
    JSON_TYPE_NULL,
    JSON_TYPE_BOOLEAN,
    JSON_TYPE_NUMBER,
    JSON_TYPE_STRING,
    JSON_TYPE_ARRAY,
    JSON_TYPE_OBJECT
} util_lib_json_value_type_t;

/* JSON value structure */
typedef struct util_lib_json_value_s {
    util_lib_json_value_type_t type;
    union {
        boolean bool_val;
        int64 int_val;
        char *str_val;
        struct {
            struct util_lib_json_value_s **items;
            uint32 length;
            uint32 capacity;
        } array;
        struct {
            char **keys;
            struct util_lib_json_value_s **values;
            uint32 length;
            uint32 capacity;
        } object;
    } u;
} util_lib_json_value_t;

/* JSON parsing context */
typedef struct util_lib_json_parse_ctx_s {
    const char *data;
    uint32 pos;
    uint32 len;
} util_lib_json_parse_ctx_t;

/* Basic parsing functions */
/**
 * @brief Parse a JSON file into a value.
 *
 * @param [in]     filename      - The JSON file to parse.
 * @return         util_lib_json_value_t* - Newly allocated JSON value or NULL on failure.
 */
util_lib_json_value_t *
util_lib_json_file_parse(const char *filename);

/**
 * @brief Parse a JSON string into a value.
 *
 * @param [in]    str    - The JSON string to parse.
 * @return        util_lib_json_value_t*    - Newly allocated JSON value or NULL on failure.
 */
util_lib_json_value_t *
util_lib_json_string_parse(const char *str);

/**
 * @brief Free a JSON value and all its children.
 *
 * @param [in]    value    - The JSON value to free.
 */
void
util_lib_json_value_free(util_lib_json_value_t *value);

/* Value access functions */
/**
 * @brief Get a value from a JSON object with the specified key.
 *
 * @param [in]    obj    - The JSON object.
 * @param [in]    key    - The key to look up.
 * @return        util_lib_json_value_t*    - The value associated with the key or NULL if not
 *                                            found.
 */
util_lib_json_value_t *
util_lib_json_object_get(util_lib_json_value_t *obj, const char *key);

/**
 * @brief Get a value from a JSON array at the specified index.
 *
 * @param [in]    arr      - The JSON array.
 * @param [in]    index    - The index to get.
 * @return        util_lib_json_value_t*    - The value at the index or NULL if invalid.
 */
util_lib_json_value_t *
util_lib_json_array_get(util_lib_json_value_t *arr, uint32 index);

/**
 * @brief Get the length of a JSON array.
 *
 * @param [in]    arr    - The JSON array.
 * @return        uint32    - The length of the array or 0 if not an array.
 */
uint32
util_lib_json_array_length_get(util_lib_json_value_t *arr);

/**
 * @brief Get the type of a JSON value.
 *
 * @param [in]    value    - The JSON value.
 * @return        util_lib_json_value_type_t    - The type of the value.
 */
util_lib_json_value_type_t
util_lib_json_type_get(util_lib_json_value_t *value);

/**
 * @brief Get a value from a JSON object and return success status.
 *
 * @param [in]     obj      - The JSON object.
 * @param [in]     key      - The key to look up.
 * @param [out]    value    - Pointer to store the retrieved value.
 * @return         TRUE     - If the key was found.
 * @return         FALSE    - Otherwise.
 */
boolean
util_lib_json_object_val_get(util_lib_json_value_t *obj,
                             const char *key,
                             util_lib_json_value_t **value);

/* Value conversion functions */
/**
 * @brief Get an integer value from a JSON value.
 *
 * @param [in]     value    - The JSON value.
 * @param [out]    out      - Pointer to store the integer value.
 * @return         TRUE     - If successful.
 * @return         FALSE    - Otherwise.
 */
boolean
util_lib_json_int_val_get(util_lib_json_value_t *value, int64 *out);

/**
 * @brief Get a string value from a JSON value.
 *
 * @param [in]    value    - The JSON value.
 * @return        const char*    - The string value or NULL if not a string.
 */
const char *
util_lib_json_string_val_get(util_lib_json_value_t *value);

/**
 * @brief Get a boolean value from a JSON value.
 *
 * @param [in]     value    - The JSON value.
 * @param [out]    out      - Pointer to store the boolean value.
 * @return         TRUE     - If successful.
 * @return         FALSE    - Otherwise.
 */
boolean
util_lib_json_bool_val_get(util_lib_json_value_t *value, boolean *out);

/* Value modification functions */
/**
 * @brief Set a value in a JSON array.
 *
 * @param [in]    arr      - The JSON array.
 * @param [in]    index    - The index to set.
 * @param [in]    value    - The value to set.
 * @return        TRUE     - If successful.
 * @return        FALSE    - Otherwise.
 */
boolean
util_lib_json_array_set(util_lib_json_value_t *arr, uint32 index, util_lib_json_value_t *value);

/**
 * @brief Set a value in a JSON object.
 *
 * @param [in]    obj      - The JSON object.
 * @param [in]    key      - The key to set.
 * @param [in]    value    - The value to set.
 * @return        TRUE     - If successful.
 * @return        FALSE    - Otherwise.
 */
boolean
util_lib_json_object_set(util_lib_json_value_t *obj, const char *key, util_lib_json_value_t *value);

/**
 * @brief Add a value to a JSON array.
 *
 * @param [in]    arr      - The JSON array.
 * @param [in]    value    - The value to add.
 * @return        TRUE     - If successful.
 * @return        FALSE    - Otherwise.
 */
boolean
util_lib_json_array_add(util_lib_json_value_t *arr, util_lib_json_value_t *value);

/* String utility functions */
/**
 * @brief Duplicate a string using osal memory functions.
 *
 * @param [in]    str    - The string to duplicate.
 * @return        char*    - A newly allocated copy of the string, or NULL on failure.
 */
char *
util_lib_json_str_dup(const char *str);

/* Copy functions */
/**
 * @brief Copy a JSON value.
 *
 * @param [in]    value    - The JSON value to copy.
 * @return        util_lib_json_value_t*    - A newly allocated copy of the JSON value or NULL on
 *                                            failure.
 */
util_lib_json_value_t *
util_lib_json_value_copy(util_lib_json_value_t *value);

/* Serialization functions */
/**
 * @brief Convert a JSON value to a string.
 *
 * @param [in]    value     - The JSON value to convert.
 * @param [in]    pretty    - Whether to format the output.
 * @return        char*    - A newly allocated string representation or NULL on failure.
 */
char *
util_lib_json_string_convert(util_lib_json_value_t *value, boolean pretty);

/**
 * @brief Write a JSON value to a file.
 *
 * @param [in]    value       - The JSON value to write.
 * @param [in]    filename    - The file to write to.
 * @param [in]    pretty      - Whether to format the output.
 * @return        TRUE     - If successful.
 * @return        FALSE    - Otherwise.
 */
boolean
util_lib_json_to_file_write(util_lib_json_value_t *value, const char *filename, boolean pretty);

/* Helper functions */
/**
 * @brief Create a new JSON value.
 *
 * @param [in]    type    - The type of JSON value to create.
 * @return        util_lib_json_value_t*    - Newly allocated JSON value or NULL on failure.
 */
util_lib_json_value_t *
util_lib_json_value_new(util_lib_json_value_type_t type);

#endif /* _UTIL_LIB_JSON_H_ */
