/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME: tob_mt.h
 * PURPOSE:
 *     Table operation bus(TOB) driver
 * NOTES:
 */

#ifndef TOB_MT_H
#define TOB_MT_H

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */
#define TOB_MT_TCAM_INDEX_OFFSET 0
#define TOB_MT_TCAM_INDEX_LEN    20
#define TOB_MT_TCAM_INST_OFFSET  20
#define TOB_MT_TCAM_INST_LEN     4

#define TOB_MT_NB_FPU_INDEX_LEN 20
#define TOB_MT_KG_FPU_INDEX_LEN 20

#define TOB_MT_HASH_INDEX_OFFSET    0
#define TOB_MT_HASH_INDEX_LEN       15
#define TOB_MT_HASH_TILE_OFFSET     15
#define TOB_MT_NB_HASH_TILE_LEN     3
#define TOB_MT_KG_HASH_TILE_LEN     1
#define TOB_MT_NB_HASH_STAGE_OFFSET 18
#define TOB_MT_KG_HASH_STAGE_OFFSET 16
#define TOB_MT_NB_HASH_STAGE_LEN    2
#define TOB_MT_KG_HASH_STAGE_LEN    4
#define TOB_MT_HASH_INST_OFFSET     20
#define TOB_MT_HASH_INST_LEN        4

#define TOB_MT_BC_REP_SLICE_NUM 2

#define TOB_MT_DMA_FALSE 0
#define TOB_MT_DMA_TRUE  1

#define TOB_MT_NB_FPU_SRAM_NUM_PER_SLICE (32 * 1024)

#define TOB_MT_NB_FPU_HASH_CONFLICT_INDEX_OFFSET 24
#define TOB_MT_NB_FPU_HASH_CONFLICT_INDEX_LEN    15

#define TOB_MT_KG_FPU_HASH_CONFLICT_INDEX_OFFSET 24
#define TOB_MT_KG_FPU_HASH_CONFLICT_INDEX_LEN    15

#define TOB_MT_KG_FPU_LPM_CONFLICT_INDEX_OFFSET 20
#define TOB_MT_KG_FPU_LPM_CONFLICT_INDEX_LEN    11

#define TOB_MT_TABLE_COPY_DMA_NUM 128

#define TOB_MT_KG_DIE_OFFSET 0x08000000

#define TOB_MT_NB_FPU_HASH_TILE_NUM_PER_STAGE (8)
#define TOB_MT_NB_FPU_HASH_STAGE_NUM          (3)
#define TOB_MT_NB_FPU_HASH_TILE_NUM           (24)
#define TOB_MT_NB_FPU_MAX_TCAM_NUM            (32)
#define TOB_MT_NB_ENTRIES_PER_TCAM            (1024)

#define TOB_MT_KG_FPU_HASH_TILE_NUM_PER_STAGE (2)
#define TOB_MT_KG_FPU_HASH_STAGE_NUM          (10)
#define TOB_MT_KG_FPU_HASH_TILE_NUM           (20)
#define TOB_MT_KG_FPU_MAX_TCAM_NUM            (24)
#define TOB_MT_KG_ENTRIES_PER_TCAM            (1024)

#define TOB_MT_KG_FPU_LPM_TILE_NUM (32)

#define TOB_MT_NB_CIA_ENTRY_NUM    (16 * 1024)
#define TOB_MT_KG_CIA_ENTRY_NUM    (32 * 1024)
#define TOB_MT_KG_PERCIA_ENTRY_NUM (2 * 1024)

/* 12.8T: FPU0 and FPU2 entry is same FPU1 and FPU3 is same */
#define TOB_MT_NB_ECC_FPU_NUM (2)

#define TOB_MT_MASTER_INST_IDX_BCAST_0     0x7EEEEEEE
#define TOB_MT_MASTER_INST_IDX_BCAST_1     0x6EEEEEEE
#define TOB_MT_SLAVE_INST_IDX_BCAST_0      0x5EEEEEEE
#define TOB_MT_SLAVE_INST_IDX_BCAST_1      0x4EEEEEEE
#define TOB_MT_MASTER_SUB_INST_IDX_BCAST_0 0x3EEEEEEE
#define TOB_MT_MASTER_SUB_INST_IDX_BCAST_1 0x2EEEEEEE

#define TOB_MT_DOUBLE_INST_IDX_BEGIN_BC_1 4

#define TOB_MT_NB_INST_NUM 8

#define TOB_MT_HASH_GET_INSTID(entry_index, inst_id) \
    (inst_id = ((entry_index >> TOB_MT_HASH_INST_OFFSET) & ((1 << TOB_MT_HASH_INST_LEN) - 1)))

#define TOB_MT_NB_HASH_GET_STAGEID(entry_index, stage_id) \
    (stage_id =                                           \
         ((entry_index >> TOB_MT_NB_HASH_STAGE_OFFSET) & ((1 << TOB_MT_NB_HASH_STAGE_LEN) - 1)))

#define TOB_MT_KG_HASH_GET_STAGEID(entry_index, stage_id) \
    (stage_id =                                           \
         ((entry_index >> TOB_MT_KG_HASH_STAGE_OFFSET) & ((1 << TOB_MT_KG_HASH_STAGE_LEN) - 1)))

#define TOB_MT_NB_HASH_GET_TILEID(entry_index, tile_id) \
    (tile_id = ((entry_index >> TOB_MT_HASH_TILE_OFFSET) & ((1 << TOB_MT_NB_HASH_TILE_LEN) - 1)))

#define TOB_MT_KG_HASH_GET_TILEID(entry_index, tile_id) \
    (tile_id = ((entry_index >> TOB_MT_HASH_TILE_OFFSET) & ((1 << TOB_MT_KG_HASH_TILE_LEN) - 1)))

#define TOB_MT_HASH_GET_INDEX(entry_index, index) \
    (index = ((entry_index >> TOB_MT_HASH_INDEX_OFFSET) & ((1 << TOB_MT_HASH_INDEX_LEN) - 1)))

#define TOB_MT_TCAM_GET_INSTID(entry_index, inst_id) \
    (inst_id = ((entry_index >> TOB_MT_TCAM_INST_OFFSET) & ((1 << TOB_MT_TCAM_INST_LEN) - 1)))

#define TOB_MT_TCAM_GET_INDEX(entry_index, index) \
    (index = ((entry_index >> TOB_MT_TCAM_INDEX_OFFSET) & ((1 << TOB_MT_TCAM_INDEX_LEN) - 1)))

#define TOB_MT_NB_FPU_GET_IDX(entry_index, index) \
    (index = (entry_index & ((1 << TOB_MT_NB_FPU_INDEX_LEN) - 1)))

#define TOB_MT_KG_FPU_GET_IDX(entry_index, index) \
    (index = (entry_index & ((1 << TOB_MT_KG_FPU_INDEX_LEN) - 1)))

#define TOB_MT_MULT_TBL_ENTRY_MAX(unit, table_id)         \
    (TOB_TBL_INFO((unit), (table_id))->entry_max_number * \
     TOB_TBL_INFO((unit), (table_id))->subinst_count)

#define TOB_MT_MULT_TBL_SUB_INST(unit, table_id, entry_id) \
    ((entry_id) / TOB_TBL_INFO((unit), (table_id))->entry_max_number)

#define TOB_MT_MULT_TBL_ENTRY_ID(unit, table_id, entry_id) \
    ((entry_id) % TOB_TBL_INFO((unit), (table_id))->entry_max_number)

/* lock is added to each cache table, and when a specific table is distinguished, the lock is
 applied. This prevents L2 from getting locked when it writes to the cache table while L3 is being
 processed
 */
#define TOB_MT_NB_ECC_CACHE_LOCK(_unit_, _inst_, _table_id_, _bank_bmp_)                           \
    do {                                                                                           \
        if (DRV_DEV_IS_NB_FAMILY(unit)) {                                                          \
            uint32 _inst_idx_ = 0;                                                                 \
            if (TOB_TABLE(_unit_, _table_id_)->duplicate_type == TOB_HW_DUP_TYPE_FPU) {            \
                if (DRV_DEV_NB_RESOURCE_DOUBLE_FAMILY(_unit_)) {                                   \
                    if (_inst_ == TOB_ODD_INST_IDX_BCAST || _inst_ == 1 || _inst_ == 3) {          \
                        _inst_idx_ = 1;                                                            \
                    }                                                                              \
                }                                                                                  \
                for (int _tile_idx_ = 0; _tile_idx_ < TOB_MT_NB_FPU_HASH_TILE_NUM; _tile_idx_++) { \
                    if ((_bank_bmp_) & (1 << _tile_idx_)) {                                        \
                        osal_semaphore_take(                                                       \
                            &_tob_mt_nb_ecc_sema_id[(_unit_)][_inst_idx_][_tile_idx_],             \
                            CLX_SEMAPHORE_WAIT_FOREVER);                                           \
                    }                                                                              \
                }                                                                                  \
            }                                                                                      \
        }                                                                                          \
    } while (0);

#define TOB_MT_NB_ECC_CACHE_UNLOCK(_unit_, _inst_, _table_id_, _bank_bmp_)                         \
    do {                                                                                           \
        if (DRV_DEV_IS_NB_FAMILY(unit)) {                                                          \
            uint32 _inst_idx_ = 0;                                                                 \
            if (TOB_TABLE(_unit_, _table_id_)->duplicate_type == TOB_HW_DUP_TYPE_FPU) {            \
                if (DRV_DEV_NB_RESOURCE_DOUBLE_FAMILY(_unit_)) {                                   \
                    if (_inst_ == TOB_ODD_INST_IDX_BCAST || _inst_ == 1 || _inst_ == 3) {          \
                        _inst_idx_ = 1;                                                            \
                    }                                                                              \
                }                                                                                  \
                for (int _tile_idx_ = 0; _tile_idx_ < TOB_MT_NB_FPU_HASH_TILE_NUM; _tile_idx_++) { \
                    if ((_bank_bmp_) & (1 << _tile_idx_)) {                                        \
                        osal_semaphore_give(                                                       \
                            &_tob_mt_nb_ecc_sema_id[(_unit_)][_inst_idx_][_tile_idx_]);            \
                    }                                                                              \
                }                                                                                  \
            }                                                                                      \
        }                                                                                          \
    } while (0);

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum tob_mt_proc_type_e {
    TOB_MT_PROC_CMST = 0,
    TOB_MT_PROC_PDMA,
    TOB_MT_PROC_ECPU,
    TOB_MT_PROC_LAST
} tob_mt_proc_type_t;

typedef enum tob_mt_bcast_e {
    TOB_MT_BCAST_NONE = 0,
    TOB_MT_BCAST_INST_ODD = 1,
    TOB_MT_BCAST_INST_EVEN = 2,
    TOB_MT_BCAST_SUBINST = 3,
    TOB_MT_BCAST_INST_MASTER_0 = 4,
    TOB_MT_BCAST_INST_MASTER_1 = 5,
    TOB_MT_BCAST_INST_SLAVE_0 = 6,
    TOB_MT_BCAST_INST_SLAVE_1 = 7,
    TOB_MT_BCAST_SUB_INST_MASTER_0 = 8,
    TOB_MT_BCAST_SUB_INST_MASTER_1 = 9,
    TOB_MT_BCAST_ALL = 10,
    TOB_MT_BCAST_DMA_INST_BCAST_KG = 11,
    TOB_MT_BCAST_LAST
} tob_mt_bcast_t;

typedef enum tob_mt_cmd_mode_e {
    TOB_MT_CMD_MEM_WRITE = 0,
    TOB_MT_CMD_MEM_DMA,
    TOB_MT_CMD_LASE
} tob_mt_cmd_mode_t;

typedef enum tob_mt_tcam_move_reg_type_e {
    TOB_MT_TCAM_MOVE_REG_TYPE_CIAT_MOVE = 0,
    TOB_MT_TCAM_MOVE_REG_TYPE_CIAT_STATUS,
    TOB_MT_TCAM_MOVE_REG_TYPE_FPU_SLC0_MOVE,
    TOB_MT_TCAM_MOVE_REG_TYPE_FPU_SLC0_STATUS,
    TOB_MT_TCAM_MOVE_REG_TYPE_FPU_SLC1_MOVE,
    TOB_MT_TCAM_MOVE_REG_TYPE_FPU_SLC1_STATUS,
    TOB_MT_TCAM_MOVE_REG_TYPE_PRECIA_MOVE,
    TOB_MT_TCAM_MOVE_REG_TYPE_PRECIA_STATUS,
    TOB_MT_TCAM_MOVE_REG_TYPE_LASE
} tob_mt_tcam_move_reg_type_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
clx_error_no_t
tob_mt_entry_write(const tob_chip_info_t chip_info, const tob_entry_info_t *ptr_entry_info);

clx_error_no_t
tob_mt_entry_read(const tob_chip_info_t chip_info, tob_entry_info_t *ptr_entry_info);

clx_error_no_t
tob_mt_fields_write(const tob_chip_info_t chip_info,
                    const tob_entry_fields_info_t *ptr_fields_info);

clx_error_no_t
tob_mt_fields_read(const tob_chip_info_t chip_info, tob_entry_fields_info_t *ptr_fields_info);

void
tob_mt_dma_entry_size_get(const uint32 unit, const uint32 table_id, uint32 *ptr_size);

clx_error_no_t
tob_mt_dma_entry_write(const tob_chip_info_t chip_info, const tob_entry_info_t *ptr_entry_info);

clx_error_no_t
tob_mt_dma_entry_read(const tob_chip_info_t chip_info, tob_entry_info_t *ptr_entry_info);

clx_error_no_t
tob_mt_table_copy(const tob_chip_info_t chip_info, const tob_tbl_copy_info_t *ptr_copy_info);

clx_error_no_t
tob_mt_table_reset(const tob_chip_info_t chip_info, const tob_tbl_reset_info_t *ptr_reset_info);

clx_error_no_t
tob_mt_tcam_flush(const tob_chip_info_t chip_info, const uint32 table_id, const uint32 entry_idx);

clx_error_no_t
tob_mt_init(const uint32 unit);

clx_error_no_t
tob_mt_deinit(const uint32 unit);

clx_error_no_t
tob_mt_dma_read_without_lock(const uint32 unit,
                             const uint32 inst_idx,
                             const uint32 subinst_idx,
                             const uint32 bank_bmp,
                             const uint32 table_id,
                             const uint32 entry_idx,
                             const uint32 entry_num,
                             uint32 *ptr_entry);

clx_error_no_t
tob_mt_entry_read_without_lock(const uint32 unit,
                               const uint32 inst_idx,
                               const uint32 subinst_idx,
                               const uint32 table_id,
                               const uint32 flags,
                               const uint32 entry_idx,
                               uint32 *ptr_entry);

clx_error_no_t
tob_mt_dma_write_without_lock(const uint32 unit,
                              const uint32 inst_idx,
                              const uint32 subinst_idx,
                              const uint32 bank_bmp,
                              const uint32 table_id,
                              const uint32 entry_idx,
                              const uint32 entry_num,
                              uint32 *ptr_entry);

clx_error_no_t
tob_mt_entry_write_without_lock(const uint32 unit,
                                const uint32 inst_idx,
                                const uint32 subinst_idx,
                                const uint32 table_id,
                                const uint32 flags,
                                const uint32 entry_idx,
                                const uint32 *ptr_entry);

void
tob_mt_inst_map(const uint32 unit,
                const uint32 inst_idx,
                const uint32 sub_inst_idx,
                const uint32 table_id,
                uint32 *ptr_map_inst_idx,
                uint32 *ptr_map_sub_inst_idx);

clx_error_no_t
tob_mt_entry_copy(const uint32 unit,
                  const uint32 inst_idx,
                  const uint32 subinst_idx,
                  const uint32 table_id,
                  const uint32 flags,
                  const uint32 src_entry_idx,
                  const uint32 dst_entry_idx,
                  const uint32 entry_num);

clx_error_no_t
tob_mt_ecc_cache_add(const tob_chip_info_t chip_info,
                     const uint32 tbl_id,
                     const uint32 entry_idx,
                     uint32 *ptr_entry);

clx_error_no_t
tob_mt_ecc_cache_del(const tob_chip_info_t chip_info,
                     const uint32 tbl_id,
                     const uint32 entry_idx,
                     uint32 *ptr_entry);
/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */
extern clx_semaphore_id_t _tob_mt_nb_ecc_sema_id[TOB_MAXIMUM_CHIPS_PER_SYSTEM]
                                                [TOB_MT_NB_ECC_FPU_NUM][TOB_MT_NB_FPU_HASH_TILE_NUM];

#endif /* End of TOB_H */
