/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  clx_stat.h
 * PURPOSE:
 *      Define the declartion for Statistics module in CLX SDK.
 * NOTES:
 *
 */

#ifndef CLX_STAT_H
#define CLX_STAT_H

#include <clx_types.h>
#include <clx_error.h>
#include <clx_init.h>
#include <clx_l3.h>
#include <clx_tm.h>

#define CLX_STAT_INVALID_CNT_ID (0xFFFFFFFF)

typedef enum
{
                                                       /* RFC2863 */
    CLX_STAT_PORT_CNT_TYPE_IF_IN_OCTETS = 0,           /* ifInOctets */
    CLX_STAT_PORT_CNT_TYPE_IF_IN_UCAST_PKTS,           /* ifInUcastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_IN_NUCAST_PKTS,          /* ifInNUcastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_IN_DISCARDS,             /* ifInDiscards */
    CLX_STAT_PORT_CNT_TYPE_IF_IN_ERRORS,               /* ifInErrors */
    CLX_STAT_PORT_CNT_TYPE_IF_IN_UNKNOWN_PROTOS,       /* ifInUnknownProtos */
    CLX_STAT_PORT_CNT_TYPE_IF_OUT_OCTETS,              /* ifOutOctets */
    CLX_STAT_PORT_CNT_TYPE_IF_OUT_UCAST_PKTS,          /* ifOutUcastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_OUT_NUCAST_PKTS,         /* ifOutNUcastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_OUT_DISCARDS,            /* ifOutDiscards */
    CLX_STAT_PORT_CNT_TYPE_IF_OUT_ERRORS,              /* ifOutErrors */
    CLX_STAT_PORT_CNT_TYPE_IF_IN_MULTICAST_PKTS,       /* ifInMulticastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_IN_BROADCAST_PKTS,       /* ifInBroadcastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_OUT_MULTICAST_PKTS,      /* ifOutMulticastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_OUT_BROADCAST_PKTS,      /* ifOutBroadcastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_HC_IN_OCTETS,            /* ifHCInOctets */
    CLX_STAT_PORT_CNT_TYPE_IF_HC_IN_UCAST_PKTS,        /* ifHCInUcastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_HC_IN_MULTICAST_PKTS,    /* ifHCInMulticastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_HC_IN_BROADCAST_PKTS,    /* ifHCInBroadcastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_HC_OUT_OCTETS,           /* ifHCOutOctets */
    CLX_STAT_PORT_CNT_TYPE_IF_HC_OUT_UCAST_PKTS,       /* ifHCOutUcastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_HC_OUT_MULTICAST_PKTS,   /* ifHCOutMulticastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_HC_OUT_BROADCAST_PKTS,   /* ifHCOutBroadcastPkts */
                                                       /* end */

                                                                  /* RFC2819 */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_DROP_EVENTS,               /* etherStatsDropEvents */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_OCTETS,                    /* etherStatsOctets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS,                      /* etherStatsPkts */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_BROADCAST_PKTS,            /* etherStatsBroadcastPkts */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_MULTICAST_PKTS,            /* etherStatsMulticastPkts */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_CRC_ALIGN_ERRORS,          /* etherStatsCRCAlignErrors */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_UNDERSIZE_PKTS,            /* etherStatsUndersizePkts */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_OVERSIZE_PKTS,             /* etherStatsOversizePkts */ 
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_FRAGMENTS,                 /* etherStatsFragments */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_JABBERS,                   /* etherStatsJabbers */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_COLLISIONS,                /* etherStatsCollisions */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_64_OCTETS,            /* etherStatsPkts64Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_65_TO_127_OCTETS,     /* etherStatsPkts65to127Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_128_TO_255_OCTETS,    /* etherStatsPkts128to255Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_256_TO_511_OCTETS,    /* etherStatsPkts256to511Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_512_TO_1023_OCTETS,   /* etherStatsPkts512to1023Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_1024_TO_1518_OCTETS,  /* etherStatsPkts1024to1518Octets */
                                                                  /* end */

                                                                        /* RFC3635 */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_ALIGNMENT_ERRORS,                 /* dot3StatsAlignmentErrors */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_FCS_ERRORS,                       /* dot3StatsFCSErrors */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_SINGLE_COLLISION_FRAMES,          /* dot3StatsSingleCollisionFrames */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_MULTIPLE_COLLISION_FRAMES,        /* dot3StatsMultipleCollisionFrames */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_SQE_TEST_ERRORS,                  /* dot3StatsSQETestErrors */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_DEFERRED_TRANSMISSIONS,           /* dot3StatsDeferredTransmissions */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_LATE_COLLISIONS,                  /* dot3StatsLateCollisions */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_EXCESSIVE_COLLISIONS,             /* dot3StatsExcessiveCollisions */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_INTERNAL_MAC_TRANSMIT_ERRORS,     /* dot3StatsInternalMacTransmitErrors */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_CARRIER_SENSE_ERRORS,             /* dot3StatsCarrierSenseErrors */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_FRAME_TOO_LONGS,                  /* dot3StatsFrameTooLongs */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_INTERNAL_MAC_RECEIVE_ERRORS,      /* dot3StatsInternalMacReceiveErrors */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_SYMBOL_ERRORS,                    /* dot3StatsSymbolErrors */

    CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_ALIGNMENT_ERRORS,              /* dot3HCStatsAlignmentErrors */
    CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_FCS_ERRORS,                    /* dot3HCStatsFCSErrors */
    CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_INTERNAL_MAC_TRANSMIT_ERRORS,  /* dot3HCStatsInternalMacTransmitErrors */
    CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_FRAME_TOO_LONGS,               /* dot3HCStatsFrameTooLongs */
    CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_INTERNAL_MAC_RECEIVE_ERRORS,   /* dot3HCStatsInternalMacReceiveErrors */
    CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_SYMBOL_ERRORS,                 /* dot3HCStatsSymbolErrors */

    CLX_STAT_PORT_CNT_TYPE_DOT3_CONTROL_IN_UNKNOWN_OPCODES,             /* dot3ControlInUnknownOpcodes */
    CLX_STAT_PORT_CNT_TYPE_DOT3_HC_CONTROL_IN_UNKNOWN_OPCODES,          /* dot3HCControlInUnknownOpcodes */

    CLX_STAT_PORT_CNT_TYPE_DOT3_IN_PAUSE_FRAMES,                        /* dot3InPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_DOT3_OUT_PAUSE_FRAMES,                       /* dot3OutPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_DOT3_HC_IN_PAUSE_FRAMES,                     /* dot3HCInPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_DOT3_HC_OUT_PAUSE_FRAMES,                    /* dot3HCOutPauseFrames */
                                                                        /* end */

                                                                                         /* RFC3273 */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_DROP_EVENTS,                                /* mediaIndependentDropEvents */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_DROPPED_FRAMES,                             /* mediaIndependentDroppedFrames */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_PKTS,                                    /* mediaIndependentInPkts */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_OVERFLOW_PKTS,                           /* mediaIndependentInOverflowPkts */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_HIGH_CAPACITY_PKTS,                      /* mediaIndependentInHighCapacityPkts */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_PKTS,                                   /* mediaIndependentOutPkts */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_OVERFLOW_PKTS,                          /* mediaIndependentOutOverflowPkts */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_HIGH_CAPACITY_PKTS,                     /* mediaIndependentOutHighCapacityPkts */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_OCTETS,                                  /* mediaIndependentInOctets */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_OVERFLOW_OCTETS,                         /* mediaIndependentInOverflowOctets */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_HIGH_CAPACITY_OCTETS,                    /* mediaIndependentInHighCapacityOctets */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_OCTETS,                                 /* mediaIndependentOutOctets */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_OVERFLOW_OCTETS,                        /* mediaIndependentOutOverflowOctets */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_HIGH_CAPACITY_OCTETS,                   /* mediaIndependentOutHighCapacityOctets */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_NUCAST_PKTS,                             /* mediaIndependentInNUCastPkts */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_NUCAST_OVERFLOW_PKTS,                    /* mediaIndependentInNUCastOverflowPkts */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_NUCAST_HIGH_CAPACITY_PKTS,               /* mediaIndependentInNUCastHighCapacityPkts */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_NUCAST_PKTS,                            /* mediaIndependentOutNUCastPkts */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_NUCAST_OVERFLOW_PKTS,                   /* mediaIndependentOutNUCastOverflowPkts */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_NUCAST_HIGH_CAPACITY_PKTS,              /* mediaIndependentOutNUCastHighCapacityPkts */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_ERRORS,                                  /* mediaIndependentInErrors */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_ERRORS,                                 /* mediaIndependentOutErrors */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_DUPLEX_CHANGES,                             /* mediaIndependentDuplexChanges */

    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS,                      /* etherStatsHighCapacityOverflowPkts */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS,                               /* etherStatsHighCapacityPkts */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_OCTETS,                    /* etherStatsHighCapacityOverflowOctets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OCTETS,                             /* etherStatsHighCapacityOctets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_64_OCTETS,            /* etherStatsHighCapacityOverflowPkts64Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_64_OCTETS,                     /* etherStatsHighCapacityPkts64Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_65_TO_127_OCTETS,     /* etherStatsHighCapacityOverflowPkts65to127Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_65_TO_127_OCTETS,              /* etherStatsHighCapacityPkts65to127Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_128_TO_255_OCTETS,    /* etherStatsHighCapacityOverflowPkts128to255Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_128_TO_255_OCTETS,             /* etherStatsHighCapacityPkts128to255Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_256_TO_511_OCTETS,    /* etherStatsHighCapacityOverflowPkts256to511Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_256_TO_511_OCTETS,             /* etherStatsHighCapacityPkts256to511Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_512_TO_1023_OCTETS,   /* etherStatsHighCapacityOverflowPkts512to1023Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_512_TO_1023_OCTETS,            /* etherStatsHighCapacityPkts512to1023Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_1024_TO_1518_OCTETS,  /* etherStatsHighCapacityOverflowPkts1024to1518Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_1024_TO_1518_OCTETS,           /* etherStatsHighCapacityPkts1024to1518Octets */
                                                                                         /* end */

                                                                    /* RFC4836 */
    CLX_STAT_PORT_CNT_TYPE_RP_MAU_MEDIA_AVAILABLE_STATE_EXITS,      /* rpMauMediaAvailableStateExits */
    CLX_STAT_PORT_CNT_TYPE_RP_MAU_FALSE_CARRIERS,                   /* rpMauFalseCarriers */

    CLX_STAT_PORT_CNT_TYPE_IF_MAU_MEDIA_AVAILABLE_STATE_EXITS,      /* ifMauMediaAvailableStateExits */
    CLX_STAT_PORT_CNT_TYPE_IF_MAU_FALSE_CARRIERS,                   /* ifMauFalseCarriers */
    CLX_STAT_PORT_CNT_TYPE_IF_MAU_HC_FALSE_CARRIERS,                /* ifMauHCFalseCarriers */
                                                                    /* end */

                                                                    /* IEEE P802.1Q(TM) Priority-based Flow Control MIB */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_REQUESTS,                  /* ieee8021PfcRequests */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_INDICATIONS,               /* ieee8021PfcIndications */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E0_IN_PAUSE_FRAMES,     /* ieee8021PfcHcE0InPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E0_OUT_PAUSE_FRAMES,    /* ieee8021PfcHcE0OutPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E1_IN_PAUSE_FRAMES,     /* ieee8021PfcHcE1InPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E1_OUT_PAUSE_FRAMES,    /* ieee8021PfcHcE1OutPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E2_IN_PAUSE_FRAMES,     /* ieee8021PfcHcE2InPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E2_OUT_PAUSE_FRAMES,    /* ieee8021PfcHcE2OutPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E3_IN_PAUSE_FRAMES,     /* ieee8021PfcHcE3InPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E3_OUT_PAUSE_FRAMES,    /* ieee8021PfcHcE3OutPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E4_IN_PAUSE_FRAMES,     /* ieee8021PfcHcE4InPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E4_OUT_PAUSE_FRAMES,    /* ieee8021PfcHcE4OutPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E5_IN_PAUSE_FRAMES,     /* ieee8021PfcHcE5InPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E5_OUT_PAUSE_FRAMES,    /* ieee8021PfcHcE5OutPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E6_IN_PAUSE_FRAMES,     /* ieee8021PfcHcE6InPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E6_OUT_PAUSE_FRAMES,    /* ieee8021PfcHcE6OutPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E7_IN_PAUSE_FRAMES,     /* ieee8021PfcHcE7InPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E7_OUT_PAUSE_FRAMES,    /* ieee8021PfcHcE7OutPauseFrames */
                                                                    /* end */

    CLX_STAT_PORT_CNT_TYPE_RX_FRAMES_RECEIVED_OK,                   /* The total count of CLX_STAT_PORT_CNT_TYPE_IF_IN_UCAST_PKTS, 
                                                                     *                    CLX_STAT_PORT_CNT_TYPE_IF_IN_MULTICAST_PKTS,
                                                                     *                    CLX_STAT_PORT_CNT_TYPE_IF_IN_BROADCAST_PKTS, 
                                                                     */
    CLX_STAT_PORT_CNT_TYPE_RX_PAUSE_MAC_CTRL_FRAMES_RECEIVED,       /* The total count of CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_INDICATIONS,
                                                                     *                    CLX_STAT_PORT_CNT_TYPE_DOT3_IN_PAUSE_FRAMES
                                                                     */
    CLX_STAT_PORT_CNT_TYPE_RX_MAC_CONTROL_FRAMES_RECEIVED,          /* The same as CLX_STAT_PORT_CNT_TYPE_IF_IN_UNKNOWN_PROTOS */
    CLX_STAT_PORT_CNT_TYPE_RX_IN_RANGE_LENGTH_ERROES,               /* Rx length error */
    CLX_STAT_PORT_CNT_TYPE_RX_PKTS_1519_TO_2560_OCTETS,             /* Count if pkt length is in the range between 1519 and 2560. Dawn only */
    CLX_STAT_PORT_CNT_TYPE_RX_PKTS_2561_TO_MAX_OCTETS,              /* Count if pkt length is larger then 2561. Dawn only */
    CLX_STAT_PORT_CNT_TYPE_RX_PKTS_1519_TO_2047_OCTETS,             /* Count if pkt length is in the range between 1519 and 2047. */
    CLX_STAT_PORT_CNT_TYPE_RX_PKTS_2048_TO_4095_OCTETS,             /* Count if pkt length is in the range between 2048 and 4095. */
    CLX_STAT_PORT_CNT_TYPE_RX_PKTS_4096_TO_9216_OCTETS,             /* Count if pkt length is in the range between 4096 and 9216. */
    CLX_STAT_PORT_CNT_TYPE_RX_PKTS_9217_TO_16383_OCTETS,            /* Count if pkt length is in the range between 9217 and 16383. */

    CLX_STAT_PORT_CNT_TYPE_TX_FRAMES_TRANSMITTED_OK,                /* The total count of CLX_STAT_PORT_CNT_TYPE_IF_OUT_UCAST_PKTS,
                                                                    *                     CLX_STAT_PORT_CNT_TYPE_IF_OUT_MULTICAST_PKTS,
                                                                    *                     CLX_STAT_PORT_CNT_TYPE_IF_OUT_BROADCAST_PKTS
                                                                    *
                                                                    */
    CLX_STAT_PORT_CNT_TYPE_TX_PAUSE_MAC_CTRL_FRAMES_TRANSMITTED,    /* The total count of CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_REQUESTS,
                                                                    *                     CLX_STAT_PORT_CNT_TYPE_DOT3_OUT_PAUSE_FRAMES
                                                                    */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_CRC_ERR,                         /* The same as CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_INTERNAL_MAC_TRANSMIT_ERRORS */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_64_OCTETS,                       /* Count if pkt length is less then 64.*/
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_65_TO_127_OCTETS,                /* Count if pkt length is in the range between 65 and 127. */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_128_TO_255_OCTETS,               /* Count if pkt length is in the range between 128 and 255. */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_256_TO_511_OCTETS,               /* Count if pkt length is in the range between 256 and 511. */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_512_TO_1023_OCTETS,              /* Count if pkt length is in the range between 512 and 1023. */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_1024_TO_1518_OCTETS,             /* Count if pkt length is in the range between 1024 and 1518. */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_1519_TO_2560_OCTETS,             /* Count if pkt length is in the range between 1519 and 2560. Dawn only */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_2561_TO_MAX_OCTETS,              /* Count if pkt length is larger then 2561. Dawn only */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_1519_TO_2047_OCTETS,             /* Count if pkt length is in the range between 1519 and 2047. */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_2048_TO_4095_OCTETS,             /* Count if pkt length is in the range between 2048 and 4095. */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_4096_TO_9216_OCTETS,             /* Count if pkt length is in the range between 4096 and 9216. */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_9217_TO_16383_OCTETS,            /* Count if pkt length is in the range between 9217 and 16383. */

    CLX_STAT_PORT_CNT_TYPE_DROP_CNT_RECEIVE,                        /* Dawn only */
    CLX_STAT_PORT_CNT_TYPE_DROP_CNT_TRANSMIT,                       /* Dawn only */

                                                            /* Drop counter */
    CLX_STAT_PORT_CNT_TYPE_TX_OVERSIZE_PKTS,                /* Tx oversize pkt */
    CLX_STAT_PORT_CNT_TYPE_L3_DISCARDS,                     /* The same as CLX_STAT_PORT_CNT_TYPE_INGRESS_L3_DISCARDS */
    CLX_STAT_PORT_CNT_TYPE_INGRESS_L3_DISCARDS,             /* Ingress l3 discard packet */
    CLX_STAT_PORT_CNT_TYPE_EGRESS_L3_DISCARDS,              /* Egress l3 discard packet */
    CLX_STAT_PORT_CNT_TYPE_L3_BLACKHOLE_DISCARDS,           /* L3 blackhole discard packet */
    CLX_STAT_PORT_CNT_TYPE_INGRESS_PARITY_DISCARDS,         /* Ingress parity discard packet */
    CLX_STAT_PORT_CNT_TYPE_EGRESS_NON_QUEUE_DISCARDS,       /* Egress non-queue discard packet */
    CLX_STAT_PORT_CNT_TYPE_EGRESS_INVALID_VLAN_DISCARDS,    /* Egress invalid vlan discard packet */
    CLX_STAT_PORT_CNT_TYPE_INGRESS_L2_MTU_DISCARDS,         /* Ingress L2 MTU discard packet */
    CLX_STAT_PORT_CNT_TYPE_BUFFER_DISCARDS,                 /* Buffer discard pkts */
    CLX_STAT_PORT_CNT_TYPE_INGRESS_NON_QUEUE_DISCARDS,      /* Ingress non-queue discard packet */
                                                            /* end */
    CLX_STAT_PORT_CNT_TYPE_LAST
} CLX_STAT_PORT_CNT_TYPE_T;

typedef enum
{
    CLX_STAT_TM_CNT_TYPE_PORT_DROP_RECEIVE = 0,  /* TM port rx drop counter */
    CLX_STAT_TM_CNT_TYPE_PORT_DROP_TRANSMIT,     /* TM port tx drop counter */
    CLX_STAT_TM_CNT_TYPE_PORT_CNT_RECEIVE,       /* TM port rx counter */
    CLX_STAT_TM_CNT_TYPE_PORT_CNT_TRANSMIT,      /* TM port tx counter */
    CLX_STAT_TM_CNT_TYPE_QUEUE_CNT,              /* TM (port , queue) counter */
    CLX_STAT_TM_CNT_TYPE_QUEUE_DROP_IGR_BUF,     /* TM (port , queue) drop counter due to igr buf full */
    CLX_STAT_TM_CNT_TYPE_QUEUE_DROP_EGR_BUF,     /* TM (port , queue) drop counter due to egr buf full */
    CLX_STAT_TM_CNT_TYPE_LAST
} CLX_STAT_TM_CNT_TYPE_T;

typedef struct CLX_STAT_TM_CNT_S
{
    UI64_T pkt_cnt;     /* The packet counter */
    UI64_T byte_cnt;    /* The packet byte counter */
} CLX_STAT_TM_CNT_T;

typedef CLX_STAT_TM_CNT_T CLX_STAT_TM_QUEUE_CNT_T;

typedef struct CLX_STAT_DIST_CNT_S
{
    UI64_T    total_byte_cnt;                   /* The total number of packet octets (including
                                                 * bad/dropped packets, broadcast packets, and
                                                 * multicast packets) received
                                                 */
    UI64_T    total_pkt_cnt;                    /* The total number of packets (including
                                                 * bad/dropped packets, broadcast packets, and
                                                 * multicast packets) received
                                                 */
    UI64_T    good_pkt_cnt_bc;                  /* The total number of good packets received and
                                                 * directed to the broadcast address
                                                 */
    UI64_T    good_pkt_cnt_mc;                  /* The total number of good packets received and
                                                 * directed to the multicast address
                                                 */
    UI64_T    pkt_cnt_len_less_equal_64;        /* pktlen <= 64Bytes */
    UI64_T    pkt_cnt_len_65_to_127;            /* 65 Bytes <= pktlen <= 127 Bytes */
    UI64_T    pkt_cnt_len_128_to_255;           /* 128 Bytes <= pktlen <= 255 Bytes */
    UI64_T    pkt_cnt_len_256_to_511;           /* 256 Bytes <= pktlen <= 511 Bytes */
    UI64_T    pkt_cnt_len_512_to_1023;          /* 512 Bytes <= pktlen <= 1023 Bytes */
    UI64_T    pkt_cnt_len_1024_to_1518;         /* 1024 Bytes <= pktlen <= 1518 Bytes */
    UI64_T    pkt_cnt_len_1519_to_2560;         /* 1519 Bytes <= pktlen <= 2560 Bytes used in CL8360 */
    UI64_T    pkt_cnt_len_2561_to_9216;         /* 2561 Bytes <= pktlen <= 9216 Bytes used in CL8360 */
    UI64_T    pkt_cnt_len_1519_to_2047;         /* 1519 Bytes <= pktlen <= 2047 Bytes used in CL8570 */
    UI64_T    pkt_cnt_len_2048_to_9216;         /* 2048 Bytes <= pktlen <= 9216 Bytes used in CL8570 */
} CLX_STAT_DIST_CNT_T;

#define CLX_STAT_CNT_NUM        (6)

typedef enum
{
    CLX_STAT_CNT_MODE_SINGLE = 0,   /* Regular counter single mode */
    CLX_STAT_CNT_MODE_DOUBLE,       /* Regular counter double mode */
    CLX_STAT_CNT_MODE_TRIPLE,       /* Regular counter triple mode */
    CLX_STAT_CNT_MODE_SIXFOLD,      /* Regular counter sixfold mode */
    CLX_STAT_CNT_MODE_LAST
} CLX_STAT_CNT_MODE_T;

typedef struct CLX_STAT_CNT_CFG_S
{
    CLX_STAT_CNT_MODE_T mode;
#define CLX_STAT_CNT_FLAGS_FORWARD          (1U << 0)    /* Count Forward */
#define CLX_STAT_CNT_FLAGS_DROP             (1U << 1)    /* Count Drop */
#define CLX_STAT_CNT_FLAGS_BYTE             (1U << 2)    /* Count Byte */
#define CLX_STAT_CNT_FLAGS_COLOR_RED        (1U << 3)    /* Count Red */
#define CLX_STAT_CNT_FLAGS_COLOR_YELLOW     (1U << 4)    /* Count Yellow */
#define CLX_STAT_CNT_FLAGS_COLOR_GREEN      (1U << 5)    /* Count Green */
#define CLX_STAT_CNT_FLAGS_COLOR_ALL                     /* Count All colors */  \
    (CLX_STAT_CNT_FLAGS_COLOR_GREEN | CLX_STAT_CNT_FLAGS_COLOR_YELLOW | CLX_STAT_CNT_FLAGS_COLOR_RED)
    UI32_T flags[CLX_STAT_CNT_NUM];                      /* Counter configuration */
} CLX_STAT_CNT_CFG_T;

typedef struct CLX_STAT_CNT_S
{
    UI64_T cnt[CLX_STAT_CNT_NUM];  /* The counter. Counting is based on the configuration */
} CLX_STAT_CNT_T;

typedef enum
{
    CLX_STAT_CNT_GROUP_MODE_SERVICE = 0,    /* Group for service counter */
    CLX_STAT_CNT_GROUP_MODE_FLOW,           /* Group for cia */
    CLX_STAT_CNT_GROUP_MODE_LAST
} CLX_STAT_CNT_GROUP_MODE_T;

typedef enum
{
    CLX_STAT_RATE_RX_BYTE, /* Bps */
    CLX_STAT_RATE_RX_PKT,  /* Pps */
    CLX_STAT_RATE_TX_BYTE, /* Bps */
    CLX_STAT_RATE_TX_PKT,  /* Pps */
    CLX_STAT_RATE_TYPE_LAST
} CLX_STAT_RATE_TYPE_T;

/* FUNCTION NAME:   clx_stat_getPortCnt
 * PURPOSE:
 *      This API is used to get port counter by physical port.
 * INPUT:
 *    unit                 --  Device unit number
 *    port                 --  Physical port
 *    type                 --  The type of counter
 *
 * OUTPUT:
 *    ptr_cnt              --  Counter
 *
 * RETURN:
 *    CLX_E_OK             --  Success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_getPortCnt(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_STAT_PORT_CNT_TYPE_T  type,
    UI64_T                          *ptr_cnt);

/* FUNCTION NAME:   clx_stat_clearPortCnt
 * PURPOSE:
 *      This API is used to clear port counter by physical port.
 * INPUT:
 *    unit                 --  Device unit number
 *    port                 --  Physical port
 *    type                 --  The type of counter
 *
 * OUTPUT:
 *
 * RETURN:
 *    CLX_E_OK             --  Success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_clearPortCnt(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_STAT_PORT_CNT_TYPE_T  type);

/* FUNCTION NAME:   clx_stat_getPortCntList
 * PURPOSE:
 *      This API is used to get port counter list by physical port.
 * INPUT:
 *    unit                 --  Device unit number
 *    port                 --  Physical port
 *    ptr_type             --  The type list of counter
 *    list_cnt             --  The number of the ptr_type and ptr_cnt
 *
 * OUTPUT:
 *    ptr_cnt              --  Counter list
 *
 * RETURN:
 *    CLX_E_OK             --  Success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_getPortCntList(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_STAT_PORT_CNT_TYPE_T *ptr_type,
    const UI32_T                    list_cnt,
    UI64_T                          *ptr_cnt);

/* FUNCTION NAME:   clx_stat_clearPortCntList
 * PURPOSE:
 *      This API is used to clear port counter list by physical port.
 * INPUT:
 *    unit                 --  Device unit number
 *    port                 --  Physical port
 *    ptr_type             --  The type list of counter
 *    list_cnt             --  The number of the ptr_type.
 *
 * OUTPUT:
 *
 * RETURN:
 *    CLX_E_OK             --  Success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_clearPortCntList(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_STAT_PORT_CNT_TYPE_T  *ptr_type,
    const UI32_T                    list_cnt);


/* FUNCTION NAME:   clx_stat_setTmQueueCntForPort
 * PURPOSE:
 *      This API is used to set port ID and TM queue counter used for port.
 * INPUT:
 *    unit                 --  Device unit number
 *    port                 --  TM port ID
 *
 * OUTPUT:
 *
 * RETURN:
 *    CLX_E_OK             --  Success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.
 *    CLX_E_NO_MEMORY      --  Allocate memory failed
 *    CLX_E_OTHERS         --  Operation failed
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_setTmQueueCntForPort(
    const UI32_T unit,
    const UI32_T port);

/* FUNCTION NAME:   clx_stat_getTmQueueCntForPort
 * PURPOSE:
 *      This API is used to get port ID and TM queue counter used for port
 * INPUT:
 *    unit                 --  Device unit number
 *
 * OUTPUT:
 *    ptr_port             --  TM port ID
 *
 * RETURN:
 *    CLX_E_OK             --  Success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_getTmQueueCntForPort(
    const UI32_T    unit,
    UI32_T          *ptr_port);

/* FUNCTION NAME:   clx_stat_setTmQueueCntForCpu
 * PURPOSE:
 *      This API is used to set CPU queue ID and TM queue counter used for CPU.
 * INPUT:
 *    unit                 --  Device unit number
 *    handler              --  The handler of TM queue
 *    cpu_handler          --  The handler of CPU queue
 *
 * OUTPUT:
 *
 * RETURN:
 *    CLX_E_OK             --  Success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.
 *    CLX_E_NO_MEMORY      --  Allocate memory failed
 *    CLX_E_OTHERS         --  Operation failed
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_setTmQueueCntForCpu(
    const UI32_T            unit,
    const CLX_TM_HANDLER_T  handler,
    const CLX_TM_HANDLER_T  cpu_handler);

/* FUNCTION NAME:   clx_stat_getTmQueueCntForCpu
 * PURPOSE:
 *      This API is used to get CPU queue ID and TM queue counter used for CPU.
 * INPUT:
 *    unit                 --  Device unit number
 *    handler              --  The handler of TM queue
 *
 * OUTPUT:
 *    ptr_cpu_handler      --  The handler of CPU queue
 *
 * RETURN:
 *    CLX_E_OK             --  Success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_getTmQueueCntForCpu(
    const UI32_T            unit,
    const CLX_TM_HANDLER_T  handler,
    CLX_TM_HANDLER_T        *ptr_cpu_handler);

/* FUNCTION NAME:   clx_stat_getTmQueueCnt
 * PURPOSE:
 *      This API is used to get TM counter by TM queue.
 * INPUT:
 *    unit                 --  Device unit number
 *    handler              --  The handler of TM queue
 *
 * OUTPUT:
 *    ptr_cnt              --  Queue counter
 *
 * RETURN:
 *    CLX_E_OK             --  Success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_getTmQueueCnt(
    const UI32_T            unit,
    const CLX_TM_HANDLER_T  handler,
    CLX_STAT_TM_QUEUE_CNT_T *ptr_cnt);

/* FUNCTION NAME:   clx_stat_clearTmQueueCnt
 * PURPOSE:
 *      This API is used to clear TM counter by TM queue.
 * INPUT:
 *    unit                 --  Device unit number
 *    handler              --  The handler of TM queue
 *
 * OUTPUT:
 *
 * RETURN:
 *    CLX_E_OK             --  Success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.
 *    CLX_E_NO_MEMORY      --  Allocate memory failed
 *    CLX_E_OTHERS         --  Operation failed
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_clearTmQueueCnt(
    const UI32_T            unit,
    const CLX_TM_HANDLER_T  handler);

/* FUNCTION NAME:   clx_stat_getTmCnt
 * PURPOSE:
 *      This API is used to get counter by port, queue, and TM counter type.
 * INPUT:
 *    unit                 --  Device unit number
 *    port                 --  Port ID
 *    handler              --  The handler of TM queue
 *    type                 --  The TM counter type
 *
 * OUTPUT:
 *    ptr_cnt              --  Counter value
 *
 * RETURN:
 *    CLX_E_OK             --  Success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.
 *    CLX_E_OTHERS         --  Operation failed
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_getTmCnt(
    const UI32_T                 unit,
    const UI32_T                 port,
    const CLX_TM_HANDLER_T       handler,
    const CLX_STAT_TM_CNT_TYPE_T type,
    CLX_STAT_TM_CNT_T            *ptr_cnt);

/* FUNCTION NAME:   clx_stat_clearTmCnt
 * PURPOSE:
 *      This API is used to clear counter by port, queue, and TM counter type.
 * INPUT:
 *    unit                 --  Device unit number
 *    port                 --  Port ID
 *    handler              --  The handler of TM queue
 *    type                 --  The TM counter type
 *
 * OUTPUT:
 *    None
 *
 * RETURN:
 *    CLX_E_OK             --  Success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.
 *    CLX_E_OTHERS         --  Operation failed
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_clearTmCnt(
    const UI32_T                 unit,
    const UI32_T                 port,
    const CLX_TM_HANDLER_T       handler,
    const CLX_STAT_TM_CNT_TYPE_T type);

/* FUNCTION NAME:   clx_stat_createDistCnt
 * PURPOSE:
 *      This API is used to create a distribution counter for
 *      ingress interface (L2, L3, tunnel), egress interface (L2, L3, tunnel),
 *      domain (VLAN, FD, VRF) and flow (ingress ACL and egress ACL).
 * INPUT:
 *    unit                 --  Device unit number
 *
 * OUTPUT:
 *    ptr_cnt_id           --  Counter logic ID.
 *
 * RETURN:
 *    CLX_E_OK             --  Success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.
 *    CLX_E_TABLE_FULL     --  There is no counter to serve the cnt_type.
 *    CLX_E_OTHERS         --  Operation failed.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_createDistCnt(
    const UI32_T        unit,
    UI32_T              *ptr_cnt_id);

/* FUNCTION NAME:   clx_stat_destroyDistCnt
 * PURPOSE:
 *      This API is used to destroy a distribution counter.
 * INPUT:
 *    unit                  --  Device unit number
 *    cnt_id                --  Counter logic ID
 *
 * OUTPUT:
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 *    CLX_E_ENTRY_NOT_FOUND --  The counter has not been created.
 *    CLX_E_OTHERS          --  Operation failed.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_destroyDistCnt(
    const UI32_T        unit,
    const UI32_T        cnt_id);

/* FUNCTION NAME:   clx_stat_getDistCnt
 * PURPOSE:
 *      This API is used to get a distribution counter.
 * INPUT:
 *    unit                  --  Device unit number
 *    cnt_id                --  Counter ID
 *
 * OUTPUT:
 *    ptr_cnt               --  Counter
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 *    CLX_E_ENTRY_NOT_FOUND --  The counter has not been created.
 *    CLX_E_OTHERS          --  Operation failed.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_getDistCnt(
    const UI32_T        unit,
    const UI32_T        cnt_id,
    CLX_STAT_DIST_CNT_T *ptr_cnt);

/* FUNCTION NAME:   clx_stat_clearDistCnt
 * PURPOSE:
 *      This API is used to clear a distribution counter.
 * INPUT:
 *    unit                   --  Device unit number
 *    cnt_id                 --  Counter ID
 * OUTPUT:
 *
 * RETURN:
 *    CLX_E_OK               --  Success.
 *    CLX_E_BAD_PARAMETER    --  Bad parameter.
 *    CLX_E_ENTRY_NOT_FOUND  --  The counter has not been created.
 *    CLX_E_OTHERS           --  Operation failed
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_clearDistCnt(
    const UI32_T        unit,
    const UI32_T        cnt_id);

/* FUNCTION NAME:   clx_stat_createCnt
 * PURPOSE:
 *      This API is used to create a counter for interface (ingress, egress) or
 *      domain (forward domain, VRF), or flow (ingress ACL or egress ACL).
 *
 * INPUT:
 *    unit                  --  Device unit number
 *    ptr_cfg               --  The type of counter
 *
 * OUTPUT:
 *    ptr_cnt_id            --  Counter ID.
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 *    CLX_E_TABLE_FULL      --  There is no counter available.
 *    CLX_E_OTHERS          --  Operation failed.
 *
 * NOTES:
 *    None
 */
CLX_ERROR_NO_T
clx_stat_createCnt(
    const UI32_T                unit,
    const CLX_STAT_CNT_CFG_T    *ptr_cfg,
    UI32_T                      *ptr_cnt_id);

/* FUNCTION NAME:   clx_stat_destroyCnt
 * PURPOSE:
 *      This API is used to destroy a counter create via clx_stat_createCnt
 *
 * INPUT:
 *    unit                  --  Device unit number
 *    cnt_id                --  Counter ID
 *
 * OUTPUT:
 *    None
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 *    CLX_E_ENTRY_NOT_FOUND --  The counter has not been created.
 *
 * NOTES:
 *    None
 */
CLX_ERROR_NO_T
clx_stat_destroyCnt(
    const UI32_T    unit,
    const UI32_T    cnt_id);

/* FUNCTION NAME:   clx_stat_getCnt
 * PURPOSE:
 *      This API is used to get value of the counter under study
 *
 * INPUT:
 *    unit                  --  Device unit number
 *    cnt_id                --  Counter ID
 *
 * OUTPUT:
 *    ptr_cnt               --  The return counter values
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 *    CLX_E_ENTRY_NOT_FOUND --  The counter has not been created.
 *
 * NOTES:
 *    The number of counters value return is determined by the type of counter under study.
 *
 */
CLX_ERROR_NO_T
clx_stat_getCnt(
    const UI32_T        unit,
    const UI32_T        cnt_id,
    CLX_STAT_CNT_T      *ptr_cnt);

/* FUNCTION NAME:   clx_stat_clearCnt
 * PURPOSE:
 *      This API is used to clear value of the counter under study
 *
 * INPUT:
 *    unit                  --  Device unit number
 *    cnt_id                --  Counter ID
 *
 * OUTPUT:
 *    None
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 *    CLX_E_ENTRY_NOT_FOUND --  The counter has not been created.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_stat_clearCnt(
    const UI32_T    unit,
    const UI32_T    cnt_id);

/* FUNCTION NAME:   clx_stat_getCntCfg
 * PURPOSE:
 *      This API is used to get config of the counter under study
 *
 * INPUT:
 *    unit                  --  Device unit number
 *    cnt_id                --  Counter ID
 *
 * OUTPUT:
 *    ptr_cfg               --  The return counter values
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 *    CLX_E_ENTRY_NOT_FOUND --  The counter has not been created.
 *
 * NOTES:
 *    The number of counters value return is determined by the type of counter under study.
 *
 */
CLX_ERROR_NO_T
clx_stat_getCntCfg(
    const UI32_T        unit,
    const UI32_T        cnt_id,
    CLX_STAT_CNT_CFG_T  *ptr_cfg);

/* FUNCTION NAME:   clx_stat_getPortRate
 * PURPOSE:
 *      This API is used to get port traffic rate by physical port.
 * INPUT:
 *    unit                 --  Device unit number
 *    port                 --  Physical port
 *    type                 --  The type of traffic rate
 *
 * OUTPUT:
 *    ptr_rate             --  Rate
 *
 * RETURN:
 *    CLX_E_OK             --  Success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_getPortRate(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_STAT_RATE_TYPE_T      type,
    UI64_T                          *ptr_rate);

/* FUNCTION NAME:   clx_stat_refreshCnt
 * PURPOSE:
 *      This API is used to trigger manually counter update to get latest counter value.
 *
 * INPUT:
 *    unit                  --  Device unit number
 *
 * OUTPUT:
 *    None
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 *    CLX_E_NOT_SUPPORT     --  This API is not support in this chip.
 *
 * NOTES:
 *    The API takes time to collect latest counter please use it wisely.
 *
 */
CLX_ERROR_NO_T
clx_stat_refreshCnt(
    const UI32_T    unit);

/* FUNCTION NAME:   clx_stat_setFlowGroupMode
 * PURPOSE:
 *      This API is used to set a flow group mode.
 * INPUT:
 *    unit                  --  Device unit number
 *    dir                   --  The flow counter group type: <CL>
 *                              CLX_DIR_INGRESS: The group ID is ingress flow group ID. <CL>
 *                              CLX_DIR_EGRESS: The group ID is egress flow group ID.
 *    grp_id                --  The flow group ID
 *    grp_mode              --  The flow group mode
 *
 * OUTPUT:
 *
 * RETURN:
 *    CLX_E_OK  --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 *    CLX_E_NOT_SUPPORT     --  This API is not support in this chip.
 *    CLX_E_OTHERS          --  Operation failed.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_setFlowGroupMode(
    const UI32_T                    unit,
    const CLX_DIR_T                 dir,
    const UI32_T                    grp_id,
    const CLX_STAT_CNT_GROUP_MODE_T grp_mode);

/* FUNCTION NAME:   clx_stat_getFlowGroupMode
 * PURPOSE:
 *      This API is used to get a flow group mode.
 * INPUT:
 *    unit                 --  Device unit number
 *    dir                  --  The flow counter group type: <CL>
 *                             CLX_DIR_INGRESS: The group ID is ingress flow group ID. <CL>
 *                             CLX_DIR_EGRESS: The group ID is egress flow group ID.
 *    grp_id               --  The flow group ID
 *
 * OUTPUT:
 *    ptr_mode             --  The flow group mode
 *
 * RETURN:
 *    CLX_E_OK             --  Success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.
 *    CLX_E_NOT_SUPPORT    --  This API is not support in this chip.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_getFlowGroupMode(
    const UI32_T                unit,
    const CLX_DIR_T             dir,
    const UI32_T                grp_id,
    CLX_STAT_CNT_GROUP_MODE_T   *ptr_mode);

/* FUNCTION NAME:   clx_stat_getFlowGroupCapacity
 * PURPOSE:
 *      This API is used to get the capacity of counter in the flow group.
 * INPUT:
 *    unit                 --  Device unit number
 *    dir                  --  The flow counter group type: <CL>
 *                             CLX_DIR_INGRESS: The group ID is ingress flow group ID. <CL>
 *                             CLX_DIR_EGRESS: The group ID is egress flow group ID.
 *    grp_id               --  The flow group ID
 *
 * OUTPUT:
 *    ptr_capacity         --  The flow group capacity.
 *
 * RETURN:
 *    CLX_E_OK             --  Success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.
 *    CLX_E_NOT_SUPPORT    --  This API is not support in this chip.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_stat_getFlowGroupCapacity(
    const UI32_T                unit,
    const CLX_DIR_T             dir,
    const UI32_T                grp_id,
    UI32_T                      *ptr_capacity);

/* FUNCTION NAME:   clx_stat_getCntIdByFlowGroup
 * PURPOSE:
 *      This API is used to get the ID of counter which belongs to the flow group.
 * INPUT:
 *    unit                   --  Device unit number
 *    dir                    --  The flow counter group type: <CL>
 *                               CLX_DIR_INGRESS: The group ID is ingress flow group ID. <CL>
 *                               CLX_DIR_EGRESS: The group ID is egress flow group ID.
 *    grp_id                 --  Flow counter group ID.
 *    id_cnt                 --  The size of the buffer to which "ptr_cnt_id" points.
 *
 * OUTPUT:
 *    ptr_cnt_id             --  The counter ID.
 *    ptr_actual_cnt_id_cnt  --  The count of counter ID in "ptr_cnt_id".
 *
 * RETURN:
 *    CLX_E_OK               --  Success.
 *    CLX_E_BAD_PARAMETER    --  Bad parameter.
 *    CLX_E_NOT_SUPPORT    --  This API is not support in this chip.
 * NOTES:
 *      User can get the counter max count and then prepare the counter ID buffer
 *      of which size the counter counts.
 */
CLX_ERROR_NO_T
clx_stat_getCntIdByFlowGroup(
    const UI32_T                unit,
    const CLX_DIR_T             dir,
    const UI32_T                grp_id,
    const UI32_T                id_cnt,
    UI32_T                      *ptr_cnt_id,
    UI32_T                      *ptr_actual_cnt_id_cnt);

#endif /* End of CLX_STAT_H */
