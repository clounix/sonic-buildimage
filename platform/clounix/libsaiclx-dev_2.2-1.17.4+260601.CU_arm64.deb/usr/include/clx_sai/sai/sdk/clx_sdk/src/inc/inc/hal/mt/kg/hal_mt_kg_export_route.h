/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_export_route.h
 * PURPOSE:
 *  Provide HAL driver API functions of export route module.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_KG_EXPORT_ROUTE_H
#define HAL_MT_KG_EXPORT_ROUTE_H
/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO  DECLARATIONS
 */
#define HAL_MT_KG_EXPORT_ROUTE_ENTRIES_PER_TCAM 1024
#define HAL_MT_KG_EXPORT_ROUTE_MAX_THREADS      1 // Maximum number of parser threads
#define HAL_MT_KG_EXPORT_ROUTE_TCAM_PER_THREAD                                  \
    (((HAL_MT_KG_SWC_MAX_TCAM_NUM) * HAL_MT_KG_EXPORT_ROUTE_ENTRIES_PER_TCAM) / \
     (HAL_MT_KG_EXPORT_ROUTE_MAX_THREADS)) // Number of TCAMs per thread (4K entries)

/* TCAM */
#define HAL_MT_KG_EXPORT_ROUTE_TABLE_FPU_TCAM_FIB_1X_SIZE 28
#define HAL_MT_KG_EXPORT_ROUTE_TABLE_FPU_TCAM_FIB_2X_SIZE \
    (HAL_MT_KG_EXPORT_ROUTE_TABLE_FPU_TCAM_FIB_1X_SIZE * 2)
#define HAL_MT_KG_EXPORT_ROUTE_TABLE_FPU_TCAM_FIB_4X_SIZE \
    (HAL_MT_KG_EXPORT_ROUTE_TABLE_FPU_TCAM_FIB_1X_SIZE * 4)

/* RSLT */
#define HAL_MT_KG_EXPORT_ROUTE_TABLE_FPU_RSLT_FIB_SIZE 16

/* AFIB HSH TILE */
#define HAL_MT_KG_EXPORT_ROUTE_AFIB_HSH_TILE_SIZE       (16 * 1024) // 16K entries
#define HAL_MT_KG_EXPORT_ROUTE_AFIB_HSH_TILE_ENTRY_SIZE 24          // 24 bytes per entry

/*
 * IPv4 TCAM field offset definitions (bit offset)
 * Reference nb_e1_fpu_tcam_fib_v4_tbl_field_offset structure
 */
#define HAL_MT_KG_EXPORT_ROUTE_IPV4_TCAM_FIELD_VLD_T_OFFSET 192 // VLD_T: offset=192, length=1
#define HAL_MT_KG_EXPORT_ROUTE_IPV4_TCAM_FIELD_KEY_TYPE_T_OFFSET \
    0                                                           // KEY_TYPE_0_T: offset=0, length=2
#define HAL_MT_KG_EXPORT_ROUTE_IPV4_TCAM_FIELD_VRF_T_OFFSET 3   // VRF_T: offset=3, length=13
#define HAL_MT_KG_EXPORT_ROUTE_IPV4_TCAM_FIELD_VRF_C_OFFSET 51  // VRF_C: offset=51, length=13
#define HAL_MT_KG_EXPORT_ROUTE_IPV4_TCAM_FIELD_HOST_IP_T_OFFSET \
    16                                                          // HOST_IP_0_T: offset=16, length=32
#define HAL_MT_KG_EXPORT_ROUTE_IPV4_TCAM_FIELD_HOST_IP_C_OFFSET \
    64                                                          // HOST_IP_0_C: offset=64, length=32

/*
 * IPv6 TCAM field offset definitions (bit offset)
 * Common fields
 */
#define HAL_MT_KG_EXPORT_ROUTE_IPV6_TCAM_FIELD_VLD_T_OFFSET 192 // VLD_T: offset=192, length=1
#define HAL_MT_KG_EXPORT_ROUTE_IPV6_TCAM_FIELD_KEY_TYPE_T_OFFSET \
    0                                                           // KEY_TYPE_0_T: offset=0, length=2
#define HAL_MT_KG_EXPORT_ROUTE_IPV6_TCAM_FIELD_VRF_T_OFFSET 3   // VRF_T: offset=3, length=13

/*
 * IPv6 2X field offset definitions (bit offset)
 * 64-bit address
 */
#define HAL_MT_KG_EXPORT_ROUTE_IPV6_2X_VRF_C_OFFSET      99 // VRF_C: offset=99, length=13
#define HAL_MT_KG_EXPORT_ROUTE_IPV6_2X_HOST_IP0_T_OFFSET 16 // HOST_IP_0_T: offset=16, length=32
#define HAL_MT_KG_EXPORT_ROUTE_IPV6_2X_HOST_IP0_C_OFFSET 64 // HOST_IP_0_C: offset=64, length=32
#define HAL_MT_KG_EXPORT_ROUTE_IPV6_2X_KEY_TYPE_T_OFFSET 0  // Same as KEY_TYPE_0_T

/*
 * IPv6 4X field offset definitions (bit offset)
 * 128-bit address
 */
#define HAL_MT_KG_EXPORT_ROUTE_IPV6_4X_HOST_IP0_T_OFFSET 16 // HOST_IP_0_T: offset=16, length=32
#define HAL_MT_KG_EXPORT_ROUTE_IPV6_4X_HOST_IP0_C_OFFSET 64 // HOST_IP_0_C: offset=64, length=32
#define HAL_MT_KG_EXPORT_ROUTE_IPV6_4X_KEY_TYPE_T_OFFSET 0  // Same as KEY_TYPE_0_T

/* Field length definitions */
#define HAL_MT_KG_EXPORT_ROUTE_FIELD_VLD_LENGTH      1  // VLD field length, 1 bit
#define HAL_MT_KG_EXPORT_ROUTE_FIELD_KEY_TYPE_LENGTH 2  // KEY_TYPE field length, 2 bits
#define HAL_MT_KG_EXPORT_ROUTE_FIELD_VRF_LENGTH      13 // VRF field length, 13 bits
#define HAL_MT_KG_EXPORT_ROUTE_FIELD_HOST_IP_LENGTH  32 // HOST_IP field length, 32 bits

/* KEY_TYPE type definitions */
#define HAL_MT_KG_EXPORT_ROUTE_KEY_TYPE_IPV4    0 // IPv4 type
#define HAL_MT_KG_EXPORT_ROUTE_KEY_TYPE_IPV6_2X 1 // IPv6 2X type
#define HAL_MT_KG_EXPORT_ROUTE_KEY_TYPE_IPV6_4X 2 // IPv6 4X type

/* RSLT field offset definitions (bit offset) */
#define HAL_MT_KG_EXPORT_ROUTE_RSLT_FIELD_IS_AFIB_OFFSET    0 // IS_AFIB: offset=0, length=1
#define HAL_MT_KG_EXPORT_ROUTE_RSLT_FIELD_PREFIX_LEN_OFFSET 1 // PREFIX_LEN: offset=1, length=7
#define HAL_MT_KG_EXPORT_ROUTE_RSLT_FIELD_TRIE_BMAP_OFFSET  8 // TRIE_BMAP: offset=8, length=32
#define HAL_MT_KG_EXPORT_ROUTE_RSLT_FIELD_AFIB_RSLT_PTR_OFFSET \
    40                                                        // AFIB_RSLT_PTR: offset=40, length=20
#define HAL_MT_KG_EXPORT_ROUTE_RSLT_FIELD_KEY_LEN_OFFSET 39   // KEY_LEN: offset=39, length=1

/* RSLT field length definitions */
#define HAL_MT_KG_EXPORT_ROUTE_RSLT_FIELD_IS_AFIB_LENGTH    1  // IS_AFIB field length, 1 bit
#define HAL_MT_KG_EXPORT_ROUTE_RSLT_FIELD_PREFIX_LEN_LENGTH 7  // PREFIX_LEN field length, 7 bits
#define HAL_MT_KG_EXPORT_ROUTE_RSLT_FIELD_TRIE_BMAP_LENGTH  31 // TRIE_BMAP field length, 31 bits
#define HAL_MT_KG_EXPORT_ROUTE_RSLT_FIELD_AFIB_RSLT_PTR_LENGTH \
    20                                                     // AFIB_RSLT_PTR field length, 20 bits
#define HAL_MT_KG_EXPORT_ROUTE_RSLT_FIELD_KEY_LEN_LENGTH 1 // KEY_LEN field length, 1 bit

/* Hash table offset definitions */
#define HAL_MT_KG_EXPORT_ROUTE_HASH_STAGE_OFFSET        16
#define HAL_MT_KG_EXPORT_ROUTE_HASH_STAGE_OFFSET_DETACH 16
#define HAL_MT_KG_EXPORT_ROUTE_HASH_TILE_OFFSET         15
#define HAL_MT_KG_EXPORT_ROUTE_HASH_TILE_OFFSET_DETACH  15
#define HAL_MT_KG_EXPORT_ROUTE_HASH_ENTRY_OFFSET_DETACH 1
#define HAL_MT_KG_EXPORT_ROUTE_HASH_FPU_LENGTH          1
#define HAL_MT_KG_EXPORT_ROUTE_HASH_STAGE_LENGTH        4
#define HAL_MT_KG_EXPORT_ROUTE_HASH_TILE_LENGTH         1
#define HAL_MT_KG_EXPORT_ROUTE_HASH_ENTRY_LENGTH_DETACH 14

#define HAL_MT_KG_EXPORT_ROUTE_AFIB_WITH_ACL_VLD_OFFSET       0
#define HAL_MT_KG_EXPORT_ROUTE_AFIB_WITH_ACL_VLD_LENGTH       1
#define HAL_MT_KG_EXPORT_ROUTE_AFIB_WITH_ACL_FWD_PTR_0_OFFSET 3
#define HAL_MT_KG_EXPORT_ROUTE_AFIB_WITH_ACL_FWD_PTR_0_LENGTH 19
#define HAL_MT_KG_EXPORT_ROUTE_AFIB_WITH_ACL_FWD_PTR_1_OFFSET 47
#define HAL_MT_KG_EXPORT_ROUTE_AFIB_WITH_ACL_FWD_PTR_1_LENGTH 19

#define HAL_MT_KG_EXPORT_ROUTE_AFIB_WITHOUT_ACL_VLD_OFFSET       0
#define HAL_MT_KG_EXPORT_ROUTE_AFIB_WITHOUT_ACL_VLD_LENGTH       1
#define HAL_MT_KG_EXPORT_ROUTE_AFIB_WITHOUT_ACL_FWD_PTR_0_OFFSET 3
#define HAL_MT_KG_EXPORT_ROUTE_AFIB_WITHOUT_ACL_FWD_PTR_0_LENGTH 19
#define HAL_MT_KG_EXPORT_ROUTE_AFIB_WITHOUT_ACL_FWD_PTR_1_OFFSET 25
#define HAL_MT_KG_EXPORT_ROUTE_AFIB_WITHOUT_ACL_FWD_PTR_1_LENGTH 19
#define HAL_MT_KG_EXPORT_ROUTE_AFIB_WITHOUT_ACL_FWD_PTR_2_OFFSET 47
#define HAL_MT_KG_EXPORT_ROUTE_AFIB_WITHOUT_ACL_FWD_PTR_2_LENGTH 19
#define HAL_MT_KG_EXPORT_ROUTE_AFIB_WITHOUT_ACL_FWD_PTR_3_OFFSET 69
#define HAL_MT_KG_EXPORT_ROUTE_AFIB_WITHOUT_ACL_FWD_PTR_3_LENGTH 19

#define HAL_MT_KG_EXPORT_ROUTE_ROUTE_FLAG_ROOTNODE      (0x01) /* Root node */
#define HAL_MT_KG_EXPORT_ROUTE_ROUTE_FLAG_AFIB_WITH_ACL (0x02) /* AFIB with ACL */

/* DATA TYPE DECLARATIONS
 */

/* FUNCTION MACRO DECLARATIONS
 */
/**
 * @brief Initialize the export route module.
 *
 * @param [in]    unit    - Chip unit number.
 * @return        CLX_E_OK    - Operation successful.
 */
clx_error_no_t
hal_mt_kg_export_route_init(uint32 unit);

/**
 * @brief Get route data from hardware and parse it into a list.
 *
 * This function exports route data from hardware and parses it into a list.
 *
 * @param [in]     unit      - Chip unit number.
 * @param [in]     ptr_cb    - Pointer to the export route control entity.
 * @param [out]    flags     - Flags.
 * @return         CLX_E_OK        - Operation successful.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_kg_export_route_data_get(uint32 unit, void *ptr_cb, uint32_t *flags);

/**
 * @brief Get route data from hardware and parse it into a list.
 *
 * This function get the destination index of the port.
 *
 * @param [in]     unit      - Chip unit number.
 * @param [in]     port      - Port number.
 * @param [out]    ptr_di    - Destination index.
 * @return         CLX_E_OK        - Operation successful.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_kg_export_route_l3_dst_idx_get(uint32 unit, const clx_port_t port, uint32 *ptr_di);
#endif