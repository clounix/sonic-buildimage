/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_phy.h
 * PURPOSE:
 *      It provide CL8400 API.
 * NOTES:
 *
 */
#ifndef HAL_MT_KG_PHY_H
#define HAL_MT_KG_PHY_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <hal/hal.h>
#include <hal/hal_phy.h>
#include <hal/hal_mdio.h>
#include <tob/tob_tbl.h>

#include <stdio.h>
#include <hal/mt/kg/hal_mt_kg_pma.h>
#include <drv/drv_io.h>
#include <osal/osal.h>
#include <hal/mt/kg/hal_mt_kg_led.h>
#include <hal/mt/kg/hal_mt_kg_mdio.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
/* plane0 phy_wrap0 eth_macro0   lane0 - 7 (slice/ip)     PHY_B*/
/* plane0 phy_wrap1 eth_macro1   lane0 - 15(slice/ip)     PHY_A*/
/* plane0 phy_wrap2 eth_macro2   lane0 - 15(slice/ip)     PHY_A*/
/* plane0 phy_wrap3 eth_macro3   lane0 - 15(slice/ip)     PHY_A*/
/* plane0 phy_wrap4 eth_macro4   lane0 - 15(slice/ip)     PHY_A*/
/* plane0 phy_wrap5 eth_macro5   lane0 - 9 (slice/ip)     PHY_C*/

/* plane1 phy_wrap0 eth_macro0   lane0 - 7 (slice/ip)     PHY_B*/
/* plane1 phy_wrap1 eth_macro1   lane0 - 15(slice/ip)     PHY_A*/
/* plane1 phy_wrap2 eth_macro2   lane0 - 15(slice/ip)     PHY_A*/
/* plane1 phy_wrap3 eth_macro3   lane0 - 15(slice/ip)     PHY_A*/
/* plane1 phy_wrap4 eth_macro4   lane0 - 15(slice/ip)     PHY_A*/
/* plane1 phy_wrap5 eth_macro5   lane0 - 9 (slice/ip)     PHY_C*/

/* plane0 phy_wrap0 d2d_macro0(slice/ip)   lane0 - 7      PHY_B*/
/* plane0 phy_wrap0 d2d_macro1(slice/ip)   lane0 - 7      PHY_B*/
/* plane0 phy_wrap0 d2d_macro2(slice/ip)   lane0 - 7      PHY_B*/
/* plane0 phy_wrap0 d2d_macro3(slice/ip)   lane0 - 7      PHY_B*/
/* plane0 phy_wrap0 d2d_macro4(slice/ip)   lane0 - 7      PHY_B*/
/* plane0 phy_wrap0 d2d_macro5(slice/ip)   lane0 - 7      PHY_B*/

/* plane1 phy_wrap0 d2d_macro0(slice/ip)   lane0 - 7      PHY_B*/
/* plane1 phy_wrap0 d2d_macro1(slice/ip)   lane0 - 7      PHY_B*/
/* plane1 phy_wrap0 d2d_macro2(slice/ip)   lane0 - 7      PHY_B*/
/* plane1 phy_wrap0 d2d_macro3(slice/ip)   lane0 - 7      PHY_B*/
/* plane1 phy_wrap0 d2d_macro4(slice/ip)   lane0 - 7      PHY_B*/
/* plane1 phy_wrap0 d2d_macro5(slice/ip)   lane0 - 7      PHY_B*/

#define HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO   (16)
#define HAL_MT_KG_PHY_B_MAX_LANES_PER_MACRO   (8)
#define HAL_MT_KG_PHY_C_MAX_LANES_PER_MACRO   (10)
#define HAL_MT_KG_PHY_A_MAX_MACRO_PER_PLANE   (4)
#define HAL_MT_KG_PHY_B_MAX_MACRO_PER_PLANE   (1)
#define HAL_MT_KG_PHY_C_MAX_MACRO_PER_PLANE   (1)
#define HAL_MT_KG_PHY_D2D_MAX_MACRO_PER_PLANE (6)
#define HAL_MT_KG_PHY_MAX_PLANE_PER_CHIP      (2)

#define HAL_MT_KG_PHY_ETH_MAX_MACRO_PER_PLANE                                    \
    (HAL_MT_KG_PHY_A_MAX_MACRO_PER_PLANE + HAL_MT_KG_PHY_B_MAX_MACRO_PER_PLANE + \
     HAL_MT_KG_PHY_C_MAX_MACRO_PER_PLANE)

#define HAL_MT_KG_PHY_ETH_MAX_MACRO_PER_CHIP \
    (HAL_MT_KG_PHY_ETH_MAX_MACRO_PER_PLANE * HAL_MT_KG_PHY_MAX_PLANE_PER_CHIP)

#define HAL_MT_KG_PHY_ETH_MAX_LANES_PER_PLANE                                      \
    ((HAL_MT_KG_PHY_A_MAX_MACRO_PER_PLANE * HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO) + \
     (HAL_MT_KG_PHY_B_MAX_MACRO_PER_PLANE * HAL_MT_KG_PHY_B_MAX_LANES_PER_MACRO) + \
     (HAL_MT_KG_PHY_C_MAX_MACRO_PER_PLANE * HAL_MT_KG_PHY_C_MAX_LANES_PER_MACRO))
#define HAL_MT_KG_PHY_ETH_MAX_LANES_PER_CHIP \
    (HAL_MT_KG_PHY_ETH_MAX_LANES_PER_PLANE * HAL_MT_KG_PHY_MAX_PLANE_PER_CHIP)
#define HAL_MT_KG_PHY_D2D_MAX_LANES_PER_PLANE \
    (HAL_MT_KG_PHY_B_MAX_LANES_PER_MACRO * HAL_MT_KG_PHY_D2D_MAX_MACRO_PER_PLANE)
#define HAL_MT_KG_PHY_D2D_MAX_LANES_PER_CHIP \
    (HAL_MT_KG_PHY_D2D_MAX_LANES_PER_PLANE * HAL_MT_KG_PHY_MAX_PLANE_PER_CHIP)
#define HAL_MT_KG_PHY_D2D_MAX_MACRO_PER_CHIP \
    (HAL_MT_KG_PHY_D2D_MAX_MACRO_PER_PLANE * HAL_MT_KG_PHY_MAX_PLANE_PER_CHIP)

#define HAL_MT_KG_PHY_D2D_PORT_LANE_NUM (4)

#define HAL_MT_KG_PHY_ETH_PHY0_BASE_ADDR    0x0A36000
#define HAL_MT_KG_PHY_ETH_PHY_OFFSET        0x0400000
#define HAL_MT_KG_PHY_ETH_LANE_OFFSET       0x0040000
#define HAL_MT_KG_PHY_D2D_PHY0_BASE_ADDR    0x223f000
#define HAL_MT_KG_PHY_D2D_PHY_OFFSET        0x0040000
#define HAL_MT_KG_PHY_PLANE_GAP             0x8000000
#define HAL_MT_KG_PHY_D2D_TX_LANE_GAP       0x0000100
#define HAL_MT_KG_PHY_D2D_PAM4_RX_LANE_BASE 0x0001000
#define HAL_MT_KG_PHY_D2D_NRZ_RX_LANE_BASE  0x0001100
#define HAL_MT_KG_PHY_D2D_RX_LANE_GAP       0x0000200

/* ------------------------------------
 * REG: FW top reg 0x41
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_TOP_FW_0X41 0x00000041
/* [10:10 - pam4 enable] */
#define HAL_MT_KG_PHY_REG_TOP_FW_0X41_PAM4_EN_OFFSET   0x0000000A
#define HAL_MT_KG_PHY_REG_TOP_FW_0X41_PAM4_EN_BITWIDTH 0x00000001
#define HAL_MT_KG_PHY_REG_TOP_FW_0X41_PAM4_EN_MASK     0x00008000

/* ------------------------------------
 * REG: NRZ RX eye margin mode
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_EYE_MARGIN_MODE 0x00000109
/* [15:15 - em_mode] */
#define HAL_MT_KG_PHY_REG_EYE_MARGIN_MODE_EM_MODE_OFFSET   0x0000000F
#define HAL_MT_KG_PHY_REG_EYE_MARGIN_MODE_EM_MODE_BITWIDTH 0x00000001
#define HAL_MT_KG_PHY_REG_EYE_MARGIN_MODE_EM_MODE_MASK     0x00008000

/* ------------------------------------
 * REG: AN enable
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_AUTONEG_EN 0x00008000
/* [12:12] - selector field */
#define HAL_MT_KG_PHY_REG_AUTONEG_EN_AN_ENABLE_OFFSET   0x0000000C
#define HAL_MT_KG_PHY_REG_AUTONEG_EN_AN_ENABLE_BITWIDTH 0x00000001
#define HAL_MT_KG_PHY_REG_AUTONEG_EN_AN_ENABLE_MASK     0x00001000

/* ------------------------------------
 * REG: AN status
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_AUTONEG_STS 0x00008001
/* [12:12] - selector field */
#define HAL_MT_KG_PHY_REG_AUTONEG_STS_AN_COMPLETE_OFFSET   0x00000005
#define HAL_MT_KG_PHY_REG_AUTONEG_STS_AN_COMPLETE_BITWIDTH 0x00000001
#define HAL_MT_KG_PHY_REG_AUTONEG_STS_AN_COMPLETE_MASK     0x00000020

/* ------------------------------------
 * REG: AN base page bit 15:0
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_15_0 0x00008010
/* [4:0] - selector field */
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_15_0_SELECTOR_OFFSET   0x00000000
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_15_0_SELECTOR_BITWIDTH 0x00000005
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_15_0_SELECTOR_MASK     0x0000001F
/* [12:10] - pause ability */
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_15_0_PAUSE_OFFSET   0x0000000A
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_15_0_PAUSE_BITWIDTH 0x00000003
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_15_0_PAUSE_MASK     0x00001C00
/* [13:13] - remote fault ability */
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_15_0_RF_OFFSET   0x0000000D
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_15_0_RF_BITWIDTH 0x00000001
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_15_0_RF_MASK     0x00002000
/* [15:15] - next page */
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_15_0_NP_OFFSET   0x0000000F
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_15_0_NP_BITWIDTH 0x00000001
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_15_0_NP_MASK     0x00008000

/* ------------------------------------
 * REG: AN base page bit 31:16
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_31_16 0x00008011
/* [15:5] - speed ability field */
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_31_16_SPEED_ABILITY_1_OFFSET   0x00000005
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_31_16_SPEED_ABILITY_1_BITWIDTH 0x0000000B
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_31_16_SPEED_ABILITY_1_MASK     0x0000FFE0

/* ------------------------------------
 * REG: AN base page bit 47:32
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_47_32 0x00008012
/* [11:0] - speed ability field */
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_47_32_SPEED_ABILITY_2_OFFSET   0x00000000
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_47_32_SPEED_ABILITY_2_BITWIDTH 0x00000005
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_47_32_SPEED_ABILITY_2_MASK     0x0000001F
/* [15:12] - fec ability field */
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_47_32_FEC_ABILITY_OFFSET   0x0000000C
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_47_32_FEC_ABILITY_BITWIDTH 0x00000004
#define HAL_MT_KG_PHY_REG_AUTONEG_BP_47_32_FEC_ABILITY_MASK     0x0000F000

/* ------------------------------------
 * REG: AN lp base page bit 15:0
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_AUTONEG_LP_15_0 0x00008013
/* [12:10] - pause ability */
#define HAL_MT_KG_PHY_REG_AUTONEG_LP_15_0_PAUSE_OFFSET   0x0000000A
#define HAL_MT_KG_PHY_REG_AUTONEG_LP_15_0_PAUSE_BITWIDTH 0x00000003
#define HAL_MT_KG_PHY_REG_AUTONEG_LP_15_0_PAUSE_MASK     0x00001C00

/* ------------------------------------
 * REG: AN lp base page bit 31:16
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_AUTONEG_LP_31_16 0x00008014
/* [15:5] - speed ability field */
#define HAL_MT_KG_PHY_REG_AUTONEG_LP_31_16_SPEED_ABILITY_1_OFFSET   0x00000005
#define HAL_MT_KG_PHY_REG_AUTONEG_LP_31_16_SPEED_ABILITY_1_BITWIDTH 0x0000000B
#define HAL_MT_KG_PHY_REG_AUTONEG_LP_31_16_SPEED_ABILITY_1_MASK     0x0000FFE0

/* ------------------------------------
 * REG: AN lp base page bit 47:32
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_AUTONEG_LP_47_32 0x00008015
/* [11:0] - speed ability field */
#define HAL_MT_KG_PHY_REG_AUTONEG_LP_47_32_SPEED_ABILITY_2_OFFSET   0x00000000
#define HAL_MT_KG_PHY_REG_AUTONEG_LP_47_32_SPEED_ABILITY_2_BITWIDTH 0x00000005
#define HAL_MT_KG_PHY_REG_AUTONEG_LP_47_32_SPEED_ABILITY_2_MASK     0x0000001F
/* [15:12] - fec ability field */
#define HAL_MT_KG_PHY_REG_AUTONEG_LP_47_32_FEC_ABILITY_OFFSET   0x0000000C
#define HAL_MT_KG_PHY_REG_AUTONEG_LP_47_32_FEC_ABILITY_BITWIDTH 0x00000004
#define HAL_MT_KG_PHY_REG_AUTONEG_LP_47_32_FEC_ABILITY_MASK     0x0000F000

/* ------------------------------------
 * REG: AN consortium lp base page bit 15:0
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_AUTONEG_CON_LP_15_0 0x00008019
/* [12:10] - pause ability */
#define HAL_MT_KG_PHY_REG_AUTONEG_CON_LP_15_0_PAUSE_OFFSET   0x0000000A
#define HAL_MT_KG_PHY_REG_AUTONEG_CON_LP_15_0_PAUSE_BITWIDTH 0x00000003
#define HAL_MT_KG_PHY_REG_AUTONEG_CON_LP_15_0_PAUSE_MASK     0x00001C00

/* ------------------------------------
 * REG: AN consortium lp base page bit 31:16
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_AUTONEG_CON_LP_31_16 0x0000801A
/* [10:0] - consortium lp speed ability field1 */
#define HAL_MT_KG_PHY_REG_AUTONEG_CON_LP_31_16_SPEED_ABILITY_1_OFFSET   0x00000000
#define HAL_MT_KG_PHY_REG_AUTONEG_CON_LP_31_16_SPEED_ABILITY_1_BITWIDTH 0x0000000B
#define HAL_MT_KG_PHY_REG_AUTONEG_CON_LP_31_16_SPEED_ABILITY_1_MASK     0x000007FF

/* ------------------------------------
 * REG: AN consortium lp base page bit 47:32
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_AUTONEG_CON_LP_47_32 0x0000801B
/* [2:0] - consortium lp speed ability field2 */
#define HAL_MT_KG_PHY_REG_AUTONEG_CON_LP_47_32_SPEED_ABILITY_2_OFFSET   0x00000000
#define HAL_MT_KG_PHY_REG_AUTONEG_CON_LP_47_32_SPEED_ABILITY_2_BITWIDTH 0x00000003
#define HAL_MT_KG_PHY_REG_AUTONEG_CON_LP_47_32_SPEED_ABILITY_2_MASK     0x00000007

/* [11:8] - fec control fec ability field */
#define HAL_MT_KG_PHY_REG_AUTONEG_CON_LP_47_32_FEC_CONTROL_OFFSET   0x00000008
#define HAL_MT_KG_PHY_REG_AUTONEG_CON_LP_47_32_FEC_CONTROL_BITWIDTH 0x00000004
#define HAL_MT_KG_PHY_REG_AUTONEG_CON_LP_47_32_FEC_CONTROL_MASK     0x00000F00

/* ------------------------------------
 * REG: AN result reg1 bit 15:0
 * ------------------------------------*/
#define HAL_MT_KG_PHY_AN_RESULT_REG1 0x00008030
/* [3:1] - an_spec_1 */
#define HAL_MT_KG_PHY_AN_RESULT_REG1_AN_SPEC_1_OFFSET   0x00000001
#define HAL_MT_KG_PHY_AN_RESULT_REG1_AN_SPEC_1_BITWIDTH 0x00000003
#define HAL_MT_KG_PHY_AN_RESULT_REG1_AN_SPEC_1_MASK     0x0000000E
/* [4:4] - base_r_fec_negotiated */
#define HAL_MT_KG_PHY_AN_RESULT_REG1_FEC_ENA_OFFSET   0x00000004
#define HAL_MT_KG_PHY_AN_RESULT_REG1_FEC_ENA_BITWIDTH 0x00000001
#define HAL_MT_KG_PHY_AN_RESULT_REG1_FEC_ENA_MASK     0x00000010
/* [6:5] - an_spec_2 */
#define HAL_MT_KG_PHY_AN_RESULT_REG1_AN_SPEC_2_OFFSET   0x00000005
#define HAL_MT_KG_PHY_AN_RESULT_REG1_AN_SPEC_2_BITWIDTH 0x00000002
#define HAL_MT_KG_PHY_AN_RESULT_REG1_AN_SPEC_2_MASK     0x00000060
/* [7:7] - rs_fec_negotiated */
#define HAL_MT_KG_PHY_AN_RESULT_REG1_AN_RS_FEC_ENA_OFFSET   0x00000007
#define HAL_MT_KG_PHY_AN_RESULT_REG1_AN_RS_FEC_ENA_BITWIDTH 0x00000001
#define HAL_MT_KG_PHY_AN_RESULT_REG1_AN_RS_FEC_ENA_MASK     0x00000080
/* [15:8] - an_spec_3 */
#define HAL_MT_KG_PHY_AN_RESULT_REG1_AN_SPEC_3_OFFSET   0x00000008
#define HAL_MT_KG_PHY_AN_RESULT_REG1_AN_SPEC_3_BITWIDTH 0x00000008
#define HAL_MT_KG_PHY_AN_RESULT_REG1_AN_SPEC_3_MASK     0x0000FF00

/* ------------------------------------
 * REG: AN result reg2 bit 15:0
 * ------------------------------------*/
#define HAL_MT_KG_PHY_AN_RESULT_REG2 0x00008031
/* [2:0] - an_spec_4 */
#define HAL_MT_KG_PHY_AN_RESULT_REG2_AN_SPEC_4_OFFSET   0x00000000
#define HAL_MT_KG_PHY_AN_RESULT_REG2_AN_SPEC_4_BITWIDTH 0x00000003
#define HAL_MT_KG_PHY_AN_RESULT_REG2_AN_SPEC_4_MASK     0x00000007

/* ------------------------------------
 * REG: AN result reg3 bit 15:0
 * ------------------------------------*/
#define HAL_MT_KG_PHY_AN_RESULT_REG3 0x00008040
/* [14:10] - an_econ_spec */
#define HAL_MT_KG_PHY_AN_RESULT_REG3_AN_CON_OFFSET   0x0000000A
#define HAL_MT_KG_PHY_AN_RESULT_REG3_AN_CON_BITWIDTH 0x00000005
#define HAL_MT_KG_PHY_AN_RESULT_REG3_AN_CON_MASK     0x00007C00

/* ------------------------------------
 * REG: AN 25G/50G consortium next page bit 15:0
 * ------------------------------------*/
#define HAL_MT_KG_PHY_AN_CONSORTIUM_NP_14_0 0x000080F3
/* [12:10] - pause ability */
#define HAL_MT_KG_PHY_AN_CONSORTIUM_NP_14_0_PAUSE_OFFSET   0x0000000A
#define HAL_MT_KG_PHY_AN_CONSORTIUM_NP_14_0_PAUSE_BITWIDTH 0x00000003
#define HAL_MT_KG_PHY_AN_CONSORTIUM_NP_14_0_PAUSE_MASK     0x00001C00

/* ------------------------------------
 * REG: AN 25G/50G consortium next page bit 31:16
 * ------------------------------------*/
#define HAL_MT_KG_PHY_AN_CONSORTIUM_NP_31_16 0x000080F4
/* [10:0] - speed ability field */
#define HAL_MT_KG_PHY_AN_CONSORTIUM_NP_31_16_ABILITY_OFFSET   0x00000000
#define HAL_MT_KG_PHY_AN_CONSORTIUM_NP_31_16_ABILITY_BITWIDTH 0x0000000B
#define HAL_MT_KG_PHY_AN_CONSORTIUM_NP_31_16_ABILITY_MASK     0x000007FF

/* ------------------------------------
 * REG: AN 25G/50G/400G consortium next page bit 47:32
 * ------------------------------------*/
#define HAL_MT_KG_PHY_AN_CONSORTIUM_NP_47_32 0x000080F5
/* [2:0] - 400G R8 speed ability field */
#define HAL_MT_KG_PHY_AN_CONSORTIUM_NP_47_32_ABILITY_OFFSET   0x00000000
#define HAL_MT_KG_PHY_AN_CONSORTIUM_NP_47_32_ABILITY_BITWIDTH 0x00000003
#define HAL_MT_KG_PHY_AN_CONSORTIUM_NP_47_32_ABILITY_MASK     0x00000007

/* [11:8] - fec control ability field */
#define HAL_MT_KG_PHY_AN_CONSORTIUM_NP_47_32_FEC_CONTROL_OFFSET   0x00000008
#define HAL_MT_KG_PHY_AN_CONSORTIUM_NP_47_32_FEC_CONTROL_BITWIDTH 0x00000004
#define HAL_MT_KG_PHY_AN_CONSORTIUM_NP_47_32_FEC_CONTROL_MASK     0x00000F00

#define HAL_MT_KG_PHY_REG_AUTONEG_NP1_15_0       0x000080F0
#define HAL_MT_KG_PHY_REG_AUTONEG_NP1_15_0_DATA  0xA005
#define HAL_MT_KG_PHY_REG_AUTONEG_NP1_31_16      0x000080F1
#define HAL_MT_KG_PHY_REG_AUTONEG_NP1_31_16_DATA 0x0353
#define HAL_MT_KG_PHY_REG_AUTONEG_NP1_47_32      0x000080F2
#define HAL_MT_KG_PHY_REG_AUTONEG_NP1_47_32_DATA 0x04DF

#define HAL_MT_KG_PHY_REG_AUTONEG_NP2_15_0       0x000080F3
#define HAL_MT_KG_PHY_REG_AUTONEG_NP2_15_0_DATA  0x0203
#define HAL_MT_KG_PHY_REG_AUTONEG_NP2_31_16      0x000080F4
#define HAL_MT_KG_PHY_REG_AUTONEG_NP2_31_16_DATA 0x0000
#define HAL_MT_KG_PHY_REG_AUTONEG_NP2_47_32      0x000080F5
#define HAL_MT_KG_PHY_REG_AUTONEG_NP2_47_32_DATA 0x0000

/* ------------------------------------
 * REG: LT control regsiter
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_LT_CONTROL 0x00008100
/* [1:1] - lt restart */
#define HAL_MT_KG_PHY_REG_LT_CONTROL_LT_RESTART_OFFSET   0x00000000
#define HAL_MT_KG_PHY_REG_LT_CONTROL_LT_RESTART_BITWIDTH 0x00000001
#define HAL_MT_KG_PHY_REG_LT_CONTROL_LT_RESTART_MASK     0x00000001
/* [1:1] - lt enable */
#define HAL_MT_KG_PHY_REG_LT_CONTROL_LT_ENABLE_OFFSET   0x00000001
#define HAL_MT_KG_PHY_REG_LT_CONTROL_LT_ENABLE_BITWIDTH 0x00000001
#define HAL_MT_KG_PHY_REG_LT_CONTROL_LT_ENABLE_MASK     0x00000002

/* ------------------------------------
 * REG: LT STATE regsiter
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_LT_STATE 0x00008104
/* [7:7] -  Training failure */
#define HAL_MT_KG_PHY_REG_LT_STATE_TRAINING_FAIL_OFFSET   0x00000007
#define HAL_MT_KG_PHY_REG_LT_STATE_TRAINING_FAIL_BITWIDTH 0x00000001
#define HAL_MT_KG_PHY_REG_LT_STATE_TRAINING_FAIL_MASK     0x00000080

/* ------------------------------------
 * REG: LT COEFFI regsiter
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_LT_COEFFI 0x00008118
/* [7:7] -  Training failure */
#define HAL_MT_KG_PHY_REG_LT_COEFFI_OFFSET   0x00000000
#define HAL_MT_KG_PHY_REG_LT_COEFFI_BITWIDTH 0x00000010
#define HAL_MT_KG_PHY_REG_LT_COEFFI_MASK     0x000000FF

/* ------------------------------------
 * REG: LT statue regsiter
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_LT_DONE 0x00008201
/* [2:2] - lt done */
#define HAL_MT_KG_PHY_REG_LT_DONE_LT_DONE_OFFSET   0x00000002
#define HAL_MT_KG_PHY_REG_LT_DONE_LT_DONE_BITWIDTH 0x00000001
#define HAL_MT_KG_PHY_REG_LT_DONE_LT_DONE_MASK     0x00000004

/* ------------------------------------
 * REG: AN mode regsiter
 * ------------------------------------*/
#define HAL_MT_KG_PHY_AN_ARG_PCS_LINK_STA_REG1 0x00008209
#define HAL_MT_KG_PHY_AN_ARG_PCS_LINK_STA_REG2 0x0000820A

#define HAL_MT_KG_PHY_AN_ARG_REG1 0x00008300
/* [15:12] - an_econ_spec */
#define HAL_MT_KG_PHY_AN_ARG_REG1_IEEE_MODE_S_OFFSET   0x0000000C
#define HAL_MT_KG_PHY_AN_ARG_REG1_IEEE_MODE_S_BITWIDTH 0x00000001
#define HAL_MT_KG_PHY_AN_ARG_REG1_IEEE_MODE_S_MASK     0x00001000

#define HAL_MT_KG_PHY_AN_ARG_REG2 0x00008301
/* [3:0] - anlt_state_readback */
#define HAL_MT_KG_PHY_AN_ARG_REG2_ANLT_STATE_READBACK_OFFSET   0x00000000
#define HAL_MT_KG_PHY_AN_ARG_REG2_ANLT_STATE_READBACK_BITWIDTH 0x00000004
#define HAL_MT_KG_PHY_AN_ARG_REG2_ANLT_STATE_READBACK_MASK     0x0000000F

/* [10:10] - hcd resolved */
#define HAL_MT_KG_PHY_AN_ARG_REG2_HCD_RESOLVED_OFFSET   0x0000000A
#define HAL_MT_KG_PHY_AN_ARG_REG2_HCD_RESOLVED_BITWIDTH 0x00000001
#define HAL_MT_KG_PHY_AN_ARG_REG2_HCD_RESOLVED_MASK     0x00000400

/* ------------------------------------
 * REG: TOP_LOOPBACK_FIFO
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_TOP_LOOPBACK_FIFO 0x0009803
/* [10:10 - pam4 enable] */
#define HAL_MT_KG_PHY_REG_TOP_LOOPBACK_FIFO_PAM4_EN_OFFSET   0x0000000A
#define HAL_MT_KG_PHY_REG_TOP_LOOPBACK_FIFO_PAM4_EN_BITWIDTH 0x00000001
#define HAL_MT_KG_PHY_REG_TOP_LOOPBACK_FIFO_PAM4_EN_MASK     0x00000400
/* [12:11 - anlt clk&data enable] */
#define HAL_MT_KG_PHY_REG_TOP_LOOPBACK_FIFO_ANLT_CLK_DATA_EN_OFFSET   0x0000000B
#define HAL_MT_KG_PHY_REG_TOP_LOOPBACK_FIFO_ANLT_CLK_DATA_EN_BITWIDTH 0x00000002
#define HAL_MT_KG_PHY_REG_TOP_LOOPBACK_FIFO_ANLT_CLK_DATA_EN_MASK     0x00001800

/* ------------------------------------
 * REG: FW_CTLE_DONE
 * ------------------------------------*/
#define HAL_MT_KG_PHY_REG_FW_CTLE_DONE 0x0009811
/* [11:11 - pll lock status] */
#define HAL_MT_KG_PHY_REG_FW_PLL_LOCK_STA_OFFSET   0x0000000B
#define HAL_MT_KG_PHY_REG_FW_PLL_LOCK_STA_BITWIDTH 0x00000001
#define HAL_MT_KG_PHY_REG_FW_PLL_LOCK_STA_MASK     0x00000800

/* [14:12 - ctle done tuning state] */
#define HAL_MT_KG_PHY_REG_FW_CTLE_DONE_TUNING_STA_OFFSET   0x0000000C
#define HAL_MT_KG_PHY_REG_FW_CTLE_DONE_TUNING_STA_BITWIDTH 0x00000003
#define HAL_MT_KG_PHY_REG_FW_CTLE_DONE_TUNING_STA_MASK     0x00007000

#define HAL_MT_KG_PHY_ETH_SLICE_TO_PLANE(unit, slice) \
    (slice / HAL_MT_KG_PHY_ETH_MAX_LANES_PER_PLANE)

#define HAL_MT_KG_PHY_ETH_SLICE_TO_MACRO(unit, slice)                                              \
    (((slice % HAL_MT_KG_PHY_ETH_MAX_LANES_PER_PLANE) < HAL_MT_KG_PHY_B_MAX_LANES_PER_MACRO) ?     \
         0 :                                                                                       \
         (((slice % HAL_MT_KG_PHY_ETH_MAX_LANES_PER_PLANE) <                                       \
           (HAL_MT_KG_PHY_B_MAX_LANES_PER_MACRO + HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO)) ?          \
              1 :                                                                                  \
              (((slice % HAL_MT_KG_PHY_ETH_MAX_LANES_PER_PLANE) <                                  \
                (HAL_MT_KG_PHY_B_MAX_LANES_PER_MACRO + HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO * 2)) ? \
                   2 :                                                                             \
                   (((slice % HAL_MT_KG_PHY_ETH_MAX_LANES_PER_PLANE) <                             \
                     (HAL_MT_KG_PHY_B_MAX_LANES_PER_MACRO +                                        \
                      HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO * 3)) ?                                  \
                        3 :                                                                        \
                        (((slice % HAL_MT_KG_PHY_ETH_MAX_LANES_PER_PLANE) <                        \
                          (HAL_MT_KG_PHY_B_MAX_LANES_PER_MACRO +                                   \
                           HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO * 4)) ?                             \
                             4 :                                                                   \
                             5)))))

#define HAL_MT_KG_PHY_ETH_SLICE_TO_MACRO_LANE(unit, slice)         \
    ((HAL_MT_KG_PHY_ETH_SLICE_TO_MACRO(unit, slice) < 1) ?         \
         (slice % HAL_MT_KG_PHY_ETH_MAX_LANES_PER_PLANE) :         \
         ((HAL_MT_KG_PHY_ETH_SLICE_TO_MACRO(unit, slice) <= 4) ?   \
              ((((slice % HAL_MT_KG_PHY_ETH_MAX_LANES_PER_PLANE) - \
                 HAL_MT_KG_PHY_B_MAX_LANES_PER_MACRO) %            \
                HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO)) :            \
              ((slice % HAL_MT_KG_PHY_ETH_MAX_LANES_PER_PLANE) -   \
               HAL_MT_KG_PHY_B_MAX_LANES_PER_MACRO - HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO * 4)))

#define HAL_MT_KG_PHY_D2D_SLICE_TO_PLANE(unit, slice) \
    (slice / HAL_MT_KG_PHY_D2D_MAX_MACRO_PER_PLANE)

#define HAL_MT_KG_PHY_D2D_SLICE_TO_MACRO(unit, slice) \
    (slice % HAL_MT_KG_PHY_D2D_MAX_MACRO_PER_PLANE)

#define HAL_MT_KG_PHY_D2D_PORT_TO_PLANE(unit, port) \
    ((port * HAL_MT_KG_PHY_D2D_PORT_LANE_NUM) / HAL_MT_KG_PHY_D2D_MAX_LANES_PER_PLANE)

#define HAL_MT_KG_PHY_D2D_PORT_TO_MACRO(unit, port) (port / 2)

#define HAL_MT_KG_ETH_MACRO_ST_LANE_ID(macro)                                                  \
    ((macro / HAL_MT_KG_PHY_ETH_MAX_MACRO_PER_PLANE) * HAL_MT_KG_PHY_ETH_MAX_LANES_PER_PLANE + \
     ((macro % HAL_MT_KG_PHY_ETH_MAX_MACRO_PER_PLANE == 0) ?                                   \
          0 :                                                                                  \
          (((macro % HAL_MT_KG_PHY_ETH_MAX_MACRO_PER_PLANE <= 4) ?                             \
                (HAL_MT_KG_PHY_B_MAX_LANES_PER_MACRO +                                         \
                 (macro % HAL_MT_KG_PHY_ETH_MAX_MACRO_PER_PLANE - 1) *                         \
                     HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO) :                                    \
                (HAL_MT_KG_PHY_B_MAX_LANES_PER_MACRO +                                         \
                 (HAL_MT_KG_PHY_A_MAX_MACRO_PER_PLANE * HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO))))))

#define HAL_MT_KG_PORT_TO_ST_LANE_ID(unit, port)                                                 \
    ((HAL_CL_PORT_TO_PLANE(unit, port) * HAL_MT_KG_PHY_ETH_MAX_LANES_PER_PLANE) +                \
     ((HAL_CL_PORT_TO_MAC_MACRO(unit, port) == 0) ?                                              \
          0 :                                                                                    \
          ((HAL_CL_PORT_TO_MAC_MACRO(unit, port) <= 4) ?                                         \
               (HAL_MT_KG_PHY_B_MAX_LANES_PER_MACRO +                                            \
                ((HAL_CL_PORT_TO_MAC_MACRO(unit, port) - 1) *                                    \
                 HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO)) :                                         \
               (HAL_MT_KG_PHY_B_MAX_LANES_PER_MACRO +                                            \
                (HAL_MT_KG_PHY_A_MAX_MACRO_PER_PLANE * HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO)))) + \
     HAL_CL_PORT_TO_MACRO_PORT(unit, port))

#define HAL_CHECK_KG_PHY_ERROR(__cr_error__)                                                  \
    do {                                                                                      \
        clx_error_no_t __rc = CLX_E_OTHERS;                                                   \
        switch (__cr_error__) {                                                               \
            case HAL_KG_PMA_SUCCESS:                                                          \
                __rc = CLX_E_OK;                                                              \
                break;                                                                        \
            case HAL_KG_PMA_FAIL:                                                             \
                __rc = CLX_E_OTHERS;                                                          \
                break;                                                                        \
            case HAL_KG_PMA_PHY_FW_DOWNLOAD_FAIL:                                             \
            case HAL_KG_PMA_FW_TIMEOUT:                                                       \
            case HAL_KG_PMA_MUTEX_TIMEOUT:                                                    \
            case HAL_KG_PMA_TIMEOUT:                                                          \
                __rc = CLX_E_TIMEOUT;                                                         \
                break;                                                                        \
            case HAL_KG_PMA_NOT_READY:                                                        \
                __rc = CLX_E_ENTRY_IN_USE;                                                    \
                break;                                                                        \
            case HAL_KG_PMA_OUT_OF_MEMORY:                                                    \
                __rc = CLX_E_NO_MEMORY;                                                       \
                break;                                                                        \
            case HAL_KG_PMA_HAL_NOT_FOUND:                                                    \
                __rc = CLX_E_ENTRY_NOT_FOUND;                                                 \
                break;                                                                        \
            case HAL_KG_PMA_INVALID_ARGS:                                                     \
                __rc = CLX_E_BAD_PARAMETER;                                                   \
                break;                                                                        \
            case HAL_KG_PMA_UNSUPPORTED:                                                      \
                __rc = CLX_E_NOT_SUPPORT;                                                     \
                break;                                                                        \
            default:                                                                          \
                __rc = CLX_E_OTHERS;                                                          \
                break;                                                                        \
        }                                                                                     \
        if (__cr_error__ != HAL_KG_PMA_OK) {                                                  \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN, #__cr_error__ "=%d\n", __cr_error__); \
            return __rc;                                                                      \
        }                                                                                     \
    } while (0)

#define DECIMAL_TO_COMPLEMENT(decimal) \
    ((decimal) >= 0 ? (uint8_t)(decimal) : (uint8_t)(~((uint8_t)(-(decimal))) + 1))

#define CASE_ENUM_RETURN_STRING_BASIC(enum, string) \
    case enum:                                      \
        return string
/* DATA TYPE DECLARATIONS
 */
#define HAL_MT_KG_PHY_TX_COEFFICIENT_C0_MAX  (63)
#define HAL_MT_KG_PHY_TX_COEFFICIENT_C0_MIN  (0)
#define HAL_MT_KG_PHY_TX_COEFFICIENT_C1_MAX  (0)
#define HAL_MT_KG_PHY_TX_COEFFICIENT_C1_MIN  (-63)
#define HAL_MT_KG_PHY_TX_COEFFICIENT_C2_MAX  (63)
#define HAL_MT_KG_PHY_TX_COEFFICIENT_C2_MIN  (0)
#define HAL_MT_KG_PHY_TX_COEFFICIENT_CN1_MAX (0)
#define HAL_MT_KG_PHY_TX_COEFFICIENT_CN1_MIN (-63)
#define HAL_MT_KG_PHY_TX_COEFFICIENT_CN2_MAX (63)
#define HAL_MT_KG_PHY_TX_COEFFICIENT_CN2_MIN (0)
#define HAL_MT_KG_PHY_TX_COEFFICIENT_TOTAL   (63)

#define FW_CMD_LOG_SILENT (0x0F00 << 16)
#define CR_LFLAG_PLL_CAL  (1 << 31)
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
typedef enum hal_mt_kg_phy_type_e {
    KG_PHY_TYPE_ETH_2T = 0,
    KG_PHY_TYPE_D2D_2T,
    KG_PHY_TYPE_ETH_4T,
    KG_PHY_TYPE_D2D_4T,
    KG_PHY_TYPE_NUM,
} hal_mt_kg_phy_type_t;

typedef enum hal_mt_kg_phy_route_e {
    ROUTE_UNKNOWN,
    ROUTE_UNINITIALIZED,
    ROUTE_LEFT_TO_RIGHT,
    ROUTE_LEFT_TO_TOP,
    ROUTE_LEFT_TO_BOTTOM,
    ROUTE_RIGHT_TO_LEFT,
    ROUTE_RIGHT_TO_TOP,
    ROUTE_RIGHT_TO_BOTTOM,
    ROUTE_TOP_TO_LEFT,
    ROUTE_TOP_TO_RIGHT,
    ROUTE_TOP_TO_BOTTOM,
    ROUTE_BOTTOM_TO_LEFT,
    ROUTE_BOTTOM_TO_RIGHT,
    ROUTE_BOTTOM_TO_TOP,
} hal_mt_kg_phy_route_t;

typedef struct hal_mt_kg_phy_refclk_route_s {
    hal_mt_kg_phy_route_t route[3];
    uint32 en1to2_1;
    uint32 en1to2_2;
    uint32 en1to2_3;
    uint32 en1to2_4;
    uint32 en2to1_1;
    uint32 en2to1_2;
    uint32 en2to1_3;
    uint32 en2to1_4;
} hal_mt_kg_phy_refclk_route_t;

#define REFCLK_ROUTE_TO_RAW(route, raw)                                                     \
    do {                                                                                    \
        raw = (route)->en1to2_1 << 28 | (route)->en1to2_2 << 24 | (route)->en1to2_3 << 20 | \
            (route)->en1to2_4 << 16 | (route)->en2to1_1 << 12 | (route)->en2to1_2 << 8 |    \
            (route)->en2to1_3 << 4 | (route)->en2to1_4 << 0;                                \
    } while (0)
typedef enum hal_mt_kg_phy_speed_e {
    KG_PHY_SPEED_CONFIG_0G = 0, // AN
    KG_PHY_SPEED_CONFIG_1P25G = 1250000,
    KG_PHY_SPEED_CONFIG_1G = KG_PHY_SPEED_CONFIG_1P25G,
    KG_PHY_SPEED_CONFIG_3G = 3125000,
    KG_PHY_SPEED_CONFIG_5G = 5000000,
    KG_PHY_SPEED_CONFIG_8G = 8000000,
    KG_PHY_SPEED_CONFIG_10G = 10312500,
    KG_PHY_SPEED_CONFIG_16G = 16000000,
    KG_PHY_SPEED_CONFIG_20G = 20625000,
    KG_PHY_SPEED_CONFIG_25G = 25781250,
    KG_PHY_SPEED_CONFIG_32G = 32000000,
    KG_PHY_SPEED_CONFIG_50G = 56250000,
    KG_PHY_SPEED_CONFIG_51G = 56250000,
    KG_PHY_SPEED_CONFIG_53G = 53125000,
    KG_PHY_SPEED_CONFIG_56G = 56250000,
} hal_mt_kg_phy_speed_t;

typedef struct hal_mt_kg_phy_state_s {
    uint32 signal_detect;
    uint32 lane_ready; // cdr lock
    uint32 adapt_done;
    uint32 tuning_state;
    uint32 pll_lock;
} hal_mt_kg_phy_state_t;

typedef struct hal_mt_kg_phy_slice_ctx_s {
    uint32 unit;
    uint32 dev_type;
    uint32 offset;
    uint32 slice_id;
    uint32 lane_id;
    hal_mt_kg_pma_slice_t *slice;
} hal_mt_kg_phy_slice_ctx_t;

typedef struct hal_mt_kg_phy_device_desc_s {
    hal_mt_kg_pma_device_type_t device_type;
    hal_mt_kg_pma_device_t *sdk_dev[HAL_MT_KG_PHY_ETH_MAX_LANES_PER_CHIP +
                                    HAL_MT_KG_PHY_D2D_MAX_MACRO_PER_CHIP]; // sdk device
    hal_mt_kg_pma_slice_t
        *slice_list[HAL_MT_KG_PHY_ETH_MAX_LANES_PER_CHIP + HAL_MT_KG_PHY_D2D_MAX_MACRO_PER_CHIP];
    // slice_ctx_t       *slice_ctx[HAL_MT_KG_PHY_ETH_MAX_LANES_PER_CHIP];
    uint32 device_cnt;
    uint32 slice_cnt;
    uint32 lane_per_slice;
    char *fw_path;
    uint32 fw_buff_sz;
    uint32 inited;
} hal_mt_kg_phy_device_desc_t;

typedef enum hal_mt_kg_phy_lane_mode_e {
    KG_LMODE_OFF = 0,
    KG_LMODE_NRZ = 1,
    KG_LMODE_PAM4 = 2,
    KG_LMODE_AN = 3,
    KG_LMODE_PAM3 = 4,
    KG_LMODE_DISABLE = 0xff
} hal_mt_kg_phy_lane_mode_t;

typedef struct hal_mt_kg_phy_port_desc_s {
    uint32 unit; // Chip id
    hal_port_map_t data;
    hal_phy_prbs_pattern_type_t prbs_pattern;
    hal_mt_kg_phy_lane_mode_t lane_mode; // just software recorded
    uint32 tx_flag;
    uint32 rx_flag;
    uint32 lane_bitmap[HAL_MT_KG_PHY_ETH_MAX_MACRO_PER_CHIP / sizeof(uint32)];
    hal_mt_kg_phy_device_desc_t *dev; // chip dev descriptor
    /*** get from hal_mt_kg_phy_cfg_t
    hal_phy_pmd_intf_type_t pmd_intf_type;
    BOOL_T cpi_port;
    UI32_T lane_speed;
    */
} hal_mt_kg_phy_port_desc_t;

typedef struct hal_mt_kg_phy_cfg_s {
    hal_mt_kg_phy_port_desc_t port_desc[CLX_PORT_NUM];
    hal_mt_kg_phy_speed_t lane_speed[HAL_MT_KG_PHY_ETH_MAX_MACRO_PER_CHIP]
                                    [HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO];
    hal_phy_pmd_intf_type_t pmd_intf_type[CLX_PORT_NUM];
    hal_phy_fec_type_t phy_fec[CLX_PORT_NUM];                         /* fec mode */
    uint32 consortium_next_page[HAL_MT_KG_PHY_ETH_MAX_MACRO_PER_CHIP]
                               [HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO]; /* an np */
    uint32 an_consortium_ability[HAL_MT_KG_PHY_ETH_MAX_MACRO_PER_CHIP]
                                [HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO];
    /* an consortium ability
       bit21: 50GBASE-KR2,
       bit22: 50GBASE-CR2,
       bit23: 400GBASE-CR8,
       bit24: 25GBASE-KR,
       bit25: 25GBASE-CR,
       bit8:  support Clause 91 FEC,
       bit9:  support Clause 74 FEC,
       bit10: request Clause 91 FEC,
       bit11: request Clause 74 FEC*/
    uint32 _laneswap_mask[HAL_MT_KG_PHY_ETH_MAX_MACRO_PER_CHIP]; /* laneswap mask */
    uint32 lane_swap[HAL_MT_KG_PHY_ETH_MAX_MACRO_PER_CHIP][HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO];
    uint32 rx_lane_swap[HAL_MT_KG_PHY_ETH_MAX_MACRO_PER_CHIP][HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO];
    /* tx lane swap */
    uint32 tx_polarity[HAL_MT_KG_PHY_ETH_MAX_MACRO_PER_CHIP][HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO];
    /* phy tx polarity */
    uint32 rx_polarity[HAL_MT_KG_PHY_ETH_MAX_MACRO_PER_CHIP][HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO];
    /* phy rx polarity */
    uint32 macro_init_flag[HAL_MT_KG_PHY_ETH_MAX_MACRO_PER_CHIP];
    hal_phy_tx_coef_t phy_txfir[HAL_MT_KG_PHY_ETH_MAX_MACRO_PER_CHIP]
                               [HAL_MT_KG_PHY_A_MAX_LANES_PER_MACRO];
    /* tx-coef */
    uint32 _map_serdes_lane[CLX_PORT_NUM];            /* map hw_lane */
    hal_phy_anlt_type_t port_anlt_mode[CLX_PORT_NUM]; /* port anlt mode */
    uint32 phy_tx_signal[CLX_PORT_NUM];
} hal_mt_kg_phy_cfg_t;

typedef enum hal_mt_kg_phy_fw_rx_control_e {
    FW_RX_CONTROL_IDLE = 0,
    FW_RX_CONTROL_NORMAL = 1,
} hal_mt_kg_phy_fw_rx_control_t;

typedef enum hal_mt_kg_phy_tuning_state_e {
    TUNING_STATE_RUNNING = 1,
    TUNING_STATE_DONE = 3,
    TUNING_STATE_FAILED = 4,
    TUNING_STATE_LAST,
} hal_mt_kg_phy_tuning_state_t;

typedef struct hal_mt_kg_phy_dump_s {
    uint32 unit; // Chip id
    uint32 port_id;
    uint32 lane_id;
    uint32 fw_status;
    uint32 rx_state;
    hal_mt_kg_pma_lane_mode_t lane_mode;
    uint32 data_rate;
    hal_mt_kg_pma_lane_mode_t fw_lane_mode;
    uint32 an_lt_mode;
    int32 tx_taps[7];
    hal_mt_kg_phy_state_t phy_state;
    int32 vco_tx_cap;
    int32 vco_rx_cap;
    int32 rx_dac;
    int32 eyes[3];
    uint32 ctle_val[2];
    uint32 agcgain[2];
    int32 atten_en;
    int32 atten_agcgain;
    int32 atten_val;
    uint32 tia1_bias;
    uint32 of;
    uint32 hf;
    double dfe_taps[3];
    int32 f13_val;
    int32 delta_val;
    uint32 edge[4];
    int32 skef_en;
    int32 skef_val;
    int32 skef_addcap;
    int32 skef_gain;
    int32 ffe_taps[8];
    int32 ppm;
    hal_mt_kg_pma_lane_tx_state_t tx_state;
    hal_mt_kg_pma_loopback_mode_t loopback_mode;
    int32 tx_polarity;
    int32 rx_polarity;
    int32 tx_gray_code;
    int32 rx_gray_code;
    int32 tx_precoder;
    int32 rx_precoder;
    int32 tx_msb;
    int32 rx_msb;
    hal_mt_kg_pma_lane_coupling_t input_mode;
    int32 tx_prbs_enable;
    hal_mt_kg_pma_prbs_pattern_t tx_pattern;
    int32 rx_prbs_enable;
    hal_mt_kg_pma_prbs_pattern_t rx_pattern;
    hal_mt_kg_phy_tuning_state_t tuning_state;
} hal_mt_kg_phy_dump_t;

typedef struct hal_mt_kg_phy_lane_cfg_s {
    uint32 unit; // Chip id
    uint32 port_id;
    hal_mt_kg_pma_lane_mode_t lane_mode;
    hal_mt_kg_phy_speed_t lane_speed;
    uint32 flag;
    int32 next_pages[12];
    uint32 consort_ability;
    int32 tx_polarity;
    int32 rx_polarity;
} hal_mt_kg_phy_lane_cfg_t;

clx_error_no_t
hal_mt_kg_phy_slice_get(const uint32 unit,
                        const hal_mt_kg_pma_device_type_t dev_type,
                        const uint32 port_id,
                        uint32 lane_idx,
                        uint32 *slice_idx,
                        hal_mt_kg_pma_slice_t **slice);
clx_error_no_t
hal_mt_kg_phy_tx_rx_en_set(const uint32 unit, const uint32 port_id, const uint32 en);

/**
 * @brief Set MDIO register.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port_id     - Port ID.
 * @param [in]    phy_type    - PHY type.
 * @param [in]    dev_type    - Device type.
 * @param [in]    reg_addr    - Register address.
 * @param [in]    reg         - Register value.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_phy_mdio_reg_set(const uint32 unit,
                           const uint32 port_id,
                           const hal_phy_type_t phy_type,
                           const uint32 dev_type,
                           const uint32 reg_addr,
                           const uint32 reg);

/**
 * @brief Get MDIO register.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port_id     - Port ID.
 * @param [in]     phy_type    - PHY type.
 * @param [in]     dev_type    - Device type.
 * @param [in]     reg_addr    - Register address.
 * @param [out]    ptr_reg     - Register value.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_phy_mdio_reg_get(const uint32 unit,
                           const uint32 port_id,
                           const hal_phy_type_t phy_type,
                           const uint32 dev_type,
                           const uint32 reg_addr,
                           uint32 *ptr_reg);

/**
 * @brief Check PLL CAL DONE status.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port ID.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_phy_pll_calc_done_check(const uint32 unit, uint32 port);

/**
 * @brief Check PLL LOCK status.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port ID.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_phy_pll_lock_status_check(const uint32 unit, uint32 port);

/**
 * @brief Set ANLT admin state.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port_id        - Port ID.
 * @param [in]    admin_state    - Admin state.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_phy_anlt_admin_state_set(const uint32 unit,
                                   const uint32 port_id,
                                   const hal_phy_admin_state_type_t admin_state);
#endif