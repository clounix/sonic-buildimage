/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  osal_dma.h
 * PURPOSE:
 *  1. Provide DRV DMA buffer management initialization and de-initialization
 *     function APIs.
 *  2. Provide DRV DMA buffer allocation and free APIs.
 *
 * NOTES:
 *
 */

#ifndef OSAL_DMA_H
#define OSAL_DMA_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define OSAL_DMA_MEM_SIZE     (4 * 1024 * 1024)
#define OSAL_RX_POOL_BUF_SIZE CLX_PKT_DMA_FRAG_SIZE

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef struct osal_dma_mpool_config_s {
    uint32 alloc_size; /* Must be 4 byte aligned*/
    uint32 entry_cnt;
    uint32 init_alloc;
} osal_dma_mpool_cfg_t;

clx_error_no_t
osal_dma_pkt_free(const void *ptr_dma_mem);

clx_error_no_t
osal_dma_tx_pkt_pool_cfg(uint32 unit);

clx_error_no_t
osal_dma_rx_pkt_pool_cfg(uint32 unit);

void *
osal_dma_tx_pkt_alloc(const uint32 size);

void *
osal_dma_rx_pkt_alloc(void);

clx_error_no_t
osal_dma_virt_to_phy_convert(void *ptr_virt_addr, clx_addr_t *ptr_phy_addr);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief Osal_dma_dma_mem_init() is responsible for DRV DMA memory management initialization.
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]    unit    - The unit number that would like to initialize.
 * @return        CLX_E_OK        - Successfully initialize DRV DMA resource.
 * @return        CLX_E_OTHERS    - Fail to complete DRV DMA resource initialization.
 */
clx_error_no_t
osal_dma_dma_mem_init(const uint32 unit);

/**
 * @brief Osal_dma_dma_mem_deinit() is responsible for DRV DMA memeory management de-initialization.
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]    unit    - The unit number that would like to de-initialize.
 * @return        CLX_E_OK        - Successfully de-initialize DRV DMA resource.
 * @return        CLX_E_OTHERS    - Fail to complete DRV DMA resource de-initialization.
 */
clx_error_no_t
osal_dma_dma_mem_deinit(const uint32 unit);

/**
 * @brief Osal_dma_alloc() is responsible for DRV DMA memory allocation.
 *
 * @param [in]    size    - The allocated DMA memory size. void pointer -- Successfully allocate
 *                          this size DRV DMA memory.
 * @return        NULL    - Fail to allocate DRV DMA memory.
 */
void *
osal_dma_alloc(const uint32 size);

/**
 * @brief Osal_dma_free() is responsible for DRV DMA memory free.
 *
 * @param [in]    ptr_dma_mem    - The DMA memory that would like to be freed.
 * @return        CLX_E_OK        - Successfully free DRV DMA memory.
 * @return        CLX_E_OTHERS    - Fail to free DRV DMA memory.
 */
clx_error_no_t
osal_dma_free(void *ptr_dma_mem);

clx_error_no_t
osal_dma_dma_usage_show(const uint32 unit);

/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */

#endif /* #ifndef OSAL_DMA_H */
