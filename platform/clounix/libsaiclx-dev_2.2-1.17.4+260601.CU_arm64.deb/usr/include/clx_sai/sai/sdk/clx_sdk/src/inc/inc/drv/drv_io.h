/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  drv_io.h
 * PURPOSE:
 *  1. Provide the IO channel access interface to chip Device Control Command(DRV).
 *  2. Define DRV IO channel related structures.
 *
 * NOTES:
 *
 */

#ifndef DRV_IO_H
#define DRV_IO_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <osal/osal.h>
#include <clx/clx_init.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */
#define DRV_MAX_DMA_MOVE_DATA_LEN (8 * 1024) /* 8KB */

typedef clx_error_no_t (*drv_io_init_t)(const uint32 unit);
typedef clx_error_no_t (*drv_io_deinit_t)(const uint32 unit);
typedef clx_error_no_t (*drv_io_intr_register_t)(const uint32 unit);
typedef clx_error_no_t (*drv_io_intr_deregister_t)(const uint32 unit);
typedef clx_error_no_t (*drv_io_indir_entry_write_t)(const uint32 unit,
                                                     const uint32 entry_len,
                                                     const uint32 entry_num,
                                                     const uint32 *ptr_data,
                                                     void *table_info);
typedef clx_error_no_t (*drv_io_indir_entry_read_t)(const uint32 unit,
                                                    const uint32 entry_len,
                                                    const uint32 entry_num,
                                                    uint32 *ptr_data,
                                                    void *table_info);
typedef clx_error_no_t (*drv_io_hash_entry_act_t)(const uint32 unit,
                                                  const uint32 entry_len,
                                                  const uint32 *ptr_data,
                                                  void *table_info);
typedef clx_error_no_t (*drv_io_indir_sram_entry_read_t)(const uint32 unit,
                                                         const uint32 entry_len,
                                                         const uint32 entry_num,
                                                         uint32 *ptr_data,
                                                         void *table_info);
typedef clx_error_no_t (*drv_io_indir_sram_entry_write_t)(const uint32 unit,
                                                          const uint32 entry_len,
                                                          const uint32 entry_num,
                                                          const uint32 *ptr_data,
                                                          void *table_info);
typedef clx_error_no_t (*drv_io_tcam_entry_move_t)(const uint32 unit, void *table_info);
typedef clx_error_no_t (*drv_io_device_id_read_t)(const uint32 unit);
typedef clx_error_no_t (*drv_io_chip_info_update_t)(const uint32 unit);
typedef clx_error_no_t (*drv_io_tcam_table_flush_t)(const uint32 unit, void *table_info);
typedef clx_error_no_t (*drv_io_tcam_entry_unload_t)(const uint32 unit, void *table_info);

typedef struct drv_io_s {
    drv_io_init_t drv_io_init;
    drv_io_deinit_t drv_io_deinit;
    drv_io_intr_register_t drv_io_intr_register;
    drv_io_intr_deregister_t drv_io_intr_deregister;
    drv_io_indir_entry_write_t drv_io_indir_entry_write;
    drv_io_indir_entry_read_t drv_io_indir_entry_read;
    drv_io_hash_entry_act_t drv_io_hash_entry_act;
    drv_io_indir_sram_entry_read_t drv_io_indir_sram_entry_read;
    drv_io_indir_sram_entry_write_t drv_io_indir_sram_entry_write;
    drv_io_tcam_entry_move_t drv_io_tcam_entry_move;
    drv_io_device_id_read_t drv_io_device_id_read;
    drv_io_chip_info_update_t drv_io_chip_info_update;
    drv_io_tcam_table_flush_t drv_io_tcam_table_flush;
    drv_io_tcam_entry_unload_t drv_io_tcam_entry_unload;
} drv_io_t;

typedef enum drv_io_err_code_e {
    DRV_IO_RSP_TIMEOUT = 0,
    DRV_IO_WR_SLAVE_ERROR,
    DRV_IO_RD_SLAVE_ERROR,
    DRV_IO_SNCK_REQ_DROP_ERROR,
    DRV_IO_SNCK_RSP_DROP_ERROR,
    DRV_IO_WR_ADDR_ERROR,
    DRV_IO_RD_ADDR_ERROR,
    DRV_IO_RSP_PROTOCOL_ERROR,
    DRV_IO_ERROR_LAST
} drv_io_err_code_t;

/* chip resource mode, same as hal_resource_mode_t */
typedef enum drv_io_resource_mode_e {
    DRV_IO_RESOURCE_NB_MODE_SINGLE = 0,
    DRV_IO_RESOURCE_NB_MODE_DOUBLE = 1,
    DRV_IO_RESOURCE_KG_MODE = 2,
    DRV_IO_RESOURCE_MODE_LAST,
} drv_io_resource_mode_t;

clx_error_no_t
drv_io_init(void);
clx_error_no_t
drv_io_deinit(void);
clx_error_no_t
drv_io_intr_register(const uint32 unit);
clx_error_no_t
drv_io_intr_deregister(const uint32 unit);
clx_error_no_t
drv_io_indir_entry_write(const uint32 unit,
                         const uint32 entry_len,
                         const uint32 entry_num,
                         const uint32 *ptr_data,
                         void *table_info);
clx_error_no_t
drv_io_indir_entry_read(const uint32 unit,
                        const uint32 entry_len,
                        const uint32 entry_num,
                        uint32 *ptr_data,
                        void *table_info);
clx_error_no_t
drv_io_hash_entry_act(const uint32 unit, const uint32 entry_len, uint32 *ptr_data, void *table_info);
clx_error_no_t
drv_io_indir_sram_entry_read(const uint32 unit,
                             const uint32 entry_len,
                             const uint32 entry_num,
                             uint32 *ptr_data,
                             void *table_info);
clx_error_no_t
drv_io_indir_sram_entry_write(const uint32 unit,
                              const uint32 entry_len,
                              const uint32 entry_num,
                              const uint32 *ptr_data,
                              void *table_info);
clx_error_no_t
drv_io_tcam_entry_move(const uint32 unit, void *table_info);

clx_error_no_t
drv_io_tcam_table_flush(const uint32 unit, void *table_info);
#endif /* END of DRV_IO_H*/
