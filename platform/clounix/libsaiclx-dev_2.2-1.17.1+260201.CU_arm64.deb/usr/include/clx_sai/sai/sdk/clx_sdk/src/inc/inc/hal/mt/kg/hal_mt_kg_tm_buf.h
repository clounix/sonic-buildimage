/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_tm_buf.h
 * PURPOSE:
 *      It provides hal traffic management module API.
 * NOTES:
 *
 *
 */

#ifndef HAL_MT_KG_TM_BUF_H
#define HAL_MT_KG_TM_BUF_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_tm.h>
#include <osal/osal.h>
#include <tob/tob_tbl.h>
#include <hal/hal.h>
#include <hal/hal_const_cmn.h>
#include <hal/mt/kg/hal_mt_kg_tm.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_KG_TM_CELL_SIZE                (232)
#define HAL_MT_KG_TM_PLANE_DROP_PORT_ID       (88)
#define HAL_MT_KG_TM_BUF_WRED_DELTA_DEFAULT   (32)
#define HAL_MT_KG_TM_BUF_WRED_PROBABILITY_MAX (100)
/* MACRO FUNCTION DECLARATIONS
 */
extern uint32 _hal_mt_kg_tm_buf_cfg_lossy_lossess_pool;

/* DATA TYPE DECLARATIONS
 */
typedef struct hal_io_wb_db_s hal_io_wb_db_t;

/*********************************************/
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief The function is used to init TM buf management HW & SW DB.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Other error.
 */
clx_error_no_t
hal_mt_kg_tm_buf_stat_rsrc_init(const uint32 unit);
clx_error_no_t
hal_mt_kg_tm_buf_rsrc_init(const uint32 unit);
clx_error_no_t
hal_mt_kg_tm_buf_cfg_init(const uint32 unit);
clx_error_no_t
hal_mt_kg_tm_buf_task_init(const uint32 unit);
clx_error_no_t
hal_mt_kg_tm_buf_rsrc_deinit(const uint32 unit);
clx_error_no_t
hal_mt_kg_tm_buf_stat_task_deinit(const uint32 unit);
clx_error_no_t
hal_mt_kg_tm_buf_port_dflt_set(const uint32 unit, const uint32 port);
clx_error_no_t
hal_mt_kg_tm_buf_stat_rsrc_deinit(const uint32 unit);
clx_error_no_t
hal_mt_kg_tm_buf_port_flush(const uint32 unit, const uint32 port, const uint32 enable);
clx_error_no_t
hal_mt_kg_tm_buf_usage_get(const uint32 unit,
                           const uint32 port,
                           const clx_tm_handler_t handler,
                           const clx_tm_buf_stat_type_t buf_usage_type,
                           uint32 *ptr_usage);
clx_error_no_t
hal_mt_kg_tm_buf_watermark_get(const uint32 unit,
                               const uint32 port,
                               const clx_tm_handler_t handler,
                               const clx_tm_buf_stat_type_t buf_watermark_type,
                               uint32 *ptr_watermark);
clx_error_no_t
hal_mt_kg_tm_buf_watermark_clear(const uint32 unit,
                                 const uint32 port,
                                 const clx_tm_handler_t handler,
                                 const clx_tm_buf_stat_type_t buf_watermark_type);
clx_error_no_t
hal_mt_kg_tm_buf_histogram_cfg_set(const uint32 unit, const clx_tm_histogram_cfg_t *ptr_config);
clx_error_no_t
hal_mt_kg_tm_buf_histogram_cfg_get(const uint32 unit, clx_tm_histogram_cfg_t *ptr_config);
clx_error_no_t
hal_mt_kg_tm_buf_histogram_cb_register(const uint32 unit,
                                       const uint32 port,
                                       const clx_tm_histogram_cb_t func,
                                       void *ptr_cookie);
clx_error_no_t
hal_mt_kg_tm_buf_histogram_cb_unregister(const uint32 unit,
                                         const uint32 port,
                                         const clx_tm_histogram_cb_t func,
                                         void *ptr_cookie);
clx_error_no_t
hal_mt_kg_tm_buf_histogram_count_clear(const uint32 unit,
                                       const uint32 port,
                                       const clx_tm_handler_t handler);
clx_error_no_t
hal_mt_kg_tm_buf_linkup_port_flush(const uint32 unit, const uint32 port, const uint32 enable);
clx_error_no_t
hal_mt_kg_tm_buf_prof_create(const uint32 unit,
                             const clx_tm_buf_prof_type_t type,
                             const uint32 prof_id);
clx_error_no_t
hal_mt_kg_tm_buf_prof_destroy(const uint32 unit,
                              const clx_tm_buf_prof_type_t type,
                              const uint32 prof_id);
clx_error_no_t
hal_mt_kg_tm_buf_prof_set(const uint32 unit, const uint32 prof_id, const clx_tm_buf_prof_t *prof);
clx_error_no_t
hal_mt_kg_tm_buf_prof_get(const uint32 unit, const uint32 prof_id, clx_tm_buf_prof_t *prof);
clx_error_no_t
hal_mt_kg_tm_buf_config_set(const uint32 unit,
                            const uint32 port,
                            const clx_tm_handler_t handler,
                            const clx_tm_buf_cfg_t *config);
clx_error_no_t
hal_mt_kg_tm_buf_config_get(const uint32 unit,
                            const uint32 port,
                            const clx_tm_handler_t handler,
                            clx_tm_buf_cfg_t *config);
clx_error_no_t
hal_mt_kg_tm_buf_wred_prof_create(const uint32 unit, const uint32 prof_id);

clx_error_no_t
hal_mt_kg_tm_buf_wred_prof_destroy(const uint32 unit, const uint32 prof_id);
clx_error_no_t
hal_mt_kg_tm_buf_wred_prof_set(const uint32 unit,
                               const uint32 prof_id,
                               const clx_tm_wred_prof_t *prof);
clx_error_no_t
hal_mt_kg_tm_buf_wred_prof_get(const uint32 unit, const uint32 prof_id, clx_tm_wred_prof_t *prof);
clx_error_no_t
hal_mt_kg_tm_buf_wred_config_set(const uint32 unit,
                                 const uint32 port,
                                 const clx_tm_handler_t handler,
                                 const clx_tm_wred_cfg_t *ptr_wred_cfg);
clx_error_no_t
hal_mt_kg_tm_buf_wred_config_get(const uint32 unit,
                                 const uint32 port,
                                 const clx_tm_handler_t handler,
                                 clx_tm_wred_cfg_t *ptr_wred_cfg);

clx_error_no_t
hal_mt_kg_tm_buf_db_dump(const uint32 unit, const uint32 flags);

clx_error_no_t
hal_mt_kg_tm_buf_igr_sys_headroom_set(const uint32 unit, const uint32 headroom);

clx_error_no_t
hal_mt_kg_tm_buf_igr_sys_headroom_get(const uint32 unit, uint32 *ptr_headroom);

clx_error_no_t
hal_mt_kg_tm_buf_share_pool_size_set(const uint32 unit,
                                     const uint32 lossy_pool_size,
                                     const uint32 lossless_pool_size,
                                     const boolean is_egr);

clx_error_no_t
hal_mt_kg_tm_buf_share_pool_size_get(const uint32 unit,
                                     uint32 *ptr_lossy_pool_size,
                                     uint32 *ptr_lossless_pool_size,
                                     const boolean is_egr);
clx_error_no_t
hal_mt_kg_tm_buf_oq_buf_cfg_update(const uint32 unit,
                                   const uint32 port,
                                   const uint32 queue,
                                   const boolean is_egr);
clx_error_no_t
hal_mt_kg_tm_buf_wb_init(const uint32 unit, hal_io_wb_db_t *ptr_db);
clx_error_no_t
hal_mt_kg_tm_buf_wb_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);
clx_error_no_t
hal_mt_kg_tm_buf_sq_tc_map_set(const uint32 unit,
                               const uint32 port,
                               const uint32 sq,
                               const uint32 tc);
#endif // HAL_MT_KG_TM_BUF_H