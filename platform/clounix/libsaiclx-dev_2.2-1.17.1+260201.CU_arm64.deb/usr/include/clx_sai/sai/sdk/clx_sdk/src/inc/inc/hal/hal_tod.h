/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_tod.h
 * PURPOSE:
 *  1. Provide tod module macros and data structures.
 */

#ifndef HAL_TOD_H
#define HAL_TOD_H

#include <hal/hal.h>
#include <hal/mt/hal_mt_intr.h>

#define HAL_TOD_BUF_LEN 3

/* NAMING CONSTANT DECLARATIONS
 */
typedef clx_error_no_t (*hal_tod_1pps_cb_func_t)(const uint32 unit);

/**
 * @brief This API is used to register 1pps callback api.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    func    - Interrupt register node pointer.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
clx_error_no_t
hal_tod_pps_cb_register(const uint32 unit, hal_tod_1pps_cb_func_t func);

/**
 * @brief This API is used to deregister 1pps callback api.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    func    - Interrupt register node pointer.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
clx_error_no_t
hal_tod_pps_cb_deregister(const uint32 unit, hal_tod_1pps_cb_func_t func);

/**
 * @brief This API is used to handle tod 1pps irq.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    ptr_intr_node    - Interrupt register node pointer.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
clx_error_no_t
hal_tod_1pps_irq_handle(uint32 unit, hal_mt_intr_reg_node_t *ptr_intr_node);

/**
 * @brief This API is used to init tod module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
clx_error_no_t
hal_tod_init(const uint32 unit);

/**
 * @brief This API is used to deinit tod module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
clx_error_no_t
hal_tod_deinit(const uint32 unit);

#endif
