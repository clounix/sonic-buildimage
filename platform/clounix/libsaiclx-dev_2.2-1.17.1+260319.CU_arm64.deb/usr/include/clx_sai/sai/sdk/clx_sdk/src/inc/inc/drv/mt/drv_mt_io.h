/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  drv_mt_io.h
 * PURPOSE:
 *  1. Provide the IO channel access interface to chip Device Control Command(DRV_MT).
 *  2. Define DRV_MT IO channel related structures.
 *
 * NOTES:
 *
 */

#ifndef DRV_MT_IO_H
#define DRV_MT_IO_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <osal/osal.h>
#include <clx/clx_init.h>
#include <drv/drv_io.h>

/* NAMING CONSTANT DECLARATIONS
 */

typedef enum drv_mt_io_table_type_e {
    DRV_MT_IO_TABLE_HASH = 0,
    DRV_MT_IO_TABLE_HASH_BDI,
    DRV_MT_IO_TABLE_HASH_FPU,
    DRV_MT_IO_TABLE_HASH_FPU_LPM,
    DRV_MT_IO_TABLE_TCAM,
    DRV_MT_IO_TABLE_TCAM_FPU,
    DRV_MT_IO_TABLE_SRAM_PL,
    DRV_MT_IO_TABLE_SRAM_TM,
    DRV_MT_IO_TABLE_LAST
} drv_mt_io_table_type_t;

typedef enum drv_mt_io_table_key_type_e {
    DRV_MT_IO_TABLE_KEY_1X = 0x0,
    DRV_MT_IO_TABLE_KEY_2X = 0x1,
    DRV_MT_IO_TABLE_KEY_4X = 0x2,
    DRV_MT_IO_TABLE_KEY_LAST
} drv_mt_io_table_key_type_t;

/* Hash cmd action */
typedef enum drv_mt_io_cmd_hash_act_e {
    DRV_MT_IO_CMD_HASH_DIRECT_READ = 0x0,
    DRV_MT_IO_CMD_HASH_DIRECT_WRITE = 0x1,
    DRV_MT_IO_CMD_HASH_SEARCH = 0x2,
    DRV_MT_IO_CMD_HASH_FIND = 0x3,
    DRV_MT_IO_CMD_HASH_INSERT = 0x4,
    DRV_MT_IO_CMD_HASH_DELETE = 0x5,
    DRV_MT_IO_CMD_HASH_UPDATE = 0x6,
    DRV_MT_IO_CMD_HASH_SCAN = 0xfff,
    DRV_MT_IO_CMD_HASH_LAST
} drv_mt_io_cmd_hash_act_t;

typedef enum drv_mt_io_hash_key_type_e {
    DRV_MT_IO_HASH_KEY_1X_IP = 0x0,
    DRV_MT_IO_HASH_KEY_2X_IP = 0x1,
    DRV_MT_IO_HASH_KEY_1X_MPLS_SID = 0x2,
    DRV_MT_IO_HASH_KEY_2X_MPLS_SIP = 0x3,
    DRV_MT_IO_HASH_KEY_LAST
} drv_mt_io_hash_key_type_t;

/* Tcam cmd action */
typedef enum drv_mt_io_cmd_tcam_act_e {
    DRV_MT_IO_CMD_TCAM_READ = 0x0,
    DRV_MT_IO_CMD_TCAM_WRITE = 0x1,
    DRV_MT_IO_CMD_TCAM_CMP = 0x2,
    DRV_MT_IO_CMD_TCAM_UNLOAD = 0x3,
    DRV_MT_IO_CMD_TCAM_FLUSH = 0x4,
    DRV_MT_IO_CMD_TCAM_VALID = 0x5,
    DRV_MT_IO_CMD_TCAM_MOVE = 0xff,
    DRV_MT_IO_CMD_TCAM_SCAN = 0xfff,
    DRV_MT_IO_CMD_TCAM_LAST
} drv_mt_io_cmd_tcam_act_t;

/* cpu hit cmd action */
typedef enum drv_mt_io_cmd_cpu_hit_act_e {
    DRV_MT_IO_CMD_CPU_HIT_WRITE = 0x0,
    DRV_MT_IO_CMD_CPU_HIT_BIT_SET = 0x1,
    DRV_MT_IO_CMD_CPU_HIT_READ = 0x2,
    DRV_MT_IO_CMD_CPU_HIT_FLUSH = 0x3,
    DRV_MT_IO_CMD_CPU_HIT_ABORD = 0x4,
    DRV_MT_IO_CMD_CPU_HIT_LAST
} drv_mt_io_cmd_cpu_hit_act_t;

/* cpu hit tcam type */
typedef enum drv_mt_io_cmd_cpu_hit_tcam_type_e {
    DRV_MT_IO_CMD_CPU_HIT_TCAM_TCAM = 0x0,
    DRV_MT_IO_CMD_CPU_HIT_TCAM_MSGI = 0x1,
    DRV_MT_IO_CMD_CPU_HIT_TCAM_RPFC = 0x2,
    DRV_MT_IO_CMD_CPU_HIT_TCAM_LAST
} drv_mt_io_cmd_cpu_hit_tcam_type_t;

/* DRV_MT constant definition */

#define DRV_MT_IO_IND_CMD_REG_WORD_SIZE           (1)
#define DRV_MT_IO_IND_ADDR_REG_WORD_SIZE          (1)
#define DRV_MT_IO_IND_STATUS_REG_WORD_SIZE        (1)
#define DRV_MT_IO_IND_HASH_STATUS_REG_WORD_SIZE   (3)
#define DRV_MT_IO_IND_CMD_TCAM_MOVE_REG_WORD_SIZE (2)

#ifdef CLX_EMU_DEV
#define DRV_MT_IO_CMD_BUSY_POLL_CNT (3000000)
#else
#define DRV_MT_IO_CMD_BUSY_POLL_CNT (1000)
#endif

#define DRV_MT_IO_IND_STATUS_DOING      (0)
#define DRV_MT_IO_IND_STATUS_DONE       (1)
#define DRV_MT_IO_IND_STATUS_OP_FAIL    (0)
#define DRV_MT_IO_IND_STATUS_OP_SUCCESS (1)

#endif /* END of DRV_MT_IO_H*/
