/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_stat.h
 * PURPOSE:
 *    It provides HAL driver API functions for stat module.
 *
 * NOTES:
 *
 *
 */
#ifndef HAL_MT_KG_STAT_H
#define HAL_MT_KG_STAT_H
/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_stat.h>
#include <clx/clx_tm.h>
#include <hal/hal_cmn.h>
#include <hal/hal_cmn_drv.h>
#include <hal/hal_stat.h>
#include <hal/hal_sec.h>

/* #define HAL_MT_KG_STAT_USE_CLD_DMA */
/* #define HAL_MT_KG_STAT_EN_RSFEC_CNT */

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_KG_STAT_MIB_SRAM_CPI_IDX_OFFSET  (256)
#define HAL_MT_KG_STAT_MIB_SRAM_LANE_IDX_OFFSET (128)
#define HAL_MT_KG_STAT_UMAC_ENTRY_NUM           (3070) /* kg mib sram depth 3070 */
#define HAL_MT_KG_STAT_SRV_CNT_IDX_OFFSET       (10)
#define HAL_MT_KG_STAT_SRV_CNT_NUM_PER_BANK     ((1U << HAL_MT_KG_STAT_SRV_CNT_IDX_OFFSET) * 6)
#define HAL_MT_KG_STAT_SRV_CNT_IDX_SEL_OFFSET   (3)
#define HAL_MT_KG_STAT_SRV_CNT_BANK_NUM         (16)
#define HAL_MT_KG_STAT_DIE_NUM                  (HAL_IS_DEVICE_KG_DOUBLE_FAMILY(unit) ? 2 : 1)
#define HAL_MT_KG_STAT_MAC_NUM_PER_DIE          (6)
#define HAL_MT_KG_STAT_LANE_NUM_PER_MAC         (16)
#define HAL_MT_KG_STAT_LANE_NUM_PER_DIE \
    (HAL_MT_KG_STAT_LANE_NUM_PER_MAC * HAL_MT_KG_STAT_MAC_NUM_PER_DIE)
#define HAL_MT_KG_STAT_CLX_UMAC_RX_MEM_ENTRY_PER_LANE (25)
#define HAL_MT_KG_STAT_CLX_UMAC_RX_REG_ENTRY_PER_LANE (19)
#define HAL_MT_KG_STAT_CLX_UMAC_TX_MEM_ENTRY_PER_LANE (25)
#define HAL_MT_KG_STAT_CLX_UMAC_TX_REG_ENTRY_PER_LANE (8)
#define HAL_MT_KG_STAT_CLX_UMAC_ENTRY_NUM             \
    (HAL_MT_KG_STAT_LANE_NUM_PER_MAC *                \
     (HAL_MT_KG_STAT_CLX_UMAC_RX_MEM_ENTRY_PER_LANE + \
      HAL_MT_KG_STAT_CLX_UMAC_TX_MEM_ENTRY_PER_LANE + \
      HAL_MT_KG_STAT_CLX_UMAC_RX_REG_ENTRY_PER_LANE + \
      HAL_MT_KG_STAT_CLX_UMAC_TX_REG_ENTRY_PER_LANE))
#define HAL_MT_KG_STAT_ETHL_LANE_NUM               (256)
#define HAL_MT_KG_STAT_ETHX_LANE_NUM               (2)
#define HAL_MT_KG_STAT_CPU_LANE_NUM                (1)
#define HAL_MT_KG_STAT_CPU_PORT_IDX                (256)
#define HAL_MT_KG_STAT_TM_QUEUECNT_NUM_PER_PLANE   (576)
#define HAL_MT_KG_STAT_TM_CPU_QUEUE_NUM            (48)
#define HAL_MT_KG_STAT_TM_CPI_QUEUE_NUM            (16)
#define HAL_MT_KG_STAT_MAX_TOLORENCE_INTERVAL      (1350000)
#define HAL_MT_KG_STAT_DEFAULT_POLLING_INTERVAL_MS (500)
#define HAL_MT_KG_STAT_MIN_POLLING_INTERVAL_MS     (250)
#define HAL_MT_KG_STAT_MAX_POLLING_INTERVAL_MS     (1000)

#define HAL_MT_KG_STAT_SQ_NUM_PER_PLANE                  (712)
#define HAL_MT_KG_STAT_SQ_NUM_PER_PORT                   (8)
#define HAL_MT_KG_STAT_OQ_NUM_PER_PLANE                  (2048)
#define HAL_MT_KG_STAT_OQ_NUM_MAX                        (2048 * 2) /* 2 dies */
#define HAL_MT_KG_STAT_GET_SQ_ID(ppid, id)               (((ppid) << 3) + (id))
#define HAL_MT_KG_STAT_PP_HEADER_LEN                     (40)
#define HAL_MT_KG_STAT_PL_FLAGS_MAC                      (1U << 0)
#define HAL_MT_KG_STAT_PP_FLAGS_TDS                      (1U << 1)
#define HAL_MT_KG_STAT_PP_FLAGS_DIS                      (1U << 2)
#define HAL_MT_KG_STAT_PP_FLAGS_FPU                      (1U << 3)
#define HAL_MT_KG_STAT_PP_FLAGS_ICIA                     (1U << 4)
#define HAL_MT_KG_STAT_PP_FLAGS_FWR                      (1U << 5)
#define HAL_MT_KG_STAT_PP_FLAGS_TM                       (1U << 6)
#define HAL_MT_KG_STAT_PP_FLAGS_RWI                      (1U << 7)
#define HAL_MT_KG_STAT_PP_FLAGS_ECIA                     (1U << 8)
#define HAL_MT_KG_STAT_PP_FLAGS_RWO                      (1U << 9)
#define HAL_MT_KG_STAT_PP_FLAGS_ALL                      (0x1FF)
#define HAL_MT_KG_TBL_CNT_RSLT_XPORT_ENTRY_NUM           (528)
#define HAL_MT_KG_STAT_CNT_RSN_GRP0_XPORT_ENTRY_NUM      (88)
#define HAL_MT_KG_STAT_DROP_RSN_PORT_GRP_XPORT_ENTRY_NUM (704)
#define HAL_MT_KG_STAT_CNT_RSN_GRP0_ID                   (0x7)
#define HAL_MT_KG_STAT_DROP_RSN_PORT_GRP_ID              (0x7)
#define HAL_MT_KG_STAT_CNT_RSN_GRP0_VALID                (0x1)

#define HAL_MT_KG_STAT_TM_PKT_CNT_UPDATE(ptr_cnt, src, clear) \
    do {                                                      \
        if (clear) {                                          \
            UI64_SET(src, _hal_mt_kg_stat_ui64_zero);         \
        } else {                                              \
            ((ptr_cnt)->pkt_cnt) += (src);                    \
        }                                                     \
    } while (0)

#define HAL_MT_KG_STAT_TM_BYTE_CNT_UPDATE(ptr_cnt, src, clear) \
    do {                                                       \
        if (clear) {                                           \
            UI64_SET(src, _hal_mt_kg_stat_ui64_zero);          \
        } else {                                               \
            ((ptr_cnt)->byte_cnt) += (src);                    \
        }                                                      \
    } while (0)
/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_MT_KG_STAT_RSFEC_LOCK(__unit__) \
    osal_semaphore_take(&(_hal_stat_rsfec_cb[__unit__].sema), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_MT_KG_STAT_RSFEC_UNLOCK(__unit__) \
    osal_semaphore_give(&(_hal_stat_rsfec_cb[__unit__].sema))

#ifdef CLX_STAT_EN_HPC_CNT
#define HAL_MT_KG_STAT_HPC_MAX_FIFO_SIZE           (4 * 1024)
#define HAL_MT_KG_STAT_HPC_MIN_FIFO_SIZE           (1 * 1024)
#define HAL_MT_KG_STAT_HPC_MAX_POLLING_INTERVAL_US (500000)
#define HAL_MT_KG_STAT_HPC_MIN_POLLING_INTERVAL_US (800)
#define HAL_MT_KG_STAT_HPC_THREAD_STACK_SIZE       (32 * 1024)
#define HAL_MT_KG_STAT_HPC_THREAD_PRIORITY         (80)
#define HAL_MT_KG_STAT_HPC_CNT_LOCK(__unit__)                              \
    osal_semaphore_take(&(_hal_mt_kg_stat_hpc_cb[__unit__].stat_buf.sema), \
                        CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_MT_KG_STAT_HPC_CNT_UNLOCK(__unit__) \
    osal_semaphore_give(&(_hal_mt_kg_stat_hpc_cb[__unit__].stat_buf.sema))
#define HAL_MT_KG_STAT_HPC_DMA_LOCK(__unit__) \
    osal_semaphore_take(&(_hal_mt_kg_stat_hpc_cb[__unit__].sema_dma), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_MT_KG_STAT_HPC_DMA_UNLOCK(__unit__) \
    osal_semaphore_give(&(_hal_mt_kg_stat_hpc_cb[__unit__].sema_dma))
#define HAL_MT_KG_STAT_HPC_QUEUE_LOCK(__unit__)                                   \
    osal_semaphore_take(&(_hal_mt_kg_stat_hpc_cb[__unit__].hpc_queue.sema_queue), \
                        CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_MT_KG_STAT_HPC_QUEUE_UNLOCK(__unit__) \
    osal_semaphore_give(&(_hal_mt_kg_stat_hpc_cb[__unit__].hpc_queue.sema_queue))

#define HAL_MT_KG_STAT_HPC_DMA_BUF_SIZE(__unit__)                        \
    ((HAL_MT_KG_STAT_DIE_NUM) *                                          \
     TOB_TABLE(__unit__, MT_KG_REG_UMAC_AXI_MIB_MEM_ID)->subinst_count * \
     TOB_TABLE(__unit__, MT_KG_REG_UMAC_AXI_MIB_MEM_ID)->entry_size *    \
     HAL_MT_KG_STAT_UMAC_ENTRY_NUM)

#define HAL_MT_KG_STAT_REG_UMAC_AXI_MIB_MEM_ADDR(__unit__, __inst__, __subinst__, __entry__)   \
    TOB_TABLE(__unit__, MT_KG_REG_UMAC_AXI_MIB_MEM_ID)->table_addr +                           \
        (TOB_TABLE(__unit__, MT_KG_REG_UMAC_AXI_MIB_MEM_ID)->slot_size * (__inst__)) +         \
        (TOB_TABLE(__unit__, MT_KG_REG_UMAC_AXI_MIB_MEM_ID)->subinst_offset * (__subinst__)) + \
        (TOB_TABLE(__unit__, MT_KG_REG_UMAC_AXI_MIB_MEM_ID)->entry_size * (__entry__))

/* Calculate SRAM offset based on unit and port */
#define HAL_MT_KG_STAT_SRAM_OFFSET(__unit__, __port__, __sram_idx_offset__)                        \
    do {                                                                                           \
        uint32 __plane_id = HAL_CL_PORT_TO_PLANE(__unit__, __port__);                              \
        uint32 __macro_id = HAL_CL_PORT_TO_MAC_MACRO(__unit__, __port__);                          \
        uint32 __chan_id = HAL_CL_PORT_TO_MACRO_PORT(__unit__, __port__);                          \
        (__sram_idx_offset__) = (__plane_id * (HAL_MT_KG_STAT_DIE_NUM - 1) *                       \
                                 HAL_MT_KG_STAT_MAC_NUM_PER_DIE * HAL_MT_KG_STAT_UMAC_ENTRY_NUM) + \
            (__macro_id * HAL_MT_KG_STAT_UMAC_ENTRY_NUM) +                                         \
            (__chan_id * HAL_MT_KG_STAT_MIB_SRAM_LANE_IDX_OFFSET);                                 \
    } while (0)

/* #define HAL_MT_KG_STAT_HPC_QUEUE_DEBUG_EN  // use to dump all queue info, debug only */
/* #define HAL_MT_KG_STAT_HPC_DEBUG_EN  // use to dump all UMAC, debug only */
/* #define HAL_MT_KG_STAT_HPC_PERFORMANCE_TEST  // debug only */
#ifdef HAL_MT_KG_STAT_HPC_PERFORMANCE_TEST
#define HAL_MT_KG_STAT_HPC_MEASURE_COUNT (1000)
#endif
#define HAL_MT_KG_STAT_FIXED_SLEEP_TIME // Fixed sleep time to stabilize port rate */
#endif                                  /* End of CLX_STAT_EN_HPC_CNT */

#define HAL_MT_KG_STAT_UMAC_MIB_BASE_ADDR              (0xA000)
#define HAL_MT_KG_STAT_UMAC_FRAMESXMITOK_ADDR          (0xC000)
#define HAL_MT_KG_STAT_UMAC_FEC_CERR_BASE_ADDR         (0xD3B0)
#define HAL_MT_KG_STAT_UMAC_FEC_UCERR_BASE_ADDR        (0xDB90)
#define HAL_MT_KG_STAT_UMAC_FEC_CERR_SYM_ERR_BASE_ADDR (0xE000)

#define HAL_MT_KG_STAT_MIB_SRAM_TYPE_START \
    ((HAL_MT_KG_STAT_UMAC_FRAMESXMITOK_ADDR - HAL_MT_KG_STAT_UMAC_MIB_BASE_ADDR) / 8)
/* DATA TYPE DECLARATIONS
 */
typedef enum hal_mt_kg_stat_mib_sram_type_e {
    HAL_MT_KG_STAT_MIB_FRAMESXMITOK,
    HAL_MT_KG_STAT_MIB_FRAMESXMITALL,
    HAL_MT_KG_STAT_MIB_FRAMESXMITERROR,
    HAL_MT_KG_STAT_MIB_OCTETSXMITOK,
    HAL_MT_KG_STAT_MIB_OCTETSXMITALL,
    HAL_MT_KG_STAT_MIB_FRAMESXMITUNICAST,
    HAL_MT_KG_STAT_MIB_FRAMESXMITMULTICAST,
    HAL_MT_KG_STAT_MIB_FRAMESXMITBROADCAST,
    HAL_MT_KG_STAT_MIB_FRAMESXMITPAUSE,
    HAL_MT_KG_STAT_MIB_FRAMESXMITPRIPAUSE,
    HAL_MT_KG_STAT_MIB_FRAMESXMITVLAN,
    HAL_MT_KG_STAT_MIB_FRAMESXMITSIZELT64,
    HAL_MT_KG_STAT_MIB_FRAMESXMITSIZEEQ64,
    HAL_MT_KG_STAT_MIB_FRAMESXMITSIZE65TO127,
    HAL_MT_KG_STAT_MIB_FRAMESXMITSIZE128TO255,
    HAL_MT_KG_STAT_MIB_FRAMESXMITSIZE256TO511,
    HAL_MT_KG_STAT_MIB_FRAMESXMITSIZE512TO1023 = 16,
    HAL_MT_KG_STAT_MIB_FRAMESXMITSIZE1024TO1518,
    HAL_MT_KG_STAT_MIB_FRAMESXMITSIZE1519TO2047,
    HAL_MT_KG_STAT_MIB_FRAMESXMITSIZE2048TO4095,
    HAL_MT_KG_STAT_MIB_FRAMESXMITSIZE4096TO8191,
    HAL_MT_KG_STAT_MIB_FRAMESXMITSIZE8192TO9215,
    HAL_MT_KG_STAT_MIB_FRAMESXMITSIZEGT9216,
    HAL_MT_KG_STAT_MIB_FRAMESXMITPRI0,
    HAL_MT_KG_STAT_MIB_FRAMESXMITPRI1,
    HAL_MT_KG_STAT_MIB_FRAMESXMITPRI2,
    HAL_MT_KG_STAT_MIB_FRAMESXMITPRI3,
    HAL_MT_KG_STAT_MIB_FRAMESXMITPRI4,
    HAL_MT_KG_STAT_MIB_FRAMESXMITPRI5,
    HAL_MT_KG_STAT_MIB_FRAMESXMITPRI6,
    HAL_MT_KG_STAT_MIB_FRAMESXMITPRI7,
    HAL_MT_KG_STAT_MIB_XMITPRI0PAUSE1US,
    HAL_MT_KG_STAT_MIB_XMITPRI1PAUSE1US = 32,
    HAL_MT_KG_STAT_MIB_XMITPRI2PAUSE1US,
    HAL_MT_KG_STAT_MIB_XMITPRI3PAUSE1US,
    HAL_MT_KG_STAT_MIB_XMITPRI4PAUSE1US,
    HAL_MT_KG_STAT_MIB_XMITPRI5PAUSE1US,
    HAL_MT_KG_STAT_MIB_XMITPRI6PAUSE1US,
    HAL_MT_KG_STAT_MIB_XMITPRI7PAUSE1US,
    HAL_MT_KG_STAT_MIB_FRAMESXMITDRAINED,
    HAL_MT_KG_STAT_MIB_FRAMESXMITJABBERED,
    HAL_MT_KG_STAT_MIB_FRAMESXMITPADDED,
    HAL_MT_KG_STAT_MIB_FRAMESXMITTRUNCATED,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDOK,
    HAL_MT_KG_STAT_MIB_OCTECTSRCVDOK,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDALL,
    HAL_MT_KG_STAT_MIB_OCTECTSRCVDALL,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDCRCERROR,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDERROR = 48,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDUNICAST,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDMULTICAST,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDBROADCAST,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDPAUSE,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDLENERROR,
    HAL_MT_KG_STAT_MIB_RESERVED0,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDOVERSIZED,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDFRAGMENTS,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDJABBER,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDPRIPAUSE,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDCRCERRSTOMP,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDMAXFRMSIZEVIO,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDVLAN,
    HAL_MT_KG_STAT_MIB_RESERVED1,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDSIZELT64,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDSIZEEQ64 = 64,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDSIZE65TO127,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDSIZE128TO255,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDSIZE256TO511,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDSIZE512TO1023,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDSIZE1024TO1518,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDSIZE1419TO2047,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDSIZE2048TO4095,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDSIZE4096TO8191,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDSIZE8912TO9215,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDSIZEGT9216,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDPRI0,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDPRI1,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDPRI2,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDPRI3,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDPRI4,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDPRI5 = 80,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDPRI6,
    HAL_MT_KG_STAT_MIB_FRAMESRCVDPRI7,
    HAL_MT_KG_STAT_MIB_RCVDPRI0PAUSE1US,
    HAL_MT_KG_STAT_MIB_RCVDPRI1PAUSE1US,
    HAL_MT_KG_STAT_MIB_RCVDPRI2PAUSE1US,
    HAL_MT_KG_STAT_MIB_RCVDPRI3PAUSE1US,
    HAL_MT_KG_STAT_MIB_RCVDPRI4PAUSE1US,
    HAL_MT_KG_STAT_MIB_RCVDPRI5PAUSE1US,
    HAL_MT_KG_STAT_MIB_RCVDPRI6PAUSE1US,
    HAL_MT_KG_STAT_MIB_RCVDPRI7PAUSE1US,
    HAL_MT_KG_STAT_MIB_RCVDSTDPAUSE1US,
    HAL_MT_KG_STAT_MIB_RESERVED2,
    HAL_MT_KG_STAT_MIB_RESERVED3,
    HAL_MT_KG_STAT_MIB_INVALIDPREAMBLE,
    HAL_MT_KG_STAT_MIB_NORMALLENINVALIDCRC,
    HAL_MT_KG_STAT_MIB_HSMC_PCS_BER_ERROR_COUNTER = 96,
    HAL_MT_KG_STAT_MIB_HSMC_PCS_ERRORED_BLOCKS_COUNTER,
    HAL_MT_KG_STAT_MIB_HSMC_PCS_VALID_ERRORED_BLOCK_COUNTER,
    HAL_MT_KG_STAT_MIB_HSMC_PCS_UNKNOWN_ERRORED_BLOCK_COUNTER,
    HAL_MT_KG_STAT_MIB_HSMC_PCS_INVALID_ERRORED_BLOCK_COUNTER,
    HAL_MT_KG_STAT_MIB_HSMC_PCS_TEST_PATTERN_ERRORS_COUNTER,
    HAL_MT_KG_STAT_MIB_HSMC_PCS_SYNC_ERROR,
    HAL_MT_KG_STAT_MIB_HSMC_PCS_BLOCK_LOCK_LOSS_COUNTER,
    HAL_MT_KG_STAT_MIB_HSMC_PCS_HIBER_COUNTER,
    HAL_MT_KG_STAT_MIB_LSPCS_INVALID_CODE,
    HAL_MT_KG_STAT_MIB_LSPCS_DISPARITY_ERROR,
    HAL_MT_KG_STAT_MIB_RSFEC_COUNTERED_CODEWORDS,
    HAL_MT_KG_STAT_MIB_RSFEC_UNCOTTECTED_CODEWORDS,
    HAL_MT_KG_STAT_MIB_RSFEC_CH_SYMBOL_ERROR_COUNTER,
    HAL_MT_KG_STAT_MIB_HSMC_PCS_LANE_BIP_N_ERRORS_COUNTER,
    HAL_MT_KG_STAT_MIB_FCFEC_LANE_N_CORRECTED_CODEWORDS,
    HAL_MT_KG_STAT_MIB_FCFEC_LANE_N_UNCORRECTED_CODEWORDS = 112,
    HAL_MT_KG_STAT_MIB_RSFEC_LANE_N_SYMBOL_ERRORS,
    HAL_MT_KG_STAT_MIB_SRAM_TYPE_LAST
} hal_mt_kg_stat_mib_sram_type_t;

typedef enum hal_mt_kg_stat_clx_mib_sram_type_e {
    /* RX mem */
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDSIZELT64 = 0,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDSIZEEQ64,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDSIZE65TO127,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDSIZE128TO255,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDSIZE256TO511,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDSIZE512TO1023,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDSIZE1024TO1518,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDSIZE1519TO2047,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDSIZE2058TO4095,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDSIZE4096TO8191,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDSIZE8192TO9215,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDSIZEGT9216,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDPRI0,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDPRI1,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDPRI2,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDPRI3,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDPRI4,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDPRI5,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDPRI6,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDPRI7,
    HAL_MT_KG_STAT_CLX_MIB_INVALIDPREAMBLE,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDCRCERR,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDCRCSTOMP,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDLENERR,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDJABBER,
    /* RX register */
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDOK, /* 25 */
    HAL_MT_KG_STAT_CLX_MIB_OCTECTSRCVDOK,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDALL,
    HAL_MT_KG_STAT_CLX_MIB_OCTECTSRCVDALL,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDERROR,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDUC,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDMC,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDBC,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDPRIPAUSE,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESRCVDPAUSE,
    HAL_MT_KG_STAT_CLX_MIB_NORMALLENINVALIDCRC,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESDROPD,
    HAL_MT_KG_STAT_CLX_MIB_PCS_ALL_ERROR,
    HAL_MT_KG_STAT_CLX_MIB_PCS_BLKTYPE_OUTTABLE,
    HAL_MT_KG_STAT_CLX_MIB_PCS_HI_BER,
    HAL_MT_KG_STAT_CLX_MIB_PCS_INVALID_BLOCK,
    HAL_MT_KG_STAT_CLX_MIB_PCS_LOCK_MISS,
    HAL_MT_KG_STAT_CLX_MIB_PCS_PAYLOAD_ERROR,
    HAL_MT_KG_STAT_CLX_MIB_PCS_SYCHEAD_INVALID,
    /* TX mem */
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITSIZELT64, /* 44 */
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITSIZEEQ64,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITSIZE65TO127,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITSIZE128TO255,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITSIZE256TO511,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITSIZE512TO1023,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITSIZE1024TO1518,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITSIZE1519TO2047,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITSIZE2048TO4095,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITSIZE4096TO8191,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITSIZE8192TO9215,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITSIZEGT9216,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITPAUSE,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITPFC,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITPRI0,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITPRI1,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITPRI2,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITPRI3,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITPRI4,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITPRI5,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITPRI6,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITPRI7,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXTXDRAINED,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESTXJABBER,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESTXPADDED,
    /* TX register */
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITOK, /* 69 */
    HAL_MT_KG_STAT_CLX_MIB_OCTECTSXMITOK,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITALL,
    HAL_MT_KG_STAT_CLX_MIB_OCTECTSXMITALL,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITERROR,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITUC,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITMC,
    HAL_MT_KG_STAT_CLX_MIB_FRAMESXMITBC,
    HAL_MT_KG_STAT_CLX_MIB_SRAM_TYPE_LAST
} hal_mt_kg_stat_clx_mib_sram_type_t;

typedef struct hal_mt_kg_stat_rsfec_task_s {
    uint32 inst_idx;
    uint32 subinst_idx;
    uint32 entry_idx;
} hal_mt_kg_stat_rsfec_task_t;

typedef struct hal_mt_kg_stat_rsfec_cb_s {
    uint64 *ptr_results;
    uint32 task_cnt;
    uint32 *ptr_tasks_id;
    hal_mt_kg_stat_rsfec_task_t *ptr_tasks;
    clx_semaphore_id_t sema;
    clx_thread_id_t update_thread_id;
    uint32 sleep_intvl;
} hal_mt_kg_stat_rsfec_cb_t;

typedef struct hal_mt_kg_stat_oq_drop_cnt_info_s {
    hal_stat_hw_type_t hw_cnt_type;
    uint32 table_id;
} hal_mt_kg_stat_oq_drop_cnt_info_t;

#ifdef CLX_STAT_EN_HPC_CNT
typedef struct hal_mt_kg_stat_hpc_queue_s {
    clx_stat_hpc_cnt_t *data;      /* Queue data buffer */
    uint32 size;                   /* Total queue size */
    uint32 head;                   /* Index for dequeue */
    uint32 tail;                   /* Index for enqueue */
    uint32 count;                  /* Current number of elements */
    clx_semaphore_id_t sema_queue; /* Queue mutex */
    boolean initialized;           /* Queue initialization flag */
} hal_mt_kg_stat_hpc_queue_t;

typedef struct hal_mt_kg_stat_hpc_cb_s {
    hal_stat_buf_t stat_buf;
    hal_mt_kg_stat_hpc_queue_t hpc_queue;
    clx_stat_hpc_cfg_t cfg;
    clx_semaphore_id_t sema_dma;
    boolean is_created;
    clx_thread_id_t task_id;
} hal_mt_kg_stat_hpc_cb_t;

#endif

/*
 * 0xF3000:  4 * 8 * 320 bytes   0xF5800     occupancy data for sdk with 8* 320 sq
 * 0xF6000:  4 * 8 * 320 bytes   0xF8800     watermark data for sdk with 8* 320 sq
 */
#define HAL_MT_KG_STAT_WATERMARK_OFFSET   (0xF6000 - 0xF3000)
#define HAL_MT_KG_STAT_WATERMARK_CNT_BASE (HAL_MT_KG_STAT_WATERMARK_OFFSET / sizeof(uint32))
#define HAL_MT_KG_STAT_WATERMARK_BUF_SIZE (0xF9000 - 0xF3000)
// #define HAL_MT_KG_STAT_WATERMARK_CNT_SIZE
// (HAL_MT_KG_TM_PLANE_NUM*HAL_MT_KG_TM_HEADROOM_COUNT_PORT_PER_PLANE*HAL_MT_KG_TM_UNICAST_QUEUE_NUM)
// #define HAL_MT_KG_STAT_WATERMARK_OCCUPANCY_SIZE
// (HAL_MT_KG_TM_PLANE_NUM*HAL_MT_KG_TM_HEADROOM_COUNT_PORT_PER_PLANE*HAL_MT_KG_TM_UNICAST_QUEUE_NUM)

#define HAL_MT_KG_STAT_WATERMARK_ADDR (HAL_MT_KG_ECPU_DTCMBASE_CHAIN + 0xF3000)
#define HAL_MT_KG_STAT_WATERMARK_LOCK(__unit__)                                   \
    osal_semaphore_take(&_hal_mt_kg_stat_watermark_info[__unit__].sema_watermark, \
                        CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_MT_KG_STAT_WATERMARK_UNLOCK(__unit__) \
    osal_semaphore_give(&_hal_mt_kg_stat_watermark_info[__unit__].sema_watermark)

typedef struct hal_mt_kg_stat_watermark_info_s {
    void *ptr_dma_buf;
    uint32 *ptr_results;
    clx_semaphore_id_t sema_watermark;
    clx_thread_id_t watermark_thread_id;
#define HAL_STAT_FLAGS_POLLING (1U << 0)
    uint32 flags;
} hal_mt_kg_stat_watermark_info_t;

#define HAL_MT_KG_STAT_SAI_MATRIX_CTRL_COLOR_GREEN  (1 << 0x0)
#define HAL_MT_KG_STAT_SAI_MATRIX_CTRL_COLOR_YELLOW (1 << 0x1)
#define HAL_MT_KG_STAT_SAI_MATRIX_CTRL_COLOR_RED    (1 << 0x2)

typedef struct hal_mt_kg_stat_sai_matrix_ctrl_array_s {
    uint32 sai_color_dst_other_ecn_enable;  /* SAI_COLOR_DST_OTHER_ECN_ENABLE */
    uint32 sai_color_dst_wred_ecn_enable;   /* SAI_COLOR_DST_WRED_ECN_ENABLE */
    uint32 sai_color_dst_other_drop_enable; /* SAI_COLOR_DST_OTHER_DROP_ENABLE */
    uint32 sai_color_dst_wred_drop_enable;  /* SAI_COLOR_DST_WRED_DROP_ENABLE */
    uint32 sai_color_src_lossy_drop_enable; /* SAI_COLOR_SRC_LOSSY_DROP_ENABLE */
    uint32 sai_color_src_lossl_drop_enable; /* SAI_COLOR_SRC_LOSSL_DROP_ENABLE */
    uint32 sai_color_cpa_drop_enable;       /* SAI_COLOR_CPA_DROP_ENABLE */
    uint32 sai_color_cpa_ecn_enable;        /* SAI_COLOR_CPA_ECN_ENABLE */
    uint32 sai_color_mod_enable;            /* SAI_COLOR_MOD_ENABLE */
    uint32 sai_color_rep_drop_enable;       /* SAI_COLOR_REP_DROP_ENABLE */
    uint32 sai_color_pass_enable;           /* SAI_COLOR_PASS_ENABLE */
    uint32 sai_color_recv_enable;           /* SAI_COLOR_RECV_ENABLE */
    uint32 account_mode;                    /* ACCOUNT_MODE */
    uint32 queue_source;                    /* QUEUE_SOURCE */
} hal_mt_kg_stat_sai_matrix_ctrl_array_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Init stat module control blocks.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Init success.
 * @return        CLX_E_NO_MEMORY        - Allocate control block failed.
 * @return        CLX_E_OTHERS           - Init fail.
 * @return        CLX_E_BAD_PARAMETER    - Parameter invalid.
 */
clx_error_no_t
hal_mt_kg_stat_init(const uint32 unit);

/**
 * @brief Deinit stat module control blocks and free resource.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Deinit success.
 * @return        CLX_E_OTHERS           - DeInit fail.
 * @return        CLX_E_BAD_PARAMETER    - Parameter invalid.
 */
clx_error_no_t
hal_mt_kg_stat_deinit(const uint32 unit);

/**
 * @brief This API is used to get counter by port, queue, and TM counter type.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Port ID.
 * @param [in]     handler    - The handler of TM queue.
 * @param [in]     type       - The TM counter type.
 * @param [out]    ptr_cnt    - Counter value.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation failed.
 * @return         CLX_E_NOT_SUPPORT      - Not support.
 */
clx_error_no_t
hal_mt_kg_stat_tm_cnt_get(const uint32 unit,
                          const uint32 port,
                          const clx_tm_handler_t handler,
                          const clx_stat_tm_t type,
                          clx_stat_tm_cnt_t *ptr_cnt);

/**
 * @brief This API is used to clear counter by port, queue, and TM counter type.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Port ID.
 * @param [in]    handler    - The handler of TM queue.
 * @param [in]    type       - The TM counter type.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operation failed.
 * @return        CLX_E_NOT_SUPPORT      - Not support.
 */
clx_error_no_t
hal_mt_kg_stat_tm_cnt_clear(const uint32 unit,
                            const uint32 port,
                            const clx_tm_handler_t handler,
                            const clx_stat_tm_t type);

/**
 * @brief This API is used to clear oq drop or ecn counter by port, queue.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Port ID.
 * @param [in]    handler    - The handler of TM queue.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_mt_kg_stat_tm_sai_oq_cnt_clear(const uint32 unit,
                                   const uint32 port,
                                   const clx_tm_handler_t handler);

/**
 * @brief This API is used to get port MIB raw counter, start from 0xA000.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port.
 * @param [in]     entry_idx    - The index of the entry, entry_idx * 8 is addr offset from 0xA000.
 * @param [out]    ptr_cnt      - Pointer to counter.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_stat_mib_raw_total_get(const uint32 unit,
                                 const uint32 port,
                                 const uint32 entry_idx,
                                 uint64 *ptr_cnt);

/**
 * @brief This API is used to get port MIB raw counter.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port.
 * @param [in]     hw_type     - The type of HW, ETHC or ETHX.
 * @param [in]     cnt_type    - The type of counter.
 * @param [out]    ptr_cnt     - Pointer to counter.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_stat_mib_raw_get(const uint32 unit,
                           const uint32 port,
                           const hal_stat_hw_type_t hw_type,
                           const hal_mt_kg_stat_mib_sram_type_t cnt_type,
                           uint64 *ptr_cnt);

/**
 * @brief This API is used to get FEC port MIB raw counter.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port.
 * @param [in]     hw_type      - The type of HW, ETHC or ETHX.
 * @param [in]     entry_idx    - The index of the entry.
 * @param [out]    ptr_cnt      - Pointer to counter.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_stat_mib_fec_raw_get(const uint32 unit,
                               const uint32 port,
                               const hal_stat_hw_type_t hw_type,
                               const uint32 entry_idx,
                               uint64 *ptr_cnt);

/**
 * @brief This API is used to clear port MIB raw counter.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port.
 * @param [in]    hw_type     - The type of HW, ETHC or ETHX.
 * @param [in]    cnt_type    - The type of counter.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_stat_mib_raw_clear(const uint32 unit,
                             const uint32 port,
                             const hal_stat_hw_type_t hw_type,
                             const hal_mt_kg_stat_mib_sram_type_t cnt_type);

/**
 * @brief This API is used to get FEC port MIB raw counter.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    port         - Physical port.
 * @param [in]    hw_type      - The type of HW, ETHC or ETHX.
 * @param [in]    entry_idx    - The index of the entry.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_stat_mib_fec_raw_clear(const uint32 unit,
                                 const uint32 port,
                                 const hal_stat_hw_type_t hw_type,
                                 const uint32 entry_idx);

/**
 * @brief This API is used to get how many times the counter has been updated.
 *
 * @param [in]     unit       - Device unit number.
 * @param [out]    ptr_cnt    - Update count.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_stat_update_cnt_get(const uint32 unit, uint64 *ptr_cnt);

/**
 * @brief This API is used to get PP storm control counter by index.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     plane      - Plane number.
 * @param [in]     cnt_idx    - The strom control counter index.
 * @param [out]    ptr_cnt    - Pointer to corresponding counter entry (3 values).
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_stat_storm_cnt_get(const uint32 unit,
                             const uint32 plane,
                             const uint32 cnt_idx,
                             hal_sec_sccounter_entry_t *ptr_cnt);

/**
 * @brief This API is used to clear PP storm control counter by index.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    plane      - Plane number.
 * @param [in]    cnt_idx    - The strom control counter index.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_stat_storm_cnt_clear(const uint32 unit, const uint32 plane, const uint32 cnt_idx);

/**
 * @brief This API is used to show debug counter.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    port         - CLX port number.
 * @param [in]    stage_bmp    - The bitmap of stage: bit0: mac; bit1: ipm;
 *                               bit2: ios: bit3: ipp; bit4: xbn; bit5: tm;
 *                               bit6: epp; bit7: epm; bit8: lbm.
 * @param [in]    flags        - Show the counter or not if it is zero.
 * @return        CLX_E_OK    - Success.
 */
clx_error_no_t
hal_mt_kg_stat_dbg_cnt_show(const uint32 unit,
                            const uint32 port,
                            const uint32 stage_bmp,
                            const uint32 flags);

/**
 * @brief This API is used to clear all debug counter.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_stat_dbg_cnt_clear(const uint32 unit);

/**
 * @brief This API is used to trigger manually counter update to get latest counter value.
 *
 * The API takes time to collect latest counter please use it wisely.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK             - Success.
 * @return        CLX_E_NOT_SUPPORT    - Not support in current mode.
 */
clx_error_no_t
hal_mt_kg_stat_cnt_refresh(const uint32 unit);

/**
 * @brief This API is used to set RS-FEC error distribution counter polling interval.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    interval    - Polling interval (unit: microsecond).
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_stat_rs_err_dist_cnt_interval_set(const uint32 unit, const uint32 interval);

/**
 * @brief This API is used to get PP counter HW index using SW index.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     sw_cnt_id         - SW counter id.
 * @param [in]     cnt_type          - Counter type.
 * @param [in]     pp_obj_type       - PP binding object type.
 * @param [out]    ptr_hw_cnt_idx    - HW counter idx.
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_TABLE_FULL         - No available HW resource.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The SW counter has not been created.
 */
clx_error_no_t
hal_mt_kg_stat_cnt_hw_idx_get(const uint32 unit,
                              const uint32 sw_cnt_id,
                              const hal_stat_hw_type_t cnt_type,
                              const hal_stat_pp_obj_type_t pp_obj_type,
                              uint32 *ptr_hw_cnt_idx);

/**
 * @brief To get a PP HW counter bank Id and corresponding index Id.
 *
 * @param [in]     unit                       - Device unit number.
 * @param [in]     hw_cnt_id                  - HW counter Id.
 * @param [in]     mode                       - Counter mode.
 * @param [out]    ptr_bank_id                - The HW bank Id of the corresponding counter.
 * @param [out]    ptr_sw_bmap_idx_of_bank    - The index the corresponding counter in the bank.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters.
 */
clx_error_no_t
hal_mt_kg_stat_pp_bank_id_get(const uint32 unit,
                              const uint32 hw_cnt_id,
                              const clx_stat_srv_cnt_mode_t mode,
                              uint32 *ptr_bank_id,
                              uint32 *ptr_sw_bmap_idx_of_bank);

/**
 * @brief To free index from a bitmap array.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    cnt_type      - Counter type.
 * @param [in]    hw_cnt_idx    - HW counter idx in HW table.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameters.
 */
clx_error_no_t
hal_mt_kg_stat_cnt_hw_idx_free(const uint32 unit,
                               const hal_stat_hw_type_t cnt_type,
                               const uint32 hw_cnt_idx);

/**
 * @brief This API is used to get value of the counter under study.
 *
 * The number of counters value return is determined by the type of counter under study.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     cnt_id     - Counter ID.
 * @param [out]    ptr_cnt    - The return counter values.
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
clx_error_no_t
hal_mt_kg_stat_cnt_get(const uint32 unit, const uint32 cnt_id, clx_stat_srv_cnt_t *ptr_cnt);

/**
 * @brief This API is used to clear value of the counter under study.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    cnt_id    - Counter ID.
 * @return        CLX_E_OK                 - Success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
clx_error_no_t
hal_mt_kg_stat_cnt_clear(const uint32 unit, const uint32 cnt_id);

/**
 * @brief This API is used to get value of the counter under study.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     rx_reason_code    - Rx reason code.
 * @param [out]    ptr_cnt           - The return counter values.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_stat_reason_cnt_get(const uint32 unit,
                              const clx_pkt_rx_reason_t rx_reason_code,
                              uint64 *ptr_cnt);

/**
 * @brief This API is used to clear value of the counter under study.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    rx_reason_code    - Rx reason code.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_stat_reason_cnt_clear(const uint32 unit, const clx_pkt_rx_reason_t rx_reason_code);

/**
 * @brief This API is used to get value of the drop reason counter under study.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     rsn_code    - Reason code.
 * @param [out]    ptr_cnt     - The return counter values.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_mt_kg_stat_drop_reason_cnt_get(const uint32 unit, const uint32 rsn_code, uint64 *ptr_cnt);

/**
 * @brief This API is used to clear value of the drop reason counter under study.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    rsn_code    - Reason code.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_mt_kg_stat_drop_reason_cnt_clear(const uint32 unit, const uint32 rsn_code);

/**
 * @brief This API is used to get value of the counter under study.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     rsn_code    - Reason code.
 * @param [out]    ptr_cnt     - The return counter values.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_mt_kg_stat_hw_reason_cnt_get(const uint32 unit, const uint32 rsn_code, uint64 *ptr_cnt);

/**
 * @brief This API is used to clear value of the counter under study.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    rsn_code    - Reason code.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_mt_kg_stat_hw_reason_cnt_clear(const uint32 unit, const uint32 rsn_code);

/**
 * @brief This API is used to get TM queue counter index by TM handler.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     handler    - The handler of TM queue.
 * @param [out]    ptr_idx    - Queue counter index.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_stat_queue_cnt_idx_get(const uint32 unit,
                                 const clx_tm_handler_t handler,
                                 uint32 *ptr_idx);

/**
 * @brief This API is used to get port rate type from port cnt type.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     type         - The type of port cnt.
 * @param [out]    rate_type    - The type of traffic rate.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_stat_port_rate_type_get(const uint32 unit,
                                  const clx_stat_port_t type,
                                  clx_stat_rate_type_t *rate_type);

#ifdef CLX_STAT_EN_HPC_CNT
/**
 * @brief This API is used to create HPC counter.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    cfg     - Cfg with polling time and FIFO size.
 * @return        CLX_E_OK                - Operation success.
 * @return        CLX_E_ALREADY_INITED    - Already initialized.
 * @return        CLX_E_BAD_PARAMETER     - Bad parameter.
 * @return        CLX_E_NO_MEMORY         - No memory.
 * @return        CLX_E_OTHERS            - Other error.
 */
clx_error_no_t
hal_mt_kg_stat_hpc_create(const uint32 unit, const clx_stat_hpc_cfg_t cfg);

/**
 * @brief This API is used to destroy HPC counter.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - Not initialized.
 */
clx_error_no_t
hal_mt_kg_stat_hpc_destroy(const uint32 unit);

clx_error_no_t
hal_mt_kg_stat_hpc_dequeue(const uint32 unit, clx_stat_hpc_cnt_t *ptr_hpc_cnt_node);
#endif /* End of CLX_STAT_EN_HPC_CNT */
#endif /* End of HAL_MT_KG_STAT_H */
