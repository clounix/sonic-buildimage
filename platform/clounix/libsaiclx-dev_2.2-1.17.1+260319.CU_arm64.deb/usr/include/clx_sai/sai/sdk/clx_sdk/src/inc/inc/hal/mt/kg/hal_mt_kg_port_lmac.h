/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
/* FILE NAME:  hal_mt_kg_port_lmac.h
 * PURPOSE:
 *      It provide HAL PORT LMAC module API.
 * NOTES:
 */

#ifndef __HAL_MT_KG_PORT_LMAC_H__
#define __HAL_MT_KG_PORT_LMAC_H__

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef enum hal_mt_kg_port_lmac_fec_type_e {
    HAL_MT_KG_PORT_LMAC_FEC_NOFEC = 0,      /**< 3'b000: NOFEC */
    HAL_MT_KG_PORT_LMAC_FEC_RS_544 = 1,     /**< 3'b001: RS(544,514) */
    HAL_MT_KG_PORT_LMAC_FEC_RS_272 = 2,     /**< 3'b010: RS(272, 257+1) */
    HAL_MT_KG_PORT_LMAC_FEC_RS_528 = 3,     /**< 3'b011: RS(528, 514) */
    HAL_MT_KG_PORT_LMAC_FEC_FC = 4,         /**< 3'b100: FC(2112,2080) */
    HAL_MT_KG_PORT_LMAC_FEC_RS_544_INT = 5, /**< 3'b101: RS(544,514)-int */
    HAL_MT_KG_PORT_LMAC_FEC_RS_272_INT = 6, /**< 3'b110: RS(272, 257+1)-int */
    HAL_MT_KG_PORT_LMAC_FEC_RS_528_INT = 7, /**< 3'b111: RS(528, 514)-int */
} hal_mt_kg_port_lmac_fec_type_t;

typedef enum hal_mt_kg_port_lmac_chmod_speed_type_e {
    HAL_MT_KG_PORT_LMAC_CHMOD_SPEED_DISABLE = 0,
    HAL_MT_KG_PORT_LMAC_CHMOD_SPEED_400G = 1,
    HAL_MT_KG_PORT_LMAC_CHMOD_SPEED_200G = 2,
    HAL_MT_KG_PORT_LMAC_CHMOD_SPEED_100G = 3,
    HAL_MT_KG_PORT_LMAC_CHMOD_SPEED_50G = 4,
    HAL_MT_KG_PORT_LMAC_CHMOD_SPEED_40G = 5,
    HAL_MT_KG_PORT_LMAC_CHMOD_SPEED_25G = 6,
    HAL_MT_KG_PORT_LMAC_CHMOD_SPEED_10G = 7,
} hal_mt_kg_port_lmac_chmod_speed_type_t;

typedef struct hal_mt_kg_port_lmac_chmode_cfg_s {
    uint32 port_speed;  // 1: 400G 2: 200G 3: 100G 4: 50G 5: 40G 6: 25G 7: 10G 0: disable; default
                        // value: 0x0
    uint32 lane_number; // 0: disable 1: 1 lane 2: 2 lane 3: 4 lane 4: 8 lane; default value: 0x0
    uint32 fec_mode; // 0: NOFEC 1: RS(544,514) 2: RS(272, 257+1) 3: RS(528, 514) 4: FC(2112,2080)
                     // 5: RS(544,514)-int 6: RS(272, 257+1)-int 7: RS(528, 514)-int, default value:
                     // 0x0
    uint32 txswrstn; // 1'b0 TX Reset Active 1'b1 TX Normal Operation, default value: 0x0
    uint32 rxswrstn; // 1'b0 RX Reset Active 1'b1 RX Normal Operation, default value: 0x0
    uint32 txen;     // 1'b1 TX Normal Operation 1'b0 TX Channel Disabled, default value: 0x1
    uint32 txdrain;  // Setting this bit causes transmit path to enter into Drain mode where all the
                     // data from the TXFIFO is drained out, default value: 0x0
    uint32 rxen;     // 1'b1 RX Normal Operation 1'b0 RX Channel Disabled, default value: 0x1
    uint32 gmiilpbk; // Setting this bit enables the Loopback on the MAC-PCS Interface for this
                     // Channel. default value: 0x0
    uint32 txjabber; // This field determines the Jabber Size for the outgoing(Transmit) frames on
                     // this Channel. default value: 0x640
    uint32 rxjabber; // This field determines the Jabber Size for the incoming (Receive) frames on
                     // this Channel. default value: 0x640
    uint32 hasfcs;   // has FCS in the Transmit packet. 0: not has fcs, mac tx will pad good FCS. 1:
                     // has FCS. default value: 0x0
    uint32 repfcs;   // replace the Transmit FCS. default value: 0x0
    uint32 ignfcs;   // Ignore the FCS on received frames, default value: 0x0
    uint32 stripfcs; // Strips the FCS of received frames before they are forwarded to the
                     // application, default value: 0x0
    uint32 ifglen;   // bit57 indicate fix ipg-0 or DIC-1, bit56 to bit 51 Selects the minimum IFG
                     // length in bytes inserted on transmit frames, default value: 0xc

#define HAL_MT_KG_PORT_LMAC_CHMODE_PORT_SPEED  (1 << 0)
#define HAL_MT_KG_PORT_LMAC_CHMODE_LANE_NUMBER (1 << 1)
#define HAL_MT_KG_PORT_LMAC_CHMODE_FEC_MODE    (1 << 2)
#define HAL_MT_KG_PORT_LMAC_CHMODE_TXSWRSTN    (1 << 3)
#define HAL_MT_KG_PORT_LMAC_CHMODE_RXSWRSTN    (1 << 4)
#define HAL_MT_KG_PORT_LMAC_CHMODE_TXEN        (1 << 5)
#define HAL_MT_KG_PORT_LMAC_CHMODE_TXDRAIN     (1 << 6)
#define HAL_MT_KG_PORT_LMAC_CHMODE_RXEN        (1 << 7)
#define HAL_MT_KG_PORT_LMAC_CHMODE_GMIILPBK    (1 << 8)
#define HAL_MT_KG_PORT_LMAC_CHMODE_TXJABBER    (1 << 9)
#define HAL_MT_KG_PORT_LMAC_CHMODE_RXJABBER    (1 << 10)
#define HAL_MT_KG_PORT_LMAC_CHMODE_HASFCS      (1 << 11)
#define HAL_MT_KG_PORT_LMAC_CHMODE_REPFCS      (1 << 12)
#define HAL_MT_KG_PORT_LMAC_CHMODE_IGNFCS      (1 << 13)
#define HAL_MT_KG_PORT_LMAC_CHMODE_STRIPFCS    (1 << 14)
#define HAL_MT_KG_PORT_LMAC_CHMODE_IFGLEN      (1 << 15)
#define HAL_MT_KG_PORT_LMAC_CHMODE_LAST        (1 << 16)
#define HAL_MT_KG_PORT_LMAC_CHMODE_ALL         (HAL_MT_KG_PORT_LMAC_CHMODE_LAST - 1)
    uint32 flag;
} hal_mt_kg_port_lmac_chmode_cfg_t;

typedef struct hal_mt_kg_port_lmac_chsts_s {
    uint32 txclkpresentall;
    uint32 rxclkpresentall;
    uint32 rxsigokall;
    uint32 blocklockall;
    uint32 amlockall;
    uint32 aligned;
    uint32 nohiber;
    uint32 nolocalfault;
    uint32 noremotefault;
    uint32 linkup;

#define HAL_MT_KG_PORT_LMAC_CHSTS_TXCLKPRESENTALL (1UL << 0)
#define HAL_MT_KG_PORT_LMAC_CHSTS_RXCLKPRESENTALL (1UL << 1)
#define HAL_MT_KG_PORT_LMAC_CHSTS_RXSIGOKALL      (1UL << 2)
#define HAL_MT_KG_PORT_LMAC_CHSTS_BLOCKLOCKALL    (1UL << 3)
#define HAL_MT_KG_PORT_LMAC_CHSTS_AMLOCKALL       (1UL << 4)
#define HAL_MT_KG_PORT_LMAC_CHSTS_ALIGNED         (1UL << 5)
#define HAL_MT_KG_PORT_LMAC_CHSTS_NOHIBER         (1UL << 6)
#define HAL_MT_KG_PORT_LMAC_CHSTS_NOLOCALFAULT    (1UL << 7)
#define HAL_MT_KG_PORT_LMAC_CHSTS_NOREMOTEFAULT   (1UL << 8)
#define HAL_MT_KG_PORT_LMAC_CHSTS_LINKUP          (1UL << 9)
#define HAL_MT_KG_PORT_LMAC_CHSTS_LAST            (1UL << 10)
#define HAL_MT_KG_PORT_LMAC_CHSTS_ALL             (HAL_MT_KG_PORT_LMAC_CHSTS_LAST - 1)
    uint32 flag;
} hal_mt_kg_port_lmac_chsts_t;

typedef struct hal_mt_kg_port_lmac_chconfig3_cfg_s {
    uint32 txpreamble;       /* TX preamble configuration */
    uint32 txdrainonfault;   /* TX drain on fault */
    uint32 rxpreamble;       /* RX preamble configuration */
    uint32 exclpfcglblstats; /* Exclude PFC global statistics */

/* CHCONFIG3 related definitions */
#define HAL_MT_KG_PORT_LMAC_CHCONFIG3_TXPREAMBLE       (1UL << 0)
#define HAL_MT_KG_PORT_LMAC_CHCONFIG3_TXDRAINONFAULT   (1UL << 1)
#define HAL_MT_KG_PORT_LMAC_CHCONFIG3_RXPREAMBLE       (1UL << 2)
#define HAL_MT_KG_PORT_LMAC_CHCONFIG3_EXCLPFCGLBLSTATS (1UL << 3)
#define HAL_MT_KG_PORT_LMAC_CHCONFIG3_LAST             (1UL << 4)
    uint32 flag; /* Indicate which fields are valid */
} hal_mt_kg_port_lmac_chconfig3_cfg_t;

typedef struct hal_mt_kg_port_lmac_chconfig4_cfg_s {
    uint32 macaddr[2];  /* MAC address */
    uint32 pauseontime; /* Pause on time */

/* CHCONFIG34 related definitions */
#define HAL_MT_KG_PORT_LMAC_CHCONFIG4_MACADDR     (1UL << 0)
#define HAL_MT_KG_PORT_LMAC_CHCONFIG4_PAUSEONTIME (1UL << 1)
#define HAL_MT_KG_PORT_LMAC_CHCONFIG4_LAST        (1UL << 2)
    uint32 flag; /* Indicate which fields are valid */
} hal_mt_kg_port_lmac_chconfig4_cfg_t;

typedef struct hal_mt_kg_port_lmac_maccfg_cfg_s {
    uint32 disfcsonerr;      /* Disable FCS on error */
    uint32 txfcen;           /* TX flow control enable */
    uint32 rxfcen;           /* RX flow control enable */
    uint32 rxfctotx;         /* RX flow control to TX */
    uint32 rxfilterfc;       /* RX filter flow control */
    uint32 rxfilterpfc;      /* RX filter PFC */
    uint32 txpadrunt;        /* TX pad runt */
    uint32 txrdthresh;       /* TX read threshold */
    uint32 txlfault;         /* TX local fault */
    uint32 txrfault;         /* TX remote fault */
    uint32 txidle;           /* TX idle */
    uint32 rxlfault;         /* RX local fault */
    uint32 rxrfault;         /* RX remote fault */
    uint32 rxidle;           /* RX idle */
    uint32 statsclr;         /* Stats clear */
    uint32 txpfcen;          /* TX PFC enable */
    uint32 rxpfcen;          /* RX PFC enable */
    uint32 txipg_credit_thr; /* TX IPG credit threshold */

/* MACCFG related definitions */
#define HAL_MT_KG_PORT_LMAC_MACCFG_DISFCSONERR      (1UL << 0)
#define HAL_MT_KG_PORT_LMAC_MACCFG_TXFCEN           (1UL << 1)
#define HAL_MT_KG_PORT_LMAC_MACCFG_RXFCEN           (1UL << 2)
#define HAL_MT_KG_PORT_LMAC_MACCFG_RXFCTOTX         (1UL << 3)
#define HAL_MT_KG_PORT_LMAC_MACCFG_RXFILTERFC       (1UL << 4)
#define HAL_MT_KG_PORT_LMAC_MACCFG_RXFILTERPFC      (1UL << 5)
#define HAL_MT_KG_PORT_LMAC_MACCFG_TXPADRUNT        (1UL << 6)
#define HAL_MT_KG_PORT_LMAC_MACCFG_TXRDTHRESH       (1UL << 7)
#define HAL_MT_KG_PORT_LMAC_MACCFG_TXLFAULT         (1UL << 8)
#define HAL_MT_KG_PORT_LMAC_MACCFG_TXRFAULT         (1UL << 9)
#define HAL_MT_KG_PORT_LMAC_MACCFG_TXIDLE           (1UL << 10)
#define HAL_MT_KG_PORT_LMAC_MACCFG_RXLFAULT         (1UL << 11)
#define HAL_MT_KG_PORT_LMAC_MACCFG_RXRFAULT         (1UL << 12)
#define HAL_MT_KG_PORT_LMAC_MACCFG_RXIDLE           (1UL << 13)
#define HAL_MT_KG_PORT_LMAC_MACCFG_STATSCLR         (1UL << 14)
#define HAL_MT_KG_PORT_LMAC_MACCFG_TXPFCEN          (1UL << 15)
#define HAL_MT_KG_PORT_LMAC_MACCFG_RXPFCEN          (1UL << 16)
#define HAL_MT_KG_PORT_LMAC_MACCFG_TXIPG_CREDIT_THR (1UL << 17)
#define HAL_MT_KG_PORT_LMAC_MACCFG_LAST             (1UL << 18)
#define HAL_MT_KG_PORT_LMAC_MACCFG_ALL              (HAL_MT_KG_PORT_LMAC_MACCFG_LAST - 1)
    uint32 flag; /* Indicate which fields are valid */
} hal_mt_kg_port_lmac_maccfg_cfg_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief LMAC chip soft reset.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    inst_msk        - Device inst mask.
 * @param [in]    sub_inst_msk    - Device sub inst mask.
 * @param [in]    state           - State.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_lmac_chip_soft_reset(uint32 unit, uint32 inst_msk, uint32 sub_inst_msk, uint32 state);

/**
 * @brief LMAC cfg umac soft_n reset.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    inst_msk        - Device inst mask.
 * @param [in]    sub_inst_msk    - Device sub inst mask.
 * @param [in]    state           - State.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_lmac_warp_cfg_umac_rst_soft_reset(uint32 unit,
                                                 uint32 inst_msk,
                                                 uint32 sub_inst_msk,
                                                 uint32 state);

/**
 * @brief LMAC chip config.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    inst_msk        - Device inst mask.
 * @param [in]    sub_inst_msk    - Sub-inst mask.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_lmac_chip_set(uint32 unit, uint32 inst_msk, uint32 sub_inst_msk);

/**
 * @brief LMAC port init.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Device port number.
 * @param [in]    fec      - Device fec.
 * @param [in]    speed    - Device speed.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_lmac_init(const uint32 unit,
                         const uint32 port,
                         const uint32 fec,
                         const clx_port_speed_t speed);

/**
 * @brief Deinitialize LMAC function of one port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Device port number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_deinit(uint32 unit, uint32 port);

/**
 * @brief LMAC chmode speed set.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Device port number.
 * @param [in]    speed    - Device speed.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_lmac_speed_set(uint32 unit, uint32 port, clx_port_speed_t speed);

/**
 * @brief LMAC speed get.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    port         - Device port number.
 * @param [in]    ptr_speed    - Pointer to store speed value.
 * @return        CLX_E_OK    - Operation successful.
 */
clx_error_no_t
hal_mt_kg_port_lmac_speed_get(uint32 unit, uint32 port, clx_port_speed_t *ptr_speed);

/**
 * @brief LMAC chmode fec set.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Device port number.
 * @param [in]    fec     - Device fec.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_lmac_fec_set(uint32 unit, uint32 port, uint32 fec);

/**
 * @brief LMAC fec get.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Device port number.
 * @param [out]    ptr_hal_fec    - Pointer to store FEC value.
 * @return         CLX_E_OK    - Operation successful.
 */
clx_error_no_t
hal_mt_kg_port_lmac_fec_get(uint32 unit, uint32 port, uint32 *ptr_hal_fec);

/**
 * @brief LMAC fec clear.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Device port number.
 * @return        CLX_E_OK    - Operation successful.
 */
clx_error_no_t
hal_mt_kg_port_lmac_fec_clear(const uint32 unit, const uint32 port);

/**
 * @brief LMAC loopback set.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Device port number.
 * @param [in]    enable    - Device enable.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_lmac_lb_set(const uint32 unit, const uint32 port, uint32 enable);

/**
 * @brief LMAC loopback get.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     port                - Device port number.
 * @param [out]    ptr_mac_loopback    - Device enable.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_lmac_lb_get(const uint32 unit, const uint32 port, uint32 *ptr_mac_loopback);

/**
 * @brief LMAC link interrupt clear.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_lmac_link_irq_clear(const uint32 unit, const uint32 port);

/**
 * @brief LMAC link interrupt enable set.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Port number.
 * @param [in]    enable    - Enable/disable flag.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_lmac_link_irq_en_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief LMAC link interrupt get.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Port number.
 * @param [out]    ptr_fault    - Pointer to store fault status.
 * @param [out]    ptr_lc       - Pointer to store link change status.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_lmac_irq_get(const uint32 unit, const uint32 port, uint32 *ptr_fault, uint32 *ptr_lc);

/**
 * @brief LMAC link fault status get.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Port number.
 * @param [out]    ptr_link       - Link status pointer.
 * @param [out]    ptr_l_fault    - Local fault status pointer.
 * @param [out]    ptr_r_fault    - Remote fault status pointer.
 * @param [out]    ptr_hiber      - Hiber status pointer.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_lmac_link_fault_get(const uint32 unit,
                                   const uint32 port,
                                   uint32 *ptr_link,
                                   uint32 *ptr_l_fault,
                                   uint32 *ptr_r_fault,
                                   uint32 *ptr_hiber);

/**
 * @brief To set port pause.
 *
 * @param [in]    unit         - Chip id.
 * @param [in]    port         - Port id.
 * @param [in]    flow_ctrl    - Flow control type.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_pause_set(const uint32 unit,
                              const uint32 port,
                              const clx_port_fc_dir_t flow_ctrl);

/**
 * @brief To get port pause.
 *
 * @param [in]     unit             - Chip id.
 * @param [in]     port             - Port id.
 * @param [out]    ptr_flow_ctrl    - Flow control type.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_pause_get(const uint32 unit,
                              const uint32 port,
                              clx_port_fc_dir_t *ptr_flow_ctrl);

/**
 * @brief To set the PFC configuration for a specific port.
 *
 * @param [in]    unit    - Chip id.
 * @param [in]    port    - Port id.
 * @param [in]    pfc     - PFC control type.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_pfc_set(const uint32 unit, const uint32 port, const clx_port_fc_dir_t pfc);

/**
 * @brief LMAC pfc get.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Device port number.
 * @param [in]     pri        - Priority.
 * @param [out]    ptr_pfc    - PFC control direction.
 * @return         CLX_E_OK    - Operation successful.
 */
clx_error_no_t
hal_mt_kg_port_lmac_pfc_get(const uint32 unit,
                            const uint32 port,
                            const uint8 pri,
                            clx_port_fc_dir_t *ptr_pfc);

/**
 * @brief This API is used to set the MAC address for a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @param [in]    mac     - The MAC address.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_lmac_addr_set(const uint32 unit, const uint32 port, const clx_mac_t mac);

/**
 * @brief This API is used to get the MAC address for a specific port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port ID.
 * @param [out]    ptr_mac    - The MAC address.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_lmac_addr_get(const uint32 unit, const uint32 port, clx_mac_t *ptr_mac);

/**
 * @brief This API is used to set the FIFO threshold for a specific port.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port ID.
 * @param [in]    speed    - Speed.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_fifo_thrd_set(const uint32 unit,
                                  const uint32 port,
                                  const clx_port_speed_t speed);

/**
 * @brief This API is used to check the LMAC MIB memory initialization status.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    plane       - Plane.
 * @param [in]    macro_id    - Macro ID.
 * @return        CLX_E_OK         - Operate success.
 * @return        CLX_E_TIMEOUT    - Operate timeout.
 */
clx_error_no_t
hal_mt_kg_port_lmac_mib_mem_check(const uint32 unit, uint32 plane, uint32 macro_id);

/**
 * @brief This API is used to set the LMAC tx reset state.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port ID.
 * @param [in]    state    - Reset state.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_lmac_admin_txrst_set(const uint32 unit, const uint32 port, const uint32 state);

/**
 * @brief This API is used to set the LMAC rx reset state.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port ID.
 * @param [in]    state    - Reset state.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_lmac_admin_rxrst_set(const uint32 unit, const uint32 port, const uint32 state);

/**
 * @brief This API is used to set the LMAC tx enable state.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port ID.
 * @param [in]    state    - Enable state.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_lmac_admin_txen_set(const uint32 unit, const uint32 port, const uint32 state);

/**
 * @brief This API is used to set the LMAC rx enable state.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port ID.
 * @param [in]    state    - Enable state.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_lmac_admin_rxen_set(const uint32 unit, const uint32 port, const uint32 state);

/**
 * @brief This API is used to get the register list for lmac.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [in]     reg_info    - Register info.
 * @param [out]    reg_info    - Register info.
 * @return         CLX_E_OK        - The operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_kg_port_lmac_dbg_reg_list_get(const uint32 unit, const uint32 port, uint32 *reg_info);
/**
 * @brief This API is used to set the IFG length for a specific port.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Physical port ID.
 * @param [in]    ifg_len    - IFG length.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_ifg_len_set(const uint32 unit, const uint32 port, const uint32 ifg_len);

/**
 * @brief This API is used to get the IFG length for a specific port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port ID.
 * @param [out]    ifg_len    - IFG length.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_ifg_len_get(const uint32 unit, const uint32 port, uint32 *ifg_len);

/**
 * @brief Set the RX idle for a specific port.
 *
 * @param [in]    unit      - Chip id.
 * @param [in]    port      - Port id.
 * @param [in]    enable    - Enable or disable RX idle.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_rxidle_set(const uint32 unit, const uint32 port, uint32 enable);

/**
 * @brief Get the RX idle for a specific port.
 *
 * @param [in]    unit       - Chip id.
 * @param [in]    port       - Port id.
 * @param [in]    rx_idle    - Enable or disable RX idle.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_rxidle_get(const uint32 unit, const uint32 port, uint32 *rx_idle);

/**
 * @brief Set the MIB max length for a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port id.
 * @param [in]    len     - MIB max length.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_mib_max_len_set(const uint32 unit, const uint32 port, const uint32 len);

/**
 * @brief Set the TX drain for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - Enable/Disable TX drain.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_tx_drain_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Set the PAUSE TX enable for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - Enable/Disable PAUSE TX.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_lfc_tx_en_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Set the PFC TX enable for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - Enable/Disable PFC TX.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_pfc_tx_en_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Set the CRC replace for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - Enable/Disable CRC replace.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_crc_replace_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Set the TX drain on fault for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - Enable/Disable TX drain on fault.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_tx_drain_on_fault_set(const uint32 unit,
                                          const uint32 port,
                                          const uint32 enable);

/**
 * @brief Get the CRC replace for a specific port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [out]    ptr_enable    - CRC replace enable.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_crc_replace_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief Set rx ignore FCS for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - Enable/Disable rx ignore FCS.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_rx_ignfcs_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Get rx ignore FCS for a specific port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [out]    ptr_enable    - Rx ignore FCS enable.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_rx_ignfcs_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief Get the MAC configuration for a specific port.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port id.
 * @param [out]    ptr_mac_cfg    - MAC configuration value.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_cfg_get(const uint32 unit, const uint32 port, clx_port_mac_cfg_t *ptr_mac_cfg);

/**
 * @brief Get the MAC status for a specific port.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port id.
 * @param [out]    ptr_mac_sts    - MAC status value.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_stat_get(const uint32 unit, const uint32 port, clx_port_mac_sts_t *ptr_mac_sts);

/**
 * @brief Set laneswap.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Port.
 * @param [in]    lane_cnt        - Lane count.
 * @param [in]    channel_gap     - Gap of channels.
 * @param [in]    ptr_laneswap    - Value of laneswap.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_lmac_laneswap_set(const uint32 unit,
                                 const uint32 port,
                                 const uint32 lane_cnt,
                                 const uint32 channel_gap,
                                 hal_mt_kg_port_laneswap_t *ptr_laneswap);

/**
 * @brief Get laneswap info.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Port.
 * @param [out]    ptr_laneswap    - Ptr value of laneswap.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_lmac_laneswap_info_get(uint32 unit,
                                      uint32 port,
                                      hal_mt_kg_port_laneswap_t *ptr_laneswap);

/**
 * @brief Set the IRQ link down for a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port id.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_lmac_link_down_irq_set(const uint32 unit, const uint32 port);
/**
 * @brief Get the signal OK for a specific port.
 *
 * This function gets the signal OK for a specific port.
 *
 * @param [in]     unit         - Chip id.
 * @param [in]     port         - Physical port id.
 * @param [out]    signal_ok    - Signal OK value.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_lmac_signal_get(const uint32 unit, const uint32 port, uint32 *signal_ok);
#endif /* #ifndef __HAL_MT_KG_PORT_LMAC_H__ */
