/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_l3_llm.h
 * PURPOSE:
 *    Provide HAL driver API functions for L3 LLM module.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_KG_L3_LLM_H
#define HAL_MT_KG_L3_LLM_H

/* INCLUDE FILE DECLARATIONS */

#include <string.h>
#include <clx/clx_types.h>
#include <clx/clx_l3.h>
#include <hal/hal_l3.h>
#include <util/util.h>
#include <hal/hal_io.h>
#include <hal/mt/kg/hal_mt_kg_l3.h>

#define LLM_TCAM_SIZE  (1024)             /* hw resource */
#define LLM_ENTRY_SIZE (1024)             /* low latency mode entry count */
#define ULM_ENTRY_SIZE (512)              /* ultra low latency mode entry count  */

#define IPV4_ULM_ADJ_OFFSET  (512)        /* ipv4 low latency mode tcam offset */
#define IPV4_LLM_TCAM_OFFSET (4096)       /* ipv4 low latency mode tcam offset */
#define IPV4_ULM_TCAM_OFFSET (4096 + 512) /* ipv4 ultra low latency mode tcam offset */

#define ADJ_INDEX_MAX_SIZE (1024)         /* adj index bitmap size */
#define ADJ_INDEX_BMP_SIZE (32)           /* adj index bitmap size */

#define LLM_LPM_V4_PREFIX_NUM (33)        /* lpm v4 prefix number */
#define LLM_LPM_V6_PREFIX_NUM (129)       /* lpm v6 prefix number */

#define LLM_LPM_MOVE_THRESHOLD (512)      /* move lpm to hash threshold */

#define L3_LLM_ERRO(...) HAL_L3_ERRO(LLM, ##__VA_ARGS__)
#define L3_LLM_WARN(...) HAL_L3_WARN(LLM, ##__VA_ARGS__)
#define L3_LLM_INFO(...) HAL_L3_INFO(LLM, ##__VA_ARGS__)

#define LLM_ENTRY_VLD_CHK(entry_idx)         ((entry_idx & 0xc0000000) >> 30)
#define LLM_ENTRY_TYPE_GET(entry_idx)        ((entry_idx & 0xc0000000) >> 30)
#define LLM_ENTRY_INDEX_GET(entry_idx)       (entry_idx & 0x3FFFFFFF)
#define LLM_ENTRY_VLD_CLR(entry_idx)         (entry_idx &= ~0xc0000000)
#define LLM_ENTRY_HASH_SET(entry_idx, index) (entry_idx = (index & 0x3FFFFFFF) | 0x40000000)
#define LLM_ENTRY_TCAM_SET(entry_idx, index) (entry_idx = (index & 0x3FFFFFFF) | 0x80000000)
/*-----------------------------------------------------------------------------
 *  priority structure
 *-----------------------------------------------------------------------------*/
typedef enum hal_mt_kg_l3_llm_type_e {
    HAL_LLM_L3_TYPE_LPM,
    HAL_LLM_L3_TYPE_HOST,
    HAL_LLM_L3_TYPE_MGI,
    HAL_LLM_L3_TYPE_LAST
} hal_mt_kg_l3_llm_type_t;

typedef enum hal_mt_kg_l3_llm_entry_type_e {
    HAL_LLM_ENTRY_TYPE_INVALID = 0,
    HAL_LLM_ENTRY_TYPE_HASH,
    HAL_LLM_ENTRY_TYPE_TCAM,
} hal_mt_kg_l3_llm_entry_type_t;

/* priority tcam entry info */
typedef struct hal_mt_kg_l3_llm_pri_tcam_entry_s {
    hal_mt_kg_l3_llm_type_t type; /* entry type           */
    int32 prefix_len;             /* prefix length        */
    clx_l3_addr_t addr;           /* route ip address     */
    clx_nhp_t nhp;                /* save nhp info ulm    */
} hal_mt_kg_l3_llm_pri_tcam_entry_t;

/* priority tcam */
typedef struct hal_mt_kg_l3_llm_pri_tcam_s {
    hal_mt_kg_l3_llm_pri_tcam_entry_t entries[LLM_TCAM_SIZE];
    uint32 count;
} hal_mt_kg_l3_llm_pri_tcam_t;

typedef struct hal_mt_kg_l3_llm_move_info_s {
    uint32 move_count;
    uint32 move_base;
} hal_mt_kg_l3_llm_move_info_t;

/* priority hash cfg */
typedef struct hal_mt_kg_l3_llm_pri_hash_cfg_s {
    hal_mt_kg_l3_llm_type_t type; /* tile type                */
    uint32 rsrc_count;            /* rsrc count, 1x view      */
    uint32 host_v4_count;         /* host v4 entry count      */
    uint32 host_v6_count;         /* host v6 entry count      */
    uint32 lpm_v4_count;          /* lpm v4 entry count       */
    uint32 lpm_v6_count;          /* lpm v6 entry count       */
    uint32 mgi_v4_count;          /* mgi v4 entry count       */
    uint32 mgi_v6_count;          /* mgi v6 entry count       */
    uint32 v4_prefix_len;         /* v4 prefix length         */
    uint32 v6_prefix_len;         /* v6 prefix length         */
} hal_mt_kg_l3_llm_pri_hash_cfg_t;

/* priority hash */
typedef struct hal_mt_kg_l3_llm_pri_hash_s {
    hal_mt_kg_l3_llm_pri_hash_cfg_t cfg[HAL_MT_KG_L3_LPM_TILE_NUM];
    uint32 host_bmp[1];
    uint32 lpm_bmp[1];
    uint32 mgi_bmp[1];
    uint32 tile_bmp[1];
} hal_mt_kg_l3_llm_pri_hash_t;

/* priority hash */
typedef struct hal_mt_kg_l3_llm_cfg_s {
    hal_mt_kg_l3_llm_pri_tcam_t tcam_v4;
    hal_mt_kg_l3_llm_pri_tcam_t tcam_v6;
    hal_mt_kg_l3_llm_pri_hash_t hash;
    util_lib_avl_head_t *ptr_rte_avl;
    util_lib_avl_head_t *ptr_adj_avl;
    uint32 sip_enable;
    clx_lock_id_t mutex;
    uint32 adj_idx_bmp[ADJ_INDEX_BMP_SIZE];
    uint32 latency_mode;
} hal_mt_kg_l3_llm_cfg_t;

/* avl node */
typedef struct hal_mt_kg_l3_llm_rte_node_s {
    /* AVL key */
    hal_mt_kg_l3_llm_type_t entry_type; /* entry type */
    boolean vrf_vld;                    /* vrf vld          */
    uint32 vrf;                         /* vrf              */
    clx_ip_addr_t prefix;               /* ip prefix        */

    /* AVL data */
    uint32 hw_index;                   /* 2'bit type + 30bit index  */
    union {
        clx_l3_host_t host_info;       /* host information */
        clx_l3_route_t lpm_info;       /* lpm information  */
        clx_l3_mcast_route_t mgi_info; /* mgi information  */
    } rte_info;                        /* used to store route info */
    union {
        uint32 ipv4_buf[MT_KG_CDB_FPU_HSH_LPM_FIB_V4_WORDS];
        uint32 ipv6_buf[MT_KG_CDB_FPU_HSH_LPM_FIB_V6_WORDS];
    } buf; /* used to store hw hsh info */
    union {
        uint32 ipv4_buf[MT_KG_CDB_FPU_TCAM_FIB_V4_WORDS];
        uint32 ipv6_buf[MT_KG_CDB_FPU_TCAM_FIB_V6_4X_WORDS];
    } tcam_buf; /* used to store tcam info */
    union {
        uint32 ip_buf[MT_KG_CDB_FPU_RSLT_FIB_WORDS];
        uint32 adj_buf[MT_KG_CDB_FPU_RSLT_ULTRA_ULTRA_LOW_LATENCY_L3_ADJ_WORDS];
    } rslt_buf; /* used to store result info */
} hal_mt_kg_l3_llm_rte_node_t;

/* inertnal trav cookie */
typedef struct hal_mt_kg_l3_llm_rte_trav_internal_cookie_s {
    uint32 unit;
    boolean ipv4;
    boolean is_increase;
    uint32 move_base;
    uint32 move_step;
} hal_mt_kg_l3_llm_rte_trav_internal_cookie_t;

/* inertnal trav cookie */
typedef struct hal_mt_kg_l3_llm_rte_adj_internal_cookie_s {
    uint32 unit;
    uint32 ori_adj;
    uint32 adj_buf[MT_KG_CDB_FPU_RSLT_ULTRA_ULTRA_LOW_LATENCY_L3_ADJ_WORDS];
} hal_mt_kg_l3_llm_rte_adj_internal_cookie_t;

/* inertnal trav cookie */
typedef struct hal_mt_kg_l3_llm_rte_cookie_s {
    hal_mt_kg_l3_llm_type_t entry_type;
    util_lib_list_t *ptr_list; /* user list */
} hal_mt_kg_l3_llm_rte_cookie_t;

/* node operation */
typedef enum hal_mt_kg_l3_llm_node_op_e {
    HAL_LLM_L3_NODE_OP_ADD,
    HAL_LLM_L3_NODE_OP_DEL,
    HAL_LLM_L3_NODE_OP_GET,
    HAL_LLM_L3_NODE_OP_UPDATE,
    HAL_LLM_L3_NODE_OP_LAST
} hal_mt_kg_l3_llm_node_op_t;

/* adj rsrc */
typedef struct hal_mt_kg_l3_llm_adj_rsrc_s {
    uint32 bdid;       /* bdid        */
    uint32 dst_idx;    /* dst idx     */
    uint32 dst_mac[2]; /* dst mac     */
    uint32 adj_buf[MT_KG_CDB_FPU_RSLT_ULTRA_LOW_LATENCY_L3_ADJ_WORDS];
} hal_mt_kg_l3_llm_adj_rsrc_t;

/* adj node */
typedef struct hal_mt_kg_l3_llm_adj_node_s {
    /* AVL key */
    uint32 adj_id; /* adj id       */

    /* AVL data */
    uint32 hw_index;       /* hw index     */
    clx_l3_adj_t adj_info; /* adj info     */
} hal_mt_kg_l3_llm_adj_node_t;
/*-----------------------------------------------------------------------------
 *  host rsrc
 *-----------------------------------------------------------------------------*/
typedef struct hal_mt_kg_l3_llm_rsrc_s {
    hal_mt_kg_l3_llm_type_t entry_type; /* entry type */
    uint32 ipv4;
    uint32 fwd_ptr;                     /* FPU fwd_ptr            */
    uint32 dst_idx;                     /* FPU dst_idx            */
    uint32 bd_idx;                      /* FPU bd_idx             */
    uint32 dst_mac[2];                  /* FPU dst_mac            */
    uint32 hw_addr;                     /* FPU hw_addr            */
    uint32 prefix_len;                  /* real prefix_len        */
    union {
        uint32 ipv4_buf[MT_KG_CDB_FPU_HSH_LPM_FIB_V4_WORDS];
        uint32 ipv6_buf[MT_KG_CDB_FPU_HSH_LPM_FIB_V6_WORDS];
    } buf;
    union {
        uint32 ipv4_buf[MT_KG_CDB_FPU_TCAM_FIB_V4_WORDS];
        uint32 ipv6_buf[MT_KG_CDB_FPU_TCAM_FIB_V6_4X_WORDS];
    } tcam_buf;
    union {
        uint32 ip_buf[MT_KG_CDB_FPU_RSLT_FIB_WORDS];
        uint32 adj_buf[MT_KG_CDB_FPU_RSLT_ULTRA_ULTRA_LOW_LATENCY_L3_ADJ_WORDS];
    } rslt_buf;
} hal_mt_kg_l3_llm_rsrc_t;

/* LLM Route Information */
typedef struct hal_mt_kg_l3_llm_route_s {
    hal_mt_kg_l3_llm_type_t entry_type;     /* entry type */
    union {
        clx_l3_host_t *ptr_host_info;       /* host information */
        clx_l3_route_t *ptr_lpm_info;       /* lpm information */
        clx_l3_mcast_route_t *ptr_mgi_info; /* mgi information */
    } route_info;
} hal_mt_kg_l3_llm_route_t;

typedef enum hal_mt_kg_l3_llm_wbdb_e {
    HAL_LLM_L3_WBDB_PRI_TCAM_V4_CFG = 0,
    HAL_LLM_L3_WBDB_PRI_TCAM_V6_CFG,
    HAL_LLM_L3_WBDB_PRI_HSH_CFG,
    HAL_LLM_L3_WBDB_RTE_AVL,
    HAL_LLM_L3_WBDB_ADJ_AVL,
    HAL_LLM_L3_WBDB_ADJ_IDX_BMP,
    HAL_LLM_L3_WBDB_LAST
} hal_mt_kg_l3_llm_wbdb_t;
/*-----------------------------------------------------------------------------
 *  api declaration
 *-----------------------------------------------------------------------------*/
clx_error_no_t
hal_mt_kg_l3_llm_deinit(uint32_t unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_kg_l3_llm_init(uint32_t unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_kg_l3_llm_route_add(const uint32 unit, const hal_mt_kg_l3_llm_route_t *ptr_route);

clx_error_no_t
hal_mt_kg_l3_llm_route_del(const uint32 unit, const hal_mt_kg_l3_llm_route_t *ptr_route);

clx_error_no_t
hal_mt_kg_l3_llm_route_get(const uint32 unit, hal_mt_kg_l3_llm_route_t *ptr_route);

clx_error_no_t
hal_mt_kg_l3_llm_route_list_get(const uint32 unit,
                                util_lib_list_t *ptr_list,
                                hal_mt_kg_l3_llm_type_t type);
clx_error_no_t
hal_mt_kg_l3_llm_adj_list_get(const uint32 unit, util_lib_list_t *ptr_list);

clx_error_no_t
hal_mt_kg_l3_llm_adj_add(const uint32 unit, clx_l3_adj_t *ptr_adj);

clx_error_no_t
hal_mt_kg_l3_llm_adj_del(const uint32 unit, const uint32 adj_id);

clx_error_no_t
hal_mt_kg_l3_llm_adj_get(const uint32 unit, clx_l3_adj_t *ptr_adj);

clx_error_no_t
hal_mt_kg_l3_llm_adj_capacity_get(const uint32 unit, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_kg_l3_llm_adj_usage_get(const uint32 unit, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_kg_l3_llm_adj_db_dump(const uint32 unit);
#endif /* End of HAL_MT_KG_L3_LLM_H */
