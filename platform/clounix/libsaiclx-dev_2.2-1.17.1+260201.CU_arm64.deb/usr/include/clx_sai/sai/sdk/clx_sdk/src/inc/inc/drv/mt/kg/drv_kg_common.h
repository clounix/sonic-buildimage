#ifndef __DRV_KG_COMMON_H__
#define __DRV_KG_COMMON_H__

#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <drv/drv.h>

clx_error_no_t
drv_kg_common_dma_cb_update(drv_dma_t **dma_drv);
clx_error_no_t
drv_kg_common_io_cb_update(drv_io_t **io_drv);
#endif // __DRV_KG_COMMON_H__