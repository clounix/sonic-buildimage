/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_FDB_H__)
#define __CLX_SAI_FDB_H__
#include "uthash.h"

/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define MAX_MAC_STR_LEN                 20
#define CLXS_FDB_DB(__unit__) (ptr_clxs_fdb_db[(__unit__)])
#define CLXS_FDB_LOCK(__unit__)   \
        osal_semaphore_take(&ptr_clxs_fdb_db[(__unit__)]->semaphore, CLX_SEMAPHORE_WAIT_FOREVER)
#define CLXS_FDB_UNLOCK(__unit__) \
        osal_semaphore_give(&ptr_clxs_fdb_db[(__unit__)]->semaphore)

#define CLXS_FDB_LRN_LIMIT_LOCK(__unit__)   \
        osal_semaphore_take(&ptr_clxs_fdb_db[(__unit__)]->semaphore_lrn_limit, CLX_SEMAPHORE_WAIT_FOREVER)
#define CLXS_FDB_LRN_LIMIT_UNLOCK(__unit__) \
        osal_semaphore_give(&ptr_clxs_fdb_db[(__unit__)]->semaphore_lrn_limit)

/*******************************************************************************
 * Data Type Definitions
 *******************************************************************************/

/* FDB learning limit structure */
typedef struct clxs_fdb_lrn_limit_s
{
    char                    key[MAX_KEY_STR_LEN]; /*  hash key, use "object_id" string */
    sai_object_id_t         oid;                  /*  object ID */
    uint32_t                lrn_max;              /*  Maximum number of learned addresses */
    uint32_t                count;                /*  Current learned count */
    bool                    limit_enable;         /*  Whether limit is enabled */
    sai_packet_action_t     violation_action;     /*  Action when learning limit is violated */
    bool                    limit_logged;         /*  Log flag to prevent duplicate logging */
    UT_hash_handle          hh;                   /*  hash handle */
} clxs_fdb_lrn_limit_t;

typedef struct clxs_fdb_bridge_port_hash_entry_s
{
    uint32_t                gport;            /*  hash key */
    sai_object_id_t         bridge_port_oid;  /*  bridge port object ID */
    UT_hash_handle          hh;               /*  hash handle */
} clxs_fdb_bridge_port_hash_entry_t;

typedef struct clxs_fdb_db_entry_s
{
    clx_bridge_domain_t     bdid; /* key */
    clx_mac_t               mac;  /* key */
    clx_port_t              port;
    clxs_fdb_entry_attrs_t  attr_info;
} clxs_fdb_db_entry_t;

/* module data base */
typedef struct clxs_fdb_db_s
{
    util_lib_avl_head_t               *fdb_entry_avl;
    clx_semaphore_id_t                semaphore;
    clxs_fdb_lrn_limit_t              *lrn_limit;
    clx_semaphore_id_t                semaphore_lrn_limit;
    clxs_fdb_bridge_port_hash_entry_t *bridge_port_hash;
} clxs_fdb_db_t;

typedef struct clxs_fdb_switchover_cookie_s
{
    clx_port_t  orig_gport;
    clx_port_t  target_gport;
} clxs_fdb_switchover_cookie_t;

/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_fdb_api_t              fdb_api;
extern clxs_fdb_db_t* ptr_clxs_fdb_db[CLXS_MAX_CHIP_NUM];


/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t
clxs_fdb_init(
    _In_ const uint32_t unit);

sai_status_t
clxs_fdb_deinit(
    _In_ const uint32_t unit);

sai_status_t
clxs_fdb_register_callback(
    _In_ const uint32_t unit,
    _In_ void *ptr_func);

/**
 * brief Set learning limit for any object (bridge port, VLAN, switch)
 *
 * param[in] unit Unit ID
 * param[in] object_id Object ID (bridge port, VLAN, or switch)
 * param[in] max_learned_addresses Maximum learned addresses
 * param[in] limit_enabled Whether limit is enabled
 *
 * return #SAI_STATUS_SUCCESS on success Failure status code on error
 */
sai_status_t
clxs_fdb_set_lrn_limit(
    _In_ const uint32_t unit,
    _In_ const sai_object_id_t object_id,
    _In_ const uint32_t max_learned_addresses,
    _In_ const bool limit_enabled);

/**
 * brief Set learning limit violation packet action for bridge port
 *
 * Note: This function is specifically for bridge port objects only.
 * VLAN and switch level objects do not support this attribute.
 *
 * param[in] unit Unit ID
 * param[in] bridge_port_id Bridge port object ID
 * param[in] violation_action Packet action when learning limit is violated
 *
 * return #SAI_STATUS_SUCCESS on success Failure status code on error
 */
sai_status_t
clxs_fdb_set_lrn_limit_violation_action(
    _In_ const uint32_t unit,
    _In_ const sai_object_id_t bridge_port_id,
    _In_ const sai_packet_action_t violation_action);


/**
 * brief Add bridge port gport hash entry
 *
 * param[in] unit Unit ID
 * param[in] bridge_port_oid Bridge port object ID
 * param[in] gport Global port ID
 *
 * return #SAI_STATUS_SUCCESS on success Failure status code on error
 */
sai_status_t
clxs_fdb_add_bridge_port_hash(
    _In_ const uint32_t unit,
    _In_ const sai_object_id_t bridge_port_oid,
    _In_ const clx_gport_t gport);

/**
 * brief Remove bridge port gport hash entry
 *
 * param[in] unit Unit ID
 * param[in] bridge_port_oid Bridge port object ID
 * param[in] gport Global port ID
 *
 * return #SAI_STATUS_SUCCESS on success Failure status code on error
 */
sai_status_t
clxs_fdb_remove_bridge_port_hash(
    _In_ const uint32_t unit,
    _In_ const sai_object_id_t bridge_port_oid,
    _In_ const clx_gport_t gport);

sai_status_t
clxs_fdb_set_switchover(
    _In_ const uint32_t unit,
    _In_ const clx_gport_t orig_gport,
    _In_ const clx_gport_t target_gport);
#endif /* __CLX_SAI_FDB_H__ */
