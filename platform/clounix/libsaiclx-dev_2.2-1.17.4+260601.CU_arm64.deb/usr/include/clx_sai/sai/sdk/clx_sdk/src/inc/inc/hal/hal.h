/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal.h
 * PURPOSE:
 *  1. Provide whole HAL resource initialization API.
 *  2. Provide HAL per-unit initialization and de-initialization function
 *     APIs.
 *  3. Provide HAL database access APIs.
 *  4. Provide a HAL multiplexing function vector.
 *
 * NOTES:
 */

#ifndef HAL_H
#define HAL_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_cfg.h>
#include <clx/clx_module.h>
#include <drv/drv.h>
#include <hal/hal_drv.h>
#include <tob/tob_tbl.h>
#include <hal/hal_intr.h>
#include <hal/hal_io.h>
#include <util/lib/util_lib_bmp.h>
#include <util/util_log.h>
#include <tob/tob.h>
#include <util/lib/util_lib_port_bmp.h>
#include <hal/hal_stk.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_DEBUG                (1)
#define HAL_MAX_DRV_CMD          (16)
#define HAL_BCAST_ADDR_OFFSET    (0x80000000)
#define HAL_BYTES_OF_WORD        (4)
#define HAL_MAX_ENTRY_WORD_SIZE  (MAX_ENTRY_SIZE / HAL_BYTES_OF_WORD)
#define HAL_INVALID_ID           (CLX_INVALID_ID)
#define HAL_ENABLE_RESOURCE_LOCK (1)
#define HAL_LOCAL_INTF_AVL       "lcl_intf_avl"
#define HAL_LOCAL_INTF_INFO_AVL  "lcl_intf_info_avl"
#define HAL_SDB_ENABLE           (0)
/* HAL support maximum MAC/SERDES macro number, \
 * may need to adjust when chip support maximum capacity change */
#define HAL_MAX_MAC_MACRO_COUNT     (64)
#define HAL_MAX_MAC_MACRO_WORD_SIZE (CLX_BITMAP_SIZE(HAL_MAX_MAC_MACRO_COUNT))
/* HAL support maximum plane port number, \
 * may need to adjust when chip support maximum capacity change
 */
#define HAL_MAX_PLANE_PORT_COUNT     (96)
#define HAL_MAX_PLANE_PORT_WORD_SIZE (CLX_BITMAP_SIZE(HAL_MAX_PLANE_PORT_COUNT))
#define HAL_MAX_CPU_PORT_COUNT       (1) /* HAL support maximum CPI port number */
#define HAL_MAX_CPI_PORT_COUNT       (2) /* HAL support maximum CPI port number */
#define HAL_CPI_PORT_0               (0) /* HAL CPI port 0 index */
#define HAL_CPI_PORT_1               (1) /* HAL CPI port 1 index */
#define HAL_CPI_PLANE_PORT           (64)
#define HAL_CPI_DP_PLANE_PORT        (32)
#define HAL_DEVICE_PXP_REV_ID        (CLX_INVALID_ID)
#define HAL_MAX_RC_PORT_COUNT        (11) /* HAL support maximum RC port number */
#define HAL_RC_PORT_0                (0)  /* HAL RC port 0 index */
#define HAL_RC_PORT_1                (1)  /* HAL RC port 1 index */
#define HAL_RC_PORT_2                (2)  /* HAL RC port 2 index */
#define HAL_RC_PORT_3                (3)  /* HAL RC port 3 index */
#define HAL_RC_PORT_4                (4)  /* HAL RC port 4 index */
#define HAL_RC_PORT_5                (5)  /* HAL RC port 5 index */
#define HAL_RC_PORT_6                (6)  /* HAL RC port 6 index */
#define HAL_RC_PORT_7                (7)  /* HAL RC port 7 index */
/* RC port in tapping mode */
#define HAL_RC_PORT_8  (8)          /* HAL RC port 8 index */
#define HAL_RC_PORT_9  (9)          /* HAL RC port 9 index */
#define HAL_RC_PORT_10 (10)         /* HAL RC port 10 index */

#define HAL_MAX_ECPU_PORT_COUNT (5) /* HAL support maximum ECPU port number */
#define HAL_ECPU_PORT_0         (0) /* HAL ECPU port 0 index */
/* RC port in tapping mode */
#define HAL_ECPU_PORT_1 (1)             /* HAL ECPU port 1 index */
#define HAL_ECPU_PORT_2 (2)             /* HAL ECPU port 2 index */
#define HAL_ECPU_PORT_3 (3)             /* HAL ECPU port 3 index */
#define HAL_ECPU_PORT_4 (4)             /* HAL ECPU port 4 index */

#define HAL_TBL_INVALID_ID   0xFFFFFFFF /* HAL invalid table id */
#define HAL_INVALID_LANE_CNT 0xFFFFFFFF /* HAL invalid serdes lane cnt */
/* MACRO FUNCTION DECLARATIONS
 */

#define PTR_HAL_FUNC_VECTOR(unit)     _ext_ptr_chip_func_vector[unit]
#define PTR_HAL_EXT_CHIP_INFO(unit)   _ext_ptr_chip_info[unit]
#define PTR_HAL_CMN_FUNC_VECTOR(unit) _ext_ptr_chip_cmn_func_vector[unit]

/* hal related check macros */
#define HAL_IS_UNIT_VALID(__unit__)                     \
    (((__unit__) < CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM) && \
     (NULL != _ext_ptr_chip_func_vector[(__unit__)]))

#define HAL_IS_VLAN_VALID(__vlan__) (((__vlan__) >= 1) && ((__vlan__) <= 4095))

#define HAL_IS_ETH_PORT_VALID(__unit__, __port__) \
    (((__port__) < CLX_PORT_NUM) &&               \
     (UTIL_LIB_BMP_BIT_CHK(HAL_PORT_BMP_ETH((__unit__)), (__port__))))

#define HAL_IS_PORT_VALID(__unit__, __port__) \
    (((__port__) < CLX_PORT_NUM) && (UTIL_LIB_BMP_BIT_CHK(HAL_PORT_BMP((__unit__)), (__port__))))

#define HAL_IS_PP_PORT_VALID(__unit__, __port__) \
    (((__port__) < CLX_PORT_NUM) && (UTIL_LIB_BMP_BIT_CHK(HAL_PORT_BMP_PP((__unit__)), (__port__))))

#define HAL_IS_PHY_PORT_VALID(__unit__, __port__) \
    (((__port__) < CLX_PORT_NUM) &&               \
     (UTIL_LIB_BMP_BIT_CHK(HAL_PORT_BMP_PHY((__unit__)), (__port__))))

#define HAL_IS_ECPU_PORT(__unit__, __port__)                     \
    (((__port__) == HAL_ECPU_PORT(__unit__, HAL_ECPU_PORT_0)) || \
     ((__port__) == HAL_ECPU_PORT(__unit__, HAL_ECPU_PORT_1)) || \
     ((__port__) == HAL_ECPU_PORT(__unit__, HAL_ECPU_PORT_2)) || \
     ((__port__) == HAL_ECPU_PORT(__unit__, HAL_ECPU_PORT_3)) || \
     ((__port__) == HAL_ECPU_PORT(__unit__, HAL_ECPU_PORT_4)))

#define HAL_ECPU_PORT_FOREACH(__unit__, __idx__)                        \
    for (__idx__ = 0; __idx__ < HAL_ECPU_PORT_NUM(__unit__); __idx__++) \
        if (HAL_INVALID_ID != HAL_ECPU_PORT(__unit__, (HAL_ECPU_PORT_0 + __idx__)))

#define HAL_IS_RC_PORT(__unit__, __port__)                   \
    (((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_0)) || \
     ((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_1)) || \
     ((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_2)) || \
     ((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_3)) || \
     ((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_4)) || \
     ((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_5)) || \
     ((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_6)) || \
     ((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_7)) || \
     ((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_8)) || \
     ((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_9)) || \
     ((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_10)))

#define HAL_IS_RC_PORT_VALID(__unit__, __port__) \
    ((HAL_IS_RC_PORT(__unit__, __port__)) &&     \
     (UTIL_LIB_BMP_BIT_CHK(HAL_PORT_BMP((__unit__)), (__port__))))

#define HAL_RC_PORT_FOREACH(__unit__, __idx__)                        \
    for (__idx__ = 0; __idx__ < HAL_RC_PORT_NUM(__unit__); __idx__++) \
        if (HAL_INVALID_ID != HAL_RC_PORT(__unit__, (HAL_RC_PORT_0 + __idx__)))

#define HAL_IS_CPI_PORT(__unit__, __port__)                    \
    (((__port__) == HAL_CPI_PORT(__unit__, HAL_CPI_PORT_0)) || \
     ((__port__) == HAL_CPI_PORT(__unit__, HAL_CPI_PORT_1)))

#define HAL_IS_CPU_PORT(__unit__, __port__) ((__port__) == HAL_CPU_PORT(__unit__))

#define HAL_IS_CPX_PORT(__unit__, __port__) \
    ((HAL_IS_CPU_PORT(__unit__, __port__)) || (HAL_IS_ECPU_PORT(__unit__, __port__)))

#define HAL_IS_CPI_PORT_VALID(__unit__, __port__) \
    ((HAL_IS_CPI_PORT(__unit__, __port__)) &&     \
     (UTIL_LIB_BMP_BIT_CHK(HAL_PORT_BMP((__unit__)), (__port__))))

#define HAL_UI32_FLD_MSK(__unit__, __tbl__, __fld__) hal_ui32_fld_mask(__unit__, __tbl__, __fld__)
#define HAL_IS_UI32_FLD_RANGE_VALID(__unit__, __tbl__, __fld__, __value__) \
    ((__value__) <= HAL_UI32_FLD_MSK((__unit__), (__tbl__), (__fld__)))
#define HAL_TRUNCATE_UI32_FLD(__unit__, __tbl__, __fld__, __value__) \
    ((__value__) & HAL_UI32_FLD_MSK((__unit__), (__tbl__), (__fld__)))

#define HAL_CHECK_ERROR(__rc__)                                                 \
    do {                                                                        \
        clx_error_no_t __rc = (__rc__);                                         \
        if (__rc != CLX_E_OK) {                                                 \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN, #__rc__ "=%d\n", __rc); \
            return __rc;                                                        \
        }                                                                       \
    } while (0)

#define HAL_CHECK_ERROR_GOTO(__rc__, __label__)                                 \
    do {                                                                        \
        clx_error_no_t __rc = (__rc__);                                         \
        if (__rc != CLX_E_OK) {                                                 \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN, #__rc__ "=%d\n", __rc); \
            goto __label__;                                                     \
        }                                                                       \
    } while (0)

#define HAL_CHECK_UNIT(__unit__)                                                              \
    do {                                                                                      \
        if (!HAL_IS_UNIT_VALID((__unit__))) {                                                 \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN, "invalid unit=%u, rc=%d\n", __unit__, \
                           CLX_E_BAD_PARAMETER);                                              \
            return CLX_E_BAD_PARAMETER;                                                       \
        }                                                                                     \
    } while (0)

#define HAL_CHECK_VLAN(__vlan_id__)                           \
    do {                                                      \
        if (!HAL_IS_VLAN_VALID((__vlan_id__))) {              \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN,       \
                           "invalid " #__vlan_id__ "=%u,"     \
                           " range=1-4095, rc=%d\n",          \
                           __vlan_id__, CLX_E_BAD_PARAMETER); \
            return CLX_E_BAD_PARAMETER;                       \
        }                                                     \
    } while (0)

#define HAL_CHECK_PORT(__unit__, __port__)                                                \
    do {                                                                                  \
        if (!HAL_IS_PORT_VALID((__unit__), (__port__))) {                                 \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN, "u=%u, invalid port=%u, rc=%d\n", \
                           __unit__, __port__, CLX_E_BAD_PARAMETER);                      \
            return CLX_E_BAD_PARAMETER;                                                   \
        }                                                                                 \
    } while (0)

#define HAL_CHECK_ETH_PORT(__unit__, __port__)                                                \
    do {                                                                                      \
        if (!HAL_IS_ETH_PORT_VALID((__unit__), (__port__))) {                                 \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN, "u=%u, invalid eth port=%u, rc=%d\n", \
                           __unit__, __port__, CLX_E_BAD_PARAMETER);                          \
            return CLX_E_BAD_PARAMETER;                                                       \
        }                                                                                     \
    } while (0)

#define HAL_CHECK_PP_PORT(__unit__, __port__)                                               \
    do {                                                                                    \
        if (!HAL_IS_PP_PORT_VALID((__unit__), (__port__))) {                                \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_ERR, "u=%u, invalid pp port=%u, rc=%d\n", \
                           __unit__, __port__, CLX_E_BAD_PARAMETER);                        \
            return CLX_E_BAD_PARAMETER;                                                     \
        }                                                                                   \
    } while (0)

#define HAL_CHECK_PHY_PORT(__unit__, __port__)                                                \
    do {                                                                                      \
        if (!HAL_IS_PHY_PORT_VALID((__unit__), (__port__))) {                                 \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN, "u=%u, invalid phy port=%u, rc=%d\n", \
                           __unit__, __port__, CLX_E_BAD_PARAMETER);                          \
            return CLX_E_BAD_PARAMETER;                                                       \
        }                                                                                     \
    } while (0)

#define HAL_CHECK_PORT_BITMAP(__unit__, __port_bitmap__)                                      \
    do {                                                                                      \
        clx_port_bitmap_t __bitmap__;                                                         \
                                                                                              \
        UTIL_LIB_PORT_BMP_INV(__bitmap__, HAL_PORT_BMP((__unit__)));                          \
        UTIL_LIB_PORT_BMP_AND(__bitmap__, (__port_bitmap__));                                 \
                                                                                              \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__)) {                                             \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN, "u=%u, invalid port bitmap, rc=%d\n", \
                           __unit__, CLX_E_BAD_PARAMETER);                                    \
            return CLX_E_BAD_PARAMETER;                                                       \
        }                                                                                     \
    } while (0)

#define HAL_CHECK_ETH_PORT_BITMAP(__unit__, __port_bitmap__)             \
    do {                                                                 \
        clx_port_bitmap_t __bitmap__;                                    \
                                                                         \
        UTIL_LIB_PORT_BMP_INV(__bitmap__, HAL_PORT_BMP_ETH((__unit__))); \
        UTIL_LIB_PORT_BMP_AND(__bitmap__, (__port_bitmap__));            \
                                                                         \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__)) {                        \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN,                  \
                           "u=%u, invalid eth port bitmap, "             \
                           "rc=%d\n",                                    \
                           __unit__, CLX_E_BAD_PARAMETER);               \
            return CLX_E_BAD_PARAMETER;                                  \
        }                                                                \
    } while (0)

#define HAL_CHECK_PP_PORT_BITMAP(__unit__, __port_bitmap__)             \
    do {                                                                \
        clx_port_bitmap_t __bitmap__;                                   \
                                                                        \
        UTIL_LIB_PORT_BMP_INV(__bitmap__, HAL_PORT_BMP_PP((__unit__))); \
        UTIL_LIB_PORT_BMP_AND(__bitmap__, (__port_bitmap__));           \
                                                                        \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__)) {                       \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN,                 \
                           "u=%u, invalid pp port bitmap, "             \
                           "rc=%d\n",                                   \
                           __unit__, CLX_E_BAD_PARAMETER);              \
            return CLX_E_BAD_PARAMETER;                                 \
        }                                                               \
    } while (0)

#define HAL_CHECK_PHY_PORT_BITMAP(__unit__, __port_bitmap__)             \
    do {                                                                 \
        clx_port_bitmap_t __bitmap__;                                    \
                                                                         \
        UTIL_LIB_PORT_BMP_INV(__bitmap__, HAL_PORT_BMP_PHY((__unit__))); \
        UTIL_LIB_PORT_BMP_AND(__bitmap__, (__port_bitmap__));            \
                                                                         \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__)) {                        \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN,                  \
                           "u=%u, invalid phy port bitmap, "             \
                           "rc=%d\n",                                    \
                           __unit__, CLX_E_BAD_PARAMETER);               \
            return CLX_E_BAD_PARAMETER;                                  \
        }                                                                \
    } while (0)

#define HAL_CHECK_PTR(__ptr__)                                                                \
    do {                                                                                      \
        if (NULL == (__ptr__)) {                                                              \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN, #__ptr__ " is null pointer, rc=%d\n", \
                           CLX_E_BAD_PARAMETER);                                              \
            return CLX_E_BAD_PARAMETER;                                                       \
        }                                                                                     \
    } while (0)

#define HAL_CHECK_ENUM_RANGE(__value__, __max__)                             \
    do {                                                                     \
        if ((__value__) >= (__max__)) {                                      \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN,                      \
                           "invalid " #__value__ "=%u, range=0-%u,"          \
                           " rc=%d\n",                                       \
                           __value__, ((__max__) - 1), CLX_E_BAD_PARAMETER); \
            return CLX_E_BAD_PARAMETER;                                      \
        }                                                                    \
    } while (0)

#define HAL_CHECK_MIN_MAX_RANGE(__value__, __min__, __max__)                                  \
    do {                                                                                      \
        if (((__value__) > (__max__)) || ((__value__) < (__min__))) {                         \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN,                                       \
                           "invalid " #__value__ "=%u, range=%u-%u,"                          \
                           " rc=%d\n",                                                        \
                           __value__, (uint32)__min__, (uint32)__max__, CLX_E_BAD_PARAMETER); \
            return CLX_E_BAD_PARAMETER;                                                       \
        }                                                                                     \
    } while (0)

#define HAL_CHECK_MAX_RANGE(__value__, __max__)                              \
    do {                                                                     \
        if ((__value__) > (__max__)) {                                       \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN,                      \
                           "invalid " #__value__ "=%u, range=0-%u,"          \
                           " rc=%d\n",                                       \
                           __value__, (uint32)__max__, CLX_E_BAD_PARAMETER); \
            return CLX_E_BAD_PARAMETER;                                      \
        }                                                                    \
    } while (0)
#define HAL_CHECK_BOOL(__value__)                                                                \
    do {                                                                                         \
        if (((FALSE) != (__value__)) && ((TRUE) != (__value__))) {                               \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN, #__value__ "=%u isn't boolean, rc=%d\n", \
                           __value__, CLX_E_BAD_PARAMETER);                                      \
            return CLX_E_BAD_PARAMETER;                                                          \
        }                                                                                        \
    } while (0)

#define HAL_CHECK_INIT(__unit__, __module_id__)                                             \
    do {                                                                                    \
        if (HAL_INIT_STAGE_NONE == HAL_MODULE_INITED((__unit__), (__module_id__))) {        \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN,                                     \
                           "u=%u, %s module isn't inited, "                                 \
                           "rc=%d\n",                                                       \
                           __unit__, clx_module_name_get(__module_id__), CLX_E_NOT_INITED); \
            return CLX_E_NOT_INITED;                                                        \
        }                                                                                   \
    } while (0)

#define HAL_PLANE_BMP_FOREACH(__unit__, __plane_idx__)                                      \
    for ((__plane_idx__) = 0; (__plane_idx__) < HAL_PLANE_NUM(__unit__); (__plane_idx__)++) \
        if (UTIL_LIB_BMP_BIT_CHK((HAL_PLANE_BMP((__unit__))), (__plane_idx__)))

#define HAL_SUBINST_FOREACH(__unit__, __tbl_id__, __sub_inst__)                           \
    for (__sub_inst__ = 0; __sub_inst__ <                                                 \
         TOB_TABLE((__unit__), (tob_tbl_hw_id_get(__unit__, __tbl_id__)))->subinst_count; \
         __sub_inst__++)

#define HAL_BANK_BMP_ID(idx) (1U << idx) /* idx is 0, 1, 2, or 3 */
#define HAL_BANK_BMP \
    (HAL_BANK_BMP_ID(0) | HAL_BANK_BMP_ID(1) | HAL_BANK_BMP_ID(2) | HAL_BANK_BMP_ID(3))

#define HAL_ALLOC_INFO(unit, tbl_id) \
    _ext_chip_control_block[unit].ptr_alloc_info->ptr_alloc_tbl[tob_tbl_hw_id_get(unit, tbl_id)]
#define HAL_ALLOC_ENTRY_NUM(unit)        _ext_chip_control_block[unit].ptr_alloc_info->entry_num
#define HAL_HASH_TYPE_L2_BMP(unit)       _ext_chip_control_block[unit].ptr_hash_info->l2_bmp[0]
#define HAL_HASH_TYPE_L2_2X_BMP(unit)    _ext_chip_control_block[unit].ptr_hash_info->l2_2x_bmp[0]
#define HAL_HASH_TYPE_L2_GROUP_BMP(unit) _ext_chip_control_block[unit].ptr_hash_info->l2_grp_bmp[0]
#define HAL_HASH_TYPE_DVIF_BMP(unit)     _ext_chip_control_block[unit].ptr_hash_info->dvif_bmp[0]
#define HAL_HASH_TYPE_L3_IPV6_128_BMP(unit) \
    _ext_chip_control_block[unit].ptr_hash_info->l3_ipv6_128_bmp[0]
#define HAL_HASH_TYPE_L3_IPV6_64_BMP(unit) \
    _ext_chip_control_block[unit].ptr_hash_info->l3_ipv6_64_bmp[0]
#define HAL_HASH_TYPE_L3_NO_PREFIX_BMP(unit) \
    _ext_chip_control_block[unit].ptr_hash_info->l3_no_prefix_bmp[0]
#define HAL_HASH_TYPE_L3_RPF_BMP(unit) _ext_chip_control_block[unit].ptr_hash_info->l3_rpf_bmp[0]
#define HAL_HASH_TYPE_SECURITY_BMP(unit) \
    _ext_chip_control_block[unit].ptr_hash_info->security_bmp[0]
#define HAL_HASH_TYPE_MPLS_BMP(unit)         _ext_chip_control_block[unit].ptr_hash_info->mpls_bmp[0]
#define HAL_HASH_TYPE_L2_BMP_PTR(unit)       _ext_chip_control_block[unit].ptr_hash_info->l2_bmp
#define HAL_HASH_TYPE_L2_2X_BMP_PTR(unit)    _ext_chip_control_block[unit].ptr_hash_info->l2_2x_bmp
#define HAL_HASH_TYPE_L2_GROUP_BMP_PTR(unit) _ext_chip_control_block[unit].ptr_hash_info->l2_grp_bmp
#define HAL_HASH_TYPE_DVIF_BMP_PTR(unit)     _ext_chip_control_block[unit].ptr_hash_info->dvif_bmp
#define HAL_HASH_TYPE_L3_IPV6_128_BMP_PTR(unit) \
    _ext_chip_control_block[unit].ptr_hash_info->l3_ipv6_128_bmp
#define HAL_HASH_TYPE_L3_IPV6_64_BMP_PTR(unit) \
    _ext_chip_control_block[unit].ptr_hash_info->l3_ipv6_64_bmp
#define HAL_HASH_TYPE_L3_NO_PREFIX_BMP_PTR(unit) \
    _ext_chip_control_block[unit].ptr_hash_info->l3_no_prefix_bmp
#define HAL_HASH_TYPE_L3_RPF_BMP_PTR(unit) _ext_chip_control_block[unit].ptr_hash_info->l3_rpf_bmp
#define HAL_HASH_TYPE_SECURITY_BMP_PTR(unit) \
    _ext_chip_control_block[unit].ptr_hash_info->security_bmp
#define HAL_HASH_TYPE_MPLS_BMP_PTR(unit) _ext_chip_control_block[unit].ptr_hash_info->mpls_bmp
#define HAL_HASH_TYPE_EXACT_BMP(unit)    _ext_chip_control_block[unit].ptr_hash_info->exact_bmp[0]
#define HAL_HASH_TYPE_EXACT_LEVEL_BMP(unit, level) \
    _ext_chip_control_block[unit].ptr_hash_info->exact_bmp[level]
#define HAL_OBJ_INFO_PTR(unit) _ext_chip_control_block[unit].ptr_obj_info
#define HAL_LCL_INTF_AVL(unit) _ext_chip_control_block[unit].ptr_obj_info->ptr_lcl_intf_avl
#define HAL_LCL_INTF_INFO_AVL(unit) \
    _ext_chip_control_block[unit].ptr_obj_info->ptr_lcl_intf_info_avl
#define HAL_INIT_STAGE(unit)             _ext_chip_control_block[unit].init_stage
#define HAL_MODULE_INFO(unit, module_id) _ext_chip_control_block[unit].ptr_module_info[module_id]
#define HAL_DRIVER_INFO(unit)            _ext_chip_control_block[unit].ptr_driver_info
#define HAL_ETH_MACRO_INFO_PTR(unit)     _ext_chip_control_block[unit].ptr_eth_macro_info
#define HAL_ETH_MACRO_NUM(unit)          _ext_chip_control_block[unit].ptr_eth_macro_info->macro_num
#define HAL_ETH_MACRO_MAP_INFO(unit, eth_macro) \
    _ext_chip_control_block[unit].ptr_eth_macro_info->ptr_macro_map[eth_macro]

#define HAL_MODULE_INITED(__unit__, __module__) (HAL_MODULE_INFO(__unit__, __module__).inited)

#define HAL_TBL_ADDR(__unit__, __tbl__, __inst__, __subinst__, __idx__)  \
    (TOB_TBL_INFO((__unit__), __tbl__)->table_addr +                     \
     TOB_TBL_INFO((__unit__), __tbl__)->slot_size * (__inst__) +         \
     TOB_TBL_INFO((__unit__), __tbl__)->subinst_offset * (__subinst__) + \
     TOB_TBL_INFO((__unit__), __tbl__)->entry_offset * (__idx__))

#define HAL_FUNC_CALL(__unit__, __module__, __func__, __param__)                                     \
    ({                                                                                               \
        clx_error_no_t __rc = CLX_E_OK;                                                              \
        if ((NULL == PTR_HAL_FUNC_VECTOR(__unit__)->__module__##_func_vec) ||                        \
            (NULL ==                                                                                 \
             PTR_HAL_FUNC_VECTOR(__unit__)->__module__##_func_vec->hal_##__module__##_##__func__)) { \
            __rc = CLX_E_NOT_SUPPORT;                                                                \
        } else {                                                                                     \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_INFO, "[N]\n");                                    \
            __rc = (PTR_HAL_FUNC_VECTOR(__unit__)                                                    \
                        ->__module__##_func_vec->hal_##__module__##_##__func__ __param__);           \
        }                                                                                            \
        __rc;                                                                                        \
    })

#define HAL_CMN_FUNC_CALL(__unit__, __module__, __func__, __param__)                           \
    ({                                                                                         \
        clx_error_no_t __rc = CLX_E_OK;                                                        \
        if ((NULL == PTR_HAL_CMN_FUNC_VECTOR(__unit__)->__module__##_cmn_func_vec) ||          \
            (NULL ==                                                                           \
             PTR_HAL_CMN_FUNC_VECTOR(__unit__)                                                 \
                 ->__module__##_cmn_func_vec->hal_##__module__##_##__func__)) {                \
            __rc = CLX_E_NOT_SUPPORT;                                                          \
        } else {                                                                               \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_INFO, "[N]\n");                              \
            __rc = (PTR_HAL_CMN_FUNC_VECTOR(__unit__)                                          \
                        ->__module__##_cmn_func_vec->hal_##__module__##_##__func__ __param__); \
        }                                                                                      \
        __rc;                                                                                  \
    })

#define HAL_API_CALL(__unit__, __module__, __func__, __param__) \
    ({                                                          \
        clx_error_no_t __rc = CLX_E_OK;                         \
        __rc = (hal##_##__module__##_##__func__ __param__);     \
        __rc;                                                   \
    })

/* Macros for chip related information */
#define HAL_DEVICE_CHIP_ID(unit)        PTR_HAL_EXT_CHIP_INFO(unit)->device_id
#define HAL_DEVICE_REV_ID(unit)         PTR_HAL_EXT_CHIP_INFO(unit)->revision_id
#define HAL_DEVICE_CONFIG_MODEL(unit)   PTR_HAL_EXT_CHIP_INFO(unit)->config_model
#define HAL_DEVICE_PACKAGE_TYPE(unit)   PTR_HAL_EXT_CHIP_INFO(unit)->package_type
#define HAL_DEVICE_SLICE_INFO(unit)     PTR_HAL_EXT_CHIP_INFO(unit)->slice_info
#define HAL_DEVICE_FREQ(unit)           PTR_HAL_EXT_CHIP_INFO(unit)->frequency
#define HAL_DEVICE_MODE(unit)           PTR_HAL_EXT_CHIP_INFO(unit)->mode
#define HAL_DEVICE_SWITCH_MODE(unit)    PTR_HAL_EXT_CHIP_INFO(unit)->switch_mode
#define HAL_PORT_DI_MODE(unit)          PTR_HAL_EXT_CHIP_INFO(unit)->port_di_mode
#define HAL_GBL_CHIP_IDX(unit)          PTR_HAL_EXT_CHIP_INFO(unit)->hw_chip_id
#define HAL_LAG_EPOCH_ID(unit)          PTR_HAL_EXT_CHIP_INFO(unit)->lag_epoch_id
#define HAL_DIE_BMP(unit)               PTR_HAL_EXT_CHIP_INFO(unit)->die_bmp
#define HAL_BIN_BMP(unit)               PTR_HAL_EXT_CHIP_INFO(unit)->bin_bmp
#define HAL_BIN_NUM(unit)               PTR_HAL_EXT_CHIP_INFO(unit)->bin_num
#define HAL_PLANE_BMP(unit)             PTR_HAL_EXT_CHIP_INFO(unit)->plane_bmp
#define HAL_SLAVE_PLANE_BMP(unit)       PTR_HAL_EXT_CHIP_INFO(unit)->slave_plane_bmp
#define HAL_FPU_BMP(unit)               PTR_HAL_EXT_CHIP_INFO(unit)->fpu_bmp
#define HAL_ETH_MACRO_BMP(unit)         PTR_HAL_EXT_CHIP_INFO(unit)->mac_macro_bmp
#define HAL_CPU_PORT(unit)              PTR_HAL_EXT_CHIP_INFO(unit)->cpu_port
#define HAL_ECPU_PORT(unit, ecpu_idx)   PTR_HAL_EXT_CHIP_INFO(unit)->ecpu_port[ecpu_idx]
#define HAL_ECPU_PORT_NUM(unit)         PTR_HAL_EXT_CHIP_INFO(unit)->ecpu_port_num
#define HAL_PORT_BMP(unit)              PTR_HAL_EXT_CHIP_INFO(unit)->port_bitmap
#define HAL_PORT_BMP_ETH(unit)          PTR_HAL_EXT_CHIP_INFO(unit)->port_bitmap_eth
#define HAL_PORT_BMP_PP(unit)           PTR_HAL_EXT_CHIP_INFO(unit)->port_bitmap_pp
#define HAL_PORT_BMP_PHY(unit)          PTR_HAL_EXT_CHIP_INFO(unit)->port_bitmap_phy
#define HAL_PORT_BMP_TOTAL(unit)        PTR_HAL_EXT_CHIP_INFO(unit)->port_bitmap_total
#define HAL_PLANE_ETH_MACRO_NUM(unit)   PTR_HAL_EXT_CHIP_INFO(unit)->plane_mac_macro_num
#define HAL_PLANE_FP_NUM(unit, plane)   PTR_HAL_EXT_CHIP_INFO(unit)->plane_fp_num
#define HAL_PLANE_ETH_PORT_NUM(unit)    PTR_HAL_EXT_CHIP_INFO(unit)->plane_eth_port_num
#define HAL_TOTAL_PORT(unit)            PTR_HAL_EXT_CHIP_INFO(unit)->total_port
#define HAL_PORT_MAP_INFO(unit, port)   PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port]
#define HAL_CPI_PORT(unit, cpi_idx)     PTR_HAL_EXT_CHIP_INFO(unit)->cpi_port[cpi_idx]
#define HAL_PLANE_PORT_MAP_INFO(unit)   PTR_HAL_EXT_CHIP_INFO(unit)->pptr_pport_map_info
#define HAL_CHIP_INFO_FLAGS(unit)       PTR_HAL_EXT_CHIP_INFO(unit)->flags
#define HAL_PLANE_PORT_BMP(unit, plane) PTR_HAL_EXT_CHIP_INFO(unit)->ptr_plane_port_bitmap[plane]
#define HAL_RC_PORT(unit, rcp_idx)      PTR_HAL_EXT_CHIP_INFO(unit)->rc_port[rcp_idx]
#define HAL_RC_PORT_NUM(unit)           PTR_HAL_EXT_CHIP_INFO(unit)->rc_port_num
#define HAL_CHIP_MAC_SELECT(unit)       PTR_HAL_EXT_CHIP_INFO(unit)->mac_select
#define HAL_LATENCY_MODE(unit)          PTR_HAL_EXT_CHIP_INFO(unit)->latency_mode
#define HAL_RESOURCE_MODE(unit)         PTR_HAL_EXT_CHIP_INFO(unit)->resource_mode

#if defined(CLX_MOCK)
#define HAL_LATENCY_MODE_SUPPORT(__unit__, __latency_mode__) (1)
#define HAL_LATENCY_MODE_CHECK(__unit__, __latency_mode__) \
    do {                                                   \
    } while (0)
#else
#define HAL_LATENCY_MODE_SUPPORT(__unit__, __latency_mode__) \
    (0 != ((__latency_mode__) & (1 << HAL_LATENCY_MODE(__unit__))))
#define HAL_LATENCY_MODE_CHECK(__unit__, __latency_mode__)               \
    do {                                                                 \
        if (HAL_IS_DEVICE_KAWAGARBO_FAMILY(__unit__)) {                  \
            if (!HAL_LATENCY_MODE_SUPPORT(__unit__, __latency_mode__)) { \
                return CLX_E_NOT_SUPPORT;                                \
            }                                                            \
        }                                                                \
    } while (0)
#endif

#define HAL_PLANE_MAC_SELECT(__unit__, __plane__) \
    (0x3f & (HAL_CHIP_MAC_SELECT(__unit__) >> (__plane__ * HAL_PLANE_ETH_MACRO_NUM(__unit__))))

#define HAL_MACRO_MAC_SELECT(__unit__, __plane__, __macro__) \
    (HAL_CHIP_MAC_SELECT(__unit__) &                         \
     (0x1 << ((__plane__ * HAL_PLANE_ETH_MACRO_NUM(__unit__)) + __macro__)))

#define HAL_MACRO_MAC_INDEX(__unit__, __plane__, __macro__) \
    ((__plane__ * HAL_PLANE_ETH_MACRO_NUM(__unit__)) + (__macro__))

#define HAL_IS_LMAC_PORT(__unit__, __port__) \
    (HAL_CHIP_MAC_SELECT(__unit__) & (0x1 << (HAL_CL_PORT_TO_ETH_MACRO(__unit__, __port__))))

#define HAL_IS_UMAC_PORT(__unit__, __port__) \
    (!(HAL_CHIP_MAC_SELECT(__unit__) & (0x1 << (HAL_CL_PORT_TO_ETH_MACRO(__unit__, __port__)))))

/* Macro to check CPI port working mode */
#define HAL_IS_CPI_PORT_ETH_MODE(unit, cpi_port)                           \
    ((cpi_port == HAL_CPI_PORT(unit, HAL_CPI_PORT_0)) ?                    \
         (HAL_CHIP_INFO_FLAGS(unit) & HAL_CHIP_INFO_FLAGS_CPI0_MODE_ETH) : \
         (HAL_CHIP_INFO_FLAGS(unit) & HAL_CHIP_INFO_FLAGS_CPI1_MODE_ETH))

#define HAL_IS_DEVICE_NAMCHABARWA_FAMILY(unit)             \
    ((HAL_DEVICE_CHIP_ID(unit) == DRV_DEV_ID_CL8652) ||    \
     (HAL_DEVICE_CHIP_ID(unit) == DRV_DEV_ID_CL860256) ||  \
     (HAL_DEVICE_CHIP_ID(unit) == DRV_DEV_ID_CL860128P) || \
     (HAL_DEVICE_CHIP_ID(unit) == DRV_DEV_ID_CL860080) ||  \
     (HAL_DEVICE_CHIP_ID(unit) == DRV_DEV_ID_CL860080P) || \
     (HAL_DEVICE_CHIP_ID(unit) == DRV_DEV_ID_CL860064P) || \
     (HAL_DEVICE_CHIP_ID(unit) == DRV_DEV_ID_CL860160) ||  \
     (HAL_DEVICE_CHIP_ID(unit) == DRV_DEV_ID_CL860168) ||  \
     (HAL_DEVICE_CHIP_ID(unit) == DRV_DEV_ID_CL860128))

#define HAL_IS_DEV_NB_RESOURCE_DOUBLE_FAMILY(unit) \
    (HAL_RESOURCE_MODE(unit) == HAL_RESOURCE_NB_MODE_DOUBLE)

#define HAL_IS_DEV_NB_RESOURCE_SINGLE_FAMILY(unit) \
    (HAL_RESOURCE_MODE(unit) == HAL_RESOURCE_NB_MODE_SINGLE)

#define HAL_IS_DEV_KG_RESOURCE_FAMILY(unit) (HAL_RESOURCE_MODE(unit) == HAL_RESOURCE_KG_MODE)

#define HAL_IS_DEV_NB_CIAT_DOUBLE_FAMILY(unit)                   \
    ((HAL_RESOURCE_MODE(unit) == HAL_RESOURCE_NB_MODE_DOUBLE) && \
     (HAL_DEVICE_CHIP_ID(unit) != DRV_DEV_ID_CL860080) &&        \
     (HAL_DEVICE_CHIP_ID(unit) != DRV_DEV_ID_CL860128))

#define HAL_IS_DEV_NB_CIAT_SINGLE_FAMILY(unit)            \
    ((HAL_DEVICE_CHIP_ID(unit) == DRV_DEV_ID_CL860080) || \
     (HAL_DEVICE_CHIP_ID(unit) == DRV_DEV_ID_CL860128))

#define HAL_IS_DEVICE_KAWAGARBO_FAMILY(unit)             \
    (((HAL_DEVICE_CHIP_ID(unit) == DRV_DEV_ID_CL8424) || \
      (HAL_DEVICE_CHIP_ID(unit) == DRV_DEV_ID_CL8421) || \
      (HAL_DEVICE_CHIP_ID(unit) == DRV_DEV_ID_CL8440)))

#define HAL_IS_DEVICE_KG_SINGLE_FAMILY(unit)            \
    ((HAL_DEVICE_CHIP_ID(unit) == DRV_DEV_ID_CL8424) || \
     (HAL_DEVICE_CHIP_ID(unit) == DRV_DEV_ID_CL8421))

#define HAL_IS_DEVICE_KG_DOUBLE_FAMILY(unit) (HAL_DEVICE_CHIP_ID(unit) == DRV_DEV_ID_CL8440)

#define HAL_IS_DEVICE_TAPPING_MODE(unit) \
    ((HAL_DFLT_CFG_TYPE_SWITCH_MODE != HAL_DEVICE_SWITCH_MODE(unit)))

#define HAL_WARM_BOOT_FLAGS_INIT   (1U << 0)
#define HAL_WARM_BOOT_FLAGS_DEINIT (1U << 1)
#define HAL_WARM_INIT(__value__)                                               \
    ((TRUE == __value__) ? (_ext_warm_boot_flag |= HAL_WARM_BOOT_FLAGS_INIT) : \
                           (_ext_warm_boot_flag &= ~HAL_WARM_BOOT_FLAGS_INIT))

#define HAL_WARM_DEINIT(__value__)                                               \
    ((TRUE == __value__) ? (_ext_warm_boot_flag |= HAL_WARM_BOOT_FLAGS_DEINIT) : \
                           (_ext_warm_boot_flag &= ~HAL_WARM_BOOT_FLAGS_DEINIT))

#define HAL_IS_WARM_INIT()   (_ext_warm_boot_flag & HAL_WARM_BOOT_FLAGS_INIT)
#define HAL_IS_WARM_DEINIT() (_ext_warm_boot_flag & HAL_WARM_BOOT_FLAGS_DEINIT)

/* Macros for CLX port related attributes */
#define HAL_CL_PORT_TO_DIE(unit, port)   PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].die
#define HAL_CL_PORT_TO_BIN(unit, port)   PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].bin
#define HAL_CL_PORT_TO_PLANE(unit, port) PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].plane
#define HAL_CL_PORT_TO_MAC_MACRO(unit, port) \
    PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].hw_mac_macro

#ifndef HAL_MT_PORT_TO_MACRO_FOR_MAC
#define HAL_MT_PORT_TO_MACRO_FOR_MAC(__unit__, __port__)      \
    ((HAL_IS_DEV_NB_RESOURCE_DOUBLE_FAMILY(__unit__)) ?       \
         (HAL_CL_PORT_TO_MAC_MACRO(__unit__, __port__) % 4) : \
         (HAL_CL_PORT_TO_MAC_MACRO(__unit__, __port__)))
#endif

#define HAL_CL_PORT_TO_TM_MAC_MACRO(unit, port) \
    PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].tm_mac_macro
#define HAL_CL_PORT_TO_SERDES_MACRO(unit, port) \
    PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].serdes_mac_macro
#define HAL_CL_PORT_TO_MACRO_PORT(unit, port) \
    PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].lane
#define HAL_CL_PORT_TO_TM_MAC_PORT(unit, port) \
    PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].mpid
#define HAL_CL_PORT_TO_PLANE_PORT(unit, port) \
    PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].ppid
#define HAL_CL_PORT_TO_ETH_MACRO(unit, port) \
    PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].eth_macro

#define HAL_CL_PORT_TO_DP_PLANE_PORT(unit, port) \
    (PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].ppid)

#define HAL_PLANE_PORT_TO_CL_PORT(unit, plane, plane_port)                                     \
    ((((plane) < HAL_PLANE_NUM(unit)) && UTIL_LIB_BMP_BIT_CHK(HAL_PLANE_BMP(unit), (plane)) && \
      ((plane_port) < PTR_HAL_EXT_CHIP_INFO(unit)->plane_max_port_num)) ?                      \
         PTR_HAL_EXT_CHIP_INFO(unit)->pptr_pport_map_info[(plane)][(plane_port)] :             \
         HAL_INVALID_ID)

/* In CL8570 PP, CPI plane_port is 64 for non-ITM bubble, and plane_port is 32 for ITM bubble.
 * It might need update when there are multiple CPI ports in a plane for later chips
 */
#define HAL_DP_PLANE_PORT_TO_CL_PORT(unit, plane, plane_port) \
    (PTR_HAL_EXT_CHIP_INFO(unit)->pptr_pport_map_info[plane][plane_port])

/* Resource management related definitions */
#ifdef HAL_ENABLE_RESOURCE_LOCK
#define HAL_COMMON_CREATE_LOCK_RESOURCE(ptr_sema_name, ptr_semaphore_id) \
    osal_semaphore_create(ptr_sema_name, 1, ptr_semaphore_id)
#define HAL_COMMON_DESTROY_LOCK_RESOURCE(ptr_semaphore_id) osal_semaphore_destroy(ptr_semaphore_id)
#define HAL_COMMON_LOCK_RESOURCE(ptr_sema, timeout)        osal_semaphore_take((ptr_sema), (timeout))
#define HAL_COMMON_FREE_RESOURCE(ptr_sema)                 osal_semaphore_give((ptr_sema))
/* mutex */
#define HAL_COMMON_CREATE_MUTEX_RESOURCE(lock_name, lock_mode, lock_id) \
    osal_lock_create((lock_name), (lock_mode), (lock_id))
#define HAL_COMMON_FREE_MUTEX_RESOURCE(lock_id) osal_lock_destroy((lock_id))
#define HAL_COMMON_MUTEX_LOCK(lock_id)          osal_lock_acquire((lock_id))
#define HAL_COMMON_MUTEX_UNLOCK(lock_id)        osal_lock_release((lock_id))
#else
#define HAL_COMMON_CREATE_LOCK_RESOURCE(ptr_sema_name, ptr_semaphore_id) CLX_E_OK
#define HAL_COMMON_DESTROY_LOCK_RESOURCE(ptr_semaphore_id)               CLX_E_OK
#define HAL_COMMON_LOCK_RESOURCE(ptr_sema, timeout)                      CLX_E_OK
#define HAL_COMMON_FREE_RESOURCE(ptr_sema)                               CLX_E_OK
/* mutex */
#define HAL_COMMON_CREATE_MUTEX_RESOURCE(lock_name, lock_mode, lock_id)  CLX_E_OK
#define HAL_COMMON_FREE_MUTEX_RESOURCE(lock_id)                          CLX_E_OK
#define HAL_COMMON_MUTEX_LOCK(lock_id)                                   CLX_E_OK
#define HAL_COMMON_MUTEX_UNLOCK(lock_id)                                 CLX_E_OK
#endif /* HAL_ENABLE_RESOURCE_LOCK */

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_chip_mode_e {
    HAL_CHIP_MODE_SIG = 0,
    HAL_CHIP_MODE_PORT,
    HAL_CHIP_MODE_FAB,
    HAL_CHIP_MODE_LAST
} hal_chip_mode_t;

typedef enum hal_plane_mode_e {
    HAL_PLANE_MODE_ETH_SIG = 0,
    HAL_PLANE_MODE_ETH_LEAF,
    HAL_PLANE_MODE_FAB_LEAF,
    HAL_PLANE_MODE_FAB_SPINE,
    HAL_PLANE_MODE_LAST
} hal_plane_mode_t;

typedef struct hal_port_map_s {
    uint32 valid;
#define HAL_PORT_MAP_FLAGS_INIT_ACTIVE    (1U << 0)
#define HAL_PORT_MAP_FLAGS_GUARANTEE      (1U << 1)
#define HAL_PORT_MAP_FLAGS_CPI            (1U << 2)
#define HAL_PORT_MAP_FLAGS_RCP            (1U << 3)
#define HAL_PORT_MAP_FLAGS_DUAL_UMAC_56G  (1U << 5)
#define HAL_PORT_MAP_FLAGS_DUAL_UMAC_112G (1U << 6)
#define HAL_PORT_MAP_FLAGS_ECPU_AS_RCP    (1U << 7)

    uint32 flags;
    uint32 eth_macro; /* eth macro id shown in schematic ethx/ethc */
    uint32 lane;      /* lane id */
    uint32 lane_cnt;  /* port lane number */
    clx_port_speed_t max_speed;
    /* attributes of this CLX port */
    uint32 die;              /* die index (die is same as bin on CL8360) */
    uint32 bin;              /* bin index */
    uint32 plane;            /* plane index */
    uint32 hw_mac_macro;     /* hw mac macro index, macro_idx in plane*/
    uint32 tm_mac_macro;     /* tm mac macro index */
    uint32 serdes_mac_macro; /* serdes mac macro index */
    uint32 mpid;             /* MAC port id */
    uint32 ppid;             /* plane port id */
    uint32 port_di;          /* port destination index */
    clx_port_speed_t lane_speed; /* per-lane bandwidth capability (25G or 50G) */
    uint32 start_lane;           /* starting lane of INIT_ACTIVE port in group */
    uint32 lane_idx;             /* position of this port within original group (0-based) */
    uint32 orig_lane_cnt;        /* lane count of original parent port before any split */
} hal_port_map_t;

/* used to record chip's macro bitmap */
typedef uint32 hal_mac_macro_bitmap_t[HAL_MAX_MAC_MACRO_WORD_SIZE];

/* used to record chip plane port bitmap */
typedef uint32 hal_plane_port_bitmap_t[HAL_MAX_PLANE_PORT_WORD_SIZE];

typedef enum hal_dev_family_e {
    HAL_DEV_FAMILY_NAMCHABARWA,
    HAL_DEV_FAMILY_KAWAGARBO,
    HAL_DEV_FAMILY_LAST
} hal_dev_family_t;

typedef enum hal_latency_mode_e {
    HAL_LATENCY_MODE_NORMAL = 0,  /* normal mode */
    HAL_LATENCY_MODE_LOW_LATENCY, /* Low latency mode is equivalent to ASIC ultra-low latency */
    HAL_LATENCY_MODE_ULTRA_LOW_LATENCY, /* ultra low latency mode is equivalent to asic
                                           ultra-ultra-low latency */
    HAL_LATENCY_MODE_LAST
} hal_latency_mode_t;

#define HAL_LATENCY_MODE_NORMAL_FLAG            (1U << HAL_LATENCY_MODE_NORMAL)
#define HAL_LATENCY_MODE_LOW_LATENCY_FLAG       (1U << HAL_LATENCY_MODE_LOW_LATENCY)
#define HAL_LATENCY_MODE_ULTRA_LOW_LATENCY_FLAG (1U << HAL_LATENCY_MODE_ULTRA_LOW_LATENCY)
#define HAL_LATENCY_MODE_ALL_FLAG                                       \
    (HAL_LATENCY_MODE_NORMAL_FLAG | HAL_LATENCY_MODE_LOW_LATENCY_FLAG | \
     HAL_LATENCY_MODE_ULTRA_LOW_LATENCY_FLAG)

typedef enum hal_resource_mode_e {
    HAL_RESOURCE_NB_MODE_SINGLE = 0,
    HAL_RESOURCE_NB_MODE_DOUBLE = 1,
    HAL_RESOURCE_KG_MODE = 2,
    HAL_RESOURCE_MODE_LAST,
} hal_resource_mode_t;

typedef struct hal_chip_info_s {
    uint32 vendor_id;                /* vendor ID                                */
    uint32 device_id;                /* device ID                                */
    uint32 revision_id;              /* revision ID                              */
    uint32 uid[3];                   /* UID                                      */
    uint32 config_model;             /* Config model                             */
    uint32 package_type;             /* Package type                             */
    uint32 slice_info;               /* Test record                              */
    uint32 hw_chip_id;               /* hw chip ID(6 bits), used for pkt module  */
    uint32 lag_epoch_id;             /* lag epoch ID(1 bit), used for pkt module */
    uint32 frequency;                /* frequency (MHz)                          */
    uint32 mode;                     /* DRV DEV run mode                         */
    uint32 switch_mode;              /* switch mode. 0 is normal, 1 is tapping   */
    hal_latency_mode_t latency_mode; /* latency mode. 0 is normal, 1 is low, 2 is ultra low */
#define HAL_CHIP_INFO_FLAGS_USE_UNIT_PORT  (1U << 0)
#define HAL_CHIP_INFO_FLAGS_CPI0_MODE_ETH  (1U << 1)
#define HAL_CHIP_INFO_FLAGS_CPI1_MODE_ETH  (1U << 2)
#define HAL_CHIP_INFO_FLAGS_LAG_EPOCH      (1U << 3)
#define HAL_CHIP_INFO_FLAG_PORT_PREEMPTION (1U << 4)
    uint32 flags;
    uint32 die_bmp[1];                              /* chip die bitmap                          */
    uint32 bin_num;                                 /* chip bin count                           */
    uint32 bin_bmp[1];                              /* chip bin bitmap                          */
    uint32 plane_bmp[1];                            /* chip plane bitmap                        */
    uint32 slave_plane_bmp[1];                      /* chip slave plane bitmap                  */
    uint32 fpu_bmp[1];                              /* chip fpu bitmap                          */
    hal_mac_macro_bitmap_t mac_macro_bmp;           /* chip mac/serdes macro bitmap             */
    hal_mac_macro_bitmap_t mac_macro_100g_bmp;      /* chip mac macro support 100G              */
    uint32 plane_mac_macro_num;                     /* plane mac macro numbers                  */
    uint32 plane_fp_num;                            /* plane front port numbers                 */
    uint32 plane_eth_port_num;                      /* plane port eth numbers                   */
    uint32 plane_max_port_num;                      /* plane maximum port numbers               */
    uint32 cpu_port;                                /* cpu port id                              */
    uint32 ecpu_port[HAL_MAX_ECPU_PORT_COUNT];      /* ecpu port id                              */
    uint32 ecpu_port_num;
    uint32 total_port;                              /* total port numbers                       */
    clx_port_bitmap_t port_bitmap;                  /* total active port bitmap                 */
    clx_port_bitmap_t port_bitmap_eth;              /* total active ether port bitmap           */
    clx_port_bitmap_t port_bitmap_pp;               /* total active plane port bitmap (PP)      */
    clx_port_bitmap_t port_bitmap_phy;              /* total active PHY (Serdes) port bitmap    */
    clx_port_bitmap_t port_bitmap_total;            /* total port bitmap (active and inactive)  */
    hal_port_map_t *ptr_port_map_info;              /* port and mac/lane map info               */
    uint32 cpi_port[HAL_MAX_CPI_PORT_COUNT];
    uint32 **pptr_pport_map_info;                   /* plane port to CL port map                */
    hal_plane_port_bitmap_t *ptr_plane_port_bitmap; /* plane active port bitmap (per-plane)     */
    uint32 phy_di_num;                              /* per chip used physical port di num       */
    uint32 port_di_mode;                            /* port di mode. 0 is static, 1 is dynamic  */
    uint32 lcl_di[CLX_PORT_NUM];                    /* local port => local di                   */
    uint32 di_map[HAL_PHY_PORT_NUM + 1];            /* port di   => local port                  */
    uint32 *ptr_plane_mode;                         /* chassis plane mode                       */
    uint32 rc_port[HAL_MAX_RC_PORT_COUNT];
    uint32 rc_port_num;
    uint32 ***ppptr_umac_port_map_info; /* umac lane to CL port map                 */
    uint32 mac_select;                  /* mac selection. 1 bit for each MAC
                                         * 0: select UMAC(default)
                                         * 1: select LMAC(Low latency MAC, support ultra-low latency,
                                         *    but only support 10G/25G R1 without FEC)*/
    hal_resource_mode_t resource_mode;  /* chip resource mode, default 0, 0: single mode, 1: double
                                           mode*/
} hal_chip_info_t;

typedef enum hal_init_stage_e {
    HAL_INIT_STAGE_NONE = 0,
    HAL_INIT_STAGE_LOW_LEVEL = (0x1U << 0),
    HAL_INIT_STAGE_TASK_RSRC = (0x1U << 1),
    HAL_INIT_STAGE_MODULE = (0x1U << 2),
    HAL_INIT_STAGE_TASK = (0x1U << 3),
} hal_init_stage_t;

typedef struct hal_module_info_s {
    hal_init_stage_t inited;
} hal_module_info_t;

typedef struct hal_hash_info_s {
#define HAL_BANK_BMP_SIZE 2
    uint32 l2_bmp[HAL_BANK_BMP_SIZE];
    uint32 l2_grp_bmp[HAL_BANK_BMP_SIZE];
    uint32 l3_ipv6_128_bmp[HAL_BANK_BMP_SIZE];
    uint32 l3_ipv6_64_bmp[HAL_BANK_BMP_SIZE];
    uint32 l3_no_prefix_bmp[HAL_BANK_BMP_SIZE];
    uint32 l3_rpf_bmp[HAL_BANK_BMP_SIZE];
    uint32 security_bmp[HAL_BANK_BMP_SIZE];
#define HAL_EXACT_BMP_LEVEL_MAX 24
    uint32 exact_bmp[HAL_EXACT_BMP_LEVEL_MAX];
    uint32 mpls_bmp[HAL_BANK_BMP_SIZE];
    uint32 dvif_bmp[HAL_BANK_BMP_SIZE];
    uint32 l2_2x_bmp[HAL_BANK_BMP_SIZE];
} hal_hash_info_t;

typedef struct hal_intf_obj_info_s {
    clx_gport_type_t type;
    uint32 flag;
    uint32 di; /* use di to put cl port for CL325x */
    uint32 is_lag;
    uint32 lag_id;
    union {
        uint32 encap_idx;
        uint32 vm_id;
    };
    uint32 ecpu_id;
} hal_intf_obj_info_t;
#define HAL_INTF_OBJ_INFO_FLAGS_WITH_ID     (1U << 0)
#define HAL_INTF_OBJ_INFO_FLAGS_NO_LCL_INTF (1U << 1)

typedef struct hal_obj_lcl_intf_s {
    clx_gport_type_t type;
    union {
        uint32 port_id;
        uint32 di;
    };
    union {
        uint32 is_lag;
        uint32 flag;
    };
    uint32 lcl_intf;
    union {
        uint32 encap_idx;
        uint32 vm_id;
    };
} hal_obj_lcl_intf_t;

typedef struct hal_obj_info_s {
    clx_semaphore_id_t *ptr_obj_sema_id;
    util_lib_avl_head_t *ptr_lcl_intf_avl;
    util_lib_avl_head_t *ptr_lcl_intf_info_avl;
} hal_obj_info_t;

typedef struct hal_chip_cb_s {
    hal_chip_info_t *ptr_chip_info;    /* chip information pointer */
    hal_drv_driver_t *ptr_driver_info; /* chip driver information pointer */
    clx_semaphore_id_t *ptr_sema_id;   /* semaphore information pointer */
    hal_drv_alloc_info_t *ptr_alloc_info;
    hal_init_stage_t init_stage;
    hal_module_info_t *ptr_module_info;           /* module information pointer */
    hal_hash_info_t *ptr_hash_info;
    hal_drv_eth_macro_info_t *ptr_eth_macro_info; /* pointer of mac macro information of this device
                                                   */
    hal_obj_info_t *ptr_obj_info;
} hal_chip_cb_t;

typedef enum hal_hash_type_e {
    HAL_HASH_TYPE_L2 = 0,
    HAL_HASH_TYPE_L2_GROUP,
    HAL_HASH_TYPE_L3_IPV6_128,
    HAL_HASH_TYPE_L3_IPV6_64,
    HAL_HASH_TYPE_L3_NO_PREFIX,
    HAL_HASH_TYPE_L3_RPF,
    HAL_HASH_TYPE_SECURITY,
    HAL_HASH_TYPE_EXACT,
    HAL_HASH_TYPE_MPLS,
    HAL_HASH_TYPE_DVIF,
    HAL_HASH_TYPE_L2_2X,
    HAL_HASH_TYPE_LAST
} hal_hash_type_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Hal_init() is responsible for HAL initialization, it will do the following: 1.
 *        Construct chip control block. 2. Initialize chip information.
 *        3. Initialize driver information.
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]    unit    - The unit number that would like to be initialized.
 * @return        CLX_E_OK        - Successfully initialize HAL.
 * @return        CLX_E_OTHERS    - Fail to complete initialization procedure.
 */
clx_error_no_t
hal_init(const uint32 unit);

/**
 * @brief Hal_deinit() is responsible for HAL de-initialization, it will do the following: 1.
 *        Reset driver information. 2. Reset chip information. 3. Free the constructed chip control
 *        block.
 *
 * @param [in]    unit    - The unit number that would like to de-initialized.
 * @return        CLX_E_OK        - Successfully de-initialize HAL.
 * @return        CLX_E_OTHERS    - Fail to complete de-initialization procedure.
 */
clx_error_no_t
hal_deinit(const uint32 unit);

/**
 * @brief Hal_system_unit_num_get() is an API that allows to get current valid unit number
 *        information for this system.
 *
 * Please note this API will return current valid unit number
 * information. For example, if there are two units on this system,
 * it will return two from this API. If one of these two units has been
 * removed, it will return one from this API.
 *
 * @param [out]    ptr_unit_num    - The total unit number information.
 * @return         CLX_E_OK               - Get the system unit information successfully.
 * @return         CLX_E_BAD_PARAMETER    - Parameter, ptr_unit_num, is a NULL pointer.
 */
clx_error_no_t
hal_system_unit_num_get(uint32 *ptr_unit_num);

/**
 * @brief Hal_unit_port_num_get() is an API that allows to get total port number information for
 *        this unit.
 *
 * @param [in]     unit            - The specified unit number.
 * @param [out]    ptr_port_num    - The total port number information on the specified unit.
 * @return         CLX_E_OK               - Get the unit's port number information successfully.
 * @return         CLX_E_BAD_PARAMETER    - Parameter, ptr_port_num, is a NULL pointer.
 * @return         CLX_E_OTHERS           - Fail to get the port number information.
 */
clx_error_no_t
hal_unit_port_num_get(const uint32 unit, uint32 *ptr_port_num);

/**
 * @brief Hal_chip_info_dump() is a function to dump chip information.
 *
 * @param [in]    unit    - The specified unit number.
 * @return        CLX_E_OK        - Dump chip information successfully.
 * @return        CLX_E_OTHERS    - Fail to dump chip information.
 */
clx_error_no_t
hal_chip_info_dump(const uint32 unit);

/**
 * @brief Hal_driver_info_dump() is a function to dump driver information.
 *
 * @param [in]    unit    - The specified unit number.
 * @return        CLX_E_OK        - Dump driver information successfully.
 * @return        CLX_E_OTHERS    - Fail to dump driver information.
 */
clx_error_no_t
hal_driver_info_dump(const uint32 unit);

/**
 * @brief Hal_port_map_info_dump() is a function to dump port mapping information.
 *
 * @param [in]    unit    - The specified unit number.
 * @return        CLX_E_OK        - Dump port mapping information successfully.
 * @return        CLX_E_OTHERS    - Fail to dump port mapping information.
 */
clx_error_no_t
hal_port_map_info_dump(const uint32 unit);

/**
 * @brief Hal_sema_lock() is responsible for lock specific table.
 *
 * @param [in]    unit      - The unit number.
 * @param [in]    tbl_id    - The table id.
 * @return        CLX_E_OK        - Successfully read table.
 * @return        CLX_E_OTHERS    - Fail to read table.
 */
clx_error_no_t
hal_sema_lock(const uint32 unit, const uint32 tbl_id);

/**
 * @brief Hal_sema_unlock() is responsible for unlock specific table.
 *
 * @param [in]    unit      - The unit number.
 * @param [in]    tbl_id    - The table id.
 * @return        CLX_E_OK        - Successfully read table.
 * @return        CLX_E_OTHERS    - Fail to read table.
 */
clx_error_no_t
hal_sema_unlock(const uint32 unit, const uint32 tbl_id);

/**
 * @brief Hal_hash_bank_bmp_set() is responsible for setting specific one hash bank bitmap.
 *
 * @param [in]    unit        - The unit number.
 * @param [in]    type        - The hash type.
 * @param [in]    bank_bmp    - Bank bitmap.
 * @return        CLX_E_OK        - Successfully read table.
 * @return        CLX_E_OTHERS    - Fail to read table.
 */
clx_error_no_t
hal_hash_bank_bmp_set(const uint32 unit, const hal_hash_type_t type, const uint32 bank_bmp);

/**
 * @brief Hal_hash_multi_bank_bmp_set() is responsible for setting specific many hash bank bitmap.
 *
 * @param [in]    unit        - The unit number.
 * @param [in]    type        - The hash type.
 * @param [in]    bank_bmp    - Point of bank bitmap. NULL.
 * @return        CLX_E_OK        - Successfully read table.
 * @return        CLX_E_OTHERS    - Fail to read table.
 */
clx_error_no_t
hal_hash_multi_bank_bmp_set(const uint32 unit, const hal_hash_type_t type, const uint32 *bank_bmp);

/**
 * @brief Hal_port_bitmap_update is used to update port bitmap.
 *
 * This function only update bitmap of front port.
 *
 * @param [in]    unit     - The chip unit number.
 * @param [in]    port     - Physical port number.
 * @param [in]    value    - Bit value (0 or 1).
 * @return        CLX_E_OK    - Operation successfully.
 */
clx_error_no_t
hal_port_bitmap_update(const uint32 unit, const uint32 port, const uint32 value);

/**
 * @brief Hal_port_di_alloc is used to allocate di for a port.
 *
 * 1. Port should not be cpu port or cpi with cpu mode
 * 2. In warm init, just return previous allocated DI.
 *
 * @param [in]     unit      - The chip unit number.
 * @param [in]     port      - Port ID.
 * @param [out]    ptr_di    - Phy port DI.
 * @return         CLX_E_OK        - Initialized successfully.
 * @return         CLX_E_OTHERS    - Internal error.
 */
clx_error_no_t
hal_port_di_alloc(const uint32 unit, const uint32 port, uint32 *ptr_di);

/**
 * @brief Hal_port_di_map_update is used to update per port used di and di map.
 *
 * @param [in]    unit    - The chip unit number.
 * @param [in]    port    - Port ID.
 * @param [in]    di      - Port Destination index.
 * @return        CLX_E_OK        - Initialized successfully.
 * @return        CLX_E_OTHERS    - Internal error.
 */
clx_error_no_t
hal_port_di_map_update(const uint32 unit, const uint32 port, const uint32 di);

/**
 * @brief Hal_port_di_get is used to get port di.
 *
 * @param [in]     unit      - The chip unit number.
 * @param [in]     port      - Port ID.
 * @param [out]    ptr_di    - Port destination index.
 * @return         CLX_E_OK        - Initialized successfully.
 * @return         CLX_E_OTHERS    - Internal error.
 */
clx_error_no_t
hal_port_di_get(const uint32 unit, const uint32 port, uint32 *ptr_di);

/**
 * @brief Hal_db_dump is used to dump hal swdb.
 *
 * @param [in]    unit     - The chip unit number.
 * @param [in]    flags    - Dump flags.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_db_dump(const uint32 unit, const uint32 flags);

/**
 * @brief Hal_rim_rsc_dump_by_idx is used to dump rim resoure use info by index.
 *
 * @param [in]    unit     - The chip unit number.
 * @param [in]    plane    - The chip plane/sub-plane number.
 * @param [in]    index    - The rim resource table index.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_rim_rsc_dump_by_idx(const uint32 unit, const uint32 plane, const uint32 index);

/**
 * @brief Hal_rim_rsc_usage_dump is used to dump rim resoure use info.
 *
 * @param [in]    unit     - The chip unit number.
 * @param [in]    plane    - The chip plane/sub-plane number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_rim_rsc_usage_dump(const uint32 unit, const uint32 plane);

/**
 * @brief Hal_ui32_fld_msk is used to get table field mask length.
 *
 * @param [in]    unit        - The chip unit number.
 * @param [in]    table_id    - Table id.
 * @param [in]    field       - Table field id.
 * @return        Field mask length.
 */
uint32
hal_ui32_fld_mask(const uint32 unit, const uint32 table_id, const uint32 field);

/**
 * @brief Hal_fld_sel_pack is used to pack field select key.
 *
 * @param [in]     unit             - The chip unit number.
 * @param [in]     table_id         - Table id.
 * @param [in]     sel_field_bmp    - Field select bitmap.
 * @param [in]     ptr_entry        - Entry buffer.
 * @param [out]    ptr_sel_buf      - Field select key buffer.
 * @return         Total bits.
 */
uint32
hal_fld_sel_pack(const uint32 unit,
                 const uint32 table_id,
                 const uint32 sel_field_bmp,
                 const uint32 *ptr_entry,
                 uint32 *ptr_sel_buf);
/**
 * @brief Hal_fld_sel_id_pack is used to pack field select key by field id.
 *
 * @param [in]     unit             - The chip unit number.
 * @param [in]     table_id         - Table id.
 * @param [in]     sel_field_bmp    - Field select bitmap.
 * @param [in]     pack_field_id    - Pack field id.
 * @param [in]     ptr_entry        - Entry buffer.
 * @param [out]    ptr_sel_buf      - Field select key buffer.
 * @return         Total bits.
 */
uint32
hal_fld_sel_id_pack(const uint32 unit,
                    const uint32 table_id,
                    const uint32 sel_field_bmp,
                    const uint32 pack_field_id,
                    const uint32 *ptr_entry,
                    uint32 *ptr_sel_buf);

/**
 * @brief Hal_fld_sel_unpack is used to unpack field select key.
 *
 * @param [in]     unit             - The chip unit number.
 * @param [in]     table_id         - Table id.
 * @param [in]     sel_field_bmp    - Field select bitmap.
 * @param [in]     ptr_sel_buf      - Field select key buffer.
 * @param [out]    ptr_entry        - Entry buffer.
 * @return         Total bits.
 */
uint32
hal_fld_sel_unpack(const uint32 unit,
                   const uint32 table_id,
                   const uint32 sel_field_bmp,
                   const uint32 *ptr_sel_buf,
                   uint32 *ptr_entry);

/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */
extern uint32 _ext_warm_boot_flag;

extern uint32 _ext_tob_zero_buf[HAL_MAX_ENTRY_WORD_SIZE];

extern hal_drv_func_vec_t *_ext_ptr_chip_func_vector[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

extern hal_chip_info_t *_ext_ptr_chip_info[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

extern hal_chip_cb_t _ext_chip_control_block[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

extern hal_cmn_drv_func_vec_t *_ext_ptr_chip_cmn_func_vector[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
#endif /* #ifndef HAL_H */
