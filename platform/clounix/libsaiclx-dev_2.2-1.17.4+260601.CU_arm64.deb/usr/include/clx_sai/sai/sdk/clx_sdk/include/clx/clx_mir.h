/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_mir.h
 * PURPOSE:
 *      Define the declaration for mirror module in CLX SDK.
 *
 * NOTES:
 */

#ifndef CLX_MIR_H
#define CLX_MIR_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
/* Mirror direction */
typedef enum clx_mir_direct_e {
    CLX_MIR_DIRECTION_INGRESS = 0, /* ingress mirror session */
    CLX_MIR_DIRECTION_EGRESS,      /* egress mirror session */
    CLX_MIR_DIRECTION_LAST,
} clx_mir_direct_t;

/* Mirror type */
typedef enum clx_mir_type_e {
    CLX_MIR_TYPE_LOCALSPAN = 0, /* mirror session type is local span */
    CLX_MIR_TYPE_RSPAN_ENCAP,   /* mirror session type is rspan encap */
    CLX_MIR_TYPE_RSPAN_DECAP,   /* mirror session type is rspan decap */
    CLX_MIR_TYPE_ERSPAN_ENCAP,  /* mirror session type is erspan encap */
    CLX_MIR_TYPE_ERSPAN_DECAP,  /* mirror session type is erspan decap */
    CLX_MIR_TYPE_LOCALSPAN_EXT, /* mirror session type is local span with extended header, CLX86
                                 * unsupported. CLX84 format [ether_type, device_id, flags, mirror
                                 * id, port, ingress TS] ether_type:
                                 * CLX_SWC_CFG_MIR_SESSION_LOCALSPAN_EXT_ETHER_TYPE device_id:
                                 * CLX_SWC_CFG_TELM_NODE_ID flags:
                                 * CLX_SWC_CFG_MIR_SESSION_LOCALSPAN_EXT_FLAGS mirror id: mirror
                                 * session id port: packet incoming port ingress TS: packet incoming
                                 * timestamp
                                 */
    CLX_MIR_TYPE_LAST,
} clx_mir_type_t;

/* ERSPAN header type */
typedef enum clx_mir_erspan_type_e {
    CLX_MIR_ERSPAN_TYPE_I = 0,           /* ERSPAN type I. CLX84, CLX86 not support */
    CLX_MIR_ERSPAN_TYPE_II,              /* ERSPAN type II, header size is 8 bytes */
    CLX_MIR_ERSPAN_TYPE_III,             /* ERSPAN type III, header size is 12 bytes */
    CLX_MIR_ERSPAN_TYPE_III_WITH_OPTION, /* ERSPAN type III with option, header size is 20 bytes */
    CLX_MIR_ERSPAN_TYPE_FLEX_TUNNEL,     /* Use flex_tunnel_idx point to flex tunnel */
    CLX_MIR_ERSPAN_TYPE_LAST,
} clx_mir_erspan_type_t;

/* ERSPAN header configuration */
typedef struct clx_mir_erspan_hdr_s {
    clx_mac_t smac;                    /* L2 source MAC address                 */
    clx_mac_t dmac;                    /* L2 destination MAC address            */
    clx_ip_addr_t sip;                 /* Source IPv4 address                   */
    clx_ip_addr_t dip;                 /* Destination IPv4 address              */
    uint8 dscp;                        /* Differentiated Services Code Point    */
    uint8 ttl;                         /* Hop limit                             */
    uint32 init_seq_num;               /* Initial sequence number of GRE header */
    clx_mir_erspan_type_t erspan_type; /* Type of ERSPAN header                 */
    uint32 erspan_id;                  /* ERSPAN ID in ERSPAN header            */
    uint8 flex_tunnel_idx;             /* Point to flex tunnel */
} clx_mir_erspan_hdr_t;

/* ERSPAN decap key information */
typedef struct clx_mir_erspan_decap_key_s {
    clx_ip_addr_t sip; /* Source IP address      */
    clx_ip_addr_t dip; /* Destination IP address */
    uint32 erspan_id;  /* ERSPAN ID              */
    uint16 vrfo;       /* Vrf id of the underlay network. */
} clx_mir_erspan_decap_key_t;

/* Mirror session information */
typedef struct clx_mir_session_cfg_s {
    clx_mir_type_t mir_type;     /* Mirror type                           */
    uint32 truncate_size;        /* Truncate size
                                    CLX86 only support 64/128/192/256/512/984
                                    CLX84 only support 64/128/192/232/424/464/888 */
    uint32 meter_rate;           /* Rate limitation (unit: 1kbps or 1pps) */
    uint32 meter_burst_size;     /* Burst size (unit: 1byte or 1pkt)      */
    clx_port_t port;             /* Destination port/lag                  */
    clx_vlan_t cvid;             /* cvid value for RSPAN/ERSPAN           */
    uint8 pcp;                   /* pcp value for RSPAN/ERSPAN            */
    uint8 dei;                   /* dei value for RSPAN/ERSPAN            */
    clx_mir_erspan_hdr_t erspan; /* ERSPAN configuration                  */
    uint32 sample_rate;          /* sample mirror packet, 0: all drop, 1: every packet sampling */
    uint32 fcm_idx;              /* FCM index for mirror session, CLX86 not support */
    uint8 tc;                    /* Traffic class mirror session, CLX86 not support */
    uint32 flags;                /* Set CLX_MIR_SESSION_CFG_FLAGS_xxx flag */
} clx_mir_session_cfg_t;

#define CLX_MIR_SESSION_CFG_FLAGS_METER_EN   (1U << 0) /* If set, enable rate limitation */
#define CLX_MIR_SESSION_CFG_FLAGS_CVID_VALID (1U << 1) /* If set, add C-TAG for RSPAN/ERSPAN */
/* Replace or add tag for RSPAN VLAN operation */
#define CLX_MIR_SESSION_CFG_FLAGS_RSPAN_REPLACE_TAG (1U << 2)
/* If set, GRE header with sequence number */
#define CLX_MIR_SESSION_CFG_FLAGS_ERSPAN_SEQ_NUM (1U << 3)
/* RSPAN DST: Whether not to decap VLAN TAG       \
 * ERSPAN DST: Whether not to decap ERSPAN header \
 */
#define CLX_MIR_SESSION_CFG_FLAGS_NO_DECAP (1U << 4)
/* ERSPAN DST: If set, translate from ERSPAN to RSPAN format */
#define CLX_MIR_SESSION_CFG_FLAGS_ERSPAN_TO_RSPAN_TRAN (1U << 5)
/* RSPAN DST: If set, translate from RSPAN to ERSPAN format */
#define CLX_MIR_SESSION_CFG_FLAGS_RSPAN_TO_ERSPAN_TRAN (1U << 6)
/* If set, rate limitation uses packet rate */
#define CLX_MIR_SESSION_CFG_FLAGS_METER_PACKET_RATE (1U << 7)
/* If set, use meter_burst_size as meter burst size */
#define CLX_MIR_SESSION_CFG_FLAGS_METER_BURST_SIZE (1U << 8)
/* If set, use sample_rate to sample mirror packet */
#define CLX_MIR_SESSION_CFG_FLAGS_SAMPLE_RATE (1 << 9)
/* If set, use fcm_idx for mirror session, CLX86 not support */
#define CLX_MIR_SESSION_CFG_FLAGS_FCM_IDX (1 << 10)
/* If set, use tc for mirror session, CLX86 not support */
#define CLX_MIR_SESSION_CFG_FLAGS_TC (1 << 11)

typedef clx_error_no_t (*clx_mir_erspan_decap_trav_func_t)(
    const uint32 unit,
    const clx_mir_erspan_decap_key_t *ptr_decap_cfg,
    const uint32 mir_id,
    void *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief This API is used to get mirror session information. User should specify the direction and
 *        session ID.
 *
 * User must specify the direction, session ID.
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     direction          - The session direction.
 * @param [in]     mir_id             - The session ID.
 * @param [out]    ptr_session_cfg    - The information of this session to be obtained.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
clx_error_no_t
clx_mir_session_get(const uint32 unit,
                    const clx_mir_direct_t direction,
                    const uint32 mir_id,
                    clx_mir_session_cfg_t *ptr_session_cfg);

/**
 * @brief This API is used to add or set a mirror session.
 *
 * Mirror module supports six mirror session types, including:
 * (1). Local SPAN session.
 * (2). RSPAN encap session.
 * (3). RSPAN decap session.
 * (4). ERSPAN encap session.
 * (5). ERSPAN decap session.
 * (6). Local SPAN with extended header session.
 * User should specify the session ID, direction and type when set an existed session.
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit               - Device unit number.
 * @param [in]    direction          - The session direction.
 * @param [in]    mir_id             - The session ID.
 * @param [in]    ptr_session_cfg    - The session information.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_EXISTS       - The session has been created.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 * @return        CLX_E_NOT_SUPPORT        - Feature is not supported.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_mir_session_add(const uint32 unit,
                    const clx_mir_direct_t direction,
                    const uint32 mir_id,
                    const clx_mir_session_cfg_t *ptr_session_cfg);

/**
 * @brief This API is used to delete a mirror session. User should specify the mirror direction and
 *        mirror id. Before deleting a mirror session, all sources binding to the session should be
 *        unbound first.
 *
 * Before deleting a mirror session, all mirror sources bound to the session
 * should be removed first.
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    direction    - The session direction.
 * @param [in]    mir_id       - The session ID.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
clx_error_no_t
clx_mir_session_del(const uint32 unit, const clx_mir_direct_t direction, const uint32 mir_id);

/**
 * @brief This API is used to get an ERSPAN tunnel decap information.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     ptr_decap_key    - The ERSPAN decap key.
 * @param [out]    ptr_mir_id       - The mirror session ID.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
clx_error_no_t
clx_mir_erspan_decap_get(const uint32 unit,
                         const clx_mir_erspan_decap_key_t *ptr_decap_key,
                         uint32 *ptr_mir_id);

/**
 * @brief This API is used to add an ERSPAN tunnel decap.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    ptr_decap_key    - The ERSPAN decap key.
 * @param [in]    mir_id           - The mirror ID.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
clx_error_no_t
clx_mir_erspan_decap_add(const uint32 unit,
                         const clx_mir_erspan_decap_key_t *ptr_decap_key,
                         const uint32 mir_id);

/**
 * @brief This API is used to delete an ERSPAN tunnel decap.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    ptr_decap_key    - The ERSPAN decap key.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
clx_error_no_t
clx_mir_erspan_decap_del(const uint32 unit, const clx_mir_erspan_decap_key_t *ptr_decap_key);

/**
 * @brief This API is used to traverse ERSPAN tunnel decap information.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - The callback function of type clx_mir_erspan_decap_trav_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_mir_erspan_decap_trav(const uint32 unit,
                          const clx_mir_erspan_decap_trav_func_t callback,
                          void *ptr_cookie);

#endif
