/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_export_arp.h
 * PURPOSE:
 *      It provide ARP export module api.
 * NOTES:
 *
 */

#ifndef __HAL_EXPORT_ARP_H__
#define __HAL_EXPORT_ARP_H__

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <util/lib/util_lib_list.h>
#include <hal/hal_eparser.h>

#ifdef __cplusplus
extern "C" {
#endif

/* NAMING CONSTANT DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* ARP message type definitions */
typedef enum hal_export_arp_msg_type_e {
    HAL_EXPORT_ARP_MSG_INVALID = 0,
    HAL_EXPORT_ARP_MSG_START = 1,
    HAL_EXPORT_ARP_MSG_DONE = 2,
    HAL_EXPORT_ARP_MSG_ERROR = 3,
} hal_export_arp_msg_type_t;

/* After eparser header, without hal_export_arp_msg_hdr_t. */
typedef struct hal_export_arp_request_msg_s {
    hal_export_arp_msg_type_t msg_type; /* Message type, should be HAL_EXPORT_ARP_MSG_START:1 */
    uint8_t isIncludeIpv4;              /* 0: not include, 1: include */
    uint8_t isIncludeIpv6;              /* 0: not include, 1: include */
    uint8_t reserved1;                  /* Reserved for future use */
    uint8_t reserved2;                  /* Reserved for future use */
} hal_export_arp_request_msg_t;
#define HAL_EXPORT_ARP_ACTION_FLAG_IPV4_INCLUDE (0x01) /* Include IPv4 */
#define HAL_EXPORT_ARP_ACTION_FLAG_IPV6_INCLUDE (0x02) /* Include IPv6 */

/* ARP TLV type definitions */
#define HAL_EXPORT_TLV_TYPE_ARP_COUNT          (0x11) /* ARP entry count */
#define HAL_EXPORT_TLV_TYPE_ARP_ENTRY_LEN      (0x12) /* ARP entry length */
#define HAL_EXPORT_TLV_TYPE_ARP_ENTRIES        (0x13) /* ARP entry data */
#define HAL_EXPORT_TLV_TYPE_ARP_IPV6_COUNT     (0x14) /* ARP IPv6 entry count */
#define HAL_EXPORT_TLV_TYPE_ARP_IPV6_ENTRY_LEN (0x15) /* ARP IPv6 entry length */
#define HAL_EXPORT_TLV_TYPE_ARP_IPV6_ENTRIES   (0x16) /* ARP IPv6 entry data */

/* ARP list structure for multi-threaded export, with separate IPv4/IPv6 lists */
typedef struct hal_export_arp_mt_list_s {
    util_lib_list_t *ipv4_list; /* IPv4 ARP entry list */
    util_lib_list_t *ipv6_list; /* IPv6 ARP entry list */
    uint32_t ipv4_count;        /* IPv4 entry count */
    uint32_t ipv6_count;        /* IPv6 entry count */
} hal_export_arp_mt_list_t;

/* ARP IPv4 entry structure */
typedef struct hal_export_arp_entry_s {
    uint32_t ip_addr;    /* IPv4 address */
    uint16_t vrf;        /* vrf */
    uint16_t bd_id;      /* BD ID */
    uint32_t port_id;    /* Port ID */
    uint8_t mac_addr[6]; /* MAC address */
    uint8_t reserved[2]; /* Reserved for future use */
} hal_export_arp_entry_t;

/* ARP IPv6 entry structure */
typedef struct hal_export_arp_ipv6_entry_s {
    uint8_t ipv6_addr[16]; /* IPv6 address */
    uint16_t vrf;          /* vrf */
    uint16_t bd_id;        /* BD ID */
    uint32_t port_id;      /* Port ID */
    uint8_t mac_addr[6];   /* MAC address */
    uint8_t reserved[2];   /* Reserved for future use */
} hal_export_arp_ipv6_entry_t;

/* Message header structure with fragment flags */
typedef struct hal_export_arp_msg_hdr_s {
    hal_export_arp_msg_type_t msg_type; /* Message type */
    uint8_t fragment_index;             /* Current fragment index, 0-based */
    uint8_t total_fragments;            /* Total number of fragments */
    uint16_t reserved;                  /* Reserved for future use */
} hal_export_arp_msg_hdr_t;

/* Export ARP common notify event types */
typedef enum hal_export_arp_notify_event_e {
    HAL_EXPORT_ARP_EVT_INVALID = 0,
    HAL_EXPORT_ARP_EVT_THREAD_EXIT = 1,
} hal_export_arp_notify_event_t;

/* GLOBAL VARIABLE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Initialize the ARP export module.
 *
 * @param [in]    unit    - Chip unit number.
 * @return        CLX_E_OK    - Operation successful.
 */
clx_error_no_t
hal_export_arp_init(uint32 unit);

/**
 * @brief Deinitialize the ARP export module.
 *
 * @param [in]    unit    - Chip unit number.
 * @return        CLX_E_OK        - Operation successful.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_export_arp_deinit(uint32 unit);

/**
 * @brief Handle ARP export start request.
 *
 * @param [in]    unit        - Chip unit number.
 * @param [in]    msg_type    - Message type.
 * @param [in]    msg         - Message pointer.
 * @param [in]    length      - Message length.
 * @return        CLX_E_OK            - Operation successful.
 * @return        CLX_E_NOT_INITED    - Module not initialized.
 * @return        CLX_E_NO_MEMORY     - Memory allocation failed.
 * @return        CLX_E_OTHERS        - Operation failed.
 */
clx_error_no_t
hal_export_arp_handle_start(uint32 unit,
                            hal_eparser_msg_type_t msg_type,
                            void *msg,
                            uint32_t length);

/**
 * @brief ARP module event processing function.
 *
 * Handle eparser COMMON_NOTIFY events for ARP module. Typically used to stop and
 * destroy export thread and clean up runtime state.
 *
 * @param [in]    unit        - Chip unit number.
 * @param [in]    data        - Event data pointer (can be NULL).
 * @param [in]    data_len    - Event data length in bytes.
 * @return        CLX_E_OK        - Operation successful.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_export_arp_event_proc(uint32 unit, void *data, uint32_t data_len);
#ifdef __cplusplus
}
#endif
#endif /* __HAL_EXPORT_ARP_H__ */