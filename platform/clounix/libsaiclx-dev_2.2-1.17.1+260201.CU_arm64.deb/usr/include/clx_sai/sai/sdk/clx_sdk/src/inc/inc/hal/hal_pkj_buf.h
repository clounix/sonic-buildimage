/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_pkj_buf.h
 * PURPOSE:
 *      It provides table buffer info of packet journal.
 *
 * NOTES:
 *
 */

#ifndef HAL_PKJ_BUF_H
#define HAL_PKJ_BUF_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <tob/tob_tbl.h>
#include <hal/mt/nb/hal_mt_nb_pkj_buf.h>
#include <hal/mt/kg/hal_mt_kg_pkj_buf.h>

/* DATA TYPE DECLARATIONS
 */
typedef struct hal_pkj_buf_pp_info_s {
    uint32 sel_cfg_id;
    uint32 sel_field_id;
    uint32 wsel_field_id;
    uint32 sel_data_id;
    uint32 data_field_id;
    uint32 sub_inst;
} hal_pkj_buf_pp_info_t;

typedef struct hal_pkj_buf_info_s {
    char *ptr_buf_name;
    uint32 pipe; /* MT Chip:HAL_MT_PKJ_PP_FLAGS_XXX */
    uint32 sel_id;
    uint32 table_total_fields;
    uint32 entry_msb;
    packing_info_t *ptr_table_entry;
    uint32 vld_field;
    uint32 hit_field;
    uint32 idx_field;
    uint32 data_field;
    uint32 data_field_num;
    uint32 next_buf_id;
    uint32 tbl_id;
} hal_pkj_buf_info_t;

#endif /* end of #ifndef HAL_PKJ_BUF_H */