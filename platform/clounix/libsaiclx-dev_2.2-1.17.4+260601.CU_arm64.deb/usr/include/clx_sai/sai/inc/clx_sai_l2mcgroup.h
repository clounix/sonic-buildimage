/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_L2MCGROUP_H__)
#define __CLX_SAI_L2MCGROUP_H__


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/

 #define CLXS_L2MCGRP_MAX_MCAST_NUM(__unit__)   ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->l2mc.max_l2mc_num):0)
 #define CLXS_L2MCGRP_MCAST_BMP_SIZE(__unit__)  (CLX_BITMAP_SIZE(CLXS_L2MCGRP_MAX_MCAST_NUM(__unit__)))
 
 #define CLXS_L2MCGRP_SEMA_NAME       ("L2MCG_SEMA")
 #define CLXS_L2MCGRP_MBR_AVL_NAME    ("L2MCG_MBR_AVL")
 
 
 #define CLXS_L2MCGRP_LOCK(__unit__)   sai_osal_mutex_lock(ptr_clxs_l2mcgrp_db[(__unit__)]->sema)
 #define CLXS_L2MCGRP_UNLOCK(__unit__)  sai_osal_mutex_unlock(ptr_clxs_l2mcgrp_db[(__unit__)]->sema)
 
 #define CLXS_L2MCGRP_IS_LEGAL_MCAST_ID(__unit__,__mcast_id__)     \
         ((__mcast_id__) < CLXS_L2MCGRP_MAX_MCAST_NUM(__unit__))
 #define CLXS_L2MCGRP_IS_LEGAL_BD_PORT_ID(__unit__,__bd_port_id__) \
         ((__bd_port_id__) < CLXS_MAX_BRIDGE_PORT_NUM(__unit__))

#define CLXS_L2MCGRP_ADD_LAG_HW_SUPPORT(__unit__)   ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->l2mc.add_lag_hw_support):0)
#define CLXS_L2MCGRP_DB(__unit__) ptr_clxs_l2mcgrp_db[(__unit__)]
#define CLXS_L2MCGRP_VALID_MCAST_BMP(__unit__)     (ptr_clxs_l2mcgrp_db[(__unit__)]->valid_mcast_bmp)
#define CLXS_L2MCGRP_MBR_INFO(__unit__)     (ptr_clxs_l2mcgrp_db[(__unit__)]->ptr_mbr_avl)
#define CLXS_L2MCGRP_MCAST_INFO(__unit__)     (ptr_clxs_l2mcgrp_db[(__unit__)]->mcast_arr)

/*******************************************************************************
 * Data Type Definitions
 *******************************************************************************/
typedef struct clxs_l2mcgrp_mcast_info_s
{
    uint32_t    mbr_cnt;
} clxs_l2mcgrp_mcast_info_t;

typedef struct clxs_l2mcgrp_mbr_node_s
{
    uint32_t    mcast_id;   /* KEY */
    clx_gport_t gport;      /* KEY */
    clxs_l2mc_group_member_attrs_t attr_info;
} clxs_l2mcgrp_mbr_node_t;

typedef struct clxs_l2mcgrp_mbr_cookie_s
{
    uint32_t                unit;
    uint32_t                mcast_id;
    uint32_t                bd_port_id;
    sai_object_id_t         **pptr_oid;
} clxs_l2mcgrp_mbr_cookie_t;

typedef struct clxs_l2mcgrp_db_s
{
    clxs_l2mcgrp_mcast_info_t     *mcast_arr;
    uint32_t                      *valid_mcast_bmp;
    util_lib_avl_head_t           *ptr_mbr_avl;
    clx_semaphore_id_t            sema;
} clxs_l2mcgrp_db_t;

/*******************************************************************************
 * Global Variable Declarations 
 *******************************************************************************/
extern const sai_l2mc_group_api_t       l2mcgroup_api;
extern clxs_l2mcgrp_db_t*               ptr_clxs_l2mcgrp_db[CLXS_MAX_CHIP_NUM];

/*******************************************************************************
 * Function Declarations 
 *******************************************************************************/ 
sai_status_t
clxs_l2mcgrp_init(
    _In_ const uint32_t             unit);

sai_status_t
clxs_l2mcgrp_deinit(
    _In_ const uint32_t             unit);

sai_status_t
clxs_l2mcgrp_get_info(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint32_t                  *ptr_mcast_id);

sai_status_t
clxs_l2mcgrp_get_object(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             mcast_id,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clxs_l2mcgrp_add_mcast_member_gport(
    _In_ const uint32_t                  unit,
    _In_ const uint32_t                  mcast_id,
    _In_ const clx_gport_t               gport);

sai_status_t
clxs_l2mcgrp_del_mcast_member_gport(
    _In_ const uint32_t                  unit,
    _In_ const uint32_t                  mcast_id,
    _In_ const clx_gport_t               gport);
#endif
