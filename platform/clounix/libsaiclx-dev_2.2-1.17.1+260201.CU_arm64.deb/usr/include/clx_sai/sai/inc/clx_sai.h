/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_H__)
#define __CLX_SAI_H__

#include <clx_sai_version.h>
#ifndef CLXS_SAI_HEAD_VERSION
#define CLXS_SAI_HEAD_VERSION                 "1.7.1"
#endif

#ifndef SAI_VERSION
#define SAI_VERSION(major, minor, revision) (10000 * (major) + 100 * (minor) + (revision))
#endif

#ifndef SAI_API_VERSION
/* SAI_MAJOR, SAI_MINOR, SAI_REVISION is defined in clx_sai_version.h when SAI VERSION < 1.8.0 */
#define SAI_API_VERSION SAI_VERSION(SAI_MAJOR, SAI_MINOR, SAI_REVISION)
#endif

#if defined(CLX_STATIC_EN)
#define STATIC static
#else
#define STATIC
#endif

#if !defined(CLXS_SAI_ALPHA_RELEASE)
#define CLXS_SAI_ALPHA_RELEASE 1
#endif

#include <sai.h>
#include <saiextensions.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <syslog.h>
#include <stdarg.h>
#include <assert.h>
#include <inttypes.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <clx_sdk.h>
#include <clx_sai_dispatch.h>
#include <clx_sai_utils.h>
#include <clx_sai_fmt.h>
#include <clx_sai_time.h>
#include <clx_sai_mutex.h>
#include <clx_sai_log.h>
#include <clx_sai_attr.h>
#include <clx_sai_attr_reflection.h>
#include <clx_sai_oid.h>
#include <clx_sai_object.h>
#include <clx_sai_acl_mgmt.h>
#include <clx_sai_port.h>
#include <clx_sai_port_link_delay.h>
#include <clx_sai_qosmap.h>
#include <clx_sai_switch.h>
#include <clx_sai_switch_feature.h>
#include <clx_sai_bridge.h>
#include <clx_sai_vlan.h>
#include <clx_sai_fdb.h>
#include <clx_sai_lag.h>
#include <clx_sai_l2mc.h>
#include <clx_sai_nexthop.h>
#include <clx_sai_nexthopgroup.h>
#include <clx_sai_policer.h>
#include <clx_sai_queue.h>
#include <clx_sai_route.h>
#include <clx_sai_routerinterface.h>
#include <clx_sai_rpfgroup.h>
#include <clx_sai_samplepacket.h>
#include <clx_sai_scheduler.h>
#include <clx_sai_schedulergroup.h>
#include <clx_sai_stp.h>
#include <clx_sai_tunnel.h>
#include <clx_sai_udf.h>
#include <clx_sai_wred.h>
#include <clx_sai_virtualrouter.h>
#include <clx_sai_acl.h>
#include <clx_sai_pkt_rx.h>
#include <clx_sai_buffer.h>
#include <clx_sai_counter.h>
#include <clx_sai_debugcounter.h>
#include <clx_sai_hash.h>
#include <clx_sai_hostif.h>
#include <clx_sai_ipmc.h>
#include <clx_sai_ipmcgroup.h>
#include <clx_sai_isolationgroup.h>
#include <clx_sai_l2mcgroup.h>
#include <clx_sai_mcastfdb.h>
#include <clx_sai_mirror.h>
#include <clx_sai_neighbor.h>
#include <clx_sai_monitor.h>
#include <clx_sai_tam_int.h>
#include <clx_sai_tam.h>
#include <clx_sai_diag.h>
#include <clx_sai_ext_phy.h>
#include <clx_sai_hotpatch_init.h>
#include <clx_sai_bfd.h>

#include <parser/dsh_parser.h>
#include <parser/dsh_util.h>

#include <execinfo.h>

#include <shal.h>


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_BRIDGE_BD_NUM(__unit__)                              ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->bridge.max_bd_num):0)
#define CLXS_MAX_BRIDGE_PORT_NUM(__unit__)                        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->bridge.max_bridge_port_num):0)
#define CLXS_BRIDGE_SUPPORT_EGRESS_VLAN_FILTER(__unit__)          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->bridge.support_egress_vlan_filter):true)
#define CLXS_MAX_PORT_MTU(__unit__)                               ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->port.max_port_mtu) :0)
#define CLXS_PORT_SUPPORT_HW_IP_COUNTER(__unit__)                 (((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->port.support_hw_ip_counter):0))
#define CLXS_CPU_PORT(__unit__)                                   ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->port.cpu_port_num):0)
#define CLXS_FDB_SUPPORT_FLUSH(__unit__)                          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->fdb.support_flush):0)
#define CLXS_MAX_LAG_NUM(__unit__)                                ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->lag.max_lag_num):0)
#define CLXS_MAX_PORT_NUM_PER_LAG(__unit__)                       ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->lag.max_port_num_per_lag):0)
#define CLXS_MIN_WRED_PROFILE_NUM(__unit__)                       ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->wred.min_wred_profile_num):0)
#define CLXS_MAX_WRED_PROFILE_NUM(__unit__)                       ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->wred.max_wred_profile_num):0)
#define CLXS_MAX_STP_NUM(__unit__)                                ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->stp.max_stp_num):0)
#define CLXS_MAX_NEIGHBOR_NUM(__unit__)                           ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->neighbor.max_neighbor_num):0)
#define CLXS_NEIGHBOR_V6_LENGTH(__unit__)                         ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->neighbor.multiple_v6_for_v4):0)
#define CLXS_MAX_NEXTHOP_NUM(__unit__)                            ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->nexthop.max_nexthop_num):0)
#define CLXS_MAX_ROUTE_NUM(__unit__)                              ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->route.max_route_num):0)
#define CLXS_MAX_ECMP_PATH_NUM(__unit__)                          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->nexthopgroup.max_ecmp_path_num):0)
#define CLXS_MAX_ECMP_GROUP_NUM(__unit__)                         ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->nexthopgroup.max_ecmp_group_num):0)
#define CLXS_ECMP_PATH_NUM_PER_GROUP(__unit__)                    ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->nexthopgroup.path_num_per_group):64)

#define CLXS_MAX_QOSMAP_PROFILE_NUM(__unit__)                     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->qos.max_profile_num):0)
#define CLXS_MAX_QOSMAP_TC_COUNT(__unit__)                        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->qos.max_tc_count):8)
#define CLXS_MAX_QOSMAP_TC_PROFILE_NUM(__unit__)                  ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->qos.max_tc_profile_num):0)
#define CLXS_MAX_QOSMAP_TC_MAP_SUPPORT_PORT(__unit__)             ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->qos.tc_map_support_port):false)
#define CLXS_MAX_QOSMAP_PFC_LOSSLESS_QUEUE_NUM(__unit__)          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->qos.pfc_lossless_queue_num):0)
#define CLXS_MAX_QOSMAP_PFC_LOSSLESS_GLOBAL_SET(__unit__)         ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->qos.pfc_lossless_global_set):false)

#define CLXS_MAX_SAMPLEPKT_PROFILE_NUM(__unit__)                  ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->samplepkt.max_samplepkt_profile_num ):0)
#define CLXS_SAMPLEPKT_SUPPORT_EGR_SFLOW_GET_DST_PORT(__unit__)   ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->samplepkt.support_egr_sflow_get_dst_port ):false)

#define CLXS_MAX_RPFGRP_NUM(__unit__)                             ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rpfgroup.max_rpfgroup_num):0)
#define CLXS_MAX_RPFGRP_MEMBER(__unit__)                          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rpfgroup.max_rpfgroup_member_num):0)

#define CLXS_DFLT_CFG_PKT_RX_GPD_NUM(__unit__)                    ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->hostif.dflt_cfg_pkt_rx_gpd_num):0)
#define CLXS_CPU_PORT_RX_CHANNEL_NUM(__unit__)                    ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->hostif.cpu_port_rx_channel_num):0)
#define CLXS_HOSTIF_SUPPORT_STAT_TRAP_PKT(__unit__)               ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->hostif.support_stat_trap_pkt):0)

#define CLXS_BUF_CELL_BYTE_SIZE(__unit__)                         ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.cell_byte_size):0)
#define CLXS_BUF_IGR_POOL_SIZE(__unit__)                          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.igr_pool_size):0)
#define CLXS_BUF_EGR_POOL_SIZE(__unit__)                          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.egr_pool_size):0)

#define CLXS_BUF_IGR_PROFILE_NUM(__unit__)                        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.igr_profile_num):0)
#define CLXS_BUF_EGR_PROFILE_NUM(__unit__)                        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.egr_profile_num):0)
#define CLXS_BUF_DFLT_IGR_PROF_ID(__unit__)                       ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.default_igr_prof_id):0)
#define CLXS_BUF_DFLT_EGR_PROF_ID(__unit__)                       ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.default_egr_prof_id):0)
#define CLXS_BUF_DFLT_IGR_MIN_TH(__unit__)                        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.default_igr_min_th):0)
#define CLXS_BUF_DFLT_EGR_MIN_TH(__unit__)                        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.default_egr_min_th):0)
#define CLXS_BUF_DFLT_XON_TH(__unit__)                            ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.default_xon_th):0)
#define CLXS_BUF_DFLT_XOFF_TH(__unit__)                           ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.default_xoff_th):0)
#define CLXS_BUF_DFLT_DYNAMIC_MAX_TH(__unit__)                    ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.default_dynamic_max_th):0)
#define CLXS_BUF_DFLT_IGR_STATIC_MAX_TH(__unit__)                 ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.default_igr_static_max_th):0)
#define CLXS_BUF_DFLT_EGR_STATIC_MAX_TH(__unit__)                 ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.default_egr_static_max_th):0)
#define CLXS_TM_SUPPORT(__unit__)                                 ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.support_tm):false)
#define CLXS_BUF_SUPPORT_PFC_WD(__unit__)                         ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.support_pfc_watchdog):false)
#define CLXS_BUF_SUPPORT_IGR_WATERMARK(__unit__)                  ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.support_igr_watermark):false)
#define CLXS_BUF_RED_ALWAYS_DROP(__unit__)                        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.red_always_drop):false)
#define CLXS_BUF_SUPPORT_HEADROOM_STAT(__unit__)                  ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.support_headroom_stat):false)
#define CLXS_BUF_SUPPORT_IGR_PG_DROP_STAT(__unit__)               ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.support_igr_pg_drop_stat):false)

#define CLXS_BUF_SUPPORT_EGR_DYNAMIC(__unit__)                     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.support_egr_dynamic):false)
#define CLXS_BUF_IGR_STAITC_ONLY(__unit__)                         ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.igr_static_only):false)
#define CLXS_BUF_DUAL_POOL_MODE(__unit__)                          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.dual_pool_mode):false)
#define CLXS_BUF_SUPPORT_SET_GLOBAL_LOSSLESS_TC(__unit__)         ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.support_set_global_lossless_tc):false)

#define CLXS_MAX_NUM_OF_IGR_MIR_SES(__unit__)                     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->mirror.max_igr_session_num):0)
#define CLXS_MAX_NUM_OF_EGR_MIR_SES(__unit__)                     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->mirror.max_igr_session_num):0)
#define CLXS_MAX_NUM_OF_MIR_SES(__unit__)                         (CLXS_MAX_NUM_OF_IGR_MIR_SES(__unit__) + CLXS_MAX_NUM_OF_EGR_MIR_SES(__unit__))
#define CLXS_MIR_SUPPORT_TC(__unit__)                             ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->mirror.support_tc):false)

#define CLXS_RSV_STP_ALL_DROP(__unit__)                           ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->stp.rsv_stp_drop):0)
#define CLXS_RSV_STP_ALL_FWD(__unit__)                            ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->stp.rsv_stp_fwd):0)
#define CLXS_RSV_STP_ALL_LRN(__unit__)                            ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->stp.rsv_stp_lrn):0)
#define CLXS_STP_RSV_NUM(__unit__)                                ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->stp.rsv_stp_num):0)

#define CLXS_ACL_TABLE_NUM_IGR(__unit__)                          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.igr_acl_table_num):0)
#define CLXS_ACL_TABLE_NUM_IGR_POST(__unit__)                     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.igr_post_acl_table_num):0)
#define CLXS_ACL_TABLE_NUM_IGR_ALL(__unit__)                     (CLXS_ACL_TABLE_NUM_IGR(__unit__) + CLXS_ACL_TABLE_NUM_IGR_POST(__unit__))
#define CLXS_ACL_TABLE_NUM_EGR(__unit__)                          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.egr_acl_table_num):0)
#define CLXS_ACL_TABLE_NUM_EGR_POST(__unit__)                     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.egr_post_acl_table_num):0)
#define CLXS_ACL_TABLE_NUM_EGR_ALL(__unit__)                     (CLXS_ACL_TABLE_NUM_EGR(__unit__) + CLXS_ACL_TABLE_NUM_EGR_POST(__unit__))
#define CLXS_ACL_ENTRY_NUM_IGR(__unit__)                          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.igr_acl_entry_num):0)
#define CLXS_ACL_ENTRY_NUM_IGR_POST(__unit__)                     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.igr_post_acl_entry_num):0)
#define CLXS_ACL_ENTRY_NUM_IGR_ALL(__unit__)                      (CLXS_ACL_ENTRY_NUM_IGR(__unit__) + CLXS_ACL_ENTRY_NUM_IGR_POST(__unit__))
#define CLXS_ACL_ENTRY_NUM_EGR(__unit__)                          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.egr_acl_entry_num):0)
#define CLXS_ACL_ENTRY_NUM_EGR_POST(__unit__)                     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.egr_post_acl_entry_num):0)
#define CLXS_ACL_ENTRY_NUM_EGR_ALL(__unit__)                      (CLXS_ACL_ENTRY_NUM_EGR(__unit__) + CLXS_ACL_ENTRY_NUM_EGR_POST(__unit__))
#define CLXS_ACL_ENTRY_NUM_MAX(__unit__)                          (CLXS_ACL_ENTRY_NUM_IGR_ALL(__unit__) + CLXS_ACL_ENTRY_NUM_EGR_ALL(__unit__))
#define CLXS_ACL_TABLE_PRIO_MIN_IGR(__unit__)                     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.igr_acl_table_prio_min):0)
#define CLXS_ACL_TABLE_PRIO_MAX_IGR(__unit__)                     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.igr_acl_table_prio_max):0)
#define CLXS_ACL_TABLE_PRIO_MIN_EGR(__unit__)                     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.egr_acl_table_prio_min):0)
#define CLXS_ACL_TABLE_PRIO_MAX_EGR(__unit__)                     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.egr_acl_table_prio_max):0)
#define CLXS_ACL_USER_META_PORT_MIN(__unit__)                     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.user_meta_port_min):0)
#define CLXS_ACL_USER_META_PORT_MAX(__unit__)                     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.user_meta_port_max):0)
#define CLXS_ACL_USER_META_PORT_OFFSET(__unit__)                  ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.user_meta_port_offset):0)
#define CLXS_ACL_USER_META_FDB_DST_MIN(__unit__)                  ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.user_meta_fdb_min):0)
#define CLXS_ACL_USER_META_FDB_DST_MAX(__unit__)                  ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.user_meta_fdb_max):0)
#define CLXS_ACL_USER_META_ROUTE_DST_MIN(__unit__)                ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.user_meta_route_dst_min):0)
#define CLXS_ACL_USER_META_ROUTE_DST_MAX(__unit__)                ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.user_meta_route_dst_max):0)
#define CLXS_ACL_USER_META_NEIGHBOR_DST_MIN(__unit__)             ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.user_meta_neighbor_dst_min):0)
#define CLXS_ACL_USER_META_NEIGHBOR_DST_MAX(__unit__)             ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.user_meta_neighbor_dst_max):0)
#define CLXS_ACL_USER_META_ACL_MIN(__unit__)                      ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.user_meta_acl_min):0)
#define CLXS_ACL_USER_META_ACL_MAX(__unit__)                      ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.user_meta_acl_max):0)
#define CLXS_ACL_SUPPORTED_SERVICE_GROUP_LABEL(__unit__)          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.support_service_group_label):0)
#define CLXS_ACL_SUPPORTED_L3_INTF_GROUP_LABEL(__unit__)          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.support_l3_intf_group_label):0)
#define CLXS_ACL_SUPPORTED_TCP_FLAG_FIELD(__unit__)               ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.support_tcp_flag_field):0)
#define CLXS_ACL_SUPPORTED_ECMP_TRACER_USING_ACL(__unit__)        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.support_ecmp_tracer_using_acl):0)
#define CLXS_ACL_SUPPORTED_ECN_MARKED_COUNT_USING_ACL(__unit__)   ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.support_ecn_marked_count_using_acl):0)
#define CLXS_ACL_SUPPORTED_V6_FLOW_LABEL_FIELD(__unit__)          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.support_v6_flow_label_field):0)
#define CLXS_ACL_SUPPORTED_FCOE(__unit__)                         ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.support_fcoe):0)
#define CLXS_ACL_SUPPORTED_QOS_ACTION_INVALID(__unit__)           ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.support_qos_action_invalid):0)
#define CLXS_ACL_SUPPORTED_FLEX_KEY(__unit__)                     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.support_flex_key):0)
#define CLXS_ACL_SUPPORTED_TRAP_REASON(__unit__)                  ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.support_trap_reason):0)
#define CLXS_ACL_SUPPORTED_METER_THREE_COLOR_STAT(__unit__)     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.support_meter_three_color_stat):0)

#define CLXS_NUM_RIF(__unit__)                                    ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rif.max_rif_num):0)
#define CLXS_NUM_RTE(__unit__)                                    ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rif.max_rte_mac_num):0)
#define CLXS_NUM_TNL_RTE(__unit__)                                ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rif.max_tnl_rte_mac_num):0)
#define CLXS_MAX_TNL_RTE_IDX(__unit__)                            ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rif.max_tnl_rte_mac_idx):0)
#define CLXS_MIN_TNL_RTE_IDX(__unit__)                            ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rif.min_tnl_rte_mac_idx):0)

#define CLXS_UDF_MATCH_MAX_NUM(__unit__)                          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->udf.max_udf_match_num):0)
#define CLXS_UDF_GROUP_CAPACITY(__unit__)                         ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->udf.udf_group_capacity):0)

#define CLXS_RIF_MODE(__unit__)                                   ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rif.resource_mode):0)
#define CLXS_RIF_SUPPORT_DROP_STAT(__unit__)                      ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rif.support_rif_drop_stat):true)
#define CLXS_MAX_RIF_COUNTER_NUM(__unit__)                        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rif.max_rif_counter_num):0)
#define CLXS_RIF_SUPPORT_L3_SRC_PRUNE(__unit__)                   ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rif.support_l3_src_prune):0)

#define CLXS_NUM_NVO3_INTF_ID(__unit__)                           ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rif.nvo3_rif_max_num):0)
#define CLXS_NUM_NVO3_RTE_MAC(__unit__)                           ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rif.nvo3_rte_mac_num):0)
#define CLXS_MAX_VRF_NUM(__unit__)                                ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->vrf.max_vrf_num):0)

#define CLXS_QUEUE_UC_NUM(__unit__)                               ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->queue.uc_queue_num):0)
#define CLXS_QUEUE_MC_NUM(__unit__)                               ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->queue.mc_queue_num):0)
#define CLXS_QUEUE_LEGACY_NUM(__unit__)                           ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->queue.legacy_queue_num):0)
#define CLXS_QUEUE_CPU_NUM(__unit__)                              ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->queue.cpu_queue_num):0)
#define CLXS_QUEUE_SUPPORT_MCQUEUE_STAT(__unit__)                 ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->queue.support_mc_queue_stat):0)
#define CLXS_QUEUE_SUPPORT_WRED_DROP_STAT(__unit__)               ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->queue.support_wred_drop_stat):false)
#define CLXS_ECN_MARK_STATS_HW_SUPPORT(__unit__)                  ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->wred.ecn_mark_stats_hw_support) :0)
#define CLXS_ECN_MARK_STATS_ACL_SUPPORT(__unit__)                  ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->wred.ecn_mark_stats_acl_support) :0)
#define CLXS_ECN_MARK_STATS_ACL_SUPPORT(__unit__)                 ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->wred.ecn_mark_stats_acl_support) :0)
#define CLXS_WRED_MIN_TH(__unit__)                                ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->wred.min_wred_th) :0)
#define CLXS_WRED_MIN_TH_G(__unit__)                              ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->wred.default_min_wred_th_g) :0)
#define CLXS_WRED_MIN_TH_Y(__unit__)                              ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->wred.default_min_wred_th_y) :0)
#define CLXS_WRED_MIN_TH_R(__unit__)                              ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->wred.default_min_wred_th_r) :0)
#define CLXS_WRED_MAX_TH(__unit__)                                ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->wred.max_wred_th) :0)
#define CLXS_WRED_MAX_TH_G(__unit__)                              ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->wred.default_max_wred_th_g) :0)
#define CLXS_WRED_MAX_TH_Y(__unit__)                              ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->wred.default_max_wred_th_y) :0)
#define CLXS_WRED_MAX_TH_R(__unit__)                              ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->wred.default_max_wred_th_r) :0)

#define CLXS_SCH_GRP_MAX_NUM_LEVEL_0(__unit__)                    ((CLXS_CHIP_SPEC(__unit__)!=NULL)?CLXS_CHIP_SPEC(__unit__)->schedulergroup.max_node_num_level0:0)
#define CLXS_SCH_GRP_MAX_NUM_LEVEL_1(__unit__)                    ((CLXS_CHIP_SPEC(__unit__)!=NULL)?CLXS_CHIP_SPEC(__unit__)->schedulergroup.max_node_num_level1:0)
#define CLXS_SCH_GRP_MAX_NUM_LEVEL_2(__unit__)                    ((CLXS_CHIP_SPEC(__unit__)!=NULL)?CLXS_CHIP_SPEC(__unit__)->schedulergroup.max_node_num_level2:0)
#define CLXS_SCH_GRP_MAX_CHILD_LEVEL_0(__unit__)                  ((CLXS_CHIP_SPEC(__unit__)!=NULL)?CLXS_CHIP_SPEC(__unit__)->schedulergroup.max_child_num_level0:0)
#define CLXS_SCH_GRP_MAX_CHILD_LEVEL_1(__unit__)                  ((CLXS_CHIP_SPEC(__unit__)!=NULL)?CLXS_CHIP_SPEC(__unit__)->schedulergroup.max_child_num_level1:0)
#define CLXS_SCH_GRP_MAX_CHILD_LEVEL_2(__unit__)                  ((CLXS_CHIP_SPEC(__unit__)!=NULL)?CLXS_CHIP_SPEC(__unit__)->schedulergroup.max_child_num_level2:0)

#define CLXS_MAX_TUNNEL_NUM(__unit__)                             ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->tunnel.max_tunnel_num) :0)
#define CLXS_TUNNEL_SUPPORT_DECAP_WITH_VLAN_FILTER(__unit__)      ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->tunnel.support_decap_with_vlan_filter):true)
#define CLXS_TUNNEL_TERM_P2MP_COMPATIBLE_WITH_P2P(__unit__)       ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->tunnel.term_p2mp_compatible_with_p2p):true)

#define MAX_ISOLATION_GROUP_OBJECT_COUNT(__unit__)                ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->isolationgrp.max_isolation_group_num):0)

#define CLXS_TAM_IFA2_PROFILE_NUM(__unit__)                       ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->tam.ifa2_profile_num):0)
#define CLXS_TAM_IOAM_PROFILE_NUM(__unit__)                       ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->tam.ioam_profile_num):0)
#define CLXS_TAM_INT2_PROFILE_NUM(__unit__)                       ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->tam.int2_profile_num):0)

#define CLXS_TAM_INT_SUPPORT_IFA(__unit__)                        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->tam.support_ifa):true)
#define CLXS_TAM_INT_SUPPORT_IOAM(__unit__)                       ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->tam.support_ioam):true)
#define CLXS_TAM_INT_SUPPORT_INT(__unit__)                        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->tam.support_int):true)
#define CLXS_TAM_MAX_HOP_CNT_CFG_MODE(__unit__)                   ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->tam.max_hop_cnt_cfg_mode):0)

#define CLXS_BFD_SESSION_MAX_NUM(__unit__)                        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->bfd.session_max_num):0)
#define CLXS_BFD_SESSION_MIN_RX(__unit__)                         ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->bfd.session_min_rx):0)
#define CLXS_BFD_SESSION_MIN_TX(__unit__)                         ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->bfd.session_min_tx):0)

#define CLXS_SWC_SUPPORT_HASH_ENGINE(__unit__)                       ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->dev.support_hash_engine):false)
#define CLXS_SWC_SUPPORT_HASH_ALGO_MURMUR(__unit__)                   ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->dev.support_hash_algo_murmur):false)

#define _SHAL_FUNC_CALL(__func_vec__, __func__, __param__, __rc__) ({               \
        clx_error_no_t __rc = CLX_E_OK;                                             \
        if ((NULL == clxs_shal_func_vec)||(NULL == clxs_shal_func_vec->__func_vec__) || (NULL == clxs_shal_func_vec->__func_vec__->__func__))             \
        {                                                                           \
            CLXS_LOG_NTC("not support this function");         \
            __rc = __rc__;                                                          \
        }                                                                           \
        else                                                                        \
        {                                                                           \
            __rc = (clxs_shal_func_vec->__func_vec__->__func__ __param__);               \
        }                                                                           \
        __rc;                                                                       \
    })

#define SHAL_FUNC_CALL(__module__,__func__, __param__) \
        _SHAL_FUNC_CALL(shal_##__module__##_func_vec, __func__, __param__, CLX_E_NOT_SUPPORT)


/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/

typedef struct clxs_shal_chip_spec_s
{
    shal_chip_spec_buffer_t            buffer;
    shal_chip_spec_queue_t             queue;
    shal_chip_spec_acl_t               acl;
    shal_chip_spec_udf_t               udf;
    shal_chip_spec_qos_t               qos;
    shal_chip_spec_schgrp_t            schedulergroup;
    shal_chip_spec_wred_t              wred;
    shal_chip_spec_policer_t           policer;
    shal_chip_spec_ipmc_t              ipmc;
    shal_chip_spec_lag_t               lag;
    shal_chip_spec_port_t              port;
    shal_chip_spec_tunnel_t            tunnel;
    shal_chip_spec_nexthopgroup_t      nexthopgroup;
    shal_chip_spec_neighbor_t          neighbor;
    shal_chip_spec_nexthop_t           nexthop;
    shal_chip_spec_route_t             route;
    shal_chip_spec_routeinterface_t    rif;
    shal_chip_spec_virtualrouter_t     vrf;
    shal_chip_spec_bridge_t            bridge;
    shal_chip_spec_fdb_t               fdb;
    shal_chip_spec_l2mc_t              l2mc;
    shal_chip_spec_mirror_t            mirror;
    shal_chip_spec_stp_t               stp;
    shal_chip_spec_isolationgrp_t      isolationgrp;
    shal_chip_spec_rpfgroup_t          rpfgroup;
    shal_chip_spec_samplepkt_t         samplepkt;
    shal_chip_spec_hostif_t            hostif;
    shal_chip_spec_dev_t               dev;
    shal_chip_spec_tam_t               tam;
    shal_chip_spec_bfd_t               bfd;
} clxs_shal_chip_spec_t;

typedef struct clxs_shal_func_vec_s
{
    shal_port_func_vec_t            *shal_port_func_vec;
    shal_switch_func_vec_t          *shal_switch_func_vec;
    shal_vlan_func_vec_t            *shal_vlan_func_vec;
    shal_vrf_func_vec_t             *shal_vrf_func_vec;
    shal_route_func_vec_t           *shal_route_func_vec;
    shal_nexthop_func_vec_t         *shal_nexthop_func_vec;
    shal_nexthopgroup_func_vec_t    *shal_nexthopgroup_func_vec;
    shal_rif_func_vec_t             *shal_rif_func_vec;
    shal_neighbor_func_vec_t        *shal_neighbor_func_vec;
    shal_mirror_func_vec_t          *shal_mirror_func_vec;
    shal_isolationgroup_func_vec_t  *shal_isolationgroup_func_vec;
    shal_hash_func_vec_t            *shal_hash_func_vec;
    shal_stp_func_vec_t             *shal_stp_func_vec;
    shal_fdb_func_vec_t             *shal_fdb_func_vec;
    shal_lag_func_vec_t             *shal_lag_func_vec;
    shal_bridge_func_vec_t          *shal_bridge_func_vec;
    shal_acl_func_vec_t             *shal_acl_func_vec;
    shal_tunnel_func_vec_t          *shal_tunnel_func_vec;
    shal_schedulergroup_func_vec_t  *shal_schedulergroup_func_vec;
    shal_l2mcgroup_func_vec_t       *shal_l2mcgroup_func_vec;
    shal_qosmap_func_vec_t          *shal_qosmap_func_vec;
    shal_hostif_func_vec_t          *shal_hostif_func_vec;
    shal_samplepacket_func_vec_t    *shal_samplepacket_func_vec;
    shal_udf_func_vec_t             *shal_udf_func_vec;
    shal_buffer_func_vec_t          *shal_buffer_func_vec;
    shal_wred_func_vec_t            *shal_wred_func_vec;
    shal_queue_func_vec_t           *shal_queue_func_vec;
    shal_policer_func_vec_t         *shal_policer_func_vec;
    shal_tam_func_vec_t             *shal_tam_func_vec;
    shal_bfd_func_vec_t             *shal_bfd_func_vec;
}clxs_shal_func_vec_t;

/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern sai_service_method_table_t       g_services;
extern  clxs_shal_func_vec_t  *clxs_shal_func_vec;
extern  clxs_shal_chip_spec_t  *clxs_shal_chip_spec;

clxs_shal_chip_spec_t * clxs_switch_get_chip_capacity( _In_ uint32_t unit);
#define CLXS_CHIP_SPEC(__unit__)                clxs_switch_get_chip_capacity(__unit__)

#endif /* __CLX_SAI_H__ */
