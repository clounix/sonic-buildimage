/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  clx_fcoe.h
 * PURPOSE:
 *      It provide FCoE module api.
 * NOTES:
 *
 */


#ifndef CLX_FCOE_H
#define CLX_FCOE_H


/* INCLUDE FILE DECLARATIONS
*/
#include <clx_port.h>
#include <clx_vlan.h>
#include <clx_l2.h>
#include <clx_l3.h>


/* DATA TYPE DECLARATIONS
 */
typedef UI32_T CLX_FCOE_FCID_T;

typedef struct CLX_FCOE_FCID_ADDR_S
{
    CLX_FCOE_FCID_T fcid;           /* FCID  */
    CLX_FCOE_FCID_T mask;           /* Mask of FCID */
} CLX_FCOE_FCID_ADDR_T;

typedef struct CLX_FCOE_INTF_INFO_S
{
    UI32_T intf_idx;                /* Interface index,  key */
    UI32_T vrf_id;                  /* VRF of interface, key */
    CLX_MAC_T mac;                  /* Mac of interface, key */

#define CLX_FCOE_INTF_FLAGS_ROUTING_ENABLE          (1UL << 0)
#define CLX_FCOE_INTF_FLAGS_IGR_METER_VALID         (1UL << 1)
#define CLX_FCOE_INTF_FLAGS_EGR_METER_VALID         (1UL << 2)
#define CLX_FCOE_INTF_FLAGS_IGR_COUNTER_VALID       (1UL << 3)
#define CLX_FCOE_INTF_FLAGS_EGR_COUNTER_VALID       (1UL << 4)
#define CLX_FCOE_INTF_FLAGS_IGR_DIST_COUNTER_VALID  (1UL << 5)
#define CLX_FCOE_INTF_FLAGS_EGR_DIST_COUNTER_VALID  (1UL << 6)
    UI32_T flags;

    UI32_T igr_meter_id;            /* Ingress meter ID */
    UI32_T egr_meter_id;            /* Egress  meter ID */

    UI32_T igr_cnt_id;              /* Ingress counter ID */
    UI32_T egr_cnt_id;              /* Egress  counter ID */

    UI32_T igr_dist_cnt_id;         /* Ingress distribution counter ID */
    UI32_T egr_dist_cnt_id;         /* Egress  distribution counter ID */

    UI32_T igr_group_label;         /* Ingress interface group label for CIA */
    UI32_T egr_group_label;         /* Egress  interface group label for CIA */
} CLX_FCOE_INTF_INFO_T;

typedef struct CLX_FCOE_HOST_INFO_S
{
    UI32_T vrf_id;                      /* Lookup key: vrf-id */
    CLX_FCOE_FCID_T fcid;               /* Lookup key: Destination FCID */

    CLX_L3_OUTPUT_TYPE_T output_type;   /* Refer to CLX_L3_OUTPUT_TYPE_T*/
    UI32_T output_id;                   /* Only support ADJ type*/
    UI32_T tc;                          /* Remark TC value */

#define CLX_FCOE_HOST_FLAGS_KEEP_TTL        (1UL << 0)    /* If vft.header exists, modify hop-count. */
#define CLX_FCOE_HOST_FLAGS_SID_TC_REMARK   (1UL << 1)    /* S_ID of packet is used to remark TC. */
#define CLX_FCOE_HOST_FLAGS_DID_TC_REMARK   (1UL << 2)    /* D_ID of packet is used to remark TC. */
#define CLX_FCOE_HOST_FLAGS_TC_STICKY       (1UL << 3)    /* Remark TC is sticky. */
    UI32_T flags;

    UI32_T group_label;                 /* group label for CIA */
} CLX_FCOE_HOST_INFO_T;

typedef struct CLX_FCOE_ROUTE_INFO_S
{
    UI32_T vrf_id;                      /* Lookup key: vfc-id */
    CLX_FCOE_FCID_ADDR_T fcid_addr;     /* Lookup key: Destination FCID address */

    CLX_L3_OUTPUT_TYPE_T output_type;   /* Refer to CLX_L3_OUTPUT_TYPE_T*/
    UI32_T output_id;                   /* Only support ADJ type */
    UI32_T tc;                          /* Remark TC value */

#define CLX_FCOE_ROUTE_FLAGS_KEEP_TTL       (1UL << 0)    /* If vft.header exists, modify hop-count. */
#define CLX_FCOE_ROUTE_FLAGS_SID_TC_REMARK  (1UL << 1)    /* S_ID of packet is used to remark TC. */
#define CLX_FCOE_ROUTE_FLAGS_DID_TC_REMARK  (1UL << 2)    /* D_ID of packet is used to remark TC. */
#define CLX_FCOE_ROUTE_FLAGS_TC_STICKY      (1UL << 3)    /* Remark TC is sticky. */
    UI32_T flags;

    UI32_T group_label;                 /* group label for CIA */
} CLX_FCOE_ROUTE_INFO_T;

typedef struct CLX_FCOE_ZONE_S
{
    CLX_BRIDGE_DOMAIN_T bdid;           /* Bridge domain ID */
    CLX_FCOE_FCID_T src_fcid;           /* The first member FCID */
    CLX_FCOE_FCID_T dst_fcid;           /* The second member FCID */
} CLX_FCOE_ZONE_T;

typedef enum
{
    CLX_FCOE_CLV_PORT_MODE_IS_F = 0,    /* The port mode is F port   */
    CLX_FCOE_CLV_PORT_MODE_IS_CL,       /* The port mode is CL port */
    CLX_FCOE_CLV_PORT_MODE_LAST
} CLX_FCOE_CLV_PORT_MODE_T;

typedef struct CLX_FCOE_CLV_PORT_INFO_S
{
    CLX_FCOE_CLV_PORT_MODE_T port_mode; /* F port or CL port */
    CLX_PORT_T     port_np_id;          /* The upstream port ID (CL port) */
} CLX_FCOE_CLV_PORT_INFO_T;

typedef struct CLX_FCOE_FC_FRAME_ACTION_S
{
#define CLX_FCOE_FC_FRAME_ACTION_FLAGS_VFT_TIMEEXCEED_TOCPU     (1UL << 0)
#define CLX_FCOE_FC_FRAME_ACTION_FLAGS_UNKNOWN_HDR_DROP         (1UL << 1)
#define CLX_FCOE_FC_FRAME_ACTION_FLAGS_CLASS2_TOCPU             (1UL << 2)
#define CLX_FCOE_FC_FRAME_ACTION_FLAGS_CLASSF_TOCPU             (1UL << 3)

    UI32_T flags;
} CLX_FCOE_FC_FRAME_ACTION_T;

/*
  EXPORTED SUBPROGRAM SPECIFICATIONS */

/* FUNCTION NAME:   clx_fcoe_addIntf
 * PURPOSE:
 *      This API is used to add an FCoE logic interface.<CL>
 *      FCF switch is based on Layer 3 forwarding, and the logic interface is a virtual
 *      entity which represents Layer3 switch interface in forwarding. Each VLAN /
 *      bridge-domain can derive one logic interface.
 * INPUT:
 *      unit            --  Device unit number
 *      bdid            --  Bridge domain ID
 *      ptr_entry       --  Logic interface information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_fcoe_addIntf(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    const CLX_FCOE_INTF_INFO_T      *ptr_entry);

/* FUNCTION NAME:   clx_fcoe_delIntf
 * PURPOSE:
 *      This API is used to delete a VLAN-based FCoE interface.
 * INPUT:
 *      unit            --  Device unit number
 *      bdid            --  Bridge domain ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_fcoe_delIntf(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid);

/* FUNCTION NAME:   clx_fcoe_getIntf
 * PURPOSE:
 *      This API is used to get FCoE interface information.
 * INPUT:
 *      unit            --  Device unit number
 *      bdid            --  Bridge domain ID
 * OUTPUT:
 *      ptr_entry       --  Logic interface information
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_fcoe_getIntf(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    CLX_FCOE_INTF_INFO_T            *ptr_entry);

/* FUNCTION NAME:   clx_fcoe_addHost
 * PURPOSE:
 *      This API is used to add an FCoE host entry, which is used in FCF switch routing.
 *      A host represents an N_Port or VE_Port which is directly connected to a local
 *      switch. The key of host is {vrf, FCID}.<CL>
 *      When an N_Port is connected, the FCID is N_Port_ID.<CL>
 *      When a VE_Port is connected, the FCID is the domain-controller address of remote
 *      switch, which has the following format: "FF-FC-Domain_id!".
 * INPUT:
 *      unit            --  Device unit number
 *      ptr_entry       --  Host information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_fcoe_addHost(
    const UI32_T                    unit,
    const CLX_FCOE_HOST_INFO_T      *ptr_entry);

/* FUNCTION NAME:   clx_fcoe_delHost
 * PURPOSE:
 *      This API is used to delete an FCoE host entry.
 * INPUT:
 *      unit            --  Device unit number
 *      ptr_entry       --  Host key
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_fcoe_delHost(
    const UI32_T                    unit,
    const CLX_FCOE_HOST_INFO_T      *ptr_entry);

/* FUNCTION NAME:   clx_fcoe_getHost
 * PURPOSE:
 *      This API is used to get an FCoE host entry configuration.
 * INPUT:
 *      unit            --  Device unit number
 *      ptr_entry       --  Host key
 * OUTPUT:
 *      ptr_entry       --  Host entry information
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_fcoe_getHost(
    const UI32_T                    unit,
    CLX_FCOE_HOST_INFO_T            *ptr_entry);

/* FUNCTION NAME:   clx_fcoe_addRoute
 * PURPOSE:
 *      This API is used to add an FCoE remote route entry, which is used in the FCF
 *      switch routing. A remote route represents an N_Port or VE_Port which is not
 *      directly connected to the local switch, and it is reachable via at least one
 *      other FCF switch.<CL>
 *      The route entry goes through Layer 3 forwarding via the longest-prefix-match
 *      mechanism, and the route entry should be derived from static configuration or by
 *      PSPF algorithm.
 * INPUT:
 *      unit            --  Device unit number
 *      ptr_entry       --  Remote route key & information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_fcoe_addRoute(
    const UI32_T                    unit,
    const CLX_FCOE_ROUTE_INFO_T     *ptr_entry);

/* FUNCTION NAME:   clx_fcoe_delRoute
 * PURPOSE:
 *      This API is used to delete an FCoE remote route entry.
 * INPUT:
 *      unit            --  Device unit number
 *      ptr_entry       --  Remote route key
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_fcoe_delRoute(
    const UI32_T                    unit,
    const CLX_FCOE_ROUTE_INFO_T     *ptr_entry);

/* FUNCTION NAME:   clx_fcoe_getRoute
 * PURPOSE:
 *      This API is used to get an FCoE remote route entry information.
 * INPUT:
 *      unit            --  Device unit number
 *      ptr_entry       --  Remote route key
 * OUTPUT:
 *      ptr_entry       --  Remote route information
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_fcoe_getRoute(
    const UI32_T                    unit,
    CLX_FCOE_ROUTE_INFO_T           *ptr_entry);

/* FUNCTION NAME:   clx_fcoe_setVntovnEnable
 * PURPOSE:
 *      This API is used to enable the vn2vn function on VLAN/forwarding-domain. The
 *      function takes effect only when routing is enabled on the logic interface. When
 *      routing is disabled, packets go through Layer 2 switching by default.
 * INPUT:
 *      unit            --  Device unit number
 *      bdid            --  Bridge domain ID
 *      enable          --  VN2VN is enabled or disabled
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_fcoe_setVntovnEnable(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    const BOOL_T                    enable);

/* FUNCTION NAME:   clx_fcoe_getVntovnEnable
 * PURPOSE:
 *      This API is used to get vn2vn enable configuration.
 * INPUT:
 *      unit            --  Device unit number
 *      bdid            --  Bridge domain ID
 * OUTPUT:
 *      ptr_enable      --  VN2VN is enabled or disabled
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_fcoe_getVntovnEnable(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    BOOL_T                          *ptr_enable);

/* FUNCTION NAME:   clx_fcoe_setZoneCheck
 * PURPOSE:
 *      This API is used to enable/disable the zoning check of VLAN/bridge-domain. When
 *      the zoning is disabled, packet will bypass the zone check.
 * INPUT:
 *      unit            --  Device unit number
 *      bdid            --  Bridge domain ID
 *      enable          --  Zoning check is enabled or disabled
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_fcoe_setZoneCheck(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    const BOOL_T                    enable);

/* FUNCTION NAME:   clx_fcoe_getZoneCheck
 * PURPOSE:
 *      This API is used to get the zoning check configuration.
 * INPUT:
 *      unit            --  Device unit number
 *      bdid            --  Bridge domain ID
 * OUTPUT:
 *      ptr_enable      --  Zoning check is enabled or disabled
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_fcoe_getZoneCheck(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    BOOL_T                          *ptr_enable);

/* FUNCTION NAME:   clx_fcoe_addZone
 * PURPOSE:
 *      This API is used to add a zoning entry; if zoning is enabled, packet will use
 *      {VLAN, src_FCID, dst_FCID} as key to look up the zoning table; if lookup is
 *      missed, the packet will be dropped. <CL>
 *      Note that the entry is normalized, the direction of src_FCID/dst_FCID takes no
 *      effect, and user only needs to add entry of one direction.
 * INPUT:
 *      unit            --  Device unit number
 *      ptr_entry       --  Zone information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_fcoe_addZone(
    const UI32_T                    unit,
    const CLX_FCOE_ZONE_T           *ptr_entry);

/* FUNCTION NAME:   clx_fcoe_delZone
 * PURPOSE:
 *      This API is used to delete a zoning entry.
 * INPUT:
 *      unit            --  Device unit number
 *      ptr_entry       --  Zone information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_fcoe_delZone(
    const UI32_T                    unit,
    const CLX_FCOE_ZONE_T           *ptr_entry);

/* FUNCTION NAME:   clx_fcoe_getZone
 * PURPOSE:
 *      This API is used to get if a zoning entry exists.
 * INPUT:
 *      unit            --  Device unit number
 *      ptr_entry       --  Zone information
 * OUTPUT:
 *      ptr_is_set      --  The rule has been set in chip or not
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_fcoe_getZone(
    const UI32_T                    unit,
    const CLX_FCOE_ZONE_T           *ptr_entry,
    BOOL_T                          *ptr_is_set);

/* FUNCTION NAME:   clx_fcoe_setPortNpvConfig
 * PURPOSE:
 *      This API is used to set per-port's CLV mode configuration information.
 * INPUT:
 *      unit       --  Device unit number
 *      port       --  CL port or F port which need to be cofigured
 *      ptr_entry  --  Per-port CLV configuration information.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_fcoe_setPortNpvConfig(
    const UI32_T                    unit,
    const CLX_PORT_T                port,
    const CLX_FCOE_CLV_PORT_INFO_T  *ptr_entry);

/* FUNCTION NAME:   clx_fcoe_getPortNpvConfig
 * PURPOSE:
 *      This API is used to get per-port's CLV mode configuration information.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  CL port or F port which need to be cofigured
 * OUTPUT:
 *      ptr_entry       --  It includes port's CLV mode configuration information
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_fcoe_getPortNpvConfig(
    const UI32_T                    unit,
    const CLX_PORT_T                port,
    CLX_FCOE_CLV_PORT_INFO_T        *ptr_entry);

/* FUNCTION NAME:   clx_fcoe_setFrameTypeAction
 * PURPOSE:
 *      This API is used to set action for several special kinds of FC frame at ingress
 *      or egress stage, this setting is global. There are five kinds of FC frame
 *      for setting action:<CL>
 *      (1) Packet with VFT ext-header, and hop-count = 1<CL>
 *      (2) Packet with IFR ext-header<CL>
 *      (3) Packet with Unknown ext-header<CL>
 *      (4) Class 2 frame<CL>
 *      (5) Class F frame
 * INPUT:
 *      unit            --  Device unit number
 *      ptr_entry       --  The configuration of FC frame
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_fcoe_setFrameTypeAction(
    const UI32_T                        unit,
    const CLX_FCOE_FC_FRAME_ACTION_T    *ptr_entry);

/* FUNCTION NAME:   clx_fcoe_getFrameTypeAction
 * PURPOSE:
 *      This API is used to get action for special FC frame.
 * INPUT:
 *      unit                --  Device unit number
 * OUTPUT:
 *      ptr_entry           --  The configuration of FC frame
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_fcoe_getFrameTypeAction(
    const UI32_T                    unit,
    CLX_FCOE_FC_FRAME_ACTION_T      *ptr_entry);

/* FUNCTION NAME:   clx_fcoe_createPort
 * PURPOSE:
 *      This API is used to create a FCoE port.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  physical port ID.
 * OUTPUT:
 *      ptr_fcoe_port   --  The pointer of the FCoE port
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_fcoe_createPort(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    CLX_PORT_T                  *ptr_fcoe_port);

/* FUNCTION NAME:   clx_fcoe_destroyPort
 * PURPOSE:
 *      This API is used to destroy a FCoE port.
 * INPUT:
 *      unit            --  Device unit number
 *      fcoe_port       --  The FCoE port
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_fcoe_destroyPort(
    const UI32_T                unit,
    const CLX_PORT_T            fcoe_port);
#endif
/* end */

