/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_wlan.h
 * PURPOSE:
 *      It provides wlan module api.
 * NOTES:
 *
 */

#ifndef CLX_WLAN_H
#define CLX_WLAN_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_tnl.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef struct clx_wlan_capwap_prof_s {
    uint16 capwap_server_port; /* Capwap data plane UDP server port */
    uint16 capwap_client_port; /* Capwap data plane UDP client port */
    uint8 radio_id;            /* Radio Identifier(RID) */

    uint32 flags;              /* Refer to CLX_WLAN_CAPWAP_PROF_FLAGS_XXX */
} clx_wlan_capwap_prof_t;
#define CLX_WLAN_CAPWAP_PROF_FLAGS_UDP_LITE_EN        \
    (0x1U << 0) /* Use UDP-Lite as transport layer.   \
                 * Set to 1 to use UDP-Lite(RFC3828); \
                 * Set to 0 to use UDP(RFC768)        \
                 */
#define CLX_WLAN_CAPWAP_PROF_FLAGS_RID_GROUP         \
    (0x1U << 1) /* CAPWAP RID group.                 \
                 * Set to 1 if RID in [1, radio_id]; \
                 * Set to 0 to use fixed radio_id    \
                 */

/* CAPWAP header information in the Access Controller(AC) encapsulation view */
typedef struct clx_wlan_capwap_s {
    clx_tnl_info_t tnl_info;                      /* Tunnel information in encapsulation view.
                                                   * Including source IP, destination IP and tunnel type */
    uint16 capwap_client_port;                    /* CAPWAP data plane UDP client port */
    uint8 radio_id;                               /* Radio ID */
    uint8 capwap_prof_id;                         /* CAPWAP profile ID */
    uint32 flags;                                 /* Refer to CLX_WLAN_CAPWAP_FLAGS_XXX */
} clx_wlan_capwap_t;
#define CLX_WLAN_CAPWAP_FLAGS_WITH_ID (0x1U << 0) /* Use user input ID to create WLAN port */

typedef struct clx_wlan_station_s {
    clx_mac_t sta_mac; /* Station MAC address */
    clx_vlan_t vid;    /* VLAN ID */
    uint32 flags;      /* Refer to CLX_WLAN_STATION_FLAGS_XXX */
    uint64 attr_bmp;   /* Refer to CLX_WLAN_STATION_ATTR_XXX */
} clx_wlan_station_t;
#define CLX_WLAN_STATION_FLAGS_MAC_CLS_VLAN_EN (0x1U << 0)

#define CLX_WLAN_STATION_ATTR_MAC_CLS_VLAN_EN \
    (0x1ULL << 0) /* Set vid, CLX_WLAN_STATION_FLAGS_MAC_CLS_VLAN_EN */
#define CLX_WLAN_STATION_ATTR_ALL (0xFFFFFFFFFFFFFFFF) /* Set all fields */

typedef clx_error_no_t (*clx_wlan_port_trav_func_t)(const uint32 unit,
                                                    const clx_port_t port,
                                                    const clx_wlan_capwap_t *ptr_capwap,
                                                    void *ptr_cookie);

typedef clx_error_no_t (*clx_wlan_decap_trav_func_t)(const uint32 unit,
                                                     const clx_port_t port,
                                                     const clx_tnl_decap_info_t *ptr_decap_info,
                                                     void *ptr_cookie);

typedef clx_error_no_t (*clx_wlan_encap_trav_func_t)(const uint32 unit,
                                                     const clx_port_t port,
                                                     const clx_tnl_encap_info_t *ptr_encap_info,
                                                     void *ptr_cookie);

typedef clx_error_no_t (*clx_wlan_station_trav_func_t)(const uint32 unit,
                                                       const clx_wlan_station_t *ptr_sta_mac,
                                                       void *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief Add CAPWAP header profile.
 *
 * This API is used to add CAPWAP header profile.
 * Support_chip: CLX84.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    id             - CAPWAP profile ID.
 * @param [in]    ptr_profile    - Point to CAPWAP profile properties.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_ENTRY_EXISTS     - CAPWAP profile already exists.
 */
clx_error_no_t
clx_wlan_capwap_prof_add(const uint32 unit,
                         const uint32 id,
                         const clx_wlan_capwap_prof_t *ptr_profile);

/**
 * @brief Delete CAPWAP header profile.
 *
 * This API is used to delete CAPWAP header profile.
 * Support_chip: CLX84.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    id      - CAPWAP profile ID.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - CAPWAP profile not found.
 */
clx_error_no_t
clx_wlan_capwap_prof_del(const uint32 unit, const uint32 id);

/**
 * @brief Get CAPWAP header profile.
 *
 * This API is used to get CAPWAP header profile.
 * Support_chip: CLX84.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     id             - CAPWAP profile ID.
 * @param [out]    ptr_profile    - Point to CAPWAP profile properties.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - CAPWAP profile not found.
 */
clx_error_no_t
clx_wlan_capwap_prof_get(const uint32 unit, const uint32 id, clx_wlan_capwap_prof_t *ptr_profile);

/**
 * @brief Create WLAN port.
 *
 * This API is used to create WLAN port. User needs to provide CAPWAP header information,
 * including source IP, destination IP, Radio ID, client port etc.
 * The created WLAN port can be used for subsequent encapsulation/decapsulation entry
 * configuration, and for L2/L3 forwarding table configuration.
 * Support_chip: CLX84.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     ptr_capwap    - Point to CAPWAP header information.
 * @param [out]    ptr_port      - Point to the created WLAN port.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_TABLE_FULL         - No resource available.
 * @return         CLX_E_ENTRY_NOT_FOUND    - CAPWAP profile not found.
 * @return         CLX_E_ENTRY_EXISTS       - WLAN port already exists.
 * @return         CLX_E_ENTRY_IN_USE       - Index in use.
 * @return         CLX_E_NO_MEMORY          - No memory available.
 */
clx_error_no_t
clx_wlan_port_create(const uint32 unit, const clx_wlan_capwap_t *ptr_capwap, clx_port_t *ptr_port);

/**
 * @brief Destroy a WLAN port.
 *
 * This API is used to destroy a WLAN port and release associated resources.
 * Support_chip: CLX84.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Destroy WLAN port number.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - WLAN port not found.
 */
clx_error_no_t
clx_wlan_port_destroy(const uint32 unit, const clx_port_t port);

/**
 * @brief Get WLAN port.
 *
 * This API is used to get the WLAN port from CAPWAP header information.
 * Support_chip: CLX84.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     ptr_capwap    - Point to CAPWAP header information.
 * @param [out]    ptr_port      - Point to WLAN port.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - WLAN port not found.
 */
clx_error_no_t
clx_wlan_port_get(const uint32 unit, const clx_wlan_capwap_t *ptr_capwap, clx_port_t *ptr_port);

/**
 * @brief Get WLAN port configuration.
 *
 * This API is used to get the CAPWAP header information of a WLAN port.
 * Support_chip: CLX84.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - WLAN port.
 * @param [out]    ptr_capwap    - Point to CAPWAP header information.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - WLAN port not found.
 */
clx_error_no_t
clx_wlan_port_hdr_get(const uint32 unit, const clx_port_t port, clx_wlan_capwap_t *ptr_capwap);

/**
 * @brief Traverse all configured WLAN ports.
 *
 * This API is used to traverse all configured WLAN ports.
 * Support_chip: CLX84.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - Input parameter of callback function.
 * @param [out]    ptr_cookie    - Output parameter of callback function.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
clx_wlan_port_trav(const uint32 unit, const clx_wlan_port_trav_func_t cb, void *ptr_cookie);

/**
 * @brief Add a decapsulation entry for WLAN port.
 *
 * This API is used to add a decapsulation entry for a WLAN port. If the decapsulation entry
 * already exists, the decapsulation attributes will be updated.
 * Support_chip: CLX84.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    port              - WLAN port.
 * @param [in]    ptr_decap_info    - Decapsulation properties to add.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - WLAN port not found.
 */
clx_error_no_t
clx_wlan_decap_add(const uint32 unit,
                   const clx_port_t port,
                   const clx_tnl_decap_info_t *ptr_decap_info);

/**
 * @brief Delete a decapsulation entry for WLAN port.
 *
 * This API is used to delete a decapsulation entry for a WLAN port.
 * Support_chip: CLX84.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - WLAN port.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - WLAN port not found.
 */
clx_error_no_t
clx_wlan_decap_del(const uint32 unit, const clx_port_t port);

/**
 * @brief Get a decapsulation entry for WLAN port.
 *
 * This API is used to get the decapsulation configuration for a WLAN port.
 * Support_chip: CLX84.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port              - WLAN port.
 * @param [out]    ptr_decap_info    - Decapsulation information to be obtained.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Decap entry not found.
 */
clx_error_no_t
clx_wlan_decap_get(const uint32 unit, const clx_port_t port, clx_tnl_decap_info_t *ptr_decap_info);

/**
 * @brief Traverse all WLAN port decapsulation entries.
 *
 * This API is used to traverse all configured WLAN port decapsulation entries.
 * Support_chip: CLX84.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - Input parameter of callback function.
 * @param [out]    ptr_cookie    - Output parameter of callback function.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
clx_wlan_decap_trav(const uint32 unit, const clx_wlan_decap_trav_func_t cb, void *ptr_cookie);

/**
 * @brief Add an encapsulation entry for WLAN port.
 *
 * This API is used to add an encapsulation entry for a WLAN port. If the encapsulation entry
 * already exists, the encapsulation attributes will be updated.
 * Support_chip: CLX84.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    port              - WLAN port.
 * @param [in]    ptr_encap_info    - Encapsulation properties to add.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - WLAN port not found.
 */
clx_error_no_t
clx_wlan_encap_add(const uint32 unit,
                   const clx_port_t port,
                   const clx_tnl_encap_info_t *ptr_encap_info);

/**
 * @brief Delete an encapsulation entry for WLAN port.
 *
 * This API is used to delete an encapsulation entry for a WLAN port.
 * Support_chip: CLX84.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - WLAN port.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - WLAN port not found.
 */
clx_error_no_t
clx_wlan_encap_del(const uint32 unit, const clx_port_t port);

/**
 * @brief Get an encapsulation entry for WLAN port.
 *
 * This API is used to get the encapsulation configuration for a WLAN port.
 * Support_chip: CLX84.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port              - WLAN port.
 * @param [out]    ptr_encap_info    - Encapsulation information to be obtained.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Encap entry not found.
 */
clx_error_no_t
clx_wlan_encap_get(const uint32 unit, const clx_port_t port, clx_tnl_encap_info_t *ptr_encap_info);

/**
 * @brief Traverse all WLAN port encapsulation entries.
 *
 * This API is used to traverse all configured WLAN port encapsulation entries.
 * Support_chip: CLX84.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - Input parameter of callback function.
 * @param [out]    ptr_cookie    - Output parameter of callback function.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
clx_wlan_encap_trav(const uint32 unit, const clx_wlan_encap_trav_func_t cb, void *ptr_cookie);

/**
 * @brief Add station MAC entry.
 *
 * This API is used to add a station MAC entry. Station MAC check is required for all CAPWAP
 * packets, and VLAN ID is optional for further L2/L3 forwarding.
 * For AP-AC tunnels, tunnel terminator checks the payload's source MAC address.
 * For AC-AC tunnels, the POP node checks the source MAC address while the POA node
 * checks the destination MAC address.
 * Support_chip: CLX84.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    ptr_sta_mac    - Station MAC entry.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_ENTRY_EXISTS     - Station MAC entry already exists.
 */
clx_error_no_t
clx_wlan_station_add(const uint32 unit, const clx_wlan_station_t *ptr_sta_mac);

/**
 * @brief Delete station MAC entry.
 *
 * This API is used to delete a station MAC entry.
 * Support_chip: CLX84.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    ptr_sta_mac    - Station MAC entry.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Station MAC entry not found.
 */
clx_error_no_t
clx_wlan_station_del(const uint32 unit, const clx_wlan_station_t *ptr_sta_mac);

/**
 * @brief Set station MAC entry.
 *
 * This API is used to update a station MAC entry.
 * Support_chip: CLX84.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    ptr_sta_mac    - Station MAC entry.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Station MAC entry not found.
 */
clx_error_no_t
clx_wlan_station_set(const uint32 unit, const clx_wlan_station_t *ptr_sta_mac);

/**
 * @brief Get station MAC entry.
 *
 * This API is used to get a station MAC entry.
 * Support_chip: CLX84.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     ptr_sta_mac    - Station MAC entry.
 * @param [out]    ptr_sta_mac    - Station MAC entry.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Station MAC entry not found.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 */
clx_error_no_t
clx_wlan_station_get(const uint32 unit, clx_wlan_station_t *ptr_sta_mac);

/**
 * @brief Traverse all station MAC entries.
 *
 * This API is used to traverse all configured station MAC entries.
 * Support_chip: CLX84.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - Input parameter of callback function.
 * @param [out]    ptr_cookie    - Output parameter of callback function.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
clx_wlan_station_trav(const uint32 unit, const clx_wlan_station_trav_func_t cb, void *ptr_cookie);
#endif