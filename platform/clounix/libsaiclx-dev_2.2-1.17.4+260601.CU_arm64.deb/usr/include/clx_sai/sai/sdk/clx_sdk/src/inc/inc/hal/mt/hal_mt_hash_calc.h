/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_hash_calc.h
 * PURPOSE:
 *  Declare chip-agnostic hash calculation dispatch API.
 *
 * NOTES:
 */

#ifndef HAL_MT_HASH_CALC_H
#define HAL_MT_HASH_CALC_H

#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_swc.h>

/**
 * @brief This function is to get flow hash value.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     prof_id         - Hash profile id.
 * @param [in]     hash_type       - Hash type.
 * @param [in]     ptr_hash_key    - Hash key.
 * @param [out]    p_hash_value    - Hash value.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_hash_calc_swc_hsh_path_val_get(const uint32 unit,
                                      const uint32 prof_id,
                                      const clx_swc_hsh_pkt_type_t hash_type,
                                      const clx_swc_flow_hsh_key_t *ptr_hash_key,
                                      uint32 *p_hash_value);

/**
 * @brief To get packet hash path.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     prof_id         - Hash profile id.
 * @param [in]     hash_type       - Hash type.
 * @param [in]     ptr_hash_key    - Pointer of hash key.
 * @param [in]     id              - Lag id / ECMP group id.
 * @param [out]    ptr_rslt        - Pointer of result.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
hal_mt_hash_calc_swc_hsh_path_get(const uint32 unit,
                                  const uint32 prof_id,
                                  const clx_swc_hsh_pkt_type_t hash_type,
                                  const clx_swc_flow_hsh_key_t *ptr_hash_key,
                                  const uint32 id,
                                  clx_swc_hsh_path_rslt_info_t *ptr_rslt);

/**
 * @brief To get hash path key.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     prof_id           - Hash profile id.
 * @param [in]     hash_type         - Hash type.
 * @param [in]     pkt_info          - Packet info.
 * @param [out]    ptr_key_bitmap    - Pointer of key bitmap.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
hal_mt_hash_calc_swc_hsh_path_key_get(const uint32 unit,
                                      const uint32 prof_id,
                                      const clx_swc_hsh_pkt_type_t hash_type,
                                      const clx_swc_hsh_path_pkt_info_t pkt_info,
                                      clx_swc_hsh_key_bmp_t *ptr_key_bitmap);

#endif /* End of HAL_MT_HASH_CALC_H */