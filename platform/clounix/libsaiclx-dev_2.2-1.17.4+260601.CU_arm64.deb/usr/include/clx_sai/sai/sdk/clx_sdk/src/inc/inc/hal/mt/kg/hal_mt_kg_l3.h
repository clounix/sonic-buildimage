/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_l3.h
 * PURPOSE:
 *      Provide HAL driver API functions for CLX84.
 * NOTES:
 *
 *
 */
#ifndef HAL_MT_KG_L3_H
#define HAL_MT_KG_L3_H

/*****************************************************************************
 * INCLUDE FILE DECLARATIONS
 *****************************************************************************
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_swc.h>
#include <clx/clx_l3.h>
#include <clx/clx_l2.h>
#include <util/util.h>
#include <util/lib/util_lib_avl.h>
#include <util/lib/util_lib_list.h>
#include <util/lib/util_lib_bit.h>
#include <util/lib/util_lib_bmp.h>
#include <hal/hal_l3.h>
#include <tob/tob_tbl.h>
#include <hal/hal_obj.h>
#include <hal/hal_io.h>
#include <hal/hal_swc.h>
#include <hal/hal_lag.h>
#include <tob/tob_tbl.h>
#include <tob/mt/tob_mt.h>
#include <hal/mt/hal_mt_l3.h>
#include <hal/mt/kg/hal_mt_kg_swc.h>
#include <hal/hal.h>

/*****************************************************************************
 * NAMING CONSTANT DECLARATIONS
 *****************************************************************************
 */
/* HITBIT */

#define HAL_MT_KG_L3_MGI_V4_HASH_ENTRY_NUM_PER_BANK (20 * 1024)
#define HAL_MT_KG_L3_MGI_V6_HASH_ENTRY_NUM_PER_BANK (10 * 1024)
#define HAL_MT_KG_L3_MSGI_HASH_ENTRY_NUM_PER_BANK   (20 * 1024)

#define HAL_MT_KG_L3_TCAM_1X_BUF_WORDS MT_KG_CDB_FPUTCAM_SLV_TILE_TCAM_IND_DATA_WORDS
#define HAL_MT_KG_L3_TCAM_2X_BUF_WORDS MT_KG_CDB_FPUTCAM_SLV_TILE_TCAM_IND_DATA_WORDS
#define HAL_MT_KG_L3_TCAM_4X_BUF_WORDS (2 * MT_KG_CDB_FPUTCAM_SLV_TILE_TCAM_IND_DATA_WORDS)
#define HAL_MT_KG_L3_HASH_BUF_WORDS    (MT_KG_CDB_FPUHSH_SLV_TILE_HSH_IND_DATA_WORDS)

/* ulm/uulm check */
#define HAL_MT_KG_L3_IS_ULM(unit)                                \
    ((HAL_LATENCY_MODE(unit) == HAL_LATENCY_MODE_LOW_LATENCY) || \
     (HAL_LATENCY_MODE(unit) == HAL_LATENCY_MODE_ULTRA_LOW_LATENCY))
#define HAL_MT_KG_L3_IS_LLM(unit)  (HAL_LATENCY_MODE(unit) == HAL_LATENCY_MODE_LOW_LATENCY)
#define HAL_MT_KG_L3_IS_ULLM(unit) (HAL_LATENCY_MODE(unit) == HAL_LATENCY_MODE_ULTRA_LOW_LATENCY)

/* INTF */
#define HAL_MT_KG_L3_INTF_NUM(unit) \
    (TOB_TBL_INFO(unit, MT_KG_TBL_DIS_RSLT_BDI_ID)->entry_max_number)
#define HAL_MT_KG_L3_INTF_MIN(unit) (0)
#define HAL_MT_KG_L3_INTF_MAX(unit) (HAL_MT_KG_L3_INTF_NUM(unit) - 1)

#define HAL_MT_KG_L3_INVALID_INTF_ID \
    (HAL_MT_KG_L3_IS_ULLM(unit) ? HAL_INVALID_ID : HAL_INVALID_FDID)
#define HAL_MT_KG_L3_INVALID_FDID (HAL_MT_KG_L3_IS_ULLM(unit) ? HAL_INVALID_ID : HAL_INVALID_FDID)
#define HAL_MT_KG_L3_INVALID_VRF  (HAL_INVALID_ID)

/* MTU */
#define HAL_MT_KG_L3_MTU_SIZE_MIN  (0)
#define HAL_MT_KG_L3_MTU_SIZE_MAX  HAL_L3_MTU_SIZE
#define HAL_MT_KG_L3_MTU_SIZE_DFLT (0)

/* VRF */
#define HAL_MT_KG_L3_VRF_ENTRY_NUM                               \
    (1 << TOB_TBL_INFO(unit, MT_KG_TBL_DIS_RSLT_BDI_ID)          \
              ->ptr_table_entry[MT_KG_DIS_RSLT_BDI_VRF_FIELD_ID] \
              .length)
#define HAL_MT_KG_L3_VRF_ENTRY_MIN (0)
#define HAL_MT_KG_L3_VRF_ENTRY_MAX (HAL_MT_KG_L3_VRF_ENTRY_NUM - 1)
#define HAL_MT_KG_L3_VRF_ENTRY_MSK (HAL_MT_KG_L3_VRF_ENTRY_NUM - 1)
#define HAL_MT_KG_L3_LBL_MAX       (65535)

/* Router-MAC */
#define HAL_MT_KG_L3_RMAC_NUM(unit) \
    (TOB_TBL_INFO(unit, MT_KG_TBL_DIS_TCAM_RMACI_ID)->entry_max_number)
#define HAL_MT_KG_L3_RMAC_MIN(unit) (0)
#define HAL_MT_KG_L3_RMAC_MAX(unit) (HAL_MT_KG_L3_RMAC_NUM(unit) - 1)

/* reserved drop adj */
#define HAL_MT_KG_L3_ADJ_HW_RESERVE_NUM (8)

/* ROUTE */
#define HAL_MT_KG_L3_ROUTE_AFIB_DFLT_NUM (32768)
#define HAL_MT_KG_L3_LPM_TILE_NUM        (32)

#define HAL_MT_KG_L3_MAX_V4_LEN (32)
#define HAL_MT_KG_L3_MAX_V6_LEN (128)

#define HAL_MT_KG_L3_LPM_HASH_TILE_INDEX_BIT  (11) /* lpm hash tile index bit */
#define HAL_MT_KG_L3_LPM_HASH_TILE_INDEX_MASK ((1 << HAL_MT_KG_L3_LPM_HASH_TILE_INDEX_BIT) - 1)
#define HAL_MT_KG_L3_LPM_HASH_TILE_ID_SHIFT   (HAL_MT_KG_L3_LPM_HASH_TILE_INDEX_BIT)
#define HAL_MT_KG_L3_LPM_HASH_TILE_ID_BIT     (5) /* lpm hash tile id bit */
#define HAL_MT_KG_L3_LPM_HASH_TILE_ID_MASK    ((1 << HAL_MT_KG_L3_LPM_HASH_TILE_ID_BIT) - 1)

#define HAL_MT_KG_L3_LPM_HASH_TILE_INDEX_GET(entry_idx) \
    (entry_idx & HAL_MT_KG_L3_LPM_HASH_TILE_INDEX_MASK)
#define HAL_MT_KG_L3_LPM_HASH_TILE_ID_GET(entry_idx) \
    ((entry_idx >> HAL_MT_KG_L3_LPM_HASH_TILE_ID_SHIFT) & HAL_MT_KG_L3_LPM_HASH_TILE_ID_MASK)

#define HAL_MT_KG_L3_LPM_HASH_TILE_SIZE (2048) /* lpm hash tile size */

/* MCAST */
#define HAL_MT_KG_L3_MCAST_L3MC_ID(unit, mcast_id) ((mcast_id) - HAL_L2_MGID_CFG_NUM(unit))

#define HAL_MT_L3_MPLS_LABEL_BITMASK    (0xFFFFF)
#define HAL_MT_L3_VALN_BITMASK          (0xFFF)
#define HAL_MT_L3_VALN_VID_BITLENGTH    (12)
#define HAL_MT_L3_SVALN_LABEL_BITLENGTH (8)

#define HAL_MT_KG_L3_MCAST_FPU_KRN_OFFSET (20)
#define HAL_MT_KG_L3_MCAST_FPU_KRN_LEN    (1)

/* ECMP */
#define HAL_MT_KG_L3_ECMP_MBR_TABLE_CNT(tot, per_table_mbr_cnt) \
    ((tot > 0) ? ((tot) - 1) / per_table_mbr_cnt + 1 : 0)
#define HAL_MT_KG_L3_ECMP_MBR_HW_CNT(tot, per_table_mbr_cnt) \
    ((HAL_MT_KG_L3_ECMP_MBR_TABLE_CNT(tot, per_table_mbr_cnt)) * per_table_mbr_cnt)
#define HAL_MT_KG_L3_ECMP_MBR_TABLE_IDX(offset, per_table_mbr_cnt)    ((offset) / per_table_mbr_cnt)
#define HAL_MT_KG_L3_ECMP_MBR_TABLE_OFFSET(offset, per_table_mbr_cnt) ((offset) * per_table_mbr_cnt)
#define HAL_MT_KG_L3_ECMP_BLOCK_SIZE_MAX                              (1024)

#define HAL_MT_KG_L3_ECMP_GRP_MAX_NUM     (16 * 1024)
#define HAL_MT_KG_L3_TNL_ECMP_GRP_MAX_NUM (1024)
#define HAL_MT_KG_L3_SUB_ECMP_GRP_MAX_NUM (4 * 1024)
#define HAL_MT_KG_L3_ECMP_L3IF_MAX_NUM    (64 * 1024)

#define HAL_MT_KG_L3_ECMP_FPU_GRP_BASE_INDEX_LEN (15)

#define HAL_MT_KG_L3_ECMP_FPU_GRP_MBR_BASE_STAGE_OFFSET (17)
#define HAL_MT_KG_L3_ECMP_FPU_GRP_MBR_BASE_TILE_OFFSET  (16)
#define HAL_MT_KG_L3_ECMP_FPU_GRP_MBR_INVALID_FWD_PTR   (0x7FFFF) /* 2b'Stage,3b'tile,14b'index */
#define HAL_MT_KG_L3_ECMP_ICIA_GRP_MBR_IVALID_FWD_PTR   (0x3FFFF)

/* FRR */
#define HAL_MT_KG_L3_FRR_ID_NUM_PER_BANK (16 * 1024)

/* FDL */
#define HAL_MT_KG_L3_FDL_ID_MAX_NUM      (4)
#define HAL_MT_KG_L3_FDL_AR_PATH_NUM     (84)
#define HAL_MT_KG_L3_FDL_PROB_DEFAULT    (0xffffffff)
#define HAL_MT_KG_L3_FDL_HSH_MSB         (11)
#define HAL_MT_KG_L3_FDL_HSH_BASE_OFFSET (12)

/* AR */
#define HAL_MT_KG_L3_AR_ID_MAX_NUM (16)

#if defined(CLX_EMU_DEV) || defined(CLX_MOCK)
#define HAL_MT_L3_HW_FPU_NUM (1) /* TODO: tmp, maybe cdb will have this macro later */
#else
#define HAL_MT_L3_HW_FPU_NUM (4) /* TODO: tmp, maybe cdb will have this macro later */
#endif

/* drop base id */
#define HAL_MT_KG_L3_DROP_ID(unit) (HAL_DROP_BASE_ID(unit))

/*****************************************************************************
 * MACRO FUNCTION DECLARATIONS
 *****************************************************************************
 */
/* hw_addr is 20bit format, 2bit stage + 3bit tile + 15bit entry_idx, entry_width is means how many
 * 1x used per entry */
#define HAL_MT_KG_L3_HIT_ADDR_GET(__hw_addr__, __hit_addr__) \
    do {                                                     \
        TOB_MT_KG_FPU_GET_IDX(__hw_addr__, __hit_addr__);    \
        (__hit_addr__) >>= 5;                                \
    } while (0)

#define HAL_MT_KG_L3_GET_PHY_FPU_ADDR(__slice_idx__, __stage_idx__, __tile_idx__, __entry_idx__, \
                                      __phy_fpu_idx__)                                           \
    ((__phy_fpu_idx__) =                                                                         \
         (((__entry_idx__) & ((1 << TOB_MT_HASH_INDEX_LEN) - 1)) |                               \
          (((__tile_idx__) & ((1 << TOB_MT_KG_HASH_TILE_LEN) - 1)) << TOB_MT_HASH_TILE_OFFSET) | \
          (((__stage_idx__) & ((1 << TOB_MT_KG_HASH_STAGE_LEN) - 1))                             \
           << TOB_MT_KG_HASH_STAGE_OFFSET) |                                                     \
          (((__slice_idx__) & ((1 << TOB_MT_HASH_INST_LEN) - 1)) << TOB_MT_HASH_INST_OFFSET)))

#define HAL_MT_KG_L3_FPU_ADDR_GET(__slice_idx__, __stage_idx__, __tile_idx__, __entry_idx__)      \
    (((__entry_idx__) & ((1 << TOB_MT_HASH_INDEX_LEN) - 1)) |                                     \
     (((__tile_idx__) & ((1 << TOB_MT_KG_HASH_TILE_LEN) - 1)) << TOB_MT_HASH_TILE_OFFSET) |       \
     (((__stage_idx__) & ((1 << TOB_MT_KG_HASH_STAGE_LEN) - 1)) << TOB_MT_KG_HASH_STAGE_OFFSET) | \
     (((__slice_idx__) & ((1 << TOB_MT_HASH_INST_LEN) - 1)) << TOB_MT_HASH_INST_OFFSET))

#define HAL_MT_KG_L3_GET_12_8T_FPU_ADDR(__slice_idx__, __entry_idx__, __phy_fpu_idx__)             \
    ((__phy_fpu_idx__) =                                                                           \
         (((__entry_idx__) &                                                                       \
           (((1 << (TOB_MT_HASH_INDEX_LEN + TOB_MT_KG_HASH_TILE_LEN + TOB_MT_KG_HASH_STAGE_LEN)) - \
             1))) |                                                                                \
          (((__slice_idx__) & ((1 << TOB_MT_HASH_INST_LEN) - 1)) << TOB_MT_HASH_INST_OFFSET)))

/* ADJ */
#define HAL_MT_KG_L3_ADJ_FPU_SIZE(__bitmap__, __bitmap_size__, __fpu_size__, __size__) \
    do {                                                                               \
        uint32 bit;                                                                    \
        (__size__) = 0;                                                                \
        UTIL_LIB_BMP_BIT_FOREACH(__bitmap__, bit, __bitmap_size__)                     \
        {                                                                              \
            (__size__) = (__size__) + (__fpu_size__);                                  \
        }                                                                              \
    } while (0)

#define HAL_MT_KG_L3_ADJ_HW_TO_SW_INDEX(type, hw_idx, sw_idx)                                      \
    do {                                                                                           \
        uint32 rsv_num = HAL_MT_KG_L3_ADJ_HW_RESERVE_NUM / (type == CLX_L3_ADJ_TYPE_VM ? 2 : 1);   \
        uint32 bank_num = HAL_SWC_HASH_ENTRY_NUM_PER_BANK / (type == CLX_L3_ADJ_TYPE_VM ? 2 : 1);  \
        if (rsv_num > 0) {                                                                         \
            (sw_idx) = ((hw_idx) / bank_num * (bank_num - rsv_num) +                               \
                        (((hw_idx) % bank_num >= rsv_num) ? ((hw_idx) % bank_num - rsv_num) : 0)); \
        } else {                                                                                   \
            (sw_idx) = (hw_idx);                                                                   \
        }                                                                                          \
    } while (0)

#define HAL_MT_KG_L3_ADJ_SW_TO_HW_INDEX(type, sw_idx, hw_idx)                                      \
    do {                                                                                           \
        uint32 rsv_num = HAL_MT_KG_L3_ADJ_HW_RESERVE_NUM / (type == CLX_L3_ADJ_TYPE_VM ? 2 : 1);   \
        uint32 bank_num = HAL_SWC_HASH_ENTRY_NUM_PER_BANK / (type == CLX_L3_ADJ_TYPE_VM ? 2 : 1);  \
        (hw_idx) = ((sw_idx) / (bank_num - rsv_num) * bank_num + (sw_idx) % (bank_num - rsv_num) + \
                    rsv_num);                                                                      \
    } while (0)

/* utility */
#define HAL_MT_KG_L3_PLANE_BMP_FOREACH(__unit__, __plane__)                     \
    for ((__plane__) = 0; (__plane__) < HAL_PLANE_NUM(__unit__); (__plane__)++) \
        if (UTIL_LIB_BMP_BIT_CHK((HAL_PLANE_BMP((__unit__))), (__plane__)))

/* hw addr and fpu addr */
#define HAL_MT_KG_L3_FWD_GET(__fpu__, __fwd__)                                                 \
    ((__fwd__) = ((__fpu__) & (HAL_SWC_HASH_ENTRY_NUM_PER_BANK - 1)) |                         \
         ((((__fpu__) >> TOB_MT_HASH_TILE_OFFSET) & ((1 << TOB_MT_KG_HASH_TILE_LEN) - 1))      \
          << (TOB_MT_HASH_TILE_OFFSET - 1)) |                                                  \
         ((((__fpu__) >> TOB_MT_KG_HASH_STAGE_OFFSET) & ((1 << TOB_MT_KG_HASH_STAGE_LEN) - 1)) \
          << (TOB_MT_KG_HASH_STAGE_OFFSET - 1)))

#define HAL_MT_KG_L3_FPU_GET(__fwd__, __fpu__)                                                  \
    ((__fpu__) = ((__fwd__) & (HAL_SWC_HASH_ENTRY_NUM_PER_BANK - 1)) |                          \
         ((((__fwd__) >> (TOB_MT_HASH_TILE_OFFSET - 1)) & ((1 << TOB_MT_KG_HASH_TILE_LEN) - 1)) \
          << TOB_MT_HASH_TILE_OFFSET) |                                                         \
         ((((__fwd__) >> (TOB_MT_KG_HASH_STAGE_OFFSET - 1)) &                                   \
           ((1 << TOB_MT_KG_HASH_STAGE_LEN) - 1))                                               \
          << TOB_MT_KG_HASH_STAGE_OFFSET))

/* VLAN and MPLS LABEL */
#define HAL_MT_KG_L3_GET_VLAN_BY_LBL(__s_vlan__, __c_vlan__, __mpls_en__, __mpls_label__) \
    do {                                                                                  \
        (__s_vlan__) = ((__mpls_label__) & HAL_MT_L3_MPLS_LABEL_BITMASK) >>               \
            HAL_MT_L3_VALN_VID_BITLENGTH;                                                 \
        if (__mpls_en__) {                                                                \
            (__s_vlan__) |= (1 << HAL_MT_L3_SVALN_LABEL_BITLENGTH);                       \
        }                                                                                 \
        (__c_vlan__) = (__mpls_label__) & HAL_MT_L3_VALN_BITMASK;                         \
    } while (0)

#define HAL_MT_KG_L3_GET_LBL_BY_VLAN(__mpls_en__, __mpls_label__, __s_vlan__, __c_vlan__) \
    do {                                                                                  \
        (__mpls_en__) = (((__s_vlan__) >> HAL_MT_L3_SVALN_LABEL_BITLENGTH) & 0x1);        \
        (__mpls_label__) = (((__s_vlan__) & ((1 << HAL_MT_L3_SVALN_LABEL_BITLENGTH) - 1)) \
                            << HAL_MT_L3_VALN_VID_BITLENGTH) |                            \
            ((__c_vlan__) & HAL_MT_L3_VALN_BITMASK);                                      \
    } while (0)

/* Mcast */
#define HAL_MT_KG_L3_MCAST_HSH_PSR_TAGS(tags, idx)                           \
    do {                                                                     \
        ((idx) = ((tags) & ((1 << HAL_MT_KG_L3_MCAST_FPU_KRN_OFFSET) - 1))); \
    } while (0)

#define HAL_MT_KG_L3_MCAST_TRANS_1X_TO_2X(hw_addr_1x, hw_addr_2x)                           \
    do {                                                                                    \
        (hw_addr_2x) = ((hw_addr_1x) & ((1 << TOB_MT_HASH_INDEX_LEN) - 1));                 \
        (hw_addr_2x) =                                                                      \
            (((hw_addr_1x) & (~((1 << TOB_MT_HASH_INDEX_LEN) - 1))) | ((hw_addr_2x) >> 1)); \
    } while (0)

/* ECMP */

/* Mcast */
#define HAL_MT_KG_L3_MAC_IS_BCAST(mac) ((*(mac) == 0xFFFFFFFF) && (*((mac) + 1) == 0xFFFF))

/* Cpu id and queue info */
#define HAL_MT_KG_L3_SET_CPU_ID(__cpu_id__, __cpu_id_queue__) \
    do {                                                      \
        (__cpu_id_queue__) &= 0x3F;                           \
        (__cpu_id_queue__) |= (((__cpu_id__) & 0x3) << 6);    \
    } while (0)

/* Cpu id and queue info */
#define HAL_MT_KG_L3_SET_CPU_QUEUE(__cpu_queue__, __cpu_id_queue__) \
    do {                                                            \
        (__cpu_id_queue__) &= 0xC0;                                 \
        (__cpu_id_queue__) |= ((__cpu_queue__) & 0x3F);             \
    } while (0)

#define HAL_KG_SCAN_HSH_GET_START_IDX(start, stage, tile) \
    ((start) = (((tile) & 0x1) << 15) | (((stage) & 0xF) << 16))

#define HAL_KG_SCAN_HSH_GET_END_IDX(end, stage, tile) \
    ((end) = ((0x3FFF) | (((tile) & 0x1) << 15) | (((stage) & 0xF) << 16)))

/* Init rwi_hsh_mcg_vif info key */
#define HAL_MT_KG_L3_HSH_MCG_VIF_KEY_INIT(hsh_info, __alt_mc_vmid__, __vm_port_idx__, __mc_id__) \
    do {                                                                                         \
        (hsh_info).mc_id = (__mc_id__);                                                          \
        (hsh_info).alt_mc_vmid = (__alt_mc_vmid__);                                              \
        (hsh_info).vm_port_idx = (__vm_port_idx__);                                              \
    } while (0)

/* Init rwi_hsh_mcg_vif info */
#define HAL_MT_KG_L3_HSH_MCG_VIF_INFO_INIT(hsh_info, __alt_mc_vmid__, __vm_port_idx__, __mc_id__, \
                                           __vm_id__)                                             \
    do {                                                                                          \
        (hsh_info).mc_id = (__mc_id__);                                                           \
        (hsh_info).alt_mc_vmid = (__alt_mc_vmid__);                                               \
        (hsh_info).vm_port_idx = (__vm_port_idx__);                                               \
        (hsh_info).vm_id = (__vm_id__);                                                           \
    } while (0)

/*****************************************************************************
 * DATA TYPE DECLARATIONS
 *****************************************************************************
 */
typedef uint32 hal_mt_kg_l3_flush_cmd_hash_entry_t[HAL_MT_L3_FLUSH_HASH_ENTRY_WORDS];

/* MCAST */
typedef struct hal_mt_kg_l3_rpf_tcam_s {
    uint32 entry_idx;
    uint32 bdid;
    uint32 grp_mtree_id;
    uint32 grp_mtree_type;
} hal_mt_kg_l3_rpf_tcam_t;

/* emdb_id and hash_id is calculate by grp_id and sn */
typedef struct hal_mt_kg_l3_mcast_mbr_s {
    struct {
        clx_l3_mcast_egr_intf_type_t intf_type; /* set when add member and used for get */
        uint32 port_id;                         /* ipmc group member port       */
        uint32 intf_id;                         /* ipmc group member interface  */
    } key;
    uint32 sn;                                  /* ipmc group member sn         */
    uint32 tbl;                                 /* tbl id                       */
    boolean is_fl;
    uint32 di;
    uint32 emdb_id;  /* ipmc group member emdb id    */
    uint32 mcdb_idx; /* ipmc group member mcdb idx   */
    uint32 emdb_idx; /* ipmc group member emdb idx   */
    uint32 mel_idx;  /* mel idx                      */
} hal_mt_kg_l3_mcast_mbr_t;

typedef struct hal_mt_kg_l3_mcast_grp_s {
    /* AVL key */
    uint32 mcast_id; /* ipmc group index         */

    /* AVL data */
    uint32 mbr_num;                                               /* ipmc group member count  */
    clx_port_bitmap_t port_bmp[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM]; /* ipmc group pbm */
    util_lib_avl_head_t *mbr_avl;                                 /* ipmc group member avl tree */
    HAL_LAGID_BITMAP_T lag_bmp;                                   /* ipmc group lagid bitmap  */
} hal_mt_kg_l3_mcast_grp_t;

typedef struct hal_mt_kg_l3_mcast_mel_key_s {
    uint32 bd_id;
    uint32 tnl_bd;
    uint32 tnl_idx;
    uint32 mpls_ctl;
    uint32 swap_en;
    uint32 swap_lbl;
    boolean tapping_faver_mel;
    boolean fcm_vld;
    boolean force_decap;
    boolean fcm_ignore_igr;
} hal_mt_kg_l3_mcast_mel_key_t;

typedef struct hal_mt_kg_l3_mcast_mel_node_s {
    /* AVL key */
    hal_mt_kg_l3_mcast_mel_key_t key;

    /* AVL data */
    uint32 cud_idx; /* resource index   */
    uint32 use_num; /* reference count  */
} hal_mt_kg_l3_mcast_mel_node_t;

typedef struct hal_mt_kg_l3_mcast_cb_s {
    /* RPF */
    uint32 rp_bmp[CLX_BITMAP_SIZE(HAL_L3_RPF_NUM)];
    util_lib_avl_head_t *rpa_avl;

    /* Usage */
    uint32 hash_1x_cnt;
    uint32 hash_2x_cnt;
    uint32 sg_tcam_cnt;

    /* Count */
    uint32 ipv4_xg_cnt;
    uint32 ipv4_sg_cnt;
    uint32 ipv6_xg_cnt;
    uint32 ipv6_sg_cnt;

    clx_semaphore_id_t sema;

    /* Swdb */
    util_lib_avl_head_t *grp_avl; /* save group and member        */
    util_lib_avl_head_t *sg_avl;  /* save (s,g) entry             */
    util_lib_avl_head_t *s_g_avl; /* save src or grp reference    */
    util_lib_avl_head_t *mel_avl; /* save mc intf cud             */

    /* Tile BMP */
    hal_swc_hsh_tile_bmp_t mgi_tile_bmp;
    hal_swc_hsh_tile_bmp_t msgi_tile_bmp;
    hal_swc_hsh_tile_bmp_t rpfc_tile_bmp;

} hal_mt_kg_l3_mcast_cb_t;

/* sw mcast ip node */
typedef struct hal_mt_kg_l3_mcast_sg_node_s {
    /* AVL key */
    boolean ipv4;
    uint32 vrf_id;
    clx_ip_t grp_ip;
    clx_ip_t src_ip;

    /* AVL data */
    uint32 insert_tcam; /* sg hw addr info */
    uint32 hw_idx;

    uint32 da_tag; /* sg hw search key */
    uint32 da_tcam_hit;
    uint32 sa_tag;
    uint32 sa_tcam_hit;
    uint32 sa_afib_hit;

} hal_mt_kg_l3_mcast_sg_node_t;

/* sw mcast ip node */
typedef struct hal_mt_kg_l3_mcast_s_g_node_s {
    /* AVL key */
    boolean ipv4;
    uint32 vrf_id;
    clx_ip_t ip;

    uint32 tag; /* hw info */
    uint32 tcam_hit;
    uint32 afib_hit;

    /* reference info */
    uint32 sg_only;  /* used by xg */
    uint32 used_num; /* used by src/xg */
} hal_mt_kg_l3_mcast_s_g_node_t;

typedef struct hal_mt_kg_l3_mcast_route_rsrc_s {
    boolean ipv4;
    uint32 tbl;                      /* table ID           */
    hal_swc_hsh_tile_bmp_t bank_bmp; /* bank bitmap        */
    union {
        uint32 ipv4_xg_buf[MT_KG_CDB_FPU_HSH_MGI_V4_WORDS];
        uint32 ipv6_xg_buf[MT_KG_CDB_FPU_HSH_MGI_V6_WORDS];
        uint32 ip_sg_buf[MT_KG_CDB_FPU_HSH_MSGI_WORDS];
    } buf;
    char ip_str[UTIL_IP_ADDR_STR_SIZE];

    /* user data */
    uint32 grp_hit;
    uint32 mcast_id;
    uint32 mcast_en;
    uint32 mc_drop;
    uint32 c2c_en;
    uint32 pim_sm_spt_rdy;
    uint32 keep_ttl;
    uint32 bd_mode;
    uint32 bdid;
    uint32 mrpf_fail_act;
    uint32 sg_only;
    uint32 sa_dc;

    /* hw info */
    uint32 valid; /* only for sg */
    uint32 da_tag;
    uint32 da_tcam_hit;
    uint32 sa_tag;
    uint32 sa_tcam_hit;
    uint32 sa_afib_hit;

    uint32 insert_tcam; /* sg hw addr info */
    uint32 hw_idx;

} hal_mt_kg_l3_mcast_route_rsrc_t;

typedef struct hal_mt_kg_l3_mcast_mel_info_s {
    uint32 bd_id;
    uint32 nvo3_adj_idx;
    uint32 nvo3_encap_idx;
    uint32 seg_vmid;
    uint32 mpls_ctl;
    uint32 swap_lbl;
    boolean fcm_vld;
    boolean tapping_mel_en;
    boolean force_decap_en;
    boolean fcm_ignore_igr;
} hal_mt_kg_l3_mcast_mel_info_t;

typedef struct hal_mt_kg_l3_hsh_mcg_vif_s {
    /* Key */
    uint32 mc_id;
    uint32 alt_mc_vmid;
    uint32 vm_port_idx;
    /* Value */
    uint32 vm_id;
} hal_mt_kg_l3_hsh_mcg_vif_t;

/* ROUTE */
typedef struct hal_mt_kg_l3_fib_rsrc_s {
    /* HW data */
    uint32 is_default;
    uint32 fwd_ptr;
    uint32 sa_dc;
    uint32 decr_ttl;
    uint32 acl_lbl;

    /* User data */
    clx_nhp_t nhp;       /* Host|Route nhp               */
    uint32 subnet_bc_id; /* SubnetBcast                  */
    uint32 subnet_bc_en; /* SubnetBcast                  */
    uint32 mpls_lbl;     /* Host|Route                   */
    uint32 mpls_en;      /* Host|Route                   */
    uint32 uc_drop;      /* Host|Route                   */

} hal_mt_kg_l3_fib_rsrc_t;

typedef struct hal_mt_kg_l3_route_rsrc_s {
    uint32 tbl_id;                    /* ILE table ID             */
    uint32 bank_bmp;                  /* ILE bank bitmap [HASH]   */
    uint32 free_exm;                  /* ILE free EXM id [HASH]   */
    uint32 flw_lbl;                   /* IEV_INDIR result         */
    uint32 iev_idx;                   /* IEV index (getFcoe)      */
    hal_mt_kg_l3_fib_rsrc_t fib_rsrc; /* FIB result               */
    union {
        uint32 ipv4_tcam_1x_buf[MT_KG_CDB_FPU_TCAM_FIB_V4_WORDS];
        uint32 ipv6_tcam_2x_buf[MT_KG_CDB_FPU_TCAM_FIB_V6_2X_WORDS];
        uint32 ipv6_tcam_4x_buf[MT_KG_CDB_FPU_TCAM_FIB_V6_4X_WORDS];
    } buf;
    union {
        uint32 fib_ptr_buf[MT_KG_CDB_FPU_RSLT_FIB_WORDS];
        uint32 afib_ptr_buf[MT_KG_CDB_FPU_RSLT_AFIB_PTR_WORDS];
        uint32 mgi_buf[MT_KG_CDB_FPU_RSLT_MGI_WORDS];
    } rslt_buf;
    uint32 lpm_tile_buf[MT_KG_CDB_FPU_HSH_LPM_AFIB_V4_WORDS];
    char ip_str[UTIL_IP_NETWORK_STR_SIZE];

    /* e.g.
     * ip=192.168.0.4/31, root-ip=192.168.0.0/29 (buf)
     * found root ile_idx=8192, iev_indir_idx=327680, trie_bmp=0x111, iev_idx=81920 (read from ADJ)
     *
     * - vrf_vld            is 1      (calculated from flag)
     * - msk_btot           is 3      (calculated from prefix)
     * - real_prefix        is 31
     * - root_prefix        is 29
     * - root_key           is 15
     *
     * - trie_bit           is 5      (0 or calculated from trie-bmp)
     * - rslt_shift         is 1      (0 or calculated from trie-bmp)
     *
     * - root_vld           is 1
     * - root_d_fpu_idx     is 8192   (read from AVL)
     * - root_s_fpu_idx     is 12288  (read from AVL)
     * - root_rslt_idx      is 327680 (read from HW)
     * - root_rslt_cnt      is 3      (read from HW)
     * - real_vld           is 1
     */
    uint32 is_1x;            /* FPU is_1x                                */
    uint32 vrf_vld;          /* FPU vrf_vld                              */
    uint32 vrf_id;           /* FPU vrf_id                               */
    uint32 option_exist_vld; /* option_exist_vld                         */
    uint32 option_exist;     /* option_exist                             */
    uint32 msk_btot;         /* FPU msk_btot                             */
    uint32 real_prefix;
    uint32 root_prefix;
    uint32 root_key;       /* calculated block key [TCAM]              */

    uint32 trie_bit;       /* based on root IP                         */
    uint32 rslt_shift;     /* based on IEV_INDIR index                 */

    uint32 root_vld;       /* root IP exists in HW                     */
    uint32 root_d_fpu_idx; /* root FPU DIP 1x      (only for root_vld) */
    uint32 root_s_fpu_idx; /* root FPU SIP 1x      (only for root_vld) */
    uint32 root_rslt_idx;  /* root indir index (only for root_vld) */
    uint32 root_rslt_cnt;  /* root indir count (only for root_vld) */
    uint32 real_vld;       /* real IP exists in HW                     */

} hal_mt_kg_l3_route_rsrc_t;

/* Add For Bulk Route */
typedef struct hal_mt_kg_l3_route_ext_rsrc_s {
    hal_mt_kg_l3_route_rsrc_t route_rsrc;
    uint32 route_id; /* ip add order */
    uint32 attrbmp;
    uint32 root_ip[HAL_L3_ROUTE_ROOT_WORD_NUM];
    uint32 root_mask[HAL_L3_ROUTE_ROOT_WORD_NUM];
} hal_mt_kg_l3_route_ext_rsrc_t;

typedef struct hal_mt_kg_l3_route_trav_cookie_s {
    uint32 unit;

    /* [In] for traverseRoute() API, directly callback */
    uint32 tbl_id;
    util_lib_list_t *ptr_list;
    uint32 cnt;

    uint32 is_dip;
    uint32 entry_num;
    uint32 old_idx;
    uint32 new_idx;

} hal_mt_kg_l3_route_trav_cookie_t;

/* Add for get l3 actual route count */
typedef struct hal_mt_kg_l3_route_num_s {
    uint32 ipv4_num;
    uint32 ipv6_num;
    /*  uint32                  ipv6_short_num; */
    /*  uint32                  ipv6_long_num;  */
    /*  uint32                  def_global_num; */
} hal_mt_kg_l3_route_num_t;

/* priority hash cfg */
typedef struct hal_mt_kg_l3_route_lpm_hash_cfg_s {
    hal_l3_lpm_tile_type_t type; /* tile type                */
    uint32 v4_vld;               /* v4 vld                   */
    uint32 v6_vld;               /* v6 vld                   */
    uint32 lpm_v4_count;         /* lpm v4 entry count       */
    uint32 lpm_v6_count;         /* lpm v6 entry count       */
    uint32 mgi_v4_count;         /* mgi v4 entry count       */
    uint32 mgi_v6_count;         /* mgi v6 entry count       */
    uint32 v4_prefix_len;        /* v4 prefix length         */
    uint32 v6_prefix_len;        /* v6 prefix length         */
    uint32 hw_rsrc_cnt;          /* hw rsrc count            */
} hal_mt_kg_l3_route_lpm_hash_cfg_t;

typedef struct hal_mt_kg_l3_route_lpm_hash_info_s {
    hal_mt_kg_l3_route_lpm_hash_cfg_t cfg[HAL_MT_KG_L3_LPM_TILE_NUM];
    uint32 lpm_v4_bmp[1];
    uint32 lpm_v6_bmp[1];
    uint32 alpm_v4_bmp[1];
    uint32 alpm_v6_bmp[1];
    uint32 mgi_v4_bmp[1];
    uint32 mgi_v6_bmp[1];
    uint32 vld_tile_bmp[1];
} hal_mt_kg_l3_route_lpm_hash_info_t;

/* ADJ */
typedef struct hal_mt_kg_l3_adj_cb_s {
    util_lib_avl_head_t *ptr_avl; /* util_lib_avl_insert(hal_l3_adj_node_t) when addAdj()
                                   * util_lib_avl_delete(hal_l3_adj_node_t) when delAdj()
                                   * util_lib_list_tail_data_insert(uint32) when addGrpList() of
                                   * ECMP and FRR util_lib_list_node_delete_by_data(uint32) when
                                   * delGrpList() of ECMP and FRR
                                   */
    clx_semaphore_id_t sema;

    uint32 *adj_1x_bmp;
    uint32 *adj_2x_bmp;
    uint32 adj_1x_cnt;
    uint32 adj_2x_cnt;
    hal_swc_hsh_tile_bmp_t arp_1x_tile;
    hal_swc_hsh_tile_bmp_t arp_2x_tile;
    hal_swc_hsh_tile_bmp_t rpf_tile;
    hal_mt_kg_l3_rpf_tcam_t rpf_tcam[HAL_MT_L3_RPF_TCAM_MAX_NUM];

} hal_mt_kg_l3_adj_cb_t;

typedef struct hal_mt_kg_l3_ecmp_l3if_node_s {
    /* AVL key */
    uint32 adj_id; /* adj index */
    /* AVL data */
    uint32 l3if_idx;     /* l3if index */
    uint32 l3if_use_num; /* l3if use num */
} hal_mt_kg_l3_ecmp_l3if_node_t;

typedef struct hal_mt_kg_l3_ecmp_tnl_node_s {
    /* AVL key */
    uint32 grp_id; /* tnl group id */
    uint32 tnl_di; /* tnl destination index */
    /* AVL data */
    uint32 output_id; /* tnl output id */
} hal_mt_kg_l3_ecmp_tnl_node_t;

typedef struct hal_mt_kg_l3_ecmp_fdl_node_s {
    /* AVL key */
    uint32 fdl_id; /* fdl index     */
    /* AVL data */
    boolean enable;   /* fdl enable     */
    uint32 ecmp_id;   /* fdl ecmp id     */
    uint32 ecmp_type; /* fdl ecmp type: 0:l3,  1:tnl */
    uint32 hsh_sel;   /* fdl hsh sel     */
} hal_mt_kg_l3_ecmp_fdl_node_t;

typedef struct hal_mt_kg_l3_ecmp_ar_node_s {
    /* AVL key */
    uint32 ar_id; /* ar index     */
    /* AVL data */
    boolean enable;   /* ar enable     */
    uint32 ecmp_id;   /* ar ecmp id     */
    uint32 ecmp_type; /* ar ecmp type: 0:l3,  1:tnl */
} hal_mt_kg_l3_ecmp_ar_node_t;

typedef struct hal_mt_kg_l3_ecmp_node_s {
    /* AVL key */
    uint32 grp_type; /* ecmp group type     */
    uint32 grp_idx;  /* ecmp group idx     */

    /* AVL data */
    boolean algo_ctrl;
    clx_l3_ecmp_mode_t ecmp_mode;      /* ecmp mode:normal/rr/ar/fdl */
    clx_l3_ecmp_algo_mode_t algo_mode; /* ecmp group mode     */
    uint32 grp_tbl;
    uint32 path_tbl;
    uint32 hal_sel;
    uint32 act_cnt;
    uint32 org_cnt;
    uint32 path_cnt;
    uint32 weight_vld; /* only update weight_cnt when this field is 1 */
    uint32 use_num;    /* reference count of host, route, fdl */
    uint32 real_size;  /* real hash buckets for fine grain ECMP */
    uint32 order_mode; /* order ecmp */
    uint32 fine_grain; /* fine grain ecmp */
    uint32 flex_mode;  /* flex ecmp */
    uint32 fdl_ar_idx; /* fdl/ar index */
} hal_mt_kg_l3_ecmp_node_t;

typedef struct hal_mt_kg_l3_ecmp_grp_s {
    uint32 grp_id; /* ecmp group index    */
    uint32 grp_tbl;
    uint32 path_tbl;
    boolean algo_ctrl;
    clx_l3_ecmp_mode_t ecmp_mode;      /* ecmp mode:normal/rr/ar/fdl */
    clx_l3_ecmp_algo_mode_t algo_mode; /* ecmp group mode     */
    clx_nhp_type_t grp_type;           /* ecmp group type     */
    uint32 hal_sel;                    /* flag for hal sel    */
    uint32 act_cnt;
    uint32 org_cnt;
    uint32 path_cnt;
    uint32 weight_vld; /* only update weight_cnt when this field is 1 */
    uint32 use_num;    /* reference count of host, route */
    uint32 real_size;  /* real hash buckets for fine grain ECMP */
    uint32 order_mode; /* order ecmp */
    uint32 fine_grain; /* fine grain ecmp */
    uint32 flex_mode;  /* flex ecmp */
    uint32 fdl_ar_idx; /* fdl/ar index */
} hal_mt_kg_l3_ecmp_grp_t;

typedef struct hal_mt_kg_l3_ecmp_fdl_info_s {
    uint32 fdl_id;
    boolean enable;
    uint32 ecmp_id;
    uint32 ecmp_type; /* 0:l3,  1:tnl */
    uint32 hsh_sel;
    uint32 prob;
    uint32 indir_base;
} hal_mt_kg_l3_ecmp_fdl_info_t;

typedef struct hal_mt_kg_l3_ecmp_ar_info_s {
    uint32 ar_id;
    boolean enable;
    uint32 ecmp_id;
    uint32 ecmp_type; /* 0:l3,  1:tnl */
    uint32 indir_base;
} hal_mt_kg_l3_ecmp_ar_info_t;

typedef struct hal_mt_kg_l3_ecmp_path_s {
    /* group */
    hal_mt_kg_l3_ecmp_grp_t ecmp_info; /* SWDB info */
    uint32 grp_tbl;                    /* ECMP_U */
    union {
        uint32 adj_buf[MT_KG_FPU_RSLT_ECMP_GRP_LAST_FIELD_ID];
        uint32 tnl_buf[MT_KG_FWR_RSLT_TNL_ECMP_GRP_LAST_FIELD_ID];
        uint32 l2_buf[MT_KG_FPU_RSLT_ECMP_GRP_LAST_FIELD_ID];
        uint32 mpls_buf[MT_KG_FPU_RSLT_ECMP_GRP_LAST_FIELD_ID];
    } grp_buf;

    /* [add/del] path from user
     * [get] path from hw
     */
    uint32 path_weight; /* weight or 1 */
    uint32 path_tbl;    /* ECMP_PATH_U */
    union {
        uint32 adj_buf[MT_KG_FPU_RSLT_ECMP_MBR_LAST_FIELD_ID];
        uint32 tnl_buf[MT_KG_FWR_RSLT_TNL_ECMP_MBR_LAST_FIELD_ID];
        uint32 l2_buf[MT_KG_FPU_RSLT_L2_ECMP_MBR_LAST_FIELD_ID];
        uint32 mpls_buf[MT_KG_FPU_RSLT_MPLS_ECMP_MBR_LAST_FIELD_ID];
    } path_buf;

    /* [add/del] state from user
     * [get] state from hw
     */
    uint32 output_id;
    uint32 fwd_ptr;
    uint32 dst_idx;
    // uint32 tnl_bd;
    uint32 state;

    uint32 mpls_ctl;
    uint32 mpls_lbl;

    /* metas from HW act */
    uint32 act_offset; /* path offset */
    uint32 act_weight; /* path count for hw, or sw_spray count for sw */
    uint32 act_vld;
    uint32 *act_list;  /* path list */

    /* metas from HW org */
    uint32 org_offset; /* path offset */
    uint32 org_weight; /* path count */
    uint32 org_vld;    /* this path may be out of org, but in act */
    uint32 *org_list;  /* path list */

} hal_mt_kg_l3_ecmp_path_t;
/*****************************************************************************
 * LOCAL SUBPROGRAM BODIES
 *****************************************************************************
 */
/* ----------------------------------------------------------------------------------- MAIN */
/* Resource */
clx_error_no_t
hal_mt_kg_l3_capacity_get(const uint32 unit,
                          const clx_swc_rsrc_t type,
                          const uint32 param,
                          uint32 *ptr_size);

clx_error_no_t
hal_mt_kg_l3_usage_get(const uint32 unit,
                       const clx_swc_rsrc_t type,
                       const uint32 param,
                       uint32 *ptr_cnt);

clx_error_no_t
hal_mt_kg_l3_dst_idx_get(const uint32 unit, const clx_port_t port, uint32 *ptr_di);

clx_error_no_t
hal_mt_kg_l3_fwd_get(const uint32 unit,
                     const clx_nhp_t nhp,
                     const uint32 subnet_bc_id,
                     uint32 *ptr_fwd_ptr);

clx_error_no_t
hal_mt_kg_l3_fwd_free(const uint32 unit,
                      const clx_nhp_t nhp,
                      const uint32 subnet_bc_id,
                      const uint32 fwd_ptr);

clx_error_no_t
hal_mt_kg_l3_nhp_get(const uint32 unit, const uint32 fwd, clx_nhp_t *ptr_nhp, uint32 *ptr_bc_id);

/* RPFC */
void
hal_mt_kg_l3_urpf_hash_trans(const uint32 unit,
                             const hal_mt_l3_rpfc_type_t type,
                             const uint32 grp_id,
                             const uint32 bdid,
                             uint32 *ptr_buf);

void
hal_mt_kg_l3_urpf_tcam_trans(const uint32 unit,
                             const hal_mt_l3_rpfc_type_t type,
                             const boolean vld,
                             const uint32 grp_id,
                             const uint32 bdid,
                             uint32 *ptr_buf);

/* Init and Deinit */
clx_error_no_t
hal_mt_kg_l3_mcast_const_set(uint32 l3_mgid_num);

clx_error_no_t
hal_mt_kg_l3_init(const uint32 unit);

clx_error_no_t
hal_mt_kg_l3_deinit(const uint32 unit);

clx_error_no_t
hal_mt_kg_l3_tbl_dma_move(const uint32 unit,
                          const uint32 tbl_id,
                          const boolean isOffsetDel,
                          const uint32 offset,
                          const uint32 old_base,
                          const uint32 old_num,
                          const uint32 new_base);

clx_error_no_t
hal_mt_kg_l3_rwi_hsh_mcg_vif_add(const uint32 unit,
                                 const uint32 alt_mc_vmid,
                                 const uint32 vm_port_idx,
                                 const uint32 mc_id,
                                 const uint32 vm_id);

clx_error_no_t
hal_mt_kg_l3_rwi_hsh_mcg_vif_del(const uint32 unit,
                                 const uint32 alt_mc_vmid,
                                 const uint32 vm_port_idx,
                                 const uint32 mc_id);

clx_error_no_t
hal_mt_kg_l3_rwi_hsh_mcg_vif_get(const uint32 unit, hal_mt_kg_l3_hsh_mcg_vif_t *mcg_vif);

clx_error_no_t
hal_mt_kg_l3_rwi_hsh_vlan_add(const uint32 unit,
                              const uint32 lcl_intf,
                              const uint32 port,
                              const uint32 bdi,
                              const uint32 s_vlan,
                              const uint32 c_vlan);

clx_error_no_t
hal_mt_kg_l3_mpls_lbl_add(const uint32 unit,
                          const clx_nhp_t nhp,
                          const uint32 mpls_en,
                          const uint32 label);

clx_error_no_t
hal_mt_kg_l3_mpls_lbl_read(const uint32 unit, const clx_nhp_t nhp, uint32 *mpls_en, uint32 *label);

clx_error_no_t
hal_mt_kg_l3_mpls_lbl_del(const uint32 unit, const clx_nhp_t nhp);

/* Dump SWDB */
clx_error_no_t
hal_mt_kg_l3_swdb_dump(const uint32 unit, const uint32 flags);

/* Properties */
clx_error_no_t
hal_mt_kg_l3_ref_update(const uint32 unit, const clx_nhp_t nhp, const boolean inc);

clx_error_no_t
hal_mt_kg_l3_urpf_check_set(const uint32 unit, const uint32 is_enable);

clx_error_no_t
hal_mt_kg_l3_urpf_check_get(const uint32 unit, uint32 *ptr_is_enable);

clx_error_no_t
hal_mt_kg_l3_icmp_redir_set(const uint32 unit, const uint32 is_enable);

clx_error_no_t
hal_mt_kg_l3_icmp_redir_get(const uint32 unit, uint32 *ptr_is_enable);

clx_error_no_t
hal_mt_kg_l3_validate_ip_set(const uint32 unit, const uint32 enable, const uint32 fail_act);

clx_error_no_t
hal_mt_kg_l3_validate_ip_get(const uint32 unit, uint32 *ptr_enable, uint32 *ptr_fail_act);

clx_error_no_t
hal_mt_kg_l3_excpt_act_set(const uint32 unit,
                           const clx_swc_cfg_t property,
                           const clx_fwd_action_t action);
/**
 * @brief Get L3 exceptions.
 *
 * Apply to the following reason:
 * - CLX_PKT_RX_REASON_IPV4_MC_LKP_MISS
 * - CLX_PKT_RX_REASON_IPV6_MC_LKP_MISS
 * - CLX_PKT_RX_REASON_IPV4_HDR_OPTION
 * - CLX_PKT_RX_REASON_IPV6_HOP_BY_HOP_EXT_HDR
 * - CLX_PKT_RX_REASON_IGR_L3_MTU_FAIL
 * - CLX_PKT_RX_REASON_EGR_L3_MTU_FAIL
 * - CLX_PKT_RX_REASON_IP_TTL_0
 * - CLX_PKT_RX_REASON_IP_TTL_1.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     property      - Property type.
 * @param [out]    ptr_action    - Action.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_l3_excpt_act_get(const uint32 unit,
                           const clx_swc_cfg_t property,
                           clx_fwd_action_t *ptr_action);
/**
 * @brief Set L3 Header error actions.
 *
 * Apply to the following reason:
 * - CLX_SWC_CFG_IPV4_VER_ERR
 * - CLX_SWC_CFG_IPV4_CHKSM_ERR
 * - CLX_SWC_CFG_IPV4_OPT
 * - CLX_SWC_CFG_IPV6_VER_ERR
 * CLX8600 not support len err.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    property    - Property type.
 * @param [in]    action      - Action.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_l3_hdr_err_act_set(const uint32 unit,
                             const clx_swc_cfg_t property,
                             const clx_fwd_action_t action);
/**
 * @brief Get L3 Header error actions.
 *
 * Apply to the following reason:
 * - CLX_SWC_CFG_IPV4_VER_ERR
 * - CLX_SWC_CFG_IPV4_CHKSM_ERR
 * - CLX_SWC_CFG_IPV4_OPT
 * - CLX_SWC_CFG_IPV4_LEN_ERR
 * CLX8600 not support len err.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     property      - Property type.
 * @param [out]    ptr_action    - Action.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_l3_hdr_err_act_get(const uint32 unit,
                             const clx_swc_cfg_t property,
                             clx_fwd_action_t *ptr_action);

/* ----------------------------------------------------------------------------------- RMAC  */
clx_error_no_t
hal_mt_kg_l3_rmac_add(const uint32 unit, const clx_l3_rmac_t *ptr_rmac);
clx_error_no_t
hal_mt_kg_l3_rmac_del(const uint32 unit, const uint32 idx);
clx_error_no_t
hal_mt_kg_l3_rmac_get(const uint32 unit, clx_l3_rmac_t *ptr_rmac);
clx_error_no_t
hal_mt_kg_l3_intf_rmac_set(const uint32 unit, const uint32 intf_id, const uint32 rmac_idx);

clx_error_no_t
hal_mt_kg_l3_rmac_trav(const uint32 unit, const clx_l3_rmac_trav_func_t cb, void *cookie);
clx_error_no_t
hal_mt_kg_l3_rmac_idx_get(const uint32 unit, const uint32 intf_id, uint32 *rmac_idx);
clx_error_no_t
hal_mt_kg_l3_rmac_idx_set(const uint32 unit, const uint32 intf_id, const uint32 rmac_idx);
/* ----------------------------------------------------------------------------------- INTF */
/* Init and Deinit */
clx_error_no_t
hal_mt_kg_l3_intf_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_kg_l3_intf_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

/* Internal API */
clx_error_no_t
hal_mt_kg_l3_intf_id_get(const uint32 unit, const clx_bridge_domain_t bdid, uint32 *ptr_intf_id);

clx_error_no_t
hal_mt_kg_l3_intf_fdid_get(const uint32 unit, const uint32 intf_id, clx_bridge_domain_t *ptr_bdid);

clx_error_no_t
hal_mt_kg_l3_intf_set(const uint32 unit, clx_l3_intf_t *ptr_intf);

clx_error_no_t
hal_mt_kg_l3_intf_rsrc_get(const uint32 unit,
                           const uint32 intf_id,
                           hal_l3_intf_rsrc_t *ptr_intf_rsrc);

clx_error_no_t
hal_mt_kg_l3_intf_capacity_get(const uint32 unit, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_kg_l3_intf_usage_get(const uint32 unit, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_kg_l3_intf_swdb_dump(const uint32 unit);

clx_error_no_t
hal_mt_kg_l3_intf_ullm_sa_use_da_or_reg_set(const uint32 unit, const uint32 sa_use_da_or_reg);

clx_error_no_t
hal_mt_kg_l3_intf_ullm_sa_use_da_or_reg_get(const uint32 unit, uint32 *ptr_sa_use_da_or_reg);

clx_error_no_t
hal_mt_kg_l3_intf_ullm_mac_sa_set(const uint32 unit,
                                  const uint32 mac_sa_hi_16,
                                  const uint32 mac_sa_lo_32);

clx_error_no_t
hal_mt_kg_l3_intf_ullm_mac_sa_get(const uint32 unit,
                                  uint32 *ptr_mac_sa_hi_16,
                                  uint32 *ptr_mac_sa_lo_32);

/* CLX API */
clx_error_no_t
hal_mt_kg_l3_intf_add(const uint32 unit, clx_l3_intf_t *ptr_intf);

clx_error_no_t
hal_mt_kg_l3_intf_del(const uint32 unit, const uint32 intf_id);

clx_error_no_t
hal_mt_kg_l3_intf_get(const uint32 unit, clx_l3_intf_t *ptr_intf);

clx_error_no_t
hal_mt_kg_l3_intf_trav(const uint32 unit, const clx_l3_intf_trav_func_t callback, void *ptr_cookie);

/* ----------------------------------------------------------------------------------- VRF */
/* Init and Deinit */
clx_error_no_t
hal_mt_kg_l3_vrf_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_kg_l3_vrf_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

/* Internal API */
clx_error_no_t
hal_mt_kg_l3_vrf_cb_get(const uint32 unit, hal_l3_vrf_cb_t **ptr_vrf_cb);

clx_error_no_t
hal_mt_kg_l3_vrf_swdb_dump(const uint32 unit);

/* CLX API */
clx_error_no_t
hal_mt_kg_l3_vrf_set(const uint32 unit, const clx_l3_vrf_t *ptr_vrf);

clx_error_no_t
hal_mt_kg_l3_vrf_get(const uint32 unit, clx_l3_vrf_t *ptr_vrf);

/* ----------------------------------------------------------------------------------- ADJ */
clx_error_no_t
hal_mt_kg_l3_adj_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_kg_l3_adj_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_kg_l3_adj_info_get(const uint32 unit, const uint32 adj_id, hal_l3_adj_info_t *adj_info);

clx_error_no_t
hal_mt_kg_l3_adj_ref_update(const uint32 unit, const uint32 adj_id, const boolean inc);

/* handle URPF */
clx_error_no_t
hal_mt_kg_l3_adj_ecmp_urpf_add(/* for addEcmpPath */
                               const uint32 unit,
                               const uint32 ecmp_id,
                               const uint32 intf_id);

clx_error_no_t
hal_mt_kg_l3_adj_ecmp_urpf_del(/* for delEcmp, delEcmpPath */
                               const uint32 unit,
                               const uint32 ecmp_id,
                               const uint32 intf_id);

clx_error_no_t
hal_mt_kg_l3_adj_ecmp_urpf_update(/* for setIntf, delIntf */
                                  const uint32 unit,
                                  const uint32 is_add,
                                  const uint32 bdid);

clx_error_no_t
hal_mt_kg_l3_adj_ecmp_refer_add(/* for addEcmpPath */
                                const uint32 unit,
                                const uint32 ecmp_id,
                                const uint32 adj_id);

clx_error_no_t
hal_mt_kg_l3_adj_ecmp_refer_del(/* for delEcmp, delEcmpPath */
                                const uint32 unit,
                                const uint32 ecmp_id,
                                const uint32 adj_id);

/* CLX API */
clx_error_no_t
hal_mt_kg_l3_adj_add(const uint32 unit, clx_l3_adj_t *ptr_adj);

clx_error_no_t
hal_mt_kg_l3_adj_del(const uint32 unit, const uint32 adj_id);

clx_error_no_t
hal_mt_kg_l3_adj_get(const uint32 unit, clx_l3_adj_t *ptr_adj);

clx_error_no_t
hal_mt_kg_l3_adj_trav(const uint32 unit,
                      const clx_l3_adj_type_t adj_type,
                      const clx_l3_adj_trav_func_t cb,
                      void *cookie);

clx_error_no_t
hal_mt_kg_l3_adj_usage_get(const uint32 unit, const uint32 param, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_kg_l3_adj_swdb_dump(const uint32 unit);

clx_error_no_t
hal_mt_kg_l3_adj_fpu_get(const uint32 unit, const uint32 adj_id, uint32 *hw_idx);

// clx_error_no_t
// hal_mt_kg_l3_adj_nhp_fpu_get(const uint32 unit, const uint32 adj_id, uint32 *ptr_hw_addr);

clx_error_no_t
hal_mt_kg_l3_adj_id_with_fpu_get(const uint32 unit, const uint32 fwd_ptr, uint32 *adj_id);

clx_error_no_t
hal_mt_kg_l3_adj_capacity_get(const uint32 unit, const uint32 param, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_kg_l3_adj_bcast_fdb_add(const uint32 unit, const uint32 subnet_bc_id, uint32 *ptr_fpu_idx);
clx_error_no_t
hal_mt_kg_l3_adj_mpls_valid_set(const uint32 unit, const uint32 adj_id, const uint32 valid);

clx_error_no_t
hal_mt_kg_l3_adj_bcast_fdb_del(const uint32 unit, const uint32 fpu_idx);

clx_error_no_t
hal_mt_kg_l3_adj_info_with_fpu_get(const uint32 unit,
                                   const uint32 fwd_ptr,
                                   hal_l3_adj_info_t *adj_info);
/* ----------------------------------------------------------------------------------- ECMP */
clx_error_no_t
hal_mt_kg_l3_ecmp_resilient_set(const uint32 unit, const uint32 is_enable);

clx_error_no_t
hal_mt_kg_l3_ecmp_resilient_get(const uint32 unit, uint32 *is_enable);

clx_error_no_t
hal_mt_kg_l3_ecmp_algomode_set(const uint32 unit, const clx_l3_ecmp_algo_mode_t mode);

clx_error_no_t
hal_mt_kg_l3_ecmp_algomode_get(const uint32 unit, clx_l3_ecmp_algo_mode_t *mode);

clx_error_no_t
hal_mt_kg_l3_ecmp_hsh_eng_algomode_set(const uint32 unit, const clx_swc_hsh_algo_t mode);

clx_error_no_t
hal_mt_kg_l3_ecmp_hsh_eng_algomode_get(const uint32 unit, clx_swc_hsh_algo_t *mode);

clx_error_no_t
hal_mt_kg_l3_ecmp_grp_max_path_set(const uint32 unit, const uint32 num);

clx_error_no_t
hal_mt_kg_l3_ecmp_grp_max_path_get(const uint32 unit, uint32 *num);

clx_error_no_t
hal_mt_kg_l3_ecmp_per_grp_capacity_get(const uint32 unit, uint32 *num);

clx_error_no_t
hal_mt_kg_l3_ecmp_tnl_adj_id_get(const uint32 unit,
                                 const uint32 grp_id,
                                 const uint32 tnl_di,
                                 uint32 *adj_id);

clx_error_no_t
hal_mt_kg_l3_ecmp_pathidx_get_by_grpadj(const uint32 unit,
                                        const uint32 ecmp_grp_id,
                                        const uint32 adj_id,
                                        uint32 *ptr_act_list,
                                        uint32 *ptr_act_cnt,
                                        uint32 *ptr_org_list,
                                        uint32 *ptr_org_cnt);

clx_error_no_t
hal_mt_kg_l3_ecmp_tnl_di_update(const uint32 unit,
                                const uint32 ecmp_grp_id,
                                const uint32 old_tnl_di,
                                const uint32 new_tnl_di);

clx_error_no_t
hal_mt_kg_l3_mcast_lcl_set(const uint32 unit,
                           const clx_swc_cfg_t type,
                           const uint32 addr,
                           const uint32 mask);
clx_error_no_t
hal_mt_kg_l3_mcast_lcl_get(const uint32 unit, const clx_swc_cfg_t type, uint32 *addr, uint32 *mask);

clx_error_no_t
hal_mt_kg_l3_ecmp_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_kg_l3_ecmp_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_kg_l3_ecmp_grp_info_get(const uint32 unit,
                               const uint32 ecmp_grp_id,
                               hal_mt_kg_l3_ecmp_grp_t *ptr_ecmp_info);

clx_error_no_t
hal_mt_kg_l3_ecmp_ref_update(const uint32 unit, const uint32 ecmp_grp_id, const boolean inc);

/* CLX API */
clx_error_no_t
hal_mt_kg_l3_ecmp_grp_acl_bind(const uint32 unit,
                               const uint32 old_ecmp_grp_id,
                               uint32 *new_ecmp_grp_id,
                               const boolean need_alloc);

clx_error_no_t
hal_mt_kg_l3_ecmp_grp_acl_unbind(const uint32 unit,
                                 const uint32 old_ecmp_grp_id,
                                 const uint32 new_ecmp_grp_id,
                                 const boolean need_free);

clx_error_no_t
hal_mt_kg_l3_ecmp_grp_add(const uint32 unit, clx_l3_ecmp_grp_t *ptr_ecmp);

clx_error_no_t
hal_mt_kg_l3_ecmp_grp_del(const uint32 unit, const uint32 ecmp_id);

clx_error_no_t
hal_mt_kg_l3_ecmp_grp_get(const uint32 unit, clx_l3_ecmp_grp_t *ptr_ecmp);

clx_error_no_t
hal_mt_kg_l3_ecmp_grp_trav(const uint32 unit,
                           const clx_nhp_type_t type,
                           const clx_l3_ecmp_grp_trav_func_t cb,
                           void *ptr_cookie);

clx_error_no_t
hal_mt_kg_l3_ecmp_grp_sync(const uint32 unit, const uint32 ori_ecmp_id, const uint32 cur_ecmp_id);

clx_error_no_t
hal_mt_kg_l3_ecmp_path_add(const uint32 unit, const clx_l3_ecmp_path_t *ptr_path);

clx_error_no_t
hal_mt_kg_l3_ecmp_path_del(const uint32 unit, const clx_l3_ecmp_path_t *ptr_path);

clx_error_no_t
hal_mt_kg_l3_ecmp_path_get_by_idx(const uint32 unit,
                                  const uint32 path_idx,
                                  clx_l3_ecmp_path_t *ptr_path);

clx_error_no_t
hal_mt_kg_l3_ecmp_path_hsh_set(const uint32 unit, const clx_l3_ecmp_path_hsh_t *ptr_hsh_set);

clx_error_no_t
hal_mt_kg_l3_ecmp_path_hsh_get(const uint32 unit, clx_l3_ecmp_path_hsh_t *ptr_hsh_get);

clx_error_no_t
hal_mt_kg_l3_ecmp_path_list_set(const uint32 unit,
                                const boolean is_org,
                                const uint32 idx,
                                const clx_l3_ecmp_path_t *ptr_path);

clx_error_no_t
hal_mt_kg_l3_ecmp_path_list_get(const uint32 unit,
                                const boolean is_org,
                                const uint32 idx,
                                clx_l3_ecmp_path_t *ptr_path);

clx_error_no_t
hal_mt_kg_l3_ecmp_all_path_list_get(const uint32 unit, clx_l3_ecmp_all_path_t *allPatchInfo);

clx_error_no_t
hal_mt_kg_l3_ecmp_hw_to_fwd_trans(const uint32 unit, const uint32 ecmp_grp_id, uint32 *ptr_fwd_ptr);

clx_error_no_t
hal_mt_kg_l3_ecmp_hwidx_from_fwd(const uint32 unit, const uint32 ptr_fwd_ptr, uint32 *ecmp_grp_id);

clx_error_no_t
hal_mt_kg_l3_ecmp_grp_usage_get(const uint32 unit, const uint32 param, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_kg_l3_ecmp_path_usage_get(const uint32 unit, const uint32 param, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_kg_l3_ecmp_grp_capacity_get(const uint32 unit, const uint32 param, uint32 *ptr_size);

clx_error_no_t
hal_mt_kg_l3_ecmp_path_capacity_get(const uint32 unit, const uint32 param, uint32 *ptr_size);

clx_error_no_t
hal_mt_kg_l3_ecmp_swdb_dump(const uint32 unit);

clx_error_no_t
hal_mt_kg_l3_ecmp_fdl_get(const uint32 unit, clx_l3_fdl_t *ptr_fdl_info);

clx_error_no_t
hal_mt_kg_l3_ecmp_fdl_add(const uint32 unit, clx_l3_fdl_t *ptr_fdl_info);

clx_error_no_t
hal_mt_kg_l3_ecmp_fdl_del(const uint32 unit, const uint32 fdl_id);

clx_error_no_t
hal_mt_kg_l3_ecmp_ar_get(const uint32 unit, clx_l3_ar_t *ptr_ar_info);

clx_error_no_t
hal_mt_kg_l3_ecmp_ar_add(const uint32 unit, clx_l3_ar_t *ptr_ar_info);

clx_error_no_t
hal_mt_kg_l3_ecmp_ar_del(const uint32 unit, const uint32 ar_id);

clx_error_no_t
hal_mt_kg_l3_ecmp_path_hsh_calc(const uint32 unit,
                                const uint32 prof_id,
                                const clx_swc_hsh_pkt_type_t hash_type,
                                const clx_swc_flow_hsh_key_t *ptr_hash_key,
                                const uint32 ecmp_grp_id,
                                clx_l3_ecmp_path_hsh_rslt_t *ptr_rslt);

clx_error_no_t
hal_mt_kg_l3_ecmp_l2_path_dump(const uint32 unit, const clx_port_t ecmp_port);

clx_error_no_t
hal_mt_kg_l3_ecmp_path_list_dump(const uint32 unit, const uint32 ecmp_grp_id);

/* Internal API */
/* Create Group */
clx_error_no_t
hal_mt_kg_l3_ecmp_l2_grp_add(const uint32 unit,
                             clx_l2_ecmp_grp_t *ptr_ecmp,
                             clx_port_t *ptr_ecmp_port);

/* Del Group */
clx_error_no_t
hal_mt_kg_l3_ecmp_l2_grp_del(const uint32 unit, const clx_port_t ecmp_port);

/* Get Group */
clx_error_no_t
hal_mt_kg_l3_ecmp_l2_grp_get(const uint32 unit,
                             const clx_port_t ecmp_port,
                             clx_l2_ecmp_grp_t *ptr_ecmp);

/* Add path */
clx_error_no_t
hal_mt_kg_l3_ecmp_l2_path_add(const uint32 unit,
                              const clx_port_t ecmp_port,
                              const clx_l2_ecmp_path_t *ptr_ecmp_path);

/* Del path */
clx_error_no_t
hal_mt_kg_l3_ecmp_l2_path_del(const uint32 unit,
                              const clx_port_t ecmp_port,
                              const clx_l2_ecmp_path_t *ptr_ecmp_path);

/* Get path by idx */
clx_error_no_t
hal_mt_kg_l3_ecmp_l2_path_get(const uint32 unit,
                              const clx_port_t ecmp_port,
                              const uint32 path_idx,
                              clx_l2_ecmp_path_t *ptr_path);

/* Set grp hsh */
clx_error_no_t
hal_mt_kg_l3_ecmp_l2_path_hsh_set(const uint32 unit, const clx_l3_ecmp_path_hsh_t *ptr_hsh_set);

/* Get grp hsh */
clx_error_no_t
hal_mt_kg_l3_ecmp_l2_path_hsh_get(const uint32 unit, clx_l3_ecmp_path_hsh_t *ptr_hsh_get);
/* ----------------------------------------------------------------------------------- HOST */

clx_error_no_t
hal_mt_kg_l3_host_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_kg_l3_host_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_kg_l3_host_idx_get(const uint32 unit,
                          const clx_l3_addr_t *host_addr,
                          hal_l3_idx_info_t *hw_info);

clx_error_no_t
hal_mt_kg_l3_mcast_route_idx_get(const uint32 unit,
                                 const clx_l3_mcast_addr_t *mcast_addr,
                                 hal_l3_idx_info_t *hw_info);

/* CLX API */
clx_error_no_t
hal_mt_kg_l3_host_add(const uint32 unit, const clx_l3_host_t *ptr_host);

clx_error_no_t
hal_mt_kg_l3_host_del(const uint32 unit, const clx_l3_addr_t *ptr_addr);

clx_error_no_t
hal_mt_kg_l3_host_get(const uint32 unit, clx_l3_host_t *ptr_host);

clx_error_no_t
hal_mt_kg_l3_host_trav(const uint32 unit, const clx_l3_host_trav_func_t cb, void *ptr_cookie);

clx_error_no_t
hal_mt_kg_l3_host_subnet_bcast_add(const uint32 unit, const clx_l3_subnet_bcast_t *ptr_subnet);

clx_error_no_t
hal_mt_kg_l3_host_subnet_bcast_del(const uint32 unit, const clx_l3_addr_t *ptr_addr);

clx_error_no_t
hal_mt_kg_l3_host_subnet_bcast_get(const uint32 unit, clx_l3_subnet_bcast_t *ptr_subnet);

clx_error_no_t
hal_mt_kg_l3_host_subnet_bcast_trav(const uint32 unit,
                                    const clx_l3_bcast_trav_func_t cb,
                                    void *ptr_cookie);

clx_error_no_t
hal_mt_kg_l3_host_capacity_get(const uint32 unit, const uint32 param, uint32 *ptr_size);

clx_error_no_t
hal_mt_kg_l3_host_usage_get(const uint32 unit, const uint32 param, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_kg_l3_host_swdb_dump(const uint32 unit);
/* ----------------------------------------------------------------------------------- ROUTE */
clx_error_no_t
hal_mt_kg_l3_route_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_kg_l3_route_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

/* CLX API */
clx_error_no_t
hal_mt_kg_l3_route_add(const uint32 unit, const clx_l3_route_t *ptr_route);

clx_error_no_t
hal_mt_kg_l3_route_del(const uint32 unit, const clx_l3_addr_t *ptr_route_addr);

clx_error_no_t
hal_mt_kg_l3_route_get(const uint32 unit, clx_l3_route_t *ptr_route);

clx_error_no_t
hal_mt_kg_l3_route_trav(const uint32 unit, const clx_l3_route_trav_func_t cb, void *ptr_cookie);

clx_error_no_t
hal_mt_kg_l3_route_bulk_route_add(const uint32 unit,
                                  const clx_bulk_op_mode_t mode,
                                  clx_l3_bulk_route_t *ptr_bulk_route);

clx_error_no_t
hal_mt_kg_l3_route_bulk_route_del(const uint32 unit,
                                  const clx_bulk_op_mode_t mode,
                                  clx_l3_bulk_route_t *ptr_bulk_route);

clx_error_no_t
hal_mt_kg_l3_route_bulk_route_get(const uint32 unit, clx_l3_route_t *ptr_route);

clx_error_no_t
hal_mt_kg_l3_route_bulk_route_dump(const uint32 unit,
                                   const uint32 count_only,
                                   const uint32 ip_type_v4);

clx_error_no_t
hal_mt_kg_l3_route_capacity_get(const uint32 unit, const uint32 param, uint32 *ptr_size);

clx_error_no_t
hal_mt_kg_l3_route_usage_get(const uint32 unit, const uint32 param, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_kg_l3_route_swdb_dump(const uint32 unit);

clx_error_no_t
hal_mt_kg_l3_route_lpm_hash_info_get(const uint32 unit,
                                     hal_mt_kg_l3_route_lpm_hash_info_t *ptr_info);

clx_error_no_t
hal_mt_kg_l3_route_lpm_tile_type_get(const uint32 unit,
                                     const uint32 tile_idx,
                                     hal_l3_lpm_tile_type_t *ptr_type);
/* ----------------------------------------------------------------------------------- MCAST */
clx_error_no_t
hal_mt_kg_l3_mcast_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_kg_l3_mcast_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

/* MEL for VEPA */
clx_error_no_t
hal_mt_kg_l3_mcast_all_mbr_del(const uint32 unit, const uint32 mcast_id);

/* CLX API */
clx_error_no_t
hal_mt_kg_l3_mcast_grp_create(const uint32 unit, const uint32 flags, uint32 *mc_id);

clx_error_no_t
hal_mt_kg_l3_mcast_grp_destroy(const uint32 unit, const uint32 mc_id);

clx_error_no_t
hal_mt_kg_l3_mcast_port_bmp_get(const uint32 unit, const uint32 mc_id, clx_port_bitmap_t port_bmp);

clx_error_no_t
hal_mt_kg_l3_mcast_egr_intf_add(const uint32 unit, const clx_l3_mcast_egr_t *ptr_egr);

clx_error_no_t
hal_mt_kg_l3_mcast_egr_intf_del(const uint32 unit, const clx_l3_mcast_egr_t *ptr_egr);

clx_error_no_t
hal_mt_kg_l3_mcast_egr_intf_set(const uint32 unit, const clx_l3_mcast_egr_t *ptr_egr);

clx_error_no_t
hal_mt_kg_l3_mcast_egr_intf_get(const uint32 unit,
                                const uint32 mcast_id,
                                const clx_port_t port_id,
                                uint32 *ptr_cnt,
                                clx_l3_mcast_egr_intf_t *ptr_intf);

clx_error_no_t
hal_mt_kg_l3_mcast_egr_intf_cnt_get(const uint32 unit,
                                    const uint32 mcast_id,
                                    const uint32 port_id,
                                    uint32 *ptr_intf_cnt);

clx_error_no_t
hal_mt_kg_l3_mcast_fl_mbr_show(const uint32 unit, const uint32 mc_id);

clx_error_no_t
hal_mt_kg_l3_mcast_route_add(const uint32 unit, const clx_l3_mcast_route_t *ptr_mroute);

clx_error_no_t
hal_mt_kg_l3_mcast_route_del(const uint32 unit, const clx_l3_mcast_addr_t *ptr_addr);

clx_error_no_t
hal_mt_kg_l3_mcast_route_get(const uint32 unit, clx_l3_mcast_route_t *ptr_mroute);

clx_error_no_t
hal_mt_kg_l3_mcast_route_trav(const uint32 unit,
                              const clx_l3_mcast_route_trav_func_t cb,
                              void *ptr_cookie);

clx_error_no_t
hal_mt_kg_l3_mcast_df_intf_add(const uint32 unit, const clx_l3_mcast_df_intf_t *ptr_intf);

clx_error_no_t
hal_mt_kg_l3_mcast_df_intf_del(const uint32 unit, const clx_l3_mcast_df_intf_t *ptr_intf);

clx_error_no_t
hal_mt_kg_l3_mcast_df_intf_get(const uint32 unit, clx_l3_mcast_df_intf_t *ptr_intf);

clx_error_no_t
hal_mt_kg_l3_mcast_swdb_dump(const uint32 unit);

clx_error_no_t
hal_mt_kg_l3_mcast_capacity_get(const uint32 unit, const uint32 param, uint32 *size);

clx_error_no_t
hal_mt_kg_l3_mcast_usage_get(const uint32 unit, const uint32 param, uint32 *cnt);

clx_error_no_t
hal_mt_kg_l3_mcast_group_usage_get(const uint32 unit, uint32 *cnt);

boolean
hal_mt_kg_l3_mcast_src_del_chk(const uint32 unit, const clx_l3_addr_t *ptr_addr);

clx_error_no_t
hal_mt_kg_l3_mcast_lag_bmp_get(const uint32 unit, const uint32 mc_id, HAL_LAGID_BITMAP_T lagid_bmp);
/* ----------------------------------------------------------------------------------- FRR */
clx_error_no_t
hal_mt_kg_l3_frr_create(const uint32 unit, clx_l3_frr_t *ptr_frr);

clx_error_no_t
hal_mt_kg_l3_frr_destroy(const uint32 unit, const uint32 frr_id);

clx_error_no_t
hal_mt_kg_l3_frr_path_add(const uint32 unit, const clx_l3_frr_path_t *ptr_path);

clx_error_no_t
hal_mt_kg_l3_frr_path_del(const uint32 unit, const clx_l3_frr_path_t *ptr_path);

clx_error_no_t
hal_mt_kg_l3_frr_state_set(const uint32 unit, const uint32 frr_id, const boolean state);

clx_error_no_t
hal_mt_kg_l3_frr_state_get(const uint32 unit, const uint32 frr_id, boolean *ptr_state);

clx_error_no_t
hal_mt_kg_l3_frr_get(const uint32 unit, const uint32 frr_id, hal_l3_frr_t *ptr_frr);

clx_error_no_t
hal_mt_kg_l3_l2_frr_path_di_get(const uint32 unit, const uint32 frr_id, hal_l3_frr_t *ptr_path);

clx_error_no_t
hal_mt_kg_l3_hash_range_get(const uint32 unit,
                            const clx_swc_hsh_tile_type_t hsh_type,
                            uint32 *start_idx,
                            uint32 *end_idx);

clx_error_no_t
hal_mt_kg_l3_hash_scan_engine_write(const uint32 unit,
                                    const hal_mt_kg_l3_flush_cmd_hash_entry_t flush_bit_entry,
                                    const hal_mt_kg_l3_flush_cmd_hash_entry_t flush_msk_entry);

clx_error_no_t
hal_mt_kg_l3_scan_engine_action_set(const uint32 unit,
                                    const clx_swc_hsh_tile_type_t type,
                                    const uint32 param);

clx_error_no_t
hal_mt_kg_l3_hash_scan_engine_range_set(const uint32 unit,
                                        const uint32 start_idx,
                                        const uint32 end_idx);

clx_error_no_t
hal_mt_kg_l3_hash_scan_engine_trigger(const uint32 unit);

clx_error_no_t
hal_mt_kg_l3_host_flush(const uint32 unit, const clx_l3_host_t *ptr_host);

#endif /* End of HAL_MT_KG_L3_H */
