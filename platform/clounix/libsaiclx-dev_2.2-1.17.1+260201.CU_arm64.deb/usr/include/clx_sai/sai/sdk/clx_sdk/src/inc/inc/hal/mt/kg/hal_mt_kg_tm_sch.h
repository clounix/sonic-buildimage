/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_tm_sch.h
 * PURPOSE:
 *      It provides hal tm SCH module schedule block API.
 * NOTES:
 *
 *
 */

#ifndef HAL_MT_KG_TM_SCH_H
#define HAL_MT_KG_TM_SCH_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_tm.h>
#include <hal/mt/kg/hal_mt_kg_tm.h>

/* NAMING CONSTANT DECLARATIONS
 */
/*dwrr weight max*/
#define HAL_MT_KG_TM_DWRR_WEIGHT_MAX (255)

// #define HAL_MT_KG_TM_QP_NUM_PER_DIE              (828)
#define HAL_MT_KG_TM_SHAPER_PPS_PAKCET_SIZE_BYTES (5000)
#define HAL_MT_KG_TM_SHAPER_PPS_PAKCET_SIZE       (HAL_MT_KG_TM_SHAPER_PPS_PAKCET_SIZE_BYTES * 8)

#define HAL_MT_KG_TM_SHAPER_DEFUALT_ADD_TOKEN_VALUE (1)
#define HAL_MT_KG_TM_SHAPER_MAX_FRACTION            (0xFFFFFF)

#define HAL_MT_KG_TM_SHAPER_DEFUALT_MAX_BUCKET (8)
#define HAL_MT_KG_TM_QP_SHAPER_RATE            (250000000)
#define HAL_MT_KG_TM_PORT_SHAPER_RATE          (250000000)
#define HAL_MT_KG_TM_2P4T_SHAPER_RATE          (312500000)
#define HAL_MT_KG_TM_2P4T_SHAPER_FRACTION      (75000000)
#define HAL_MT_KG_TM_2P4T_PD_SCH_RATE          (2400)
#define HAL_MT_KG_TM_2P4T_MC_SCH_RATE          (2400)
#define HAL_MT_KG_TM_2T_PD_SCH_RATE           (2001)
#define HAL_MT_KG_TM_2T_MC_SCH_RATE           (2001)
#define HAL_MT_KG_TM_SHAPER_PORT_STEP_RATE     (40) // 40k
#define HAL_MT_KG_TM_SHAPER_QP_STEP_RATE       (40) // 32K

#define HAL_MT_KG_TM_RESERVED_OQ_RANGE_L (2040)
#define HAL_MT_KG_TM_RESERVED_OQ_RANGE_H (2046)

#define HAL_MT_KG_TM_SHAPER_DEFUALT_MAX_BUCKET (8) // Yv:need to check
#define HAL_MT_KG_TM_BANDWIDTH_RESET_VALUE \
    (0xFFFFFFFE)                                   // When the max bandwidth is asic initial value

/*port max speed 400G that is 400000000(kbps) in shapers*/
#define HAL_MT_KG_TM_PORT_SPEED_MAX (400000000)
#define HAL_MT_KG_TM_PORT_PPS_SPEED_MAX \
    (HAL_MT_KG_TM_PORT_SPEED_MAX / (HAL_MT_KG_TM_SHAPER_PPS_PAKCET_SIZE / 1000)) //

/*default credit size*/
#define HAL_MT_KG_TM_SCH_CREDIT_SIZE (1250) // Bytes
/*max bucket size, 32767(10 bis) * 1250(credit szie) bytes*/

#define HAL_MT_KG_TM_PORT_SPEED_TO_PORT_BANDWIDTH(val) val * 1000

#define HAL_MT_KG_TM_SCH_MAX_BUCKET_BPS (0x3FF * HAL_MT_KG_TM_SCH_CREDIT_SIZE)
#define HAL_MT_KG_TM_SCH_MAX_BUCKET_PPS \
    (HAL_MT_KG_TM_SCH_MAX_BUCKET_BPS / HAL_MT_KG_TM_SHAPER_PPS_PAKCET_SIZE_BYTES)
typedef struct hal_mt_kg_tm_sch_shaper_reg_s {
    uint32 cir_max_bucket_table_id;
    uint32 cir_add_token_value_table_id;
    uint32 cir_fraction_table_id;
    uint32 pir_max_bucket_table_id;
    uint32 pir_add_token_value_table_id;
    uint32 pir_fraction_table_id;
} hal_mt_kg_tm_sch_shaper_reg_t;

typedef struct hal_mt_kg_tm_sch_shaper_cfg_s {
    uint32 cfg_cir_shaper_max_bucket;
    uint32 cfg_cir_add_token_value;
    uint32 cfg_cir_fraction;
    uint32 cfg_pir_shaper_max_bucket;
    uint32 cfg_pir_add_token_value;
    uint32 cfg_pir_fraction;
} hal_mt_kg_tm_sch_shaper_cfg_t;

typedef struct hal_mt_kg_tm_sch_hw_idx_s {
    uint32 inst_idx;
    uint32 sub_idx;
    uint32 entry_idx;
} hal_mt_kg_tm_sch_hw_idx_t;

clx_error_no_t
hal_mt_kg_tm_sch_cfg_init(const uint32 unit);
clx_error_no_t
hal_mt_kg_tm_sch_wb_init(const uint32 unit, hal_io_wb_db_t *ptr_db);
clx_error_no_t
hal_mt_kg_tm_sch_wb_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);
clx_error_no_t
hal_mt_kg_tm_sch_speed_set(const uint32 unit, const uint32 port, const clx_port_speed_t speed);
/**
 * @brief Get min/max bandwidth of a handler.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - Egress physical port id which to be written.
 * @param [in]     handler          - The handler which the bandwidth to be got.
 * @param [out]    ptr_bandwidth    - The bandwidth of the handler.
 * @return         CLX_E_OK        - Success.
 * @return         CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_mt_kg_tm_sch_shaper_get(const uint32 unit,
                            const clx_port_t port,
                            const clx_tm_handler_t handler,
                            clx_tm_shaper_t *ptr_bandwidth);

/**
 * @brief Configure min/max bandwidth for a handler.
 *
 * If maxbandwidth is 0, sdk will configure port speed to hardware.
 * If burst size is 0, sdk will calculate burst size itself.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    port             - Egress physical port id which to be written.
 * @param [in]    handler          - The handler which the bandwidth written on.
 * @param [in]    ptr_bandwidth    - Bandwidth informations.
 * @return        CLX_E_OK        - Success.
 * @return        CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_mt_kg_tm_sch_shaper_set(const uint32 unit,
                            const clx_port_t port,
                            const clx_tm_handler_t handler,
                            const clx_tm_shaper_t *ptr_bandwidth);
/**
 * @brief Enable hqos feature of a port.
 *
 * If the port enable hqos queues, it will return CLX_E_OK.
 * Otherwiese, if there is no resouce for more hqos port,
 * it will return CLX_E_TABLE_FULL.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Egress physical port id which to be written.
 * @return        CLX_E_OK            - Success.
 * @return        CLX_E_TABLE_FULL    - Run out hqos resouce.
 */
clx_error_no_t
hal_mt_kg_tm_sch_hqos_enable_set(const uint32 unit, const uint32 port);

/**
 * @brief Disable hqos feature of a port.
 *
 * It will disable hqos of a port and return CLX_E_OK.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Egress physical port id which to be written.
 * @return        CLX_E_OK    - Success.
 */
clx_error_no_t
hal_mt_kg_tm_sch_hqos_enable_clear(const uint32 unit, const uint32 port);
/**
 * @brief Chekc if the port has hoqs queues.
 *
 * If the port has hqos queues, it will return true.
 * Otherwiese, it will return false.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Egress physical port id which to be written.
 * @param [out]    ptr_enable    - Enable/disabe hqos of the port.
 * @return         CLX_E_OK    - Success.
 */
clx_error_no_t
hal_mt_kg_tm_sch_hqos_enable_get(const uint32 unit, const clx_port_t port, boolean *ptr_enable);

/**
 * @brief Get min hqos queue's min dqc oq of a port.
 *
 * If the port has hqos queues, it will return its min dqc oq.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - Egress physical port id which to be written.
 * @param [out]    ptr_min_dqcoq    - Minimum dqc oq number.
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The port doesn't enable hqos.
 */
clx_error_no_t
hal_mt_kg_tm_sch_hqos_min_dqcoq_per_port_get(const uint32 unit,
                                             const uint32 port,
                                             uint32 *ptr_min_dqcoq);

/**
 * @brief Configure sp/dwrr weight for a handler.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Egress physical port id which to be written.
 * @param [in]     handler      - The handler which the bandwidth written on.
 * @param [out]    sched_cfg    - Parameters of scheduler.
 * @return         CLX_E_OK        - Success.
 * @return         CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_mt_kg_tm_sch_sched_mode_set(const uint32 unit,
                                const uint32 port,
                                const clx_tm_handler_t handler,
                                const clx_tm_sched_cfg_t sched_cfg);
/**
 * @brief Get sp/dwrr weight of a handler.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - Egress physical port id which to be got.
 * @param [in]     handler          - The handler which to be got.
 * @param [out]    ptr_sched_cfg    - Parameters of scheduler.
 * @return         CLX_E_OK        - Success.
 * @return         CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_mt_kg_tm_sch_sched_mode_get(const uint32 unit,
                                const uint32 port,
                                const clx_tm_handler_t handler,
                                clx_tm_sched_cfg_t *ptr_sched_cfg);

clx_error_no_t
hal_mt_kg_tm_sch_port_dflt_set(const uint32 unit, const uint32 port);
#if 0
clx_error_no_t
hal_mt_kg_tm_sch_mcq_offset_chk(const uint32 unit,
                                         const uint32 port,
                                         const uint32 handler_id,
                                         boolean *ptr_if_mcq_valid);
#endif
#endif // HAL_MT_KG_TM_SCH_H