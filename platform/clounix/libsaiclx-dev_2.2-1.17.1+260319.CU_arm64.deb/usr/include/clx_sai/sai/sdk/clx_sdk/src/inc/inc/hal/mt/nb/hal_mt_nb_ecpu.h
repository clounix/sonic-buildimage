/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_ecpu.h
 * PURPOSE:
 *  Provide HAL driver API functions of ecpu module.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NB_ECPU_H
#define HAL_MT_NB_ECPU_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_swc.h>
#include <hal/hal_ecpu.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO  DECLARATIONS
 */
#define HAL_MT_NB_ECPU_MAX_CORE       (1)
#define HAL_MT_NB_ECPU_ITCM_LOW_ADDR  (0)
#define HAL_MT_NB_ECPU_ITCM_HI_ADDR   (0x100000)
#define HAL_MT_NB_ECPU_DTCM_LOW_ADDR  (0x20000000)
#define HAL_MT_NB_ECPU_DTCM_HI_ADDR   (0x20100000)
#define HAL_MT_NB_ECPU_ITCMBASE       (0)
#define HAL_MT_NB_ECPU_DTCMBASE       (0x20000000)
#define HAL_MT_NB_ECPU_ITCMBASE_CHAIN (0x51cbc00) /*The address of ITCM on the chain*/
#define HAL_MT_NB_ECPU_DTCMBASE_CHAIN (0x52cbc00) /*The address of DTCM on the chain*/
#define HAL_MT_NB_EADDR2CHADDR(eaddr) \
    ((eaddr) - HAL_MT_NB_ECPU_DTCMBASE + HAL_MT_NB_ECPU_DTCMBASE_CHAIN)
#define HAL_MT_NB_CHADDR2EADDR(chaddr) \
    ((chaddr) - HAL_MT_NB_ECPU_DTCMBASE_CHAIN + HAL_MT_NB_ECPU_DTCMBASE)

#define HAL_MT_NB_CFG_PDMA_CH_ENABLE (0X051C1404)
/* Define elink ring buffer basic macro
 */
#define HAL_MT_NB_RING_BUFFER_BLOCK_SIZE   (1024 * 32)
#define HAL_MT_NB_RING_BUFFER_CONTROL_SIZE (1024) /*ring buffer control area size*/
#define HAL_MT_NB_RING_BUFFER_SIZE                                                             \
    (HAL_MT_NB_RING_BUFFER_BLOCK_SIZE - HAL_MT_NB_RING_BUFFER_CONTROL_SIZE) /*ring buffer data \
                                                                               area size*/
#define HAL_MT_NB_RING_BUFFER_BUFFER_SIZE (256)                             /*each buffer size*/

#define HAL_MT_NB_RING_BUFFER_OFFSET (0xf0000) /*Offset address of ring buffer in ITCM :64k*/

#define HAL_MT_NB_RING_BUFFER_TXBUFF_ADDR \
    (HAL_MT_NB_ECPU_ITCMBASE_CHAIN + HAL_MT_NB_RING_BUFFER_OFFSET)
#define HAL_MT_NB_RING_BUFFER_TXBUFF_BASE \
    (HAL_MT_NB_RING_BUFFER_TXBUFF_ADDR + HAL_MT_NB_RING_BUFFER_CONTROL_SIZE)

#define HAL_MT_NB_RING_BUFFER_RXBUFF_ADDR \
    (HAL_MT_NB_RING_BUFFER_TXBUFF_ADDR + HAL_MT_NB_RING_BUFFER_BLOCK_SIZE)
#define HAL_MT_NB_RING_BUFFER_RXBUFF_BASE \
    (HAL_MT_NB_RING_BUFFER_RXBUFF_ADDR + HAL_MT_NB_RING_BUFFER_CONTROL_SIZE)

#define HAL_MT_NB_ECPU_PORT_MIN_BANDWIDTH  0
#define HAL_MT_NB_ECPU_PORT_MIN_BURST_SIZE 0
#define HAL_MT_NB_ECPU_PORT_MAX_BANDWIDTH  5000 // pps
#define HAL_MT_NB_ECPU_PORT_MAX_BURST_SIZE 50

#define HAL_MT_NB_TM_ECPU_QUEUE_NUM                    8
#define HAL_MT_NB_TM_ECPU_MBURST_CFG_ADDR              0x000F0000 // on DTCM address
#define HAL_MT_NB_TM_ECPU_MBURST_CLEAR_WATERMARK_ADDR  0x000F0FFC
#define HAL_MT_NB_TM_ECPU_MBURST_REPORT_WATERMARK_ADDR 0x000F1000
#define HAL_MT_NB_TM_HISTOGRAM_PORT_PER_PLANE          (32)
#define HAL_MT_NB_TM_ECPU_MBURST_PORT_NUM              (256)       // 256 front ports
#define HAL_MT_NB_TM_ECPU_MBURST_QUEUE_PRE_PORT        (8)         // 8 uc queue per port

#define HAL_MT_NB_TM_ECPU_HEADROOM_CFG_ADDR             0x000FEC00 // on DTCM address
#define HAL_MT_NB_TM_ECPU_HEADROOM_CLEAR_WATERMARK_ADDR 0x000FEFFC // on DTCM address
#define HAL_MT_NB_TM_HEADROOM_COUNT_PORT_PER_PLANE      (40)
#define HAL_MT_NB_TM_ECPU_HEADROOM_QUEUE_PRE_PORT       (8)
#define HAL_MT_NB_TM_ECPU_HEADROOM_WATERMARK_ADDR       0x000FBC00
#define HAL_MT_NB_TM_ECPU_HEADROOM_COUNTER_ADDR         0x000FEFF0

#define HAL_MT_NB_ECPU_FORBID_READ_BAC_ADDR \
    (HAL_MT_NB_TM_ECPU_HEADROOM_CLEAR_WATERMARK_ADDR - sizeof(uint32)) // on DTCM address 0x200feff8
#define HAL_MT_NB_ECPU_FORBID_READ_BAC_ACK_ADDR \
    (HAL_MT_NB_ECPU_FORBID_READ_BAC_ADDR - sizeof(uint32))             // on DTCM address
#define HAL_MT_NB_ECPU_WAIT_FLAG_DONE_LOOP (5)
#define HAL_MT_NB_ECPU_RAW_CONFIG_ADDR     HAL_MT_NB_TM_ECPU_MBURST_CFG_ADDR
#define HAL_MT_NB_ECPU_RAW_CONFIG_LEN      (0x2000)

#define HAL_MT_NB_ECPU_ITCM_LEN                (0x100000)
#define HAL_MT_NB_ECPU_DTCM_LEN                (0x100000)
#define HAL_MT_NB_ECPU_SWD_CFG_DEBUG_CTL       (0x051CB828)
#define HAL_MT_NB_ECPU_SWD_CTL_HOST_SWD        (0x051CB89C)
#define HAL_MT_NB_ECPU_SWD_CTL_SW_PACKET       (0x051CB8A0)
#define HAL_MT_NB_ECPU_SWD_CFW_SW_COMMAND      (0x051CB8A4)
#define HAL_MT_NB_ECPU_SWD_CTL_SW_WDATA        (0x051CB8A8)
#define HAL_MT_NB_ECPU_SWD_SYM_SW_RDATA        (0x051CB8AC)
#define HAL_MT_NB_ECPU_SWD_SYM_SW_STATUS       (0x051CB8B4)
#define HAL_MT_NB_ECPU_SWD_STA_SW_BUSY         (0x051CB8B8)
#define HAL_MT_NB_ECPU_SWD_WAIT_FLAG_DONE_LOOP (50)

#define HAL_MT_NB_ECPU_STA_DEBUG_INFO (0x051CB82C)
/* SWD DP Register Addresses */
#define HAL_MT_NB_ECPU_SWD_DP_ADDR_0 (0x00)
#define HAL_MT_NB_ECPU_SWD_DP_ADDR_4 (0x04)
#define HAL_MT_NB_ECPU_SWD_DP_ADDR_8 (0x08)

/* SWD AP Register Addresses */
#define HAL_MT_NB_ECPU_SWD_AP_CSW (0x00)
#define HAL_MT_NB_ECPU_SWD_AP_TAR (0x04)
#define HAL_MT_NB_ECPU_SWD_AP_DRW (0x0C)
#define HAL_MT_NB_ECPU_SWD_AP_IDR (0xFC)

/* AP CSW Register Bits and Values */
#define HAL_MT_NB_ECPU_SWD_AP_CSW_BASIC_MODE  (0x03800040)
#define HAL_MT_NB_ECPU_SWD_AP_CSW_FULL_MODE   (0x4F800040)
#define HAL_MT_NB_ECPU_SWD_AP_CSW_NO_AUTO_INC (0x03000012)

/* ARM Cortex Debug Registers */
#define HAL_MT_NB_ECPU_ARM_DEMCR_ADDR  (0xE000EDFC)
#define HAL_MT_NB_ECPU_ARM_DHCSR_ADDR  (0xE000EDF0)
#define HAL_MT_NB_ECPU_ARM_DCRSR_ADDR  (0xE000EDF4)
#define HAL_MT_NB_ECPU_ARM_DCRDR_ADDR  (0xE000EDF8)
#define HAL_MT_NB_ECPU_WTD_CONFIG_ADDR (0x40000000)
#define HAL_MT_NB_ECPU_WTD_RELOAD_ADDR (0x40000004)

/* DHCSR Register Values */
#define HAL_MT_NB_ECPU_ARM_DHCSR_DBGKEY       (0xA05F0000)
#define HAL_MT_NB_ECPU_ARM_DHCSR_C_DEBUGEN    (0x00000001)
#define HAL_MT_NB_ECPU_ARM_DHCSR_C_HALT       (0x00000002)
#define HAL_MT_NB_ECPU_ARM_DHCSR_C_STEP       (0x00000004)
#define HAL_MT_NB_ECPU_ARM_DHCSR_C_MASKINTS   (0x00000008)
#define HAL_MT_NB_ECPU_ARM_DHCSR_VC_CORERESET (0x01000000)

/* DHCSR Status Bits (Read-only) */
#define HAL_MT_NB_ECPU_ARM_DHCSR_S_HALT   (0x00020000)
#define HAL_MT_NB_ECPU_ARM_DHCSR_S_REGRDY (0x00010000)

/* DCRSR Register Bits */
#define HAL_MT_NB_ECPU_ARM_DCRSR_REGWNR (0x00010000)

/* ARM Cortex-M Core Register Numbers for DCRSR */
#define HAL_MT_NB_ECPU_ARM_REG_R0        (0)
#define HAL_MT_NB_ECPU_ARM_REG_R1        (1)
#define HAL_MT_NB_ECPU_ARM_REG_R2        (2)
#define HAL_MT_NB_ECPU_ARM_REG_R3        (3)
#define HAL_MT_NB_ECPU_ARM_REG_R4        (4)
#define HAL_MT_NB_ECPU_ARM_REG_R5        (5)
#define HAL_MT_NB_ECPU_ARM_REG_R6        (6)
#define HAL_MT_NB_ECPU_ARM_REG_R7        (7)
#define HAL_MT_NB_ECPU_ARM_REG_R8        (8)
#define HAL_MT_NB_ECPU_ARM_REG_R9        (9)
#define HAL_MT_NB_ECPU_ARM_REG_R10       (10)
#define HAL_MT_NB_ECPU_ARM_REG_R11       (11)
#define HAL_MT_NB_ECPU_ARM_REG_R12       (12)
#define HAL_MT_NB_ECPU_ARM_REG_SP        (13)
#define HAL_MT_NB_ECPU_ARM_REG_LR        (14)
#define HAL_MT_NB_ECPU_ARM_REG_PC        (15)
#define HAL_MT_NB_ECPU_ARM_REG_XPSR      (16)
#define HAL_MT_NB_ECPU_ARM_REG_MSP       (17)
#define HAL_MT_NB_ECPU_ARM_REG_PSP       (18)
#define HAL_MT_NB_ECPU_ARM_REG_CONTROL   (20)
#define HAL_MT_NB_ECPU_ARM_REG_FAULTMASK (21)
#define HAL_MT_NB_ECPU_ARM_REG_BASEPRI   (22)
#define HAL_MT_NB_ECPU_ARM_REG_PRIMASK   (23)

#define HAL_MT_NB_ECPU_SWD_DEFAULT_CLOCK_FREQ_HZ (2500000)
#define HAL_MT_NB_ECPU_SWD_CLOCK_FREQ_HZ         (1000000000)
#define HAL_MT_NB_ECPU_SWD_FREQ_FACTOR           (0x20)

/*ecpu used tx/rx pdma channel and general pdma channel 8*/
#define HAL_MT_NB_ECPU_FIFORXDATA_CH 16U
#define HAL_MT_NB_ECPU_FIFOTXDATA_CH 17U
#define HAL_MT_NB_ECPU_NB2ECPU_CH    8U

/* DATA TYPE DECLARATIONS
 */

typedef struct hal_mt_nb_ecpu_mburst_cfg_s {
    uint8_t port[256];       /* Port number of mburst */
    uint32_t threshold0;     /* Threshold value of histogram sections */
    uint32_t threshold1;     /* Threshold value of histogram sections */
    uint32_t cpu_port_plane; /* CPU port plane */
    uint32_t enable;         /* Enable mburst detection */
} hal_mt_nb_ecpu_mburst_cfg_t;

typedef struct hal_mt_nb_ecpu_mburst_s {
    uint32 flag;
    uint32 high_th;
    uint32 low_th;
    boolean enable;
} hal_mt_nb_ecpu_mburst_t;
#define HAL_MT_NB_ECPU_MBURST_FLAG_SET_HIGH_TH (1 << 0)
#define HAL_MT_NB_ECPU_MBURST_FLAG_SET_LOW_TH  (1 << 1)
#define HAL_MT_NB_ECPU_MBURST_FLAG_SET_ENABLE  (1 << 2)

#pragma pack(1)
typedef struct hal_mt_nb_ecpu_mburst_event_s {
    uint64_t valid : 1;
    uint64_t type : 1;
    uint64_t port : 8;
    uint64_t event_time : 58;
    uint64_t watermark : 20;
    uint64_t watermark_time : 40;
    uint64_t queue_id : 16;
} hal_mt_nb_ecpu_mburst_event_t;

typedef struct hal_mt_nb_ecpu_swd_ctl_host_swd_s {
    uint32 host_swd_en : 1;
    uint32 nTRST_sel : 1;
    uint32 period : 8;
    uint32 rsv : 22;
} hal_mt_nb_ecpu_swd_ctl_host_swd_t;

typedef struct hal_mt_nb_ecpu_swd_ctl_sw_packet_s {
    uint32 apndp : 1;
    uint32 wrnrd : 1;
    uint32 addr3_2 : 2;
    uint32 force_data_phase : 1;
    uint32 rsv : 28;
} hal_mt_nb_ecpu_swd_ctl_sw_packet_t;

typedef enum hal_mt_nb_ecpu_swd_operation_code_e {
    HAL_MT_NB_ECPU_SWD_OPERATION_CODE_NTRST_GENERATION = 0,
    HAL_MT_NB_ECPU_SWD_OPERATION_CODE_JTAG2SWD = 1,
    HAL_MT_NB_ECPU_SWD_OPERATION_CODE_SWD_LINE_RST = 2,
    HAL_MT_NB_ECPU_SWD_OPERATION_CODE_PACKET_READ_OR_WRITE = 3,
    HAL_MT_NB_ECPU_SWD_OPERATION_CODE_LAST
} hal_mt_nb_ecpu_swd_operation_code_t;

typedef struct hal_mt_nb_ecpu_swd_cfw_sw_command_s {
    uint32 operation_code : 2;
    uint32 rsv : 30;
} hal_mt_nb_ecpu_swd_cfw_sw_command_t;

typedef struct hal_mt_nb_ecpu_swd_sym_sw_rdata_s {
    uint32 rdata : 32;
    uint32 parity : 1;
    uint32 rsv : 31;
} hal_mt_nb_ecpu_swd_sym_sw_rdata_t;

typedef struct hal_mt_nb_ecpu_swd_sym_sw_status_s {
    uint32 ack : 3;
    uint32 no_ack : 1;
    uint32 no_rdata : 1;
    uint32 parity_err : 1;
    uint32 rsv : 26;
} hal_mt_nb_ecpu_swd_sym_sw_status_t;

typedef struct hal_mt_nb_ecpu_sta_debug_info_s {
    uint32 halted : 1;
    uint32 jtagsel : 1;
    uint32 swsel : 1;
    uint32 swoactive : 1;
    uint32 traceportsize : 2;
    uint32 trcena : 1;
    uint32 dbgrestarted : 1;
    uint32 padding1 : 24;
} hal_mt_nb_ecpu_sta_debug_info_t;
#pragma pack()

typedef struct hal_mt_nb_ecpu_headroom_cfg_s {
    uint8 port[320];     /* Port number of headroom */
    uint32 enable;       /* Enable headroom statistics */
    uint32 cfg_interval; /* ms */
    uint32 tm_pool_mode; /* 0: single pool mode, 1: dual pool mode */
} hal_mt_nb_ecpu_headroom_cfg_t;

/* FUNCTION MACRO DECLARATIONS
 */
/**
 * @brief This API is used to init ecpu tx/rx hw information.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK            - Successfully.
 * @return        CLX_E_NOT_INITED    - Ecpu not started.
 * @return        CLX_E_OTHERS        - Failed to init hardware.
 */
clx_error_no_t
hal_mt_nb_ecpu_hw_init(const uint32 unit);
/**
 * @brief This API is used to reboot ecpu.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK            - Successfully.
 * @return        CLX_E_NOT_INITED    - Ecpu not started.
 * @return        CLX_E_OTHERS        - Failed to reboot.
 */
clx_error_no_t
hal_mt_nb_ecpu_reboot(const uint32 unit);

/**
 * @brief This API is used to stop the ecpu of the specified unit.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to stop ecpu.
 */
clx_error_no_t
hal_mt_nb_ecpu_force_stop(const uint32 unit);

/**
 * @brief This API is used to start the ecpu of the specified unit.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    core     - Core number.
 * @param [in]    index    - Firmware index.
 * @return        CLX_E_OK                 - Successfully.
 * @return        CLX_E_OTHERS             - Failed to start ecpu.
 * @return        CLX_E_BAD_PARAMETER      - Failed to get firmware path.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Failed to get firmware description path.
 */
clx_error_no_t
hal_mt_nb_ecpu_core_start(const uint32 unit, const uint32 core, const uint32 index);

/**
 * @brief This API is used to start the ecpu of the specified unit.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    index    - Firmware index.
 * @return        CLX_E_OK                 - Successfully.
 * @return        CLX_E_OTHERS             - Failed to start ecpu.
 * @return        CLX_E_BAD_PARAMETER      - Failed to get firmware path.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Failed to get firmware description path.
 */
clx_error_no_t
hal_mt_nb_ecpu_start(const uint32 unit, const uint32 index);

/**
 * @brief This API is used to start the ecpu of the specified unit with binary data.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    pdata    - Firmware binary data.
 * @param [in]    size     - Firmware binary data size.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to start ecpu.
 */
clx_error_no_t
hal_mt_nb_ecpu_binary_start(const uint32 unit, const void *pdata, const uint32 size);

/**
 * @brief This API is used to notify the ecpu micro burst event.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    dmsg    - Data message.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_nb_ecpu_mburst_notify_cb(uint32 unit, hal_ecpu_elink_msg_data_hdr_t *dmsg);

/**
 * @brief This API is used to stop ecpu of the specified unit.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to stop ecpu.
 */
clx_error_no_t
hal_mt_nb_ecpu_stop(const uint32 unit);

/**
 * @brief This API is used to read ecpu memory.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    addr    - Memory address.
 * @param [in]    len     - Memory length.
 * @param [in]    pbuf    - Buffer.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_OTHERS           - Failed to read memory.
 * @return        CLX_E_BAD_PARAMETER    - Parameters is invalid.
 */
clx_error_no_t
hal_mt_nb_ecpu_memory_read(const uint32 unit, const uint32 addr, const uint32 len, uint32 *pbuf);

/**
 * @brief This API is used to read ecpu memory.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    addr    - Flash address.
 * @param [in]    len     - Length.
 * @param [in]    pbuf    - Buffer.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_OTHERS           - Failed to read flash.
 * @return        CLX_E_BAD_PARAMETER    - Parameters is invalid.
 */
clx_error_no_t
hal_mt_nb_ecpu_flash_read(const uint32 unit, const uint32 addr, const uint32 len, uint32 *pbuf);

/**
 * @brief This API is used to upload fireware to ecpu sram and start ecpu.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    core    - Core number.
 * @param [in]    path    - Fireware file name.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_OTHERS           - Failed to upload fireware.
 * @return        CLX_E_BAD_PARAMETER    - Failed to open fireware file,
 *                                         maybe it doesn't exist.
 */
clx_error_no_t
hal_mt_nb_ecpu_sram_fw_update(const uint32 unit, const uint32 core, char *path);

/**
 * @brief This API is used to upload fireware to ecpu sram and start ecpu.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    core     - Core number.
 * @param [in]    pdata    - Firmware binary data.
 * @param [in]    size     - Firmware binary data size.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to upload fireware.
 */
clx_error_no_t
hal_mt_nb_ecpu_sram_fw_binary_update(const uint32 unit,
                                     const uint32 core,
                                     const void *pdata,
                                     const uint32 size);

/**
 * @brief This API is used to upload raw fireware to ecpu sram and start ecpu.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_OTHERS           - Failed to upload fireware.
 * @return        CLX_E_BAD_PARAMETER    - Failed to open fireware file,
 *                                         maybe it doesn't exist.
 */
clx_error_no_t
hal_mt_nb_ecpu_sram_raw_fw_update(const uint32 unit);

/**
 * @brief This API is used to set microburst detection configure.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    mburst_cfg    - Configure.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_OTHERS           - Ecpu not runing.
 * @return        CLX_E_BAD_PARAMETER    - Configure maybe error.
 */
clx_error_no_t
hal_mt_nb_ecpu_mburst_set(const uint32 unit, const hal_mt_nb_ecpu_mburst_t *mburst_cfg);

/**
 * @brief This API is used to set microburst detection configure.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    mburst_cfg    - Configure.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_OTHERS           - Ecpu not runing.
 * @return        CLX_E_BAD_PARAMETER    - Configure maybe error.
 */
clx_error_no_t
hal_mt_nb_ecpu_mburst_get(const uint32 unit, hal_mt_nb_ecpu_mburst_t *mburst_cfg);

/**
 * @brief This API is used to add microburst detection queue.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Port.
 * @param [in]    uc_queue    - Queue_id with 0-7.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Error with read config failed.
 */
clx_error_no_t
hal_mt_nb_ecpu_mburst_queue_add(const uint32 unit, const uint32 port, const uint32 uc_queue);

/**
 * @brief This API is used to del microburst detection queue.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Port.
 * @param [in]    uc_queue    - Queue_id with 0-7.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Error with read config failed.
 */
clx_error_no_t
hal_mt_nb_ecpu_mburst_queue_del(const uint32 unit, const uint32 port, const uint32 uc_queue);

/**
 * @brief This API is used to tell ecpu clear microburst watermark.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to stop microburst detection.
 */
clx_error_no_t
hal_mt_nb_ecpu_mburst_watermark_clear(const uint32 unit);

/**
 * @brief This API is used to register ecpu interrupt callback.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to register interrupt callback.
 */
clx_error_no_t
hal_mt_nb_ecpu_intr_register(const uint32 unit);

/**
 * @brief This API is used to unregister ecpu interrupt callback.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to register interrupt callback.
 */
clx_error_no_t
hal_mt_nb_ecpu_intr_unregister(const uint32 unit);

/**
 * @brief This API is used to trigger host to ecpu interrupt.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    core    - Core number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_nb_ecpu_intr_to_ecpu_trigger(const uint32 unit, const uint32 core);

/**
 * @brief This API is used to clear ecpu to host interrupt.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    core    - Core number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_nb_ecpu_from_ecpu_intr_clr(const uint32 unit, const uint32 core);

/**
 * @brief This API is used to enable ecpu to host interrupt.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    core    - Core number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_nb_ecpu_from_ecpu_intr_enable(const uint32 unit, const uint32 core);

/**
 * @brief This API is used to get diag log buffer information.
 *
 * @param [out]    buf_info    - Buffer information pointer.
 * @return         CLX_E_OK    - Successfully.
 */
clx_error_no_t
hal_mt_nb_ecpu_diag_log_buf_info_get(hal_ecpu_diag_buf_info_t *buf_info);

/**
 * @brief This API is used to get dtcm address.
 *
 * @param [out]    addr    - Dtcm address pointer.
 * @return         CLX_E_OK    - Successfully.
 */
clx_error_no_t
hal_mt_nb_ecpu_dtcm_addr_get(uint64 *addr);

/**
 * @brief This API is used to get dtcm on chain address.
 *
 * @param [out]    addr    - Dtcm address pointer.
 * @return         CLX_E_OK    - Successfully.
 */
clx_error_no_t
hal_mt_nb_ecpu_dtcm_on_chain_addr_get(uint64 *addr);

/**
 * @brief This API is used to get itcm address.
 *
 * @param [out]    addr    - Dtcm address pointer.
 * @return         CLX_E_OK    - Successfully.
 */
clx_error_no_t
hal_mt_nb_ecpu_itcm_addr_get(uint64 *addr);

/**
 * @brief This API is used to get itcm on chain address.
 *
 * @param [out]    addr    - Dtcm address pointer.
 * @return         CLX_E_OK    - Successfully.
 */
clx_error_no_t
hal_mt_nb_ecpu_itcm_on_chain_addr_get(uint64 *addr);

/**
 * @brief This API is used to init ecpu ring buffer tx handle.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    core    - Core number @param [inout] pbuf - Ring buffer tx handler.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
clx_error_no_t
hal_mt_nb_ecpu_ring_buf_tx_handler_init(const uint32 unit,
                                        const uint32 core,
                                        hal_ecpu_ring_buffer_control_t *pbuf);

/**
 * @brief This API is used to init ecpu ring buffer rx handle.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    core    - Core number @param [inout] pbuf - Ring buffer rx handler.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
clx_error_no_t
hal_mt_nb_ecpu_ring_buf_rx_handler_init(const uint32 unit,
                                        const uint32 core,
                                        hal_ecpu_ring_buffer_control_t *pbuf);

/**
 * @brief This API is used to set port limit.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
clx_error_no_t
hal_mt_nb_ecpu_port_limit_set(const uint32 unit);

/**
 * @brief This API is used to tell ecpu not read bac. set true to forbid read back.
 *        set false to allow read back.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    forbid    - Forbid read back.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_mt_nb_ecpu_forbid_read_bac_set(const uint32 unit, boolean forbid);
/**
 * @brief This API is used to tell ecpu clear headroom watermark.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Port number.
 * @param [in]    queue    - Queue number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_mt_nb_ecpu_headroom_watermark_clr(const uint32 unit, const uint32 port, const uint32 queue);

/**
 * @brief This API is used to check whether headroom statistics is running.
 *
 * @param [in]    unit    - Device unit number.
 * @return        TRUE     - Headroom statistics is running.
 * @return        FALSE    - Headroom statistics is not running.
 */
boolean
hal_mt_nb_ecpu_headroom_is_run(const uint32 unit);

clx_error_no_t
hal_mt_nb_ecpu_core_num_get(const uint32 unit, uint32 *pnum);

/**
 * @brief This API is used to set reset signal of the ecpu of the specified unit.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to set reset signal.
 */
clx_error_no_t
hal_mt_nb_ecpu_reset(const uint32 unit);

clx_error_no_t
hal_mt_nb_ecpu_swd_enable_set(const uint32 unit, const boolean enable);

clx_error_no_t
hal_mt_nb_ecpu_swd_wait(const uint32 unit);

clx_error_no_t
hal_mt_nb_ecpu_swd_dp_read(const uint32 unit, const uint32 address, uint32 *ptr_rdata);

clx_error_no_t
hal_mt_nb_ecpu_swd_dp_write(const uint32 unit, const uint32 address, uint32 data);

clx_error_no_t
hal_mt_nb_ecpu_swd_ap_read(const uint32 unit, const uint32 address, uint32 *ptr_rdata);

clx_error_no_t
hal_mt_nb_ecpu_swd_ap_write(const uint32 unit, const uint32 address, uint32 data);

clx_error_no_t
hal_mt_nb_ecpu_swd_clock_init(const uint32 unit);

clx_error_no_t
hal_mt_nb_ecpu_swd_target_select(const uint32 unit);

clx_error_no_t
hal_mt_nb_ecpu_swd_reset(const uint32 unit);

clx_error_no_t
hal_mt_nb_ecpu_swd_init(const uint32 unit);

clx_error_no_t
hal_mt_nb_ecpu_swd_dp_init(const uint32 unit);

clx_error_no_t
hal_mt_nb_ecpu_swd_ap_reg_read(const uint32 unit, const uint32 address, uint32 *ptr_rdata);

clx_error_no_t
hal_mt_nb_ecpu_swd_ap_reg_write(const uint32 unit, const uint32 address, uint32 data);

clx_error_no_t
hal_mt_nb_ecpu_swd_ap_init(const uint32 unit, const boolean use_full_mode);

clx_error_no_t
hal_mt_nb_ecpu_swd_debug_ctl_set(const uint32 unit, const boolean enable);

clx_error_no_t
hal_mt_nb_ecpu_swd_debug_enable(const uint32 unit);

clx_error_no_t
hal_mt_nb_ecpu_swd_debug_disable(const uint32 unit);

clx_error_no_t
hal_mt_nb_ecpu_swd_core_halt(const uint32 unit);

clx_error_no_t
hal_mt_nb_ecpu_swd_core_resume(const uint32 unit);

clx_error_no_t
hal_mt_nb_ecpu_swd_core_status_clear(const uint32 unit);

clx_error_no_t
hal_mt_nb_ecpu_swd_core_fpu_clear(const uint32 unit);

clx_error_no_t
hal_mt_nb_ecpu_swd_core_reg_write(const uint32 unit, const uint32 reg_num, const uint32 value);

clx_error_no_t
hal_mt_nb_ecpu_swd_core_reg_read(const uint32 unit, const uint32 reg_num, uint32 *ptr_value);

clx_error_no_t
hal_mt_nb_ecpu_pdma_disable(const uint32 unit);

clx_error_no_t
hal_mt_nb_ecpu_halt(const uint32 unit);

clx_error_no_t
hal_mt_nb_ecpu_core_reg_reset(const uint32 unit);

clx_error_no_t
hal_mt_nb_ecpu_sram_fw_no_reset_update(const uint32 unit, char *path);

clx_error_no_t
hal_mt_nb_ecpu_sram_fw_binary_no_reset_update(const uint32 unit,
                                              const void *pdata,
                                              const uint32 size);

clx_error_no_t
hal_mt_nb_ecpu_headroom_status_set(const uint32 unit, const boolean enable);

#endif /* #ifndef HAL_MT_NB_ECPU_H */
