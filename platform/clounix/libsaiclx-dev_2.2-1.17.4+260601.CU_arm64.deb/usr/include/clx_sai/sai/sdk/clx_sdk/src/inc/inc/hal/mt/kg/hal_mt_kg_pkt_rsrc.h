/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_pkt_rsrc.h
 * PURPOSE:
 *      It provides hal pkt module API.
 * NOTES:
 *
 */

#ifndef HAL_MT_KG_PKT_RSRC_H
#define HAL_MT_KG_PKT_RSRC_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_pkt.h>

#include <hal/hal_pkt_rsrc.h>
#include <hal/mt/hal_mt_pkt_rsrc.h>

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_mt_kg_pkt_rsrc_pp_rsn_e {
    /* PL */
    HAL_MT_KG_PKT_PP_RSN_ECC_ERR = 1,
    HAL_MT_KG_PKT_PP_RSN_IPL_ERR_FRM,
    HAL_MT_KG_PKT_PP_RSN_IPL_CRC_ERR,
    HAL_MT_KG_PKT_PP_RSN_IPL_MAX_LEN_VLT,
    HAL_MT_KG_PKT_PP_RSN_IPL_JABBER_FRM,
    HAL_MT_KG_PKT_PP_RSN_IPL_LEN_ERR,
    HAL_MT_KG_PKT_PP_RSN_IPL_CONST_SOP,
    HAL_MT_KG_PKT_PP_RSN_IPL_OVER_MTU,
    HAL_MT_KG_PKT_PP_RSN_IPL_EOP_TIME_OUT,
    HAL_MT_KG_PKT_PP_RSN_IPL_BUF_OVF,
    HAL_MT_KG_PKT_PP_RSN_LBM_FRG_DROP,
    HAL_MT_KG_PKT_PP_RSN_LBM_TRUN_ERR,
    HAL_MT_KG_PKT_PP_RSN_LBM_RECVD_ERR,

    /* TDS, 16 */
    HAL_MT_KG_PKT_PP_RSN_TDS_RSN_OFFSET = 16,
    HAL_MT_KG_PKT_PP_RSN_TDS_TUNNEL_MAC_SA = 16,
    HAL_MT_KG_PKT_PP_RSN_TDS_MTU2,
    HAL_MT_KG_PKT_PP_RSN_TDS_MTU3,
    HAL_MT_KG_PKT_PP_RSN_TDS_TNL_TTL0,
    HAL_MT_KG_PKT_PP_RSN_TDS_TNL_TTL1,
    HAL_MT_KG_PKT_PP_RSN_TDS_TNL_BAD_IP_0,
    HAL_MT_KG_PKT_PP_RSN_TDS_TNL_BAD_IP_1,
    HAL_MT_KG_PKT_PP_RSN_TDS_BDO_SPT,
    HAL_MT_KG_PKT_PP_RSN_TDS_IP_ETH_DIS,
    HAL_MT_KG_PKT_PP_RSN_TDS_IP_IP_DIS,
    HAL_MT_KG_PKT_PP_RSN_TDS_GRE_ETH_DIS,
    HAL_MT_KG_PKT_PP_RSN_TDS_GRE_IP_DIS,
    HAL_MT_KG_PKT_PP_RSN_TDS_GRE_ERSPAN_DIS,
    HAL_MT_KG_PKT_PP_RSN_TDS_VXLAN_ETH_DIS,
    HAL_MT_KG_PKT_PP_RSN_TDS_GPE_ETH_DIS,
    HAL_MT_KG_PKT_PP_RSN_TDS_GPE_IP_DIS,
    HAL_MT_KG_PKT_PP_RSN_TDS_GENEVE_ETH_DIS,
    HAL_MT_KG_PKT_PP_RSN_TDS_GENEVE_IP_DIS,
    HAL_MT_KG_PKT_PP_RSN_TDS_FLEX_ETH_DIS,
    HAL_MT_KG_PKT_PP_RSN_TDS_FLEX_IP_DIS,
    HAL_MT_KG_PKT_PP_RSN_TDS_TEP_SRC_MISS,
    HAL_MT_KG_PKT_PP_RSN_TDS_TEP_BIND,
    HAL_MT_KG_PKT_PP_RSN_TDS_ERSPAN_MISS,
    HAL_MT_KG_PKT_PP_RSN_TDS_GRE_VER,
    HAL_MT_KG_PKT_PP_RSN_TDS_GRE_FLG0,
    HAL_MT_KG_PKT_PP_RSN_TDS_GRE_FLG1,
    HAL_MT_KG_PKT_PP_RSN_TDS_GRE_FLG2,
    HAL_MT_KG_PKT_PP_RSN_TDS_GRE_FLG3,
    HAL_MT_KG_PKT_PP_RSN_TDS_BAS_ZR,
    HAL_MT_KG_PKT_PP_RSN_TDS_BAS_FLG0,
    HAL_MT_KG_PKT_PP_RSN_TDS_BAS_FLG1,
    HAL_MT_KG_PKT_PP_RSN_TDS_GPE_ZR,
    HAL_MT_KG_PKT_PP_RSN_TDS_GPE_FLG0,
    HAL_MT_KG_PKT_PP_RSN_TDS_GPE_FLG1,
    HAL_MT_KG_PKT_PP_RSN_TDS_GENEVE_VER,
    HAL_MT_KG_PKT_PP_RSN_TDS_GENEVE_O,
    HAL_MT_KG_PKT_PP_RSN_TDS_GENEVE_C,
    HAL_MT_KG_PKT_PP_RSN_TDS_FLEX_EXCPT_1,
    HAL_MT_KG_PKT_PP_RSN_TDS_FLEX_EXCPT_2,
    HAL_MT_KG_PKT_PP_RSN_TDS_FLEX_EXCPT_3,
    HAL_MT_KG_PKT_PP_RSN_TDS_FLEX_EXCPT_4,
    HAL_MT_KG_PKT_PP_RSN_TDS_FLEX_EXCPT_5,
    HAL_MT_KG_PKT_PP_RSN_TDS_FLEX_EXCPT_6,
    HAL_MT_KG_PKT_PP_RSN_TDS_FLEX_EXCPT_7,
    HAL_MT_KG_PKT_PP_RSN_TDS_FLEX_EXCPT_8,
    HAL_MT_KG_PKT_PP_RSN_TDS_FLEX_EXCPT_9,
    HAL_MT_KG_PKT_PP_RSN_TDS_FLEX_EXCPT_10,
    HAL_MT_KG_PKT_PP_RSN_TDS_FLEX_EXCPT_11,
    HAL_MT_KG_PKT_PP_RSN_TDS_FLEX_EXCPT_12,
    HAL_MT_KG_PKT_PP_RSN_TDS_FLEX_EXCPT_13,
    HAL_MT_KG_PKT_PP_RSN_TDS_FLEX_EXCPT_14,
    HAL_MT_KG_PKT_PP_RSN_TDS_FLEX_EXCPT_15,
    HAL_MT_KG_PKT_PP_RSN_TDS_MPLS_EN,
    HAL_MT_KG_PKT_PP_RSN_TDS_MPLS_LSP_RSVD0,
    HAL_MT_KG_PKT_PP_RSN_TDS_MPLS_LSP_RSVD1,
    HAL_MT_KG_PKT_PP_RSN_TDS_MPLS_LSP_RSVD2,
    HAL_MT_KG_PKT_PP_RSN_TDS_MPLS_ELI_BOS,
    HAL_MT_KG_PKT_PP_RSN_TDS_MPLS_2ND_ELI,
    HAL_MT_KG_PKT_PP_RSN_TDS_MPLS_XL_BOS,
    HAL_MT_KG_PKT_PP_RSN_TDS_MPLS_EXPOSE_TTL0,
    HAL_MT_KG_PKT_PP_RSN_TDS_MPLS_EXPOSE_TTL1,
    HAL_MT_KG_PKT_PP_RSN_TDS_MPLS_LSP_IP,
    HAL_MT_KG_PKT_PP_RSN_TDS_HSH_SRV6_FUNC_MISS,
    HAL_MT_KG_PKT_PP_RSN_TDS_SRV6_ERR_HDR,
    HAL_MT_KG_PKT_PP_RSN_TDS_SRV6_FUNC_REDIR,
    HAL_MT_KG_PKT_PP_RSN_TDS_SRV6_OAM,
    HAL_MT_KG_PKT_PP_RSN_TDS_SRV6_TLV,
    HAL_MT_KG_PKT_PP_RSN_TDS_NOR_PORT_GET_VM_PKT,
    HAL_MT_KG_PKT_PP_RSN_TDS_VM_PORT_GET_NO_VM_PKT,
    HAL_MT_KG_PKT_PP_RSN_TDS_VM_PORT_GET_WRONG_VM_PKT,
    HAL_MT_KG_PKT_PP_RSN_CIA_UDF_RSN,
    HAL_MT_KG_PKT_PP_RSN_CIA_UDF1_RSN,
    /* DIS, 96 */
    HAL_MT_KG_PKT_PP_RSN_DIS_RSN_OFFSET = 96,
    HAL_MT_KG_PKT_PP_RSN_DIS_SRV6_USP_SL0 = 96,
    HAL_MT_KG_PKT_PP_RSN_DIS_SRV6_SL0,
    HAL_MT_KG_PKT_PP_RSN_DIS_SRV6_DECAP_SL_NON_ZERO,
    HAL_MT_KG_PKT_PP_RSN_DIS_SRV6_NXTUSID0,
    HAL_MT_KG_PKT_PP_RSN_DIS_SRV6_NXTCSID0,
    HAL_MT_KG_PKT_PP_RSN_DIS_SRV6_DECAP_USID_NON_ZERO,
    HAL_MT_KG_PKT_PP_RSN_DIS_SRV6_DECAP_INNER_UNK,
    HAL_MT_KG_PKT_PP_RSN_DIS_SRV6_USP_SL0_TWO_SRH,
    HAL_MT_KG_PKT_PP_RSN_DIS_SRV6_USP_NO_SRH,
    HAL_MT_KG_PKT_PP_RSN_DIS_SRV6_RSVD_END_BEH_CODE,
    HAL_MT_KG_PKT_PP_RSN_DIS_PSR_PKT_INC,
    HAL_MT_KG_PKT_PP_RSN_DIS_TNL_AUTO_IP,
    HAL_MT_KG_PKT_PP_RSN_DIS_TNL_ISATAP_IP,
    HAL_MT_KG_PKT_PP_RSN_DIS_BDI_HSH_MISS,
    HAL_MT_KG_PKT_PP_RSN_DIS_BDI_IDX_INVALID,
    HAL_MT_KG_PKT_PP_RSN_DIS_VLAN_MBR,
    HAL_MT_KG_PKT_PP_RSN_DIS_DOT1X_PORT_BASED,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRIO_TAG,
    HAL_MT_KG_PKT_PP_RSN_DIS_LCL_DROP_PKT_UNTAGGED,
    HAL_MT_KG_PKT_PP_RSN_DIS_LCL_DROP_PKT_TAGGED,
    HAL_MT_KG_PKT_PP_RSN_DIS_LCL_DROP_PKT_TAGGED_EXCPT_DEFAULT,
    HAL_MT_KG_PKT_PP_RSN_DIS_PSR_PKT_BAD_IP,
    HAL_MT_KG_PKT_PP_RSN_DIS_MPLS_DECAP_BOS,
    HAL_MT_KG_PKT_PP_RSN_DIS_MPLS_PW_CW,
    HAL_MT_KG_PKT_PP_RSN_DIS_MPLS_PW_ACH,
    HAL_MT_KG_PKT_PP_RSN_DIS_MPLS_PW_UNK,
    HAL_MT_KG_PKT_PP_RSN_DIS_MPLS_L3VPN_IP,
    HAL_MT_KG_PKT_PP_RSN_DIS_IGMP_SNOOPING,
    HAL_MT_KG_PKT_PP_RSN_DIS_MLD_SNOOPING,
    HAL_MT_KG_PKT_PP_RSN_DIS_SRV6_ERR_HDR,
    HAL_MT_KG_PKT_PP_RSN_DIS_TNL_ECN_1,
    HAL_MT_KG_PKT_PP_RSN_DIS_TNL_ECN_2,
    HAL_MT_KG_PKT_PP_RSN_DIS_TNL_ECN_3,
    HAL_MT_KG_PKT_PP_RSN_DIS_DOS_CHK,
    HAL_MT_KG_PKT_PP_RSN_DIS_BDI_SPT,
    HAL_MT_KG_PKT_PP_RSN_DIS_IPV4_SRC_GUARD,
    HAL_MT_KG_PKT_PP_RSN_DIS_IPV6_SRC_GUARD,
    HAL_MT_KG_PKT_PP_RSN_DIS_IPV4_MAC_DA_MC_MAPPING_MISMATCH,
    HAL_MT_KG_PKT_PP_RSN_DIS_IPV6_MAC_DA_MC_MAPPING_MISMATCH,
    HAL_MT_KG_PKT_PP_RSN_DIS_IP_MC_LCL,
    HAL_MT_KG_PKT_PP_RSN_DIS_L3VPN_BUT_NO_L3_SERVICE,
    HAL_MT_KG_PKT_PP_RSN_DIS_L3PORT_GET_IP_UC_PKT_BUT_RMAC_FAIL,
    HAL_MT_KG_PKT_PP_RSN_DIS_L3PORT_GET_IP_UC_PKT_BUT_IP_UC_NOT_EN,
    HAL_MT_KG_PKT_PP_RSN_DIS_L3PORT_GET_IP_MC_PKT_BUT_IP_MC_NOT_EN,
    HAL_MT_KG_PKT_PP_RSN_DIS_L3PORT_GET_NON_IP_PKT,
    HAL_MT_KG_PKT_PP_RSN_DIS_RMAC_HIT_BUT_NON_L3_FWD,
    HAL_MT_KG_PKT_PP_RSN_DIS_UNEXPECTED_LKUP_TYPE,
    HAL_MT_KG_PKT_PP_RSN_DIS_SRV6_L2_FWD_IS_L3_IF,
    HAL_MT_KG_PKT_PP_RSN_DIS_L2MTU,
    HAL_MT_KG_PKT_PP_RSN_DIS_L3MTU = 159,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_OFFSET = HAL_MT_KG_PKT_PP_RSN_DIS_L3MTU + 1,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_0 = HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_OFFSET,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_1,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_2,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_3,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_4,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_5,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_6,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_7,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_8,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_9,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_10,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_11,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_12,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_13,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_14,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_15,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_16,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_17,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_18,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_19,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_20,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_21,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_22,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_23,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_24,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_25,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_26,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_27,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_28,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_29,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_30,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_31,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_32,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_33,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_34,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_35,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_36,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_37,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_38,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_39,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_40,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_41,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_42,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_43,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_44,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_45,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_46,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_47,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_48,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_49,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_50,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_51,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_52,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_53,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_54,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_55,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_56,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_57,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_58,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_59,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_60,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_61,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_62,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_63,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_64,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_65,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_66,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_67,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_68,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_69,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_70,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_71,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_72,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_73,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_74,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_75,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_76,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_77,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_78,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_79,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_80,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_81,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_82,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_83,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_84,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_85,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_86,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_87,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_88,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_89,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_90,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_91,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_92,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_93,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_94,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_95,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_96,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_97,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_98,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_99,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_100,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_101,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_102,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_103,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_104,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_105,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_106,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_107,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_108,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_109,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_110,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_111,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_112,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_113,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_114,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_115,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_116,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_117,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_118,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_119,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_120,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_121,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_122,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_123,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_124,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_125,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_126,
    HAL_MT_KG_PKT_PP_RSN_DIS_PRECIA_UULM_127,
    /* FPU, 288 */
    HAL_MT_KG_PKT_PP_RSN_FPU_RSN_OFFSET = 288,
    HAL_MT_KG_PKT_PP_RSN_FPU_L3MC_SPT_RDY_SET_1 = 288,
    HAL_MT_KG_PKT_PP_RSN_FPU_L3MC_PIM_REGISTER,
    HAL_MT_KG_PKT_PP_RSN_FPU_L3MC_C2C,
    HAL_MT_KG_PKT_PP_RSN_FPU_GLEAN_ADJ,
    HAL_MT_KG_PKT_PP_RSN_FPU_L2UC_DA_MISS,
    HAL_MT_KG_PKT_PP_RSN_FPU_L2MC_DA_MISS,
    HAL_MT_KG_PKT_PP_RSN_FPU_L3UC_IPV4_DIP_MISS,
    HAL_MT_KG_PKT_PP_RSN_FPU_L3MC_IPV4_DIP_MISS,
    HAL_MT_KG_PKT_PP_RSN_FPU_L3UC_IPV6_DIP_MISS,
    HAL_MT_KG_PKT_PP_RSN_FPU_L3MC_IPV6_DIP_MISS,
    HAL_MT_KG_PKT_PP_RSN_FPU_L3UC_RPF_FAIL_DROP,
    HAL_MT_KG_PKT_PP_RSN_FPU_L3UC_RPF_FAIL_REDIR,
    HAL_MT_KG_PKT_PP_RSN_FPU_L3MC_RPF_FAIL_DROP,
    HAL_MT_KG_PKT_PP_RSN_FPU_L3MC_RPF_FAIL_REDIR,
    HAL_MT_KG_PKT_PP_RSN_FPU_L3MC_RPF_FAIL_CANT_FALL_BACK_L2,
    HAL_MT_KG_PKT_PP_RSN_FPU_L3UC_ICMP_REDIR,
    HAL_MT_KG_PKT_PP_RSN_FPU_L3UC_NO_FWD_PTR,
    HAL_MT_KG_PKT_PP_RSN_FPU_L3UC_NO_AFIB_RSLT_PTR,
    HAL_MT_KG_PKT_PP_RSN_FPU_L25MPLS_TRANSIT_LBL_MISS,
    HAL_MT_KG_PKT_PP_RSN_FPU_ECMPGRP_ZERO_NUM_PATH,
    HAL_MT_KG_PKT_PP_RSN_FPU_ECMPMBR_INVALID,
    HAL_MT_KG_PKT_PP_RSN_FPU_L2_SA_HIT_BUT_INVALID_IDX,
    HAL_MT_KG_PKT_PP_RSN_FPU_L2_SA_MOVE,
    HAL_MT_KG_PKT_PP_RSN_FPU_L2_SA_MISS_0,
    HAL_MT_KG_PKT_PP_RSN_FPU_L2_SA_MISS_1,
    HAL_MT_KG_PKT_PP_RSN_FPU_L2_SA_FWD_MAC_BD_MISMATCH,
    HAL_MT_KG_PKT_PP_RSN_FPU_L2ECMP_MISS,
    HAL_MT_KG_PKT_PP_RSN_FPU_DVIF_MISS,
    HAL_MT_KG_PKT_PP_RSN_FPU_BUM_DISABLE,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_0,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_1,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_2,
    /* ICIA, 320 */
    HAL_MT_KG_PKT_PP_RSN_ICIA_RSN_OFFSET = 320,
    HAL_MT_KG_PKT_PP_RSN_ICIA_POLICE_RED_EXCPT = 320,
    HAL_MT_KG_PKT_PP_RSN_ICIA_ACTION_SUP_CPU,
    HAL_MT_KG_PKT_PP_RSN_ICIA_ACTION_SUP_DROP,
    HAL_MT_KG_PKT_PP_RSN_ICIA_STORM_RED_EXCPT,
    HAL_MT_KG_PKT_PP_RSN_ICIA_INT_SOURCE_RCV_INT_ENCAP,
    HAL_MT_KG_PKT_PP_RSN_ICIA_ECMPGRP_ZERO_NUM_PATH,
    HAL_MT_KG_PKT_PP_RSN_ICIA_ECMPMBR_INVALID,
    HAL_MT_KG_PKT_PP_RSN_ICIA_NFS_PROFILE_0,
    HAL_MT_KG_PKT_PP_RSN_ICIA_NFS_PROFILE_1,
    HAL_MT_KG_PKT_PP_RSN_ICIA_NFS_PROFILE_2,
    HAL_MT_KG_PKT_PP_RSN_ICIA_NFS_PROFILE_3,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_3,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_4,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_5,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_6,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_7,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_8,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_9,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_10,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_11,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_12,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_13,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_14,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_15,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_16,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_17,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_18,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_19,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_20,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_21,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_22,
    /* FWR, 352 */
    HAL_MT_KG_PKT_PP_RSN_FWR_RSN_OFFSET = 352,
    HAL_MT_KG_PKT_PP_RSN_FWR_SFLOW_SAMPLER = 352,
    HAL_MT_KG_PKT_PP_RSN_FWR_L2_UC_SOURCE_PRUNING,
    HAL_MT_KG_PKT_PP_RSN_FWR_L3_UC_SOURCE_PRUNING,
    HAL_MT_KG_PKT_PP_RSN_FWR_UC_UL2UL_PRUNING,
    HAL_MT_KG_PKT_PP_RSN_FWR_TNL_IDX_IN_LAT_MODE,
    HAL_MT_KG_PKT_PP_RSN_FWR_IP_TTL0,
    HAL_MT_KG_PKT_PP_RSN_FWR_IP_TTL1,
    HAL_MT_KG_PKT_PP_RSN_FWR_IPV4_OPTION_EXIST_FWD,
    HAL_MT_KG_PKT_PP_RSN_FWR_IPV6_NHDR_SW_FWD,
    HAL_MT_KG_PKT_PP_RSN_FWR_TNL_ECMPGRP_ZERO_NUM_PATH,
    HAL_MT_KG_PKT_PP_RSN_FWR_TNL_ECMPMBR_INVALID,
    HAL_MT_KG_PKT_PP_RSN_FWR_TELM_OVER_UNSUPPORTED_TYPE,
    HAL_MT_KG_PKT_PP_RSN_FWR_DI_TO_CPU_ENTRY_0,
    HAL_MT_KG_PKT_PP_RSN_FWR_DI_TO_CPU_ENTRY_1,
    HAL_MT_KG_PKT_PP_RSN_FWR_DI_TO_CPU_ENTRY_2,
    HAL_MT_KG_PKT_PP_RSN_FWR_DI_TO_CPU_ENTRY_3,
    HAL_MT_KG_PKT_PP_RSN_FWR_DI_TO_CPU_ENTRY_4,
    HAL_MT_KG_PKT_PP_RSN_FWR_DI_TO_CPU_ENTRY_5,
    HAL_MT_KG_PKT_PP_RSN_FWR_DI_TO_CPU_ENTRY_6,
    HAL_MT_KG_PKT_PP_RSN_FWR_DI_TO_CPU_ENTRY_7,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_23,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_24,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_25,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_26,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_27,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_28,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_29,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_30,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_31,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_32,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_33,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_34,
    /* RWI, 384 */
    HAL_MT_KG_PKT_PP_RSN_RWI_RSN_OFFSET = 384,
    HAL_MT_KG_PKT_PP_RSN_RWI_TM_ERR = 384,
    HAL_MT_KG_PKT_PP_RSN_RWI_EVPN_ESI_FLITER,
    HAL_MT_KG_PKT_PP_RSN_RWI_EVPN_DF_FLITER,
    HAL_MT_KG_PKT_PP_RSN_RWI_VLAN_HSH_MISS,
    HAL_MT_KG_PKT_PP_RSN_RWI_MCG_VIF_HSH_MISS,
    HAL_MT_KG_PKT_PP_RSN_RWI_L2MTU,
    HAL_MT_KG_PKT_PP_RSN_RWI_L3MTU,
    HAL_MT_KG_PKT_PP_RSN_RWI_BDI_SPT,
    HAL_MT_KG_PKT_PP_RSN_RWI_DOT1X_PORT_BASED,
    HAL_MT_KG_PKT_PP_RSN_RWI_SUPP_TAG,
    HAL_MT_KG_PKT_PP_RSN_RWI_INT_OVER_UNSUPPORTED_TYPE,
    HAL_MT_KG_PKT_PP_RSN_RWI_L2_MC_SOURCE_PRUNING,
    HAL_MT_KG_PKT_PP_RSN_RWI_L3_MC_SOURCE_PRUNING,
    HAL_MT_KG_PKT_PP_RSN_RWI_MC_UL2UL_PRUNING,
    HAL_MT_KG_PKT_PP_RSN_RWI_MC_L3VPN_PRUNING,
    HAL_MT_KG_PKT_PP_RSN_RWI_IOAM_OVER_UNSUPPORTED_TYPE,
    HAL_MT_KG_PKT_PP_RSN_RWI_INT_REPORT_REC,
    HAL_MT_KG_PKT_PP_RSN_RWI_INT_MTU_EXCEED,
    HAL_MT_KG_PKT_PP_RSN_RWI_INT_META_INCOMP,
    HAL_MT_KG_PKT_PP_RSN_RWI_TELM_NONEXIST_DECAP,
    HAL_MT_KG_PKT_PP_RSN_RWI_TELM_NONEXIST_ENCAP,
    HAL_MT_KG_PKT_PP_RSN_RWI_IFA_HOP_LIMIT_0,
    HAL_MT_KG_PKT_PP_RSN_RWI_POST_SMALL_PKT,
    HAL_MT_KG_PKT_PP_RSN_RWI_INC_OVERFLOW,
    HAL_MT_KG_PKT_PP_RSN_RWI_SFLOW_LOW_LATENCY_SAMPLER,
    HAL_MT_KG_PKT_PP_RSN_RWI_INVALID_INST,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_35,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_36,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_37,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_38,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_39,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_40,
    /* ECIA, 416 */
    HAL_MT_KG_PKT_PP_RSN_ECIA_RSN_OFFSET = 416,
    HAL_MT_KG_PKT_PP_RSN_ECIA_ACTION_SUP_CPU = 416,
    HAL_MT_KG_PKT_PP_RSN_ECIA_ACTION_SUP_DROP,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_41,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_42,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_43,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_44,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_45,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_46,
    HAL_MT_KG_PKT_PP_RSN_CIA_COPY_RSN_47,
    /* RWO, 448 */
    HAL_MT_KG_PKT_PP_RSN_RWO_RSN_OFFSET = 448,
    HAL_MT_KG_PKT_PP_RSN_RWO_SFLOW_SAMPLER = 448,
    HAL_MT_KG_PKT_PP_RSN_RWO_STACKING_UC_TTL,
    HAL_MT_KG_PKT_PP_RSN_RWO_STACKING_MC_BREAK,
    HAL_MT_KG_PKT_PP_RSN_RWO_INT_OVER_VXLAN_BASE,
    HAL_MT_KG_PKT_PP_RSN_RWO_INT_OVER_UNSUPPORTED_TNL,
    HAL_MT_KG_PKT_PP_RSN_RWO_IOAM_OVER_UNSUPPORTED_TNL,
    HAL_MT_KG_PKT_PP_RSN_RWO_L3MTU,
    HAL_MT_KG_PKT_PP_RSN_RWO_MPLS_PHP_BOS_ETH,
    HAL_MT_KG_PKT_PP_RSN_RWO_POST_SMALL_PKT,
    HAL_MT_KG_PKT_PP_RSN_RWO_HDC_VAL,
    HAL_MT_KG_PKT_PP_RSN_RWO_INC_OVERFLOW,
    HAL_MT_KG_PKT_PP_RSN_RWO_FDL_STA_HI_BCONT_IS_SMALLER_THAN_LO,
    HAL_MT_KG_PKT_PP_RSN_LAST = 478, // 512, GT than 478 for TM

    /* TM */
    HAL_MT_KG_PKT_PP_RSN_TM_RSVD_BEGIN = 479,
    HAL_MT_KG_PKT_PP_RSN_PDB_WR_ERR = 480,
    HAL_MT_KG_PKT_PP_RSN_ASM_PKTSZ_ERR = 481,
    HAL_MT_KG_PKT_PP_RSN_REP_MC_CONGEST = 482,
    HAL_MT_KG_PKT_PP_RSN_REP_MC_MBR_DROP = 483,
    HAL_MT_KG_PKT_PP_RSN_REP_DELETE_PORT = 484,
    HAL_MT_KG_PKT_PP_RSN_REP_CHASSIS_PRUN = 485,
    HAL_MT_KG_PKT_PP_RSN_REP_INT_PRUN = 486,
    HAL_MT_KG_PKT_PP_RSN_REP_BLACKHOLE_DI = 487,
    HAL_MT_KG_PKT_PP_RSN_REP_OUTRANGE_DI = 488,
    HAL_MT_KG_PKT_PP_RSN_REP_LAG_SIZE_ERR = 489,
    HAL_MT_KG_PKT_PP_RSN_REP_FL_SIZE_ERR = 490,
    HAL_MT_KG_PKT_PP_RSN_REP_BYPASS_DI = 491,
    HAL_MT_KG_PKT_PP_RSN_REP_STACKING_FL_DOWN = 492,
    HAL_MT_KG_PKT_PP_RSN_REP_FAILOVER_PORT_DOWN = 493,
    HAL_MT_KG_PKT_PP_RSN_REP_LAG_BYPASS_ERR = 494,
    HAL_MT_KG_PKT_PP_RSN_REP_AR_LAG_PORT_MAP_ERR = 495,
    HAL_MT_KG_PKT_PP_RSN_BAC_IN_SPORT_ERR = 496,
    HAL_MT_KG_PKT_PP_RSN_BAC_IN_CODE_ERR = 497,
    HAL_MT_KG_PKT_PP_RSN_BAC_IN_OQ_ERR = 498,
    HAL_MT_KG_PKT_PP_RSN_BAC_SRC_CONGEST = 499,
    HAL_MT_KG_PKT_PP_RSN_BAC_DST_CONGEST = 500,
    HAL_MT_KG_PKT_PP_RSN_OQ_ENQ_FAIL = 501,
    HAL_MT_KG_PKT_PP_RSN_TM_RSVD_END = 511,

    /* MOD to cpu reason */
    HAL_MT_KG_PKT_PP_RSN_MOD = 511, // This is not hw reason, just for internal use
} hal_mt_kg_pkt_rsrc_pp_rsn_t;

typedef struct hal_mt_kg_pkt_rsrc_pp_rsn_map_s {
    hal_mt_kg_pkt_rsrc_pp_rsn_t pp_rsn_code;
    char str_pp_rsn[HAL_PKT_PP_RSN_STR_LEN];
    clx_pkt_rx_reason_t rsn_code;
    char str_rsn[HAL_PKT_RSN_STR_LEN];
    clx_pkt_drop_reason_t drop_reason;
} hal_mt_kg_pkt_rsrc_pp_rsn_map_t;

/* EXPORTED SUBPROGRAM BODIES
 */
/**
 * @brief To translate the reason from user-view to chip-view.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     rsn_code      - The user-view reason.
 * @param [out]    pp_rsn_bmp    - Pointer to the chip-view reason.
 * @return         CLX_E_OK               - Success to translate the reason.
 * @return         CLX_E_BAD_PARAMETER    - User-view reason does not match chip-view reason.
 */
clx_error_no_t
hal_mt_kg_pkt_rsrc_usr_to_pp_rsn_get(const uint32 unit,
                                     const clx_pkt_rx_reason_t rsn_code,
                                     hal_mt_pkt_pp_rsn_bmp_t pp_rsn_bmp);

/**
 * @brief To translate the reason from chip-view to user-view.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     pp_rsn_bmp      - The chip-view reason.
 * @param [out]    ptr_rsn_code    - Pointer to the user-view reason.
 * @return         CLX_E_OK               - Success to translate the reason.
 * @return         CLX_E_BAD_PARAMETER    - Chip-view reason does not match User-view reason.
 */
clx_error_no_t
hal_mt_kg_pkt_rsrc_pp_to_user_rsn_get(const uint32 unit,
                                      const hal_mt_pkt_pp_rsn_bmp_t pp_rsn_bmp,
                                      clx_pkt_rx_reason_t *ptr_rsn_code);

/**
 * @brief To translate the reason bitmap from chip-view to user-view.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     pp_reason_bitmap    - The chip-view reason.
 * @param [out]    rx_reason_bitmap    - Pointer to the user-view reason.
 * @return         CLX_E_OK               - Success to translate the reason.
 * @return         CLX_E_BAD_PARAMETER    - Chip-view reason does not match User-view reason.
 */
clx_error_no_t
hal_mt_kg_pkt_rsrc_pp_to_user_rsn_bmp_get(const uint32 unit,
                                          const hal_mt_pkt_pp_rsn_bmp_t pp_reason_bitmap,
                                          clx_pkt_rx_rsn_bmp_t rx_reason_bitmap);

/**
 * @brief To map the reason from user reason bitmap to HW EPP exception bitmap.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     user_bitmap    - The user reason bitmap.
 * @param [out]    hw_bitmap      - The HW reason bitmap.
 * @return         CLX_E_OK        - Success to map the reason.
 * @return         CLX_E_OTHERS    - Fail to map the reason.
 */
clx_error_no_t
hal_mt_kg_pkt_rsrc_user_bmp_to_pp_bmp_convert(const uint32 unit,
                                              const clx_pkt_rx_rsn_bmp_t user_bitmap,
                                              hal_mt_pkt_pp_rsn_bmp_t hw_bitmap);

/**
 * @brief To map the reason from user reason bitmap to HW EPP exception bitmap.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     hw_bitmap      - The HW reason bitmap.
 * @param [out]    user_bitmap    - The user reason bitmap.
 * @return         CLX_E_OK        - Success to map the reason.
 * @return         CLX_E_OTHERS    - Fail to map the reason.
 */
clx_error_no_t
hal_mt_kg_pkt_rsrc_pp_bmp_to_user_bmp_convert(const uint32 unit,
                                              hal_mt_pkt_pp_rsn_bmp_t hw_bitmap,
                                              clx_pkt_rx_rsn_bmp_t user_bitmap);

/**
 * @brief To map the reason from HW CPU reason to HW EPP exception bitmap.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     cpu_reason     - The user reason bitmap.
 * @param [out]    user_bitmap    - The HW reason bitmap.
 * @return         CLX_E_OK        - Success to map the reason.
 * @return         CLX_E_OTHERS    - Fail to map the reason.
 */
clx_error_no_t
hal_mt_kg_pkt_rsrc_pp_to_user_bmp_convert(const uint32 unit,
                                          const uint32 cpu_reason,
                                          clx_pkt_rx_rsn_bmp_t user_bitmap);

/**
 * @brief To translate reason code to string.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     rsn_code    - The reason code.
 * @param [in]     str_len     - String length.
 * @param [out]    str_rsn     - The reason string.
 * @return         CLX_E_OK                 - Success to translate the reason.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Reason code does not match.
 */
clx_error_no_t
hal_mt_kg_pkt_rsrc_rsn_str_get(const uint32 unit,
                               const clx_pkt_rx_reason_t rsn_code,
                               const uint32 str_len,
                               char *str_rsn);

/**
 * @brief To translate chip-view PP reasons to string.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     pp_rsn_code    - The PP reason code.
 * @param [in]     str_len        - String length.
 * @param [out]    str_pp_rsn     - The PP reason code string.
 * @return         CLX_E_OK                 - Success to translate the reason.
 * @return         CLX_E_BAD_PARAMETER      - PP reason out of range.
 * @return         CLX_E_ENTRY_NOT_FOUND    - PP reason does not match.
 */
clx_error_no_t
hal_mt_kg_pkt_rsrc_pp_rsn_str_get(const uint32 unit,
                                  const hal_mt_kg_pkt_rsrc_pp_rsn_t pp_rsn_code,
                                  const uint32 str_len,
                                  char *str_pp_rsn);

/**
 * @brief To translate reason string to reason code.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     str_rsn     - The reason string.
 * @param [out]    rsn_code    - The reason code.
 * @return         CLX_E_OK                 - Success to translate the reason.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Reason string does not match.
 */
clx_error_no_t
hal_mt_kg_pkt_rsrc_rsn_code_get(const uint32 unit,
                                const char *str_rsn,
                                clx_pkt_rx_reason_t *rsn_code);

/**
 * @brief To translate PP reason string to PP reason code.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     str_pp_rsn     - The PP reason string.
 * @param [out]    pp_rsn_code    - The PP reason code.
 * @return         CLX_E_OK                 - Success to translate the reason.
 * @return         CLX_E_ENTRY_NOT_FOUND    - RX reason string does not match.
 */
clx_error_no_t
hal_mt_kg_pkt_rsrc_pp_rsn_code_get(const uint32 unit,
                                   const char *str_pp_rsn,
                                   hal_mt_kg_pkt_rsrc_pp_rsn_t *pp_rsn_code);

clx_error_no_t
hal_mt_kg_pkt_rsrc_drp_to_pp_rsn_get(const uint32 unit,
                                     const clx_pkt_drop_reason_t drp_code,
                                     hal_mt_pkt_pp_rsn_bmp_t pp_rsn_bmp);

/**
 * @brief To translate the reason from chip-view to drop reason.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     pp_rsn_code     - PP reason code.
 * @param [out]    ptr_drp_code    - Pointer to the drop reason code.
 * @return         CLX_E_OK               - Success to translate the reason.
 * @return         CLX_E_BAD_PARAMETER    - PP reason code does not match drop reason.
 */
clx_error_no_t
hal_mt_kg_pkt_rsrc_pp_to_drp_rsn_get(const uint32 unit,
                                     const hal_mt_kg_pkt_rsrc_pp_rsn_t pp_rsn_code,
                                     clx_pkt_drop_reason_t *ptr_drp_code);

#endif /* End of HAL_VLAN_H */
