/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  drv_kg_io.h
 * PURPOSE:
 *  1. Provide the IO channel access interface to chip Device Control Command(DRV_MT).
 *  2. Define DRV_MT IO channel related structures.
 *
 * NOTES:
 *
 */

#ifndef DRV_KG_IO_H
#define DRV_KG_IO_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <osal/osal.h>
#include <clx/clx_init.h>
#include <drv/drv_io.h>
#include <drv/mt/drv_mt_io.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define DRV_IO_KG_BROADCAST_ADDR                (0x4000000)
#define DRV_IO_KG_BROADCAST_ECPU_REP_NUM_ADDR   (0x00040040)
#define DRV_IO_KG_BROADCAST_ECPU_ADDR_STEP_ADDR (0x0004003C)
#define DRV_IO_KG_BROADCAST_PDMA_REP_NUM_ADDR   (0x00040040)
#define DRV_IO_KG_BROADCAST_PDMA_ADDR_STEP_ADDR (0x00040044)
#define DRV_IO_KG_BROADCAST_CMST_REP_NUM_ADDR   (0x00040048)
#define DRV_IO_KG_BROADCAST_CMST_ADDR_STEP_ADDR (0x0004004C)

#define DRV_MT_IO_KG_IND_FPU_HSH_LPM_CMD_REG_WORD_SIZE     (2)
#define DRV_MT_IO_KG_IND_FPU_HASH_LPM_STATUS_REG_WORD_SIZE (21)
#define DRV_MT_IO_KG_IND_FPU_HASH_STATUS_REG_WORD_SIZE     (16)

#pragma pack(push, 1)
#if defined(CLX_EN_BIG_ENDIAN)
typedef union drv_kg_io_reg_cpu_hit_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    union {
        struct fpu_field {
            uint32 : 8;
            uint32 cpu_hit_ind_addr : 20;
            uint32 sel_hsh_or_tcam : 1;
            uint32 cpu_hit_ind_cmd : 3;
        } fpu_field;
        struct tcam_field {
            uint32 : 12;
            uint32 cpu_hit_ind_addr : 16;
            uint32 sel_lpm_or_tcam : 1;
            uint32 cpu_hit_ind_cmd : 3;
        } tcam_field;
    } field;
} drv_kg_io_reg_cpu_hit_cmd_reg_t;

/* tile_hsh_ind_addr */
typedef union drv_kg_io_reg_hash_ind_addr_reg_u {
    uint32 reg[DRV_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 : 12;
        uint32 ind_addr : 20;
    } field;
} drv_kg_io_reg_hash_ind_addr_reg_t;

typedef union drv_kg_io_reg_fpu_hash_stat_reg_u {
    uint32 reg[DRV_MT_IO_KG_IND_FPU_HASH_STATUS_REG_WORD_SIZE];
    struct {
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 8;
        uint32 cpu_fd_dup : 1;
        uint32 cpu_fd_hit : 1;
        uint32 cpu_fd_tile_no : 5;
        uint32 cpu_fd_idx : 15;
        uint32 op_suc : 1;
        uint32 ind_access_done : 1;
    } field;
} drv_kg_io_reg_fpu_hash_stat_reg_t;

/* tile_lpm_ind_status */
typedef union drv_kg_io_reg_fpu_hash_lpm_stat_reg_u {
    uint32 reg[DRV_MT_IO_KG_IND_FPU_HASH_LPM_STATUS_REG_WORD_SIZE];
    struct {
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 11;
        uint32 cpu_fd_dup : 1;
        uint32 cpu_fd_hit : 1;
        uint32 cpu_fd_tile_no : 5;
        uint32 cpu_fd_idx : 11;
        uint32 op_suc : 1;
        uint32 ind_access_done : 1;
    } field;
} drv_kg_io_reg_fpu_hash_lpm_stat_reg_t;

/* tile_hsh_ind_status Response status */
typedef union drv_kg_io_reg_hash_stat_reg_u {
    uint32 reg[DRV_MT_IO_IND_HASH_STATUS_REG_WORD_SIZE];
    struct {
        uint32 ind_result2 : 32;
        uint32 ind_result1 : 32;
        uint32 ind_result0 : 30;
        uint32 op_suc : 1;
        uint32 ind_access_done : 1;
    } field;
} drv_kg_io_reg_hash_stat_reg_t;

/* tile_lpm_ind_cmd */
typedef union drv_kg_io_reg_fpu_hash_lpm_cmd_reg_u {
    uint32 reg[DRV_MT_IO_KG_IND_FPU_HSH_LPM_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 25;
        uint32 del_hit_op : 1;
        uint32 insert_hit_op : 1;
        uint32 acc_bmp : 32;
        uint32 ecc_access : 1;
        uint32 key_type : 1;
        uint32 cmd : 3;
    } field;
} drv_kg_io_reg_fpu_hash_lpm_cmd_reg_t;

/* tile_lpm_ind_addr */
typedef union drv_kg_io_reg_fpu_hash_lpm_addr_reg_u {
    uint32 reg[DRV_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 : 16;
        uint32 ind_addr : 16;
    } field;
} drv_kg_io_reg_fpu_hash_lpm_addr_reg_t;

typedef union drv_kg_io_reg_fpu_hash_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 del_hit_op : 1;
        uint32 insert_hit_op : 1;
        uint32 acc_bmp : 20;
        uint32 ecc_access : 1;
        uint32 key_type : 2;
        uint32 cmd : 3;
    } field;
} drv_kg_io_reg_fpu_hash_cmd_reg_t;

typedef union drv_kg_io_reg_hash_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 28;
        uint32 ecc_access : 1;
        uint32 cmd : 3;
    } field;
    struct {
        uint32 : 27;
        uint32 ecc_access : 1;
        uint32 key_type : 1;
        uint32 cmd : 3;
    } field1;
} drv_kg_io_reg_hash_cmd_reg_t;

/* slc0_tile_tcam_ind_cmd */
typedef union drv_kg_io_reg_fpu_tcam_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 26;
        uint32 ind_slc_select : 1;
        uint32 mode : 2;
        uint32 cmd : 3;
    } field;
} drv_kg_io_reg_fpu_tcam_cmd_reg_t;

typedef union drv_kg_io_reg_tcam_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 26;
        uint32 mode : 3;
        uint32 cmd : 3;
    } field;
} drv_kg_io_reg_tcam_cmd_reg_t;

/* tile_tcam_ind_addr */
typedef union drv_kg_io_reg_fpu_tcam_addr_reg_u {
    uint32 reg[DRV_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 : 17;
        uint32 ind_mem_addr : 15;
    } field;
} drv_kg_io_reg_fpu_tcam_addr_reg_t;

typedef union drv_kg_io_reg_tcam_addr_reg_u {
    uint32 reg[DRV_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 : 17;
        uint32 ind_mem_addr : 15;
    } field;
} drv_kg_io_reg_tcam_addr_reg_t;

typedef union drv_kg_io_reg_tcam_sta_reg_u {
    uint32 reg[DRV_MT_IO_IND_STATUS_REG_WORD_SIZE];
    struct {
        uint32 : 31;
        uint32 ind_access_done : 1;
    } field;
} drv_kg_io_reg_tcam_sta_reg_t;

typedef union drv_kg_io_reg_tcam_move_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_TCAM_MOVE_REG_WORD_SIZE];
    struct {
        uint32 move_or_init : 1;
        uint32 move_mode : 2;
        uint32 op_num : 15;
        uint32 dst_addr : 15;
        uint32 src_addr : 15;
    } ciat_cmd;
    struct {
        uint32 move_or_init : 1;
        uint32 move_mode : 2;
        uint32 op_num : 15;
        uint32 dst_addr : 15;
        uint32 src_addr : 15;
    } fpu_cmd;
    struct {
        uint32 move_or_init : 1;
        uint32 move_mode : 2;
        uint32 op_num : 11;
        uint32 dst_addr : 11;
        uint32 src_addr : 11;
    } dis_cmd;
} drv_kg_io_reg_tcam_move_cmd_reg_t;

typedef union drv_kg_io_reg_tcam_move_sta_reg_u {
    uint32 reg[DRV_MT_IO_IND_STATUS_REG_WORD_SIZE];
    struct {
        uint32 cur_src_ptr : 15;
        uint32 move_done : 1;
        uint32 ack_lock : 4;
        uint32 cur_status : 3;
    } field;
} drv_kg_io_reg_tcam_move_sta_reg_t;

/* wd_mem_addr */
typedef union drv_kg_io_reg_ipl_lbm_wd_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 22;
        uint32 dp_sel : 1;
        uint32 address : 9;
    } field;
} drv_kg_io_reg_ipl_lbm_wd_mem_addr_t;

/* data_buf_addr */
typedef union drv_kg_io_reg_ipl_lbm_data_buf_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 18;
        uint32 dp_sel : 1;
        uint32 mem_sel : 5;
        uint32 address : 8;
    } field;
} drv_kg_io_reg_ipl_lbm_data_buf_addr_t;

/* vrf_mem_addr */
typedef union drv_kg_io_reg_tm_vrf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 14;
        uint32 mem_inst_sel : 7; /* range 0~71, emu0:0~35 , emu1:36~71 */
        uint32 address : 11;
    } field;
} drv_kg_io_reg_tm_vrf_mem_addr_t;

/* data_buf_mem_addr */
typedef union drv_kg_io_reg_ipl_pipe_data_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 17;
        uint32 mem_bank_id : 4;
        uint32 address : 11;
    } field;
} drv_kg_io_reg_ipl_pipe_data_buf_mem_addr_t;

/* fd_buf_mem_addr */
typedef union drv_kg_io_reg_ipl_pipe_fd_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 18;
        uint32 address : 14;
    } field;
} drv_kg_io_reg_ipl_pipe_fd_buf_mem_addr_t;

/* epl_pipe_data_buf_mem_addr */
typedef union drv_kg_io_reg_epl_pipe_data_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 16;
        uint32 bank_idx : 5;
        uint32 address : 11;
    } field;
} drv_kg_io_reg_epl_pipe_data_buf_mem_addr_t;

/* epl_pipe_fd_buf_mem_addr */
typedef union drv_kg_io_reg_epl_pipe_fd_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 19;
        uint32 address : 13;
    } field;
} drv_kg_io_reg_epl_pipe_fd_buf_mem_addr_t;

/* epl_pkt_gen_data_buf_addr */
typedef union drv_kg_io_reg_epl_pkt_gen_data_buf_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 21;
        uint32 bank_idx : 4;
        uint32 address : 7;
    } field;
} drv_kg_io_reg_epl_pkt_gen_data_buf_addr_t;

/* sn_mem_addr */
typedef union drv_kg_io_reg_tm_iqc_sn_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 17;
        uint32 mem_inst_sel : 3;
        uint32 address : 12;
    } field;
} drv_kg_io_reg_tm_iqc_sn_mem_addr_t;

/* sn_mem_addr */
typedef union drv_kg_io_reg_tm_eqc_sn_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 20;
        uint32 mem_inst_sel : 4;
        uint32 address : 8;
    } field;
} drv_kg_io_reg_tm_eqc_sn_mem_addr_t;

/* bc_mem_addr */
typedef union drv_kg_io_reg_tm_iqc_bc_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 19;
        uint32 mem_inst_sel : 1;
        uint32 address : 12;
    } field;
} drv_kg_io_reg_tm_iqc_bc_mem_addr_t;

/* bc_mem_addr */
typedef union drv_kg_io_reg_tm_eqc_bc_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 19;
        uint32 mem_inst_sel : 3;
        uint32 address : 8;
    } field;
} drv_kg_io_reg_tm_eqc_bc_mem_addr_t;

/* qsize_mem_addr */
typedef union drv_kg_io_reg_tm_iqc_qsize_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 18;
        uint32 mem_inst_sel : 2;
        uint32 address : 12;
    } field;
} drv_kg_io_reg_tm_iqc_qsize_mem_addr_t;

/* pcnt_mem_addr */
typedef union drv_kg_io_reg_tm_iqc_pcnt_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 17;
        uint32 mem_inst_sel : 3;
        uint32 address : 12;
    } field;
} drv_kg_io_reg_tm_iqc_pcnt_mem_addr_t;

/* pcnt_mem_addr */
typedef union drv_kg_io_reg_tm_eqc_pcnt_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 20;
        uint32 mem_inst_sel : 4;
        uint32 address : 8;
    } field;
} drv_kg_io_reg_tm_eqc_pcnt_mem_addr_t;

/* pbc_mem_addr */
typedef union drv_kg_io_reg_tm_iqc_pbc_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 23;
        uint32 mem_inst_sel : 2;
        uint32 address : 7;
    } field;
} drv_kg_io_reg_tm_iqc_pbc_mem_addr_t;

/* csz_psz_mem_addr */
typedef union drv_kg_io_reg_tm_iqc_csz_psz_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 17;
        uint32 mem_inst_sel : 3;
        uint32 address : 12;
    } field;
} drv_kg_io_reg_tm_iqc_csz_psz_mem_addr_t;

/* fdl_hsh_status_mem_addr */
typedef union drv_kg_io_reg_tm_rep_fdl_hsh_status_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 22;
        uint32 address : 10;
    } field;
} drv_kg_io_reg_tm_rep_fdl_hsh_status_mem_addr_t;

/* age_hsh_status_mem_addr */
typedef union drv_kg_io_reg_tm_rep_age_hsh_status_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 22;
        uint32 address : 10;
    } field;
} drv_kg_io_reg_tm_rep_age_hsh_status_mem_addr_t;

/* fbm_mem_addr */
typedef union drv_kg_io_reg_tm_pde_fbm_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 23;
        uint32 mem_inst_sel : 1;
        uint32 address : 8;
    } field;
} drv_kg_io_reg_tm_pde_fbm_mem_addr_t;

/* fbm_mem_addr */
typedef union drv_kg_io_reg_tm_eqc_pde_fbm_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 24;
        uint32 mem_inst_sel : 2;
        uint32 address : 6;
    } field;
} drv_kg_io_reg_tm_eqc_pde_fbm_mem_addr_t;

/* fbm_mem_addr */
typedef union drv_kg_io_reg_tm_ppl_fbm_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 23;
        uint32 emu_id : 1;
        uint32 address : 8;
    } field;
} drv_kg_io_reg_tm_ppl_fbm_mem_addr_t;

/* CLX */
/* ddc_retry_buf_mem_addr */
typedef union drv_kg_io_reg_clx_ddc_retry_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 23;
        uint32 addr : 9;
    } field;
} drv_kg_io_reg_clx_ddc_retry_buf_mem_addr_t;

/* ddc_seq_ptr_table_addr */
typedef union drv_kg_io_reg_clx_ddc_seq_ptr_table_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 22;
        uint32 addr : 10;
    } field;
} drv_kg_io_reg_clx_ddc_seq_ptr_table_addr_t;

/* PCX */
/* cmst_rsp_buf0_addr */
typedef union drv_kg_io_reg_pcx_top_cmst_rsp_buf_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 24;
        uint32 addr : 8;
    } field;
} drv_kg_io_reg_pcx_top_cmst_rsp_buf_addr_t;

#elif defined(CLX_EN_LITTLE_ENDIAN)
typedef union drv_kg_io_reg_cpu_hit_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    union {
        struct fpu_field {
            uint32 cpu_hit_ind_cmd : 3;
            uint32 sel_hsh_or_tcam : 1;
            uint32 cpu_hit_ind_addr : 20;
            uint32 : 8;
        } fpu_field;
        struct tcam_field {
            uint32 cpu_hit_ind_cmd : 3;
            uint32 sel_lpm_or_tcam : 1;
            uint32 cpu_hit_ind_addr : 16;
            uint32 : 12;
        } tcam_field;
    } field;
} drv_kg_io_reg_cpu_hit_cmd_reg_t;

/* tile_hsh_ind_addr */
typedef union drv_kg_io_reg_hash_ind_addr_reg_u {
    uint32 reg[DRV_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 ind_addr : 20;
        uint32 : 12;
    } field;
} drv_kg_io_reg_hash_ind_addr_reg_t;

/* Response status */
typedef union drv_kg_io_reg_fpu_hash_stat_reg_u {
    uint32 reg[DRV_MT_IO_KG_IND_FPU_HASH_STATUS_REG_WORD_SIZE];
    struct {
        uint32 ind_access_done : 1;
        uint32 op_suc : 1;
        uint32 cpu_fd_idx : 15;
        uint32 cpu_fd_tile_no : 5;
        uint32 cpu_fd_hit : 1;
        uint32 cpu_fd_dup : 1;
        // uint32 cpu_fd_hit_idx       :     360;
        // uint32 cpu_fd_key_exist_bmp :     24;
        // uint32 cpu_fd_row_freebmp   :     192;
    } field;
} drv_kg_io_reg_fpu_hash_stat_reg_t;

/* tile_lpm_ind_status */
typedef union drv_kg_io_reg_fpu_hash_lpm_stat_reg_u {
    uint32 reg[DRV_MT_IO_KG_IND_FPU_HASH_LPM_STATUS_REG_WORD_SIZE];
    struct {
        uint32 ind_access_done : 1;
        uint32 op_suc : 1;
        uint32 cpu_fd_idx : 11;
        uint32 cpu_fd_tile_no : 5;
        uint32 cpu_fd_hit : 1;
        uint32 cpu_fd_dup : 1;
    } field;
} drv_kg_io_reg_fpu_hash_lpm_stat_reg_t;

/* tile_hsh_ind_status Response status */
typedef union drv_kg_io_reg_hash_stat_reg_u {
    uint32 reg[DRV_MT_IO_IND_HASH_STATUS_REG_WORD_SIZE];
    struct {
        uint32 ind_access_done : 1;
        uint32 op_suc : 1;
        uint32 ind_result0 : 30;
        uint32 ind_result1 : 32;
        uint32 ind_result2 : 32;
    } field;
} drv_kg_io_reg_hash_stat_reg_t;

/* tile_lpm_ind_cmd */
typedef union drv_kg_io_reg_fpu_hash_lpm_cmd_reg_u {
    uint32 reg[DRV_MT_IO_KG_IND_FPU_HSH_LPM_CMD_REG_WORD_SIZE];
    struct {
        uint32 cmd : 3;
        uint32 key_type : 1;
        uint32 ecc_access : 1;
        uint32 acc_bmp : 32;
        uint32 insert_hit_op : 1;
        uint32 del_hit_op : 1;
        uint32 : 25;
    } field;
} drv_kg_io_reg_fpu_hash_lpm_cmd_reg_t;

/* tile_lpm_ind_addr */
typedef union drv_kg_io_reg_fpu_hash_lpm_addr_reg_u {
    uint32 reg[DRV_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 ind_addr : 16;
        uint32 : 16;
    } field;
} drv_kg_io_reg_fpu_hash_lpm_addr_reg_t;

typedef union drv_kg_io_reg_fpu_hash_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 cmd : 3;
        uint32 key_type : 2;
        uint32 ecc_access : 1;
        uint32 acc_bmp : 20;
        uint32 insert_hit_op : 1;
        uint32 del_hit_op : 1;
    } field;
} drv_kg_io_reg_fpu_hash_cmd_reg_t;

typedef union drv_kg_io_reg_hash_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 cmd : 3;
        uint32 ecc_access : 1;
    } field;
    struct {
        uint32 cmd : 3;
        uint32 key_type : 1;
        uint32 ecc_access : 1;
    } field1;
} drv_kg_io_reg_hash_cmd_reg_t;

/* slc0_tile_tcam_ind_cmd */
typedef union drv_kg_io_reg_fpu_tcam_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 cmd : 3;
        uint32 mode : 2;
        uint32 ind_slc_select : 1;
    } field;
} drv_kg_io_reg_fpu_tcam_cmd_reg_t;

typedef union drv_kg_io_reg_tcam_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 cmd : 3;
        uint32 mode : 3;
    } field;
} drv_kg_io_reg_tcam_cmd_reg_t;

/* tile_tcam_ind_addr */
typedef union drv_kg_io_reg_fpu_tcam_addr_reg_u {
    uint32 reg[DRV_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 ind_mem_addr : 15;
    } field;
} drv_kg_io_reg_fpu_tcam_addr_reg_t;

typedef union drv_kg_io_reg_tcam_addr_reg_u {
    uint32 reg[DRV_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 ind_mem_addr : 15;
    } field;
} drv_kg_io_reg_tcam_addr_reg_t;

typedef union drv_kg_io_reg_tcam_sta_reg_u {
    uint32 reg[DRV_MT_IO_IND_STATUS_REG_WORD_SIZE];
    struct {
        uint32 ind_access_done : 1;
    } field;
} drv_kg_io_reg_tcam_sta_reg_t;

typedef union drv_kg_io_reg_tcam_move_cmd_reg_u {
    uint32 reg[DRV_MT_IO_IND_CMD_TCAM_MOVE_REG_WORD_SIZE];
    struct {
        uint32 src_addr : 15;
        uint32 dst_addr : 15;
        uint32 op_num : 15;
        uint32 move_mode : 2;
        uint32 move_or_init : 1;
    } ciat_cmd;
    struct {
        uint32 src_addr : 15;
        uint32 dst_addr : 15;
        uint32 op_num : 15;
        uint32 move_mode : 2;
        uint32 move_or_init : 1;
    } fpu_cmd;
    struct {
        uint32 src_addr : 11;
        uint32 dst_addr : 11;
        uint32 op_num : 11;
        uint32 move_mode : 2;
        uint32 move_or_init : 1;
    } dis_cmd;
} drv_kg_io_reg_tcam_move_cmd_reg_t;

typedef union drv_kg_io_reg_tcam_move_sta_reg_u {
    uint32 reg[DRV_MT_IO_IND_STATUS_REG_WORD_SIZE];
    struct {
        uint32 cur_status : 3;
        uint32 ack_lock : 4;
        uint32 move_done : 1;
        uint32 cur_src_ptr : 15;
    } field;
} drv_kg_io_reg_tcam_move_sta_reg_t;

/* wd_mem_addr */
typedef union drv_kg_io_reg_ipl_lbm_wd_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 9;
        uint32 dp_sel : 1;
    } field;
} drv_kg_io_reg_ipl_lbm_wd_mem_addr_t;

/* data_buf_addr */
typedef union drv_kg_io_reg_ipl_lbm_data_buf_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 8;
        uint32 mem_sel : 5;
        uint32 dp_sel : 1;
    } field;
} drv_kg_io_reg_ipl_lbm_data_buf_addr_t;

/* vrf_mem_addr */
typedef union drv_kg_io_reg_tm_vrf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 11;
        uint32 mem_inst_sel : 7; /* range 0~71, emu0:0~35 , emu1:36~71 */
        uint32 : 14;
    } field;
} drv_kg_io_reg_tm_vrf_mem_addr_t;

/* data_buf_mem_addr */
typedef union drv_kg_io_reg_ipl_pipe_data_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 11;
        uint32 mem_bank_id : 4;
        uint32 : 17;
    } field;
} drv_kg_io_reg_ipl_pipe_data_buf_mem_addr_t;

/* fd_buf_mem_addr */
typedef union drv_kg_io_reg_ipl_pipe_fd_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 14;
        uint32 : 18;
    } field;
} drv_kg_io_reg_ipl_pipe_fd_buf_mem_addr_t;

/* epl_pipe_data_buf_mem_addr */
typedef union drv_kg_io_reg_epl_pipe_data_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 11;
        uint32 bank_idx : 5;
        uint32 : 16;
    } field;
} drv_kg_io_reg_epl_pipe_data_buf_mem_addr_t;

/* epl_pipe_fd_buf_mem_addr */
typedef union drv_kg_io_reg_epl_pipe_fd_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 13;
        uint32 : 19;
    } field;
} drv_kg_io_reg_epl_pipe_fd_buf_mem_addr_t;

/* epl_pkt_gen_data_buf_addr */
typedef union drv_kg_io_reg_epl_pkt_gen_data_buf_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 7;
        uint32 bank_idx : 4;
        uint32 : 21;
    } field;
} drv_kg_io_reg_epl_pkt_gen_data_buf_addr_t;

/* sn_mem_addr */
typedef union drv_kg_io_reg_tm_iqc_sn_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 12;
        uint32 mem_inst_sel : 3;
        uint32 : 17;
    } field;
} drv_kg_io_reg_tm_iqc_sn_mem_addr_t;

/* sn_mem_addr */
typedef union drv_kg_io_reg_tm_eqc_sn_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 8;
        uint32 mem_inst_sel : 4;
        uint32 : 20;
    } field;
} drv_kg_io_reg_tm_eqc_sn_mem_addr_t;

/* bc_mem_addr */
typedef union drv_kg_io_reg_tm_iqc_bc_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 12;
        uint32 mem_inst_sel : 1;
        uint32 : 19;
    } field;
} drv_kg_io_reg_tm_iqc_bc_mem_addr_t;

/* bc_mem_addr */
typedef union drv_kg_io_reg_tm_eqc_bc_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 8;
        uint32 mem_inst_sel : 3;
        uint32 : 19;
    } field;
} drv_kg_io_reg_tm_eqc_bc_mem_addr_t;

/* qsize_mem_addr */
typedef union drv_kg_io_reg_tm_iqc_qsize_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 12;
        uint32 mem_inst_sel : 2;
        uint32 : 18;
    } field;
} drv_kg_io_reg_tm_iqc_qsize_mem_addr_t;

/* pcnt_mem_addr */
typedef union drv_kg_io_reg_tm_iqc_pcnt_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 12;
        uint32 mem_inst_sel : 3;
        uint32 : 17;
    } field;
} drv_kg_io_reg_tm_iqc_pcnt_mem_addr_t;

/* pcnt_mem_addr */
typedef union drv_kg_io_reg_tm_eqc_pcnt_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 8;
        uint32 mem_inst_sel : 4;
        uint32 : 20;
    } field;
} drv_kg_io_reg_tm_eqc_pcnt_mem_addr_t;

/* pbc_mem_addr */
typedef union drv_kg_io_reg_tm_iqc_pbc_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 7;
        uint32 mem_inst_sel : 2;
        uint32 : 23;
    } field;
} drv_kg_io_reg_tm_iqc_pbc_mem_addr_t;

/* csz_psz_mem_addr */
typedef union drv_kg_io_reg_tm_iqc_csz_psz_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 12;
        uint32 mem_inst_sel : 3;
        uint32 : 17;
    } field;
} drv_kg_io_reg_tm_iqc_csz_psz_mem_addr_t;

/* fdl_hsh_status_mem_addr */
typedef union drv_kg_io_reg_tm_rep_fdl_hsh_status_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 10;
        uint32 : 22;
    } field;
} drv_kg_io_reg_tm_rep_fdl_hsh_status_mem_addr_t;

/* age_hsh_status_mem_addr */
typedef union drv_kg_io_reg_tm_rep_age_hsh_status_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 10;
        uint32 : 22;
    } field;
} drv_kg_io_reg_tm_rep_age_hsh_status_mem_addr_t;

/* fbm_mem_addr */
typedef union drv_kg_io_reg_tm_pde_fbm_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 8;
        uint32 mem_inst_sel : 1;
        uint32 : 23;
    } field;
} drv_kg_io_reg_tm_pde_fbm_mem_addr_t;

/* fbm_mem_addr */
typedef union drv_kg_io_reg_tm_eqc_pde_fbm_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 6;
        uint32 mem_inst_sel : 2;
        uint32 : 24;
    } field;
} drv_kg_io_reg_tm_eqc_pde_fbm_mem_addr_t;

/* fbm_mem_addr */
typedef union drv_kg_io_reg_tm_ppl_fbm_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 8;
        uint32 emu_id : 1;
        uint32 : 23;
    } field;
} drv_kg_io_reg_tm_ppl_fbm_mem_addr_t;

/* CLX */
/* ddc_retry_buf_mem_addr */
typedef union drv_kg_io_reg_clx_ddc_retry_buf_mem_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 addr : 9;
        uint32 : 23;
    } field;
} drv_kg_io_reg_clx_ddc_retry_buf_mem_addr_t;

/* ddc_seq_ptr_table_addr */
typedef union drv_kg_io_reg_clx_ddc_seq_ptr_table_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 addr : 10;
        uint32 : 22;
    } field;
} drv_kg_io_reg_clx_ddc_seq_ptr_table_addr_t;

/* PCX */
/* cmst_rsp_buf0_addr */
typedef union drv_kg_io_reg_pcx_top_cmst_rsp_buf_addr_u {
    uint32 reg[DRV_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 addr : 8;
        uint32 : 24;
    } field;
} drv_kg_io_reg_pcx_top_cmst_rsp_buf_addr_t;

#else
#error "Host endian is not defined!!\n"
#endif
#pragma pack(pop)

typedef struct drv_kg_io_tcam_fpu_info_s {
    drv_kg_io_reg_fpu_tcam_cmd_reg_t ind_cmd;
    drv_kg_io_reg_fpu_tcam_addr_reg_t ind_addr;
    drv_kg_io_reg_tcam_sta_reg_t ind_sta;
    uint32 acc_bmp;
} drv_kg_io_tcam_fpu_info_t;

typedef struct drv_kg_io_tcam_info_s {
    drv_kg_io_reg_tcam_cmd_reg_t ind_cmd;
    drv_kg_io_reg_tcam_addr_reg_t ind_addr;
    drv_kg_io_reg_tcam_sta_reg_t ind_sta;
} drv_kg_io_tcam_info_t;

typedef struct drv_kg_io_hash_fpu_lpm_info_s {
    drv_kg_io_reg_fpu_hash_lpm_cmd_reg_t ind_cmd;
    drv_kg_io_reg_fpu_hash_lpm_addr_reg_t ind_addr;
    drv_kg_io_reg_fpu_hash_lpm_stat_reg_t ind_sta;
} drv_kg_io_hash_fpu_lpm_info_t;

typedef struct drv_kg_io_hash_fpu_info_s {
    drv_kg_io_reg_fpu_hash_cmd_reg_t ind_cmd;
    drv_kg_io_reg_hash_ind_addr_reg_t ind_addr;
    drv_kg_io_reg_fpu_hash_stat_reg_t ind_sta;
} drv_kg_io_hash_fpu_info_t;

typedef struct drv_kg_io_hash_info_s {
    drv_kg_io_reg_hash_cmd_reg_t ind_cmd;
    drv_kg_io_reg_hash_ind_addr_reg_t ind_addr;
    drv_kg_io_reg_hash_stat_reg_t ind_sta;
} drv_kg_io_hash_info_t;

typedef struct drv_kg_io_tcam_move_info_s {
    drv_kg_io_reg_tcam_move_cmd_reg_t ind_move_cmd;
    drv_kg_io_reg_tcam_move_sta_reg_t ind_move_sta;
} drv_kg_io_tcam_move_info_t;

typedef union drv_kg_io_pl_tm_ind_mem_info_u {
    /* pl */
    drv_kg_io_reg_ipl_lbm_data_buf_addr_t ipl_lbm_data_buf_ind_cmd;
    drv_kg_io_reg_ipl_lbm_wd_mem_addr_t ipl_lbm_wd_mem_ind_cmd;
    drv_kg_io_reg_ipl_pipe_data_buf_mem_addr_t ipl_pipe_data_buf_mem_ind_cmd;
    drv_kg_io_reg_ipl_pipe_fd_buf_mem_addr_t ipl_pipe_fd_mem_ind_cmd;
    drv_kg_io_reg_epl_pipe_data_buf_mem_addr_t epl_pipe_data_buf_mem_ind_cmd;
    drv_kg_io_reg_epl_pipe_fd_buf_mem_addr_t epl_pipe_fd_mem_ind_cmd;
    drv_kg_io_reg_epl_pkt_gen_data_buf_addr_t epl_pkt_gen_data_buf_mem_ind_cmd;

    /* tm */
    drv_kg_io_reg_tm_vrf_mem_addr_t tm_emu_verf_mem_ind_cmd;
    drv_kg_io_reg_tm_iqc_sn_mem_addr_t tm_iqc_sn_mem_ind_cmd;
    drv_kg_io_reg_tm_eqc_sn_mem_addr_t tm_eqc_sn_mem_ind_cmd;
    drv_kg_io_reg_tm_iqc_bc_mem_addr_t tm_iqc_bc_mem_ind_cmd;
    drv_kg_io_reg_tm_eqc_bc_mem_addr_t tm_eqc_bc_mem_ind_cmd;
    drv_kg_io_reg_tm_iqc_qsize_mem_addr_t tm_iqc_qsize_mem_ind_cmd;
    drv_kg_io_reg_tm_iqc_pcnt_mem_addr_t tm_iqc_pcnt_mem_ind_cmd;
    drv_kg_io_reg_tm_eqc_pcnt_mem_addr_t tm_eqc_pcnt_mem_ind_cmd;
    drv_kg_io_reg_tm_iqc_pbc_mem_addr_t tm_iqc_pbc_mem_ind_cmd;
    drv_kg_io_reg_tm_iqc_csz_psz_mem_addr_t tm_iqc_csz_psz_mem_ind_cmd;
    drv_kg_io_reg_tm_rep_fdl_hsh_status_mem_addr_t tm_rep_fdl_hsh_status_mem_ind_cmd;
    drv_kg_io_reg_tm_rep_age_hsh_status_mem_addr_t tm_rep_age_hsh_status_mem_ind_cmd;
    drv_kg_io_reg_tm_pde_fbm_mem_addr_t tm_pde_fbm_mem_ind_cmd;
    drv_kg_io_reg_tm_eqc_pde_fbm_mem_addr_t tm_eqc_pde_fbm_mem_ind_cmd;
    drv_kg_io_reg_tm_ppl_fbm_mem_addr_t tm_ppl_fbm_mem_ind_cmd;
} drv_kg_io_pl_tm_ind_mem_info_t;

typedef union drv_kg_io_clx_ind_mem_info_u {
    drv_kg_io_reg_clx_ddc_retry_buf_mem_addr_t clx_ddc_retry_buf_mem_ind_cmd;
    drv_kg_io_reg_clx_ddc_seq_ptr_table_addr_t clx_ddc_seq_ptr_table_addr_ind_cmd;
} drv_kg_io_clx_ind_mem_info_t;

typedef union drv_kg_io_pcx_ind_mem_info_u {
    drv_kg_io_reg_pcx_top_cmst_rsp_buf_addr_t pcx_top_cmst_rsp_buf_addr_ind_cmd;
} drv_kg_io_pcx_ind_mem_info_t;

typedef struct drv_kg_io_table_meta_s {
    uint32 ind_cmd_addr;
    uint32 ind_address_addr;
    uint32 ind_status_addr;
    uint32 ind_data_addr;
    uint32 acc_bmp_addr;

    union {
        drv_kg_io_tcam_fpu_info_t tcam_fpu_info;
        drv_kg_io_tcam_info_t tcam_info;
        drv_kg_io_hash_fpu_lpm_info_t hash_fpu_lpm_info;
        drv_kg_io_hash_fpu_info_t hash_fpu_info;
        drv_kg_io_hash_info_t hash_info;
        drv_kg_io_pl_tm_ind_mem_info_t tm_pl_info;
        drv_kg_io_clx_ind_mem_info_t clx_ind_info;
        drv_kg_io_pcx_ind_mem_info_t pcx_ind_info;
        drv_kg_io_tcam_move_info_t tcam_move_info;
    };

    drv_mt_io_table_type_t table_type;
    boolean access_by_dma;

} drv_kg_io_table_meta_t;

/* DRV CMST ERROR LOG */
#pragma pack(push, 1)
#if defined(CLX_EN_BIG_ENDIAN)
typedef struct drv_kg_io_error_cmst_code_s {
    uint32 req_addr_2 : 21; /* means req_data when cmst_error_code is sn_rsp_drop 3'b100 */
    uint32 req_mid : 3;
    uint32 req_sn : 8;
    uint32 : 3;
    uint32 error_info_valid : 1;
    uint32 master_id : 3;
    uint32 cmst_error_code : 3;
    uint32 req_type : 2;
    uint32 req_attr : 3;
    uint32 req_size : 6;
    uint32 req_addr_1 : 11; /* means req_data when cmst_error_code is sn_rsp_drop 3'b100 */
} drv_kg_io_error_cmst_code_t;

typedef struct drv_kg_io_error_cslv_code_s {
    uint32 req_addr_2 : 21;
    uint32 req_mid : 3;
    uint32 req_sn : 8;
    uint32 : 3;
    uint32 error_info_valid : 1;
    uint32 master_id : 3;
    uint32 cmst_error_code : 3;
    uint32 req_type : 2;
    uint32 req_attr : 3;
    uint32 req_size : 6;
    uint32 slv_error_code : 2;
    uint32 req_addr_1 : 9;
} drv_kg_io_error_cslv_code_t;

typedef struct drv_kg_io_error_other_code_s {
    uint32 chain_id_2 : 2;
    uint32 : 11;
    uint32 req_addr_lsb : 8;
    uint32 : 3;
    uint32 : 8;
    uint32 : 3;
    uint32 error_info_valid : 1;
    uint32 master_id : 3;
    uint32 cmst_error_code : 3;
    uint32 req_type : 2;
    uint32 req_attr : 3;
    uint32 req_size : 6;
    uint32 : 6;
    uint32 die_sel : 1;
    uint32 : 1;
    uint32 chain_id_1 : 3;
} drv_kg_io_error_other_code_t;
#elif defined(CLX_EN_LITTLE_ENDIAN)
typedef struct drv_kg_io_error_cmst_code_s {
    uint32 req_sn : 8;
    uint32 req_mid : 3;
    uint32 req_addr_2 : 21; /* means req_data when cmst_error_code is sn_rsp_drop 3'b100 */
    uint32 req_addr_1 : 11; /* means req_data when cmst_error_code is sn_rsp_drop 3'b100 */
    uint32 req_size : 6;
    uint32 req_attr : 3;
    uint32 req_type : 2;
    uint32 cmst_error_code : 3;
    uint32 master_id : 3;
    uint32 error_info_valid : 1;
    uint32 : 3;
} drv_kg_io_error_cmst_code_t;

typedef struct drv_kg_io_error_cslv_code_s {
    uint32 req_sn : 8;
    uint32 req_mid : 3;
    uint32 req_addr_2 : 21;
    uint32 req_addr_1 : 9;
    uint32 slv_error_code : 2;
    uint32 req_size : 6;
    uint32 req_attr : 3;
    uint32 req_type : 2;
    uint32 cmst_error_code : 3;
    uint32 master_id : 3;
    uint32 error_info_valid : 1;
    uint32 : 3;
} drv_kg_io_error_cslv_code_t;

typedef struct drv_kg_io_error_other_code_s {
    uint32 : 8;
    uint32 : 3;
    uint32 req_addr_lsb : 8;
    uint32 : 11;
    uint32 chain_id_2 : 2;
    uint32 chain_id_1 : 3;
    uint32 : 1;
    uint32 die_sel : 1;
    uint32 : 6;
    uint32 req_size : 6;
    uint32 req_attr : 3;
    uint32 req_type : 2;
    uint32 cmst_error_code : 3;
    uint32 master_id : 3;
    uint32 error_info_valid : 1;
    uint32 : 3;
} drv_kg_io_error_other_code_t;
#else
#error "Host endian is not defined!!\n"
#endif
#pragma pack(pop)

typedef struct drv_kg_io_error_code_s {
    union {
        drv_kg_io_error_cmst_code_t cmst_code;
        drv_kg_io_error_cslv_code_t cslv_code;
        drv_kg_io_error_other_code_t other_code;
    };

} drv_kg_io_error_code_t;

#endif /* END of DRV_KG_IO_H*/
