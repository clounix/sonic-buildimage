/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *******************************************************************************/

/* FILE NAME:  hal_ecpu_eparser.h
 * PURPOSE:
 *      It provide eparser module api.
 * NOTES:
 *
 */

#ifndef __HAL_EPARSER_H__
#define __HAL_EPARSER_H__

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_ecpu.h>

#ifdef __cplusplus
extern "C" {
#endif

/* NAMING CONSTANT DECLARATIONS (Macro Definitions)
 */

/* DATA TYPE DECLARATIONS (Data Structure Definitions)
 */

/* Module identifier enum, add new modules here as needed */
typedef enum hal_eparser_module_id_e {
    HAL_EPARSER_MODULE_INVALID = 0,
    HAL_EPARSER_MODULE_EXPORT_ROUTE,  /* Route export module */
    HAL_EPARSER_MODULE_HARDWARE_BFD,  /* Hardware BFD module */
    HAL_EPARSER_MODULE_EXPORT_ARP,    /* ARP export module */
    HAL_EPARSER_MODULE_EXPORT_MAC,    /* MAC export module */
    HAL_EPARSER_MODULE_EXPORT_IFDIAG, /* Interface diagnostic export module */
    HAL_EPARSER_MODULE_MAX
} hal_eparser_module_id_t;

/* Event type enum, defines different event types handled by eparser */
typedef enum hal_eparser_event_type_e {
    HAL_EPARSER_EVENT_INVALID = 0,
    HAL_EPARSER_EVENT_ASYNC_SEND,
    HAL_EPARSER_EVENT_COMMON_NOTIFY,
    HAL_EPARSER_EVENT_MAX
} hal_eparser_event_type_t;

// Message header structure
typedef struct hal_eparser_com_hdr_s {
    uint32_t type : 28;                // Message type
    uint32_t unit : 4;                 // Chip unit number
    hal_eparser_module_id_t module_id; // 0 when type==HAL_EPARSER_MSG_TYPE_REGMESSAGE, otherwise
                                       // module id
    uint32_t length;                   // Message body length
} hal_eparser_com_hdr_t;

// eparser message type definitions, shared by app and ecpu both direction
typedef enum hal_eparser_msg_type_e {
    HAL_EPARSER_MSG_TYPE_REGMESSAGE = 1, /* app to eparser */
    HAL_EPARSER_MSG_TYPE_REQUEST_ASYNC,  /* app to eparser */
    HAL_EPARSER_MSG_TYPE_REQUEST_SYNC,   /* app to eparser */
    HAL_EPARSER_MSG_TYPE_RESPONSE,       /* eparser to app */
    HAL_EPARSER_MSG_TYPE_NOTIFY,         /* eparser to app */
    HAL_EPARSER_MSG_TYPE_MAX
} hal_eparser_msg_type_t;

/* TLV header structure definition */
typedef struct hal_eparser_tlv_hdr_s {
    uint16_t type;   /* TLV type */
    uint16_t length; /* TLV length */
} hal_eparser_tlv_hdr_t;
// Registration message structure
typedef struct hal_eparser_reg_msg_s {
    hal_eparser_module_id_t reg_module; // Registration module id
} hal_eparser_reg_msg_t;

// Event callback control block
typedef struct hal_eparser_event_cb_s {
    hal_eparser_event_type_t event_type; // event type
    hal_eparser_module_id_t module_id;   // event processing module id
    uint32_t unit;                       // chip unit number
    uint8_t data_takeover; // 0: data will memcpy,and caller need free data ptr; 1: data will not
                           // memcpy,and caller must't free data ptr
    union {
        hal_eparser_msg_type_t send_msg_type;
        uint32_t data;
    } user_data;

} hal_eparser_event_cb_t;

/* Module function pointer type definitions */
/* app to eparser message processing function */
typedef clx_error_no_t (*module_message_proc_func_t)(uint32 unit,
                                                     hal_eparser_msg_type_t msg_type,
                                                     void *msg,
                                                     uint32_t length);
/* eparser event queue processing function */
typedef clx_error_no_t (*module_event_proc_func_t)(uint32 unit, void *data, uint32_t data_len);
/* module initialization function */
typedef clx_error_no_t (*module_init_func_t)(uint32 unit);
/* module deinitialization function */
typedef clx_error_no_t (*module_deinit_func_t)(uint32 unit);

/* Module function collection structure */
typedef struct hal_eparser_module_funcs_s {
    module_message_proc_func_t message_proc_func; /* Message processing function */
    module_event_proc_func_t event_proc_func;     /* Event processing function */
    module_init_func_t init_func;                 /* Module initialization function */
    module_deinit_func_t deinit_func;             /* Module deinitialization function */
} hal_eparser_module_funcs_t;

/* GLOBAL VARIABLE DECLARATIONS (Global Variable Declarations)
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS (External Function Declarations)
 */
/**
 * @brief Initialize eparser module.
 *
 * @param [in]    unit    - Chip unit number.
 * @return        CLX_E_OK               - Operation successful.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_eparser_init(uint32 unit);

/**
 * @brief Deinitialize eparser module.
 *
 * @param [in]    unit    - Chip unit number.
 * @return        CLX_E_OK        - Operation successful.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_eparser_deinit(uint32 unit);

/**
 * @brief Register module function pointer.
 *
 * @param [in]    module_id    - Module identifier.
 * @param [in]    funcs        - Module function set.
 * @return        CLX_E_OK               - Operation successful.
 * @return        CLX_E_BAD_PARAMETER    - Invalid module ID.
 */
clx_error_no_t
hal_eparser_module_register(hal_eparser_module_id_t module_id,
                            const hal_eparser_module_funcs_t *funcs);
/**
 * @brief Unregister module function pointer.
 *
 * @param [in]    module_id    - Module identifier to unregister.
 * @return        CLX_E_OK               - Operation successful.
 * @return        CLX_E_BAD_PARAMETER    - Invalid module ID.
 */
clx_error_no_t
hal_eparser_module_deregister(hal_eparser_module_id_t module_id);

/**
 * @brief Enqueue event notification message to eparser event queue for asynchronous processing.
 *
 * This function adds an event notification message to the lock-free event queue
 * for asynchronous processing by the eparser main thread. The function validates
 * event callback parameters including event type and module ID before enqueuing.
 * This is a thread-safe function and can be called from multiple thread contexts.
 *
 * @param [in]    evt_cb      - Event callback structure containing event type,
 *                              module ID, and user data.
 * @param [in]    data        - Event data pointer (can be NULL if data_len is 0).
 * @param [in]    data_len    - Event data length in bytes.
 * @return        CLX_E_OK               - Event successfully enqueued.
 * @return        CLX_E_BAD_PARAMETER    - Invalid evt_cb pointer, event type,
 *                                         or module ID.
 * @return        CLX_E_NO_MEMORY        - Memory allocation failed for data copy.
 * @return        CLX_E_OTHERS           - Event queue is full or eventfd write failed.
 */
clx_error_no_t
hal_eparser_event_notify(hal_eparser_event_cb_t *evt_cb, void *data, uint32_t data_len);

/**
 * @brief Send message to registered clients through event queue.
 *
 * This function enqueues the message to the event queue for asynchronous processing.
 * The actual sending will be performed in the event handler thread.
 *
 * @param [in]    unit         - Chip unit number.
 * @param [in]    module_id    - Module id registered with client.
 * @param [in]    msg_type     - Message type.
 * @param [in]    data         - Data to send.
 * @param [in]    data_len     - Data length.
 * @return        CLX_E_OK               - Operation successful.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_eparser_msg_send(uint32 unit,
                     hal_eparser_module_id_t module_id,
                     hal_eparser_msg_type_t msg_type,
                     const void *data,
                     uint32_t data_len);

/**
 * @brief Send message to registered clients with header and data sent separately.
 *
 * This function sends a message in two parts:
 * 1. First sends the message header containing type, unit, module_id and length information
 * 2. Then sends the actual data payload with a loop to handle large data.
 *
 * @param [in]    unit         - Chip unit number.
 * @param [in]    module_id    - Module id registered with client.
 * @param [in]    msg_type     - Message type.
 * @param [in]    data         - Data to send.
 * @param [in]    data_len     - Data length.
 * @return        CLX_E_OK               - Operation successful.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_eparser_msg_instant_send(uint32 unit,
                             hal_eparser_module_id_t module_id,
                             hal_eparser_msg_type_t msg_type,
                             const void *data,
                             uint32_t data_len);

/* ===== Memory Record (compile-time optional) =====
 * Define HAL_EPARSER_MEM_RECORD_ENABLE before including this header
 * to enable memory allocation recording for export modules.
 * Disabled by default: all record macros expand to no-ops with zero overhead.
 */
#ifdef HAL_EPARSER_MEM_RECORD_ENABLE

#include <osal/osal_mdc.h>

#define HAL_EPARSER_MEM_BUCKET_NUM 6

/* Bucket boundaries: <=64B, <=256B, <=4KB, <=64KB, <=1MB, >1MB */
#define HAL_EPARSER_MEM_BUCKET_64B   0
#define HAL_EPARSER_MEM_BUCKET_256B  1
#define HAL_EPARSER_MEM_BUCKET_4KB   2
#define HAL_EPARSER_MEM_BUCKET_64KB  3
#define HAL_EPARSER_MEM_BUCKET_1MB   4
#define HAL_EPARSER_MEM_BUCKET_LARGE 5

/* Per-bucket allocation counter */
typedef struct hal_eparser_mem_counter_s {
    uint32_t alloc_cnt;
    uint32_t free_cnt;
    uint64_t alloc_bytes;
    uint64_t free_bytes;
} hal_eparser_mem_counter_t;

/* Full record with normal and DMA sections */
typedef struct hal_eparser_mem_record_s {
    hal_eparser_mem_counter_t normal[HAL_EPARSER_MEM_BUCKET_NUM];
    hal_eparser_mem_counter_t dma[HAL_EPARSER_MEM_BUCKET_NUM];
} hal_eparser_mem_record_t;

static inline uint32_t
_hal_eparser_mem_bucket_index_get(uint32_t size)
{
    if (64 >= size)
        return HAL_EPARSER_MEM_BUCKET_64B;
    if (256 >= size)
        return HAL_EPARSER_MEM_BUCKET_256B;
    if (4096 >= size)
        return HAL_EPARSER_MEM_BUCKET_4KB;
    if (65536 >= size)
        return HAL_EPARSER_MEM_BUCKET_64KB;
    if (1048576 >= size)
        return HAL_EPARSER_MEM_BUCKET_1MB;
    return HAL_EPARSER_MEM_BUCKET_LARGE;
}

static inline void
_hal_eparser_mem_record_reset(hal_eparser_mem_record_t *ptr_record)
{
    if (NULL != ptr_record) {
        osal_memset(ptr_record, 0, sizeof(hal_eparser_mem_record_t));
    }
}

static inline void
_hal_eparser_mem_record_alloc(hal_eparser_mem_record_t *ptr_record, uint32_t size)
{
    if (NULL != ptr_record) {
        uint32_t idx = _hal_eparser_mem_bucket_index_get(size);
        __atomic_fetch_add(&ptr_record->normal[idx].alloc_cnt, 1, __ATOMIC_RELAXED);
        __atomic_fetch_add(&ptr_record->normal[idx].alloc_bytes, (uint64_t)size, __ATOMIC_RELAXED);
    }
}

static inline void
_hal_eparser_mem_record_free(hal_eparser_mem_record_t *ptr_record, uint32_t size)
{
    if (NULL != ptr_record) {
        uint32_t idx = _hal_eparser_mem_bucket_index_get(size);
        __atomic_fetch_add(&ptr_record->normal[idx].free_cnt, 1, __ATOMIC_RELAXED);
        __atomic_fetch_add(&ptr_record->normal[idx].free_bytes, (uint64_t)size, __ATOMIC_RELAXED);
    }
}

static inline void
_hal_eparser_mem_record_dma_alloc(hal_eparser_mem_record_t *ptr_record, uint32_t size)
{
    if (NULL != ptr_record) {
        uint32_t idx = _hal_eparser_mem_bucket_index_get(size);
        __atomic_fetch_add(&ptr_record->dma[idx].alloc_cnt, 1, __ATOMIC_RELAXED);
        __atomic_fetch_add(&ptr_record->dma[idx].alloc_bytes, (uint64_t)size, __ATOMIC_RELAXED);
    }
}

static inline void
_hal_eparser_mem_record_dma_free(hal_eparser_mem_record_t *ptr_record, uint32_t size)
{
    if (NULL != ptr_record) {
        uint32_t idx = _hal_eparser_mem_bucket_index_get(size);
        __atomic_fetch_add(&ptr_record->dma[idx].free_cnt, 1, __ATOMIC_RELAXED);
        __atomic_fetch_add(&ptr_record->dma[idx].free_bytes, (uint64_t)size, __ATOMIC_RELAXED);
    }
}

static inline boolean
_hal_eparser_mem_record_is_balance(const hal_eparser_mem_record_t *ptr_record)
{
    uint32_t i;
    if (NULL == ptr_record) {
        return TRUE;
    }
    for (i = 0; i < HAL_EPARSER_MEM_BUCKET_NUM; i++) {
        if (ptr_record->normal[i].alloc_cnt != ptr_record->normal[i].free_cnt) {
            return FALSE;
        }
        if (ptr_record->dma[i].alloc_cnt != ptr_record->dma[i].free_cnt) {
            return FALSE;
        }
    }
    return TRUE;
}

static inline boolean
_hal_eparser_mem_record_has_used(const hal_eparser_mem_record_t *ptr_record)
{
    uint32_t i;
    if (NULL == ptr_record) {
        return FALSE;
    }
    for (i = 0; i < HAL_EPARSER_MEM_BUCKET_NUM; i++) {
        if (ptr_record->normal[i].alloc_cnt > 0 || ptr_record->normal[i].free_cnt > 0) {
            return TRUE;
        }
        if (ptr_record->dma[i].alloc_cnt > 0 || ptr_record->dma[i].free_cnt > 0) {
            return TRUE;
        }
    }
    return FALSE;
}

/* Public API macros (enabled) - expand to inline function calls */
#define HAL_EPARSER_MEM_RECORD_RESET(ptr_record) _hal_eparser_mem_record_reset(ptr_record)
#define HAL_EPARSER_MEM_RECORD_ALLOC(ptr_record, size) \
    _hal_eparser_mem_record_alloc(ptr_record, size)
#define HAL_EPARSER_MEM_RECORD_FREE(ptr_record, size) _hal_eparser_mem_record_free(ptr_record, size)
#define HAL_EPARSER_MEM_RECORD_DMA_ALLOC(ptr_record, size) \
    _hal_eparser_mem_record_dma_alloc(ptr_record, size)
#define HAL_EPARSER_MEM_RECORD_DMA_FREE(ptr_record, size) \
    _hal_eparser_mem_record_dma_free(ptr_record, size)
#define HAL_EPARSER_MEM_RECORD_IS_BALANCE(ptr_record) _hal_eparser_mem_record_is_balance(ptr_record)
#define HAL_EPARSER_MEM_RECORD_HAS_USED(ptr_record)   _hal_eparser_mem_record_has_used(ptr_record)

/* Variable declaration helpers */
#define HAL_EPARSER_MEM_RECORD_DEF(var)        hal_eparser_mem_record_t var
#define HAL_EPARSER_MEM_RECORD_DEF_STATIC(var) static hal_eparser_mem_record_t var
#define HAL_EPARSER_MEM_RECORD_DEF_EXTERN(var) extern hal_eparser_mem_record_t var

/* Stats print macro - must be a macro so UTIL_LOG_PRINT expands at call site */
#define HAL_EPARSER_MEM_RECORD_STATS_PRINT(ptr_record, module_name)                              \
    do {                                                                                         \
        static const char *_mem_bucket_names[HAL_EPARSER_MEM_BUCKET_NUM] = {                     \
            "<=64B", "<=256B", "<=4KB", "<=64KB", "<=1MB", ">1MB"};                              \
        uint32_t _i;                                                                             \
        if (_hal_eparser_mem_record_has_used(ptr_record)) {                                      \
            boolean _has_leak = !_hal_eparser_mem_record_is_balance(ptr_record);                 \
            UTIL_LOG_PRINT(UTIL_LOG_ECPU_EPARSER, UTIL_LOG_INFO,                                 \
                           "----- %s Memory Stats%s -----\n", (module_name),                     \
                           _has_leak ? " (LEAK DETECTED)" : "");                                 \
            for (_i = 0; _i < HAL_EPARSER_MEM_BUCKET_NUM; _i++) {                                \
                if ((ptr_record)->normal[_i].alloc_cnt > 0 ||                                    \
                    (ptr_record)->normal[_i].free_cnt > 0) {                                     \
                    UTIL_LOG_PRINT(UTIL_LOG_ECPU_EPARSER, UTIL_LOG_INFO,                         \
                                   "  Normal [%s]: alloc=%u(%llu bytes), free=%u(%llu bytes), "  \
                                   "balance=%d%s\n",                                             \
                                   _mem_bucket_names[_i], (ptr_record)->normal[_i].alloc_cnt,    \
                                   (unsigned long long)(ptr_record)->normal[_i].alloc_bytes,     \
                                   (ptr_record)->normal[_i].free_cnt,                            \
                                   (unsigned long long)(ptr_record)->normal[_i].free_bytes,      \
                                   (int)((ptr_record)->normal[_i].alloc_cnt -                    \
                                         (ptr_record)->normal[_i].free_cnt),                     \
                                   ((ptr_record)->normal[_i].alloc_cnt !=                        \
                                    (ptr_record)->normal[_i].free_cnt) ?                         \
                                       " ***LEAK***" :                                           \
                                       "");                                                      \
                }                                                                                \
                if ((ptr_record)->dma[_i].alloc_cnt > 0 || (ptr_record)->dma[_i].free_cnt > 0) { \
                    UTIL_LOG_PRINT(                                                              \
                        UTIL_LOG_ECPU_EPARSER, UTIL_LOG_INFO,                                    \
                        "  DMA    [%s]: alloc=%u(%llu bytes), free=%u(%llu bytes), "             \
                        "balance=%d%s\n",                                                        \
                        _mem_bucket_names[_i], (ptr_record)->dma[_i].alloc_cnt,                  \
                        (unsigned long long)(ptr_record)->dma[_i].alloc_bytes,                   \
                        (ptr_record)->dma[_i].free_cnt,                                          \
                        (unsigned long long)(ptr_record)->dma[_i].free_bytes,                    \
                        (int)((ptr_record)->dma[_i].alloc_cnt - (ptr_record)->dma[_i].free_cnt), \
                        ((ptr_record)->dma[_i].alloc_cnt != (ptr_record)->dma[_i].free_cnt) ?    \
                            " ***LEAK***" :                                                      \
                            "");                                                                 \
                }                                                                                \
            }                                                                                    \
        }                                                                                        \
    } while (0)

#else /* !HAL_EPARSER_MEM_RECORD_ENABLE */

/* Stub type so variable declarations remain valid */
typedef struct hal_eparser_mem_record_s {
    uint8_t _dummy;
} hal_eparser_mem_record_t;

/* All record operations expand to no-ops */
#define HAL_EPARSER_MEM_RECORD_RESET(ptr_record)                    ((void)0)
#define HAL_EPARSER_MEM_RECORD_ALLOC(ptr_record, size)              ((void)0)
#define HAL_EPARSER_MEM_RECORD_FREE(ptr_record, size)               ((void)0)
#define HAL_EPARSER_MEM_RECORD_DMA_ALLOC(ptr_record, size)          ((void)0)
#define HAL_EPARSER_MEM_RECORD_DMA_FREE(ptr_record, size)           ((void)0)
#define HAL_EPARSER_MEM_RECORD_IS_BALANCE(ptr_record)               (TRUE)
#define HAL_EPARSER_MEM_RECORD_HAS_USED(ptr_record)                 (FALSE)
#define HAL_EPARSER_MEM_RECORD_STATS_PRINT(ptr_record, module_name) ((void)0)

/* Variable declaration helpers - auto suppress unused warnings when disabled */
#define HAL_EPARSER_MEM_RECORD_DEF(var)                             hal_eparser_mem_record_t __attribute__((unused)) var
#define HAL_EPARSER_MEM_RECORD_DEF_STATIC(var) \
    static hal_eparser_mem_record_t __attribute__((unused)) var
#define HAL_EPARSER_MEM_RECORD_DEF_EXTERN(var) \
    extern hal_eparser_mem_record_t __attribute__((unused)) var

#endif /* HAL_EPARSER_MEM_RECORD_ENABLE */

#ifdef __cplusplus
}
#endif
#endif /* __HAL_EPARSER_H__ */