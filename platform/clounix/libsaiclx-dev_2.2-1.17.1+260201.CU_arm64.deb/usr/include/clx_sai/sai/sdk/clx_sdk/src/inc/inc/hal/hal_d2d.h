/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_d2d.h
 * PURPOSE:
 *      It provide HAL D2D module API.
 * NOTES:
 *
 */

#ifndef HAL_D2D_H
#define HAL_D2D_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARACTIONS
 */
typedef enum hal_d2d_fec_cnt_type_e {
    HAL_D2D_FEC_CNT_TYPE_CERR = 0x0,
    HAL_D2D_FEC_CNT_TYPE_UCERR,
    HAL_D2D_FEC_CNT_TYPE_SERR,
    HAL_D2D_FEC_CNT_TYPE_LAST
} HAL_D2D_FEC_CNT_TYPE_T;

typedef struct HAL_D2D_DDC_FEC_CNT_S {
    uint64 cnts_fec_ue_cw_num;
    uint64 cnts_fec_ce_cw_num;
    uint64 cnts_fec_err_sym_cw_num[8];
    uint64 accs_fec_err_sym_num_lane[4];
    uint64 accs_fec_err_bit_num_lane[4];
    uint64 stas_hiser_window_fec_cw_ue_num;
    uint64 stas_hiser_window_fec_cw_ce_num;
    uint64 stas_hiser_window_fec_err_sym_num_lane[4];
    uint64 stas_hiser_window_fec_err_bit_num_lane[4];
} HAL_D2D_DDC_FEC_CNT_T;

typedef struct HAL_D2D_DDC_STATUS_S {
    uint32 stas_nts;
    uint32 stas_nrs;
    uint32 stas_as;
    uint32 stas_max_nak_retry_times;
    uint32 irqs_link_int;
    uint32 ddc_seq_ptr_table_ecc_err_int;
    uint32 ddc_seq_ptr_table_ecc_err_info;
    uint64 stas_link_status;
    uint32 stas_phy_txclk_freq[4];
    uint32 stas_phy_rxclk_freq[4];
    uint32 stas_dc_diff_value[3];
    uint32 stas_log_dc_max_diff_value[3];
} HAL_D2D_DDC_STATUS_T;

typedef enum hal_d2d_ddc_mode_e {
    HAL_D2D_DDC_MODE_STATUS = 0x0,
    HAL_D2D_DDC_MODE_FEC,
    HAL_D2D_DDC_MODE_LAST
} HAL_D2D_DDC_MODE_T;

#define HAL_DDC_CNT_NUM     12
#define HAL_D2D_DDC_CNT_NUM 24

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

#endif /* End of HAL_D2D_H */
