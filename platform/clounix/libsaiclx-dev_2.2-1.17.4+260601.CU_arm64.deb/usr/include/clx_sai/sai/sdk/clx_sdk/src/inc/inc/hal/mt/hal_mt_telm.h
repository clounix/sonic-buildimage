/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_telm.h
 * PURPOSE:
 *    Provide HAL driver API functions for NB.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_TELM_H
#define HAL_MT_TELM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_telm.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_TELM_INT_LFSR_IDX_OFFSET             (8)
#define HAL_MT_TELM_INT_PROFILE_NUM                 (8)
#define HAL_MT_TELM_TYPE_NUM                        (3)
#define HAL_MT_TELM_SAMPLER_THRESHOLD_DEFAULT_VALUE (0)
#define HAL_MT_TELM_SAMPLER_VALUE_DEFAULT_VALUE     (0xDEADBEEF)
#define HAL_MT_TELM_SAMPLER_TAPS_DEFAULT_VALUE      (0x80200003)
#define HAL_MT_TELM_INT_INSTR_BMP_DEFAULT_VALUE     (0)
#define HAL_MT_TELM_INT_CUD_ENTRY_NUM               (50)
#define HAL_MT_TELM_ROLE_TBL_PORT_NUM               (16)
#define HAL_MT_TELM_IS_EDGE_TBL_DI_NUM              (32)
#define HAL_MT_TELM_INSTR_MASK_DEFAULT_VALUE        (0xFFFF)
#define HAL_MT_TELM_HW_ID_MAX_VALUE                 (0x3F)
#define HAL_MT_TELM_TNL_REPORT_INDEX_INT(unit)      (HAL_LCL_INTF_GRP_ID_TNL_MAX_NUM(unit) - 2)
#define HAL_MT_TELM_TNL_REPORT_INDEX_MOD(unit)      (HAL_LCL_INTF_GRP_ID_TNL_MAX_NUM(unit) - 1)
#define HAL_MT_TELM_MOD_BLOOM_CLK_TO_NS(unit)       (1000.0 / HAL_DEVICE_FREQ(unit))
#define HAL_MT_TELM_MOD_BLOOM_TIMER_MAX_NS(unit) \
    ((uint32)(0xFFFFFFFF / HAL_DEVICE_FREQ(unit)) * 1000)
#define HAL_MT_TELM_MOD_BLOOM_TH_MAX (1023)
#define HAL_MT_TELM_MOD_BLOOM_TIMER_DFLT(unit) \
    (HAL_DEVICE_FREQ(unit) * 1000000) /* 1s at device frequency */
#define HAL_MT_TELM_MOD_BLOOM_TH_DFLT  (0x300)
#define HAL_MT_TELM_MOD_DELETE_PORT_OQ (4095)

#define HAL_MT_TELM_REP_O_CUD_OFFSET (1)
#define HAL_MT_TELM_REP_C_ACT_OFFSET (6)
#define HAL_MT_TELM_REP_C_CUD_OFFSET (7)
#define HAL_MT_TELM_REP_R_ACT_OFFSET (12)
#define HAL_MT_TELM_REP_R_CUD_OFFSET (13)

#define HAL_MT_TELM_REP_O_ACT_FIELD_ID (0)
#define HAL_MT_TELM_REP_O_CUD_FIELD_ID (1)
#define HAL_MT_TELM_REP_C_ACT_FIELD_ID (2)
#define HAL_MT_TELM_REP_C_CUD_FIELD_ID (3)
#define HAL_MT_TELM_REP_R_ACT_FIELD_ID (4)
#define HAL_MT_TELM_REP_R_CUD_FIELD_ID (5)

#define HAL_MT_TELM_INT_IDENTS                                                    \
    (CLX_TELM_INT_DOMAIN_ATTR_IDENT_GENEVE | CLX_TELM_INT_DOMAIN_ATTR_IDENT_GRE | \
     CLX_TELM_INT_DOMAIN_ATTR_IDENT_VXLAN | CLX_TELM_INT_DOMAIN_ATTR_IDENT_TCP |  \
     CLX_TELM_INT_DOMAIN_ATTR_IDENT_UDP)
#define HAL_MT_TELM_IOAM_FIFO_NOTIFY_MUTEX_SEMA_NAME ("IOAM_FIFO_NOTIFY_MUTEX_SEMA")
#define HAL_MT_TELM_IOAM_FIFO_TASK_NAME              ("IOAM_FIFO_TASK")
#define HAL_MT_TELM_IOAM_FIFO_DMA_ENTRY_NUM \
    (32 * 1024) /* FIFO entry dma size is 256b in 2^N unit. */
#define HAL_MT_TELM_IOAM_MAX_RING_BUF_ENTRY_NUM      (65535)
#define HAL_MT_TELM_IOAM_FIFO_UPLOAD_SEQ_NUM_BASE    (0)
#define HAL_MT_TELM_IOAM_STATS_FIFO_THRESHOLD_COUNT  (0x20)
#define HAL_MT_TELM_IOAM_STATS_FIFO_ALM_FULL_DEFAULT (0X4)
#define HAL_MT_TELM_IOAM_STATS_FIFO_TIMEOUT_DEFAULT(unit) \
    (HAL_DEVICE_FREQ(unit) * 1000 * 10) /* 10ms, unit is 1/1.35Ghz */
#define HAL_MT_TELM_IOAM_CFG_FWR_SAMPLE_INTERVAL_DEFAULT (0x1000)

#define HAL_MT_TELM_IOAM_CFG_IP_PROTOCOL  (0xba) /* identify ioam header protocol for ipv4 */
#define HAL_MT_TELM_IFA_IP_PROTOCOL       (0x83) /* identify ifa header protocol for ipv4 */
#define HAL_MT_TELM_IOAM_CFG_HBH_OPT_TYPE (0x11) /* identify ioam header protocol for ipv6 */
#define HAL_MT_TELM_IOAM_CFG_HBH_OPT_TYPE_MASK \
    (0x1f) /* mask opt type, fix to 0x1f, not expose to user to set */

#define HAL_MT_TELM_IOAM_STATS_FIFO_READ_PTR_UPDATE_THRESHOLD \
    (HAL_MT_TELM_IOAM_STATS_FIFO_THRESHOLD_COUNT)
#define HAL_MT_TELM_IOAM_FIFO_ENTRY_BYTES \
    (MT_NB_CDB_RWI_SLV_IOAM_STATS_FIFO_WORDS * HAL_BYTES_OF_WORD)

#define HAL_MT_TELM_IOAM_FIFO_TASK_SLEEP_USEC (10 * 1000)
#define HAL_MT_TELM_IOAM_FIFO_TASK_SLEEP_TH_ENTRY_NUM \
    (HAL_MT_TELM_IOAM_STATS_FIFO_READ_PTR_UPDATE_THRESHOLD * 256)

#define HAL_MT_TELM_TM_LUT_ENTRY_PER_LC_MAX_NUM (25)

#define HAL_MT_TELM_RWI_INT_RPT_CFG_DEFAULT_TNL_IDX      (0x1fff)
#define HAL_MT_TELM_RWI_INT_RPT_CFG_DEFAULT_TNL_BD_IDX   (0x1ff)
#define HAL_MT_TELM_RWI_INT_RPT_CFG_DEFAULT_TNL_PORT_IDX (0xfff)

#define HAL_MT_TELM_RWI_MOD_RPT_CFG_DEFAULT_TNL_IDX  (0x1ffe)
#define HAL_MT_TELM_RWI_MOD_RPT_CFG_DEFAULT_INTR_BMP (0xEF81)

#define HAL_MT_TELM_IOAM_FIFO_CHANNEL_NUM (19)
#define HAL_MT_TELM_IOAM_FIFO_CHANNEL_BMP (1 << HAL_MT_TELM_IOAM_FIFO_CHANNEL_NUM)
/* CH19_CLR/MASk offset bit is 17 */
#define HAL_MT_TELM_IOAM_FIFO_CHANNEL_CLR_BMP (1 << 17)

/* TODO: temp define here. interface.h */
#define HAL_MT_TELM_IFMON_ETH_LANE_NUM_PER_SLICE (32)
#define HAL_MT_TELM_IFMON_SLICE_NUM              (8)

/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_MT_TELM_CHECK_RC_RETURN(rc, module, level, format, arg...)  \
    do {                                                                \
        if (rc != CLX_E_OK) {                                           \
            UTIL_LOG_PRINT(module, level, "rc:%u, " format, rc, ##arg); \
            return rc;                                                  \
        }                                                               \
    } while (0);

#define HAL_MT_TELM_CHECK_RC_NOT_RETURN(rc, module, level, format, arg...) \
    do {                                                                   \
        if (rc != CLX_E_OK) {                                              \
            UTIL_LOG_PRINT(module, level, "rc:%u, " format, rc, ##arg);    \
        }                                                                  \
    } while (0);

/* DATA TYPE DECLARATIONS
 */

typedef enum hal_mt_telm_tob_type_e {
    HAL_MT_TELM_TOB_TYPE_DFLT_PROF,
    HAL_MT_TELM_TOB_TYPE_USE_BD,
    HAL_MT_TELM_TOB_TYPE_INSTR_MASK,
    HAL_MT_TELM_TOB_TYPE_MIRROR_DROP,
    HAL_MT_TELM_TOB_TYPE_INT_REP_DI,
    HAL_MT_TELM_TOB_TYPE_FORCE_OFF,
    HAL_MT_TELM_TOB_TYPE_INT_CLONE_PRI,
    HAL_MT_TELM_TOB_TYPE_INT_VER,
    HAL_MT_TELM_TOB_TYPE_NODE_ID,
    HAL_MT_TELM_TOB_TYPE_HW_ID,
    HAL_MT_TELM_TOB_TYPE_INT_REP_UDP_DP,
    HAL_MT_TELM_TOB_TYPE_MOD_OQ,
    HAL_MT_TELM_TOB_TYPE_IFA_LCL_NAMESPACE,
    HAL_MT_TELM_TOB_TYPE_TELM_REP_DS_ID,
    HAL_MT_TELM_TOB_TYPE_INT_MAX_HOP_CNT, /* CLX86 only */
    HAL_MT_TELM_TOB_TYPE_LAST
} hal_mt_telm_tob_type_t;

typedef struct hal_mt_telm_tob_cfg_s {
    hal_mt_telm_tob_type_t op_type; /* Operation type */
    uint32 reg_id;                  /* Register ID */
    uint32 field_id;                /* Field ID */
    uint32 inst_idx;                /* Instance index */
    uint32 subinst_idx;             /* Sub-instance index */
    const char *log_msg;            /* Log message */
} hal_mt_telm_tob_cfg_t;

typedef struct hal_mt_telm_int_cb_s {
    uint32 sample_rate[HAL_MT_TELM_INT_PROFILE_NUM];
} hal_mt_telm_int_cb_t;

typedef enum hal_mt_telm_wbdb_e {
    HAL_MT_TELM_WBDB_MOD_GLB_EN,
    HAL_MT_TELM_WBDB_INT_CB,
    HAL_MT_TELM_WBDB_LAST
} hal_mt_telm_wbdb_t;

typedef struct hal_mt_telm_ioam_fifo_notify_handler_s {
    clx_telm_ioam_fifo_read_func_t callback;
    void *ptr_cookie;
} hal_mt_telm_ioam_fifo_notify_handler_t;

typedef struct hal_mt_telm_ioam_cb_s {
    hal_mt_telm_ioam_fifo_notify_handler_t notify_handler;

    uint32 thread_pri;        /* Priority of FIFO task */
    uint32 thread_stack_size; /* Stack size of FIFO task */

    // hal_intr_type_t intr_type;

} hal_mt_telm_ioam_cb_t;

typedef struct hal_mt_telm_mod_cb_s {
    // clx_pkt_rx_reason_t rx_reason;
    uint32 mod_glb_en;
    uint32 out_port;      /* user configed out port */
    uint32 queue_id;      /* user configed queue id in per port */
    uint32 nvo3_encap_id; /* nvo3 encap id */
    uint32 nvo3_adj_id;   /* nvo3 adj id */
    uint32 compress_rate; /* mod compress rate */
} hal_mt_telm_mod_cb_t;

typedef struct hal_mt_telm_hop_cnt_zero_s {
    clx_telm_hop_cnt_zero_func_t callback;
    void *ptr_cookie;
} hal_mt_telm_hop_cnt_zero_t;

typedef struct hal_mt_telm_ifa_exceed_notify_handler_s {
    clx_telm_ifa_max_len_exceed_func_t callback;
    void *ptr_cookie;
} hal_mt_telm_ifa_exceed_notify_handler_t;

typedef struct hal_mt_telm_irq_cb_s {
    hal_mt_telm_hop_cnt_zero_t hop_cnt_zero_notify_handler;
    hal_mt_telm_ifa_exceed_notify_handler_t ifa_exceed_notify_handler;
} hal_mt_telm_irq_cb_t;

typedef struct hal_mt_telm_cb_s {
    hal_mt_telm_int_cb_t telm_int_cb;
    hal_mt_telm_ioam_cb_t telm_ioam_cb;
    hal_mt_telm_mod_cb_t telm_mod_cb;
    hal_mt_telm_irq_cb_t telm_irq_cb;
} hal_mt_telm_cb_t;

typedef struct hal_mt_telm_ioam_diag_reg_cfg_s {
    uint32 stats_fifo_threshold;
    uint32 stats_fifo_timeout_l;
    uint32 stats_fifo_timeout_h;
    uint32 fast_reload;
    uint32 color_switch_by_pkt;
    uint32 fifo_alm_full;
} hal_mt_telm_ioam_diag_reg_cfg_t;

typedef enum hal_mt_telm_rwi_port_speed_e {
    /* port speed. 0: 10G;  1: 25G; 2: 40G; 3: 50G; 4:100G; 5:200G; 6:400G */
    HAL_MT_TELM_RWI_PORT_SPEED_10G = 0,
    HAL_MT_TELM_RWI_PORT_SPEED_25G,
    HAL_MT_TELM_RWI_PORT_SPEED_40G,
    HAL_MT_TELM_RWI_PORT_SPEED_50G,
    HAL_MT_TELM_RWI_PORT_SPEED_100G,
    HAL_MT_TELM_RWI_PORT_SPEED_200G,
    HAL_MT_TELM_RWI_PORT_SPEED_400G,
    HAL_MT_TELM_RWI_PORT_SPEED_800G,

    /* add for KG port support */
    /* 7-800G; 8-1.6T; 9-3.2T; 10-10M; 11-100M; 12-1G; 13-2.5G; 14-5G */
    HAL_MT_TELM_RWI_PORT_SPEED_1600G,
    HAL_MT_TELM_RWI_PORT_SPEED_3200G,
    HAL_MT_TELM_RWI_PORT_SPEED_10M,
    HAL_MT_TELM_RWI_PORT_SPEED_100M,
    HAL_MT_TELM_RWI_PORT_SPEED_1G,
    HAL_MT_TELM_RWI_PORT_SPEED_2P5G,
    HAL_MT_TELM_RWI_PORT_SPEED_5G,
    HAL_MT_TELM_RWI_PORT_SPEED_LAST
} hal_mt_telm_rwi_port_speed_t;

typedef enum hal_mt_telm_trunc_type_e {
    HAL_MT_TELM_TRUNC_TYPE_INT, /* clone truncate for INT CUD types */
    HAL_MT_TELM_TRUNC_TYPE_MOD, /* clone truncate for MOD CUD type */
    HAL_MT_TELM_TRUNC_TYPE_LAST
} hal_mt_telm_trunc_type_t;

/*********************************************/
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

clx_error_no_t
hal_mt_telm_init(const uint32 unit);

clx_error_no_t
hal_mt_telm_deinit(const uint32 unit);

clx_error_no_t
hal_mt_telm_swc_cfg_set(const uint32 unit,
                        const clx_swc_cfg_t cfg,
                        const uint32 param0,
                        const uint32 param1);

clx_error_no_t
hal_mt_telm_swc_cfg_get(const uint32 unit,
                        const clx_swc_cfg_t cfg,
                        uint32 *ptr_param0,
                        uint32 *ptr_param1);

clx_error_no_t
hal_mt_telm_notify_cb_register(const uint32 unit,
                               const clx_telm_irq_type_t irq_type,
                               const void *callback,
                               void *ptr_cookie);

clx_error_no_t
hal_mt_telm_notify_cb_deregister(const uint32 unit,
                                 const clx_telm_irq_type_t irq_type,
                                 const void *callback,
                                 void *ptr_cookie);

clx_error_no_t
hal_mt_telm_cfg_set(const uint32 unit,
                    const clx_telm_cfg_t cfg,
                    const clx_telm_cfg_param_t *ptr_param);

clx_error_no_t
hal_mt_telm_cfg_get(const uint32 unit, const clx_telm_cfg_t cfg, clx_telm_cfg_param_t *ptr_param);

clx_error_no_t
hal_mt_telm_trunc_set(const uint32 unit,
                      const hal_mt_telm_trunc_type_t truncate_type,
                      const clx_telm_trunc_t *truncate);

clx_error_no_t
hal_mt_telm_trunc_get(const uint32 unit,
                      const hal_mt_telm_trunc_type_t truncate_type,
                      clx_telm_trunc_t *ptr_truncate);

/* ========================= INT api list =========================== */

clx_error_no_t
hal_mt_telm_int_prof_set(const uint32 unit,
                         const uint32 profile_id,
                         const clx_telm_int_prof_t *ptr_profile_cfg);

clx_error_no_t
hal_mt_telm_int_prof_get(const uint32 unit,
                         const uint32 profile_id,
                         clx_telm_int_prof_t *ptr_profile_cfg);

clx_error_no_t
hal_mt_telm_int_glb_set(const uint32 unit,
                        const clx_telm_int_domain_t *ptr_domain_cfg,
                        const clx_telm_int_device_t *ptr_device_cfg);

clx_error_no_t
hal_mt_telm_int_glb_get(const uint32 unit,
                        clx_telm_int_domain_t *ptr_domain_cfg,
                        clx_telm_int_device_t *ptr_device_cfg);

/* ========================= ＭOD api list =========================== */

clx_error_no_t
hal_mt_telm_mod_cfg_get(const uint32 unit, clx_telm_mod_cfg_t *ptr_mod_cfg);

clx_error_no_t
hal_mt_telm_mod_cfg_set(const uint32 unit, const clx_telm_mod_cfg_t *ptr_mod_cfg);

clx_error_no_t
hal_mt_telm_collector_set(const uint32 unit,
                          const clx_telm_collector_type_t collector_type,
                          const clx_telm_collector_cfg_info_t *ptr_clct_cfg_info);

clx_error_no_t
hal_mt_telm_collector_get(const uint32 unit,
                          const clx_telm_collector_type_t collector_type,
                          clx_telm_collector_cfg_info_t *ptr_clct_cfg_info);

clx_error_no_t
hal_mt_telm_collector_clear(const uint32 unit, const clx_telm_collector_type_t collector_type);
/**
 * @brief Port link change notify MOD to modify oq. Only support cpu or eth port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Cl port.
 * @param [in]    drop    - Link status is down, oq set at del port, in order to drop.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_telm_mod_link_chg_notify(const uint32 unit, const uint32 port, const boolean drop);

clx_error_no_t
hal_mt_telm_ioam_fifo_handle(uint32_t unit, void *ptr_data, uint32 data_size, void *ptr_cookies);

clx_error_no_t
hal_mt_telm_mod_nvo3_adj_id_get(const uint32 unit, uint32 *ptr_nvo3_adj_id);
clx_error_no_t
hal_mt_telm_mod_nvo3_encap_id_get(const uint32 unit, uint32 *ptr_nvo3_encap_id);
clx_error_no_t
hal_mt_telm_mod_out_port_get(const uint32 unit, uint32 *ptr_out_port);
clx_error_no_t
hal_mt_telm_mod_out_queue_get(const uint32 unit, uint32 *ptr_out_queue);
clx_error_no_t
hal_mt_telm_hop_cnt_zero_event_trigger(const uint32 unit);
clx_error_no_t
hal_mt_telm_ifa_len_exceed_event_trigger(const uint32 unit);

clx_error_no_t
hal_mt_telm_mod_rate_get(const uint32 unit, uint32 *ptr_rate);
clx_error_no_t
hal_mt_telm_mod_rate_set(const uint32 unit, const uint32 rate);

clx_error_no_t
hal_mt_telm_is_ioam_type_get(const uint32 unit, boolean *ptr_is_ioam_type);

#endif /* End of HAL_MT_TELM_H */
