/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_nfe.h
 * PURPOSE:
 *      It provide API for netflow module.
 * NOTES:
 *
 */
#ifndef HAL_MT_KG_NFE_H
#define HAL_MT_KG_NFE_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <hal/hal.h>
#include <hal/hal_phy.h>
#include <hal/hal_mdio.h>
#include <tob/tob_tbl.h>

#include <stdio.h>
#include <drv/drv_io.h>
#include <osal/osal.h>
#include <hal/mt/kg/hal_mt_kg_led.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MT_KG_NFE_BIT_MSK32(x) (0x1ul << (x))

/* DATA TYPE DECLARATIONS
 */
#define HAL_MT_KG_NFE_IGR_TILE_CNT_DFLT       2
#define HAL_MT_KG_NFE_IGR_TILE_CNT_MAX        4
#define HAL_MT_KG_NFE_FLOW_ENTRY_CNT_PER_TILE 16384
#define HAL_MT_KG_NFE_HASH_KEY_0_BIT_LEN      154
#define HAL_MT_KG_NFE_HASH_KEY_1_BIT_LEN      179
#define HAL_MT_KG_NFE_HASH_KEY_1_FLG_LEN      1
#define HAL_MT_KG_NFE_HASH_KEY_BIT_LEN \
    (HAL_MT_KG_NFE_HASH_KEY_0_BIT_LEN + HAL_MT_KG_NFE_HASH_KEY_1_BIT_LEN)
#define HAL_MT_KG_NFE_HASH_KEY_ARRAY_SIZE \
    ((HAL_MT_KG_NFE_HASH_KEY_0_BIT_LEN + HAL_MT_KG_NFE_HASH_KEY_1_BIT_LEN) / (4 * 8) + 1)
#define HAL_MT_KG_NFE_FLOW_DATA_LEN 84
#define HAL_MT_KG_NFE_HSH_VALID_BIT_OFFSET \
    18 /* due to last 32 bit key value only low 14 bits is valid */

/* define overflow flag */
#define HAL_MT_KG_NFE_OVERFLOW_FLAG_BYTE_CNT      0x01
#define HAL_MT_KG_NFE_OVERFLOW_FLAG_PKT_CNT       0x02
#define HAL_MT_KG_NFE_OVERFLOW_FLAG_TOTAL_Q_OCC   0x04
#define HAL_MT_KG_NFE_OVERFLOW_FLAG_TOTAL_LATENCY 0x08

/* define action type */
#define HAL_MT_KG_NFE_ACTION_TYPE_INVALID  0x00
#define HAL_MT_KG_NFE_ACTION_TYPE_LEARNING 0x01
#define HAL_MT_KG_NFE_ACTION_TYPE_AGING    0x02
#define HAL_MT_KG_NFE_ACTION_TYPE_OVERFLOW 0x03
#define HAL_MT_KG_NFE_ACTION_TYPE_SCAN     0x04
#define HAL_MT_KG_NFE_ACTION_TYPE_CONFLICT 0x05

#define HAL_MT_KG_NFE_HSH_KEY_1X 0x0
#define HAL_MT_KG_NFE_HSH_KEY_2X 0x1

/* define nfe pdma src addr type */
#define HAL_MT_KG_NFE_PDMA_IGR_SRC_ADDR (0x0ac) /* die 0: 0x2efb0ac, die 1: 0xaefb0ac */
#define HAL_MT_KG_NFE_PDMA_EGR_SRC_ADDR (0x100) /* die 0: 0x2efb100, die 1: 0xaefb100 */
#define HAL_MT_KG_NFE_PDMA_SRC_ADDR_MSK (0x1ffLL)

#define HAL_MT_KG_NFE_FLOW_DATA_PKT_CNT_MAX         0x100000000LL
#define HAL_MT_KG_NFE_FLOW_DATA_BYTE_CNT_MAX        0x10000000000LL
#define HAL_MT_KG_NFE_FLOW_DATA_TOTAL_LATENCY_MAX   0x40000000000LL
#define HAL_MT_KG_NFE_FLOW_DATA_TOTAL_QUEUE_OCC_MAX 0x200000000000LL

typedef enum hal_mt_kg_nfe_tnl_type_e {
    HAL_MT_KG_NFE_TNL_TYPE_NONE,
    HAL_MT_KG_NFE_TNL_TYPE_GRE_WITH_KEY,
    HAL_MT_KG_NFE_TNL_TYPE_VXLAN_GBP,
    HAL_MT_KG_NFE_TNL_TYPE_GENEVE_OR_VXLAN_BAS,
    HAL_MT_KG_NFE_TNL_TYPE_LAST,
} hal_mt_kg_nfe_tnl_type_t;

typedef enum hal_mt_kg_nfe_scan_trigger_e {
    HAL_MT_KG_NFE_SCAN_TRIGGER_STOP = 0,
    HAL_MT_KG_NFE_SCAN_TRIGGER_START = 1,
    HAL_MT_KG_NFE_SCAN_TRIGGER_LAST,
} hal_mt_kg_nfe_scan_trigger_t;

typedef enum hal_mt_kg_nfe_scan_opt_e {
    HAL_MT_KG_NFE_SCAN_OPT_AGING,
    HAL_MT_KG_NFE_SCAN_OPT_SCAN,
    HAL_MT_KG_NFE_SCAN_OPT_LAST,
} hal_mt_kg_nfe_scan_opt_t;

/* define nfe scan type */
typedef enum hal_mt_kg_nfe_scan_type_e {
    HAL_MT_KG_NFE_SCAN_TYPE_1X,
    HAL_MT_KG_NFE_SCAN_TYPE_2X,
    HAL_MT_KG_NFE_SCAN_TYPE_LAST,
} hal_mt_kg_nfe_scan_type_t;

typedef struct hal_mt_kg_nfe_scan_info_s {
    uint32 start_idx;
    uint32 end_idx;
} hal_mt_kg_nfe_scan_info_t;

typedef struct hal_mt_kg_nfe_cfg_info_s {
    uint32 igr_tile_cnt;
    hal_mt_kg_nfe_scan_info_t scan_info[CLX_NFE_DIR_LAST];
} hal_mt_kg_nfe_cfg_info_t;

#define HAL_MT_NFE_THD_INTR_YELLOW (0x1 << 0)
#define HAL_MT_NFE_THD_INTR_RED    (0x1 << 1)

/* define L2 key type */
typedef enum hal_mt_kg_nfe_l2_key_type_e {
    HAL_MT_KG_NFE_L2_KEY_VLAN1_PRIO = 0,
    HAL_MT_KG_NFE_L2_KEY_VLAN1_ID = 1,
    HAL_MT_KG_NFE_L2_KEY_VLAN0_PRIO = 2,
    HAL_MT_KG_NFE_L2_KEY_VLAN0_ID = 3,
    HAL_MT_KG_NFE_L2_KEY_LAST_ETYPE = 4,
    HAL_MT_KG_NFE_L2_KEY_MAC_DA = 5,
    HAL_MT_KG_NFE_L2_KEY_MAC_SA = 6,
    HAL_MT_KG_NFE_L2_KEY_LAST,
} hal_mt_kg_nfe_l2_key_type_t;

/* define L3 key type */
typedef enum hal_mt_kg_nfe_l3_key_type_e {
    HAL_MT_KG_NFE_L3_KEY_IP_TTL = 0,
    HAL_MT_KG_NFE_L3_KEY_IP_FRAG = 1,
    HAL_MT_KG_NFE_L3_KEY_ECN = 2,
    HAL_MT_KG_NFE_L3_KEY_VRF = 3,
    HAL_MT_KG_NFE_L3_KEY_IP_OPT1_TYPE = 4,
    HAL_MT_KG_NFE_L3_KEY_IP_OPT0_TYPE = 5,
    HAL_MT_KG_NFE_L3_KEY_IPV6_FLW_LBL = 6,
    HAL_MT_KG_NFE_L3_KEY_IP_DA_0 = 7,
    HAL_MT_KG_NFE_L3_KEY_IP_DA_1 = 8,
    HAL_MT_KG_NFE_L3_KEY_IP_DA_2 = 9,
    HAL_MT_KG_NFE_L3_KEY_IP_DA_3 = 10,
    HAL_MT_KG_NFE_L3_KEY_IP_SA_0 = 11,
    HAL_MT_KG_NFE_L3_KEY_IP_SA_1 = 12,
    HAL_MT_KG_NFE_L3_KEY_IP_SA_2 = 13,
    HAL_MT_KG_NFE_L3_KEY_IP_SA_3 = 14,
    HAL_MT_KG_NFE_L3_KEY_ULP = 15,
    HAL_MT_KG_NFE_L3_KEY_L4_DP = 16,
    HAL_MT_KG_NFE_L3_KEY_L4_SP = 17,
    HAL_MT_KG_NFE_L3_KEY_IP_TOS = 18,
    HAL_MT_KG_NFE_L3_KEY_LAST,
} hal_mt_kg_nfe_l3_key_type_t;

/* define TNL key type */
typedef enum hal_mt_kg_nfe_tnl_key_type_e {
    HAL_MT_KG_NFE_TNL_KEY_GBP_TAG = 0,
    HAL_MT_KG_NFE_TNL_KEY_VNI = 1,
    HAL_MT_KG_NFE_TNL_KEY_LAST,
} hal_mt_kg_nfe_tnl_key_type_t;

/* define common key type */
typedef enum hal_mt_kg_nfe_com_key_type_e {
    HAL_MT_KG_NFE_COM_KEY_QUE_ID = 0,
    HAL_MT_KG_NFE_COM_KEY_L3_DA_LBL = 1,
    HAL_MT_KG_NFE_COM_KEY_L3_SA_LBL = 2,
    HAL_MT_KG_NFE_COM_KEY_L2_DA_LBL = 3,
    HAL_MT_KG_NFE_COM_KEY_L2_SA_LBL = 4,
    HAL_MT_KG_NFE_COM_KEY_BDI = 5,
    HAL_MT_KG_NFE_COM_KEY_INTF_IDX = 6,
    HAL_MT_KG_NFE_COM_KEY_LAST,
} hal_mt_kg_nfe_com_key_type_t;

typedef enum hal_mt_kg_nfe_stats_type_e {
    HAL_MT_KG_NFE_STATS_IGR_IF_IDX = 0,
    HAL_MT_KG_NFE_STATS_EGR_IF_IDX = 1,
    HAL_MT_KG_NFE_STATS_IGR_BDI = 2,
    HAL_MT_KG_NFE_STATS_EGR_BDI = 3,
    HAL_MT_KG_NFE_STATS_START_TS = 4,
    HAL_MT_KG_NFE_STATS_END_TS = 5,
    HAL_MT_KG_NFE_STATS_PKT_CNT = 6,
    HAL_MT_KG_NFE_STATS_BYTE_CNT = 7,
    HAL_MT_KG_NFE_STATS_TOTAL_LATENCY = 8,
    HAL_MT_KG_NFE_STATS_MAX_LATENCY = 9,
    HAL_MT_KG_NFE_STATS_TOTAL_OCCUPANCY = 10,
    HAL_MT_KG_NFE_STATS_MAX_OCCUPANCY = 11,
    HAL_MT_KG_NFE_STATS_LAST,
} hal_mt_kg_nfe_stats_type_t;

#pragma pack(1)
typedef struct hal_mt_kg_nfe_fifo_info_s {
    /* action type */
    uint32 action_type : 3;
    /* overflow flag */
    uint32 overflow_flag : 4;
    /* hash info */
    uint32 key_len_0 : 1;
    uint32 prof_idx : 5;
    uint32 pkt_type : 2;
    uint32 tnl_type : 2;
    uint32 intf_idx : 16;
    uint32 key_0 : 32;
    uint32 key_1 : 32;
    uint32 key_2 : 32;
    uint32 key_3 : 32;
    uint32 key_4 : 32; /* including 1 bit key_len_1 field */
    uint32 key_5 : 32;
    uint32 key_6 : 32;
    uint32 key_7 : 32;
    uint32 key_8 : 32;
    uint32 key_9 : 32;
    uint32 key_10 : 14;
    /* collect info */
    uint32 max_q_occ : 16;
    uint32 total_q_occ_l : 32;
    uint32 total_q_occ_h : 13;
    uint32 max_latency : 16;
    uint32 total_latency_l : 32;
    uint32 total_latency_h : 10;
    uint32 byte_cnt_l : 32;
    uint32 byte_cnt_h : 8;
    uint32 pkt_cnt : 32;
    uint32 flow_start_ts : 32;
    uint32 flow_end_ts : 32;
    uint32 bdi : 14;
    uint32 fwd_status : 4;
    uint32 tcp_flags : 8;
    uint32 overflow : 1;
    uint32 resv2 : 23;
} hal_mt_kg_nfe_fifo_info_t;
#pragma pack()

/* define l3 support pkt type */
typedef enum hal_mt_kg_nfe_pkt_type_e {
    HAL_MT_KG_NFE_L3_TYPE_ALL,
    HAL_MT_KG_NFE_L3_TYPE_IPV4,
    HAL_MT_KG_NFE_L3_TYPE_IPV6,
    HAL_MT_KG_NFE_L3_TYPE_LAST,
} hal_mt_kg_nfe_pkt_type_t;

/* l2 key cfg info */
typedef struct hal_mt_kg_nfe_l2_key_s {
    boolean is_vld;
    uint32 flow_data_type;
} hal_mt_kg_nfe_l2_key_t;

/* l3 key cfg info */
typedef struct hal_mt_kg_nfe_l3_key_s {
    boolean is_vld;
    hal_mt_kg_nfe_pkt_type_t supported_pkt_type;
    uint32 flow_data_type;
} hal_mt_kg_nfe_l3_key_t;

/* tunnel key cfg info */
typedef struct hal_mt_kg_nfe_tnl_key_s {
    boolean is_vld;
    boolean flow_data_set_list[HAL_MT_KG_NFE_TNL_TYPE_LAST];
} hal_mt_kg_nfe_tnl_key_t;

/* common key cfg info */
typedef struct hal_mt_kg_nfe_com_key_s {
    boolean is_vld;
    uint32 flow_data_type;
} hal_mt_kg_nfe_com_key_t;

/* stats info */
typedef struct hal_mt_kg_nfe_stats_s {
    boolean is_vld;
    uint32 flow_data_type;
} hal_mt_kg_nfe_stats_t;

typedef struct hal_mt_kg_nfe_profile_info_s {
    clx_nfe_flow_data_bmp_t flow_data_bmp; /* flow data bitmap */
    hal_mt_kg_nfe_l2_key_t l2_key[HAL_MT_KG_NFE_L2_KEY_LAST];
    hal_mt_kg_nfe_l3_key_t l3_key[HAL_MT_KG_NFE_L3_KEY_LAST];
    hal_mt_kg_nfe_tnl_key_t tnl_key;
    hal_mt_kg_nfe_com_key_t com_key[HAL_MT_KG_NFE_COM_KEY_LAST];
    hal_mt_kg_nfe_stats_t stats[HAL_MT_KG_NFE_STATS_LAST];
} hal_mt_kg_nfe_profile_info_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief This API is used to set threshold.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    dir        - Direction.
 * @param [in]    thd_cfg    - Threshold configuration.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_thd_set(const uint32 unit, const clx_nfe_dir_t dir, const clx_nfe_thd_cfg_t *thd_cfg);

/**
 * @brief This API is used to set long flow interval.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    dir         - Direction.
 * @param [in]    interval    - Long flow interval.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_long_flow_interval_set(const uint32 unit,
                                     const clx_nfe_dir_t dir,
                                     const uint32 interval);

/**
 * @brief This API is used to set scan done interrupt.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    slc          - Slice number.
 * @param [in]    dir          - Direction.
 * @param [in]    is_enable    - Enable or disable interrupt.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_scan_done_intr_set(const uint32 unit,
                                 const uint32 slc,
                                 const clx_nfe_dir_t dir,
                                 const boolean is_enable);

/**
 * @brief This API is used to set yellow thd interrupt.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    slc          - Slice number.
 * @param [in]    dir          - Direction.
 * @param [in]    is_enable    - Enable or disable interrupt.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_yellow_thd_intr_set(const uint32 unit,
                                  const uint32 slc,
                                  const clx_nfe_dir_t dir,
                                  const boolean is_enable);

/**
 * @brief This API is used to set red thd interrupt.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    slc          - Slice number.
 * @param [in]    dir          - Direction.
 * @param [in]    is_enable    - Enable or disable interrupt.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_red_thd_intr_set(const uint32 unit,
                               const uint32 slc,
                               const clx_nfe_dir_t dir,
                               const boolean is_enable);

/**
 * @brief This API is used to get scan done status.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     slc            - Slice number.
 * @param [in]     dir            - Direction.
 * @param [out]    ptr_is_done    - Scan done status.
 * @return         CLX_E_OK               - Successfully.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_scan_status_get(const uint32 unit,
                              const uint32 slc,
                              const clx_nfe_dir_t dir,
                              boolean *ptr_is_done);

/**
 * @brief This API is used to get current flow count.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     dir             - Direction.
 * @param [out]    ptr_flow_cnt    - Current flow count.
 * @return         CLX_E_OK               - Successfully.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_current_flow_cnt_get(const uint32 unit,
                                   const clx_nfe_dir_t dir,
                                   uint32 *ptr_flow_cnt);

/**
 * @brief This API is used to get current flow max count.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     dir             - Direction.
 * @param [out]    ptr_flow_cnt    - Current flow maximum count.
 * @return         CLX_E_OK               - Successfully.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_current_flow_max_cnt_get(const uint32 unit,
                                       const clx_nfe_dir_t dir,
                                       uint32 *ptr_flow_cnt);

/**
 * @brief This API is used to get conflict flow count.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     dir             - Direction.
 * @param [out]    ptr_flow_cnt    - Conflict flow count.
 * @return         CLX_E_OK               - Successfully.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_conflict_flow_cnt_get(const uint32 unit,
                                    const clx_nfe_dir_t dir,
                                    uint32 *ptr_flow_cnt);

/**
 * @brief This API is used to clear conflict flow count.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    dir     - Direction.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_conflict_flow_cnt_clr(const uint32 unit, const clx_nfe_dir_t dir);

/**
 * @brief This API is used to register nfe interrupt callback.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_intr_register(const uint32 unit);

/**
 * @brief This API is used to unregister nfe interrupt callback.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_intr_unregister(const uint32 unit);

/**
 * @brief This API is used to start nfe aging.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    dir     - Direction.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_aging_start(const uint32 unit, const uint32 dir);

/**
 * @brief This API is used to start nfe force aging.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    dir     - Direction.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_force_aging_start(const uint32 unit, const uint32 dir);

/**
 * @brief This API is used to start nfe force aging 2x.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    dir     - Direction.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_force_aging_2x_start(const uint32 unit, const uint32 dir);

/**
 * @brief This API is used to stop nfe aging.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    dir     - Direction.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to stop nfe aging.
 */
clx_error_no_t
hal_mt_kg_nfe_aging_stop(const uint32 unit, const uint32 dir);

/**
 * @brief This API is used to start nfe aging 2x.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    dir     - Direction.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to start nfe aging 2x.
 */
clx_error_no_t
hal_mt_kg_nfe_aging_2x_start(const uint32 unit, const uint32 dir);

/**
 * @brief This API is used to set nfe profile.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    nfe_prof_id     - NFE profile ID.
 * @param [in]    ptr_nfe_info    - NFE profile configuration information.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_prof_cfg_set(const uint32 unit,
                           const uint32 nfe_prof_id,
                           const clx_nfe_prof_cfg_info_t *ptr_nfe_info);

/**
 * @brief This API is used to set nfe default profile.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    nfe_prof_id    - NFE profile ID.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_prof_dflt_set(const uint32 unit, const uint32 nfe_prof_id);

/**
 * @brief Initialize netflow module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_init(const uint32 unit);

/**
 * @brief Deinitialize netflow module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_deinit(const uint32 unit);

/**
 * @brief Get netflow flow data length.
 *
 * @param [in]    unit    - Device unit number.
 * @return        Flow data length in bytes.
 */
uint32
hal_mt_kg_nfe_flow_data_len_get(const uint32 unit);

/**
 * @brief Parse netflow profile key.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    nfe_prof_id    - Netflow profile ID.
 * @param [in]    ptr_nfe_cfg    - Netflow profile configuration information.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_prof_key_psr_proc(const uint32 unit,
                                const uint32 nfe_prof_id,
                                const clx_nfe_prof_cfg_info_t *ptr_nfe_cfg);

/**
 * @brief This API is used to parse flow data.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     src_addr     - Source address.
 * @param [in]     flow_data    - Flow data.
 * @param [out]    dst_addr     - Destination address.
 * @param [out]    dst_len      - Destination length.
 * @return         CLX_E_OK               - Successfully.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_flow_data_psr_proc(const uint32 unit,
                                 const uint64_t src_addr,
                                 const void *flow_data,
                                 uint8 *dst_addr,
                                 uint32 *dst_len);

/**
 * @brief Check if netflow needs batch processing.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Batch processing needed.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_kg_nfe_is_need_batch_process(const uint32 unit);

/**
 * @brief This API is used to start nfe aging.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    dir     - Direction.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to start nfe aging.
 */
clx_error_no_t
hal_mt_kg_nfe_scan_start(const uint32 unit, const uint32 dir);

/**
 * @brief This API is used to start nfe force aging 2x.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    dir     - Direction.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to start nfe force aging 2x.
 */
clx_error_no_t
hal_mt_kg_nfe_scan_2x_start(const uint32 unit, const uint32 dir);
#endif /* HAL_MT_KG_NFE_H */
