/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_cia.h
 * PURPOSE:
 *    Provide HAL driver API functions for CL8570.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_KG_CIA_H
#define HAL_MT_KG_CIA_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_cia.h>
#include <hal/hal_cia.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_KG_CIA_EXACT_FLAGS                              \
    (CLX_CIA_EXACT_GRP_PROF_FLAGS_EXACT_IGNORE_MSK |           \
     CLX_CIA_EXACT_GRP_PROF_FLAGS_EXACT_IGNORE_MSK_WITH_TILE | \
     CLX_CIA_EXACT_GRP_PROF_FLAGS_SELECT_KEY_ENABLE)

#define HAL_MT_KG_CIA_UDF_0_PKG_TLV_BASE_ID (0)

#define HAL_MT_KG_CIA_UDF_PROF_NUM                     (128)
#define HAL_MT_KG_CIA_IGR_CIA_GROUP_LABEL_LSB_VLD_BITS (16)
#define HAL_MT_KG_CIA_REWR_PAGE_NUM                    (32)
#define HAL_MT_KG_CIA_IGR_UCP_DEFAULT_NUM              (24)
#define HAL_MT_KG_CIA_EGR_UCP_DEFAULT_NUM              (8)
#define HAL_MT_KG_CIA_EGR_UCP_32K_NUM                  (32)
#define HAL_MT_KG_CIA_EGR_UCP_28K_NUM                  (28)
#define HAL_MT_KG_CIA_EGR_UCP_24K_NUM                  (24)
#define HAL_MT_KG_CIA_EGR_UCP_16K_NUM                  (16)
#define HAL_MT_KG_CIA_EGR_UCP_12K_NUM                  (12)
#define HAL_MT_KG_CIA_EGR_UCP_8K_NUM                   (8)
#define HAL_MT_KG_CIA_EGR_UCP_0K_NUM                   (0)
#define HAL_MT_KG_CIA_IGR_UCP_32K_NUM                  (32)
#define HAL_MT_KG_CIA_IGR_UCP_28K_NUM                  (28)
#define HAL_MT_KG_CIA_IGR_UCP_24K_NUM                  (24)
#define HAL_MT_KG_CIA_IGR_UCP_16K_NUM                  (16)
#define HAL_MT_KG_CIA_IGR_UCP_8K_NUM                   (8)
#define HAL_MT_KG_CIA_IGR_UCP_4K_NUM                   (4)
#define HAL_MT_KG_CIA_IGR_UCP_0K_NUM                   (0)
#define HAL_MT_KG_CIA_IGR_UCP_NUM                      (24)
#define HAL_MT_KG_CIA_EGR_UCP_NUM                      (8)
#define HAL_MT_KG_CIA_IGR_POST_UCP_NUM                 (0)
#define HAL_MT_KG_CIA_EGR_POST_UCP_NUM                 (0)
#define HAL_MT_KG_CIA_EXACT_UCP_NUM                    (20)
#define HAL_MT_KG_CIA_IGR_GROUP_NUM                    (12)
#define HAL_MT_KG_CIA_EGR_GROUP_NUM                    (4)
#define HAL_MT_KG_CIA_IGR_POST_GROUP_NUM               (0)
#define HAL_MT_KG_CIA_EGR_POST_GROUP_NUM               (0)
#define HAL_MT_KG_CIA_EXACT_GROUP_NUM                  (20)
#define HAL_MT_KG_CIA_UCP_ENTRY_NUM                    (1024)
#define HAL_MT_KG_CIA_UCP_ENTRY_BITS                   (10)
#define HAL_MT_KG_CIA_IGR_PRE_UCP_ENTRY_NUM            (512)
#define HAL_MT_KG_CIA_IGR_PRE_UCP_ENTRY_BITS           (9)
#define HAL_MT_KG_CIA_IGR_ENTRY_NUM                    (HAL_MT_KG_CIA_IGR_UCP_NUM * HAL_MT_KG_CIA_UCP_ENTRY_NUM)
#define HAL_MT_KG_CIA_EGR_ENTRY_NUM                    (HAL_MT_KG_CIA_EGR_UCP_NUM * HAL_MT_KG_CIA_UCP_ENTRY_NUM)

#define HAL_MT_KG_CIA_IGR_PRE_UCP_NUM (4)
#define HAL_MT_KG_CIA_IGR_PRE_ENTRY_NUM \
    (HAL_MT_KG_CIA_IGR_PRE_UCP_NUM * HAL_MT_KG_CIA_IGR_PRE_UCP_ENTRY_NUM)
#define HAL_MT_KG_CIA_IGR_PRE_GROUP_NUM                   (2)
#define HAL_MT_KG_CIA_IGR_PRE_UCP_NUM_ULTRA_LOW_LATENCY   (1)
#define HAL_MT_KG_CIA_IGR_PRE_GROUP_NUM_ULTRA_LOW_LATENCY (1)

#define HAL_MT_KG_CIA_IGR_PRE_ENTRY_1X_BITS (169)
#define HAL_MT_KG_CIA_IGR_PRE_ENTRY_KD_BITS (3)
#define HAL_MT_KG_CIA_IGR_PRE_ENTRY_4X_BITS (4 * HAL_MT_KG_CIA_IGR_PRE_ENTRY_1X_BITS)
#define HAL_MT_KG_CIA_IGR_PRE_ENTRY_4X_BITS_DATA_LEN \
    (HAL_MT_KG_CIA_IGR_PRE_ENTRY_4X_BITS - (4 * HAL_MT_KG_CIA_IGR_PRE_ENTRY_KD_BITS))
#define HAL_MT_KG_CIA_IGR_PRE_ENTRY_FIX_KEY_CMN_BITS  (91 + 184)
#define HAL_MT_KG_CIA_IGR_PRE_ENTRY_FIX_KEY_ARP_BITS  (455)
#define HAL_MT_KG_CIA_IGR_PRE_ENTRY_FIX_KEY_IPV6_BITS (670)
#define HAL_MT_KG_CIA_IGR_PRE_ENTRY_FIX_KEY_IPV4_BITS (458)
#define HAL_MT_KG_CIA_IGR_PRE_ENTRY_FIX_KEY_DATA_BITS (435)
#define HAL_MT_KG_CIA_IGR_PRE_ENTRY_ACTION_NUM_MAX    (2)
#define HAL_MT_KG_CIA_IGR_PRE_MAX_ACTION_TYPE_NUM     (4)
#define HAL_MT_KG_CIA_UDF_KEY_SINGLE_NUM_MAX          (12)

#define HAL_MT_KG_CIA_ACTION_FCM_INST_MAX         (8)
#define HAL_MT_KG_CIA_ACTION_FCM_DEL_BYTE_CNT_MAX (8)
#define HAL_MT_KG_CIA_FCM_TLV_BIDX_MAX            (128)
#define HAL_MT_KG_CIA_FCM_REPAIR_USR_IDX_MAX      (4)
#define HAL_MT_KG_CIA_FCM_REPAIR_BYTE_CNT_MAX     (4)
#define HAL_MT_KG_CIA_FCM_MODIFY_BYTE_CNT_MAX     (4)

#define HAL_MT_KG_CIA_IGR_POST_ENTRY_NUM \
    (HAL_MT_KG_CIA_IGR_POST_UCP_NUM * HAL_MT_KG_CIA_UCP_ENTRY_NUM)
#define HAL_MT_KG_CIA_EGR_POST_ENTRY_NUM \
    (HAL_MT_KG_CIA_EGR_POST_UCP_NUM * HAL_MT_KG_CIA_UCP_ENTRY_NUM)
#define HAL_MT_KG_CIA_TBL_ENTRY_GET(__unit__, __entry_1x_id__, __stage__, __tbl_entry_id__)       \
    do {                                                                                          \
        uint32 ucp_num = 0;                                                                       \
        if ((CLX_CIA_STAGE_IGR == __stage__) || (CLX_CIA_STAGE_IGR_POST == __stage__)) {          \
            __tbl_entry_id__ = __entry_1x_id__;                                                   \
        } else if (CLX_CIA_STAGE_EGR == __stage__) {                                              \
            hal_mt_cia_ucp_num_get(unit, CLX_CIA_STAGE_IGR, &ucp_num);                            \
            __tbl_entry_id__ =                                                                    \
                (__entry_1x_id__ + (ucp_num * PTR_HAL_CONST_INFO(__unit__, cia)->ucp_entry_num)); \
        } else if (CLX_CIA_STAGE_EGR_POST == __stage__) {                                         \
            hal_mt_cia_ucp_num_get(unit, CLX_CIA_STAGE_IGR_POST, &ucp_num);                       \
            __tbl_entry_id__ =                                                                    \
                (__entry_1x_id__ + (ucp_num * PTR_HAL_CONST_INFO(__unit__, cia)->ucp_entry_num)); \
        } else if (CLX_CIA_STAGE_IGR_PRE == __stage__) {                                          \
            __tbl_entry_id__ = __entry_1x_id__;                                                   \
        } else {                                                                                  \
            __tbl_entry_id__ = HAL_INVALID_ID;                                                    \
        }                                                                                         \
    } while (0)

#define HAL_MT_KG_CIA_GET_ENTRY_TBL_ID(__tbl_id__, __stage__, __norm_width__) \
    do {                                                                      \
        if (CLX_CIA_STAGE_IGR_PRE == __stage__) {                             \
            switch ((__norm_width__)) {                                       \
                case (1):                                                     \
                    (__tbl_id__) = MT_KG_TBL_DIS_TCAM_PRECIA_UCP_1X_ID;       \
                    break;                                                    \
                case (2):                                                     \
                    (__tbl_id__) = MT_KG_TBL_DIS_TCAM_PRECIA_UCP_2X_ID;       \
                    break;                                                    \
                default: /* 4 */                                              \
                    (__tbl_id__) = MT_KG_TBL_DIS_TCAM_PRECIA_UCP_4X_ID;       \
                    break;                                                    \
            }                                                                 \
        } else {                                                              \
            switch ((__norm_width__)) {                                       \
                case (1):                                                     \
                    (__tbl_id__) = MT_KG_TBL_CIAT_CIA_TCAM_UCP_1X_ID;         \
                    break;                                                    \
                case (2):                                                     \
                    (__tbl_id__) = MT_KG_TBL_CIAT_CIA_TCAM_UCP_2X_ID;         \
                    break;                                                    \
                default: /* 4 */                                              \
                    (__tbl_id__) = MT_KG_TBL_CIAT_CIA_TCAM_UCP_4X_ID;         \
                    break;                                                    \
            }                                                                 \
        }                                                                     \
    } while (0)

#define HAL_MT_KG_CIA_GET_UCP_VLD_FIELD_ID(__field__, __tbl_id__)         \
    do {                                                                  \
        switch ((__tbl_id__)) {                                           \
            case (MT_KG_TBL_CIAT_CIA_TCAM_UCP_1X_ID):                     \
                (__tbl_id__) = MT_KG_CIAT_CIA_TCAM_UCP_1X_VLD_T_FIELD_ID; \
                break;                                                    \
            case (MT_KG_TBL_CIAT_CIA_TCAM_UCP_2X_ID):                     \
                (__tbl_id__) = MT_KG_CIAT_CIA_TCAM_UCP_2X_VLD_T_FIELD_ID; \
                break;                                                    \
            default: /* MT_NB_TBL_CIAT_CIA_TCAM_UCP_4X_ID */              \
                (__tbl_id__) = MT_KG_CIAT_CIA_TCAM_UCP_4X_VLD_T_FIELD_ID; \
                break;                                                    \
        }                                                                 \
    } while (0)

#define HAL_MT_KG_CIA_SELECT_KEY_SET(__unit__, __keys__, __bits__, __tbl_id__, __field_id__)    \
    do {                                                                                        \
        if (!UTIL_LIB_BIT_CHK(__keys__, __field_id__)) {                                        \
            __bits__ += TOB_TABLE(__unit__, __tbl_id__)->ptr_table_entry[__field_id__].length;  \
        }                                                                                       \
        UTIL_LIB_BIT_SET(__keys__, __field_id__);                                               \
        UTIL_LOG_PRINT(                                                                         \
            UTIL_LOG_CIA, UTIL_LOG_INFO, "u=%u, set select key, tbl=%s, key_fld=%s, bits=%d\n", \
            __unit__, TOB_TABLE(__unit__, __tbl_id__)->ptr_table_name,                          \
            TOB_TABLE(__unit__, __tbl_id__)->ptr_table_entry[__field_id__].ptr_field_name,      \
            __bits__);                                                                          \
    } while (0)

#define HAL_MT_KG_CIA_SELECT_KEY_CHECK(__keys__, __field_id__) \
    ((__field_id__ != HAL_MT_KG_CIA_FIELD_INVALID) && UTIL_LIB_BIT_CHK(__keys__, __field_id__))

#define HAL_MT_KG_CIA_SELECT_KEY_CHECK_RETURN_ERROR(__keys__, __unit__, __tbl_id__, __field_id__)  \
    do {                                                                                           \
        if (__field_id__ == HAL_MT_KG_CIA_FIELD_INVALID) {                                         \
            UTIL_LOG_PRINT(UTIL_LOG_CIA, UTIL_LOG_WARN, "tbl=%s, invalid field_id, not support\n", \
                           TOB_TABLE(__unit__, __tbl_id__)->ptr_table_name);                       \
            return CLX_E_BAD_PARAMETER;                                                            \
        }                                                                                          \
        if (!HAL_MT_KG_CIA_SELECT_KEY_CHECK(__keys__, __field_id__)) {                             \
            UTIL_LOG_PRINT(                                                                        \
                UTIL_LOG_CIA, UTIL_LOG_WARN, "no select key, tbl=%s, key_fld=%s\n",                \
                TOB_TABLE(__unit__, __tbl_id__)->ptr_table_name,                                   \
                TOB_TABLE(__unit__, __tbl_id__)->ptr_table_entry[__field_id__].ptr_field_name);    \
            return CLX_E_BAD_PARAMETER;                                                            \
        }                                                                                          \
    } while (0)

#define HAL_MT_KG_CIA_IGR_PRE_MAX_RSLT_PRIORITY_VAL (3)
#define HAL_MT_KG_CIA_ASSIGN_DI_MAX_BITS            (15)
#define HAL_MT_KG_CIA_ASSIGN_VNI_MAX_BITS           (24)
#define HAL_MT_KG_CIA_ASSIGN_BD_MAX_BITS            (14)
#define HAL_MT_KG_CIA_ASSIGN_VRF_MAX_BITS           (13)
#define HAL_MT_KG_CIA_ASSIGN_UDF_ID_MAX             (11)
#define HAL_MT_KG_CIA_ASSIGN_PKG_VAL_RSH_MAX        (15)
#define HAL_MT_KG_CIA_ASSIGN_PKG_VAL_LSH_MAX        (15)
#define HAL_MT_KG_CIA_QOS_PCP_MAX_BITS              (3)
#define HAL_MT_KG_CIA_QOS_DEI_MAX_BITS              (1)
#define HAL_MT_KG_CIA_QOS_TC_MAX_BITS               (3)
#define HAL_MT_KG_CIA_QOS_ECN_MARK_MAX_BITS         (8)
#define HAL_MT_KG_CIA_VID_MAX_BITS                  (12)
#define HAL_MT_KG_CIA_ACT_HW_TYPE_NONE              (0)

#define HAL_MT_KG_CIA_IGR_PRE_MISC_ACT_CPU_CTL_VAL   (2)
#define HAL_MT_KG_CIA_IGR_PRE_MISC_ACT_DROP_CTL_VAL  (2)
#define HAL_MT_KG_CIA_IGR_PRE_MISC_ACT_IGR_DROP_CODE (321)

/* entry pack action flags */
#define HAL_MT_KG_CIA_IGR_PRE_ENTRY_PACK_ACT_VLAN (1U << 0)
#define HAL_MT_KG_CIA_IGR_PRE_ENTRY_PACK_ACT_UDF  (1U << 1)
#define HAL_MT_KG_CIA_IGR_PRE_ENTRY_PACK_ACT_MISC (1U << 2)
#define HAL_MT_KG_CIA_IGR_PRE_ENTRY_PACK_ACT_QOS  (1U << 3)

/* igr entry action flags */
#define HAL_MT_KG_CIA_IGR_ENTRY_PACK_ACT_NONE        (1U << 0)
#define HAL_MT_KG_CIA_IGR_ENTRY_PACK_ACT_MISC        (1U << 1)
#define HAL_MT_KG_CIA_IGR_ENTRY_PACK_ACT_NFE         (1U << 2)
#define HAL_MT_KG_CIA_IGR_ENTRY_PACK_ACT_RSN         (1U << 3)
#define HAL_MT_KG_CIA_IGR_ENTRY_PACK_ACT_MIR         (1U << 4)
#define HAL_MT_KG_CIA_IGR_ENTRY_PACK_ACT_SFLW        (1U << 5)
#define HAL_MT_KG_CIA_IGR_ENTRY_PACK_ACT_SPARE       (1U << 6)
#define HAL_MT_KG_CIA_IGR_ENTRY_PACK_ACT_CNT_REG0    (1U << 7)
#define HAL_MT_KG_CIA_IGR_ENTRY_PACK_ACT_CNT_REG1    (1U << 8)
#define HAL_MT_KG_CIA_IGR_ENTRY_PACK_ACT_MARK_MTR    (1U << 9)
#define HAL_MT_KG_CIA_IGR_ENTRY_PACK_ACT_POLICER_MTR (1U << 10)
#define HAL_MT_KG_CIA_IGR_ENTRY_PACK_ACT_ECN         (1U << 11)
#define HAL_MT_KG_CIA_IGR_ENTRY_PACK_ACT_PBR         (1U << 12)
#define HAL_MT_KG_CIA_IGR_ENTRY_PACK_ACT_QOS         (1U << 13)
#define HAL_MT_KG_CIA_IGR_ENTRY_PACK_ACT_TELM        (1U << 14)
#define HAL_MT_KG_CIA_IGR_ENTRY_PACK_ACT_LABEL       (1U << 15)

/* egr entry action flags */
#define HAL_MT_KG_CIA_EGR_ENTRY_PACK_ACT_NONE        (1U << 0)
#define HAL_MT_KG_CIA_EGR_ENTRY_PACK_ACT_SPARE0      (1U << 1)
#define HAL_MT_KG_CIA_EGR_ENTRY_PACK_ACT_NFE         (1U << 2)
#define HAL_MT_KG_CIA_EGR_ENTRY_PACK_ACT_RSN         (1U << 3)
#define HAL_MT_KG_CIA_EGR_ENTRY_PACK_ACT_MIR         (1U << 4)
#define HAL_MT_KG_CIA_EGR_ENTRY_PACK_ACT_SFLW        (1U << 5)
#define HAL_MT_KG_CIA_EGR_ENTRY_PACK_ACT_SPARE1      (1U << 6)
#define HAL_MT_KG_CIA_EGR_ENTRY_PACK_ACT_CNT_REG0    (1U << 7)
#define HAL_MT_KG_CIA_EGR_ENTRY_PACK_ACT_CNT_REG1    (1U << 8)
#define HAL_MT_KG_CIA_EGR_ENTRY_PACK_ACT_MARK_MTR    (1U << 9)
#define HAL_MT_KG_CIA_EGR_ENTRY_PACK_ACT_POLICER_MTR (1U << 10)
#define HAL_MT_KG_CIA_EGR_ENTRY_PACK_ACT_ECN         (1U << 11)
#define HAL_MT_KG_CIA_EGR_ENTRY_PACK_ACT_DSCP        (1U << 12)
#define HAL_MT_KG_CIA_EGR_ENTRY_PACK_ACT_QOS         (1U << 13)

#define HAL_MT_KG_CIA_FIELD_INVALID (0xffffffff)

/* pre cia action check flags */
#define HAL_MT_KG_CIA_IGR_PRE_VLAN_ACT_CHECK_FLAGS (CLX_CIA_ACT_FLAGS_VID_ACT_VLD)
#define HAL_MT_KG_CIA_IGR_PRE_UDF_ACT_CHECK_FLAGS \
    (CLX_CIA_ACT_FLAGS_ASSIGN | CLX_CIA_ACT_FLAGS_ECMP_TYPE | CLX_CIA_ACT_FLAGS_HASH)
#define HAL_MT_KG_CIA_IGR_PRE_MISC_ACT_CHECK_FLAGS \
    (CLX_CIA_ACT_FLAGS_COPY_TO_CPU | CLX_CIA_ACT_FLAGS_DROP | CLX_CIA_ACT_FLAGS_VID_ACT_VLD)
#define HAL_MT_KG_CIA_IGR_PRE_QOS_ACT_CHECK_FLAGS \
    (CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_BLIND | CLX_CIA_ACT_FLAGS_PKT_FCM)

#define HAL_MT_KG_CIA_ACTION_FLAGS_IGR_PRE                                                    \
    (HAL_MT_KG_CIA_IGR_PRE_VLAN_ACT_CHECK_FLAGS | HAL_MT_KG_CIA_IGR_PRE_UDF_ACT_CHECK_FLAGS | \
     HAL_MT_KG_CIA_IGR_PRE_MISC_ACT_CHECK_FLAGS | HAL_MT_KG_CIA_IGR_PRE_QOS_ACT_CHECK_FLAGS)

#define HAL_MT_KG_CIA_CHECK_FLAGS_SIMULTANEOUS(__flags__, __simultaneous_flags__) \
    (((__flags__) & (__simultaneous_flags__)) == (__simultaneous_flags__))

/* igr action check flags */
#define HAL_MT_KG_CIA_IGR_MISC_ACTION_CHECK_FLAGS                                                 \
    (CLX_CIA_ACT_FLAGS_XOR_LFSR | CLX_CIA_ACT_FLAGS_VID_ACT_VLD |                                 \
     CLX_CIA_ACT_FLAGS_ALLOW_TRUNCATE | CLX_CIA_ACT_FLAGS_FORCE_DECAP |                           \
     CLX_CIA_ACT_FLAGS_CANCEL_LEARN | CLX_CIA_ACT_FLAGS_KEEP_TTL | CLX_CIA_ACT_FLAGS_TCP_CPA_EN | \
     CLX_CIA_ACT_FLAGS_ECMP_TYPE | CLX_CIA_ACT_FLAGS_HASH | CLX_CIA_ACT_FLAGS_LAG_AR_EN |         \
     CLX_CIA_ACT_FLAGS_GBP_SEL | CLX_CIA_ACT_FLAGS_MOD_STATE)

#define HAL_MT_KG_CIA_IGR_RSN_ACTION_CHECK_FLAGS \
    (CLX_CIA_ACT_FLAGS_COPY_TO_CPU | CLX_CIA_ACT_FLAGS_UDF_RSN_VLD)

#define HAL_MT_KG_CIA_IGR_NFE_ACTION_CHECK_FLAGS                        \
    (CLX_CIA_ACT_FLAGS_NFE | CLX_CIA_ACT_FLAGS_BYPASS_TTL_CHECK_FAIL |  \
     CLX_CIA_ACT_FLAGS_BYPASS_RPF_CHECK_FAIL | CLX_CIA_ACT_FLAGS_DROP | \
     CLX_CIA_ACT_FLAGS_DROP_FORCE | CLX_CIA_ACT_FLAGS_COPY_TO_CPU |     \
     CLX_CIA_ACT_FLAGS_COPY_TO_CPU_FORCE)

#define HAL_MT_KG_CIA_IGR_QOS_ACTION_CHECK_FLAGS                                      \
    (CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_YELLOW | CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_GREEN | \
     CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_RED)
#define HAL_MT_KG_CIA_IGR_ECN_ACTION_CHECK_FLAGS                            \
    (CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_BLIND | CLX_CIA_ACT_FLAGS_HQOS_QUEUE | \
     CLX_CIA_ACT_FLAGS_ECN_EN)
#define HAL_MT_KG_CIA_IGR_PBR_ACTION_CHECK_FLAGS       (CLX_CIA_ACT_FLAGS_REDIR)
#define HAL_MT_KG_CIA_IGR_TELM_ACTION_CHECK_FLAGS      (CLX_CIA_ACT_FLAGS_TELM_ACT_VLD)
#define HAL_MT_KG_CIA_IGR_CIA_LABEL_ACTION_CHECK_FLAGS (CLX_CIA_ACT_FLAGS_PKT_FCM)
#define HAL_MT_KG_CIA_IGR_NFS_ACTION_CHECK_FLAGS       (CLX_CIA_ACT_FLAGS_NFS)

/* igr/egr action check flags */
#define HAL_MT_KG_CIA_SFLW_ACTION_CHECK_FLAGS \
    (CLX_SAMPLE_FLAGS_SAMPLE_TO_MIR | CLX_SAMPLE_FLAGS_EGR_SAMPLE_HIGH_LATENCY)
#define HAL_MT_KG_CIA_SRV_CNT_ACTION_CHECK_FLAGS (CLX_CIA_ACT_FLAGS_COUNTER_VLD)
#define HAL_MT_KG_CIA_MARK_ACTION_CHECK_FLAGS    (CLX_CIA_ACT_FLAGS_METER_VLD)
#define HAL_MT_KG_CIA_POLICER_ACTION_CHECK_FLAGS (CLX_CIA_ACT_FLAGS_MIR_POLICER_VLD)

/* egr action check flags */
#define HAL_MT_KG_CIA_EGR_RSN_ACTION_CHECK_FLAGS \
    (CLX_CIA_ACT_FLAGS_COPY_TO_CPU | CLX_CIA_ACT_FLAGS_UDF_RSN_VLD)

#define HAL_MT_KG_CIA_EGR_NFE_ACTION_CHECK_FLAGS                                     \
    (CLX_CIA_ACT_FLAGS_NFE | CLX_CIA_ACT_FLAGS_DROP | CLX_CIA_ACT_FLAGS_DROP_FORCE | \
     CLX_CIA_ACT_FLAGS_COPY_TO_CPU | CLX_CIA_ACT_FLAGS_COPY_TO_CPU_FORCE)
#define HAL_MT_KG_CIA_EGR_QOS_ACTION_CHECK_FLAGS                                      \
    (CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_YELLOW | CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_GREEN | \
     CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_RED)
#define HAL_MT_KG_CIA_EGR_ECN_ACTION_CHECK_FLAGS \
    (CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_BLIND | CLX_CIA_ACT_FLAGS_ECN_EN)
#define HAL_MT_KG_CIA_EGR_DSCP_ACTION_CHECK_FLAGS                                     \
    (CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_GREEN | CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_YELLOW | \
     CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_RED)

#define HAL_MT_KG_CIA_ACTION_FLAGS_IGR                                                            \
    (HAL_MT_KG_CIA_IGR_MISC_ACTION_CHECK_FLAGS | HAL_MT_KG_CIA_IGR_RSN_ACTION_CHECK_FLAGS |       \
     HAL_MT_KG_CIA_IGR_NFE_ACTION_CHECK_FLAGS | HAL_MT_KG_CIA_IGR_QOS_ACTION_CHECK_FLAGS |        \
     HAL_MT_KG_CIA_IGR_ECN_ACTION_CHECK_FLAGS | HAL_MT_KG_CIA_IGR_PBR_ACTION_CHECK_FLAGS |        \
     HAL_MT_KG_CIA_IGR_TELM_ACTION_CHECK_FLAGS | HAL_MT_KG_CIA_IGR_CIA_LABEL_ACTION_CHECK_FLAGS | \
     HAL_MT_KG_CIA_SFLW_ACTION_CHECK_FLAGS | HAL_MT_KG_CIA_SRV_CNT_ACTION_CHECK_FLAGS |           \
     HAL_MT_KG_CIA_MARK_ACTION_CHECK_FLAGS | HAL_MT_KG_CIA_POLICER_ACTION_CHECK_FLAGS |           \
     HAL_MT_KG_CIA_IGR_NFS_ACTION_CHECK_FLAGS)

#define HAL_MT_KG_CIA_ACTION_FLAGS_EGR                                                     \
    (HAL_MT_KG_CIA_EGR_RSN_ACTION_CHECK_FLAGS | HAL_MT_KG_CIA_EGR_NFE_ACTION_CHECK_FLAGS | \
     HAL_MT_KG_CIA_EGR_QOS_ACTION_CHECK_FLAGS | HAL_MT_KG_CIA_EGR_ECN_ACTION_CHECK_FLAGS | \
     HAL_MT_KG_CIA_EGR_DSCP_ACTION_CHECK_FLAGS | HAL_MT_KG_CIA_SFLW_ACTION_CHECK_FLAGS |   \
     HAL_MT_KG_CIA_SRV_CNT_ACTION_CHECK_FLAGS | HAL_MT_KG_CIA_MARK_ACTION_CHECK_FLAGS |    \
     HAL_MT_KG_CIA_POLICER_ACTION_CHECK_FLAGS)

#define HAL_MT_KG_CIA_ACTION_FLAGS_BLIND_QOS_CHECK_FLAGS_METER_VLD \
    (CLX_CIA_QOS_ACT_FLAGS_QOS_DO_NOT_MODIFY | CLX_CIA_QOS_ACT_FLAGS_REMARK_ECN)

#define HAL_MT_KG_CIA_ACTION_FLAGS_IGR_BLIND_QOS_CHECK_FLAGS                      \
    (CLX_CIA_QOS_ACT_FLAGS_REMARK_TC | CLX_CIA_QOS_ACT_FLAGS_REMARK_COLOR |       \
     CLX_CIA_QOS_ACT_FLAGS_QOS_DO_NOT_MODIFY | CLX_CIA_QOS_ACT_FLAGS_REMARK_ECN | \
     CLX_CIA_QOS_ACT_FLAGS_DROP)

#define HAL_MT_KG_CIA_ACTION_FLAGS_EGR_BLIND_QOS_CHECK_FLAGS                \
    (CLX_CIA_QOS_ACT_FLAGS_REMARK_PCP | CLX_CIA_QOS_ACT_FLAGS_REMARK_DEI |  \
     CLX_CIA_QOS_ACT_FLAGS_REMARK_DSCP | CLX_CIA_QOS_ACT_FLAGS_REMARK_ECN | \
     CLX_CIA_QOS_ACT_FLAGS_DROP)

#define HAL_MT_KG_CIA_ACTION_FLAGS_IGR_COLOR_QOS_CHECK_FLAGS                \
    (CLX_CIA_QOS_ACT_FLAGS_REMARK_TC | CLX_CIA_QOS_ACT_FLAGS_REMARK_COLOR | \
     CLX_CIA_QOS_ACT_FLAGS_DROP)

#define HAL_MT_KG_CIA_ACTION_FLAGS_EGR_COLOR_QOS_CHECK_FLAGS               \
    (CLX_CIA_QOS_ACT_FLAGS_REMARK_PCP | CLX_CIA_QOS_ACT_FLAGS_REMARK_DEI | \
     CLX_CIA_QOS_ACT_FLAGS_REMARK_DSCP | CLX_CIA_QOS_ACT_FLAGS_DROP)

#define HAL_MT_KG_CIA_ACTION_FWD_MSK_SRC_PRUNE (0x01)
#define HAL_MT_KG_CIA_ACTION_FWD_MSK_TTL       (0x06)
#define HAL_MT_KG_CIA_ACTION_FWD_MSK_RPF       (0x18)

#define HAL_MT_KG_CIA_QOS_COLOR_SEL_INFO_MAX (3)

#define HAL_MT_KG_CIA_NFS_MAX_NUM (4)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef enum hal_mt_kg_cia_fcm_op_code_e {
    HAL_MT_KG_CIA_FCM_OP_CODE_DMAC_HI = 0,
    HAL_MT_KG_CIA_FCM_OP_CODE_DMAC_LO = 1,
    HAL_MT_KG_CIA_FCM_OP_CODE_SMAC_HI = 2,
    HAL_MT_KG_CIA_FCM_OP_CODE_SMAC_LO = 3,
    HAL_MT_KG_CIA_FCM_OP_CODE_L2_VLAN0 = 4,
    HAL_MT_KG_CIA_FCM_OP_CODE_L2_VLAN1 = 5,
    HAL_MT_KG_CIA_FCM_OP_CODE_IPV6_DA_3 = 6,
    HAL_MT_KG_CIA_FCM_OP_CODE_IPV6_DA_2 = 7,
    HAL_MT_KG_CIA_FCM_OP_CODE_IPV6_DA_1 = 8,
    HAL_MT_KG_CIA_FCM_OP_CODE_IPV6_DA_0 = 9,
    HAL_MT_KG_CIA_FCM_OP_CODE_IPV6_SA_3 = 10,
    HAL_MT_KG_CIA_FCM_OP_CODE_IPV6_SA_2 = 11,
    HAL_MT_KG_CIA_FCM_OP_CODE_IPV6_SA_1 = 12,
    HAL_MT_KG_CIA_FCM_OP_CODE_IPV6_SA_0 = 13,
    HAL_MT_KG_CIA_FCM_OP_CODE_IPV4_DIP = 14,
    HAL_MT_KG_CIA_FCM_OP_CODE_IPV4_SIP = 15,
    HAL_MT_KG_CIA_FCM_OP_CODE_IPV6_TOS = 16,
    HAL_MT_KG_CIA_FCM_OP_CODE_IPV4_TOS = 17,
    HAL_MT_KG_CIA_FCM_OP_CODE_L4_SPORT = 18,
    HAL_MT_KG_CIA_FCM_OP_CODE_L4_DPORT = 19,
    HAL_MT_KG_CIA_FCM_OP_CODE_PREP_USR = 20,
    HAL_MT_KG_CIA_FCM_OP_CODE_TAP_STRIP = 21,
    HAL_MT_KG_CIA_FCM_OP_CODE_LAST
} hal_mt_kg_cia_fcm_op_code_t;

typedef enum hal_mt_kg_cia_fcm_int_val_e {
    HAL_MT_KG_CIA_FCM_INT_VAL_SI = 0,
    HAL_MT_KG_CIA_FCM_INT_VAL_SRC_BD = 1,
    HAL_MT_KG_CIA_FCM_INT_VAL_MIR_DIR = 2,
    HAL_MT_KG_CIA_FCM_INT_VAL_ITS_H_32 = 3,
    HAL_MT_KG_CIA_FCM_INT_VAL_ITS_L_32 = 4,
    HAL_MT_KG_CIA_FCM_INT_VAL_ETS_H_32 = 5,
    HAL_MT_KG_CIA_FCM_INT_VAL_ETS_L_32 = 6,
    HAL_MT_KG_CIA_FCM_INT_VAL_LATENCY = 7,
    HAL_MT_KG_CIA_FCM_INT_VAL_USR_0 = 8,
    HAL_MT_KG_CIA_FCM_INT_VAL_USR_1 = 9,
    HAL_MT_KG_CIA_FCM_INT_VAL_USR_2 = 10,
    HAL_MT_KG_CIA_FCM_INT_VAL_USR_3 = 11,
    HAL_MT_KG_CIA_FCM_INT_VAL_LAST
} hal_mt_kg_cia_fcm_int_val_t;

typedef enum hal_mt_kg_cia_ipv6_opt_hdr_type_e {
    HAL_MT_KG_CIA_IPV6_OPT_HDR_TYPE_NONE = 0,
    HAL_MT_KG_CIA_IPV6_OPT_HDR_TYPE_AUTH = 1,
    HAL_MT_KG_CIA_IPV6_OPT_HDR_TYPE_HOP_BY_HOP = 2,
    HAL_MT_KG_CIA_IPV6_OPT_HDR_TYPE_FRAG = 3,
    HAL_MT_KG_CIA_IPV6_OPT_HDR_TYPE_RTE = 4,
    HAL_MT_KG_CIA_IPV6_OPT_HDR_TYPE_EXT_0 = 5,
    HAL_MT_KG_CIA_IPV6_OPT_HDR_TYPE_EXT_1 = 6,
    HAL_MT_KG_CIA_IPV6_OPT_HDR_TYPE_EXT_2 = 7,
    HAL_MT_KG_CIA_IPV6_OPT_HDR_TYPE_EXT_3 = 8,
    HAL_MT_KG_CIA_IPV6_OPT_HDR_TYPE_LAST,
} hal_mt_kg_cia_ipv6_opt_hdr_type_t;

typedef enum hal_mt_kg_cia_byte_sel_enum_e {
    HAL_MT_KG_CIA_BYTE_SEL_1B = 0,
    HAL_MT_KG_CIA_BYTE_SEL_2B = 1,
} hal_mt_kg_cia_byte_sel_enum_t;

typedef enum hal_mt_kg_cia_byte_offset_typ_enum_e {
    HAL_MT_KG_CIA_BOFFSET_ENCAP = 0,
    HAL_MT_KG_CIA_BOFFSET_ETH = 1,
    HAL_MT_KG_CIA_BOFFSET_START_L2_SKIP0 = 2,
    HAL_MT_KG_CIA_BOFFSET_START_L2_SKIP1 = 3,
    HAL_MT_KG_CIA_BOFFSET_START_L3_HDR = 4,
    HAL_MT_KG_CIA_BOFFSET_START_L3_OPTION = 5,
    HAL_MT_KG_CIA_BOFFSET_START_L4_HDR = 7,
    HAL_MT_KG_CIA_BOFFSET_END_L4_HDR = 8,
    HAL_MT_KG_CIA_BOFFSET_START_TNL_HDR = 9,
    HAL_MT_KG_CIA_BOFFSET_END_TNL_HDR = 10,
} hal_mt_kg_cia_byte_offset_typ_enum_t;

typedef enum hal_mt_kg_cia_l3_frame_type_e {
    HAL_MT_KG_CIA_L3_FRAME_TYPE_DATA = 0,
    HAL_MT_KG_CIA_L3_FRAME_TYPE_IPV4 = 1,
    HAL_MT_KG_CIA_L3_FRAME_TYPE_IPV6 = 2,
    HAL_MT_KG_CIA_L3_FRAME_TYPE_ARP = 3,
    HAL_MT_KG_CIA_L3_FRAME_TYPE_MPLS = 4,
    HAL_MT_KG_CIA_L3_FRAME_TYPE_LAST
} hal_mt_kg_cia_l3_frame_type_t;

typedef enum hal_mt_kg_cia_igr_pre_act_hw_type_e {
    HAL_MT_KG_CIA_IGR_PRE_ACT_HW_TYPE_NONE = 0,
    HAL_MT_KG_CIA_IGR_PRE_ACT_HW_TYPE_VLAN,
    HAL_MT_KG_CIA_IGR_PRE_ACT_HW_TYPE_UDF,
    HAL_MT_KG_CIA_IGR_PRE_ACT_HW_TYPE_MISC,
    HAL_MT_KG_CIA_IGR_PRE_ACT_HW_TYPE_QOS,
    HAL_MT_KG_CIA_IGR_PRE_ACT_HW_TYPE_LAST
} hal_mt_kg_cia_igr_pre_act_hw_type_t;

typedef enum hal_mt_kg_cia_act_dir_e {
    HAL_MT_KG_CIA_ACT_DIR_INGRESS = 0,
    HAL_MT_KG_CIA_ACT_DIR_EGRESS,
    HAL_MT_KG_CIA_ACT_DIR_LAST
} hal_mt_kg_cia_act_dir_t;

typedef enum hal_mt_kg_cia_igr_act_hw_type_e {
    HAL_MT_KG_CIA_IGR_ACT_HW_TYPE_NONE = 0,
    HAL_MT_KG_CIA_IGR_ACT_HW_TYPE_MISC,
    HAL_MT_KG_CIA_IGR_ACT_HW_TYPE_NFE,
    HAL_MT_KG_CIA_IGR_ACT_HW_TYPE_RSN,
    HAL_MT_KG_CIA_IGR_ACT_HW_TYPE_MIR,
    HAL_MT_KG_CIA_IGR_ACT_HW_TYPE_SFLW,
    HAL_MT_KG_CIA_IGR_ACT_HW_TYPE_SPARE,
    HAL_MT_KG_CIA_IGR_ACT_HW_TYPE_CNT_REG0,
    HAL_MT_KG_CIA_IGR_ACT_HW_TYPE_CNT_REG1,
    HAL_MT_KG_CIA_IGR_ACT_HW_TYPE_MARK_MTR, // remark or drop
    HAL_MT_KG_CIA_IGR_ACT_HW_TYPE_POLICER_MTR,
    HAL_MT_KG_CIA_IGR_ACT_HW_TYPE_ECN,
    HAL_MT_KG_CIA_IGR_ACT_HW_TYPE_PBR,
    HAL_MT_KG_CIA_IGR_ACT_HW_TYPE_QOS, // tc&color
    HAL_MT_KG_CIA_IGR_ACT_HW_TYPE_TELM,
    HAL_MT_KG_CIA_IGR_ACT_HW_TYPE_LABEL
} hal_mt_kg_cia_igr_act_hw_type_t;

typedef enum hal_mt_kg_cia_egr_act_hw_type_e {
    HAL_MT_KG_CIA_EGR_ACT_HW_TYPE_NONE = 0,
    HAL_MT_KG_CIA_EGR_ACT_HW_TYPE_SPARE0, // no use
    HAL_MT_KG_CIA_EGR_ACT_HW_TYPE_NFE,    // for netflow
    HAL_MT_KG_CIA_EGR_ACT_HW_TYPE_RSN,
    HAL_MT_KG_CIA_EGR_ACT_HW_TYPE_MIR,    // same as ICIA
    HAL_MT_KG_CIA_EGR_ACT_HW_TYPE_SFLW,   // same as ICIA
    HAL_MT_KG_CIA_EGR_ACT_HW_TYPE_SPARE1,
    HAL_MT_KG_CIA_EGR_ACT_HW_TYPE_CNT_REG0,
    HAL_MT_KG_CIA_EGR_ACT_HW_TYPE_CNT_REG1,
    HAL_MT_KG_CIA_EGR_ACT_HW_TYPE_MARK_MTR,    // remark or drop
    HAL_MT_KG_CIA_EGR_ACT_HW_TYPE_POLICER_MTR, // same as ICIA
    HAL_MT_KG_CIA_EGR_ACT_HW_TYPE_ECN,
    HAL_MT_KG_CIA_EGR_ACT_HW_TYPE_DSCP,        // mark dscp/exp
    HAL_MT_KG_CIA_EGR_ACT_HW_TYPE_QOS,         // mark pcp_dei
    HAL_MT_KG_CIA_EGR_ACT_HW_TYPE_LAST
} hal_mt_kg_cia_egr_act_hw_type_t;

typedef enum hal_mt_kg_cia_igr_pre_vid_act_type_e {
    HAL_MT_KG_CIA_IGR_PRE_VID_ACT_TYPE_NONE = 0,
    HAL_MT_KG_CIA_IGR_PRE_VID_ACT_TYPE_ASSIGN_VID,
    HAL_MT_KG_CIA_IGR_PRE_VID_ACT_TYPE_ASSIGN_VID_ADD_SVID,
    HAL_MT_KG_CIA_IGR_PRE_VID_ACT_TYPE_ASSIGN_VID_ADD_CVID,
    HAL_MT_KG_CIA_IGR_PRE_VID_ACT_TYPE_LAST
} hal_mt_kg_cia_igr_pre_vid_act_type_t;

typedef enum hal_mt_kg_cia_igr_pre_act_assign_type_e {
    HAL_MT_KG_CIA_IGR_PRE_ACT_ASSIGN_TYPE_NONE = 0,
    HAL_MT_KG_CIA_IGR_PRE_ACT_ASSIGN_TYPE_ASSIGN_DI,
    HAL_MT_KG_CIA_IGR_PRE_ACT_ASSIGN_TYPE_ASSIGN_VNI,
    HAL_MT_KG_CIA_IGR_PRE_ACT_ASSIGN_TYPE_ASSIGN_BD,
    HAL_MT_KG_CIA_IGR_PRE_ACT_ASSIGN_TYPE_ASSIGN_VRF,
    HAL_MT_KG_CIA_IGR_PRE_ACT_ASSIGN_TYPE_LAST
} hal_mt_kg_cia_igr_pre_act_assign_type_t;

typedef enum hal_mt_kg_cia_act_ecmp_type_e {
    HAL_MT_KG_CIA_ACT_ECMP_TYPE_NONE = 0,
    HAL_MT_KG_CIA_ACT_ECMP_TYPE_AR,
    HAL_MT_KG_CIA_ACT_ECMP_TYPE_RR,
    HAL_MT_KG_CIA_ACT_ECMP_TYPE_FDL,
    HAL_MT_KG_CIA_ACT_ECMP_TYPE_LAST
} hal_mt_kg_cia_act_ecmp_type_t;

typedef enum hal_mt_kg_cia_act_qos_color_e {
    HAL_MT_KG_CIA_ACT_QOS_COLOR_GREEN = 0,
    HAL_MT_KG_CIA_ACT_QOS_COLOR_YELLOW = 1,
    HAL_MT_KG_CIA_ACT_QOS_COLOR_RED = 2,
    HAL_MT_KG_CIA_ACT_QOS_COLOR_LAST
} hal_mt_kg_cia_act_qos_color_t;

typedef enum hal_mt_kg_cia_qos_sel_type_e {
    HAL_MT_KG_CIA_QOS_SEL_TYPE_NONE = 0,
    HAL_MT_KG_CIA_QOS_SEL_TYPE_GREEN,
    HAL_MT_KG_CIA_QOS_SEL_TYPE_YELLOW,
    HAL_MT_KG_CIA_QOS_SEL_TYPE_RED,
    HAL_MT_KG_CIA_QOS_SEL_TYPE_LAST
} hal_mt_kg_cia_qos_sel_type_t;

typedef enum hal_mt_kg_cia_igr_pre_act_add_vlan_ctl_e {
    HAL_MT_KG_CIA_IGR_PRE_ACT_ADD_VLAN_CTL_NONE = 0,
    HAL_MT_KG_CIA_IGR_PRE_ACT_ADD_VLAN_CTL_SET,
    HAL_MT_KG_CIA_IGR_PRE_ACT_ADD_VLAN_CTL_CLEAR,
    HAL_MT_KG_CIA_IGR_PRE_ACT_ADD_VLAN_CTL_LAST
} hal_mt_kg_cia_igr_pre_act_add_vlan_ctl_t;

typedef enum hal_mt_kg_cia_igr_pre_act_del_vlan_num_e {
    HAL_MT_KG_CIA_IGR_PRE_ACT_DEL_VLAN_NUM_NONE = 0,
    HAL_MT_KG_CIA_IGR_PRE_ACT_DEL_VLAN_NUM_1,
    HAL_MT_KG_CIA_IGR_PRE_ACT_DEL_VLAN_NUM_2,
    HAL_MT_KG_CIA_IGR_PRE_ACT_DEL_VLAN_NUM_LAST
} hal_mt_kg_cia_igr_pre_act_del_vlan_num_t;

typedef enum hal_mt_kg_cia_pkt_tnl_type_e {
    HAL_MT_KG_CIA_PKT_TNL_TYPE_NONE = 0,
    HAL_MT_KG_CIA_PKT_TNL_TYPE_IP_RAW,
    HAL_MT_KG_CIA_PKT_TNL_TYPE_VXLAN,
    HAL_MT_KG_CIA_PKT_TNL_TYPE_GENEVE,
    HAL_MT_KG_CIA_PKT_TNL_TYPE_GTPU,
    HAL_MT_KG_CIA_PKT_TNL_TYPE_GRE,
    HAL_MT_KG_CIA_PKT_TNL_TYPE_FLEX,
    HAL_MT_KG_CIA_PKT_TNL_TYPE_MPLS,
    HAL_MT_KG_CIA_PKT_TNL_TYPE_LAST
} hal_mt_kg_cia_pkt_tnl_type_t;

typedef enum hal_mt_kg_cia_pkt_vlan_type_e {
    HAL_MT_KG_CIA_PKT_VLAN_TYPE_NO_VLAN = 0,
    HAL_MT_KG_CIA_PKT_VLAN_TYPE_SINGLE_VLAN = 1,
    HAL_MT_KG_CIA_PKT_VLAN_TYPE_TRIPLE_VLAN = HAL_MT_KG_CIA_PKT_VLAN_TYPE_SINGLE_VLAN,
    HAL_MT_KG_CIA_PKT_VLAN_TYPE_DOUBLE_VLAN = 3,
    HAL_MT_KG_CIA_PKT_VLAN_TYPE_QUADRUPLE_VLAN = HAL_MT_KG_CIA_PKT_VLAN_TYPE_DOUBLE_VLAN,
    HAL_MT_KG_CIA_PKT_VLAN_TYPE_LAST
} hal_mt_kg_cia_pkt_vlan_type_t;

typedef enum hal_mt_kg_cia_l2_frm_type_e {
    HAL_MT_KG_CIA_L2_FRM_TYPE_NONE = 0,
    HAL_MT_KG_CIA_L2_FRM_TYPE_ETH = 1,
    HAL_MT_KG_CIA_L2_FRM_TYPE_LLC_OTHER = 2,
    HAL_MT_KG_CIA_L2_FRM_TYPE_RFC1042 = 3,
    HAL_MT_KG_CIA_L2_FRM_TYPE_LAST
} hal_mt_kg_cia_l2_frm_type_t;

/* {frag, 1st_frag} */
typedef enum hal_mt_kg_cia_ip_frg_typ_e {
    HAL_MT_KG_CIA_IP_FRG_NONE = 1,     /* 00 */
    HAL_MT_KG_CIA_IP_FRG_MID_LAST = 2, /* 10 */
    HAL_MT_KG_CIA_IP_FRG_1ST = 3,      /* 11 */
    HAL_MT_KG_CIA_IP_FRG_ALL = 2,      /* 1* */
} hal_mt_kg_cia_ip_frg_typ_t;

typedef enum hal_mt_kg_cia_act_drop_e {
    HAL_MT_KG_CIA_ACT_DROP_NONE = 0,
    HAL_MT_KG_CIA_ACT_DROP_NORMAL,
    HAL_MT_KG_CIA_ACT_DROP_FORCE,
    HAL_MT_KG_CIA_ACT_DROP_CANCEL,
    HAL_MT_KG_CIA_ACT_DROP_LAST
} hal_mt_kg_cia_act_drop_t;

typedef enum hal_mt_kg_cia_act_copy_to_cpu_e {
    HAL_MT_KG_CIA_ACT_COPY_TO_CPU_NONE = 0,
    HAL_MT_KG_CIA_ACT_COPY_TO_CPU_NORMAL,
    HAL_MT_KG_CIA_ACT_COPY_TO_CPU_FORCE,
    HAL_MT_KG_CIA_ACT_COPY_TO_CPU_CANCEL,
    HAL_MT_KG_CIA_ACT_COPY_TO_CPU_LAST
} hal_mt_kg_cia_act_copy_to_cpu_t;

typedef enum hal_mt_kg_cia_act_vid_ctrl_e {
    HAL_MT_KG_CIA_ACT_VID_CTRL_NONE = 0,
    HAL_MT_KG_CIA_ACT_VID_CTRL_KEEP_1,
    HAL_MT_KG_CIA_ACT_VID_CTRL_KEEP_2,
    HAL_MT_KG_CIA_ACT_VID_CTRL_KEEP_LAST
} hal_mt_kg_cia_act_vid_ctrl_t;

typedef enum hal_mt_kg_cia_policy_ucp_grp_e {
    HAL_MT_KG_CIA_POLICY_UCP_GRP_NONE = 0,
    HAL_MT_KG_CIA_POLICY_UCP_GRP_LCL,
    HAL_MT_KG_CIA_POLICY_UCP_GRP_L3_TYPE,
    HAL_MT_KG_CIA_POLICY_UCP_GRP_PKG,
    HAL_MT_KG_CIA_POLICY_UCP_GRP_LAST
} hal_mt_kg_cia_policy_ucp_grp_t;

typedef struct hal_mt_kg_cia_qos_color_sel_info_s {
    hal_mt_kg_cia_qos_sel_type_t sel;
    uint32 tc;
    uint32 color;
    uint32 vld;
    uint32 dscp;
} hal_mt_kg_cia_qos_color_sel_info_t;

/* POLICY TYPE*/
#define HAL_MT_KG_CIA_POLICY_TYPE_NONE (1U << 0)
#define HAL_MT_KG_CIA_POLICY_TYPE_0    (1U << 1)
#define HAL_MT_KG_CIA_POLICY_TYPE_1    (1U << 2)

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
clx_error_no_t
hal_mt_kg_cia_ucp_cfg_set(const uint32 unit,
                          const clx_cia_stage_t stage,
                          const uint32 tbl_id,
                          const uint32 grp_id,
                          const uint32 ucp_id,
                          const hal_cia_ucp_frm_type_t frame_type,
                          uint32 *ptr_buf);

clx_error_no_t
hal_mt_kg_cia_ucp_reset(const uint32 unit,
                        const clx_cia_stage_t stage,
                        const uint32 grp_id,
                        uint32 ucp_bmp);

clx_error_no_t
hal_mt_kg_cia_hw_entry_add(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const uint32 entry_1x_id,
                           const uint32 norm_width,
                           const hal_cmn_cia_plane_bcast_info_t *ptr_bcast_info,
                           uint32 (*ptr_entry_2d_buf)[HAL_CIA_ENTRY_WORDS]);

clx_error_no_t
hal_mt_kg_cia_hw_entry_vld_set(const uint32 unit,
                               const clx_cia_stage_t stage,
                               const uint32 hw_entry_id,
                               const uint32 norm_width,
                               const boolean entry_valid);

clx_error_no_t
hal_mt_kg_cia_hw_entry_read(const uint32 unit,
                            const clx_cia_stage_t stage,
                            const uint32 entry_1x_id,
                            const uint32 norm_width,
                            uint32 (*ptr_entry_2d_buf)[HAL_CIA_ENTRY_WORDS]);

clx_error_no_t
hal_mt_kg_cia_hw_entry_del(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const uint32 entry_1x_id,
                           const uint32 norm_width);

clx_error_no_t
hal_mt_kg_cia_cont_hw_entry_clear(const uint32 unit,
                                  const clx_cia_stage_t stage,
                                  const uint32 start_1x_entry,
                                  const uint32 last_1x_entry);

clx_error_no_t
hal_mt_kg_cia_cfg_init(const uint32 unit);

clx_error_no_t
hal_mt_kg_cia_hw_entry_move(const uint32 unit,
                            const clx_cia_stage_t stage,
                            const uint32 tbl_id,
                            const int32 src_1x_entry_id,
                            const int32 dst_1x_entry_id,
                            const uint32 tot_1x_move_entry_num,
                            const drv_dma_d2d_dir_t d2d_dir,
                            const uint32 shift_cnt,
                            const uint32 cont_move);

clx_error_no_t
hal_mt_kg_cia_move_tbl_id_get(const uint32 unit,
                              const clx_cia_stage_t stage,
                              const uint32 norm_width,
                              uint32 *ptr_tbl_id);

clx_error_no_t
hal_mt_kg_cia_rim_fcm_idx_alloc(const uint32 unit, const uint32 is_flw, uint32 *ptr_index);

clx_error_no_t
hal_mt_kg_cia_rim_fcm_idx_free(const uint32 unit, const uint32 is_flw, const uint32 index);

clx_error_no_t
hal_mt_kg_cia_rim_fcm_act_set(const uint32 unit,
                              const uint32 is_flw,
                              const uint32 index,
                              const void *ptr_action);

clx_error_no_t
hal_mt_kg_cia_rim_fcm_act_get(const uint32 unit,
                              const uint32 is_flw,
                              const uint32 index,
                              const void *ptr_action);

clx_error_no_t
hal_mt_kg_cia_rim_fcm_act_trav(const uint32 unit,
                               const uint32 is_flw,
                               const clx_cia_rim_trav_func_t callback,
                               void *ptr_cookie);

clx_error_no_t
hal_mt_kg_cia_rim_redir_idx_alloc(const uint32 unit,
                                  const clx_cia_rim_alloc_t type,
                                  uint32 *ptr_index);

clx_error_no_t
hal_mt_kg_cia_rim_redir_idx_free(const uint32 unit,
                                 const clx_cia_rim_alloc_t type,
                                 const uint32 a_index);

clx_error_no_t
hal_mt_kg_cia_rim_redir_idx_trav(const uint32 unit,
                                 const clx_cia_rim_alloc_t type,
                                 const clx_cia_rim_trav_func_t callback,
                                 void *ptr_cookie);

clx_error_no_t
hal_mt_kg_cia_rim_nfs_idx_alloc(const uint32 unit, uint32 *ptr_index);

clx_error_no_t
hal_mt_kg_cia_rim_nfs_idx_free(const uint32 unit, const uint32 index);

clx_error_no_t
hal_mt_kg_cia_rim_nfs_idx_set(const uint32 unit, const uint32 index, const void *ptr_action);
clx_error_no_t
hal_mt_kg_cia_rim_nfs_idx_get(const uint32 unit, const uint32 index, void *ptr_action);

clx_error_no_t
hal_mt_kg_cia_rim_nfs_idx_trav(const uint32 unit,
                               const clx_cia_rim_trav_func_t callback,
                               void *ptr_cookie);

clx_error_no_t
hal_mt_kg_cia_ecmp_info_update(const uint32 unit,
                               const uint32 ecmp_group_id,
                               const hal_l3_ecmp_t *ptr_ecmp_info);

clx_error_no_t
hal_mt_kg_cia_cfg_init(const uint32 unit);

clx_error_no_t
hal_mt_kg_cia_grp_enable(const uint32 unit,
                         const clx_cia_stage_t stage,
                         const uint32 group,
                         const uint32 enable);

clx_error_no_t
hal_mt_kg_cia_grp_prof_add(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const uint32 ucp_member_bmp,
                           const uint32 prio,
                           const clx_cia_grp_prof_t *ptr_grp_prof,
                           hal_cia_grp_info_t *ptr_hal_grp_info);
clx_error_no_t
hal_mt_kg_cia_grp_prof_get(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const uint32 group_id,
                           const uint32 ucp_member_bmp,
                           clx_cia_grp_prof_t *ptr_grp_prof);

clx_error_no_t
hal_mt_kg_cia_entry_pack(const uint32 unit,
                         const clx_cia_stage_t stage,
                         const uint32 group,
                         const boolean entry_vld,
                         const clx_cia_classify_t *ptr_classify,
                         const clx_cia_act_t *ptr_action,
                         hal_cia_entry_pack_info_t *ptr_pack_info,
                         hal_cia_entry_alloc_info_t *ptr_alloc_info,
                         hal_cmn_cia_plane_bcast_info_t *ptr_bcast_info,
                         uint32 *ptr_norm_width,
                         uint32 (*ptr_entry_2d_buf)[HAL_CIA_ENTRY_WORDS]);

clx_error_no_t
hal_mt_kg_cia_entry_unpack(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const hal_cia_entry_info_t *ptr_entry_info,
                           boolean *ptr_entry_valid,
                           clx_cia_classify_t *ptr_classify,
                           clx_cia_act_t *ptr_action);
clx_error_no_t
hal_mt_kg_cia_tapping_tpid_set(const uint32 unit, const clx_swc_cfg_t property, const uint32 tpid);

clx_error_no_t
hal_mt_kg_cia_tapping_tpid_get(const uint32 unit, const clx_swc_cfg_t property, uint32 *tpid);

clx_error_no_t
hal_mt_kg_cia_select_key_prof_set(const uint32 unit,
                                  const clx_cia_select_cfg_type_t type,
                                  const uint32 prof_id,
                                  const clx_cia_select_key_prof_t *ptr_prof);

clx_error_no_t
hal_mt_kg_cia_entry_alloc_rsrc_free(const uint32 unit,
                                    const clx_cia_stage_t stage,
                                    const hal_cia_entry_alloc_info_t *ptr_alloc_info);

clx_error_no_t
hal_mt_kg_cia_ucp_to_grp_add(const uint32 unit,
                             const clx_cia_stage_t stage,
                             const uint32 group,
                             const uint32 new_ucp);
clx_error_no_t
hal_mt_kg_cia_adj_info_update(const uint32 unit,
                              const uint32 adj_id,
                              const hal_l3_adj_info_t *ptr_adj_info);

clx_error_no_t
hal_mt_kg_cia_pkt_format_get(const uint32 unit,
                             const clx_cia_stage_t stage,
                             const uint32 udf_prof_id,
                             const hal_cia_udf_info_t *ptr_udf_info,
                             clx_cia_pkt_format_t *ptr_pkt_format);

clx_error_no_t
hal_mt_kg_cia_pkg_lou_prof_idx_get(const uint32 unit,
                                   const clx_cia_stage_t stage,
                                   const uint32 udf_prof_id,
                                   uint32 *ptr_exact_pkg_prof_vld,
                                   uint32 *ptr_exact_pkg_prof_idx,
                                   uint32 *ptr_cia_pkg_prof_vld,
                                   uint32 *ptr_cia_pkg_prof_idx,
                                   uint32 *ptr_lou_prof_vld,
                                   uint32 *ptr_lou_prof_idx);
clx_error_no_t
hal_mt_kg_cia_tcam_pkg_lou_set(const uint32 unit,
                               const clx_cia_stage_t stage,
                               const uint32 udf_key_prof_id,
                               const boolean valid,
                               const clx_cia_pkt_format_t *ptr_pkt_format);
clx_error_no_t
hal_mt_kg_cia_pkg_prof_get(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const uint32 cia_pkg_prof_idx,
                           const uint32 cia_pkg_prof_vld,
                           const hal_cia_udf_info_t *ptr_udf_info,
                           clx_cia_udf_prof_t *ptr_profile);

clx_error_no_t
hal_mt_kg_cia_pkg_prof_set(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const uint32 udf_prof_id,
                           const clx_cia_udf_prof_t *ptr_profile,
                           uint32 *ptr_cia_pkg_vld,
                           uint32 *ptr_pkg_0_cnt,
                           uint32 *ptr_pkg_1_cnt,
                           uint32 *ptr_pkg_0_consecutive_bmp,
                           uint32 *ptr_pkg_1_consecutive_bmp,
                           uint32 *ptr_pkg_valid_bmp);

clx_error_no_t
hal_mt_kg_cia_pkg_prof_reset(const uint32 unit,
                             const clx_cia_stage_t stage,
                             const uint32 udf_prof_id);

clx_error_no_t
hal_mt_kg_cia_exact_pkg_prof_get(const uint32 unit,
                                 const uint32 exact_pkg_prof_idx,
                                 const hal_cia_udf_info_t *ptr_udf_info,
                                 clx_cia_udf_prof_t *ptr_profile);

clx_error_no_t
hal_mt_kg_cia_exact_pkg_prof_set(const uint32 unit,
                                 const uint32 udf_prof_id,
                                 const clx_cia_udf_prof_t *ptr_profile,
                                 uint32 *ptr_exact_pkg_vld,
                                 uint32 *ptr_consecutive_bmp);
clx_error_no_t
hal_mt_kg_cia_exact_pkg_prof_reset(const uint32 unit,
                                   const uint32 udf_prof_id,
                                   hal_cia_udf_info_t *ptr_profile);

clx_error_no_t
hal_mt_kg_cia_range_prof_set(const uint32 unit,
                             const clx_cia_stage_t stage,
                             const uint32 udf_prof_id,
                             const uint32 range_id,
                             const clx_cia_range_cfg_t *ptr_range);
clx_error_no_t
hal_mt_kg_cia_range_prof_get(const uint32 unit,
                             const clx_cia_stage_t stage,
                             const uint32 udf_prof_id,
                             const uint32 range_id,
                             const hal_cia_range_info_t *ptr_range_info,
                             clx_cia_range_cfg_t *ptr_range);
clx_error_no_t
hal_mt_kg_cia_range_prof_clear(const uint32 unit,
                               const clx_cia_stage_t stage,
                               const uint32 udf_prof_id,
                               const uint32 range_id);

clx_error_no_t
hal_mt_kg_cia_rim_rdir_to_l3_mpls_info_get(const uint32 unit,
                                           const uint32 tbl_id,
                                           const uint32 index,
                                           clx_cia_redir_act_t *ptr_redir_action);

clx_error_no_t
hal_mt_kg_cia_rim_rdir_to_l3_mc_info_get(const uint32 unit,
                                         const uint32 tbl_id,
                                         const uint32 index,
                                         const hal_cia_avl_redir_info_t *ptr_avl_redir,
                                         clx_cia_redir_act_t *ptr_redir_action);
clx_error_no_t
hal_mt_kg_cia_rim_rdir_to_l2_info_set(const uint32 unit,
                                      const uint32 tbl_id,
                                      const uint32 index,
                                      const clx_cia_redir_act_t *ptr_redir_action,
                                      hal_cia_avl_redir_info_t *ptr_avl_redir);

clx_error_no_t
hal_mt_kg_cia_rim_rdir_to_l2_uc_info_get(const uint32 unit,
                                         const uint32 tbl_id,
                                         const uint32 index,
                                         const hal_cia_avl_redir_info_t *ptr_avl_redir,
                                         clx_cia_redir_act_t *ptr_redir_action);

clx_error_no_t
hal_mt_kg_cia_rim_rdir_to_l2_mc_info_get(const uint32 unit,
                                         const uint32 tbl_id,
                                         const uint32 index,
                                         const hal_cia_avl_redir_info_t *ptr_avl_redir,
                                         clx_cia_redir_act_t *ptr_redir_action);

clx_error_no_t
hal_mt_kg_cia_rim_rdir_to_l3_mc_info_set(const uint32 unit,
                                         const uint32 tbl_id,
                                         const uint32 index,
                                         const clx_cia_redir_act_t *ptr_redir_action,
                                         hal_cia_avl_redir_info_t *ptr_avl_redir);

clx_error_no_t
hal_mt_kg_cia_rim_rdir_to_l3_mpls_info_set(const uint32 unit,
                                           const uint32 tbl_id,
                                           const uint32 index,
                                           const clx_cia_redir_act_t *ptr_redir_action,
                                           hal_cia_avl_redir_info_t *ptr_avl_redir);

clx_error_no_t
hal_mt_kg_cia_rim_rdir_to_l3_uc_info_set(const uint32 unit,
                                         const uint32 tbl_id,
                                         const uint32 index,
                                         const clx_cia_redir_act_t *ptr_redir_action,
                                         hal_cia_avl_redir_info_t *ptr_avl_redir);

clx_error_no_t
hal_mt_kg_cia_rim_rdir_to_l3_ecmp_info_set(const uint32 unit,
                                           const uint32 tbl_id,
                                           const uint32 index,
                                           const clx_cia_redir_act_t *ptr_redir_action,
                                           hal_cia_avl_redir_info_t *ptr_avl_redir);

clx_error_no_t
hal_mt_kg_cia_nfs_age_trigger(const uint32 unit);

clx_error_no_t
hal_mt_kg_cia_exact_grp_prof_get(const uint32 unit,
                                 const clx_cia_stage_t stage,
                                 const uint32 grp_id,
                                 const uint32 ucp_member_bmp,
                                 clx_cia_exact_grp_prof_t *ptr_grp_prof);

clx_error_no_t
hal_mt_kg_cia_exact_grp_hw_cfg_set(const uint32 unit,
                                   const clx_cia_exact_grp_prof_t *ptr_grp_prof,
                                   const uint32 level);
clx_error_no_t
hal_mt_kg_cia_exact_action_update(const uint32 unit,
                                  const uint32 grp_id,
                                  const uint32 tile_bmp,
                                  uint32 *key_buf,
                                  uint32 fpu_inst,
                                  const uint32 new_rslt_tbl,
                                  uint32 *rslt_buf,
                                  hal_cia_exact_entry_info_t *ptr_entry_info,
                                  uint32 *key_idx,
                                  uint32 *new_rslt_idx);
clx_error_no_t
hal_mt_kg_cia_fpu_four_action_pack(const uint32 unit,
                                   const uint32 new_rslt_idx,
                                   uint32 *fpu_action,
                                   uint32 *fpu_action_type);

clx_error_no_t
hal_mt_kg_cia_exact_key_info_get(const uint32 unit,
                                 const clx_cia_exact_classify_t *ptr_classify,
                                 hal_cia_exact_entry_pack_info_t *ptr_pack_info,
                                 uint32 *ptr_key_tbl);

clx_error_no_t
hal_mt_kg_cia_exact_entry_add(const uint32 unit,
                              const clx_cia_stage_t stage,
                              const uint32 grp_id,
                              const clx_cia_exact_entry_t *ptr_entry_info,
                              uint32 *ptr_entry_id);
clx_error_no_t
hal_mt_kg_cia_exact_entry_get(const uint32 unit,
                              hal_cia_exact_entry_info_t *ptr_entry_info,
                              clx_cia_exact_classify_t *ptr_classify,
                              clx_cia_act_t *ptr_action);

clx_error_no_t
hal_mt_kg_cia_hash_id_to_entry_id_trans(uint32 unit, uint32 hash_idx, uint32 *entry_id);

clx_error_no_t
hal_mt_kg_cia_exact_entry_id_info_get(const uint32 unit,
                                      const uint32 hw_entry_id,
                                      clx_cia_stage_t *ptr_stage,
                                      uint32 *ptr_grp_id);
/**
 * @brief The API is used to set ipv6 extension option type parser.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    type              - Ipv6 extension option type.
 * @param [in]    ptr_type_value    - Ipv6 extension option type value.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_cia_ipv6_opt_hdr_type_psr_get(const uint32 unit,
                                        const clx_cia_ipv6_opt_hdr_type_t type,
                                        uint32 *ptr_type_value);

/**
 * @brief The API is used to set ipv6 extension option type parser.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    type          - Ipv6 extension option type.
 * @param [in]    type_value    - Ipv6 extension option type value.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_cia_ipv6_opt_hdr_type_psr_set(const uint32 unit,
                                        const clx_cia_ipv6_opt_hdr_type_t type,
                                        const uint32 type_value);

#endif /* End of HAL_MT_KG_CIA_H */
