/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   osal_types.h
 * PURPOSE:
 *      Define the commom data type in CLX SDK.
 * NOTES:
 */

#ifndef OSAL_TYPES_H
#define OSAL_TYPES_H
#ifdef __KERNEL__
#include <linux/types.h>
#else
#include <stdint.h>
#endif

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef NULL
#define NULL (void *)0
#endif

#if defined(CLX_EN_HOST_64_BIT_BIG_ENDIAN)
#define UI64_MSW 0
#define UI64_LSW 1
#elif defined(CLX_EN_HOST_64_BIT_LITTLE_ENDIAN)
#define UI64_MSW 1
#define UI64_LSW 0
#else
#define UI64_MSW 1
#define UI64_LSW 0
#endif

#define OSAL_US_PER_SECOND    (1000000)    /* macro second per second      */
#define OSAL_NS_PER_USECOND   (1000)       /* nano second per macro second */
#define OSAL_NS_PER_SECOND    (1000000000) /* nano second per second      */
#define OSAL_TIME_YEAR_OFFSET (1900)

/* DATA TYPE DECLARATIONS
 */
typedef int boolean;
typedef int8_t int8;
typedef uint8_t uint8;
typedef int16_t int16;
typedef uint16_t uint16;
typedef int32_t int32;
typedef uint32_t uint32;

#if defined(CLX_EN_COMPILER_SUPPORT_LONG_LONG)
typedef int64_t int64;
typedef uint64_t uint64;
#else
typedef struct {
    int32 i64[2];
} int64;
typedef struct {
    uint32 ui64[2];
} uint64;
#endif

#if defined(CLX_EN_COMPILER_SUPPORT_LONG_LONG)
#define UI64_HI(dst)                ((uint32)((dst) >> 32))
#define UI64_LOW(dst)               ((uint32)((dst) & 0xffffffff))
#define UI64_ASSIGN(dst, high, low) ((dst) = (((uint64)(high)) << 32 | (uint64)(low)))
#define UI64_SET(dst, src)          ((dst) = (src))
#define UI64_ADD_UI32(dst, src)     ((dst) += ((uint64)(src)))
#define UI64_SUB_UI32(dst, src)     ((dst) -= ((uint64)(src)))
#define UI64_ADD_UI64(dst, src)     ((dst) += (src))
#define UI64_SUB_UI64(dst, src)     ((dst) -= (src))
#define UI64_AND(dst, src)          ((dst) &= (src))
#define UI64_OR(dst, src)           ((dst) |= (src))
#define UI64_XOR(dst, src)          ((dst) ^= (src))
#define UI64_NOT(dst)               ((dst) = ~(dst))
#define UI64_MULT_UI32(dst, src)    ((dst) *= (src))
#define UI64_MULT_UI64(dst, src)    ((dst) *= (src))
/* uint64 type data comparion:
 * if data1 > data2 return 1
 * if data1 < data2 return -1
 * if data1 == data2 return 0
 */
#define UI64_CMP(data1, data2) (((data1) > (data2)) ? 1 : (((data1) < (data2)) ? -1 : 0))

#define I64_HI(dst)                ((int32)((dst) >> 32))
#define I64_LOW(dst)               ((int32)((dst) & 0xffffffff))
#define I64_ASSIGN(dst, high, low) ((dst) = (((int64)(high)) << 32 | (int64)(low)))
#define I64_SET(dst, src)          ((dst) = (src))
#define I64_ADD_UI32(dst, src)     ((dst) += ((int64)(src)))
#define I64_SUB_UI32(dst, src)     ((dst) -= ((int64)(src)))
#define I64_ADD_UI64(dst, src)     ((dst) += (src))
#define I64_SUB_UI64(dst, src)     ((dst) -= (src))
#define I64_AND(dst, src)          ((dst) &= (src))
#define I64_OR(dst, src)           ((dst) |= (src))
#define I64_XOR(dst, src)          ((dst) ^= (src))
#define I64_NOT(dst)               ((dst) = ~(dst))
#define I64_MULT_UI32(dst, src)    ((dst) *= (src))
#define I64_MULT_UI64(dst, src)    ((dst) *= (src))
/* int64 type data comparion:
 * if data1 > data2 return 1
 * if data1 < data2 return -1
 * if data1 == data2 return 0
 */
#define I64_CMP(data1, data2) (((data1) > (data2)) ? 1 : (((data1) < (data2)) ? -1 : 0))
#else
#define UI64_HI(dst)  ((dst).ui64[UI64_MSW])
#define UI64_LOW(dst) ((dst).ui64[UI64_LSW])
#define UI64_ASSIGN(dst, high, low) \
    do {                            \
        UI64_HI(dst) = (high);      \
        UI64_LOW(dst) = (low);      \
    } while (0)

#define UI64_SET(dst, src)             \
    do {                               \
        UI64_HI(dst) = UI64_HI(src);   \
        UI64_LOW(dst) = UI64_LOW(src); \
    } while (0)

#define UI64_ADD_UI32(dst, src)     \
    do {                            \
        uint32 _i_ = UI64_LOW(dst); \
        UI64_LOW(dst) += (src);     \
        if (UI64_LOW(dst) < _i_) {  \
            UI64_HI(dst)++;         \
        }                           \
    } while (0)

#define UI64_SUB_UI32(dst, src)     \
    do {                            \
        uint32 _i_ = UI64_LOW(dst); \
        UI64_LOW(dst) -= src;       \
        if (UI64_LOW(dst) > _i_) {  \
            UI64_HI(dst)--;         \
        }                           \
    } while (0)

#define UI64_ADD_UI64(dst, src)         \
    do {                                \
        uint32 _i_ = UI64_LOW(dst);     \
        UI64_LOW(dst) += UI64_LOW(src); \
        if (UI64_LOW(dst) < _i_) {      \
            UI64_HI(dst)++;             \
        }                               \
        UI64_HI(dst) += UI64_HI(src);   \
    } while (0)

#define UI64_SUB_UI64(dst, src)         \
    do {                                \
        uint32 _i_ = UI64_LOW(dst);     \
        UI64_LOW(dst) -= UI64_LOW(src); \
        if (UI64_LOW(dst) > _i_) {      \
            UI64_HI(dst)--;             \
        }                               \
        UI64_HI(dst) -= UI64_HI(src);   \
    } while (0)

#define UI64_AND(dst, src)              \
    do {                                \
        UI64_HI(dst) &= UI64_HI(src);   \
        UI64_LOW(dst) &= UI64_LOW(src); \
    } while (0)

#define UI64_OR(dst, src)               \
    do {                                \
        UI64_HI(dst) |= UI64_HI(src);   \
        UI64_LOW(dst) |= UI64_LOW(src); \
    } while (0)

#define UI64_XOR(dst, src)              \
    do {                                \
        UI64_HI(dst) ^= UI64_HI(src);   \
        UI64_LOW(dst) ^= UI64_LOW(src); \
    } while (0)

#define UI64_NOT(dst)                   \
    do {                                \
        UI64_HI(dst) = ~UI64_HI(dst);   \
        UI64_LOW(dst) = ~UI64_LOW(dst); \
    } while (0)

/* uint64 type data comparion:
 * if data1 > data2 return 1
 * if data1 < data2 return -1
 * if data1 == data2 return 0
 */
#define UI64_CMP(data1, data2)                                                     \
    (((data1).ui64[UI64_MSW] > (data2).ui64[UI64_MSW]) ?                           \
         1 :                                                                       \
         (((data1).ui64[UI64_MSW] == (data2).ui64[UI64_MSW]) ?                     \
              (((data1).ui64[UI64_LSW] == (data2).ui64[UI64_LSW]) ?                \
                   0 :                                                             \
                   (((data1).ui64[UI64_LSW] > (data2).ui64[UI64_LSW]) ? 1 : -1)) : \
              -1))

#define UI64_MULT_UI64(dst, src)                              \
    do {                                                      \
        uint32 _ret_low_ = 0;                                 \
        uint32 _ret_high_ = 0;                                \
        uint32 _i_ = 0;                                       \
        uint32 _j_ = 0;                                       \
        uint32 _temp_ = 0;                                    \
        uint32 dst_t[4] = {0, 0, 0, 0};                       \
        uint32 src_t[4] = {0, 0, 0, 0};                       \
        dst_t[0] = UI64_LOW(dst) & 0xFFFF;                    \
        dst_t[1] = UI64_LOW(dst) >> 16;                       \
        dst_t[2] = UI64_HI(dst) & 0xFFFF;                     \
        dst_t[3] = UI64_HI(dst) >> 16;                        \
        src_t[0] = UI64_LOW(src) & 0xFFFF;                    \
        src_t[1] = UI64_LOW(src) >> 16;                       \
        src_t[2] = UI64_HI(src) & 0xFFFF;                     \
        src_t[3] = UI64_HI(src) >> 16;                        \
        for (_i_ = 0; _i_ < 4; _i_++) {                       \
            for (_j_ = 0; _j_ < 4; _j_++) {                   \
                if ((dst_t[_i_] != 0) && (src_t[_j_] != 0)) { \
                    _temp_ = dst_t[_i_] * src_t[_j_];         \
                    if (0 == (_i_ + _j_)) {                   \
                        _ret_low_ += _temp_;                  \
                        if (_ret_low_ < _temp_) {             \
                            _ret_high_++;                     \
                        }                                     \
                    }                                         \
                    if (1 == (_i_ + _j_)) {                   \
                        _ret_low_ += (_temp_ << 16);          \
                        if (_ret_low_ < (_temp_ << 16)) {     \
                            _ret_high_++;                     \
                        }                                     \
                        _ret_high_ += (_temp_ >> 16);         \
                    }                                         \
                    if (2 == (_i_ + _j_)) {                   \
                        _ret_high_ += _temp_;                 \
                    }                                         \
                    if (3 == (_i_ + _j_)) {                   \
                        _ret_high_ += (_temp_ << 16);         \
                    }                                         \
                }                                             \
            }                                                 \
        }                                                     \
        UI64_HI(dst) = _ret_high_;                            \
        UI64_LOW(dst) = _ret_low_;                            \
    } while (0)

#define UI64_MULT_UI32(dst, src)                              \
    do {                                                      \
        uint32 _ret_low_ = 0;                                 \
        uint32 _ret_high_ = 0;                                \
        uint32 _i_ = 0;                                       \
        uint32 _j_ = 0;                                       \
        uint32 _temp_ = 0;                                    \
        uint32 dst_t[4] = {0, 0, 0, 0};                       \
        uint32 src_t[2] = {0, 0};                             \
        dst_t[0] = UI64_LOW(dst) & 0xFFFF;                    \
        dst_t[1] = UI64_LOW(dst) >> 16;                       \
        dst_t[2] = UI64_HI(dst) & 0xFFFF;                     \
        dst_t[3] = UI64_HI(dst) >> 16;                        \
        src_t[0] = src & 0xFFFF;                              \
        src_t[1] = src >> 16;                                 \
        for (_i_ = 0; _i_ < 4; _i_++) {                       \
            for (_j_ = 0; _j_ < 2; _j_++) {                   \
                if ((dst_t[_i_] != 0) && (src_t[_j_] != 0)) { \
                    _temp_ = dst_t[_i_] * src_t[_j_];         \
                    if (0 == (_i_ + _j_)) {                   \
                        _ret_low_ += _temp_;                  \
                        if (_ret_low_ < _temp_) {             \
                            _ret_high_++;                     \
                        }                                     \
                    }                                         \
                    if (1 == (_i_ + _j_)) {                   \
                        _ret_low_ += (_temp_ << 16);          \
                        if (_ret_low_ < (_temp_ << 16)) {     \
                            _ret_high_++;                     \
                        }                                     \
                        _ret_high_ += (_temp_ >> 16);         \
                    }                                         \
                    if (2 == (_i_ + _j_)) {                   \
                        _ret_high_ += _temp_;                 \
                    }                                         \
                    if (3 == (_i_ + _j_)) {                   \
                        _ret_high_ += (_temp_ << 16);         \
                    }                                         \
                }                                             \
            }                                                 \
        }                                                     \
        UI64_HI(dst) = _ret_high_;                            \
        UI64_LOW(dst) = _ret_low_;                            \
    } while (0)

#endif

typedef struct osal_timespec_s {
    uint64 sec;  /* second */
    uint64 nsec; /* Nanoseconds.  */
} osal_timespec_t;

#endif /* OSAL_TYPES_H */
