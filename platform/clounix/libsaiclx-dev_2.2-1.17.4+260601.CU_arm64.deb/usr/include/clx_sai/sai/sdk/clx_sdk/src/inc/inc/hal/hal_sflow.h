/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_sflow.h
 * PURPOSE:
 *  Define the declartion for sFlow module.
 *
 * NOTES:
 *
 */

#ifndef HAL_SFLOW_H
#define HAL_SFLOW_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_SFLOW_INVALID_ID (0xFFFFFFFF)

#define HAL_SFLOW_LOW_LATENCY_MODE(__unit__)                         \
    ((HAL_LATENCY_MODE(__unit__) == HAL_LATENCY_MODE_LOW_LATENCY) || \
     (HAL_LATENCY_MODE(__unit__) == HAL_LATENCY_MODE_ULTRA_LOW_LATENCY))

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_sflow_src_type_e {
    /* Caller bind sFlow profile to physical port. */
    HAL_SFLOW_SRC_TYPE_PHY_PORT_IGR,
    HAL_SFLOW_SRC_TYPE_PHY_PORT_EGR,
    HAL_SFLOW_SRC_TYPE_ACL_IGR,
    HAL_SFLOW_SRC_TYPE_ACL_EGR,
    HAL_SFLOW_SRC_TYPE_FLOW_IGR,
    /* Caller use LCL to bind sFlow profile. */
    HAL_SFLOW_SRC_TYPE_LCL_IGR,
    HAL_SFLOW_SRC_TYPE_LCL_EGR,
    /* Caller use BDI to bind sFlow profile/ */
    HAL_SFLOW_SRC_TYPE_BDI_IGR,
    HAL_SFLOW_SRC_TYPE_BDI_EGR,
    HAL_SFLOW_SRC_TYPE_LAST
} hal_sflow_src_type_t;

typedef enum hal_sflow_dst_type_e {
    HAL_SFLOW_DST_TYPE_CPU = 0,     /* sFlow to CPU */
    HAL_SFLOW_DST_TYPE_MIR_SESSION, /* sFlow to mirror session */
    HAL_SFLOW_DST_TYPE_LAST
} hal_sflow_dst_type_t;

typedef struct hal_sflow_profile_s {
    hal_sflow_src_type_t src_type;
    uint32 sampling_rate;
    boolean sample_high_latency;
    hal_sflow_dst_type_t dst_type;
    uint32 mir_session_id;
    uint32 profile_id;
} hal_sflow_profile_t;

/* GLOBAL VARIABLE DECLARATIONS
 */
/* LOCAL SUBPROGRAM DECLARATIONS
 */

clx_error_no_t
hal_sflow_init(const uint32 unit);

clx_error_no_t
hal_sflow_deinit(const uint32 unit);

clx_error_no_t
hal_sflow_profile_add(const uint32 unit,
                      const hal_sflow_src_type_t src_type,
                      const uint32 sampling_rate,
                      const boolean sample_high_latency,
                      const hal_sflow_dst_type_t dst_type,
                      const uint32 mir_session_id,
                      const uint32 old_profile_id,
                      uint32 *ptr_profile_id);

clx_error_no_t
hal_sflow_profile_free(const uint32 unit,
                       const hal_sflow_src_type_t src_type,
                       const uint32 profile_id);

clx_error_no_t
hal_sflow_profile_get(const uint32 unit,
                      const hal_sflow_src_type_t src_type,
                      const uint32 profile_id,
                      boolean *ptr_sample_high_latency,
                      hal_sflow_dst_type_t *ptr_dst_type,
                      uint32 *ptr_mir_session_id,
                      uint32 *ptr_sampling_rate);

clx_error_no_t
hal_sflow_sample_high_latency_thd_set(const uint32 unit, const uint32 thd);

clx_error_no_t
hal_sflow_sample_high_latency_thd_get(const uint32 unit, uint32 *ptr_thd);

clx_error_no_t
hal_sflow_high_latency_cb_get(const uint32 unit,
                              uint32 *high_latency_threshold,
                              uint32 *high_latency_en);

clx_error_no_t
hal_sflow_high_latency_cb_set(const uint32 unit,
                              const uint32 high_latency_threshold,
                              const uint32 high_latency_en);

#endif /* End of HAL_SFLOW_H */
