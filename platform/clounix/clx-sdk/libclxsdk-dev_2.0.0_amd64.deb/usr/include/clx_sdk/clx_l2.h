/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  clx_l2.h
 *
 * PURPOSE:
 *      It provides L2 switching module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_L2_H
#define CLX_L2_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define CLX_L2_MCAST_FLAGS_REPLICATION         (1U << 0)    /* If this flag is set, more than one replications of a packet
                                                            * can be forwarded on a port.
                                                            * If this flag is not set, only one replication of a pakcet
                                                            * can be forwarded on a port.
                                                            */
#define CLX_L2_MCAST_FLAGS_ADD_WITH_ID         (1U << 1)    /* Use the specified multicast ID while creating */
#define CLX_L2_MCAST_FLAGS_BYPASS_LAG_PRUNE    (1U << 2)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef struct CLX_L2_ADDR_S
{
    CLX_BRIDGE_DOMAIN_T    bdid;                            /* Bridge domain ID */
    CLX_MAC_T              mac;                             /* 802.3 MAC address */
    CLX_PORT_T             port;                            /* Port number */
    CLX_VLAN_ACTION_T      action;                          /* CLX_VLAN_ACTION_XXX action */
    CLX_VLAN_T             svid;                            /* Service VLAN ID */
    CLX_VLAN_T             cvid;                            /* Customer VLAN ID */
    UI32_T                 group_label;                     /* ACL label */

#define CLX_L2_ADDR_FLAGS_STATIC               (1U << 0)    /* Set entry static */
#define CLX_L2_ADDR_FLAGS_PENDING              (1U << 1)    /* Set entry pending */
#define CLX_L2_ADDR_FLAGS_DROP                 (1U << 2)    /* Frames which hit this entry will be dropped */
#define CLX_L2_ADDR_FLAGS_SECURE               (1U << 3)    /* Set entry secure */
#define CLX_L2_ADDR_FLAGS_SVID_VALID           (1U << 4)    /* Set entry svid vaild */
#define CLX_L2_ADDR_FLAGS_CVID_VALID           (1U << 5)    /* Set entry cvid vaild */
#define CLX_L2_ADDR_FLAGS_TO_CPU               (1U << 6)    /* Copy to cpu */
#define CLX_L2_ADDR_FLAGS_NO_CALLBACK          (1U << 7)    /* Support when operation mode is polling mode. 
                                                            * The l2 polling events will not be generated if this flag is set. 
                                                            */
#define CLX_L2_ADDR_FLAGS_OVERWRITE_DYNAMIC    (1U << 8)    /* Not supported on CL8360. 
                                                            * Overwrite entry while the hash bucket is full.
                                                            */
    UI32_T                 flags;                           /* CLX_L2_ADDR_FLAGS_XXX flags */
} CLX_L2_ADDR_T;

typedef enum
{
    CLX_L2_ADDR_MATCH_FIELD_STATIC  = (1U << 0),    /* Replace all L2 entries matching given static status */
    CLX_L2_ADDR_MATCH_FIELD_BDID    = (1U << 1),    /* Replace all L2 entries matching given bdid */
    CLX_L2_ADDR_MATCH_FIELD_PORT    = (1U << 2),    /* Replace all L2 entries matching given port */
    CLX_L2_ADDR_MATCH_FIELD_PENDING = (1U << 3),    /* Replace all L2 entries matching given pending status */
    CLX_L2_ADDR_MATCH_FIELD_LAST
} CLX_L2_ADDR_MATCH_FIELD_T;

typedef enum
{
    CLX_L2_ADDR_REPLACE_FIELD_DEL     = (1U << 0),    /* Delete L2 unicast MAC address entries.
                                                      * If this field is set, other fields will be ignored.
                                                      */
    CLX_L2_ADDR_REPLACE_FIELD_STATIC  = (1U << 1),    /* Replace static field */
    CLX_L2_ADDR_REPLACE_FIELD_PENDING = (1U << 2),    /* Replace pending field */
    CLX_L2_ADDR_REPLACE_FIELD_DROP    = (1U << 3),    /* Replace drop field */
    CLX_L2_ADDR_REPLACE_FIELD_SECURE  = (1U << 4),    /* Replace secure field */
    CLX_L2_ADDR_REPLACE_FIELD_PORT    = (1U << 5),    /* Replace port.
                                                      * Need to specify bdid value if port type is ip/trill/nsh tnl.
                                                      */
    CLX_L2_ADDR_REPLACE_FIELD_VLAN    = (1U << 6),    /* Replace action/svid/cvid/SVID_VALID flag/CVID_VALID flag.
                                                      * To replace vlan, need to replace port at the same time.
                                                      */
    CLX_L2_ADDR_REPLACE_FIELD_LAST
} CLX_L2_ADDR_REPLACE_FIELD_T;

typedef enum
{
    CLX_L2_ADDR_NOTIFY_ADD = 0,    /* New entry added in L2 FDB */
    CLX_L2_ADDR_NOTIFY_MODIFY,     /* Entry modified in L2 FDB */
    CLX_L2_ADDR_NOTIFY_DELETE,     /* Entry deleted in L2 FDB */
    CLX_L2_ADDR_NOTIFY_LAST
} CLX_L2_ADDR_NOTIFY_REASON_T;

/* Callback function use for receiving notification about insertions into, 
 * modifications, and deletions from the L2 table dynamically as they occur. 
 */
typedef void
(*CLX_L2_ADDR_NOTIFY_FUNC_T)(
    const UI32_T                         unit,
    const CLX_L2_ADDR_NOTIFY_REASON_T    reason,
    const CLX_L2_ADDR_T                  *ptr_addr,
    void                                 *ptr_cookie);

/* L2 traverse unicast entry callback */
typedef CLX_ERROR_NO_T
(*CLX_L2_ADDR_TRAVERSE_FUNC_T)(
    const UI32_T           unit,
    const CLX_L2_ADDR_T    *ptr_addr,
    void                   *ptr_cookie);

typedef enum
{
    CLX_L2_ADDR_TRAVERSE_MODE_BLOCKING = 0,    /* Traverse blocking mode */
    CLX_L2_ADDR_TRAVERSE_MODE_NON_BLOCKING,    /* Traverse non blocking mode */
    CLX_L2_ADDR_TRAVERSE_MODE_LAST
} CLX_L2_ADDR_TRAVERSE_MODE_T;

typedef enum
{
    CLX_L2_MCAST_EGR_INTF_TYPE_PORT = 0,    /* If use this type,
                                            *  - for uni/nni port, egress s-vlan tag will be removed/added.
                                            *  - for non uni/nni port,
                                            *    egress vlan will be the same as ingress classified vlan.
                                            */
    CLX_L2_MCAST_EGR_INTF_TYPE_L2,          /* If use this type, user can set CLX_VLAN_ACTION_XXX and ETM_HSH_MC_SC_U_FDID will hit. */
    CLX_L2_MCAST_EGR_INTF_TYPE_VM_1BR,
    CLX_L2_MCAST_EGR_INTF_TYPE_VM_NIV,
    CLX_L2_MCAST_EGR_INTF_TYPE_VM_VEPA,
    CLX_L2_MCAST_EGR_INTF_TYPE_NV,
    CLX_L2_MCAST_EGR_INTF_TYPE_TRILL,
    CLX_L2_MCAST_EGR_INTF_TYPE_MPLS,
    CLX_L2_MCAST_EGR_INTF_TYPE_LAST
} CLX_L2_MCAST_EGR_INTF_TYPE_T;

typedef struct CLX_L2_MCAST_EGR_INTF_NV_S
{
    CLX_PORT_T          tnl_port;       /* unicast tunnel */
    CLX_TUNNEL_KEY_T    tnl_key;        /* multicast tunnel */
    UI32_T              nvo3_adj_id;
} CLX_L2_MCAST_EGR_INTF_NV_T;

typedef struct CLX_L2_MCAST_EGR_INTF_TRILL_S
{
    CLX_TRILL_NICKNAME_T    egr_nickname;
    UI32_T                  nvo3_adj_id;
} CLX_L2_MCAST_EGR_INTF_TRILL_T;

typedef struct CLX_L2_MCAST_EGR_INTF_MPLS_S
{
    CLX_PORT_T    pw_port;
} CLX_L2_MCAST_EGR_INTF_MPLS_T;

typedef struct CLX_L2_MCAST_EGR_INTF_S
{
    CLX_L2_MCAST_EGR_INTF_TYPE_T    type;    /* If (type == CLX_L2_MCAST_EGR_INTF_TYPE_PORT),
                                                only the port field should be filled,
                                                the other fileds will be ignored. */
    UI32_T                          port;    /* Port number */
    CLX_BRIDGE_DOMAIN_T             bdid;    /* Bridge domain ID */
    CLX_VLAN_ACTION_T               action;  /* CLX_VLAN_ACTION_XXX action */
    CLX_VLAN_T                      svid;    /* Service VLAN ID */
    CLX_VLAN_T                      cvid;    /* Customer VLAN ID */
    union
    {
        UI32_T                           vm_id;
        CLX_L2_MCAST_EGR_INTF_NV_T       nv;
        CLX_L2_MCAST_EGR_INTF_TRILL_T    trill;
        CLX_L2_MCAST_EGR_INTF_MPLS_T     mpls;
    };
#define CLX_L2_MCAST_EGR_INTF_FLAGS_SVID_VALID    (1U << 0)    /* Set entry svid vaild */
#define CLX_L2_MCAST_EGR_INTF_FLAGS_CVID_VALID    (1U << 1)    /* Set entry cvid vaild */
    UI32_T                          flags;                     /* CLX_L2_MCAST_EGR_INTF_FLAGS_XXX flags */
} CLX_L2_MCAST_EGR_INTF_T;

typedef struct CLX_L2_MCAST_ADDR_S
{
    CLX_BRIDGE_DOMAIN_T    bdid;                           /* Bridge domain ID */
    CLX_MAC_T              mac;                            /* 802.3 mac address */
    UI32_T                 mcast_id;                       /* Multicast ID */
    UI32_T                 group_label;                    /* ACL label */ 
    CLX_VLAN_ACTION_T      action;                         /* CLX_VLAN_ACTION_XXX action. */
    UI32_T                 svid;                           /* Service VLAN ID. */

#define CLX_L2_MCAST_ADDR_FLAGS_DROP          (1U << 0)    /* Frames which hit this entry will be dropped */
#define CLX_L2_MCAST_ADDR_FLAGS_TO_CPU        (1U << 1)    /* copy to cpu */
#define CLX_L2_MCAST_ADDR_FLAGS_SVID_VALID    (1U << 2)    /* Not supported on CL8360, used for qinq */
    UI32_T                 flags;                          /* CLX_L2_MCAST_ADDR_FLAGS_XXX flags */
} CLX_L2_MCAST_ADDR_T;

/* L2 traverse multicast entry callback */
typedef CLX_ERROR_NO_T
(*CLX_L2_MCAST_ADDR_TRAVERSE_FUNC_T)(
    const UI32_T                 unit,
    const CLX_L2_MCAST_ADDR_T    *ptr_addr,
    void                         *ptr_cookie);

typedef struct CLX_L2_IP_MCAST_GROUP_S
{
    CLX_BRIDGE_DOMAIN_T    bdid;                          /* Bridge domain ID */
    CLX_IP_ADDR_T          grp_ip;                        /* Multicast group IP */ 
    CLX_IP_ADDR_T          src_ip;                        /* Value of grp_ip.ipv4 and src_ip.ipv4 should synchornized.
                                                          * If src_ip.ip_addr is all zero, use group only.
                                                          */
    UI32_T                 mcast_id;                      /* Multicast ID */
    UI32_T                 group_label;                   /* ACL label */ 
    UI32_T                 svid;                          /* Service VLAN ID */

#define CLX_L2_IP_MCAST_GROUP_FLAGS_DROP          (1U << 0)    /* Frames which hit this entry will be dropped */
#define CLX_L2_IP_MCAST_GROUP_FLAGS_TO_CPU        (1U << 1)    /* copy to cpu */
#define CLX_L2_IP_MCAST_GROUP_FLAGS_SVID_VALID    (1U << 2)    /* Not supported on CL8360, used for qinq */
    UI32_T                 flags;                              /* CLX_L2_IP_MCAST_GROUP_FLAGS_XXX flags */
} CLX_L2_IP_MCAST_GROUP_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   clx_l2_addAddr
 * PURPOSE:
 *      This API is used to add/set a L2 unicast MAC address entry.<CL>
 *      If the address entry does not exist, it will add the entry;
 *      if the address entry already exists, it will set the entry with user input value.
 * INPUT:
 *      unit      --  Device unit number
 *      ptr_addr  --  The L2 address entry to be added/set
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_addAddr(
    const UI32_T           unit,
    const CLX_L2_ADDR_T    *ptr_addr);

/* FUNCTION NAME:   clx_l2_delAddr
 * PURPOSE:
 *      This API is used to delete a L2 unicast MAC address entry.
 * INPUT:
 *      unit      --  Device unit number
 *      ptr_addr  --  The L2 address entry to be deleted.
 *                    User should only fill the key fields "bdid" and "mac". The other fields will be ignored.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_delAddr(
    const UI32_T           unit,
    const CLX_L2_ADDR_T    *ptr_addr);

/* FUNCTION NAME:   clx_l2_getAddr
 * PURPOSE:
 *      This API is used to get a L2 unicast MAC address entry.
 * INPUT:
 *      unit      --  Device unit number
 *      ptr_addr  --  The L2 address entry to be obtained.
 *                    User should only fill the key fields "bdid" and "mac". The other fields will be ignored.
 * OUTPUT:
 *      ptr_addr  --  The fully filled L2 address entry obtained.
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_getAddr(
    const UI32_T     unit,
    CLX_L2_ADDR_T    *ptr_addr);

/* FUNCTION NAME:   clx_l2_replaceAddr
 * PURPOSE:
 *      This API is used to replace L2 unicast MAC address entries which match the specified criteria
 *      with the newly specified values.
 * INPUT:
 *      unit              --  Device unit number
 *      match_field       --  Indicate which fields of L2 uncast MAC address entry are used to match the given
 *                            "ptr_match_addr". User can choose one or more fields to do matching.
 *                            Refer to CLX_L2_ADDR_MATCH_FIELD_XXX.
 *      ptr_match_addr    --  Specify the values of matched fields used to perform matching.
 *                            User need to input values of these fields which are chosen by "match_field" parameter.
 *      replace_field     --  Indicate which fields' values will be replaced with new values.
 *                            Refer to CLX_L2_ADDR_REPLACE_FIELD_XXX.
 *      ptr_replace_addr  --  Specify the new values used to replace the old values for the matched MAC address entries.
 *                            User need to input values of these fields which are chosen by "replace_field" parameter.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      When user specifies the "replace_field" with CLX_L2_ADDR_REPLACE_FIELD_DEL set,
 *      other values which are included by "replace_field" parameter will be ignored,
 *      and the parameter "ptr_replace_addr" can be NULL.
 */
CLX_ERROR_NO_T
clx_l2_replaceAddr(
    const UI32_T           unit,
    const UI32_T           match_field,
    const CLX_L2_ADDR_T    *ptr_match_addr,
    const UI32_T           replace_field,
    const CLX_L2_ADDR_T    *ptr_replace_addr);

/* FUNCTION NAME:   clx_l2_traverseAddr
 * PURPOSE:
 *      This API is used to traverse all the L2 unicast MAC address entries, and handle it by user's callback.
 * INPUT:
 *      unit        --  Device unit number
 *      mode        --  The L2 traverse mode. Refer to CLX_L2_ADDR_TRAVERSE_MODE_XXX.
 *      callback    --  The callback function to be called when each L2 address entry is traversed
 *      ptr_cookie  --  The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie  --  The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_traverseAddr(
    const UI32_T                         unit,
    const CLX_L2_ADDR_TRAVERSE_MODE_T    mode,
    const CLX_L2_ADDR_TRAVERSE_FUNC_T    callback,
    void                                 *ptr_cookie);

/* FUNCTION NAME:   clx_l2_registerAddrNotifyCallback
 * PURPOSE:
 *      This API is used to register a callback function that will be called
 *      whenever the L2 unicast MAC address table is updated.
 * INPUT:
 *      unit        --  Device unit number
 *      callback    --  The callback function of type CLX_L2_ADDR_NOTIFY_FUNC_T
 *      ptr_cookie  --  The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie  --  The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_registerAddrNotifyCallback(
    const UI32_T                       unit,
    const CLX_L2_ADDR_NOTIFY_FUNC_T    callback,
    void                               *ptr_cookie);

/* FUNCTION NAME:   clx_l2_deregisterAddrNotifyCallback
 * PURPOSE:
 *      This API is used to degister a callback function that will be called
 *      whenever the L2 unicast MAC address table is updated.
 * INPUT:
 *      unit        --  Device unit number
 *      callback    --  The callback function of type CLX_L2_ADDR_NOTIFY_FUNC_T
 *      ptr_cookie  --  The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie  --  The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_deregisterAddrNotifyCallback(
    const UI32_T                       unit,
    const CLX_L2_ADDR_NOTIFY_FUNC_T    callback,
    void                               *ptr_cookie);

/* FUNCTION NAME:   clx_l2_addMcastId
 * PURPOSE:
 *      This API is used to add a L2 multicast ID. <CL>
 *      After the L2 multicast ID is added, L2 multicast egress interfaces can be added to it.
 *      If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is set, this API will add L2 multicast ID with the ID pointed by ptr_mcast_id;
 *      if CLX_L2_MCAST_FLAGS_ADD_WITH_ID is not set, this API will allocate a L2 multicast ID.
 * INPUT:
 *      unit          --  Device unit number
 *      flags         --  The L2 multicast flags. Refer to CLX_L2_MCAST_FLAGS_XXX.
 *      ptr_mcast_id  --  If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is set,
 *                        this field specifies the L2 multicast ID to be added.
 * OUTPUT:
 *      ptr_mcast_id  --  If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is not set,
 *                        this field specifies the allocated L2 multicast ID.
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_addMcastId(
    const UI32_T    unit,
    const UI32_T    flags,
    UI32_T          *ptr_mcast_id);

/* FUNCTION NAME:   clx_l2_delMcastId
 * PURPOSE:
 *      This API is used to delete a L2 multicast ID.
 * INPUT:
 *      unit      --  Device unit number
 *      mcast_id  --  The L2 multicast ID to be deleted
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_delMcastId(
    const UI32_T    unit,
    const UI32_T    mcast_id);

/* FUNCTION NAME:   clx_l2_getMcastId
 * PURPOSE:
 *      This API is used to get a L2 multicast ID.
 * INPUT:
 *      unit         --  Device unit number
 *      mcast_id     --  The L2 multicast ID to be obtained
 * OUTPUT:
 *      ptr_flags    --  The L2 multicast flags. Refer to CLX_L2_MCAST_FLAGS_XXX.
 *      port_bitmap  --  The egress port bitmap
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_getMcastId(
    const UI32_T         unit,
    const UI32_T         mcast_id,
    UI32_T               *ptr_flags,
    CLX_PORT_BITMAP_T    port_bitmap);

/* FUNCTION NAME:   clx_l2_addMcastEgrIntf
 * PURPOSE:
 *      This API is used to add egress interface for a L2 multicast ID.
 * INPUT:
 *      unit          --  Device unit number
 *      mcast_id      --  The L2 multicast ID
 *      egr_intf_cnt  --  The number of egress interfaces to be added
 *      ptr_egr_intf  --  The egress interface list to be added
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_addMcastEgrIntf(
    const UI32_T                     unit,
    const UI32_T                     mcast_id,
    const UI32_T                     egr_intf_cnt,
    CLX_L2_MCAST_EGR_INTF_T          *ptr_egr_intf);

/* FUNCTION NAME:   clx_l2_delMcastEgrIntf
 * PURPOSE:
 *      This API is used to delete egress interface for a L2 multicast ID.
 * INPUT:
 *      unit          --  Device unit number
 *      mcast_id      --  The L2 multicast ID
 *      egr_intf_cnt  --  The number of egress interfaces to be deleted
 *      ptr_egr_intf  --  The egress interface list to be deleted.
 *                        If CLX_L2_MCAST_FLAGS_REPLICATION of the L2 multicast ID is not set,
 *                        user should only fill the "type", "bdid" and "port" fields,
 *                        and the other fields will be ignored.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_delMcastEgrIntf(
    const UI32_T                     unit,
    const UI32_T                     mcast_id,
    const UI32_T                     egr_intf_cnt,
    CLX_L2_MCAST_EGR_INTF_T          *ptr_egr_intf);

/* FUNCTION NAME:   clx_l2_getMcastEgrIntfCnt
 * PURPOSE:
 *      This API is used to get egress interface count for a L2 multicast ID.
 * INPUT:
 *      unit              --  Device unit number
 *      mcast_id          --  The L2 multicast ID
 * OUTPUT:
 *      ptr_egr_intf_cnt  --  The egress interface count
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_getMcastEgrIntfCnt(
    const UI32_T    unit,
    const UI32_T    mcast_id,
    UI32_T          *ptr_egr_intf_cnt);

/* FUNCTION NAME:   clx_l2_getMcastEgrIntf
 * PURPOSE:
 *      This API is used to get egress interface for a L2 multicast ID.
 * INPUT:
 *      unit                     --  Device unit number
 *      mcast_id                 --  The L2 multicast ID
 *      egr_intf_cnt             --  The number of egress interfaces to be get
 * OUTPUT:
 *      ptr_egr_intf             --  The egress interface list obtained
 *      ptr_actual_egr_intf_cnt  --  The actual number of egress interface obtained
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_getMcastEgrIntf(
    const UI32_T               unit,
    const UI32_T               mcast_id,
    const UI32_T               egr_intf_cnt,
    CLX_L2_MCAST_EGR_INTF_T    *ptr_egr_intf,
    UI32_T                     *ptr_actual_egr_intf_cnt);

/* FUNCTION NAME:   clx_l2_addMcastAddr
 * PURPOSE:
 *      This API is used to add/set a L2 multicast MAC address entry.<CL>
 *      If the multicast address entry does not exist, it will add the entry;
 *      if the multicast address entry already exists, it will set the entry with user input value.
 * INPUT:
 *      unit      --  Device unit number
 *      ptr_addr  --  The L2 multicast address entry to be added/set
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_addMcastAddr(
    const UI32_T                 unit,
    const CLX_L2_MCAST_ADDR_T    *ptr_addr);

/* FUNCTION NAME:   clx_l2_delMcastAddr
 * PURPOSE:
 *      This API is used to delete a L2 multicast address entry.
 * INPUT:
 *      unit      --  Device unit number
 *      ptr_addr  --  The L2 multicast entry to be deleted.
 *                    User should only fill the key fields "bdid" and "mac". The other fields will be ignored.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_delMcastAddr(
    const UI32_T                 unit,
    const CLX_L2_MCAST_ADDR_T    *ptr_addr);

/* FUNCTION NAME:   clx_l2_getMcastAddr
 * PURPOSE:
 *      This API is used to get a L2 multicast address entry.
 * INPUT:
 *      unit      --  Device unit number
 *      ptr_addr  --  The L2 multicast address entry to be obtained.
 *                    User should only fill the key fields "bdid" and "mac". The other fields will be ignored.
 * OUTPUT:
 *      ptr_addr  --  The full filled L2 multicast address entry obtained
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_getMcastAddr(
    const UI32_T           unit,
    CLX_L2_MCAST_ADDR_T    *ptr_addr);

/* FUNCTION NAME:   clx_l2_traverseMcastAddr
 * PURPOSE:
 *      This API is used to traverse all the L2 multicast MAC address entries, and handle it by user's callback.
 * INPUT:
 *      unit        --  Device unit number
 *      mode        --  The L2 traverse mode. Refer to CLX_L2_ADDR_TRAVERSE_MODE_XXX.
 *      callback    --  The callback function to be called when each L2 multicast address entry is traversed
 *      ptr_cookie  --  The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie  --  The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_traverseMcastAddr(
    const UI32_T                               unit,
    const CLX_L2_ADDR_TRAVERSE_MODE_T          mode,
    const CLX_L2_MCAST_ADDR_TRAVERSE_FUNC_T    callback,
    void                                       *ptr_cookie);

/* FUNCTION NAME:   clx_l2_addIpMcastGroup
 * PURPOSE:
 *      This API is used to add/set a L2 IP multicast group entry.<CL>
 *      If the IP multicast entry does not exist, it will add the entry;
 *      if the IP multicast entry already exists, it will set the entry with user input value.
 * INPUT:
 *      unit       --  Device unit number
 *      ptr_group  --  The IP multicast entry to be added/set
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_addIpMcastGroup(
    const UI32_T                     unit,
    const CLX_L2_IP_MCAST_GROUP_T    *ptr_group);

/* FUNCTION NAME:   clx_l2_delIpMcastGroup
 * PURPOSE:
 *      This API is used to delete a L2 IP multicast group entry.
 * INPUT:
 *      unit       --  Device unit number
 *      ptr_group  --  The L2 IP multicast entry to be deleted.
                       User should only fill the key fields "bdid", "grp_ip" and "src_ip". Other fields will be ignored.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_delIpMcastGroup(
    const UI32_T                     unit,
    const CLX_L2_IP_MCAST_GROUP_T    *ptr_group);

/* FUNCTION NAME:   clx_l2_getIpMcastGroup
 * PURPOSE:
 *      This API is used to get a L2 IP multicast group entry.
 * INPUT:
 *      unit       --  Device unit number
 *      ptr_group  --  The L2 IP multicast entry to be obtained.
                       User should only fill the key fields "bdid", "grp_ip" and "src_ip". Other fields will be ignored.
 * OUTPUT:
 *      ptr_group  --  The full filled L2 IP multicast entry obtained
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l2_getIpMcastGroup(
    const UI32_T               unit,
    CLX_L2_IP_MCAST_GROUP_T    *ptr_group);

#endif  /* End of CLX_L2_H */

