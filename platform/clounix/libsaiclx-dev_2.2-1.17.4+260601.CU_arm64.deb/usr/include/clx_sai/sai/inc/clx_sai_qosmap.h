/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_QOSMAP_H__)
#define __CLX_SAI_QOSMAP_H__


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_QOSMAP_MAX_TC_COUNT_DEFAULT            (16)
#define CLXS_QOSMAP_MAX_USER_TC                     (7)
#define CLXS_QOSMAP_MIN_USER_TC                     (0)
#define CLXS_QOSMAP_MAX_PFC_COUNT                   (8)
#define CLXS_QOSMAP_MAX_DOT1P_COUNT                 (8)

#if SAI_API_VERSION >= SAI_VERSION(1,7,0)
#define CLXS_QOSMAP_MAX_EXP_COUNT                   (8)    /* 3 bit EXP in MPLS Lable */
#endif
#define CLXS_QOSMAP_MAX_DSCP_COUNT                  (64)
#define CLXS_QOSMAP_MAX_COLOR_COUNT                 (3)
#if SAI_API_VERSION >= SAI_VERSION(1,9,0)
#define CLXS_QOSMAP_TYPES_MAX                       (SAI_QOS_MAP_TYPE_MPLS_EXP_TO_FORWARDING_CLASS+5)
#else
#define CLXS_QOSMAP_TYPES_MAX                       (SAI_QOS_MAP_TYPE_TC_AND_COLOR_TO_MPLS_EXP+5)
#endif
/* 0 reserved by SDK */
#define CLXS_QOSMAP_PROFILE_OFFSET                      (1)
#define CLXS_QOSMAP_PROFILE_VALUE_INVALID               (0xFFFFFFFF)
#define CLXS_QOSMAP_PROFILE_VALUE_DEFAULT               (0)

#define CLXS_QOSMAP_TYPE_PHB_INGRESS_TO_TC(__type__)    \
                                                    (((__type__ == SAI_QOS_MAP_TYPE_DOT1P_TO_TC ) || \
                                                        (__type__ == SAI_QOS_MAP_TYPE_DSCP_TO_TC) || \
                                                        (__type__ == SAI_QOS_MAP_TYPE_MPLS_EXP_TO_TC))? 1 : 0)

#define CLXS_QOSMAP_TYPE_PHB_INGRESS_TO_COLOR(__type__) \
                                                    (((__type__ == SAI_QOS_MAP_TYPE_DOT1P_TO_COLOR ) || \
                                                        (__type__ == SAI_QOS_MAP_TYPE_DSCP_TO_COLOR) || \
                                                        (__type__ == SAI_QOS_MAP_TYPE_MPLS_EXP_TO_COLOR))? 1 : 0)

#define CLXS_QOSMAP_TYPE_PHB_INGRESS(__type__)      (CLXS_QOSMAP_TYPE_PHB_INGRESS_TO_TC(__type__) || \
                                                        CLXS_QOSMAP_TYPE_PHB_INGRESS_TO_COLOR(__type__))

#define CLXS_QOSMAP_PROFILE_MAX_NUM(__unit__)       (CLXS_MAX_QOSMAP_PROFILE_NUM(__unit__) + CLXS_QOSMAP_PROFILE_OFFSET)

#define CLXS_QOSMAP_PROFILE_PTR(__unit__, __type__, __idx__)    \
                                                    ((clxs_qosmap_profile_t *)(_clxs_qosmap_db[__unit__]->ptr_profile + \
                                                        (__type__ * CLXS_QOSMAP_PROFILE_MAX_NUM(__unit__) + __idx__)))

#define CLXS_QOSMAP_PROFILE_VALID(__unit__, __type__, __idx__)    \
                                                    ((__idx__ >= CLXS_QOSMAP_PROFILE_MAX_NUM(__unit__)) ? \
                                                        0 : (CLXS_QOSMAP_PROFILE_PTR(__unit__, __type__, __idx__)->valid) ? 1 : 0)

/*qosmap type macro based hw_type begin*/
#define CLXS_QOSMAP_HW_TYPE_PHB_INGRESS(__hw_type__)   \
                                                    (((CLXS_QOSMAP_HW_TYPE_PCP_DEI_TO_PHB == __hw_type__ ) || \
                                                        (CLXS_QOSMAP_HW_TYPE_DSCP_TO_PHB == __hw_type__) ||    \
                                                        (CLXS_QOSMAP_HW_TYPE_EXP_TO_PHB == __hw_type__)) ? 1 : 0)

#define CLXS_QOSMAP_HW_TYPE_PHB_EGRESS(__hw_type__)     \
                                                    (((CLXS_QOSMAP_HW_TYPE_PHB_TO_PCP_DEI == __hw_type__ ) || \
                                                            (CLXS_QOSMAP_HW_TYPE_PHB_TO_DSCP == __hw_type__) ||    \
                                                            (CLXS_QOSMAP_HW_TYPE_PHB_TO_EXP == __hw_type__)) ? 1 : 0)

#define CLXS_QOSMAP_HW_TYPE_TC_TO_QUEUE(__hw_type__)   \
                                                    ((CLXS_QOSMAP_HW_TYPE_TC_TO_QUEUE == __hw_type__) ? 1 : 0)

#define CLXS_QOSMAP_HW_TYPE_PFC(__hw_type__)        ((CLXS_QOSMAP_HW_TYPE_PRI_FC == __hw_type__) ? 1 : 0)

#define CLXS_QOSMAP_HW_TYPE_PHB(__hw_type__)        (CLXS_QOSMAP_HW_TYPE_PHB_INGRESS(__hw_type__) || \
                                                                CLXS_QOSMAP_HW_TYPE_PHB_EGRESS(__hw_type__))

#define CLXS_QOSMAP_HW_PROFILE_MAX_NUM(__unit__,__hw_type__)       \
                                                    (CLXS_QOSMAP_HW_TYPE_TC_TO_QUEUE(__hw_type__) ? \
                                                        (CLXS_MAX_QOSMAP_TC_PROFILE_NUM(__unit__) + CLXS_QOSMAP_PROFILE_OFFSET) : \
                                                        CLXS_QOSMAP_PROFILE_MAX_NUM(__unit__))

#define CLXS_QOSMAP_HW_PROFILE_PTR(__unit__, __hw_type__, __idx__)    \
                                                    ((clxs_qosmap_hw_profile_t *)(_clxs_qosmap_db[__unit__]->ptr_hw_profile + \
                                                        (__hw_type__ * CLXS_QOSMAP_PROFILE_MAX_NUM(__unit__) + __idx__)))

#define CLXS_QOSMAP_HW_PROFILE_VALID(__unit__, __hw_type__, __idx__)    \
                                                    ((__idx__ >= CLXS_QOSMAP_HW_PROFILE_MAX_NUM(__unit__, __hw_type__)) ? \
                                                        0 : (CLXS_QOSMAP_HW_PROFILE_PTR(__unit__, __hw_type__, __idx__)->valid) ? 1 : 0)

/*qosmap type macro based hw_type end*/
#define CLXS_QOSMAP_CHECK_MAX(__value__, __max__) do    \
{                                                       \
    if ((__value__) > (__max__))                        \
    {                                                   \
        return  SAI_STATUS_INVALID_PARAMETER;           \
    }                                                   \
}while(0)

#define CLXS_QOSMAP_SW_TYPE_STR(__type__)           ({uint8_t t = (__type__); (t < CLXS_QOSMAP_TYPES_MAX) ?     \
                                                        clxs_qosmap_sw_type_str[t] : "Wrong type";})

#define CLXS_QOSMAP_HW_TYPE_STR(__type__)           ({uint8_t t = (__type__); (t < CLXS_QOSMAP_HW_TYPE_LAST) ?  \
                                                        clxs_qosmap_hw_type_str[t] : "Wrong type";})

#define CLXS_QOSMAP_LOCK(unit) \
        sai_osal_mutex_lock(_clxs_qosmap_db[unit]->data_protect);

#define CLXS_QOSMAP_UNLOCK(unit) \
        sai_osal_mutex_unlock(_clxs_qosmap_db[unit]->data_protect);


/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/
typedef enum
{
    CLXS_QOSMAP_HW_TYPE_PCP_DEI_TO_PHB = 0,
    CLXS_QOSMAP_HW_TYPE_DSCP_TO_PHB,
    CLXS_QOSMAP_HW_TYPE_EXP_TO_PHB,
    CLXS_QOSMAP_HW_TYPE_PHB_TO_PCP_DEI,
    CLXS_QOSMAP_HW_TYPE_PHB_TO_DSCP,
    CLXS_QOSMAP_HW_TYPE_PHB_TO_EXP,
    CLXS_QOSMAP_HW_TYPE_TC_TO_QUEUE,
    CLXS_QOSMAP_HW_TYPE_PRI_FC,
    CLXS_QOSMAP_HW_TYPE_LAST
}  clxs_qosmap_hw_type_t;

typedef struct clxs_qosmap_sw_type_map_s{
    sai_qos_map_type_t              sw_type;
    sai_qos_map_type_t              sw_type_related;
    clxs_qosmap_hw_type_t           hw_type;
    uint32_t                        qosmap_max_count;
    bool                            support;
} clxs_qosmap_sw_type_map_t;

typedef struct clxs_qosmap_sdk_type_s{
    clx_dir_t               sdk_direction;
    clx_qos_mapping_type_t  sdk_qosmap_type;
} clxs_qosmap_sdk_type_t;

typedef struct clxs_qosmap_hw_type_map_s{
    clxs_qosmap_hw_type_t   hw_type;
    clxs_qosmap_sdk_type_t  sdk_type;
    uint32_t                qosmap_max_count;
} clxs_qosmap_hw_type_map_t;

typedef struct clxs_qosmap_oid_info_s{
    sai_qos_map_type_t  type;
    sai_object_id_t     oid;
} clxs_qosmap_oid_info_t;

typedef struct clxs_qosmap_info_dual_s{
    clxs_qosmap_oid_info_t   to_tc_info;
    clxs_qosmap_oid_info_t   to_color_info;
} clxs_qosmap_info_dual_t;

typedef union clxs_qosmap_bind_info_s{
    clxs_qosmap_oid_info_t  single_bind_info;
    clxs_qosmap_info_dual_t dual_bind_info;
} clxs_qosmap_bind_info_t;

typedef struct clxs_qosmap_profile_s{
    bool                valid;
    sai_object_id_t     qosmap_oid;
    sai_qos_map_list_t  qosmap_list;
    uint32_t            ref_cnt;
} clxs_qosmap_profile_t;

typedef struct clxs_qosmap_hw_profile_s{
    bool        valid;
    uint32_t    profile_single_or_tc;
    uint32_t    profile_none_or_color;
    uint32_t    ref_cnt;
} clxs_qosmap_hw_profile_t;

typedef struct clxs_qosmap_db_s{
    clxs_qosmap_profile_t       *ptr_profile;
    clxs_qosmap_hw_profile_t    *ptr_hw_profile;
    clx_semaphore_id_t          data_protect;
} clxs_qosmap_db_t;


/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_qos_map_api_t  qosmap_api;
extern clxs_qosmap_db_t         *_clxs_qosmap_db[CLXS_MAX_CHIP_NUM];
extern char                     *clxs_qosmap_sw_type_str[CLXS_QOSMAP_TYPES_MAX];
extern char                     *clxs_qosmap_hw_type_str[CLXS_QOSMAP_HW_TYPE_LAST];


/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t clxs_qosmap_alloc_hw_profile(
    _In_    uint32_t                unit,
    _In_    sai_qos_map_type_t      type,
    _In_    clxs_qosmap_bind_info_t *ptr_qosmap,
    _Out_   uint32_t                *ptr_hw_profile_id);

bool clxs_qosmap_check_type(
    _In_    sai_qos_map_type_t  type);

sai_status_t clxs_qosmap_free_hw_profile(
    _In_    uint32_t                unit,
    _In_    sai_qos_map_type_t      type,
    _In_    clxs_qosmap_bind_info_t *ptr_qosmap);

sai_status_t clxs_qosmap_get_pfc_map_info(
    _In_    sai_object_id_t     pfc_qosmap_oid,
    _Out_   sai_qos_map_list_t  *ptr_qosmap_list);

sai_status_t clxs_qosmap_get_pfc_priority(
    _In_    uint32_t            unit,
    _In_    sai_object_id_t     qosmap_oid,
    _In_    uint32_t            id,
    _Out_   uint32_t            *ptr_priority);

sai_status_t clxs_qosmap_init(
    uint32_t unit);

sai_status_t clxs_qosmap_deinit(
    uint32_t unit);

sai_status_t clxs_get_qosmap_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t  clxs_qosmap_get_max_count(
    _In_    sai_qos_map_type_t  type,
    _Out_   uint32_t            *ptr_max_count);

sai_status_t clxs_qosmap_get_tc(
    sai_object_id_t         qosmap_oid,
    uint8_t                 queue,
    uint8_t                 *ptr_tc);

#endif /* __CLX_SAI_QOSMAP_H__ */
