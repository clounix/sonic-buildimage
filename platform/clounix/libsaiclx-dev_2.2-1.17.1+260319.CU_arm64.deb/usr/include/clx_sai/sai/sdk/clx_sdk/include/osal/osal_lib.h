/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  osal_lib.h
 * PURPOSE:
 *      Provide platform dependent librauroray porting layer.
 *
 * NOTES:
 *
 */

#ifndef OSAL_LIB_H
#define OSAL_LIB_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <stdarg.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define OSAL_VA_START(ap, last) va_start(ap, last)
#define OSAL_VA_END(ap)         va_end(ap)
#define OSAL_VA_ARG(ap, type)   va_arg(ap, type)

/* For FT and SQA verification, OSAL_EN_ASSERT should be defined. */
/* #define OSAL_EN_ASSERT */

#ifdef OSAL_EN_ASSERT
#define OSAL_ASSERT(express) ((express) ? 0 : osal_assert(#express, __FILE__, __LINE__))
#else
#define OSAL_ASSERT(express)
#endif

/* DATA TYPE DECLARATIONS
 */
typedef va_list osal_va_list;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief OS abstration API to set the first (num) bytes of the block of memory
 *        pointed by (ptr) to the specified (value).
 *
 * @param [in]     ptr_mem    - point of the memory to fill
 * @param [in]     value      - value to be set (cast to unsigned char)
 * @param [in]     num        - number of bytes to copy.
 * @return    Pointer to memory is returned
 */
void *
osal_memset(void *ptr_mem, const int32 value, const uint32 num);

/**
 * @brief OS abstration API to copy from source address to destination address with
 *        given number of bytes.
 *
 * @param [in]     ptr_dst    - point of the destination memory to copy to
 * @param [in]     ptr_src    - point of the source memory to copy from
 * @param [in]     num        - number of bytes to copy.
 * @return    Destination address is returned
 */
void *
osal_memcpy(void *ptr_dst, const void *ptr_src, const uint32 num);

/**
 * @brief OS abstration API to compare between 2 block of memory with given number of
 *        bytes.
 *
 * @param [in]     ptr_mem1    - point of the memory to compare.
 * @param [in]     ptr_mem2    - point of the memory to compare.
 * @param [in]     num         - number of bytes to compare.
 * @return         0    - contents of both memory blocks are equal.
 *                        positive integer -- not match, ptr_mem1's first byte is greater than
 *            ptr_mem2's first byte.
 *            negative integer -- not match, ptr_mem1's first byte is less than
 *            ptr_mem2's first byte.
 */
int32
osal_memcmp(const void *ptr_mem1, const void *ptr_mem2, const uint32 num);

/**
 * @brief OS abstration API to copy (num) characters from (ptr_src) to (ptr_dst). If the
 *        end of the source C string (which is signaled by a null-character) is found
 *        before num characters have been copied, destination is padded with zeros
 *        until a total of num characters have been written to it.
 *
 * If there is no null byte among the frist (num)  bytes of (ptr_src),
 * the (ptr_dst) will not be null terminated.
 *
 * @param [in]     ptr_dst    - Pointer to the destination array where the content is to be copied.
 * @param [in]     ptr_src    - C string to be copied.
 * @param [in]     num        - Maximum number of characters to be copied from source.
 * @return    Destination address is returned
 */
char *
osal_strncpy(char *ptr_dst, const char *ptr_src, const uint32 num);

/**
 * @brief OS abstration API to compare (ptr_str1) and (ptr_str2).
 *
 * @param [in]     ptr_str1    - C string to be compared.
 * @param [in]     ptr_str2    - C string to be compared.
 * @return         0    - contents of both memory blocks are equal.
 *                        positive integer -- not match, ptr_str1 is greater than ptr_str2.
 *            negative integer -- not match, ptr_str1 is less than ptr_str2.
 */
int32
osal_strcmp(const char *ptr_str1, const char *ptr_str2);

/**
 * @brief OS abstration API to compare the first (num) characters of (ptr_str1) and
 *        (ptr_str2).
 *
 * @param [in]     ptr_str1    - C string to be compared.
 * @param [in]     ptr_str2    - C string to be compared.
 * @param [in]     num         - Maximum number of characters to compare.
 * @return         0    - contents of both memory blocks are equal.
 *                        positive integer -- not match, ptr_str1 is greater than ptr_str2.
 *            negative integer -- not match, ptr_str1 is less than ptr_str2.
 */
int32
osal_strncmp(const char *ptr_str1, const char *ptr_str2, const uint32 num);

/**
 * @brief OS abstration API to returns the length of the C string str.
 *
 * @param [in]     ptr_str    - C string to return length.
 * @return    length of string
 */
uint32
osal_strlen(const char *ptr_str);

/**
 * @brief it appends the <ptr_src> string to the <ptr_dest> string, owverwriting
 *        the null byte('\0') at the end of dest, and then adds a terminating null
 *        byte. The <ptr_dest> string must have enough space for the result.
 *
 * the dest string must have at least space:
 * osal_strlen(ptr_dest) + osal_strlen(ptr_src) + 1
 *
 * @param [in]     ptr_dest    - the dest string will save the result, it must have enough space.
 * @param [in]     ptr_src     - the src string will be appended to the dest string.
 *                           Non NULL -- the result string pointer, it points to ptr_dest as same.
 * @return         NULL    - there is NULL pointer.
 */
char *
osal_strcat(char *ptr_dest, const char *ptr_src);

/**
 * @brief it appends the <ptr_src> string to the <ptr_dest> string at most <num>
 *        chars,  the null byte('\0') at the end of dest will be overwirtten, and will
 *        add a '\0' to the end of the result. The <ptr_dest> string must have enough
 *        space for the result.
 *
 * the dest string must have at least space:
 * osal_strlen(ptr_dest) + n + 1
 *
 * @param [in]     ptr_dest    - the dest string will save the result, it must have enough space.
 * @param [in]     ptr_src     - the src string will be appended to the dest string.
 * @param [in]     num         - the max number of chars from ptr_src will be appended.
 * @return         Non NULL    - the result string pointer, it points to ptr_dest as same.
 * @return         NULL        - there is NULL pointer.
 */
char *
osal_strncat(char *ptr_dest, const char *ptr_src, uint32 num);

/**
 * @brief OS abstration API to splits <ptr_str> string according to given delimiters
 *        and returns next token. It needs to be called in a loop to get all tokens.
 *        It returns NULL when there are no more tokens. <ptr_save> is a pointer to
 *        a char context between successive calls that parse the same string.
 *
 * @param [in]     ptr_str         - Pointer to the string where the content is to be splited.
 * @param [in]     ptr_delim       - Delimeter string used for split.
 * @param [in]     ptr_save        - Pointer to the string for strtok_r() internal usage.
 * @return         Non NULL        - the next token.
 * @return         NULL            - no more tokens.
 */
char *
osal_strtok_r(char *ptr_str, const char *ptr_delim, char **ptr_save);

/**
 * @brief OS abstration API to print the string to standard output.
 *
 * It could refer to the standard C's printf.
 *
 * @param [in]  ptr_fmt   - %[flags][width][.precision][length]specifier
 *                          specifier   | output
 *                          ------------+---------------------------------------------------
 *                          d or i      | Signed decimal integer
 *                          u           | Unsigned decimal integer
 *                          o or O      | Unsigned octal
 *                          x           | Unsigned hexadecimal integer
 *                          X           | Unsigned hexadecimal integer (uppercase)
 *                          f           | Decimal floating point
 *                          c           | Character
 *                          s           | String of characters
 *                          n           | Nothing printed.
 *                          %           | A % followed by another % character will write a
 *                          | single % to the stream.
 *                          flags       | description
 *                          ------------+---------------------------------------------------
 *                          -           | Left-justify within the given field width
 *                          +           | Forces to preceed the result with a plus or minus
 *                          | sign
 *                          (space)     | If no sign is going to be written, a blank space
 *                          | is inserted before the value.
 *                          #           | Used with o, x or X specifiers the value is
 *                          | preceeded with 0, 0x or 0x respectively for values
 *                          | different than zero.
 *                          0           | Left-pads the number with zeroes (0) instead of
 *                          | spaces when padding is specified
 *                          width       | description
 *                          ------------+---------------------------------------------------
 *                          (number)    | Minimum number of characters to be printed.
 *                          | but as an additional integer value argument
 *                          | preceding the argument that has to be formatted.
 *                          .precision  | description
 *                          ------------+---------------------------------------------------
 *                          .number        | For integer specifiers (d, i, o, u, x, X):
 *                          | precision specifies the minimum number of digits
 *                          | to be written. If the value to be written is
 *                          | shorter than this number, the result is padded
 *                          | with leading zeros. The value is not truncated
 *                          | even if the result is longer. A precision of 0
 *                          | means that no character is written for the value 0
 *                          |
 *                          | For a, A, e, E, f and F specifiers:
 *                          | this is the number of digits to be printed after
 *                          | the decimal point (by default, this is 6).
 *                          |
 *                          | For g and G specifiers:
 *                          | This is the maximum number of significant digits
 *                          | to be printed.
 *                          | For s: this is the maximum number of characters to
 *                          | be printed. By default all characters are printed
 *                          | until the ending null character is encountered.
 *                          | If the period is specified without an explicit
 *                          | value for precision, 0 is assumed.
 *                          |           specifiers
 *                          +---------------+-----------------------+-----------
 *                          length      | d i           | u o x X               |
 *                          ------------+---------------+-----------------------+-----------
 *                          h           | short int     | unsigned short int    |
 *                          l           | long int      | unsigned long int     |
 * @return    On success, the total number of characters written is returned.
 *            If a writing error occurs, the error indicator (ferror) is set and a
 *            negative number is returned.
 */
void
osal_printf(const char *ptr_fmt, ...);

/**
 * @brief OS abstration API to composes a string with the same text that would be
 *        printed.
 *
 * @param [in]     ptr_str    - pointer to the buffer
 * @param [in]     length     - The length of the buffer
 * @param [in]     ptr_fmt    - C string that contains a format string that follows
 *                              the same specifications as format in osal_printf.
 * @return    On success, the total number of characters written is returned.
 *            If a writing error occurs, the error indicator (ferror) is set and a
 *            negative number is returned.
 */
int32
osal_snprintf(char *ptr_str, const uint32 length, const char *ptr_fmt, ...);

/**
 * @brief OS abstration API to composes a string with the same text that would be
 *        printed.
 *
 * @param [in]     ptr_str    - pointer to the buffer
 * @param [in]     length     - The length of the buffer
 * @param [in]     ptr_fmt    - C string that contains a format string that follows
 *                              the same specifications as format in osal_printf.
 * @param [in]     ap         - The pointer ro the first variable
 * @return    On success, the total number of characters written is returned.
 *            If a writing error occurs, the error indicator (ferror) is set and a
 *            negative number is returned.
 */
int32
osal_vsnprintf(char *ptr_str, const uint32 length, const char *ptr_fmt, osal_va_list ap);

/**
 * @brief it is used to set random seed
 *
 * @param [in]     seed    - random seed
 */
void
osal_srand(const uint32 seed);

/**
 * @brief it is used to get a random uint32 number
 *
 * @return    random number
 */
uint32
osal_rand(void);

/**
 * @brief OS abstration API to assert.
 *
 * @param [in]     ptr_express    - express to evaluate, false to assert
 * @param [in]     prt_file       - filename of assert point
 * @param [in]     line           - line number of assert point
 */
uint32
osal_assert(const char *ptr_express, const char *prt_file, const uint32 line);

#if defined(CLX_EN_COMPILER_SUPPORT_LONG_LONG)
/**
 * @brief OS abstration API to do 64 bits division by 32 bits.
 *
 * @param [in]     dividend      - dividend operator
 * @param [in]     divisor       - divisor operator
 * @param [out]    ptr_result    - save the devision result
 */
clx_error_no_t
osal_64bits_div_ui32(uint64 dividend, uint32 divisor, uint64 *ptr_result);
#endif

#endif /* End of OSAL_LIB_H */
