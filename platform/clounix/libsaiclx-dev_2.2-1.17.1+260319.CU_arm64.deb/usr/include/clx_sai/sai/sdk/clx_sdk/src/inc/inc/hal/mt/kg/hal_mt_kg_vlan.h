/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_vlan.h
 * PURPOSE:
 *  Define the declaration for VLAN module for CL8600.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_KG_VLAN_H
#define HAL_MT_KG_VLAN_H

#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_swc.h>
#include <clx/clx_vlan.h>
#include <hal/hal_const_cmn.h>
#include <hal/hal_vlan.h>

/* NAMING CONSTANT DECLARATIONS
 */
typedef enum hal_mt_kg_vlan_pvlan_port_type_e {
    HAL_MT_KG_VLAN_PVLAN_PORT_TYPE_N, /* Normal VLAN */
    HAL_MT_KG_VLAN_PVLAN_PORT_TYPE_P, /* Primary VLAN */
    HAL_MT_KG_VLAN_PVLAN_PORT_TYPE_I, /* Isolated VLAN */
    HAL_MT_KG_VLAN_PVLAN_PORT_TYPE_C, /* Community VLAN */
    HAL_MT_KG_VLAN_PVLAN_PORT_TYPE_LAST,
} hal_mt_kg_vlan_pvlan_port_type_t;

typedef enum hal_mt_kg_vlan_hw_vlan_tag_mode_e {
    HAL_MT_KG_HW_VLAN_TAG_MODE_1Q,
    HAL_MT_KG_HW_VLAN_TAG_MODE_1AD,
    HAL_MT_KG_HW_VLAN_TAG_MODE_24B,
    HAL_MT_KG_HW_VLAN_TAG_MODE_SEG,
} hal_mt_kg_vlan_hw_vlan_tag_mode_t;

/* DATA TYPE DECLARATIONS
 */

/* MACRO API DECLARATIONS
 */

/**
 * @brief Create vlan entry.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    vid     - VLAN ID.
 * @return        CLX_E_OK              - Operate success.
 * @return        CLX_E_ENTRY_EXISTS    - Duplicated create.
 * @return        CLX_E_OTHERS          - Operate fail.
 */
clx_error_no_t
hal_mt_kg_vlan_create(const uint32 unit, const uint32 vid);

/**
 * @brief Destroy vlan entry.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    vid     - VLAN ID.
 * @return        CLX_E_OK              - Operate success.
 * @return        CLX_E_ENTRY_EXISTS    - Duplicated create.
 * @return        CLX_E_OTHERS          - Operate fail.
 */
clx_error_no_t
hal_mt_kg_vlan_destroy(const uint32 unit, const uint32 vid);

/**
 * @brief Get member and untag port list of a vlan.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     vid            - 802.1Q VLAN id.
 * @param [out]    port_bmp       - VLAN port member.
 * @param [out]    ut_port_bmp    - VLAN untag member.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry.
 * @return         CLX_E_NOT_INITED         - VLAN module not initialized.
 * @return         CLX_E_OTHERS             - Other faults.
 */
clx_error_no_t
hal_mt_kg_vlan_port_get(const uint32 unit,
                        const clx_vlan_t vid,
                        clx_port_bitmap_t port_bmp,
                        clx_port_bitmap_t ut_port_bmp);

/**
 * @brief Add VLAN port members, default tag mode is tagged.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    vid            - 802.1Q VLAN id.
 * @param [in]    port_bmp       - Port member to new add.
 * @param [in]    ut_port_bmp    - Untag port member to new add.
 * @return        CLX_E_OK                 - Operate success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - VLAN not created.
 * @return        CLX_E_NOT_INITED         - VLAN module not initialized.
 * @return        CLX_E_OTHERS             - Other faults.
 */
clx_error_no_t
hal_mt_kg_vlan_port_add(const uint32 unit,
                        const clx_vlan_t vid,
                        const clx_port_bitmap_t port_bmp,
                        const clx_port_bitmap_t ut_port_bmp);

/**
 * @brief Delete VLAN port members.
 *
 * VLAN entry includes member port list and untag port list.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    vid         - 802.1Q VLAN id.
 * @param [in]    port_bmp    - Port bitmap to delete.
 * @return        CLX_E_OK                 - Operate success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - VLAN not created.
 * @return        CLX_E_NOT_INITED         - VLAN module not initialized.
 * @return        CLX_E_OTHERS             - Other faults.
 */
clx_error_no_t
hal_mt_kg_vlan_port_del(const uint32 unit, const clx_vlan_t vid, const clx_port_bitmap_t port_bmp);

/**
 * @brief Set VLAN port member tag/untag mode.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    vid         - 802.1Q VLAN id.
 * @param [in]    port_bmp    - VLAN port member bitmap.
 * @param [in]    mode        - Tag/untag Mode.
 * @return        CLX_E_OK                 - Operate success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - No such entry.
 */
clx_error_no_t
hal_mt_kg_vlan_tag_mode_set(const uint32 unit,
                            const clx_vlan_t vid,
                            const clx_port_bitmap_t port_bmp,
                            const clx_vlan_tag_mode_t mode);

/**
 * @brief Traverse vlan tagged/untagged member port for active vlan.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    callback      - The callback function to be called for each traversed vlan entry.
 * @param [in]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Other faults.
 */
clx_error_no_t
hal_mt_kg_vlan_trav(const uint32 unit, const CLX_VLAN_TRAV_FUNC_T callback, void *ptr_cookie);

/**
 * @brief This API is used to bind VLAN and bridge domain.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    vid     - 802.1Q VLAN id.
 * @param [in]    bdid    - Bridge domain id.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_vlan_bd_bind(const uint32 unit, const clx_vlan_t vid, const clx_bridge_domain_t bdid);

/**
 * @brief This API is used to unbind VLAN and bridge domain.
 *
 * Support_chip: all.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    vid     - 802.1Q VLAN id.
 * @param [in]    bdid    - Bridge domain id.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_vlan_bd_unbind(const uint32 unit, const clx_vlan_t vid, const clx_bridge_domain_t bdid);

/**
 * @brief This API is used to get the bridge domain bound to VLAN.
 *
 * Support_chip: all.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     vid     - 802.1Q VLAN id.
 * @param [out]    bdid    - Bridge domain id.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_vlan_bd_get(const uint32 unit, const clx_vlan_t vid, clx_bridge_domain_t *bdid);

/**
 * @brief Set VLAN type.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    vid     - 802.1Q VLAN id.
 * @param [in]    type    - Normal/private VLAN.
 * @return        CLX_E_OK                 - Operate success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - VLAN not created.
 */
clx_error_no_t
hal_mt_kg_vlan_type_set(const uint32 unit, const clx_vlan_t vid, const clx_vlan_type_t type);

/**
 * @brief Get VLAN type.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     vid     - 802.1Q VLAN id.
 * @param [out]    type    - Normal/private VLAN.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - VLAN not created.
 */
clx_error_no_t
hal_mt_kg_vlan_type_get(const uint32 unit, const clx_vlan_t vid, clx_vlan_type_t *type);

/**
 * @brief Add private VLAN extension trunk port.
 *
 * Support_chip: all.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    vid         - Primary/community/isolated VLAN id.
 * @param [in]    port_bmp    - Trunk port bitmap.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_ENTRY_EXISTS     - Private VLAN index is in use.
 */
clx_error_no_t
hal_mt_kg_vlan_private_tport_add(const uint32 unit,
                                 const clx_vlan_t vid,
                                 const clx_port_bitmap_t port_bmp);

/**
 * @brief Delete private VLAN extension trunk port.
 *
 * Support_chip: all.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    vid         - Primary/community/isolated VLAN id.
 * @param [in]    port_bmp    - Trunk port bitmap.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_ENTRY_EXISTS     - Private VLAN index is in use.
 */
clx_error_no_t
hal_mt_kg_vlan_private_tport_del(const uint32 unit,
                                 const clx_vlan_t vid,
                                 const clx_port_bitmap_t port_bmp);

/**
 * @brief Get private VLAN extension trunk port.
 *
 * Support_chip: all.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     vid         - Primary/community/isolated VLAN id.
 * @param [out]    port_bmp    - Trunk port bitmap.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Not found.
 */
clx_error_no_t
hal_mt_kg_vlan_private_tport_get(const uint32 unit,
                                 const clx_vlan_t vid,
                                 clx_port_bitmap_t port_bmp);

/**
 * @brief Set VLAN filter.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Logic port ID.
 * @param [in]    dir       - Filter direction.
 * @param [in]    enable    - Enable/Disable filter.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_vlan_filter_set(const uint32 unit,
                          const uint32 port,
                          const clx_dir_t dir,
                          const boolean enable);

/**
 * @brief Get VLAN filter.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Logic port ID.
 * @param [in]     dir       - Filter direction.
 * @param [out]    enable    - Enable/Disable filter.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_vlan_filter_get(const uint32 unit,
                          const uint32 port,
                          const clx_dir_t dir,
                          boolean *enable);

/**
 * @brief Apply default vlan related properties for the new created port: (1) Join default vlan as
 *        untagged member port (2) Join default vlan flooding member.
 *
 * (1) CLX/Hw design support modify member port of an inactive VLAN.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate fail.
 */
clx_error_no_t
hal_mt_kg_vlan_port_dflt_set(const uint32 unit, const uint32 port);

/**
 * @brief Reset default vlan related properties for the deleted port: (1) Remove from default vlan
 *        member port (2) Remove from default vlan flooding member.
 *
 * (1) CLX/Hw design support modify member port of an inactive VLAN.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate fail.
 */
clx_error_no_t
hal_mt_kg_vlan_port_dflt_reset(const uint32 unit, const uint32 port);

/**
 * @brief Init vlan module.
 *
 * 1) Create default vlan and add all port as untagged member.
 * 2) Create default bridge domain and bind default vlan to that.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK                - Operate success.
 * @return        CLX_E_ALREADY_INITED    - Unexpected init.
 * @return        CLX_E_OTHERS            - Init fail.
 */
clx_error_no_t
hal_mt_kg_vlan_init(const uint32 unit);

/**
 * @brief Deinit vlan module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK            - Operate success.
 * @return        CLX_E_NOT_INITED    - Unexpected deinit.
 * @return        CLX_E_OTHERS        - Init fail.
 */
clx_error_no_t
hal_mt_kg_vlan_deinit(const uint32 unit);

/**
 * @brief This function is to get VLAN chip configurable information.
 *
 * @param [in]    unit     - Device unit number, get chip configuration is required,
 *                           but get global configuration is not required.
 * @param [in]    type     - Type for get chip configurable information.
 * @param [in]    para0    - Parameter0 if necessary.
 * @param [in]    para1    - Parameter1 if necessary ptr_value.
 * @return        CLX_E_OK             - Operate success.
 * @return        CLX_E_NOT_SUPPORT    - Not support.
 * @return        CLX_E_OTHERS         - Operate fail.
 */
clx_error_no_t
hal_mt_kg_vlan_chip_cfg_info_get(const uint32 unit,
                                 const clx_swc_chip_cfg_info_type_t type,
                                 const uint32 para0,
                                 const uint32 para1,
                                 uint32 *ptr_value);

/**
 * @brief This API is used to add extend TPID.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     type        - TPID type.
 * @param [out]    tpid_grp    - Extending TPID group.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_vlan_ext_tpid_add(const uint32 unit,
                            const clx_vlan_ext_tpid_type_t type,
                            const clx_vlan_ext_tpid_grp_t tpid_grp);

/**
 * @brief This API is used to del extend TPID.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     type        - TPID type.
 * @param [out]    tpid_grp    - Extending TPID group.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_vlan_ext_tpid_del(const uint32 unit,
                            const clx_vlan_ext_tpid_type_t type,
                            const clx_vlan_ext_tpid_grp_t tpid_grp);

/**
 * @brief This API is used to get extend TPID.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     type        - TPID type.
 * @param [out]    tpid_grp    - Extending TPID group.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_vlan_ext_tpid_get(const uint32 unit,
                            const clx_vlan_ext_tpid_type_t type,
                            clx_vlan_ext_tpid_grp_t tpid_grp);

/**
 * @brief This API is used to add TPID.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     type              - TPID type.
 * @param [in]     tpid_grp          - TPID group.
 * @param [out]    ptr_s_prof_idx    - STPID profile index.
 * @param [out]    ptr_c_prof_idx    - CTPID profile index.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_vlan_igr_tpid_add(const uint32 unit,
                            const hal_vlan_tpid_type_t type,
                            const hal_vlan_tpid_grp_t tpid_grp,
                            uint32 *ptr_s_prof_idx,
                            uint32 *ptr_c_prof_idx);

/**
 * @brief This API is used to del TPID.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    type          - TPID type.
 * @param [in]    s_prof_idx    - STPID profile index.
 * @param [in]    c_prof_idx    - CTPID profile index.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_vlan_igr_tpid_del(const uint32 unit,
                            const hal_vlan_tpid_type_t type,
                            const uint32 s_prof_idx,
                            const uint32 c_prof_idx);

/**
 * @brief This API is used to get TPID.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     type          - TPID type.
 * @param [in]     s_prof_idx    - STPID profile index.
 * @param [in]     c_prof_idx    - CTPID profile index.
 * @param [out]    tpid_grp      - TPID group.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_vlan_igr_tpid_get(const uint32 unit,
                            const hal_vlan_tpid_type_t type,
                            const uint32 s_prof_idx,
                            const uint32 c_prof_idx,
                            hal_vlan_tpid_grp_t tpid_grp);

/**
 * @brief This API is used to add mac vlan entry.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    mac     - Mac address.
 * @param [in]    vid     - VLAN id.
 * @param [in]    prio    - Priority id, not support.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Table is full.
 */
clx_error_no_t
hal_mt_kg_vlan_mac_vlan_add(const uint32 unit,
                            const clx_mac_t mac,
                            const clx_vlan_t vid,
                            const uint8 prio);

/**
 * @brief This API is used to del mac vlan entry.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    mac     - Mac address.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_vlan_mac_vlan_del(const uint32 unit, const clx_mac_t mac);

/**
 * @brief This API is used to get mac vlan entry.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     mac         - Mac address.
 * @param [out]    ptr_vid     - VLAN id.
 * @param [out]    ptr_prio    - Priority id, not support.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_vlan_mac_vlan_get(const uint32 unit,
                            const clx_mac_t mac,
                            clx_vlan_t *ptr_vid,
                            uint8 *ptr_prio);

/**
 * @brief Set vlan classify priority.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    type    - Vlan classify type.
 * @param [in]    prio    - Mac vlan priority.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_vlan_classify_prio_set(const uint32 unit,
                                 const clx_vlan_classify_prio_type_t type,
                                 const uint32 prio);

/**
 * @brief Get vlan classify priority.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     type        - Vlan classify type.
 * @param [out]    ptr_prio    - Mac vlan priority.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_vlan_classify_prio_get(const uint32 unit,
                                 clx_vlan_classify_prio_type_t type,
                                 uint32 *ptr_prio);

/**
 * @brief This API is used to set vlan range mapping entry.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    index      - Range mapping index.
 * @param [in]    ptr_cfg    - VLAN range mapping configuration.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_vlan_range_mapping_set(const uint32 unit,
                                 const uint32 index,
                                 const clx_vlan_range_mapping_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get vlan range mapping entry.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     index      - Range mapping index.
 * @param [out]    ptr_cfg    - VLAN range mapping configuration.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_vlan_range_mapping_get(const uint32 unit,
                                 const uint32 index,
                                 clx_vlan_range_mapping_cfg_t *ptr_cfg);

/**
 * @brief Diag print dis_hsh_bdi entry.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    lcl_intf    - LCL interface.
 * @param [in]    s_vlan      - Service vlan.
 * @param [in]    c_vlan      - Customer vlan.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
hal_mt_kg_vlan_igr_hsh_print(const uint32 unit,
                             const uint32 lcl_intf,
                             const clx_vlan_t s_vlan,
                             const clx_vlan_t c_vlan);

/**
 * @brief Diag print rwi_hsh_vlan entry.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    lcl_intf    - LCL interface.
 * @param [in]    bd          - Bridge domain index.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
hal_mt_kg_vlan_egr_hsh_print(const uint32 unit,
                             const uint32 lcl_intf,
                             const clx_bridge_domain_t bd);

/**
 * @brief Save interface vlan info to vlan module, it will add rwi hsh vlan entry.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    bdid      - BD id.
 * @param [in]    enable    - Enable L3 or disable L3.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_vlan_l3_bd_set(const uint32 unit, const uint32 bdid, const boolean enable);

/**
 * @brief Get low latency mode default VLAN.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     plane       - Plane ID.
 * @param [in]     lcl_intf    - Local intf ID.
 * @param [out]    ptr_vid     - VLAN ID.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_vlan_llm_dflt_vlan_get(const uint32 unit,
                                 const uint32 plane,
                                 const uint32 lcl_intf,
                                 clx_vlan_t *ptr_vid);

/**
 * @brief Set low latency mode default VLAN.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    plane       - Plane ID.
 * @param [in]    lcl_intf    - Local intf ID.
 * @param [in]    vid         - VLAN ID.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_vlan_llm_dflt_vlan_set(const uint32 unit,
                                 const uint32 plane,
                                 const uint32 lcl_intf,
                                 const clx_vlan_t vid);

/**
 * @brief Init default VLAN in low latency mode.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     port                - Physical port ID.
 * @param [in]     vid                 - Default VLAN ID.
 * @param [out]    ptr_cia_entry_id    - Default VLAN ID.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
hal_mt_kg_vlan_llm_dflt_vlan_init(const uint32 unit,
                                  const uint32 port,
                                  const clx_vlan_t vid,
                                  uint32 *ptr_cia_entry_id);

#endif
