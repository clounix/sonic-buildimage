/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_CFG_EXTEND_H__)
#define __CLX_SAI_CFG_EXTEND_H__
#include "uthash.h"
/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_SHOW_ECMP_PATH_BY_COUNTER     1
#define CLXS_SHOW_ECMP_PATH_BY_ALGO        2
#define CLXS_PORT_LINK_DELAY_DEF_MODE      1
#define CLXS_PORT_LINK_DELAY_EXT_MODE      2
#define CLXS_PORT_BREAKOUT_LANE_4          4
#define CLXS_WRED_ECN_UNMARK_COUNT_ACL     2
#define CLXS_WRED_ECN_COUNT_ACL_IPV6       4

#define SDK_CFG_TYPE_NAME_MAX_LEN   (64)
#define SDK_CFG_TYPE_LINE_MAX_LEN   (256)
#define CLXS_CFG_DEFAULT_PARAM0             0
#define CLXS_CFG_DEFAULT_PARAM1             0
#define CLXS_CFG_EXTEND_PARAM1_IS_STR_VALUE       (0xFFFFFFFF)
/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/
 typedef enum
{
    CLXS_CFG_EXTEND_FIRST = CLX_CFG_TYPE_LAST + 1,
    CLXS_CFG_EXTEND_DIAG_LOG_SEVERITY = CLXS_CFG_EXTEND_FIRST,
    CLXS_CFG_EXTEND_PORT_BREAKOUT_LANE_NUM_MAX,
    CLXS_CFG_EXTEND_SDK_LOG_SEVERITY,
    CLXS_CFG_EXTEND_ECMP_RH_HASH_SEED,
    CLXS_CFG_EXTEND_LAG_RH_HASH_SEED,
    CLXS_CFG_EXTEND_ECMP_MEMBERS_MAX_COUNT,
#ifdef CLX_TAM_MOD_EXTEND_ENABLE
    CLXS_CFG_EXTEND_MOD_PP_QUEUE_CIR,
    CLXS_CFG_EXTEND_MOD_TM_QUEUE_CIR,
#endif
    CLXS_CFG_EXTEND_LOG_DES_DIR,
    CLXS_CFG_EXTEND_CPI_ENABLE,
    CLXS_CFG_EXTEND_ACL_SONIC_BIND,
    CLXS_CFG_EXTEND_ADJ_DROP_BY_DELETING_FDB,
    CLXS_CFG_EXTEND_BRIDGEPORT_ING_FILTER,
    CLXS_CFG_EXTEND_ECC_ERR_LOG,
    CLXS_CFG_EXTEND_MAC_MOVE_NOTIFY,
    CLXS_CFG_EXTEND_PORT_IP_COUNT_USING_ACL,
    CLXS_CFG_EXTEND_PORT_LINK_DELAY,
    CLXS_CFG_EXTEND_SHOW_ECMP_PATH,
    CLXS_CFG_EXTEND_SWITCH_MONITOR,
    CLXS_CFG_EXTEND_RIF_RESOURCE_MODE,
    CLXS_CFG_EXTEND_TUNNEL_NOV3_RIF_NUM,
    CLXS_CFG_EXTEND_TUNNEL_NOV3_RTE_MAC_NUM,
    CLXS_CFG_EXTEND_EXT_PHY_TYPE,
    CLXS_CFG_EXTEND_EXT_PHY_LINE_CARD_SCAN_INTERVAL,
    CLXS_CFG_EXTEND_SUPPORT_BULK_GET_STATS,
    CLXS_CFG_EXTEND_PORT_FLEX_SPEED_SLOWDOWN,
    CLXS_CFG_EXTEND_L3_MTU_FAIL_ACTION,
    CLXS_CFG_EXTEND_PORT_SERDES_CONFIG_FROM_FILE,
    CLXS_CFG_EXTEND_NETIF_VLAN_TAG_TYPE,
    CLXS_CFG_EXTEND_CPU_RX_RATE_LIMIT, /* param0: 0:cpu port rx rate, 1: cpu queue rx rate
                                       param1: when param0 is 0, NA
                                               when param0 is 1, queue id
                                       value : rate pps
                                    */
    CLXS_CFG_EXTEND_NEIGHBOR_FLUSH_HOST,
    CLXS_CFG_EXTEND_WATERMARK_READ_CLEAR_ENABLE,
    CLXS_CFG_EXTEND_LINKDELAY_STATUS_CHANGE_LOG,
    CLXS_CFG_EXTEND_TAM_INT_TRUNCATE_SIZE,
    CLXS_CFG_EXTEND_MOD_RX_BY_NETIF,
    CLXS_CFG_EXTEND_FDB_DEFAULT_AGE_TIME,
    CLXS_CFG_EXTEND_LAG_MEMBER_AUTO_UPDATE,
    CLXS_CFG_EXTEND_HASH_DEFAULT_L2_FIELD,
    CLXS_CFG_EXTEND_HOSTIF_ARP_REPLY_TRAP2CPU,
    CLXS_CFG_EXTEND_HOSTIF_DEF_TRAP_GROUP_QUEUE0,  /* default queue id, 0: use cpu_queue in hostif_cpu_reason_map, 1: use queue 0 */
    CLXS_CFG_EXTEND_DUPLICATE_CREATE_RETURN_EXISTS,
    CLXS_CFG_EXTEND_PORT_OVERSIZE_GREATER_THAN_MTU,
    CLXS_CFG_EXTEND_PORT_STATS_L1_BYTE,
    CLXS_CFG_EXTEND_BFD_HW_ENABLE,
    CLXS_CFG_EXTEND_ACL_FORWARD_SPECIAL_IP_PROTOCOL,
    CLXS_CFG_EXTEND_PORT_ECN_MARK_COUNT_USING_ACL,
    CLXS_CFG_EXTEND_TAM_INT_IFA2_MODIFY_DEVICE_ID,
    CLXS_CFG_EXTEND_TAM_INT_IFA2_QUEUE_CIR,
    CLXS_CFG_EXTEND_SAMPLEPACKET_GET_OUT_PORT,
    CLXS_CFG_EXTEND_QUEUE_LOSSLESS_DROP_COUNTER,
    CLXS_CFG_EXTEND_NEXTHOPGROUP_RH_BY_FG,
    CLXS_CFG_EXTEND_BUFFER_ALPHA_STANDARD_MAPPING,
    CLXS_CFG_EXTEND_LAG_MEMBER_REJOIN_FAST,
    CLXS_CFG_EXTEND_PORT_FIRST_ADMIN_UP_DELAY,
    CLXS_CFG_EXTEND_ACL_V6_USE_IP_PROTOCOL,
    CLXS_CFG_EXTEND_ACL_V6_USE_DSCP,
    CLXS_CFG_EXTEND_ACL_V6_USE_ECN,
    CLXS_CFG_EXTEND_MOD_TTL_ERROR_PKT,
    CLXS_CFG_EXTEND_PORT_CT_IGNORE_FCS_COUNTER,
    CLXS_CFG_EXTEND_LOG_PREFIX,
    CLXS_CFG_EXTEND_NEXTHOPGROUP_RH_BY_HW,
    CLXS_CFG_EXTEND_PORT_BLOCK_USING_ACL,
    CLXS_CFG_EXTEND_ACL_PG_CNT_BITMAP,
    CLXS_CFG_EXTEND_COPP_AWARE_FLOW_CNT,
    CLXS_CFG_EXTEND_UDF_INNER_L4_DST_PORT,
    CLXS_CFG_EXTEND_UDF_INNER_IP_PROTOCOL,
    CLXS_CFG_EXTEND_SCHEDULER_SUPPORT_RATE_ZERO,
    CLXS_CFG_EXTEND_ACL_DROP_USE_DROP_DI,
    CLXS_CFG_EXTEND_LAST
}clxs_cfg_extend_type_t;


typedef union
{
    uint32_t u32;
    char str[SDK_CFG_TYPE_NAME_MAX_LEN];
} clxs_cfg_extend_value_t;


typedef struct
{
    char key[MAX_KEY_STR_LEN];  /* key of the config inculde unit,type,param0,param1*/
    clxs_cfg_extend_type_t type;
    char name[SDK_CFG_TYPE_NAME_MAX_LEN];
    uint32_t param0;
    uint32_t param1;
    clxs_cfg_extend_value_t default_value;
    clxs_cfg_extend_value_t value;
    UT_hash_handle hh;
} clxs_cfg_extend_info_t;
/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/

/*hash table of the configuration, does not need to warmboot, it will be initialized in the init function*/
extern clxs_cfg_extend_info_t *ptr_clxs_cfg_extend_db[CLXS_MAX_CHIP_NUM];

/*******************************************************************************
 * Function Declarations
 *******************************************************************************/

sai_status_t
clxs_cfg_get_value(
    _In_ const uint32_t unit,
    _Inout_ clxs_cfg_extend_info_t *ptr_cfg_info);

uint32_t
clxs_cfg_get_value_by_type(
    _In_ const uint32_t unit,
    _In_ const clxs_cfg_extend_type_t cfg_type);

sai_status_t
clxs_cfg_add_default_cfg_table(
    _In_ const uint32_t unit);

sai_status_t
clxs_cfg_add_user_cfg_table(
    _In_ const char *ptr_filename);

sai_status_t
clxs_cfg_delete_user_cfg_table(
    _In_ const uint32_t unit);

#endif /* __CLX_SAI_CFG_EXTEND_H__ */
