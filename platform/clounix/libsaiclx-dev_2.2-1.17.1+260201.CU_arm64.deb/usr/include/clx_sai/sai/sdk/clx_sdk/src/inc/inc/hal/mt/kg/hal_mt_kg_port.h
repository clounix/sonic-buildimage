/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_port.h
 * PURPOSE:
 *      It provide HAL PORT module API.
 * NOTES:
 */

#ifndef HAL_MT_KG_PORT_H
#define HAL_MT_KG_PORT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_KG_DP_MAX_NUM                  (2)
#define HAL_MT_KG_ETH_SLICE_MAX_NUM           (2)
#define HAL_MT_KG_ETH_MACRO_MAX_NUM_PER_SLICE (6)
#define HAL_MT_KG_ETH_MACRO_MAX_NUM           (12)
#define HAL_MT_KG_ETH_MACRO_LANES_PER_MACRO   (16)
#define HAL_MT_KG_ETH_MACRO_0_LANES           (8)
#define HAL_MT_KG_ETH_MACRO_5_LANES           (10)
#define HAL_MT_KG_PORT_MACRO_INVALID          (0xFFFFFFFF)

#define HAL_MT_KG_PL_CHANNEL_NUM 16
#define HAL_MT_KG_PL_QUEUE_NUM   2

#define HAL_MT_KG_PORT_DERICTION_INGRESS (0)
#define HAL_MT_KG_PORT_DERICTION_EGRESS  (1)

#define HAL_MT_KG_PORT_MBURST_CNT_TX_BYTE       (0)
#define HAL_MT_KG_PORT_MBURST_CNT_TX_PKT        (1)
#define HAL_MT_KG_PORT_MBURST_CNT_TX_MATCH_BYTE (2)
#define HAL_MT_KG_PORT_MBURST_CNT_TX_MATCH_PKT  (3)

#define HAL_MT_KG_PORT_RUNT_DFT         64
#define HAL_MT_KG_PORT_MTU              10200
#define HAL_MT_KG_PORT_PPH_LEANGTH      40
#define HAL_MT_KG_PORT_OUTER_MAC_LENGTH 12

#define HAL_MT_KG_PORT_JABBER_DFT \
    (HAL_MT_KG_PORT_MTU + HAL_MT_KG_PORT_PPH_LEANGTH + HAL_MT_KG_PORT_OUTER_MAC_LENGTH)

#define HAL_MT_KG_PORT_CPU_ECPU_PORT_PLANE (0)
#define HAL_MT_KG_PORT_CPU_PORT_MACRO      (0)
#define HAL_MT_KG_PORT_ECPU_PORT_MACRO     (5)
#define HAL_MT_KG_PORT_CPU_PLANE_PORT      (84)
#define HAL_MT_KG_PORT_ECPU_PLANE_PORT     (85)
#define HAL_MT_KG_PORT_RC0_PLANE_PORT      (86)
#define HAL_MT_KG_PORT_RC1_PLANE_PORT      (87)

#define HAL_MT_KG_PL_PLANE_ETH_PORT_NUM   (82)
#define HAL_MT_KG_PL_PLANE_CPX_PL_CHANNEL (15)
#define HAL_MT_KG_PL_PLANE_DFT_PL_CHANNEL (0)

#define HAL_MT_KG_PL_PPID_TO_CHANNEL(__PPID__)                                                \
    (((__PPID__) < HAL_MT_KG_ETH_MACRO_0_LANES) ?                                             \
         (__PPID__) :                                                                         \
         ((__PPID__) < HAL_MT_KG_PL_PLANE_ETH_PORT_NUM) ?                                     \
         (((__PPID__) - HAL_MT_KG_ETH_MACRO_0_LANES) % HAL_MT_KG_ETH_MACRO_LANES_PER_MACRO) : \
         ((__PPID__) == HAL_MT_KG_PORT_CPU_PLANE_PORT ||                                      \
          (__PPID__) == HAL_MT_KG_PORT_ECPU_PLANE_PORT) ?                                     \
         HAL_MT_KG_PL_PLANE_CPX_PL_CHANNEL :                                                  \
         HAL_MT_KG_PL_PLANE_DFT_PL_CHANNEL)

#define HAL_MT_KG_PORT_TO_PL_CHANNEL(__UNIT__, __PORT__) \
    HAL_MT_KG_PL_PPID_TO_CHANNEL(HAL_CL_PORT_TO_PLANE_PORT(__UNIT__, __PORT__))

#define HAL_MT_KG_PL_CHANNEL_TO_PPID(__SUB_INST__, __PL_CHANNEL__)             \
    (((__SUB_INST__) == 0) ? (__PL_CHANNEL__) :                                \
                             (HAL_MT_KG_ETH_MACRO_0_LANES + (__PL_CHANNEL__) + \
                              (((__SUB_INST__) - 1) * HAL_MT_KG_ETH_MACRO_LANES_PER_MACRO)))

#define HAL_MT_KG_PL_CHANNEL_TO_CL_PORT(__UNIT__, __INST__, __SUB_INST__, __PL_CHANNEL__) \
    HAL_PLANE_PORT_TO_CL_PORT(__UNIT__, __INST__,                                         \
                              HAL_MT_KG_PL_CHANNEL_TO_PPID(__SUB_INST__, __PL_CHANNEL__))

// pick all umac and umac wrap regs and IPL&EPL macro based regs
#define HAL_MT_KG_PORT_REG_CHECK(__REG_ID__)                             \
    ((((__REG_ID__) >= MT_KG_REG_CLX_UMAC_WRAP_CFGS_CHMODE_0_ID) &&      \
      ((__REG_ID__) <= MT_KG_REG_CLX_UMAC_WRAP_HIER_IRQ1_TST_ID)) ||     \
     (((__REG_ID__) >= MT_KG_REG_CLX_TOD_UMAC_WRAP_SCRATCH_ID) &&        \
      ((__REG_ID__) <= MT_KG_REG_CLX_TOD_UMAC_WRAP_HIER_IRQ1_TST_ID)) || \
     (((__REG_ID__) >= MT_KG_REG_UMAC_AXI_CHMODE_0_ID) &&                \
      ((__REG_ID__) <= MT_KG_REG_UMAC_AXI_MIB_MEM_ID)) ||                \
     (((__REG_ID__) >= MT_KG_REG_UMAC_WRAP_SCRATCH_ID) &&                \
      ((__REG_ID__) <= MT_KG_REG_UMAC_WRAP_HIER_IRQ1_TST_ID)) ||         \
     (((__REG_ID__) >= MT_KG_REG_EPL_PIPE_SCRATCH_ID) &&                 \
      ((__REG_ID__) <= MT_KG_REG_EPL_PIPE_HIER_IRQ1_TST_ID)) ||          \
     (((__REG_ID__) >= MT_KG_REG_PHY_WRAP_SCRATCH_ID) &&                 \
      ((__REG_ID__) <= MT_KG_REG_PHY_WRAP_HIER_IRQ1_TST_ID)) ||          \
     (((__REG_ID__) >= MT_KG_REG_IPL_PIPE_SCRATCH_ID) &&                 \
      ((__REG_ID__) <= MT_KG_REG_IPL_PIPE_HIER_IRQ1_TST_ID)) ||          \
     (((__REG_ID__) >= MT_KG_TBL_IPL_PIPE_IPV4_6_PLTC_MEM_ID) &&         \
      ((__REG_ID__) <= MT_KG_TBL_IPL_PIPE_VLAN_PLTC_MEM_ID)))

#define HAL_MT_KG_PORT_SUBMODULE_UMAC 0
#define HAL_MT_KG_PORT_SUBMODULE_CMN  1
#define HAL_MT_KG_PORT_SUBMODULE_PIPE 2
#define HAL_MT_KG_PORT_SUBMODULE_LBM  3
#define HAL_MT_KG_PORT_SUBMODULE_LAST 4

#define HAL_MT_KG_PORT_DBG_REG_NUM_MAX       (50)
#define HAL_MT_KG_PORT_DBG_TOTAL_REG_NUM_MAX (700)

typedef struct hal_mt_kg_port_reg_info_s {
    uint32 reg_type;
    uint32 submodule;
    uint32 based;
    uint32 *reg_list;
    uint32 reg_cnt;
} hal_mt_kg_port_reg_info_t;

typedef struct hal_mt_kg_port_swap_info_s {
    uint32 umac_to_sd_swap[CLX_DIR_BOTH][HAL_MT_KG_ETH_MACRO_LANES_PER_MACRO];
    uint32 umac_to_pl_swap[CLX_DIR_BOTH][HAL_MT_KG_ETH_MACRO_LANES_PER_MACRO];
} hal_mt_kg_port_swap_info_t;

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_mt_kg_port_fc_e {
    HAL_MT_KG_PORT_FC_DISABLE,
    HAL_MT_KG_PORT_FC_PAUSE,
    HAL_MT_KG_PORT_FC_PFC,
    HAL_MT_KG_PORT_FC_LAST
} hal_mt_kg_port_fc_t;

#define HAL_MT_KG_PL_PAUSE_MODE      0
#define HAL_MT_KG_PL_PFC_MODE        1
#define HAL_MT_KG_PL_FC_DIS_MODE     2
#define HAL_MT_KG_PL_PAUSE_MODE_LAST 3

typedef struct hal_mt_kg_port_laneswap_s {
// laneswap type, 0: tx, 1: rx
#define HAL_MT_KG_PORT_LANESWAP_TYPE_TX (0)
#define HAL_MT_KG_PORT_LANESWAP_TYPE_RX (1)
    uint32 type;
    uint32 laneswap_mask;
    uint32 laneswap_val[HAL_MT_KG_ETH_MACRO_LANES_PER_MACRO];
} hal_mt_kg_port_laneswap_t;

typedef enum hal_mt_kg_port_mac_idx_e {
    HAL_MT_KG_MAC_IDX_MAC0 = 0x0, /* MAC0 */
    HAL_MT_KG_MAC_IDX_MAC1,       /* MAC1 */
    HAL_MT_KG_MAC_IDX_MAC2,       /* MAC2 */
    HAL_MT_KG_MAC_IDX_MAC3,       /* MAC3 */
    HAL_MT_KG_MAC_IDX_MAC4,       /* MAC4 */
    HAL_MT_KG_MAC_IDX_MAC5,       /* MAC5 */
    HAL_MT_KG_MAC_IDX_MAC6,       /* MAC6 */
    HAL_MT_KG_MAC_IDX_MAC7,       /* MAC7 */
    HAL_MT_KG_MAC_IDX_MAC8,       /* MAC8 */
    HAL_MT_KG_MAC_IDX_MAC9,       /* MAC9 */
    HAL_MT_KG_MAC_IDX_MAC10,      /* MAC10 */
    HAL_MT_KG_MAC_IDX_MAC11,      /* MAC11 */
    HAL_MT_KG_MAC_IDX_LAST
} hal_mt_kg_port_mac_idx_t;

/* MACRO FUNCTION DECLARATIONS
 */

/**
 * @brief This API is used to set the MAC address for a specific port.
 *
 * Example is as below.
 * clx_mac_t clx_mac = {0x0, 0x1, 0x2, 0x3, 0x4, 0x5};
 * uint32    hw_mac[2];
 * hw_mac[0] = 0x00010203;
 * hw_mac[1] = 0x0405;.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @param [in]    mac     - The MAC address.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_mac_addr_set(const uint32 unit, const uint32 port, const clx_mac_t mac);

/**
 * @brief This API is used to get the MAC address for a specific port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port ID.
 * @param [out]    ptr_mac    - The MAC address.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_mac_addr_get(const uint32 unit, const uint32 port, clx_mac_t *ptr_mac);

/**
 * @brief To apply default properties for the new created port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Set port default fail.
 */
clx_error_no_t
hal_mt_kg_port_default_set(const uint32 unit, const uint32 port);

/**
 * @brief To clear default properties for the destroyed port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Reset port default fail.
 */
clx_error_no_t
hal_mt_kg_port_default_reset(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to set the mapping between unit/port and mac/lane number.
 *
 * This API is suggested to be used during SDK initialization.
 * Support_chip: CLX8400.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Physical port ID.
 * @param [in]    ptr_lane_map    - Lane map info pointer.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_lane_map_set(const uint32 unit,
                            const uint32 port,
                            const clx_port_lane_map_info_t *ptr_lane_map);

/**
 * @brief This API is used to get the mapping between unit/port and mac/lane number.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Physical port ID.
 * @param [out]    ptr_lane_map    - Lane map info pointer.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_lane_map_get(const uint32 unit,
                            const uint32 port,
                            clx_port_lane_map_info_t *ptr_lane_map);

/**
 * @brief To set eth port dead lock.
 *
 * @param [in]    unit     - Chip id.
 * @param [in]    port     - Port id.
 * @param [in]    queue    - Queue id.
 * @param [in]    mode     - Dead lock state.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_dead_lock_set(const uint32 unit,
                             const uint32 port,
                             const uint32 queue,
                             const uint32 mode);

/**
 * @brief To set eth port dead lock.
 *
 * Set  based on 0.74ns unit. For example 100ms 1.35*10^8 (80B EFCO);.
 * Support_chip: CLX8400.
 *
 * @param [in]    unit         - Chip id.
 * @param [in]    port         - Port id.
 * @param [in]    threshold    - Dead lock threshold.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_dead_lock_th_set(const uint32 unit, const uint32 port, const uint32 threshold);

/**
 * @brief This API is used to set the medium type for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port ID.
 * @param [in]    medium    - Medium type.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_medium_type_set(const uint32 unit,
                               const uint32 port,
                               const clx_port_medium_t medium);

/**
 * @brief This API is used to get the medium type for a specific port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port ID.
 * @param [out]    ptr_medium    - Medium type.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_medium_type_get(const uint32 unit, const uint32 port, clx_port_medium_t *ptr_medium);

/**
 * @brief This API is used to set counter clear.
 *
 * Support_chip: CLX8400.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_SUPPORT      - This API is not support in this chip.
 */
clx_error_no_t
hal_mt_kg_port_fec_clear(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to show debug info.
 *
 * Support_chip: CLX8400.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port.
 * @param [in]    module    - Debug module.
 * @param [in]    type      - Debug info type.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_NOT_SUPPORT      - This API is not support in this chip.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_dbg_info_show(const uint32 unit,
                             const uint32 port,
                             const uint32 module,
                             const uint32 type);

/**
 * @brief Set tx state per physical port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - 1: enable tx state 0: disable tx state.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_tx_state_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Set Port config.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Port ID.
 * @param [in]    ptr_config    - Port config.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_cfg_set(const uint32 unit, const uint32 port, const clx_port_cfg_t *ptr_config);

/**
 * @brief Get port config.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Port ID.
 * @param [out]    ptr_config    - Port config.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_cfg_get(const uint32 unit, const uint32 port, clx_port_cfg_t *ptr_config);

/**
 * @brief This API is used to init port config.
 *
 * Support_chip: CLX8400.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK            - Success.
 * @return        CLX_E_NOT_INITED    - Module is not initialized.
 */
clx_error_no_t
hal_mt_kg_port_cfg_init(uint32 unit);

clx_error_no_t
hal_mt_kg_port_mac_config_update(uint32 unit, uint32 port, uint32 an_speed, uint32 an_fec);

/**
 * @brief To set the speed for a specific port.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port id.
 * @param [in]    speed    - The speed of the physical port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_speed_set(const uint32 unit, const uint32 port, const clx_port_speed_t speed);

/**
 * @brief To get the speed list for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port              - Physical port id.
 * @param [in]     max_len           - The max length of speedlist.
 * @param [out]    ptr_speed_list    - The supported speed list of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_speed_list_get(const uint32 unit,
                              const uint32 port,
                              const uint32 max_len,
                              clx_port_speed_t *ptr_speed_list);

/**
 * @brief To get the speed for a specific port.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port id.
 * @param [out]    ptr_speed    - The speed of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_speed_get(const uint32 unit, const uint32 port, clx_port_speed_t *ptr_speed);

/**
 * @brief To set the flow control configuration for a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port id.
 * @param [in]    fc      - The flow control configuration of the physical port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_flow_ctrl_set(const uint32 unit, const uint32 port, const clx_port_fc_dir_t fc);

/**
 * @brief To get the flow control configuration for a specific port.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Physical port id.
 * @param [out]    ptr_fc    - The flow control configuration of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_flow_ctrl_get(const uint32 unit, const uint32 port, clx_port_fc_dir_t *ptr_fc);

/**
 * @brief To set the PFC configuration for a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port id.
 * @param [in]    pri     - The priority number 0~7.
 * @param [in]    pfc     - The PFC configuration of the physical port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_pri_flow_ctrl_set(const uint32 unit,
                                 const uint32 port,
                                 const uint8 pri,
                                 const clx_port_fc_dir_t pfc);

/**
 * @brief To get the PFC configuration for a specific port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port id.
 * @param [in]     pri        - The priority number 0~7.
 * @param [out]    ptr_pfc    - The PFC configuration of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_pri_flow_ctrl_get(const uint32 unit,
                                 const uint32 port,
                                 const uint8 pri,
                                 clx_port_fc_dir_t *ptr_pfc);

/**
 * @brief To get the EEE mode for a specific port.
 *
 * NB umac not support eee.
 * Support_chip: CLX8400.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port id.
 * @param [out]    ptr_mode    - The EEE mode of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_eee_mode_get(const uint32 unit, const uint32 port, clx_port_eee_mode_t *ptr_mode);

/**
 * @brief This API is used to get the ability for a specific port.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port ID.
 * @param [out]    ptr_ability    - Port ability.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_ability_get(const uint32 unit, const uint32 port, clx_port_ability_t *ptr_ability);

/**
 * @brief To set the auto-negotiation advertisement for a specific port.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port           - Physical port id.
 * @param [in]    ptr_ability    - Autonegotiation ability setting per port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_local_adv_ability_set(const uint32 unit,
                                     const uint32 port,
                                     const clx_port_ability_t *ptr_ability);

/**
 * @brief To get the auto-negotiation advertisement for a specific port.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port           - Physical port id.
 * @param [in]    ptr_ability    - Autonegotiation ability setting per port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_local_adv_ability_get(const uint32 unit,
                                     const uint32 port,
                                     clx_port_ability_t *ptr_ability);

/**
 * @brief This API is used to get the auto-negotiation remote advertisement for a specific port.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port ID.
 * @param [out]    ptr_ability    - Autonegotiation ability setting per port.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_remote_adv_ability_get(const uint32 unit,
                                      const uint32 port,
                                      clx_port_ability_t *ptr_ability);

/**
 * @brief This API is used to set the loopback for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port ID.
 * @param [in]    lbtype    - Loopback type: CLX_PORT_LOOPBACK_DISABLE: disable loopback.
 *                            CLX_PORT_LOOPBACK_PHY: local PHY loopback.
 *                             CLX_PORT_LOOPBACK_PHY_NEAR_END_PARALLEL: local PHY parallel loopback.
 *                            CLX_PORT_LOOPBACK_PHY_FAR_END_SERIAL: remote serial loopback.
 *                            CLX_PORT_LOOPBACK_PHY_FAR_END_PARALLEL: remote parallel loopback
 *                            external phy. CLX_PORT_LOOPBACK_MAC: local MAC loopback.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_lb_set(const uint32 unit, const uint32 port, const clx_port_loopback_t lbtype);

/**
 * @brief This API is used to get the loopback for a specific port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port ID.
 * @param [out]    ptr_lbtype    - Loopback type: CLX_PORT_LOOPBACK_DISABLE: disable loopback.
 *                                 CLX_PORT_LOOPBACK_PHY: local PHY loopback.
 *                                  CLX_PORT_LOOPBACK_PHY_NEAR_END_PARALLEL: local PHY parallel
 *                                 loopback. CLX_PORT_LOOPBACK_PHY_FAR_END_SERIAL: remote serial
 *                                 loopback. CLX_PORT_LOOPBACK_PHY_FAR_END_PARALLEL: remote
 *                                 parallel loopback external phy. CLX_PORT_LOOPBACK_MAC: local MAC
 *                                 loopback.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_lb_get(const uint32 unit, const uint32 port, clx_port_loopback_t *ptr_lbtype);

/**
 * @brief This API is used to initialize a specific port.
 *
 * @param [in]    unit                 - Device unit number.
 * @param [in]    port                 - Physical port ID.
 * @param [in]    ptr_create_config    - Port create config.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_create(const uint32 unit,
                      const uint32 port,
                      const clx_port_create_config_t *ptr_create_config);

/**
 * @brief This API is used to deinitialize a specific port.
 *
 * All ports in the same sub-marco on CL8600 must
 * link/admin down first before deinit a port.
 * Support_chip: CLX8400.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_destroy(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to set the PHY configuration for a specific port.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port ID.
 * @param [in]    ptr_config    - PHY config.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_phy_cfg_set(const uint32 unit,
                           const uint32 port,
                           const clx_port_phy_cfg_t *ptr_config);

/**
 * @brief This API is used to get the PHY configuration for a specific port.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port ID.
 * @param [in]    ptr_config    - PHY config.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_phy_cfg_get(const uint32 unit, const uint32 port, clx_port_phy_cfg_t *ptr_config);

/**
 * @brief This API is used to set the egress TPID0 as TPID1 value for RSPAN port.
 *
 * Called by mirror module.
 * Support_chip: CLX8400.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    port             - Port Number.
 * @param [in]    is_rspan_port    - Port is RSPAN port.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_egr_port_tpid_for_rspan_set(const uint32 unit,
                                           const uint32 port,
                                           const boolean is_rspan_port);

/**
 * @brief Get port tx timestamp entry information.
 *
 * @param [in]     unit            - Chip id.
 * @param [in]     port            - Port id.
 * @param [out]    ptr_ts_entry    - Timestamp entry information.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_ts_tx_entry_get(const uint32 unit,
                               const uint32 port,
                               clx_port_ts_entry_t *ptr_ts_entry);

/**
 * @brief This API is used to set the MAC tx reset state for a specific port.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port ID.
 * @param [in]    state    - The MAC tx reset state.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_mac_txrst_set(const uint32 unit, const uint32 port, uint32 state);

/**
 * @brief This API is used to get xoff status.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     port               - Physical port.
 * @param [out]    ptr_xoff_status    - Xoff status.
 * @return         CLX_E_OK             - Success.
 * @return         CLX_E_NOT_SUPPORT    - This API is not support in this chip.
 */
clx_error_no_t
hal_mt_kg_port_xoff_status_get(const uint32 unit,
                               const uint32 port,
                               clx_port_xoff_status_t *ptr_xoff_status);

/**
 * @brief Set laneswap value for a specific port.
 *
 * @param [in]    unit                - Device unit number.
 * @param [in]    port                - Port.
 * @param [in]    lane_cnt            - Number of lanes.
 * @param [in]    ptr_laneswap_val    - Value of laneswap.
 * @param [in]    type                - Laneswap type, 0: tx, 1: rx.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_laneswap_set(uint32 unit,
                            uint32 port,
                            uint32 lane_cnt,
                            const uint32 *ptr_laneswap_val,
                            uint32 type);

/**
 * @brief Get laneswap value for a specific port.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     port                - Port.
 * @param [in]     lane_cnt            - Number of lanes.
 * @param [out]    ptr_laneswap_val    - Value of laneswap.
 * @param [in]     type                - Laneswap type, 0: tx, 1: rx.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_laneswap_get(uint32 unit,
                            uint32 port,
                            uint32 lane_cnt,
                            uint32 *ptr_laneswap_val,
                            uint32 type);

/**
 * @brief This API is used to set the tc2q map for a specific port.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Device port number.
 * @param [in]    dir         - Direction of pl.
 * @param [in]    tc2q_map    - TC2Q map.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_tc2q_map_set(uint32 unit, uint32 port, clx_dir_t dir, uint32 *tc2q_map);

/**
 * @brief This API is used to get the tc2q map for a specific port.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Device port number.
 * @param [in]    dir         - Direction of pl.
 * @param [in]    tc2q_map    - TC2Q map.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_tc2q_map_get(uint32 unit, uint32 port, clx_dir_t dir, uint32 *tc2q_map);

/**
 * @brief This API is used to set the epl xoff mask pltc for a specific port.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Device port number.
 * @param [in]    pltc_bmp    - PTC bitmap.
 * @param [in]    enable      - Enable.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_egress_xoff_mask_port_pltc_set(const uint32 unit,
                                              const uint32 port,
                                              const uint32 pltc_bmp,
                                              uint32 enable);

/**
 * @brief This API is used to get the q2tc map for a specific port.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Device port number.
 * @param [in]    q2tc_map    - Q2TC map.
 * @param [in]    dir         - Direction of pl.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_q2tc_map_get(uint32 unit, uint32 port, clx_dir_t dir, uint32 *q2tc_map);

/**
 * @brief This API is used to set the q2tc map for a specific port.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Device port number.
 * @param [in]    dir         - Direction of pl.
 * @param [in]    q2tc_map    - Q2TC map.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_q2tc_map_set(uint32 unit, uint32 port, clx_dir_t dir, uint32 *q2tc_map);

/**
 * @brief This API is used to get the ipl fc mode for a specific port.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Device port number.
 * @param [in]    ptr_mode    - Pfc mod.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_ingress_fc_mode_get(uint32 unit, uint32 port, uint32 *ptr_mode);

/**
 * @brief This API is used to set the ipl dscp pltc map for a specific port.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Device port number.
 * @param [in]    dscp            - Dscp.
 * @param [in]    ptr_loss_idx    - Loss index.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_ingress_dscp_pltc_map_set(uint32 unit, uint32 port, uint32 dscp, uint32 ptr_loss_idx);

/**
 * @brief This API is used to get the ipl dscp pltc map for a specific port.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Device port number.
 * @param [in]    dscp            - Dscp.
 * @param [in]    ptr_loss_idx    - Loss index.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_ingress_dscp_pltc_map_get(uint32 unit,
                                         uint32 port,
                                         uint32 dscp,
                                         uint32 *ptr_loss_idx);

/**
 * @brief This API is used to get the ipl vlan pltc map for a specific port.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Device port number.
 * @param [in]    pcp             - Dscp.
 * @param [in]    dei             - DEI.
 * @param [in]    ptr_loss_idx    - Loss index.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_ingress_vlan_pltc_map_get(uint32 unit,
                                         uint32 port,
                                         uint32 pcp,
                                         uint32 dei,
                                         uint32 *ptr_loss_idx);

/**
 * @brief This API is used to set the ipl vlan pltc map for a specific port.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Device port number.
 * @param [in]    pcp             - Dscp.
 * @param [in]    dei             - DEI.
 * @param [in]    ptr_loss_idx    - Loss index.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_ingress_vlan_pltc_map_set(uint32 unit,
                                         uint32 port,
                                         uint32 pcp,
                                         uint32 dei,
                                         uint32 ptr_loss_idx);

/**
 * @brief This API is used to get the ipl exp pltc map for a specific port.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Device port number.
 * @param [in]    exp             - Exp.
 * @param [in]    ptr_loss_idx    - Loss index.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_ingress_exp_pltc_map_get(uint32 unit, uint32 port, uint32 exp, uint32 *ptr_loss_idx);

/**
 * @brief This API is used to set the ipl exp pltc map for a specific port.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Device port number.
 * @param [in]    exp             - Exp.
 * @param [in]    ptr_loss_idx    - Loss index.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_ingress_exp_pltc_map_set(uint32 unit, uint32 port, uint32 exp, uint32 ptr_loss_idx);

/**
 * @brief To set the RX idle for a specific port.
 *
 * @param [in]    unit      - Chip id.
 * @param [in]    port      - Port id.
 * @param [in]    enable    - Enable or disable RX idle.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_rxidle_set(const uint32 unit, const uint32 port, uint32 enable);

/**
 * @brief To get the RX idle for a specific port.
 *
 * @param [in]    unit       - Chip id.
 * @param [in]    port       - Port id.
 * @param [in]    rx_idle    - Enable or disable RX idle.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_rxidle_get(const uint32 unit, const uint32 port, uint32 *rx_idle);

/**
 * @brief Set the TPID for the first VLAN tag.
 *
 * This function sets the TPID for the first VLAN tag on a port.
 *
 * @param [in]    unit       - Chip id.
 * @param [in]    port       - Port id.
 * @param [in]    tp_type    - TPID type.
 * @param [in]    tpid       - TPID value.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_mac_tpid_set(const uint32 unit, const uint32 port, const uint32 tp_type, uint32 tpid);

/**
 * @brief This API is used to set the epl queue flush enable for a specific port.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Device port number.
 * @param [in]    queue_type    - Choose HAL_MT_PORT_LOSSLESS_QUEUE or HAL_MT_PORT_LOSSY_QUEUE.
 * @param [in]    enable        - Flush enable.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_egress_que_flush_en_set(const uint32 unit,
                                       const uint32 port,
                                       const uint32 queue_type,
                                       const uint32 enable);

/**
 * @brief This API is used to set the epl flow ctrl ignore for a specific port.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Device port number.
 * @param [in]    queue_type    - Choose HAL_MT_PORT_LOSSLESS_QUEUE or HAL_MT_PORT_LOSSY_QUEUE.
 * @param [in]    enable        - Ignore enable.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_egress_flow_ctrl_ignore_set(const uint32 unit,
                                           const uint32 port,
                                           const uint32 queue_type,
                                           uint32 enable);

/**
 * @brief Get mburst statistic.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [in]     dir         - Direction.
 * @param [out]    ptr_stat    - Mburst stat.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_mburst_stat_get(const uint32 unit,
                               const uint32 port,
                               const clx_dir_t dir,
                               clx_port_mburst_stat_t *ptr_stat);

/**
 * @brief Set Mburst property.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Physical port ID.
 * @param [in]    ptr_cfg    - Property type.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_mburst_cfg_set(const uint32 unit,
                              const uint32 port,
                              const clx_port_mburst_cfg_t *ptr_cfg);

/**
 * @brief Get capacity of port-related resource.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     type        - Resource type.
 * @param [in]     param       - Parameter if necessary.
 * @param [out]    ptr_size    - Size of capacity.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_capacity_get(const uint32 unit,
                            const clx_swc_rsrc_t type,
                            const uint32 param,
                            uint32 *ptr_size);

/**
 * @brief Get usage of port-related resource.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     type       - Resource type.
 * @param [in]     param      - Parameter if necessary.
 * @param [out]    ptr_cnt    - Count of usage.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_usage_get(const uint32 unit,
                         const clx_swc_rsrc_t type,
                         const uint32 param,
                         uint32 *ptr_cnt);

/**
 * @brief This API is used to update the portlist for port reset command.
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     init_lane_cnt        - Initial lane count.
 * @param [in]     init_speed           - Initial speed.
 * @param [in]     ptr_portlist         - Port list.
 * @param [in]     ptr_init_portlist    - Initial port list.
 * @param [out]    init_port_cnt        - Initial port count.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_reset_portlist_update(const uint32 unit,
                                     const uint32 init_lane_cnt,
                                     const clx_port_speed_t init_speed,
                                     clx_port_bitmap_t *ptr_portlist,
                                     clx_port_bitmap_t *ptr_init_portlist,
                                     uint32 *init_port_cnt);

/**
 * @brief Deinit laneswap. called in port deinit.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_laneswap_deinit(uint32 unit);

/**
 * @brief To set the phy speed for a specific port.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port id.
 * @param [in]    speed    - The speed of the physical port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_phy_speed_set(const uint32 unit, const uint32 port, const clx_port_speed_t speed);

/*
 * @brief Process SyncE for a specific port.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     port               - Physical port id.
 * @param [in]     link_status        - Link status.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_synce_process(const uint32 unit, const uint32 port, const uint32 link_status);

/**
 * @brief This API is used to set destination index.
 *
 * Support_chip: CLX8400.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port.
 * @param [in]    di      - Destination index.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_di_set(const uint32 unit, const uint32 port, const uint32 di);

/**
 * @brief This API is used to get signal OK.
 *
 * Support_chip: CLX8400.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - Physical port.
 * @param [out]    ptr_signal_ok    - Signal OK value.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_signal_get(const uint32 unit,
                             const uint32 port,
                             uint32 *ptr_signal_ok);
#endif /* #ifndef HAL_MT_KG_PORT_H */
