/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_srv6.h
 * PURPOSE:
 *      It provide srv6 tunnel hal chip layer api.
 * NOTES:
 *
 */

#ifndef HAL_MT_KG_SRV6_H
#define HAL_MT_KG_SRV6_H

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief Traverse srv6 tunnel information then save to a list.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     type        - Swdb type to be traversed.
 * @param [out]    ptr_list    - List to store srv6 information.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_srv6_trav_list_trans(const uint32 unit,
                               const hal_srv6_trav_type_t type,
                               util_lib_list_t *ptr_list);

clx_error_no_t
hal_mt_kg_srv6_ecmp_grp_id_to_tnl_idx_trav(const uint32 unit,
                                           const uint32 ecmp_grp_id,
                                           uint32 *tnl_idx_list,
                                           uint32 *tnl_idx_list_size);

clx_error_no_t
hal_mt_kg_srv6_cfg_init(const uint32 unit);

clx_error_no_t
hal_mt_kg_srv6_warm_init(const uint32 unit);

clx_error_no_t
hal_mt_kg_srv6_warm_deinit(const uint32 unit);

clx_error_no_t
hal_mt_kg_srv6_encap_add(const uint32 unit,
                         const clx_port_t port,
                         const clx_srv6_encap_cfg_t *ptr_encap_info);

clx_error_no_t
hal_mt_kg_srv6_encap_del(const uint32 unit, const clx_port_t port);

clx_error_no_t
hal_mt_kg_srv6_encap_set(const uint32 unit,
                         const clx_port_t port,
                         const clx_srv6_encap_cfg_t *ptr_encap_info);

clx_error_no_t
hal_mt_kg_srv6_encap_get(const uint32 unit,
                         const clx_port_t port,
                         clx_srv6_encap_cfg_t *ptr_encap_info);

clx_error_no_t
hal_mt_kg_srv6_encap_trav(const uint32 unit,
                          const clx_srv6_encap_trav_func_t callback,
                          void *ptr_cookie);

clx_error_no_t
hal_mt_kg_srv6_local_add(const uint32 unit,
                         const clx_port_t port,
                         const clx_srv6_local_cfg_t *ptr_local_info);

clx_error_no_t
hal_mt_kg_srv6_local_del(const uint32 unit, const clx_port_t port);

clx_error_no_t
hal_mt_kg_srv6_local_set(const uint32 unit,
                         const clx_port_t port,
                         const clx_srv6_local_cfg_t *ptr_local_info);

clx_error_no_t
hal_mt_kg_srv6_local_get(const uint32 unit,
                         const clx_port_t port,
                         clx_srv6_local_cfg_t *ptr_local_info);

clx_error_no_t
hal_mt_kg_srv6_local_trav(const uint32 unit,
                          const clx_srv6_local_trav_func_t callback,
                          void *ptr_cookie);

clx_error_no_t
hal_mt_kg_srv6_property_set(const uint32 unit, const clx_srv6_property_t *ptr_property);

clx_error_no_t
hal_mt_kg_srv6_property_get(const uint32 unit, clx_srv6_property_t *ptr_property);

clx_error_no_t
hal_mt_kg_srv6_srv_sid_add(const uint32 unit,
                           const clx_port_t port,
                           const clx_srv6_sid_map_t *ptr_sid_map);

clx_error_no_t
hal_mt_kg_srv6_srv_sid_del(const uint32 unit,
                           const clx_port_t port,
                           const clx_srv6_sid_map_t *ptr_sid_map);

clx_error_no_t
hal_mt_kg_srv6_srv_sid_set(const uint32 unit,
                           const clx_port_t port,
                           const clx_srv6_sid_map_t *ptr_sid_map);

clx_error_no_t
hal_mt_kg_srv6_srv_sid_get(const uint32 unit,
                           const clx_port_t port,
                           clx_srv6_sid_map_t *ptr_sid_map);

clx_error_no_t
hal_mt_kg_srv6_nvo3_route_add(const uint32 unit,
                              const clx_port_t port,
                              const clx_srv6_nvo3_route_info_t *ptr_srv6_nvo3_route);

clx_error_no_t
hal_mt_kg_srv6_nvo3_route_del(const uint32 unit, const clx_port_t port);

clx_error_no_t
hal_mt_kg_srv6_nvo3_route_set(const uint32 unit,
                              const clx_port_t port,
                              const clx_srv6_nvo3_route_info_t *ptr_srv6_nvo3_route);

clx_error_no_t
hal_mt_kg_srv6_nvo3_route_get(const uint32 unit,
                              const clx_port_t port,
                              clx_srv6_nvo3_route_info_t *ptr_srv6_nvo3_route);

clx_error_no_t
hal_mt_kg_srv6_nvo3_route_trav(const uint32 unit,
                               const clx_srv6_nvo3_route_trav_func_t callback,
                               void *ptr_cookie);

clx_error_no_t
hal_mt_kg_srv6_mysid_entry_add(const uint32 unit,
                               const clx_srv6_mysid_entry_t *ptr_mysid_entry,
                               const clx_srv6_mysid_cfg_t *ptr_mysid_info);

clx_error_no_t
hal_mt_kg_srv6_mysid_entry_del(const uint32 unit, const clx_srv6_mysid_entry_t *ptr_mysid_entry);

clx_error_no_t
hal_mt_kg_srv6_mysid_entry_set(const uint32 unit,
                               const clx_srv6_mysid_entry_t *ptr_mysid_entry,
                               const clx_srv6_mysid_cfg_t *ptr_mysid_info);

clx_error_no_t
hal_mt_kg_srv6_mysid_entry_get(const uint32 unit,
                               const clx_srv6_mysid_entry_t *ptr_mysid_entry,
                               clx_srv6_mysid_cfg_t *ptr_mysid_info);

clx_error_no_t
hal_mt_kg_srv6_mysid_entry_trav(const uint32 unit,
                                const clx_srv6_mysid_entry_trav_func_t callback,
                                void *ptr_cookie);

clx_error_no_t
hal_mt_kg_srv6_seg_srv_add(const uint32 unit,
                           const clx_port_t port,
                           const uint32 service_id,
                           const uint32 bdid);

clx_error_no_t
hal_mt_kg_srv6_seg_srv_del(const uint32 unit, const clx_port_t port, const uint32 service_id);

clx_error_no_t
hal_mt_kg_srv6_seg_srv_set(const uint32 unit,
                           const clx_port_t port,
                           const uint32 service_id,
                           const uint32 bdid);

clx_error_no_t
hal_mt_kg_srv6_seg_srv_get(const uint32 unit,
                           const clx_port_t port,
                           const uint32 service_id,
                           uint32 *ptr_bdid);

clx_error_no_t
hal_mt_kg_srv6_endpoint_policy_add(const uint32 unit,
                                   const clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

clx_error_no_t
hal_mt_kg_srv6_endpoint_policy_del(const uint32 unit,
                                   const clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

clx_error_no_t
hal_mt_kg_srv6_endpoint_policy_set(const uint32 unit,
                                   const clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

clx_error_no_t
hal_mt_kg_srv6_endpoint_policy_get(const uint32 unit,
                                   clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

clx_error_no_t
hal_mt_kg_srv6_endpoint_policy_trav(const uint32 unit,
                                    const clx_srv6_endpoint_policy_trav_func_t callback,
                                    void *ptr_cookie);
#endif /* End of HAL_MT_KG_SRV6_H */
