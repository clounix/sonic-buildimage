/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_port_umac.h
 * PURPOSE:
 *      It provide HAL PORT UMAC module API.
 * NOTES:
 */

#ifndef __HAL_MT_KG_PORT_UMAC_H__
#define __HAL_MT_KG_PORT_UMAC_H__

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
/* DATA TYPE DECLARATIONS
 */

typedef enum hal_mt_kg_port_umac_chmode_e {
    HAL_MT_KG_PORT_UMAC_CHMODE_DISABLED = 0,       /* 6'd00 : Disabled */
    HAL_MT_KG_PORT_UMAC_CHMODE_10M_SGMII = 1,      /* 6'd01 : 10M SGMII */
    HAL_MT_KG_PORT_UMAC_CHMODE_100M_SGMII = 4,     /* 6'd04 : 100M SGMII */
    HAL_MT_KG_PORT_UMAC_CHMODE_1G_SGMII = 7,       /* 6'd07 : 1G SGMII */
    HAL_MT_KG_PORT_UMAC_CHMODE_1G_BASEX = 9,       /* 6'd09 : 1GBASE-X */
    HAL_MT_KG_PORT_UMAC_CHMODE_2P5G_USXGMII = 11,  /* 6'd11: 2.5G USXGMII */
    HAL_MT_KG_PORT_UMAC_CHMODE_5G_USXGMII = 13,    /* 6'd13: 5G USXGMII */
    HAL_MT_KG_PORT_UMAC_CHMODE_10G_R1 = 15,        /* 6'd15 : 10GBASE-R */
    HAL_MT_KG_PORT_UMAC_CHMODE_10G_R1_FC = 16,     /* 6'd16 : 10GBASE-R + FC(2112, 2080) */
    HAL_MT_KG_PORT_UMAC_CHMODE_25G_R1 = 21,        /* 6'd21 : 25GBASE-R1 */
    HAL_MT_KG_PORT_UMAC_CHMODE_25G_R1_FC = 22,     /* 6'd22 : 25GBASE-R1 + FC(2112, 2080) */
    HAL_MT_KG_PORT_UMAC_CHMODE_25G_R1_RS = 23,     /* 6'd23 : 25GBASE-R1 + RS(528, 514) (IEEE
                                                      802.3-2018) */
    HAL_MT_KG_PORT_UMAC_CHMODE_25G_R1_CON_RS = 24, /* 6'd24 : 25GBASE-R1 + RS(528, 514)
                                                      (Consortium r2.0) */
    HAL_MT_KG_PORT_UMAC_CHMODE_40G_R4 = 26,        /* 6'd26 : 40GBASE-R4 */
    HAL_MT_KG_PORT_UMAC_CHMODE_40G_R4_FC = 27,     /* 6'd27 : 40GBASE-R4 + FC(2112, 2080) */
    HAL_MT_KG_PORT_UMAC_CHMODE_40G_R2 = 28,        /* 6'd28 : 40GBASE-R2 */
    HAL_MT_KG_PORT_UMAC_CHMODE_40G_R2_FC = 29,     /* 6'd29 : 40GBASE-R2 + FC(2112, 2080) */
    HAL_MT_KG_PORT_UMAC_CHMODE_50G_R2 = 37,        /* 6'd37 : 50GBASE-R2 */
    HAL_MT_KG_PORT_UMAC_CHMODE_50G_R2_FC = 38,     /* 6'd38 : 50GBASE-R2 + FC(2112, 2080) */
    HAL_MT_KG_PORT_UMAC_CHMODE_50G_R2_RS = 39,     /* 6'd39 : 50GBASE-R2 + RS(528, 514) */
    HAL_MT_KG_PORT_UMAC_CHMODE_50G_R1_KP = 43,     /* 6'd43 : 50GBASE-R1 + RS(544, 514) */
    HAL_MT_KG_PORT_UMAC_CHMODE_100G_R2_KP_CK = 44, /* 6'd44 : 100GBASE-R2 + RS(544, 514)-Int
                                                      (Clause 161) */
    HAL_MT_KG_PORT_UMAC_CHMODE_100G_R1_KP_CK = 45, /* 6'd45 */
    HAL_MT_KG_PORT_UMAC_CHMODE_100G_R4 = 46,       /* 6'd46 : 100GBASE-R4 */
    HAL_MT_KG_PORT_UMAC_CHMODE_100G_R4_RS = 47,    /* 6'd47 : 100GBASE-R4 + RS(528, 514) (Clause
                                                      91) */
    HAL_MT_KG_PORT_UMAC_CHMODE_100G_R2_KP = 50,    /* 6'd50 : 100GBASE-R2 + RS(544, 514) (Clause
                                                      91) */
    HAL_MT_KG_PORT_UMAC_CHMODE_200G_R8_KP = 52,    /* 6'd52 */
    HAL_MT_KG_PORT_UMAC_CHMODE_200G_R4_KP = 53,    /* 6'd53 : 200GBASE-R4 + RS(544, 514) */
    HAL_MT_KG_PORT_UMAC_CHMODE_400G_R8_KP = 56,    /* 6'd56 : 400GBASE-R8 + RS(544, 514) */
    HAL_MT_KG_PORT_UMAC_CHMODE_LAST
} hal_mt_kg_port_umac_chmode_t;

typedef struct hal_mt_kg_port_umac_chmode_cfg_s {
    uint32 mode;     /* Channel mode */
    uint32 txen;     /* TX enable */
    uint32 txdrain;  /* TX drain */
    uint32 rxen;     /* RX enable */
    uint32 gmiilpbk; /* GMII loopback */
    uint32 txjabber; /* TX jabber */
    uint32 rxjabber; /* RX jabber */
    uint32 disfcs;   /* Disable FCS */
    uint32 invfcs;   /* Invert FCS */
    uint32 ignfcs;   /* Ignore FCS */
    uint32 stripfcs; /* Strip FCS */
    uint32 ifglen;   /* IFG length */
    uint32 txswrst;  /* TX soft reset */
    uint32 rxswrst;  /* RX soft reset */

/* CHMODE related definitions */
#define HAL_MT_KG_PORT_UMAC_CHMODE_MODE     (1UL << 0)
#define HAL_MT_KG_PORT_UMAC_CHMODE_TXEN     (1UL << 2)
#define HAL_MT_KG_PORT_UMAC_CHMODE_TXDRAIN  (1UL << 3)
#define HAL_MT_KG_PORT_UMAC_CHMODE_RXEN     (1UL << 4)
#define HAL_MT_KG_PORT_UMAC_CHMODE_GMIILPBK (1UL << 5)
#define HAL_MT_KG_PORT_UMAC_CHMODE_TXJABBER (1UL << 6)
#define HAL_MT_KG_PORT_UMAC_CHMODE_RXJABBER (1UL << 7)
#define HAL_MT_KG_PORT_UMAC_CHMODE_DISFCS   (1UL << 8)
#define HAL_MT_KG_PORT_UMAC_CHMODE_INVFCS   (1UL << 9)
#define HAL_MT_KG_PORT_UMAC_CHMODE_IGNFCS   (1UL << 10)
#define HAL_MT_KG_PORT_UMAC_CHMODE_STRIPFCS (1UL << 11)
#define HAL_MT_KG_PORT_UMAC_CHMODE_IFGLEN   (1UL << 12)
#define HAL_MT_KG_PORT_UMAC_CHMODE_TXSWRST  (1UL << 13)
#define HAL_MT_KG_PORT_UMAC_CHMODE_RXSWRST  (1UL << 14)
#define HAL_MT_KG_PORT_UMAC_CHMODE_LAST     (1UL << 15)
#define HAL_MT_KG_PORT_UMAC_CHMODE_ALL      (HAL_MT_KG_PORT_UMAC_CHMODE_LAST - 1)
    uint32 flag; /* Indicate which fields are valid */
} hal_mt_kg_port_umac_chmode_cfg_t;

typedef struct hal_mt_kg_port_umac_chconfig3_cfg_s {
    uint32 ifg0b;            /* IFG0B */
    uint32 counterrvlan;     /* Counter RVLAN */
    uint32 customhdr;        /* Custom header */
    uint32 rxmaxfrmsize;     /* RX max frame size */
    uint32 txpreamble;       /* TX preamble */
    uint32 txdrainonfault;   /* TX drain on fault */
    uint32 rxpreamble;       /* RX preamble */
    uint32 rxerrmask;        /* RX error mask */
    uint32 sjsize;           /* SJ size */
    uint32 txrepcrcovrd;     /* TX REP CRC override */
    uint32 exclpfcglblstats; /* Exclude PFC global stats */
    uint32 clrstatsswrst;    /* Clear stats on SW reset */
    uint32 alwaysfilterfc;   /* Always filter FC */

/* CHCONFIG3 related definitions */
#define HAL_MT_KG_PORT_UMAC_CHCONFIG3_IFG0B            (1UL << 0)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG3_COUNTERRVLAN     (1UL << 1)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG3_CUSTOMHDR        (1UL << 2)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG3_RXMAXFRMSIZE     (1UL << 4)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG3_TXPREAMBLE       (1UL << 5)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG3_TXDRAINONFAULT   (1UL << 6)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG3_RXPREAMBLE       (1UL << 7)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG3_RXERRMASK        (1UL << 8)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG3_SJSIZE           (1UL << 9)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG3_TXREPCRCOVRD     (1UL << 10)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG3_EXCLPFCGLBLSTATS (1UL << 11)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG3_CLRSTATSONSWRST  (1UL << 12)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG3_ALWAYSFILTERFC   (1UL << 13)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG3_LAST             (1UL << 14)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG3_ALL              (HAL_MT_KG_PORT_UMAC_CHCONFIG3_LAST - 1)
    uint32 flag; /* Indicate which fields are valid */
} hal_mt_kg_port_umac_chconfig3_cfg_t;

typedef struct hal_mt_kg_port_umac_maccfg_cfg_s {
    uint32 disfcsonerr;   /* Disable FCS on error */
    uint32 txfcen;        /* TX flow control enable */
    uint32 rxfcen;        /* RX flow control enable */
    uint32 rxpfcen;       /* RX PFC enable */
    uint32 rxfctotx;      /* RX flow control to TX */
    uint32 rxfilterfc;    /* RX filter flow control */
    uint32 rxfilterpfc;   /* RX filter PFC */
    uint32 txrdthresh;    /* TX read threshold */
    uint32 txlfault;      /* TX link fault */
    uint32 txrfault;      /* TX remote fault */
    uint32 txidle;        /* TX idle */
    uint32 rxlfault;      /* RX link fault */
    uint32 rxrfault;      /* RX remote fault */
    uint32 rxidle;        /* RX idle */
    uint32 txstrictfault; /* TX strict fault */
    uint32 statclr;       /* Stats clear */
    uint32 txignorerx;    /* TX ignore RX */
    uint32 txpfcen;       /* TX PFC enable */

/* MACCFG related definitions */
#define HAL_MT_KG_PORT_UMAC_MACCFG_DISFCSONERR   (1UL << 1)
#define HAL_MT_KG_PORT_UMAC_MACCFG_TXFCEN        (1UL << 3)
#define HAL_MT_KG_PORT_UMAC_MACCFG_RXFCEN        (1UL << 5)
#define HAL_MT_KG_PORT_UMAC_MACCFG_RXPFCEN       (1UL << 6)
#define HAL_MT_KG_PORT_UMAC_MACCFG_RXFCTOTX      (1UL << 7)
#define HAL_MT_KG_PORT_UMAC_MACCFG_RXFILTERFC    (1UL << 8)
#define HAL_MT_KG_PORT_UMAC_MACCFG_RXFILTERPFC   (1UL << 9)
#define HAL_MT_KG_PORT_UMAC_MACCFG_TXRDTHRESH    (1UL << 11)
#define HAL_MT_KG_PORT_UMAC_MACCFG_TXLFAULT      (1UL << 12)
#define HAL_MT_KG_PORT_UMAC_MACCFG_TXRFAULT      (1UL << 13)
#define HAL_MT_KG_PORT_UMAC_MACCFG_TXIDLE        (1UL << 14)
#define HAL_MT_KG_PORT_UMAC_MACCFG_RXLFAULT      (1UL << 16)
#define HAL_MT_KG_PORT_UMAC_MACCFG_RXRFAULT      (1UL << 17)
#define HAL_MT_KG_PORT_UMAC_MACCFG_RXIDLE        (1UL << 18)
#define HAL_MT_KG_PORT_UMAC_MACCFG_TXSTRICTFAULT (1UL << 19)
#define HAL_MT_KG_PORT_UMAC_MACCFG_STATSCLR      (1UL << 20)
#define HAL_MT_KG_PORT_UMAC_MACCFG_TXIGNORERX    (1UL << 21)
#define HAL_MT_KG_PORT_UMAC_MACCFG_TXPFCEN       (1UL << 22)
#define HAL_MT_KG_PORT_UMAC_MACCFG_LAST          (1UL << 23)
#define HAL_MT_KG_PORT_UMAC_MACCFG_ALL           (HAL_MT_KG_PORT_UMAC_MACCFG_LAST - 1)
    uint32 flag; /* Indicate which fields are valid */
} hal_mt_kg_port_umac_maccfg_cfg_t;

typedef struct hal_mt_kg_port_umac_chconfig6_cfg_s {
    uint32 corrbyp;        /* Correction bypass */
    uint32 indibyp;        /* Indication bypass */
    uint32 hiserthresh;    /* High SER threshold */
    uint32 degserenable;   /* Degraded SER enable */
    uint32 degserinterval; /* Degraded SER interval */
    uint32 txllfecen;      /* TX LL FEC enable */
    uint32 rxllfecen;      /* RX LL FEC enable */

/* CHCONFIG6 related definitions */
#define HAL_MT_KG_PORT_UMAC_CHCONFIG6_CORRBYP        (1UL << 0)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG6_INDIBYP        (1UL << 1)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG6_HISERTHRESH    (1UL << 2)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG6_DEGSERENABLE   (1UL << 3)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG6_DEGSERINTERVAL (1UL << 4)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG6_TXLLFECEN      (1UL << 5)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG6_RXLLFECEN      (1UL << 6)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG6_LAST           (1UL << 7)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG6_ALL            (HAL_MT_KG_PORT_UMAC_CHCONFIG6_LAST - 1)
    uint32 flag; /* Indicate which fields are valid */
} hal_mt_kg_port_umac_chconfig6_cfg_t;

typedef struct hal_mt_kg_port_umac_chconfig4_cfg_s {
    uint32 macaddr[2];  /* MAC address */
    uint32 pauseontime; /* Pause on time */

/* CHCONFIG34 related definitions */
#define HAL_MT_KG_PORT_UMAC_CHCONFIG4_MACADDR     (1UL << 0)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG4_PAUSEONTIME (1UL << 1)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG4_LAST        (1UL << 2)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG4_ALL         (HAL_MT_KG_PORT_UMAC_CHCONFIG4_LAST - 1)
    uint32 flag; /* Indicate which fields are valid */
} hal_mt_kg_port_umac_chconfig4_cfg_t;

typedef struct hal_mt_kg_port_umac_chconfig34_cfg_s {
    uint32 txtsoffsetext;    /* TX timestamp offset extension */
    uint32 txtscaloffsetinc; /* TX timestamp calibration offset increment */
    uint32 rxtsoffsetext;    /* RX timestamp offset extension */
    uint32 rxtscaloffsetinc; /* RX timestamp calibration offset increment */

/* CHCONFIG34 related definitions */
#define HAL_MT_KG_PORT_UMAC_CHCONFIG34_TXTSOFFSETEXT    (1UL << 0)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG34_TXTSCALOFFSETINC (1UL << 1)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG34_RXTSOFFSETEXT    (1UL << 2)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG34_RXTSCALOFFSETINC (1UL << 3)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG34_LAST             (1UL << 4)
#define HAL_MT_KG_PORT_UMAC_CHCONFIG34_ALL              (HAL_MT_KG_PORT_UMAC_CHCONFIG34_LAST - 1)
    uint32 flag; /* Indicate which fields are valid */
} hal_mt_kg_port_umac_chconfig34_cfg_t;

typedef struct hal_mt_kg_port_umac_intcontrol_cfg_s {
    uint32 intsts; /* Interrupt status */
    uint32 intclr; /* Interrupt clear */
    uint32 intena; /* Interrupt enable */
    uint32 intraw; /* Interrupt raw */

/* INTCONTROL related definitions */
#define HAL_MT_KG_PORT_UMAC_INTCONTROL_INTSTS (1UL << 0)
#define HAL_MT_KG_PORT_UMAC_INTCONTROL_INTCLR (1UL << 1)
#define HAL_MT_KG_PORT_UMAC_INTCONTROL_INTENA (1UL << 2)
#define HAL_MT_KG_PORT_UMAC_INTCONTROL_INTRAW (1UL << 3)
#define HAL_MT_KG_PORT_UMAC_INTCONTROL_LAST   (1UL << 4)
#define HAL_MT_KG_PORT_UMAC_INTCONTROL_ALL    (HAL_MT_KG_PORT_UMAC_INTCONTROL_LAST - 1)
    uint32 flag; /* Indicate which fields are valid */
} hal_mt_kg_port_umac_intcontrol_cfg_t;

typedef struct hal_mt_kg_port_umac_chsts_s {
    uint32 txclkpresentall;
    uint32 rxclkpresentall;
    uint32 rxsigokall;
    uint32 blocklockall;
    uint32 amlockall;
    uint32 aligned;
    uint32 nohiber;
    uint32 nolocalfault;
    uint32 noremotefault;
    uint32 linkup;
    uint32 hiser;
    uint32 fecdegser;
    uint32 rxamsf;

#define HAL_MT_KG_PORT_UMAC_CHSTS_TXCLKPRESENTALL (1UL << 0)
#define HAL_MT_KG_PORT_UMAC_CHSTS_RXCLKPRESENTALL (1UL << 1)
#define HAL_MT_KG_PORT_UMAC_CHSTS_RXSIGOKALL      (1UL << 2)
#define HAL_MT_KG_PORT_UMAC_CHSTS_BLOCKLOCKALL    (1UL << 3)
#define HAL_MT_KG_PORT_UMAC_CHSTS_AMLOCKALL       (1UL << 4)
#define HAL_MT_KG_PORT_UMAC_CHSTS_ALIGNED         (1UL << 5)
#define HAL_MT_KG_PORT_UMAC_CHSTS_NOHIBER         (1UL << 6)
#define HAL_MT_KG_PORT_UMAC_CHSTS_NOLOCALFAULT    (1UL << 7)
#define HAL_MT_KG_PORT_UMAC_CHSTS_NOREMOTEFAULT   (1UL << 8)
#define HAL_MT_KG_PORT_UMAC_CHSTS_LINKUP          (1UL << 9)
#define HAL_MT_KG_PORT_UMAC_CHSTS_HISER           (1UL << 10)
#define HAL_MT_KG_PORT_UMAC_CHSTS_FECDEGSER       (1UL << 11)
#define HAL_MT_KG_PORT_UMAC_CHSTS_RXAMSF          (1UL << 12)
#define HAL_MT_KG_PORT_UMAC_CHSTS_LAST            (1UL << 13)
#define HAL_MT_KG_PORT_UMAC_CHSTS_ALL             (HAL_MT_KG_PORT_UMAC_CHSTS_LAST - 1)
    uint32 flag;
} hal_mt_kg_port_umac_chsts_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief UMAC chip soft reset.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    inst_msk        - Device inst mask.
 * @param [in]    sub_inst_msk    - Sub-inst mask.
 * @param [in]    state           - Reset state.
 * @return        CLX_E_OK               - Operation successful.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter provided.
 * @return        CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_chip_soft_reset(uint32 unit, uint32 inst_msk, uint32 sub_inst_msk, uint32 state);

/**
 * @brief UMAC chip config.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    inst_msk        - Device inst mask.
 * @param [in]    sub_inst_msk    - Sub-inst mask.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_chip_set(uint32 unit, uint32 inst_msk, uint32 sub_inst_msk);

/**
 * @brief This API is used to set the UMAC tx reset state.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port ID.
 * @param [in]    state    - Reset state.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_admin_txrst_set(const uint32 unit, const uint32 port, const uint32 state);

/**
 * @brief This API is used to polling set the UMAC tx reset state.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port ID.
 * @param [in]    state    - Reset state.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_admin_txrst_polling_set(const uint32 unit,
                                            const uint32 port,
                                            const uint32 state);

/**
 * @brief This API is used to get the UMAC tx reset state.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port ID.
 * @param [in]    state    - Reset state.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_admin_txrst_get(const uint32 unit, const uint32 port, uint32 *state);
/**
 * @brief This API is used to set the UMAC rx reset state.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port ID.
 * @param [in]    state    - Reset state.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_admin_rxrst_set(const uint32 unit, const uint32 port, const uint32 state);

/**
 * @brief This API is used to set the UMAC tx enable state.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port ID.
 * @param [in]    state    - Enable state.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_admin_txen_set(const uint32 unit, const uint32 port, const uint32 state);

/**
 * @brief This API is used to set the UMAC rx enable state.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port ID.
 * @param [in]    state    - Enable state.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_admin_rxen_set(const uint32 unit, const uint32 port, const uint32 state);

/**
 * @brief UMAC chmode mode set.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Device port number.
 * @param [in]    an_flag     - AN flag.
 * @param [in]    speed       - Device speed.
 * @param [in]    fec         - Device fec.
 * @param [in]    lane_cnt    - Device lane count.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_speed_fec_set(uint32 unit,
                                  uint32 port,
                                  uint32 an_flag,
                                  uint32 speed,
                                  uint32 fec,
                                  uint32 lane_cnt);

/**
 * @brief UMAC low speed medium chmode mode set.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Device port number.
 * @param [in]    medium    - Medium.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_low_speed_medium_chmode_set(uint32 unit, uint32 port, uint32 medium);

/**
 * @brief UMAC low latency set.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Device port number.
 * @param [in]    fec     - Device fec.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_low_latency_set(uint32 unit, uint32 port, uint32 fec);

/**
 * @brief UMAC loopback set.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Device port number.
 * @param [in]    enable    - Device enable.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_lb_set(const uint32 unit, const uint32 port, uint32 enable);

/**
 * @brief UMAC loopback get.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     port                - Device port number.
 * @param [out]    ptr_mac_loopback    - Device enable.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_lb_get(const uint32 unit, const uint32 port, uint32 *ptr_mac_loopback);

/**
 * @brief UMAC udlink set.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Device port number.
 * @param [in]    enable    - Device enable.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_udlink_set(const uint32 unit, const uint32 port, uint32 enable);

/**
 * @brief UMAC udlink get.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Device port number.
 * @param [out]    ptr_udlink    - Device enable.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_udlink_get(const uint32 unit, const uint32 port, uint32 *ptr_udlink);

/**
 * @brief UMAC port init.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Device port number.
 * @param [in]    lane_cnt    - Device lane count.
 * @param [in]    fec         - Device fec.
 * @param [in]    speed       - Device speed.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_init(const uint32 unit,
                         const uint32 port,
                         const uint32 lane_cnt,
                         const uint32 fec,
                         const clx_port_speed_t speed);

/**
 * @brief Deinitialize MAC function of one port.
 *
 * @param [in]    unit    - Chip id.
 * @param [in]    port    - Port id.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_umac_deinit(const uint32 unit, const uint32 port);

/**
 * @brief UMAC link irq clear.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_link_irq_clear(const uint32 unit, const uint32 port);

/**
 * @brief UMAC link irq enable set.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Port number.
 * @param [in]    enable    - Enable state.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_link_irq_en_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief UMAC irq get.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Port number.
 * @param [out]    ptr_fault    - Fault status pointer.
 * @param [out]    ptr_lc       - Link change status pointer.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_irq_get(const uint32 unit, const uint32 port, uint32 *ptr_fault, uint32 *ptr_lc);

/**
 * @brief UMAC link fault get.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Port number.
 * @param [out]    ptr_link       - Link status pointer.
 * @param [out]    ptr_l_fault    - Left fault status pointer.
 * @param [out]    ptr_r_fault    - Right fault status pointer.
 * @param [out]    ptr_hiber      - Hiber status pointer.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_link_fault_get(const uint32 unit,
                                   const uint32 port,
                                   uint32 *ptr_link,
                                   uint32 *ptr_l_fault,
                                   uint32 *ptr_r_fault,
                                   uint32 *ptr_hiber);

/**
 * @brief This API is used to reset the UMAC TX when high BER is detected.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_high_ber_tx_reset(const uint32 unit, const uint32 port);

/**
 * @brief Set UMAC MACCFG configuration.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Port number.
 * @param [in]    maccfg_cfg    - MACCFG configuration.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_maccfg_set(const uint32 unit,
                               const uint32 port,
                               hal_mt_kg_port_umac_maccfg_cfg_t *maccfg_cfg);

/**
 * @brief UMAC fec get.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Device port number.
 * @param [in]    ptr_fec    - Pointer to store FEC value.
 * @return        CLX_E_OK               - Operation successful.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter provided.
 * @return        CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_fec_get(uint32 unit, uint32 port, uint32 *ptr_fec);

/**
 * @brief UMAC speed get.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    port         - Device port number.
 * @param [in]    ptr_speed    - Pointer to store speed value.
 * @return        CLX_E_OK    - Operation successful.
 */
clx_error_no_t
hal_mt_kg_port_umac_speed_get(uint32 unit, uint32 port, clx_port_speed_t *ptr_speed);

/**
 * @brief UMAC fec clear.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Device port number.
 * @return        CLX_E_OK    - Operation successful.
 */
clx_error_no_t
hal_mt_kg_port_umac_fec_clear(const uint32 unit, const uint32 port);

/**
 * @brief To set port pause.
 *
 * @param [in]    unit         - Chip id.
 * @param [in]    port         - Port id.
 * @param [in]    flow_ctrl    - Flow control type.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_umac_pause_set(const uint32 unit,
                              const uint32 port,
                              const clx_port_fc_dir_t flow_ctrl);

/**
 * @brief To get port pause.
 *
 * @param [in]     unit             - Chip id.
 * @param [in]     port             - Port id.
 * @param [out]    ptr_flow_ctrl    - Flow control type.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_umac_pause_get(const uint32 unit,
                              const uint32 port,
                              clx_port_fc_dir_t *ptr_flow_ctrl);

/**
 * @brief To set the PFC configuration for a specific port.
 *
 * @param [in]    unit    - Chip id.
 * @param [in]    port    - Port id.
 * @param [in]    pfc     - PFC control direction.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_umac_pfc_set(const uint32 unit, const uint32 port, const clx_port_fc_dir_t pfc);

/**
 * @brief UMAC pfc get.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Device port number.
 * @param [in]     pri        - Priority.
 * @param [out]    ptr_pfc    - PFC control direction.
 * @return         CLX_E_OK               - Operation successful.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return         CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_pfc_get(const uint32 unit,
                            const uint32 port,
                            const uint8 pri,
                            clx_port_fc_dir_t *ptr_pfc);

/**
 * @brief This API is used to set the MAC address for a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @param [in]    mac     - The MAC address.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_addr_set(const uint32 unit, const uint32 port, const clx_mac_t mac);

/**
 * @brief This API is used to get the MAC address for a specific port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port ID.
 * @param [out]    ptr_mac    - The MAC address.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_addr_get(const uint32 unit, const uint32 port, clx_mac_t *ptr_mac);

/**
 * @brief This API is used to set the fabric enable for a specific port.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    port         - Physical port ID.
 * @param [in]    fabric_en    - Fabric enable.
 * @return        CLX_E_OK        - The operation success.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_fabric_set(uint32 unit, uint32 port, uint32 fabric_en);

/**
 * @brief This API is used to set the IFG zero for a specific port.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port ID.
 * @param [in]    ifg0b    - IFG zero.
 * @return        CLX_E_OK        - The operation success.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_ifg_zero_set(const uint32 unit, const uint32 port, uint32 ifg0b);

/**
 * @brief This API is used to get the IFG zero for a specific port.
 *
 * @param [in]     unit     - Device unit number.
 * @param [in]     port     - Physical port ID.
 * @param [out]    ifg0b    - IFG zero.
 * @return         CLX_E_OK        - The operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_ifg_zero_get(const uint32 unit, const uint32 port, uint32 *ifg0b);

/**
 * @brief This API is used to set the FIFO threshold for a specific port.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port ID.
 * @param [in]    speed    - Speed.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_fifo_thrd_set(const uint32 unit, const uint32 port, const uint32 speed);

/**
 * @brief This API is used to get the register list for umac.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [in]     reg_info    - Register info.
 * @param [out]    reg_info    - Register info.
 * @return         CLX_E_OK        - The operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_dbg_reg_list_get(const uint32 unit, const uint32 port, uint32 *reg_info);

/**
 * @brief This API is used to set the IFG length for a specific port.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Physical port ID.
 * @param [in]    ifg_len    - IFG length.
 * @return        CLX_E_OK        - The operation success.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_ifg_len_set(const uint32 unit, const uint32 port, const uint32 ifg_len);

/**
 * @brief This API is used to get the IFG length for a specific port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port ID.
 * @param [out]    ifg_len    - IFG length.
 * @return         CLX_E_OK        - The operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_ifg_len_get(const uint32 unit, const uint32 port, uint32 *ifg_len);

/**
 * @brief Set the RX idle for a specific port.
 *
 * @param [in]    unit      - Chip id.
 * @param [in]    port      - Port id.
 * @param [in]    enable    - Enable or disable RX idle.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_umac_rxidle_set(const uint32 unit, const uint32 port, uint32 enable);

/**
 * @brief Get the RX idle for a specific port.
 *
 * @param [in]    unit       - Chip id.
 * @param [in]    port       - Port id.
 * @param [in]    rx_idle    - RX idle state.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_umac_rxidle_get(const uint32 unit, const uint32 port, uint32 *rx_idle);

/**
 * @brief Set the MIB max length for a specific port.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Physical port id.
 * @param [in]    max_len    - Max length of mib counter.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_mib_max_len_set(const uint32 unit, const uint32 port, const uint32 max_len);

/**
 * @brief Get the MIB max length for a specific port.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port id.
 * @param [out]    ptr_max_len    - MIB max length.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_mib_max_len_get(const uint32 unit, const uint32 port, uint32 *ptr_max_len);

/**
 * @brief Set the TX drain for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - Enable/Disable TX drain.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_tx_drain_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Set the Pause TX enable for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - Enable/Disable PAUSE TX.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_lfc_tx_en_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Set the PFC TX enable for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - Enable/Disable PFC TX.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_pfc_tx_en_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Set the CRC replace for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - Enable/Disable CRC replace.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_crc_replace_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Get the CRC replace for a specific port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [out]    ptr_enable    - CRC replace enable.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_crc_replace_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief Set rx ignore FCS for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - Enable/Disable rx ignore FCS.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_rx_ignfcs_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Get rx ignore FCS for a specific port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [out]    ptr_enable    - Rx ignore FCS enable.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_rx_ignfcs_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief Set the TX drain on fault for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - Enable/Disable TX drain on fault.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_tx_drain_on_fault_set(const uint32 unit,
                                          const uint32 port,
                                          const uint32 enable);

/**
 * @brief Get the MAC configuration for a specific port.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port id.
 * @param [out]    ptr_mac_cfg    - MAC configuration value.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_umac_cfg_get(const uint32 unit, const uint32 port, clx_port_mac_cfg_t *ptr_mac_cfg);

/**
 * @brief Get the MAC status for a specific port.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port id.
 * @param [out]    ptr_mac_sts    - MAC status value.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_umac_stat_get(const uint32 unit, const uint32 port, clx_port_mac_sts_t *ptr_mac_sts);

/**
 * @brief Set the TPID for the first VLAN tag.
 *
 * This function sets the TPID for the first VLAN tag on a port.
 *
 * @param [in]    unit    - Chip id.
 * @param [in]    port    - Port id.
 * @param [in]    tpid    - TPID value.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_umac_tpid0_set(const uint32 unit, const uint32 port, uint32 tpid);

/**
 * @brief Set the TPID for the second VLAN tag.
 *
 * This function sets the TPID for the second VLAN tag on a port.
 *
 * @param [in]    unit    - Chip id.
 * @param [in]    port    - Port id.
 * @param [in]    tpid    - TPID value.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_umac_tpid1_set(const uint32 unit, const uint32 port, uint32 tpid);

/**
 * @brief Set laneswap.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Port.
 * @param [in]    lane_cnt        - Lane count.
 * @param [in]    channel_gap     - Gap of channels.
 * @param [in]    ptr_laneswap    - Value of laneswap.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_laneswap_set(const uint32 unit,
                                 const uint32 port,
                                 const uint32 lane_cnt,
                                 const uint32 channel_gap,
                                 hal_mt_kg_port_laneswap_t *ptr_laneswap);

/**
 * @brief Get laneswap info.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Port.
 * @param [out]    ptr_laneswap    - Ptr value of laneswap.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_umac_laneswap_info_get(uint32 unit,
                                      uint32 port,
                                      hal_mt_kg_port_laneswap_t *ptr_laneswap);

/**
 * @brief Get the signal OK for a specific port.
 *
 * This function gets the signal OK for a specific port.
 *
 * @param [in]     unit         - Chip id.
 * @param [in]     port         - Physical port id.
 * @param [out]    signal_ok    - Signal OK value.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_umac_signal_get(const uint32 unit, const uint32 port, uint32 *signal_ok);

/**
 * @brief UMAC laneswap deinit.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_kg_port_umac_laneswap_deinit(const uint32 unit);
#endif /* __HAL_MT_KG_PORT_UMAC_H__ */