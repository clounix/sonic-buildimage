/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_tnl.h
 * PURPOSE:
 *      It provide tunnel hal layer api.
 * NOTES:
 *
 */

#ifndef HAL_MT_KG_TNL_H
#define HAL_MT_KG_TNL_H

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_KG_ES_GROUP_MAX     (0x7F) /* evpn_esi max value for sec_tep */
#define HAL_MT_KG_ES_GROUP_MIN     (0)    /* evpn_esi min value for sec_tep */
#define HAL_MT_KG_NFE_PROF_IDX_NUM (32)   /* netflow engine profile id*/

/* MACRO FUNCTION DECLARATIONS
 */
/*
 * Example is as below.
 *  clx_ipv6_t clx_ipv6 = {0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
 *                         0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f};
 *  uint32     hw_ipv6[5];
 *
 *  After HAL_MT_KG_TNL_SRC_TEP_IPV6_TO_HW_IPV6(clx_ipv6, hw_ipv6),
 *  hw_ipv6[0] = 0x26282a2c;
 *  hw_ipv6[1] = 0x00202224;
 *  hw_ipv6[2] = 0x1c1d1e1f;
 *  hw_ipv6[3] = 0x18191a1b;
 *  hw_ipv6[4] = 0x17;
 */
#define HAL_MT_KG_TNL_SRC_TEP_IPV6_TO_HW_IPV6(__hw_ipv6__, __clx_ipv6__)                   \
    do {                                                                                   \
        (__hw_ipv6__)[0] = (uint32)((__clx_ipv6__)[3]) << 26 | (__clx_ipv6__)[4] << 18 |   \
            (__clx_ipv6__)[5] << 10 | (__clx_ipv6__)[6] << 2 | (__clx_ipv6__)[7] >> 6;     \
        (__hw_ipv6__)[1] = (uint32)((__clx_ipv6__)[0]) << 18 | (__clx_ipv6__)[1] << 10 |   \
            (__clx_ipv6__)[2] << 2 | (__clx_ipv6__)[3] >> 6;                               \
        (__hw_ipv6__)[2] = (uint32)((__clx_ipv6__)[12]) << 24 | (__clx_ipv6__)[13] << 16 | \
            (__clx_ipv6__)[14] << 8 | (__clx_ipv6__)[15];                                  \
        (__hw_ipv6__)[3] = (__clx_ipv6__)[8] << 24 | (__clx_ipv6__)[9] << 16 |             \
            (__clx_ipv6__)[10] << 8 | (__clx_ipv6__)[11];                                  \
        (__hw_ipv6__)[4] = (uint32)(__clx_ipv6__)[7] & 0x3f;                               \
    } while (0)

#define HAL_MT_KG_TNL_DST_TEP_IPV6_TO_HW_IPV6(__hw_ipv6__, __clx_ipv6__)                   \
    do {                                                                                   \
        (__hw_ipv6__)[0] = (uint32)((__clx_ipv6__)[3]) << 29 | (__clx_ipv6__)[4] << 21 |   \
            (__clx_ipv6__)[5] << 13 | (__clx_ipv6__)[6] << 5 | (__clx_ipv6__)[7] >> 3;     \
        (__hw_ipv6__)[1] = (uint32)((__clx_ipv6__)[0]) << 21 | (__clx_ipv6__)[1] << 13 |   \
            (__clx_ipv6__)[2] << 5 | (__clx_ipv6__)[3] >> 3;                               \
        (__hw_ipv6__)[2] = (uint32)((__clx_ipv6__)[12]) << 24 | (__clx_ipv6__)[13] << 16 | \
            (__clx_ipv6__)[14] << 8 | (__clx_ipv6__)[15];                                  \
        (__hw_ipv6__)[3] = (__clx_ipv6__)[8] << 24 | (__clx_ipv6__)[9] << 16 |             \
            (__clx_ipv6__)[10] << 8 | (__clx_ipv6__)[11];                                  \
        (__hw_ipv6__)[4] = (uint32)(__clx_ipv6__)[7] & 0x7;                                \
    } while (0)

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_mt_kg_tnl_ip_tnl_type_enum_e {
    HAL_MT_KG_IP_TNL_GRE_WO_KEY = 0,
    HAL_MT_KG_IP_TNL_GRE_W_KEY = 1,
    HAL_MT_KG_IP_TNL_RAW = 2,
    HAL_MT_KG_IP_TNL_ISATAP = 3,
    HAL_MT_KG_IP_TNL_6TO4 = 4,
    HAL_MT_KG_IP_TNL_VXLAN_BAS = 5,
    HAL_MT_KG_IP_TNL_VXLAN_GPE_WO_VNI = 6,
    HAL_MT_KG_IP_TNL_VXLAN_GPE_W_VNI = 7,
    HAL_MT_KG_IP_TNL_GENEVE = 8,
    HAL_MT_KG_IP_TNL_INT_REPORT = 9,
    HAL_MT_KG_IP_TNL_SRV6_ENCAP = 10,
    HAL_MT_KG_IP_TNL_SRV6_INSERT = 11,
    HAL_MT_KG_IP_TNL_FLEX_0 = 12,
    HAL_MT_KG_IP_TNL_FLEX_1 = 13,
    HAL_MT_KG_IP_TNL_FLEX_2 = 14,
    HAL_MT_KG_IP_TNL_FLEX_3 = 15,
    HAL_MT_KG_IP_TNL_MPLS = 16,
    HAL_MT_KG_IP_TNL_SRV6_ENCAP_DT2M = 17,
    HAL_MT_KG_IP_TNL_LAST
} hal_mt_kg_tnl_ip_tnl_type_enum_t;

typedef enum hal_mt_kg_tnl_flex_inner_type_enum_e {
    HAL_MT_KG_TNL_FLEX_INNER_TYPE_NA = 0,
    HAL_MT_KG_TNL_FLEX_INNER_TYPE_ETH = 1,
    HAL_MT_KG_TNL_FLEX_INNER_TYPE_IPV4 = 2,
    HAL_MT_KG_TNL_FLEX_INNER_TYPE_IPV6 = 3,
    HAL_MT_KG_TNL_FLEX_INNER_TYPE_SRH = 4,
    HAL_MT_KG_TNL_FLEX_INNER_TYPE_MPLS = 5,
    HAL_MT_KG_TNL_FLEX_INNER_TYPE_NIB = 6,
    HAL_MT_KG_TNL_FLEX_INNER_TYPE_LAST

} hal_mt_kg_tnl_flex_inner_type_enum_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief Alloc src-ip index.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    is_ipv4       - Index is ipv4.
 * @param [in]    ptr_src_ip    - Src-ip address.
 * @param [in]    ptr_idx       - Src-ip index.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_ip_sa_idx_alloc(const uint32 unit,
                              const boolean is_ipv4,
                              const clx_ip_addr_t *ptr_src_ip,
                              uint32 *ptr_idx);

/**
 * @brief Free src-ip index.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    is_ipv4    - Index is ipv4.
 * @param [in]    idx        - Src-ip index.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_ip_sa_idx_free(const uint32 unit, const boolean is_ipv4, const uint32 idx);

/**
 * @brief Alloc dst-ip index.
 *
 * *ptr_idx means the index of the field in ip-tunnel
 * *ptr_idx means the index of the entry in srv6.
 *
 * @param [in]    unit                - Device unit number.
 * @param [in]    is_ipv4             - Index is ipv4.
 * @param [in]    ptr_dst_ip          - Pointer to destination ip address.
 * @param [in]    is_seglist          - Is srv6 segment list.
 * @param [in]    ptr_segment_list    - Pointer to segment list.
 * @param [in]    ptr_idx             - IpDa entry index.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_ip_da_idx_alloc(const uint32 unit,
                              const boolean is_ipv4,
                              const clx_ip_addr_t *ptr_dst_ip,
                              const boolean is_seglist,
                              const clx_srv6_sidlist_t *ptr_segment_list,
                              uint32 *ptr_idx);

/**
 * @brief Free src-ip index.
 *
 * Idx means the index of the field in ip-tunnel
 * idx means the index of the entry in srv6.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    is_ipv4          - Index is ipv4.
 * @param [in]    is_seglist       - Is srv6 segment list.
 * @param [in]    segments_left    - Pointer to segment list.
 * @param [in]    idx              - Dst-ip index.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_ip_da_idx_free(const uint32 unit,
                             const boolean is_ipv4,
                             const boolean is_seglist,
                             const uint32 segments_left,
                             const uint32 idx);

/**
 * @brief Alloc dst-ip index from RWO_SRAM_TNL_IPDA1.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     service_sid    - Service SID IPv6 address.
 * @param [out]    ptr_idx        - Ipda1 entry index.
 * @return         CLX_E_OK    - Operation success. CLX_E_TABLE_FULL - No available entry in the
 *                               table.
 */
clx_error_no_t
hal_mt_kg_tnl_ip_da1_idx_alloc(const uint32 unit, const clx_ipv6_t service_sid, uint32 *ptr_idx);

/**
 * @brief Free dst-ip index from RWO_SRAM_TNL_IPDA1.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    idx     - Ipda1 entry index.
 * @return        CLX_E_OK    - Operation success. CLX_E_TABLE_FULL - No available entry in the
 *                              table.
 */
clx_error_no_t
hal_mt_kg_tnl_ip_da1_idx_free(const uint32 unit, const uint32 idx);

clx_error_no_t
hal_mt_kg_tnl_nvo3_adj_hw_idx_get(const uint32 unit,
                                  const uint32 nvo3_adj_id,
                                  uint32 *ptr_tnl_bd_idx);

clx_error_no_t
hal_mt_kg_tnl_nvo3_adj_sw_idx_get(const uint32 unit,
                                  const uint32 di,
                                  const uint32 tnl_bd_idx,
                                  uint32 *ptr_nvo3_adj_id);

clx_error_no_t
hal_mt_kg_tnl_tnl_bd_cfg(const uint32 unit,
                         const hal_cmn_action_t hwdb_action,
                         const uint32 nvo3_encap_idx,
                         const uint32 tnl_port_idx,
                         uint32 *ptr_nvo3_adj_id);

clx_error_no_t
hal_mt_kg_tnl_nvo3_adj_ref_update(const uint32 unit, const uint32 nvo3_adj_id, const boolean inc);

/**
 * @brief Update egress port and nvo3 adjacency for a nvo3 route.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    nvo3_encap_idx    - Hash key.
 * @param [in]    tnl_port_idx      - Hash key.
 * @param [in]    path_idx          - Index to FWR_RSLT_TNL_ECMP_MBR.
 * @param [in]    port              - Egress port of nvo3_adj_info.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_nvo3_adj_path_update(const uint32 unit,
                                   const uint32 nvo3_encap_idx,
                                   const uint32 tnl_port_idx,
                                   const uint32 path_idx,
                                   const clx_port_t port);

/**
 * @brief Initiate the L3 tunnel hardware resource, such as hardware table and registers.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_cfg_init(const uint32 unit);

clx_error_no_t
hal_mt_kg_tnl_nvo3_adj_add(const uint32 unit, const uint32 flags, clx_l3_adj_t *ptr_nvo3_adj_info);

clx_error_no_t
hal_mt_kg_tnl_nvo3_adj_del(const uint32 unit, const uint32 flags, const uint32 nvo3_adj_id);

clx_error_no_t
hal_mt_kg_tnl_nvo3_adj_get(const uint32 unit, clx_l3_adj_t *ptr_nvo3_adj_info);

clx_error_no_t
hal_mt_kg_tnl_nvo3_adj_trav(const uint32 unit,
                            const clx_l3_adj_trav_func_t callback,
                            void *ptr_cookie);

clx_error_no_t
hal_mt_kg_tnl_mac_add(const uint32 unit,
                      const uint32 index,
                      const clx_tnl_mac_info_t *ptr_tunnel_mac_info);

clx_error_no_t
hal_mt_kg_tnl_mac_del(const uint32 unit, const uint32 index);

clx_error_no_t
hal_mt_kg_tnl_mac_get(const uint32 unit,
                      const uint32 index,
                      clx_tnl_mac_info_t *ptr_tunnel_mac_info);

clx_error_no_t
hal_mt_kg_tnl_mac_trav(const uint32 unit, const clx_tnl_mac_trav_t callback, void *ptr_cookie);

clx_error_no_t
hal_mt_kg_tnl_entry_decap_add(const uint32 unit,
                              const clx_tnl_info_t *ptr_tnl_info,
                              const clx_tnl_decap_info_t *ptr_decap_info);

clx_error_no_t
hal_mt_kg_tnl_entry_decap_del(const uint32 unit, const clx_tnl_info_t *ptr_tnl_info);

clx_error_no_t
hal_mt_kg_tnl_entry_decap_get(const uint32 unit,
                              const clx_tnl_info_t *ptr_tnl_info,
                              clx_tnl_decap_info_t *ptr_decap_info);

clx_error_no_t
hal_mt_kg_tnl_entry_decap_trav(const uint32 unit,
                               const clx_tnl_decap_trav_func_t cb,
                               void *ptr_cookie);

/**
 * @brief Real body of clx_tnl_decap_add() for INPUT/OUTPUT/RETURN description,
 *        please refer to clx_tnl_decap_add().
 *
 * This API would be called by MIR module when adding ERSPAN decap session.
 * The third parameter would be raised to TRUE when called by MIR module.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    ptr_tnl_info      - Tunnel header info.
 * @param [in]    ptr_decap_info    - Pointer to tunnel decap information.
 * @param [in]    erspan            - TRUE: erspan_term_session, FALSE: l3t.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_mt_kg_tnl_entry_decap_common_add(const uint32 unit,
                                     const clx_tnl_info_t *ptr_tnl_info,
                                     const clx_tnl_decap_info_t *ptr_decap_info,
                                     const boolean erspan);

clx_error_no_t
hal_mt_kg_tnl_entry_decap_common_del(const uint32 unit,
                                     const clx_tnl_info_t *ptr_tnl_info,
                                     const boolean erspan);

clx_error_no_t
hal_mt_kg_tnl_entry_decap_common_get(const uint32 unit,
                                     const clx_tnl_info_t *ptr_tnl_info,
                                     clx_tnl_decap_info_t *ptr_decap_info,
                                     const boolean erspan);

clx_error_no_t
hal_mt_kg_tnl_nvo3_route_add(const uint32 unit,
                             const clx_tnl_info_t *ptr_tnl_info,
                             const clx_tnl_nvo3_route_info_t *ptr_nvo3_route_info);

clx_error_no_t
hal_mt_kg_tnl_nvo3_route_del(const uint32 unit, const clx_tnl_info_t *ptr_tnl_info);

clx_error_no_t
hal_mt_kg_tnl_nvo3_route_get(const uint32 unit,
                             const clx_tnl_info_t *ptr_tnl_info,
                             clx_tnl_nvo3_route_info_t *ptr_nvo3_route_info);

clx_error_no_t
hal_mt_kg_tnl_nvo3_route_trav(const uint32 unit,
                              const clx_tnl_nvo3_route_trav_func_t cb,
                              void *ptr_cookie);

clx_error_no_t
hal_mt_kg_tnl_tnl_to_list_trav(const uint32 unit,
                               const hal_tnl_trav_type_t type,
                               util_lib_list_t *ptr_list);

clx_error_no_t
hal_mt_kg_tnl_ecmp_grp_id_to_tnl_idx_trav(const uint32 unit,
                                          const uint32 ecmp_grp_id,
                                          uint32 *tnl_idx_list,
                                          uint32 *tnl_idx_list_size);

clx_error_no_t
hal_mt_kg_tnl_entry_encap_add(const uint32 unit,
                              const clx_tnl_info_t *ptr_tnl_info,
                              const clx_tnl_encap_info_t *ptr_encap_info);

clx_error_no_t
hal_mt_kg_tnl_entry_encap_del(const uint32 unit, const clx_tnl_info_t *ptr_tnl_info);

clx_error_no_t
hal_mt_kg_tnl_entry_encap_get(const uint32 unit,
                              const clx_tnl_info_t *ptr_tnl_info,
                              clx_tnl_encap_info_t *ptr_encap_info);

clx_error_no_t
hal_mt_kg_tnl_entry_encap_trav(const uint32 unit,
                               const clx_tnl_encap_trav_func_t cb,
                               void *ptr_cookie);

/**
 * @brief To apply default properties for the new created port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Set port default fail.
 */
clx_error_no_t
hal_mt_kg_tnl_port_dflt_set(const uint32 unit, const uint32 port);

clx_error_no_t
hal_mt_kg_tnl_phy_port_set(const uint32 unit,
                           const clx_port_t port,
                           const clx_tnl_port_info_t *ptr_port_info);

clx_error_no_t
hal_mt_kg_tnl_phy_port_get(const uint32 unit,
                           const clx_port_t port,
                           clx_tnl_port_info_t *ptr_port_info);

/**
 * @brief Add or set a tunnel to a specified segment and related service.
 *
 * The ptr_seg_srv->vid_bdid value modification is not allowed.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_tnl_info    - Tunnel header info.
 * @param [in]    ptr_segment     - Pointer to segment information.
 * @param [in]    bdid            - Bdid.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_seg_srv_add(const uint32 unit,
                          const clx_tnl_info_t *ptr_tnl_info,
                          const clx_tnl_seg_key_t *ptr_segment,
                          const uint32 bdid);

/**
 * @brief Delete a tunnel from a specified segment.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_tnl_info    - Tunnel header info.
 * @param [in]    ptr_segment     - Pointer to segment information.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_seg_srv_del(const uint32 unit,
                          const clx_tnl_info_t *ptr_tnl_info,
                          const clx_tnl_seg_key_t *ptr_segment);

/**
 * @brief Get the service of a (segment, tunnel) pair.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     ptr_tnl_info    - Tunnel header info.
 * @param [in]     ptr_segment     - Pointer to segment information.
 * @param [out]    ptr_bdid        - Pointer to bdid.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_seg_srv_get(const uint32 unit,
                          const clx_tnl_info_t *ptr_tnl_info,
                          const clx_tnl_seg_key_t *ptr_segment,
                          uint32 *ptr_bdid);

/**
 * @brief Set vxlan udp_port.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    dport    - Vxlan udp_port.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_vxlan_udp_port_set(const uint32 unit, const uint32 dport);

/**
 * @brief Get vxlan udp dport.
 *
 * @param [in]     unit         - Device unit number.
 * @param [out]    ptr_dport    - Vxlan udp dport.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_vxlan_udp_port_get(const uint32 unit, uint32 *ptr_dport);

clx_error_no_t
hal_mt_kg_tnl_encap_ip_idx_cfg(const uint32 unit,
                               const clx_ip_addr_t *ptr_src_ip,
                               const clx_ip_addr_t *ptr_dst_ip,
                               uint32 *ptr_src_ip_idx,
                               uint32 *ptr_dst_ip_idx);

clx_error_no_t
hal_mt_kg_tnl_es_grp_create(const uint32 unit, const uint32 flags, uint32 *ptr_es_grp);

clx_error_no_t
hal_mt_kg_tnl_es_grp_destroy(const uint32 unit, const uint32 es_grp);

clx_error_no_t
hal_mt_kg_tnl_es_grp_mbr_add(const uint32 unit,
                             const uint32 es_grp,
                             const clx_port_t *ptr_port_mbr,
                             const uint32 port_num);

clx_error_no_t
hal_mt_kg_tnl_es_grp_mbr_del(const uint32 unit,
                             const uint32 es_grp,
                             const clx_port_t *ptr_port_mbr,
                             const uint32 port_num);

clx_error_no_t
hal_mt_kg_tnl_es_grp_mbr_get(const uint32 unit,
                             const uint32 es_grp,
                             clx_port_t *ptr_port_mbr,
                             uint32 *ptr_port_num);

/**
 * @brief Set hw parsering tunnel enable.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    type            - Tunnel parser type.
 * @param [in]    slice_bmp_en    - Parser en per slice.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_psr_en_set(const uint32 unit,
                         const clx_tnl_psr_type_t type,
                         const uint32 slice_bmp_en);

/**
 * @brief Get hw parsering tunnel enable status.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     type            - Tunnel parser type.
 * @param [out]    slice_bmp_en    - Parser en per slice.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_psr_en_get(const uint32 unit, const clx_tnl_psr_type_t type, uint32 *slice_bmp_en);

clx_error_no_t
hal_mt_kg_tnl_ipv6_ext_set(const uint32 unit,
                           const clx_tnl_ipv6_ext_type_t type,
                           const uint32 optValue);

clx_error_no_t
hal_mt_kg_tnl_ipv6_ext_get(const uint32 unit,
                           const clx_tnl_ipv6_ext_type_t type,
                           uint32 *ptr_optValue);

clx_error_no_t
hal_mt_kg_tnl_flex_tnl_add(const uint32 unit,
                           const uint32 index,
                           const clx_tnl_flex_tnl_info_t *ptr_flex_tnl_info);

clx_error_no_t
hal_mt_kg_tnl_flex_tnl_del(const uint32 unit, const uint32 index);

clx_error_no_t
hal_mt_kg_tnl_flex_tnl_get(const uint32 unit,
                           const uint32 index,
                           clx_tnl_flex_tnl_info_t *ptr_flex_tnl_info);

clx_error_no_t
hal_mt_kg_tnl_flex_tnl_udf_cfg(const uint32 unit, const uint32 index, const uint32 flags);

clx_error_no_t
hal_mt_kg_tnl_flex_tnl_sdh_cfg(const uint32 unit, const uint32 index);

clx_error_no_t
hal_mt_kg_tnl_wlan_usage_trav(const uint32 unit, const hal_tnl_trav_type_t type, uint32 *ptr_usage);

clx_error_no_t
hal_mt_kg_tnl_rwi_rslt_lcl_cfg(const uint32 unit,
                               const clx_tnl_info_t tnl_hdr,
                               const clx_tnl_encap_info_t *ptr_encap_info,
                               const boolean add,
                               const uint32 lcl_intf_idx);

clx_error_no_t
hal_mt_kg_tnl_rwi_rslt_lcl_del(const uint32 unit, const uint32 lcl_intf_idx);

clx_error_no_t
hal_mt_kg_tnl_dis_rslt_lcl_add(const uint32 unit,
                               const clx_tnl_info_t tnl_hdr,
                               const clx_tnl_decap_info_t *ptr_decap_info,
                               const boolean add,
                               const uint32 dis_rslt_lcl_idxs);

clx_error_no_t
hal_mt_kg_tnl_dis_rslt_lcl_del(const uint32 unit, const uint32 lcl_intf_idx);

clx_error_no_t
hal_mt_kg_tnl_dis_rslt_lcl_get(const uint32 unit,
                               const uint32 tnl_dis_rslt_lcl_idx,
                               const clx_tnl_info_t tnl_hdr,
                               clx_tnl_decap_info_t *ptr_decap_info);

clx_error_no_t
hal_mt_kg_tnl_wlan_encap_obj_retrieve(const uint32 unit,
                                      const uint32 nvo3_encap_idx,
                                      clx_tnl_encap_info_t *ptr_encap_info);

clx_error_no_t
hal_mt_kg_tnl_wlan_decap_obj_retrieve(const uint32 unit,
                                      const uint32 lcl_intf_idx,
                                      clx_tnl_decap_info_t *ptr_decap_info);

/**
 * @brief Set tnl exception's action.
 *
 * CLX84 support TTL0/1 action.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    property    - Exception enum.
 * @param [in]    action      - Drop/to_cpu/forward.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_excpt_act_set(const uint32 unit,
                            const clx_swc_cfg_t property,
                            clx_fwd_action_t action);

/**
 * @brief Get tnl exception's action.
 *
 * CLX84 support TTL0/1 action.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    property      - Exception enum.
 * @param [in]    ptr_action    - Drop/to_cpu/forward.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_excpt_act_get(const uint32 unit,
                            const clx_swc_cfg_t property,
                            clx_fwd_action_t *ptr_action);

/**
 * @brief Enable/Disable the VXLAN Router Alert feature.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    enable    - 0 or 1.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_vxlan_ra_chk_set(const uint32 unit, const uint32 enable);

/**
 * @brief Get the VXLAN Router Alert Enable/Disable status.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_enable    - 0 or 1.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_vxlan_ra_chk_get(const uint32 unit, uint32 *ptr_enable);

/**
 * @brief Enable/Disable the NVGRE Router Alert feature.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    enable    - 0 or 1.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_nvgre_ra_chk_set(const uint32 unit, const uint32 enable);

/**
 * @brief Get the NVGRE Router Alert Enable/Disable status.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_enable    - 0 or 1.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_tnl_nvgre_ra_chk_get(const uint32 unit, uint32 *ptr_enable);

#endif /* End of HAL_MT_KG_TNL_H */
