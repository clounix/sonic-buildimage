/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   hal_mt_kg_port_epl.h
 * PURPOSE:
 *      It provides EPL module API.
 * NOTES:
 */

#ifndef __HAL_MT_KG_PORT_EPL_H__
#define __HAL_MT_KG_PORT_EPL_H__

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <hal/mt/kg/hal_mt_kg_port.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_KG_EPL_EPG_DURATION          (100)
#define HAL_MT_KG_EPL_EPG_LEN_MAX           (9600)
#define HAL_MT_KG_EPL_EPG_LEN_MIN           (64)
#define HAL_MT_KG_EPL_EPG_DATA_MAX          (9640)
#define HAL_MT_KG_EPL_EPG_MAC_ADDR_LEN      (6)
#define HAL_MT_KG_EPL_PIPE_DATA_BUF_REG_NUM (4)
#define HAL_MT_KG_EPL_LINE_DATA_SIZE        (232)
#define HAL_MT_KG_EPL_LAST_BANK_DATA_SIZE   (8)
#define HAL_MT_KG_EPL_LINE_MAX_NUM          (128)
#define HAL_MT_KG_EPL_BANK_DATA_SIZE        (16)
#define HAL_MT_KG_EPL_DATA_ADDR_OFST        (5)
#define HAL_MT_KG_EPL_BYTE_NUM_PRE_REG      (4)
#define HAL_MT_KG_EPL_BYTE_BIT_OFST         (8)
#define HAL_MT_KG_EPL_LINE_BANK_NUM         (15)
#define HAL_MT_KG_EPL_LINE_DATABANK_NUM     (14)
#define HAL_MT_KG_EPL_DPORT_OFST            (7)
#define HAL_MT_KG_EPL_EOP_OFST              (13)
#define HAL_MT_KG_EPL_PAYLOAD_OFST          (13)
#define HAL_MT_KG_EPL_FRAG_SIZE_OFST        (14)
#define HAL_MT_KG_EPL_CORE_CLOCK_MHZ        (1000)
#define HAL_MT_KG_EPL_ETH_TYPE              (0x8809)
#define HAL_MT_KG_EPL_EPG_DEFAULT_LOOP_NUM  (0xFF)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MT_KG_EPL_TDM_SLOT_NUM 32

/* DATA TYPE DECLARATIONS
 */

typedef struct hal_mt_kg_port_epl_cmn_global_cfg_s {
    uint32 port86_en;
    uint32 port87_en;
    uint32 pkt_drop_en;
    uint32 test_mode_en;
#define HAL_MT_KG_EPL_CMN_GLOBAL_PORT86_EN    (1 << 0)
#define HAL_MT_KG_EPL_CMN_GLOBAL_PORT87_EN    (1 << 1)
#define HAL_MT_KG_EPL_CMN_GLOBAL_PKT_DROP_EN  (1 << 2)
#define HAL_MT_KG_EPL_CMN_GLOBAL_TEST_MODE_EN (1 << 3)
#define HAL_MT_KG_EPL_CMN_GLOBAL_LAST         (1 << 4)
    uint32 flag;
} hal_mt_kg_port_epl_cmn_global_cfg_t;

typedef struct hal_mt_kg_port_epl_port_char_cfg_s {
    uint32 port_en;
    uint32 port_mode; // '3' for cpx(ecpu or ecpu);'2' for cpi;'1' for fabric port;'0' for ether
                      // port
    uint32 port_idx; // when mode=3,'1' for ecpu;'0' for cpu. when mode=2,'1' for cpi1;'0' for cpi0.
                     // others no cared
    uint32 pph_keep; // '1' for keep pph; '0' for no keep pph
    uint32 port_speed; // port speed.4'd9 400g;8 200g;7 100g;6 50g;5 40g;4 25g;3 10g;2 5g;1 2p5g;0
                       // 1g.

#define HAL_MT_KG_EPL_ETH_PORT_CHAR_PORT_EN    (1 << 0)
#define HAL_MT_KG_EPL_ETH_PORT_CHAR_PORT_MODE  (1 << 1)
#define HAL_MT_KG_EPL_ETH_PORT_CHAR_PORT_IDX   (1 << 2)
#define HAL_MT_KG_EPL_ETH_PORT_CHAR_PPH_KEEP   (1 << 3)
#define HAL_MT_KG_EPL_ETH_PORT_CHAR_PORT_SPEED (1 << 4)
#define HAL_MT_KG_EPL_ETH_PORT_CHAR_LAST       (1 << 5)
    uint32 flag;
} hal_mt_kg_port_epl_port_char_cfg_t;

typedef struct hal_mt_kg_port_epl_port_pipe_char_cfg_s {
    uint32 fc_mode;      // 2'b01 pause mode; 2'b10 pfc mode;others not cared about xoff
    uint32 pipe_speed;   // port speed.4'd9 400g;8 200g;7 100g;6 50g;5 40g;4 25g;3 10g;2 5g;1 2p5g;0
                         // 1g.
    uint32 que_flush_en; // queue flush enable for lossy queue(bit[7]) and lossless queue(bit[6])
    uint32 ch_flush_en;  // it will flush lossy and lossless queue of this channel at same time
    uint32 pfc_dead_lock_en;   // pfc dead-lock detect enable for lossless queue of this channel
    uint32 pause_dead_lock_en; // pause dead-lock detect enable for this channel
    uint32 leak_en;            // data leak enable for this channel
    uint32 leak_th;            // data leak threshold for this channel 128B unit.

#define HAL_MT_KG_EPL_PORT_PIPE_CHAR_FC_MODE            (1 << 0)
#define HAL_MT_KG_EPL_PORT_PIPE_CHAR_PIPE_SPEED         (1 << 1)
#define HAL_MT_KG_EPL_PORT_PIPE_CHAR_QUE_FLUSH_EN       (1 << 2)
#define HAL_MT_KG_EPL_PORT_PIPE_CHAR_CH_FLUSH_EN        (1 << 3)
#define HAL_MT_KG_EPL_PORT_PIPE_CHAR_PFC_DEAD_LOCK_EN   (1 << 4)
#define HAL_MT_KG_EPL_PORT_PIPE_CHAR_PAUSE_DEAD_LOCK_EN (1 << 5)
#define HAL_MT_KG_EPL_PORT_PIPE_CHAR_LEAK_EN            (1 << 6)
#define HAL_MT_KG_EPL_PORT_PIPE_CHAR_LEAK_TH            (1 << 7)
#define HAL_MT_KG_EPL_PORT_PIPE_CHAR_LAST               (1 << 8)
    uint32 flag;
} hal_mt_kg_port_epl_port_pipe_char_cfg_t;

typedef struct hal_mt_kg_port_epl_pfc_mask_ch_cfg_s {
    uint32 tc[8]; // TC[0-7] PFC mask enable

#define HAL_MT_KG_EPL_PFC_MASK_CH_TC0  (1 << 0)
#define HAL_MT_KG_EPL_PFC_MASK_CH_TC1  (1 << 1)
#define HAL_MT_KG_EPL_PFC_MASK_CH_TC2  (1 << 2)
#define HAL_MT_KG_EPL_PFC_MASK_CH_TC3  (1 << 3)
#define HAL_MT_KG_EPL_PFC_MASK_CH_TC4  (1 << 4)
#define HAL_MT_KG_EPL_PFC_MASK_CH_TC5  (1 << 5)
#define HAL_MT_KG_EPL_PFC_MASK_CH_TC6  (1 << 6)
#define HAL_MT_KG_EPL_PFC_MASK_CH_TC7  (1 << 7)
#define HAL_MT_KG_EPL_PFC_MASK_CH_LAST (1 << 8)
#define HAL_MT_KG_EPL_PFC_MASK_CH_ALL  (0xFF)
    uint32 flag;
} hal_mt_kg_port_epl_pfc_mask_ch_cfg_t;

typedef struct hal_mt_kg_port_epl_flow_ctrl_ignore_cfg_s {
    uint32 ch[16]; // TC[0-7] PFC mask enable

#define HAL_MT_KG_EPL_FLOW_CTRL_IGNORE_CH0  (1 << 0)
#define HAL_MT_KG_EPL_FLOW_CTRL_IGNORE_CH1  (1 << 1)
#define HAL_MT_KG_EPL_FLOW_CTRL_IGNORE_CH2  (1 << 2)
#define HAL_MT_KG_EPL_FLOW_CTRL_IGNORE_CH3  (1 << 3)
#define HAL_MT_KG_EPL_FLOW_CTRL_IGNORE_CH4  (1 << 4)
#define HAL_MT_KG_EPL_FLOW_CTRL_IGNORE_CH5  (1 << 5)
#define HAL_MT_KG_EPL_FLOW_CTRL_IGNORE_CH6  (1 << 6)
#define HAL_MT_KG_EPL_FLOW_CTRL_IGNORE_CH7  (1 << 7)
#define HAL_MT_KG_EPL_FLOW_CTRL_IGNORE_CH8  (1 << 8)
#define HAL_MT_KG_EPL_FLOW_CTRL_IGNORE_CH9  (1 << 9)
#define HAL_MT_KG_EPL_FLOW_CTRL_IGNORE_CH10 (1 << 10)
#define HAL_MT_KG_EPL_FLOW_CTRL_IGNORE_CH11 (1 << 11)
#define HAL_MT_KG_EPL_FLOW_CTRL_IGNORE_CH12 (1 << 12)
#define HAL_MT_KG_EPL_FLOW_CTRL_IGNORE_CH13 (1 << 13)
#define HAL_MT_KG_EPL_FLOW_CTRL_IGNORE_CH14 (1 << 14)
#define HAL_MT_KG_EPL_FLOW_CTRL_IGNORE_CH15 (1 << 15)
#define HAL_MT_KG_EPL_FLOW_CTRL_IGNORE_LAST (1 << 16)
#define HAL_MT_KG_EPL_FLOW_CTRL_IGNORE_ALL  (0xFFFF)
    uint32 flag;
} hal_mt_kg_port_epl_flow_ctrl_ignore_cfg_t;

typedef struct hal_mt_kg_port_epl_pipe_ch_tc2q_map_s {
    uint32 ch_tc2q_map[8];

#define HAL_MT_KG_EPL_PIPE_CH_TC0_QUE_MAP   (1 << 0)
#define HAL_MT_KG_EPL_PIPE_CH_TC1_QUE_MAP   (1 << 1)
#define HAL_MT_KG_EPL_PIPE_CH_TC2_QUE_MAP   (1 << 2)
#define HAL_MT_KG_EPL_PIPE_CH_TC3_QUE_MAP   (1 << 3)
#define HAL_MT_KG_EPL_PIPE_CH_TC4_QUE_MAP   (1 << 4)
#define HAL_MT_KG_EPL_PIPE_CH_TC5_QUE_MAP   (1 << 5)
#define HAL_MT_KG_EPL_PIPE_CH_TC6_QUE_MAP   (1 << 6)
#define HAL_MT_KG_EPL_PIPE_CH_TC7_QUE_MAP   (1 << 7)
#define HAL_MT_KG_EPL_PIPE_CH_TC2Q_MAP_LAST (1 << 8)
    uint32 flag;
} hal_mt_kg_port_epl_pipe_ch_tc2q_map_t;

typedef struct hal_mt_kg_port_epl_lsy_que_spd_read_th_cfg_s {
    uint32 spd_400g_th;
    uint32 spd_200g_th;
    uint32 spd_100g_th;
    uint32 spd_50g_th;
    uint32 spd_40g_th;
    uint32 spd_25g_th;
    uint32 spd_10g_th;
    uint32 spd_5g_th;
    uint32 spd_2p5g_th;
    uint32 spd_1g_th;

#define HAL_MT_KG_EPL_LSY_QUE_SPD_READ_TH_SPD_400G_TH (1 << 0)
#define HAL_MT_KG_EPL_LSY_QUE_SPD_READ_TH_SPD_200G_TH (1 << 1)
#define HAL_MT_KG_EPL_LSY_QUE_SPD_READ_TH_SPD_100G_TH (1 << 2)
#define HAL_MT_KG_EPL_LSY_QUE_SPD_READ_TH_SPD_50G_TH  (1 << 3)
#define HAL_MT_KG_EPL_LSY_QUE_SPD_READ_TH_SPD_40G_TH  (1 << 4)
#define HAL_MT_KG_EPL_LSY_QUE_SPD_READ_TH_SPD_25G_TH  (1 << 5)
#define HAL_MT_KG_EPL_LSY_QUE_SPD_READ_TH_SPD_10G_TH  (1 << 6)
#define HAL_MT_KG_EPL_LSY_QUE_SPD_READ_TH_SPD_5G_TH   (1 << 7)
#define HAL_MT_KG_EPL_LSY_QUE_SPD_READ_TH_SPD_2P5G_TH (1 << 8)
#define HAL_MT_KG_EPL_LSY_QUE_SPD_READ_TH_SPD_1G_TH   (1 << 9)
#define HAL_MT_KG_EPL_LSY_QUE_SPD_READ_TH_LAST        (1 << 10)
    uint32 flag;
} hal_mt_kg_port_epl_lsy_que_spd_read_th_cfg_t;

typedef struct hal_mt_kg_port_epl_lls_que_spd_read_th_cfg_s {
    uint32 spd_400g_th;
    uint32 spd_200g_th;
    uint32 spd_100g_th;
    uint32 spd_50g_th;
    uint32 spd_40g_th;
    uint32 spd_25g_th;
    uint32 spd_10g_th;
    uint32 spd_5g_th;
    uint32 spd_2p5g_th;
    uint32 spd_1g_th;

#define HAL_MT_KG_EPL_LLS_QUE_SPD_READ_TH_SPD_400G_TH (1 << 0)
#define HAL_MT_KG_EPL_LLS_QUE_SPD_READ_TH_SPD_200G_TH (1 << 1)
#define HAL_MT_KG_EPL_LLS_QUE_SPD_READ_TH_SPD_100G_TH (1 << 2)
#define HAL_MT_KG_EPL_LLS_QUE_SPD_READ_TH_SPD_50G_TH  (1 << 3)
#define HAL_MT_KG_EPL_LLS_QUE_SPD_READ_TH_SPD_40G_TH  (1 << 4)
#define HAL_MT_KG_EPL_LLS_QUE_SPD_READ_TH_SPD_25G_TH  (1 << 5)
#define HAL_MT_KG_EPL_LLS_QUE_SPD_READ_TH_SPD_10G_TH  (1 << 6)
#define HAL_MT_KG_EPL_LLS_QUE_SPD_READ_TH_SPD_5G_TH   (1 << 7)
#define HAL_MT_KG_EPL_LLS_QUE_SPD_READ_TH_SPD_2P5G_TH (1 << 8)
#define HAL_MT_KG_EPL_LLS_QUE_SPD_READ_TH_SPD_1G_TH   (1 << 9)
#define HAL_MT_KG_EPL_LLS_QUE_SPD_READ_TH_LAST        (1 << 10)
    uint32 flag;
} hal_mt_kg_port_epl_lls_que_spd_read_th_cfg_t;

typedef struct hal_mt_kg_port_epl_fd_buf_s {
    uint32 plq0_start_addr;
    uint32 plq0_size;
    uint32 plq1_start_addr;
    uint32 plq1_size;
} hal_mt_kg_port_epl_fd_buf_t;

typedef struct hal_mt_kg_port_epl_tdm_slot2ch_map_cfg_s {
    uint32 tdm_slot[HAL_MT_KG_EPL_TDM_SLOT_NUM];

#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT0  (1 << 0)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT1  (1 << 1)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT2  (1 << 2)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT3  (1 << 3)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT4  (1 << 4)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT5  (1 << 5)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT6  (1 << 6)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT7  (1 << 7)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT8  (1 << 8)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT9  (1 << 9)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT10 (1 << 10)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT11 (1 << 11)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT12 (1 << 12)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT13 (1 << 13)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT14 (1 << 14)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT15 (1 << 15)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT16 (1 << 16)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT17 (1 << 17)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT18 (1 << 18)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT19 (1 << 19)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT20 (1 << 20)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT21 (1 << 21)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT22 (1 << 22)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT23 (1 << 23)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT24 (1 << 24)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT25 (1 << 25)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT26 (1 << 26)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT27 (1 << 27)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT28 (1 << 28)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT29 (1 << 29)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT30 (1 << 30)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_SLOT31 (1 << 31)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_LAST   (1 << 32)
#define HAL_MT_KG_EPL_TDM_SLOT2CH_MAP_ALL    (0xFFFFFFFF)
    uint32 flag;
} hal_mt_kg_port_epl_tdm_slot2ch_map_cfg_t;

typedef struct hal_mt_kg_port_epl_pkt_gen_info_cfg_s {
    uint32 data_addr;   // data address[6:0]
    uint32 dport;       // destination port [13:7]
    uint32 eop;         // end of packet [14]
    uint32 frag_size;   // fragment size [23:15]
    uint32 pd_fifo_num; // pd fifo number [24]

#define HAL_MT_KG_EPL_PKT_GEN_INFO_DATA_ADDR   (1 << 0)
#define HAL_MT_KG_EPL_PKT_GEN_INFO_DPORT       (1 << 1)
#define HAL_MT_KG_EPL_PKT_GEN_INFO_EOP         (1 << 2)
#define HAL_MT_KG_EPL_PKT_GEN_INFO_FRAG_SIZE   (1 << 3)
#define HAL_MT_KG_EPL_PKT_GEN_INFO_PD_FIFO_NUM (1 << 4)
#define HAL_MT_KG_EPL_PKT_GEN_INFO_LAST        (1 << 5)
    uint32 flag;
} hal_mt_kg_port_epl_pkt_gen_info_cfg_t;

typedef struct hal_mt_kg_port_epl_pkt_head_vlan_s {
    uint16 vlan_tpid; // 2bytes,   0x8100, IEEE 802.1Q tag
    uint16 vlan_id;   // 12bits,   vlan id, 0-4095
    uint8 vlan_pri;   // 3bits,    priority, 0-7
    uint8 vlan_cfi;   // 1bit,     0-std format mac addr, 1-non std
} hal_mt_kg_port_epl_pkt_head_vlan_t;

typedef struct hal_mt_kg_port_epl_pkt_head_s {
    clx_mac_t dst_mac;                           // 6bytes,   destination mac address
    clx_mac_t src_mac;                           // 6bytes,   source mac address
    hal_mt_kg_port_epl_pkt_head_vlan_t vlan_cfg; // vlan pkt field cfg
    uint16 eth_ii_type;                          // 2bytes,   ethernet II type or 802.3 payload size
    uint8 vlan_vld; // 1bit,     0-ethernet II pkt, 1-vlan pkt and need vlan_cfg
} hal_mt_kg_port_epl_pkt_head_t;

typedef struct hal_mt_kg_port_epl_pkt_gen_cfg_s {
    uint32 pkt_size;        // total bytes size of the pkt 64-9640
    hal_mt_kg_port_epl_pkt_head_t pkt_head_cfg;
    uint8 dport;            // pkt destination port, 0-31
    uint8 pph_kept_ind;     // 1bit, 0-pph_kept_ind, 1-pph_not_kept_ind
    uint8 cpx_port_idx;     // 1bit, 0-cpi0/cpu, 1-cpi1/ecpu
    uint8 port_type;        // 2bits, 0-fabric port, 1-cpu port, 2-cpi port, 3-ecpu port
    uint8 pd_fifo_num;      // 2bits, 0-pd_fifo_num, 1-pd_fifo_num, 2-pd_fifo_num, 3-pd_fifo_num
    uint8 repeat_num;       // 8bits, the pkt sent times during repeat duration in a loop
    uint8 loop_num;         // 8bits, times of repeat_num sent pkts, 0-continuously
    uint8 payload_ofst;     // 5bits, addr of payload start5'd13 is no vlan frame; 5'd17 vlan frame
    uint8 payload_random;   // 1bits, if use the random payload
    uint8 head_ofst;        // 4bits, addr of payload start5'd13 is no vlan frame; 5'd17 vlan frame
    uint8 head_random;      // 2bits, 2'b00/11-no change head, 2'b01-random, 2'b10-increase
    uint8 plen_random_en;   // 1bit
    uint8 data_duplication; // 1bit , data to multi umac dport
    uint16 repeat_duration; // 16bits, default 0x100
    uint32 payload_size;    // 32bits, payload size,
    uint8 pkt_payload[HAL_MT_KG_EPL_EPG_LEN_MAX]; // pkt payload
} hal_mt_kg_port_epl_pkt_gen_cfg_t;

typedef struct hal_mt_kg_port_epl_dp_que_spd_read_th_s {
    uint32 lsy_spd_800g_th;
    uint32 lsy_spd_400g_th;
    uint32 lsy_spd_200g_th;
    uint32 lsy_spd_100g_th;
    uint32 lsy_spd_50g_th;
    uint32 lsy_spd_40g_th;
    uint32 lsy_spd_25g_th;
    uint32 lsy_spd_10g_th;
    uint32 lls_spd_800g_th;
    uint32 lls_spd_400g_th;
    uint32 lls_spd_200g_th;
    uint32 lls_spd_100g_th;
    uint32 lls_spd_50g_th;
    uint32 lls_spd_40g_th;
    uint32 lls_spd_25g_th;
    uint32 lls_spd_10g_th;
} hal_mt_kg_port_epl_dp_que_spd_read_th_t;

typedef struct hal_mt_kg_port_epl_dbg_cnt_s {
    uint32 pipe_eth_port_out_pkt_total_cnt;
    uint32 pipe_out_pkt_byte_cnt;
    uint32 pipe_sel_port_out_pkt_cnt; // cfg_pipe_channel
    uint32 pipe_sel_port_out_pkt_byte_cnt;
    uint32 pipe_fab_port_out_pkt_total_cnt;
    uint32 pipe_cpi_port_out_pkt_total_cnt;
    uint32 pipe_cpx_port_out_pkt_total_cnt;
    uint32 pipe_runt_pkt_drop_cnt;
    // uint32 pipe_sel_port_runt_pkt_cnt;
    // uint32 pipe_epl_ubuf_buf_num_used_max_cnt;
    uint32 pipe_data_buf_ovfl_drop_cnt_ubuf;
    uint32 pipe_fd_buf_ovfl_drop_cnt_ubuf;

    uint32 dp_recvd_pkt_cnt;
    uint32 dp_pipe_pkt_in_total_cnt;
    uint32 dp_pkt_drop_total_cnt;
    uint32 cmn_sel_port_in_pkt_num; // cfg_debug_port
    uint32 dp_ilegal_dport_drop_cnt;
    uint32 dp_ilegal_destination_drop_cnt;
    uint32 dp_pkt_size_less64_drop_cnt;
    uint32 dp_port_disable_pkt_drop_cnt;
    uint32 dp_pkt_sop_err_drop_cnt;
    uint32 dp_lbm_fwd_valid_drop_cnt;   // dp0_port86_fwd_valid_drop_cnt
    uint32 dp_lbm_rec_invalid_drop_cnt; // dp0_port86_rec_invalid_drop_cnt
    uint32 dp_lbm_packet_in_cnt;
    uint32 dp_lbm_packet_out_cnt;
    uint32 dp_lbm_packet_drop_cnt;
    uint32 dp_buf_trun_pkt_cnt;
    uint32 dp_pkt_bg_mtu_trun_pkt_cnt;
    uint32 dp_runt_pkt_cnt;

#define HAL_MT_KG_EPL_DBG_PIPE_ETH_PORT_OUT_PKT_TOTAL_CNT  (1 << 0)
#define HAL_MT_KG_EPL_DBG_PIPE_OUT_PKT_BYTE_CNT            (1 << 1)
#define HAL_MT_KG_EPL_DBG_PIPE_SEL_PORT_OUT_PKT_CNT        (1 << 2)
#define HAL_MT_KG_EPL_DBG_PIPE_SEL_PORT_OUT_PKT_BYTE_CNT   (1 << 3)
#define HAL_MT_KG_EPL_DBG_PIPE_FAB_PORT_OUT_PKT_TOTAL_CNT  (1 << 4)
#define HAL_MT_KG_EPL_DBG_PIPE_CPI_PORT_OUT_PKT_TOTAL_CNT  (1 << 5)
#define HAL_MT_KG_EPL_DBG_PIPE_CPX_PORT_OUT_PKT_TOTAL_CNT  (1 << 6)
#define HAL_MT_KG_EPL_DBG_PIPE_RUNT_PKT_DROP_CNT           (1 << 7)
#define HAL_MT_KG_EPL_DBG_PIPE_DATA_BUF_OVFL_DROP_CNT_UBUF (1 << 8)
#define HAL_MT_KG_EPL_DBG_PIPE_FD_BUF_OVFL_DROP_CNT_UBUF   (1 << 9)
#define HAL_MT_KG_EPL_DBG_DP_RECVD_PKT_CNT                 (1 << 10)
#define HAL_MT_KG_EPL_DBG_DP_PIPE_PKT_IN_TOTAL_CNT         (1 << 11)
#define HAL_MT_KG_EPL_DBG_DP_PKT_DROP_TOTAL_CNT            (1 << 12)
#define HAL_MT_KG_EPL_DBG_CMN_SEL_PORT_IN_PKT_NUM          (1 << 13)
#define HAL_MT_KG_EPL_DBG_DP_ILEGAL_DPORT_DROP_CNT         (1 << 14)
#define HAL_MT_KG_EPL_DBG_DP_ILEGAL_DESTINATION_DROP_CNT   (1 << 15)
#define HAL_MT_KG_EPL_DBG_DP_PKT_SIZE_LESS64_DROP_CNT      (1 << 16)
#define HAL_MT_KG_EPL_DBG_DP_PORT_DISABLE_PKT_DROP_CNT     (1 << 17)
#define HAL_MT_KG_EPL_DBG_DP_PKT_SOP_ERR_DROP_CNT          (1 << 18)
#define HAL_MT_KG_EPL_DBG_DP_LBM_FWD_VALID_DROP_CNT        (1 << 19)
#define HAL_MT_KG_EPL_DBG_DP_LBM_REC_INVALID_DROP_CNT      (1 << 20)
#define HAL_MT_KG_EPL_DBG_DP_LBM_PACKET_IN_CNT             (1 << 21)
#define HAL_MT_KG_EPL_DBG_DP_LBM_PACKET_OUT_CNT            (1 << 22)
#define HAL_MT_KG_EPL_DBG_DP_LBM_PACKET_DROP_CNT           (1 << 23)
#define HAL_MT_KG_EPL_DBG_DP_BUF_TRUN_PKT_CNT              (1 << 24)
#define HAL_MT_KG_EPL_DBG_DP_PKT_BG_MTU_TRUN_PKT_CNT       (1 << 25)
#define HAL_MT_KG_EPL_DBG_DP_RUNT_PKT_CNT                  (1 << 26)
    uint32 flag;
} hal_mt_kg_port_epl_dbg_cnt_t;

typedef struct hal_mt_kg_port_epl_dbg_que_cnt_s {
    uint32 epl_pipe_que_data_remain_cnt[HAL_MT_KG_PL_CHANNEL_NUM][HAL_MT_KG_PL_QUEUE_NUM];
    uint32 epl_pipe_que_eop_cnt[HAL_MT_KG_PL_CHANNEL_NUM][HAL_MT_KG_PL_QUEUE_NUM];
    uint32 epl_pipe_free_buf_num[HAL_MT_KG_PL_CHANNEL_NUM];
    uint32 epl_pipe_buf_used_cnt[HAL_MT_KG_PL_CHANNEL_NUM];
    uint32 epl_ubuf_buf_num_used_max_cnt[HAL_MT_KG_PL_CHANNEL_NUM];

#define HAL_MT_KG_EPL_DBG_EPL_PIPE_QUE_DATA_REMAIN_CNT  (1 << 0)
#define HAL_MT_KG_EPL_DBG_EPL_PIPE_QUE_EOP_CNT          (1 << 1)
#define HAL_MT_KG_EPL_DBG_EPL_PIPE_FREE_BUF_NUM         (1 << 2)
#define HAL_MT_KG_EPL_DBG_EPL_PIPE_BUF_USED_CNT         (1 << 3)
#define HAL_MT_KG_EPL_DBG_EPL_UBUF_BUF_NUM_USED_MAX_CNT (1 << 4)
    uint32 flag;
} hal_mt_kg_port_epl_dbg_que_cnt_t;

typedef struct hal_mt_kg_port_epl_port_refl_ts_fifo_rdata_umac_s {
    uint32 umac_ch;          // UMAC channel number
    uint32 ts_id;            // Timestamp ID
    uint32 timestamp[3];     // Timestamp value
    uint32 tod_id;           // Time of Day ID
    uint32 umac_refl_err;    // UMAC reflection error
    uint32 epl_refl_ecc_err; // EPL reflection ECC error

#define HAL_MT_KG_EPL_PORT_REFL_TS_FIFO_RDATA_UMAC_CH               (1 << 0)
#define HAL_MT_KG_EPL_PORT_REFL_TS_FIFO_RDATA_UMAC_TS_ID            (1 << 1)
#define HAL_MT_KG_EPL_PORT_REFL_TS_FIFO_RDATA_UMAC_TIMESTAMP        (1 << 2)
#define HAL_MT_KG_EPL_PORT_REFL_TS_FIFO_RDATA_UMAC_TOD_ID           (1 << 3)
#define HAL_MT_KG_EPL_PORT_REFL_TS_FIFO_RDATA_UMAC_UMAC_REFL_ERR    (1 << 4)
#define HAL_MT_KG_EPL_PORT_REFL_TS_FIFO_RDATA_UMAC_EPL_REFL_ECC_ERR (1 << 5)
#define HAL_MT_KG_EPL_PORT_REFL_TS_FIFO_RDATA_UMAC_LAST             (1 << 6)
    uint32 flag;
} hal_mt_kg_port_epl_port_refl_ts_fifo_rdata_umac_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
clx_error_no_t
hal_mt_kg_port_epl_fd_buff_err_mask(const uint32 unit, const uint32 port, bool enable);

/**
 * @brief EPL FD buffer value get.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Device port number.
 * @param [in]     dest_speed     - Destination speed.
 * @param [out]    cur_buffer     - Current FD buffer.
 * @param [out]    dest_buffer    - Destination FD buffer.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_fd_buffer_get(const uint32 unit,
                                 const uint32 port,
                                 const clx_port_speed_t dest_speed,
                                 hal_mt_kg_port_epl_fd_buf_t *cur_buffer,
                                 hal_mt_kg_port_epl_fd_buf_t *dest_buffer);

/**
 * @brief EPL FD buffer size set.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Device port number.
 * @param [in]    q_id      - Queue ID.
 * @param [in]    q_size    - Queue size.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_fd_buffer_size_set(uint32 unit,
                                      const uint32 port,
                                      const uint32 q_id,
                                      uint32 q_size);

clx_error_no_t
hal_mt_kg_port_epl_fd_buff_drop_th_get(const uint32 unit, const uint32 port, uint32 *ptr_afull_th);

clx_error_no_t
hal_mt_kg_port_epl_fd_buff_drop_th_set(const uint32 unit, const uint32 port, uint32 afull_th);

clx_error_no_t
hal_mt_kg_port_epl_tdm_slot_mask(const uint32 unit, const uint32 port, const uint32 valid);

/**
 * @brief EPL FD buffer value get.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Device port number.
 * @param [in]     speed     - Device speed.
 * @param [out]    fd_buf    - EPL FD buffer.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
 clx_error_no_t
 hal_mt_kg_port_epl_fd_buffer_value_get(const uint32 unit,
                                        const uint32 port,
                                        const clx_port_speed_t speed,
                                        hal_mt_kg_port_epl_fd_buf_t *fd_buf);

clx_error_no_t
hal_mt_kg_port_epl_fd_buffer_clean(const uint32 unit, const uint32 port, uint32 address, uint32 size);

clx_error_no_t
hal_mt_kg_port_epl_fd_buffer_pointer_get(const uint32 unit, const uint32 port, uint32 address, uint32 size, uint32 *pointer);

clx_error_no_t
hal_mt_kg_port_epl_pipe_que_data_remain_cnt_get(const uint32 unit, const uint32 port, uint32 *remain_cnt);

/**
 * @brief EPL init for port.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Device port number.
 * @param [in]    lane_cnt    - Device lane count.
 * @param [in]    speed       - Device speed.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_init(const uint32 unit, const uint32 port, const uint32 lane_cnt, const clx_port_speed_t speed);

/**
 * @brief EPL deinit for port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Device port number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_deinit(const uint32 unit, const uint32 port);

/**
 * @brief EPL pipe FD buffer get.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Device port number.
 * @param [out]    fd_buf    - EPL FD buffer.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_pipe_fd_buf_cfg_get(uint32 unit,
                                       const uint32 port,
                                       hal_mt_kg_port_epl_fd_buf_t *fd_buf);

/**
 * @brief EPL tdm slot to channel map get.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Device port number.
 * @param [out]    slot2ch_map    - TDM slot to channel map.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_tdm_slot_map_get(const uint32 unit, const uint32 port, uint32 *slot2ch_map);

/**
 * @brief EPL chip soft reset.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    state    - State.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_chip_soft_reset(uint32 unit, uint32 state);

/**
 * @brief EPL pipe mem init.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_pipe_mem_init(uint32 unit);

/**
 * @brief EPL mem check.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_mem_check(uint32 unit);

/**
 * @brief EPL plane init.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_plane_init(uint32 unit);

/**
 * @brief EPL buffer empty check.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Device port number.
 * @return        CLX_E_OK         - Operate success.
 * @return        CLX_E_TIMEOUT    - Timeout.
 * @return        CLX_E_OTHERS     - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_buf_empty_check(const uint32 unit, const uint32 port);

/**
 * @brief EPL admin state config.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Device port number.
 * @param [in]    enable    - Enable.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_admin_state_cfg(const uint32 unit, const uint32 port, uint32 enable);

/**
 * @brief EPL flush enable config.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Device port number.
 * @param [in]    enable    - Enable.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_flush_en_cfg(const uint32 unit, const uint32 port, uint32 enable);

/**
 * @brief EPL xoff mask port pltc config.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Device port number.
 * @param [in]    pltc_bmp    - PTC bitmap.
 * @param [in]    enable      - Enable.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_xoff_mask_port_pltc_cfg(const uint32 unit,
                                           const uint32 port,
                                           const uint32 pltc_bmp,
                                           uint32 enable);

/**
 * @brief EPL port speed config.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Device port number.
 * @param [in]    speed    - Device speed.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_speed_set(const uint32 unit, const uint32 port, const clx_port_speed_t speed);

/**
 * @brief EPL fabric set.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    port         - Device port number.
 * @param [in]    fabric_en    - Fabric enable.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_fabric_mode_set(uint32 unit, uint32 port, uint32 fabric_en);

/**
 * @brief EPL fabric get.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Device port number.
 * @param [out]    fabric_en    - Fabric enable.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_fabric_mode_get(uint32 unit, uint32 port, uint32 *fabric_en);

/**
 * @brief This API is used to get the register list for epl.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [in]     reg_info    - Register info.
 * @param [out]    reg_info    - Register info.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_epl_dbg_reg_list_get(const uint32 unit, const uint32 port, uint32 *reg_info);

/**
 * @brief EPL debug counter get.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Device port number.
 * @param [out]    dbg_cnt    - Debug counter.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_dbg_cnt_get(uint32 unit, uint32 port, hal_mt_kg_port_epl_dbg_cnt_t *dbg_cnt);

/**
 * @brief EPL debug queue counter get.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Device port number.
 * @param [out]    dbg_cnt    - Debug counter.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_dbg_que_cnt_get(uint32 unit,
                                   uint32 port,
                                   hal_mt_kg_port_epl_dbg_que_cnt_t *dbg_cnt);

/**
 * @brief EPL tc2q map cfg.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Device port number.
 * @param [in]    tc2q_map    - TC2Q map.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_tc2q_map_set(uint32 unit, uint32 port, uint32 *tc2q_map);

/**
 * @brief EPL tc2q map get.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Device port number.
 * @param [in]    tc2q_map    - TC2Q map.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_tc2q_map_get(uint32 unit, uint32 port, uint32 *tc2q_map);

/**
 * @brief EPL eth dead lock cfg.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Device port number.
 * @param [in]    queue    - Choose the queue.
 * @param [in]    mode     - Dead lock mode pfc/pause.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_eth_dead_lock_cfg(const uint32 unit,
                                     const uint32 port,
                                     const uint32 queue,
                                     const uint32 mode);

/**
 * @brief EPL cut through cfg.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    cut_through    - Cut through enable.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_cut_through_cfg(uint32 unit, uint32 cut_through);

/**
 * @brief EPL port flow control mode config.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Device port number.
 * @param [in]    fc_mode    - Flow control mode.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_fc_mode_set(const uint32 unit, const uint32 port, const uint32 fc_mode);

/**
 * @brief EPL dead lock detect threshold cfg.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    port         - Device port number.
 * @param [in]    threshold    - Threshold value.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_dead_lock_detect_th_cfg(const uint32 unit,
                                           const uint32 port,
                                           const uint32 threshold);

/**
 * @brief EPL queue flush enable config.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Device port number.
 * @param [in]    queue_type    - Choose HAL_MT_PORT_LOSSLESS_QUEUE or HAL_MT_PORT_LOSSY_QUEUE.
 * @param [in]    enable        - Enable.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_que_flush_en_cfg(const uint32 unit,
                                    const uint32 port,
                                    const uint32 queue_type,
                                    const uint32 enable);

/**
 * @brief Get port average rate.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    port         - Device port number.
 * @param [in]    aver_rate    - Average rate.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_average_rate_get(const uint32 unit, uint32 port, uint32 *aver_rate);

/**
 * @brief Select monitor port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Device port number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_monitor_port_select(const uint32 unit, uint32 port);

/**
 * @brief Set specific port rate sample window.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Device port number.
 * @param [in]    window_count    - Window count.
 * @param [in]    div_shift       - Div shift.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_mburst_win_div_set(const uint32 unit,
                                      const uint32 port,
                                      const uint32 window_count,
                                      const uint32 div_shift);

/**
 * @brief Get specific port rate sample window.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Device port number.
 * @param [in]    window_count    - Window count.
 * @param [in]    div_shift       - Div shift.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_mburst_win_div_get(const uint32 unit,
                                      const uint32 port,
                                      uint32 *window_count,
                                      uint32 *div_shift);

/**
 * @brief Get monitor port.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Device port number.
 * @param [in]    monitor_port    - Monitor port number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_monitor_port_get(const uint32 unit, uint32 port, uint32 *monitor_port);

/**
 * @brief EPL flow ctrl ignore cfg.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Device port number.
 * @param [in]    queue_type    - Choose HAL_MT_PORT_LOSSLESS_QUEUE or HAL_MT_PORT_LOSSY_QUEUE.
 * @param [in]    enable        - Enable.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_flow_ctrl_ignore_cfg(const uint32 unit,
                                        const uint32 port,
                                        const uint32 queue_type,
                                        uint32 enable);

/**
 * @brief EPL flow ctrl ignore get.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Device port number.
 * @param [in]     queue_type    - Choose HAL_MT_PORT_LOSSLESS_QUEUE or HAL_MT_PORT_LOSSY_QUEUE.
 * @param [out]    enable        - Enable.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_flow_ctrl_ignore_get(const uint32 unit,
                                        const uint32 port,
                                        const uint32 queue_type,
                                        uint32 *enable);

/**
 * @brief Get FIFO empty.
 *
 * @param [in]     unit     - Unit number.
 * @param [in]     port     - Port number.
 * @param [out]    empty    - Empty.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_fifo_empty_get(const uint32 unit, const uint32 port, uint32 *empty);

/**
 * @brief Get packet generation enable.
 *
 * @param [in]     unit          - Unit number.
 * @param [in]     port          - Port number.
 * @param [out]    ptr_enable    - Enable.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_epg_state_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief Generate packet.
 *
 * @param [in]    unit       - Unit number.
 * @param [in]    port       - Port number.
 * @param [in]    speed      - Speed.
 * @param [in]    pkt_cfg    - Packet configuration.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_pkt_gen(const uint32 unit,
                           const uint32 port,
                           clx_port_speed_t speed,
                           hal_mt_kg_port_epl_pkt_gen_cfg_t *pkt_cfg);

/**
 * @brief Stop packet generation.
 *
 * @param [in]    unit    - Unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_gen_pkt_stop(const uint32 unit, const uint32 port);

/**
 * @brief Get ts entry.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Device port number.
 * @param [out]    ts_seq_num    - Timestamp sequence number.
 * @param [out]    ts_sec        - Timestamp second.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_ts_entry_get(const uint32 unit,
                                const uint32 port,
                                uint32 *ts_seq_num,
                                uint32 *ts_sec);

/**
 * @brief Check ts fifo irq.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Device port number.
 * @return        CLX_E_OK         - Operate success.
 * @return        CLX_E_TIMEOUT    - Timeout.
 * @return        CLX_E_OTHERS     - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_ts_fifo_irq_check(uint32 unit, uint32 port);

/**
 * @brief Get epl xoff status.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Device port number.
 * @param [in]    xoff_sta    - Epl receive xoff status.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_epl_recv_xoff_sta_get(uint32 unit, uint32 port, uint32 *xoff_sta);
#endif /* __HAL_MT_KG_PORT_EPL_H__ */