/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  util_lib_crc.h
 * PURPOSE:
 *  this file is used to provide crc32 calculation operations to other users.
 * NOTES:
 *  it contains operations as below:
 *      1. calculate crc32
 *
 *
 *
 */
#ifndef UTIL_LIB_CRC_H
#define UTIL_LIB_CRC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <util/lib/util_lib.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief It is used to calculate crc32 of a buffer of data.
 *
 * "123456789" crc is 0xCBF43926
 * in packet, the crc is filled like: 26 39 f4 cb.
 *
 * @param [in]     ptr_data    - Buffer start address.
 * @param [in]     byte_len    - Buffer length.
 * @param [in]     ptr_crc     - Input crc base (initialized to 0 when first call).
 * @param [out]    ptr_crc     - The crc result.
 * @return         CLX_E_OK               - Calculate success.
 * @return         CLX_E_BAD_PARAMETER    - There is NULL pointer parameter.
 */
clx_error_no_t
util_lib_crc_crc32_calc(const uint8 *ptr_data, const uint32 byte_len, uint32 *ptr_crc);

/**
 * @brief It is used to calculate crc32 of a buffer of data. (data unit = word).
 *
 * Efuse crc check needs this function for word crc calculation
 * Illustration for bit num = 4
 * 1100001011
 * ------------------------
 * 10011/ 11010110110000             1st run: remainder = 1101
 * 10011
 * -----
 * 10011   <-- left shift    2nd run: remainder = 1001
 * 10011   <-- xored value when remainde MSB==1
 * -----
 * ^ 000010110
 * |     10011
 * |     -----
 * |      010100
 * remainder    10011
 * MSB is 1    -----
 * XORed POLY     1110  --> CRC.
 *
 * @param [in]     ptr_data    - Buffer start address.
 * @param [in]     word_len    - Buffer length in word.
 * @param [out]    ptr_crc     - The crc result.
 * @return         CLX_E_OK               - Calculate success.
 * @return         CLX_E_BAD_PARAMETER    - There is NULL pointer parameter.
 */
clx_error_no_t
util_lib_crc_crc32_word_calc(const uint32 *ptr_data, const uint32 word_len, uint32 *ptr_crc);

#endif /* End of UTIL_LIB_CRC_H */
