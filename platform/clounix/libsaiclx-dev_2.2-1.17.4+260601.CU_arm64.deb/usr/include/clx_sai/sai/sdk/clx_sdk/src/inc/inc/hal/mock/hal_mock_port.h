/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mock_port.h
 * PURPOSE:
 *      It provide HAL MOCK PORT module API.
 * NOTES:
 */

#ifndef HAL_MOCK_PORT_H
#define HAL_MOCK_PORT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef struct hal_mock_port_mock_cfg_s {
    uint8_t port_admin;
    uint8_t port_loopback;
} hal_mock_port_mock_cfg_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS */

/* STATIC VARIABLE DECLARATIONS
 */
/**
 * @brief This API is used to configure a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @param [in]    cfg     - Port configuration.
 * @return        CLX_E_OK        - The operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mock_port_cfg_set(const uint32 unit, const uint32 port, const clx_port_cfg_t *cfg);

/**
 * @brief This API is used to get the configuration of a specific port.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - Physical port ID.
 * @param [out]    cfg     - Port configuration.
 * @return         CLX_E_OK        - The operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mock_port_cfg_get(const uint32 unit, const uint32 port, clx_port_cfg_t *cfg);

/**
 * @brief This API is used to set the loopback of a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port ID.
 * @param [in]    lbtype    - Loopback type.
 * @return        CLX_E_OK        - The operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mock_port_lb_set(const uint32 unit, const uint32 port, const clx_port_loopback_t lbtype);

/**
 * @brief This API is used to get the loopback of a specific port.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Physical port ID.
 * @param [out]    lbtype    - Loopback type.
 * @return         CLX_E_OK        - The operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mock_port_lb_get(const uint32 unit, const uint32 port, clx_port_loopback_t *lbtype);

/**
 * @brief This API is used to get the physical link status for a specific port.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [out]    ptr_link    - Link status (Reference to CLX_PORT_LINK_XXX).
 * @return         CLX_E_OK        - The operation success.
 * @return         CLX_E_OTHERS    - Simulator or transport error.
 */
clx_error_no_t
hal_mock_port_link_get(const uint32 unit, const uint32 port, uint32 *ptr_link);

/**
 * @brief To initialize port module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK                - Operate success.
 * @return        CLX_E_ALREADY_INITED    - Module is reinitialized.
 * @return        CLX_E_OTHERS            - Init fail.
 */
clx_error_no_t
hal_mock_port_init(const uint32 unit);

/**
 * @brief To deinitialize the port module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK            - Success.
 * @return        CLX_E_NOT_INITED    - Module is not initialized.
 * @return        CLX_E_OTHERS        - Deinitialization failed for other reasons.
 */
clx_error_no_t
hal_mock_port_deinit(const uint32 unit);

#endif /* #ifndef HAL_MOCK_PORT_H */
