/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   hal_mt_nb_pvt.h
 * PURPOSE:
 *      It provide HAL PVT module API.
 * NOTES:
 */

#ifndef HAL_MT_NB_PVT_H
#define HAL_MT_NB_PVT_H

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_NB_PVT_REASON_PRIORITY_MIN (0)

/*
 * Multiplies an integer by a fraction, while avoiding unnecessary
 * overflow or loss of precision.
 */
#define HAL_MT_NB_PVT_MULT_FRAC(x, numer, denom)        \
    ({                                                  \
        typeof(x) quot = (x) / (denom);                 \
        typeof(x) rem = (x) % (denom);                  \
        (quot * (numer)) + ((rem * (numer)) / (denom)); \
    })

#define HAL_MT_NB_PVT_RESULT_CHECK(rc, sema, mem) \
    if ((rc) != CLX_E_OK) {                       \
        if (sema) {                               \
            osal_semaphore_give(sema);            \
        }                                         \
        if (mem) {                                \
            osal_free(mem);                       \
        }                                         \
        return (rc);                              \
    }

/* DATA TYPE DECLARATIONS
 */
/*
 * struct hal_mt_nb_pvt_poly_term_t - a term descriptor of the PVT data translation
 *              polynomial
 * @deg: degree of the term.
 * @coef: multiplication factor of the term.
 * @divider: distributed divider per each degree.
 * @divider_leftover: divider leftover, which couldn't be redistributed.
 */
typedef struct hal_mt_nb_pvt_poly_term_s {
    uint32 deg;
    int32 coef;
    int32 divider;
    int32 divider_leftover;
} hal_mt_nb_pvt_poly_term_t;

/*
 * struct hal_mt_nb_pvt_poly_t - PVT data translation polynomial descriptor
 * @total_divider: total data divider.
 * @terms: polynomial terms up to a free one.
 */
typedef struct hal_mt_nb_pvt_poly_s {
    int32 total_divider;
    hal_mt_nb_pvt_poly_term_t terms[];
} hal_mt_nb_pvt_poly_t;

typedef enum hal_mt_nb_pvt_sensor_type_e {
    HAL_MT_NB_PVT_TEMP,
    HAL_MT_NB_PVT_VOLT,
    HAL_MT_NB_PVT_LVT,
    HAL_MT_NB_PVT_ULVT,
    HAL_MT_NB_PVT_SVT,
    HAL_MT_NB_PVT_SENSORS_MAX
} hal_mt_nb_pvt_sensor_type_t;

typedef enum hal_mt_nb_pvt_trim_type_e {
    HAL_MT_NB_PVT_TRIMO,
    HAL_MT_NB_PVT_TRIMG,
    HAL_MT_NB_PVT_VTRIM,
    HAL_MT_NB_PVT_TRIM_TYPE_MAX
} hal_mt_nb_pvt_trim_type_t;

typedef struct hal_mt_nb_pvt_trim_s {
    uint32 bit_offset;
    uint32 bit_num;
    uint32 bit_msk;
    uint32 value;
} hal_mt_nb_pvt_trim_t;

typedef struct hal_mt_nb_pvt_ctrl_reg_filed_s {
    uint32 bit_offset;
    uint32 bit_num;
    uint32 bit_msk;
    uint32 value;
} hal_mt_nb_pvt_ctrl_reg_filed_t;

/*
it it mapping to PVT field, it is derived from
hal_mt_nb_reg_top_cfg_pvt10_control_field_t
*/
typedef enum hal_mt_nb_pvt_control_field_e {
    HAL_MT_NB_CONTROL_PVT_VSAMPLE_FIELD_ID,
    HAL_MT_NB_CONTROL_PVT_PSAMPLE_FIELD_ID,
    HAL_MT_NB_CONTROL_PVT_TRIMO_FIELD_ID,
    HAL_MT_NB_CONTROL_PVT_TRIMG_FIELD_ID,
    HAL_MT_NB_CONTROL_PVT_VTRIM_FIELD_ID,
    HAL_MT_NB_CONTROL_PADDING1_FIELD_ID,
    HAL_MT_NB_CONTROL_LAST_FIELD_ID
} hal_mt_nb_pvt_control_field_t;

typedef struct hal_mt_nb_pvt_dev_s {
    uint32 id;
    clx_semaphore_id_t sema;
    uint32 ctrl_reg;
    uint32 data_reg;
    uint32 ena_reg;
    uint32 ready_reg;
    hal_mt_nb_pvt_trim_t trim[HAL_MT_NB_PVT_TRIM_TYPE_MAX];
} hal_mt_nb_pvt_dev_t;

typedef struct hal_mt_nb_pvt_s_trim_s {
    uint32 trim[HAL_MT_NB_PVT_TRIM_TYPE_MAX];
} hal_mt_nb_pvt_s_trim_t;

typedef enum hal_mt_nb_pvt_id_e {
    HAL_MT_NB_PVT_ID_0,
    HAL_MT_NB_PVT_ID_1,
    HAL_MT_NB_PVT_ID_2,
    HAL_MT_NB_PVT_ID_3,
    HAL_MT_NB_PVT_ID_4,
    HAL_MT_NB_PVT_ID_5,
    HAL_MT_NB_PVT_ID_6,
    HAL_MT_NB_PVT_ID_7,
    HAL_MT_NB_PVT_ID_8,
    HAL_MT_NB_PVT_ID_9,
    HAL_MT_NB_PVT_ID_10,
    HAL_MT_NB_PVT_ID_11,
    HAL_MT_NB_PVT_ID_12,
    HAL_MT_NB_PVT_ID_13,
    HAL_MT_NB_PVT_ID_14,
    HAL_MT_NB_PVT_ID_MAX
} hal_mt_nb_pvt_id_t;

typedef enum hal_mt_nb_pvt_s_id_e {
    HAL_MT_NB_S_PVT_ID_0,
    HAL_MT_NB_S_PVT_ID_MAX
} hal_mt_nb_pvt_s_id_t;

#define HAL_MT_NB_PVT_TIME_OUT 1000

#define HAL_MT_NB_PVT_ENA_ENABLE    1
#define HAL_MT_NB_PVT_ENA_DISENABLE 0

typedef struct hal_mt_nb_pvt_eva_s {
    uint32 vsample;
    uint32 psample;
} hal_mt_nb_pvt_eva_t;

/* EFUSE BIT mapping for PVT TRIMG/TRIMO/VTRIM */
#define HAL_MT_NB_EFUSE_PAGE_SIZE      256
#define HAL_MT_NB_PVT_REG_BIT_NUM      32
#define HAL_MT_NB_PVT_TRIMO_BIT_OFFSET 384 /* Bit 384 ~ 504 */
#define HAL_MT_NB_PVT_TRIMO_BIT_NUM    8
#define HAL_MT_NB_PVT_TRIMO_MASK       0xFF

#define HAL_MT_NB_PVT_TRIMG_BIT_OFFSET 512 /* BIt 512 ~ 587 */
#define HAL_MT_NB_PVT_TRIMG_BIT_NUM    5
#define HAL_MT_NB_PVT_TRIMG_MASK       0x1F

#define HAL_MT_NB_PVT_VTRIM_BIT_OFFSET 592 /* BIt 592 ~ 667 */
#define HAL_MT_NB_PVT_VTRIM_BIT_NUM    5
#define HAL_MT_NB_PVT_VTRIM_MASK       0x1F

#define HAL_MT_NB_PVT_ID_CHK(unit, id) OSAL_ASSERT((id) < HAL_MT_NB_PVT_ID_MAX);

/**
 * @brief Get chip temperature.
 *
 * @param [in]     unit               - Device unit number.
 * @param [out]    ptr_temperature    - Chip temperature.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_pvt_chip_temp_get(const uint32 unit, int32 *ptr_temperature);

/**
 * @brief Get chip temperature for AN-LT usage.
 *
 * @param [in]     unit               - Device unit number.
 * @param [out]    ptr_temperature    - Chip temperature.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_pvt_anlt_chip_temp_get(const uint32 unit, int32 *ptr_temperature);

/**
 * @brief Get chip temperature.
 *
 * @param [in]     unit               - Device unit number.
 * @param [out]    ptr_temperature    - Chip temperature list.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_pvt_chip_temp_list_get(const uint32 unit, clx_swc_thermal_list_t *ptr_temperature);

/**
 * @brief Get calibration information.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     inst              - Instance number.
 * @param [out]    ptr_calib_info    - Calibration information.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_pvt_calib_info_get(const uint32 unit,
                             const uint32 inst,
                             clx_swc_pvt_calib_info_t *ptr_calib_info);

/**
 * @brief Initialize PVT.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_pvt_init(const uint32 unit);

/**
 * @brief Deinitialize PVT.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_pvt_deinit(const uint32 unit);

#endif /* #ifndef HAL_MT_NB_PVT_H */
