/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

#include <clx/clx_error.h>
typedef int osal_timer_id_t;

typedef void (*osal_timer_handler_t)(void *arg);

/* EXPORTED SUBPROGRAM BODIES
 */

/**
 * @brief OS abstration API to init osal timer task and resource. This function can ignore when
 *        init. Because the timer start function will also check timer task status.
 *        If timer task not start, it will init it.
 *
 * @return        CLX_E_OK        - Successfully init.
 * @return        CLX_E_OTHERS    - Timer init failed.
 */
clx_error_no_t
osal_timer_init(void);

/**
 * @brief OS abstration API to deinit osal timer task and resource.
 *
 * @return        CLX_E_OK        - Successfully deinit.
 * @return        CLX_E_OTHERS    - Trigger timer task failed.
 */
clx_error_no_t
osal_timer_deinit(void);

/**
 * @brief OS abstration API to start a timmer.
 *
 * @param [in]     time_value_ms    - Timer value in ms.
 * @param [in]     func             - Callback function when timeout.
 * @param [in]     arg              - Arg for callback function.
 * @param [out]    out_timerid      - Timerid.
 * @return         CLX_E_OK            - Successfully get time.
 * @return         CLX_E_TABLE_FULL    - No Timer resource.
 * @return         CLX_E_OTHERS        - Fail to get time.
 */
clx_error_no_t
osal_timer_start(osal_timer_id_t *out_timerid,
                 const uint32 time_value_ms,
                 const osal_timer_handler_t func,
                 const void *arg);

/**
 * @brief OS abstration API to stop running timer.
 *
 * @param [in]     timerid     - Timerid.
 * @param [out]    func_arg    - Output user configure func_arg, if NULL,
 *                               will ignore it.
 * @return         CLX_E_OK               - Successfully stop timer.
 * @return         CLX_E_BAD_PARAMETER    - Wrong timerid.
 * @return         CLX_E_OTHERS           - Stop timer failed.
 */
clx_error_no_t
osal_timer_stop(osal_timer_id_t timerid, void **func_arg);