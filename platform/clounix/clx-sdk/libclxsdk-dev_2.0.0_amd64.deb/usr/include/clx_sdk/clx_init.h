/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:   clx_init.h
 * PURPOSE:
 *      Custom configuration on CLX SDK.
 * NOTES:
 */
#ifndef CLX_INIT_H
#define CLX_INIT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_module.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define CLX_INIT_DBG_FLAG_ERR   (1U << 0)
#define CLX_INIT_DBG_FLAG_WARN  (1U << 1)
#define CLX_INIT_DBG_FLAG_INFO  (1U << 2)


/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef void
(*CLX_INIT_WRITE_FUNC_T) (
    const void *ptr_buf,
    UI32_T len);

typedef CLX_ERROR_NO_T
(*CLX_INIT_OPEN_NONVOLATILE_FUNC_T) (
    void);

typedef CLX_ERROR_NO_T
(*CLX_INIT_CLOSE_NONVOLATILE_FUNC_T) (
    void);

typedef I32_T
(*CLX_INIT_WRITE_NONVOLATILE_FUNC_T) (
    const void *ptr_buf,
    UI32_T num_bytes);

typedef I32_T
(*CLX_INIT_READ_NONVOLATILE_FUNC_T) (
    void *ptr_buf,
    UI32_T num_bytes);

typedef struct CLX_INIT_PARAM_S
{
    CLX_INIT_WRITE_FUNC_T               dsh_write_func;   /* Write function for diag shell */
    CLX_INIT_WRITE_FUNC_T               debug_write_func; /* Write function for debug message */
    CLX_INIT_OPEN_NONVOLATILE_FUNC_T    open_nv_func;     /* Open non-volatile function file */
    CLX_INIT_CLOSE_NONVOLATILE_FUNC_T   close_nv_func;    /* Close non-volatile function file */
    CLX_INIT_WRITE_NONVOLATILE_FUNC_T   write_nv_func;    /* Write non-volatile function into file */
    CLX_INIT_READ_NONVOLATILE_FUNC_T    read_nv_func;     /* Read non-volatile function from file */
} CLX_INIT_PARAM_T;

typedef enum
{
    CLX_INIT_MODE_WARM_INIT = 0,    /* reload config in init stage */
    CLX_INIT_MODE_WARM_DEINIT,      /* save config in deinit stage */
    CLX_INIT_MODE_LAST
} CLX_INIT_MODE_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   clx_init_initCmnModule
 * PURPOSE:
 *      This API is used to initialize the common modules.
 * INPUT:
 *      ptr_init_param      -- The sdk_demo callback functions.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_OTHERS        -- Operation failed.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_init_initCmnModule(
    CLX_INIT_PARAM_T        *ptr_init_param);

/* FUNCTION NAME:   clx_init_deinitCmnModule
 * PURPOSE:
 *      This API is used to deinitialize the common modules.
 * INPUT:
 *      None
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_OTHERS        -- Operation failed.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_init_deinitCmnModule(
    void);

/* FUNCTION NAME:   clx_init_initLowLevel
 * PURPOSE:
 *      This API is used to initialize the low level modules.
 * INPUT:
 *      unit                -- The unit ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_OTHERS        -- Operation failed.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_init_initLowLevel(
    const   UI32_T          unit);

/* FUNCTION NAME:   clx_init_deinitLowLevel
 * PURPOSE:
 *      This API is used to deinitialize the low level modules.
 * INPUT:
 *      unit                -- The unit ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_OTHERS        -- Operation failed.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_init_deinitLowLevel(
    const   UI32_T          unit);

/* FUNCTION NAME:   clx_init_initTaskRsrc
 * PURPOSE:
 *      This API is used to initialize the task resources of the modules.
 * INPUT:
 *      unit                -- The unit ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_OTHERS        -- Operation failed.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_init_initTaskRsrc(
    const   UI32_T          unit);

/* FUNCTION NAME:   clx_init_deinitTaskRsrc
 * PURPOSE:
 *      This API is used to deinitialize the task resources of the modules.
 * INPUT:
 *      unit                -- The unit ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_OTHERS        -- Operation failed.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_init_deinitTaskRsrc(
    const   UI32_T          unit);

/* FUNCTION NAME:   clx_init_initModule
 * PURPOSE:
 *      This API is used to initialize the modules.
 * INPUT:
 *      unit                -- The unit ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_OTHERS        -- Operation failed.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_init_initModule(
    const   UI32_T          unit);

/* FUNCTION NAME:   clx_init_deinitModule
 * PURPOSE:
 *      This API is used to deinitialize the modules.
 * INPUT:
 *      unit                -- The unit ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_OTHERS        -- Operation failed.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_init_deinitModule(
    const   UI32_T          unit);

/* FUNCTION NAME:   clx_init_initTask
 * PURPOSE:
 *      This API is used to initialize the tasks of the modules.
 * INPUT:
 *      unit                -- The unit ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_OTHERS        -- Operation failed.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_init_initTask(
    const   UI32_T          unit);

/* FUNCTION NAME:   clx_init_deinitTask
 * PURPOSE:
 *      This API is used to deinitialize the tasks of the modules.
 * INPUT:
 *      unit                -- The unit ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_OTHERS        -- Operation failed.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_init_deinitTask(
    const   UI32_T          unit);

/* FUNCTION NAME:   clx_init_getUnitNum
 * PURPOSE:
 *      This API is used to get the unit numbers.
 * INPUT:
 *      None
 * OUTPUT:
 *      ptr_num             -- The unit numbers
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_OTHERS        -- Operation failed.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_init_getUnitNum(
    UI32_T                  *ptr_num);

/* FUNCTION NAME:   clx_deinit
 * PURPOSE:
 *      This API is used to deinitialize the CLX SDK.
 * INPUT:
 *      None
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK             -- Successfully de-initialize SDK.
 *      CLX_E_OTHERS         -- Fail to complete de-initialization procedure.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_deinit(
    void);

/* FUNCTION NAME:   clx_init_setInitMode
 * PURPOSE:
 *      This API is used to set init Mode.
 * INPUT:
 *      unit                -- The unit ID
 *      mode                -- warm init, or deinit mode
 *      enable              -- TRUE, FALSE
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_OTHERS        -- Operation failed.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_init_setInitMode(
    const UI32_T unit,
    const CLX_INIT_MODE_T mode,
    const BOOL_T enable);

/* FUNCTION NAME:   clx_init_getInitMode
 * PURPOSE:
 *      This API is used to get init Mode.
 * INPUT:
 *      unit                -- The unit ID
 *      mode                -- warm init, or deinit mode
 * OUTPUT:
 *      ptr_enable
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_OTHERS        -- Operation failed.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_init_getInitMode(
    const UI32_T unit,
    const CLX_INIT_MODE_T mode,
    BOOL_T *ptr_enable);

/* FUNCTION NAME:   clx_init_setModuleDebugFlag
 * PURPOSE:
 *      This API is used to set debug flag on each module. Once module's
 *      debug flag has been set, the corresponding debug messages will be
 *      dumpped by debug_write_func.
 * INPUT:
 *      unit                -- The unit ID
 *      module_id           -- The module ID
 *      dbg_flag            -- The debug flag defined by CLX_INIT_DBG_FLAG_XXX
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_OTHERS        -- Operation failed.
 *
 * NOTES:
 *      The unit ID is meaningless on this API.
 */
CLX_ERROR_NO_T
clx_init_setModuleDebugFlag(
    const UI32_T            unit,
    const CLX_MODULE_T      module_id,
    const UI32_T            dbg_flag);

/* FUNCTION NAME:   clx_init_getModuleDebugFlag
 * PURPOSE:
 *      This API is used to get debug flag setting from each module.
 * INPUT:
 *      unit                -- The unit ID
 *      module_id           -- The module ID
 * OUTPUT:
 *      ptr_dbg_flag        -- The debug flag defined by CLX_INIT_DBG_FLAG_XXX
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_OTHERS        -- Operation failed.
 *
 * NOTES:
 *      The unit ID is meaningless on this API.
 */
CLX_ERROR_NO_T
clx_init_getModuleDebugFlag(
    const UI32_T            unit,
    const CLX_MODULE_T      module_id,
    UI32_T                  *ptr_dbg_flag);

#endif  /* CLX_INIT_H */
