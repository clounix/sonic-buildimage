/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_ifmon.h
 * PURPOSE:
 *      It provide HAL PORT module API.
 * NOTES:
 */

#ifndef HAL_MT_NB_IFMON_H
#define HAL_MT_NB_IFMON_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>

/* NAMING CONSTANT DECLARATIONS
 */
clx_error_no_t
hal_mt_nb_ifmon_link_irq_clear(const uint32 unit, const uint32 port);

clx_error_no_t
hal_mt_nb_ifmon_link_irq_en_set(const uint32 unit, const uint32 port, const uint32 enable);

clx_error_no_t
hal_mt_nb_ifmon_irq_get(const uint32 unit, const uint32 port, uint32 *fault, uint32 *link_change);

clx_error_no_t
hal_mt_nb_ifmon_link_fault_get(const uint32 unit,
                               const uint32 port,
                               uint32 *ptr_link,
                               uint32 *ptr_l_fault,
                               uint32 *ptr_r_fault,
                               uint32 *ptr_hiber);

/**
 * @brief To process anlt.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    anlt_np_bitmap    - Anlt next page bitmap.
 * @return        CLX_E_OK    - Operation is successfully. LX_E_BAD_PARAMETER - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_ifmon_anlt_process(const uint32 unit, HAL_MT_IFMON_ANLT_BITMAP_T anlt_np_bitmap);

/**
 * @brief To monitor anlt fsm.
 *
 * @param [in]    unit               - Chip id.
 * @param [in]    anlt_fsm_bitmap    - Anlt fsm port bitmap.
 * @param [in]    hiber_bitmap       - Hiber port bitmap.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_ifmon_anlt_fsm_process(const uint32 unit,
                                 HAL_MT_IFMON_ANLT_BITMAP_T anlt_fsm_bitmap,
                                 HAL_MT_IFMON_PORT_BITMAP_T hiber_bitmap);

/**
 * @brief To monitor chip temperature.
 *
 * @param [in]    unit    - Chip id.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_ifmon_temp_protect_process(const uint32 unit);

/**
 * @brief To get fsm hang cnt per port.
 *
 * @param [in]    unit            - Chip id.
 * @param [in]    port            - Port id.
 * @param [in]    fsm_hang_cnt    - Fsm hang cnt.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_ifmon_anlt_fsm_hang_cnt_get(const uint32 unit, uint32 port, uint32 *fsm_hang_cnt);

/**
 * @brief To process eqbk hang.
 *
 * @param [in]    unit    - Chip id.
 * @param [in]    port    - Port id.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_ifmon_eqbk_hang_process(const uint32 unit, const uint32 port);

/**
 * @brief To config serdes anlt interrupt.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port ID.
 * @param [in]    enable    - Enable/disbale anlt interrupt.
 * @return        CLX_E_OK    - Operation is successfully. LX_E_BAD_PARAMETER - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_ifmon_an_intr_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief To config serdes anlt interrupt.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Physical port ID.
 * @param [out]    status    - An interrupt statue.
 * @return         CLX_E_OK    - Operation is successfully. LX_E_BAD_PARAMETER - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_ifmon_an_intr_stat_get(const uint32 unit, const uint32 port, uint32 *status);

/**
 * @brief To config led lane status for a specific speed.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port ID.
 * @param [in]    speed    - A specific speed.
 * @return        CLX_E_OK    - Operation is successfully. LX_E_BAD_PARAMETER - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_ifmon_led_speed_set(const uint32 unit, const uint32 port, const uint32 speed);

#endif
