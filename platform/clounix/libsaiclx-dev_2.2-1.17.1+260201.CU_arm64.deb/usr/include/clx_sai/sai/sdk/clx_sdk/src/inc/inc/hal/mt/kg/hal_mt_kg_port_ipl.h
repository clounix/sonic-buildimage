/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *******************************************************************************/

#ifndef __HAL_MT_KG_PORT_IPL_H__
#define __HAL_MT_KG_PORT_IPL_H__

/* FILE NAME:  hal_mt_kg_port_ipl.h
 * PURPOSE:
 *      It provide HAL MT KG PORT IPL module API.
 * NOTES:
 *
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <hal/mt/kg/hal_mt_kg_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef struct hal_mt_kg_port_ipl_pipe_eth_cfg_s {
    uint32 port_en;
    uint32 port_type;    //'2'b00' for eth port; '01'fabric port;'10'for cpi port; '11'cpu port;
    uint32 pfc_mode;     //'1' for pfc mode; '0' for pause mode
    uint32 port_speed;   // 0:0G,1:1G;2:2.5G;3:5G;4:10G;5:25G;6:40G;7:50G;8:100G;9:200G;10:400G;
    uint32 cpi_have_pph; // only for cpi port; '1' for have pph; '0' for no pph (spec is wrong)
    uint32 disable_pfc_pause; //'1' ipl not use pause room and not gen xoff, '0': normal
    uint32 fast_tm_pfc;       //'1': final_pfc = ipl_pfc | tm_pfc 0: final_pfc=ipl_pfc
    uint32 timeout_enable;    //'1' fd-fd in pkt is timeout,generation eop, '0': normal
    uint32 leak_en;           //'1' leak enable,'0' leak disable
    uint32 leak_size;         // leak size config unit 1024byte;

/* Flag definitions for hal_mt_kg_port_ipl_pipe_eth_cfg_t */
#define HAL_MT_KG_IPL_PIPE_ETH_PORT_EN           (1 << 0)
#define HAL_MT_KG_IPL_PIPE_ETH_PORT_TYPE         (1 << 1)
#define HAL_MT_KG_IPL_PIPE_ETH_PFC_MODE          (1 << 2)
#define HAL_MT_KG_IPL_PIPE_ETH_PORT_SPEED        (1 << 3)
#define HAL_MT_KG_IPL_PIPE_ETH_CPI_HAVE_PPH      (1 << 4)
#define HAL_MT_KG_IPL_PIPE_ETH_DISABLE_PFC_PAUSE (1 << 5)
#define HAL_MT_KG_IPL_PIPE_ETH_FAST_TM_PFC       (1 << 6)
#define HAL_MT_KG_IPL_PIPE_ETH_TIMEOUT_ENABLE    (1 << 7)
#define HAL_MT_KG_IPL_PIPE_ETH_LEAK_EN           (1 << 8)
#define HAL_MT_KG_IPL_PIPE_ETH_LEAK_SIZE         (1 << 9)
#define HAL_MT_KG_IPL_PIPE_ETH_LAST              (1 << 10)
    uint32 flag;
} hal_mt_kg_port_ipl_pipe_eth_cfg_t;

typedef struct hal_mt_kg_port_ipl_tc2q_mix_s {
    uint32 unknown_tc;
    uint32 ctrl_pkt_tc;
    uint32 cfg_use_l3;
} hal_mt_kg_port_ipl_tc2q_mix_t;

typedef struct hal_mt_kg_port_ipl_q2tc_map_s {
    uint32 plq0_q2tc_map;
    uint32 plq1_q2tc_map;

/* Flag definitions for hal_mt_kg_port_ipl_q2tc_map_t */
#define HAL_MT_KG_IPL_Q2TC_MAP_PLQ0_Q2TC_MAP (1 << 0)
#define HAL_MT_KG_IPL_Q2TC_MAP_PLQ1_Q2TC_MAP (1 << 1)
#define HAL_MT_KG_IPL_Q2TC_MAP_LAST          (1 << 2)
    uint32 flag;
} hal_mt_kg_port_ipl_q2tc_map_t;

typedef struct hal_mt_kg_port_ipl_tc2q_map_s {
    uint32 plq0_tc2q_map;
    uint32 plq1_tc2q_map;

/* Flag definitions for hal_mt_kg_port_ipl_tc2q_map_t */
#define HAL_MT_KG_IPL_TC2Q_MAP_PLQ0_TC2Q_MAP (1 << 0)
#define HAL_MT_KG_IPL_TC2Q_MAP_PLQ1_TC2Q_MAP (1 << 1)
#define HAL_MT_KG_IPL_TC2Q_MAP_LAST          (1 << 2)
    uint32 flag;
} hal_mt_kg_port_ipl_tc2q_map_t;

typedef struct hal_mt_kg_port_ipl_pltc_map_cfg_s {
    uint32 ipv4_6_pltc_lossless_index;
    uint32 dscp;
    uint32 vlan_pltc_lossless_index;
    uint32 pcp;
    uint32 dei;
    uint32 exp_pltc_lossless_index;
    uint32 exp;

/* Flag definitions for hal_mt_kg_port_ipl_pltc_map_cfg_t */
#define HAL_MT_KG_PORT_IPL_IPV4_6_PLTC_MAP (1 << 0)
#define HAL_MT_KG_PORT_IPL_VLAN_PLTC_MAP   (1 << 1)
#define HAL_MT_KG_PORT_IPL_EXP_PLTC_MAP    (1 << 2)
#define HAL_MT_KG_PORT_IPL_PLTC_MAP_LAST   (1 << 3)
    uint32 flag;
} hal_mt_kg_port_ipl_pltc_map_cfg_t;

typedef struct hal_mt_kg_port_ipl_pipe_cfg_global_s {
    uint32 debug_port_index;
    uint32 pause_hrm_num_used_max_clr;
    uint32 data_buf_num_used_max_clr;
    uint32 port_xoff_lock_clr;
    uint32 share_trunc_enable;
    uint32 cpu_le_swap_en;
    uint32 cpu_protect_disable;
    uint32 cfg_use_cxh_tc;

#define HAL_MT_KG_IPL_PIPE_CFG_GLOBAL_DEBUG_PORT_INDEX           (1 << 0)
#define HAL_MT_KG_IPL_PIPE_CFG_GLOBAL_PAUSE_HRM_NUM_USED_MAX_CLR (1 << 1)
#define HAL_MT_KG_IPL_PIPE_CFG_GLOBAL_DATA_BUF_NUM_USED_MAX_CLR  (1 << 2)
#define HAL_MT_KG_IPL_PIPE_CFG_GLOBAL_PORT_XOFF_LOCK_CLR         (1 << 3)
#define HAL_MT_KG_IPL_PIPE_CFG_GLOBAL_SHARE_TRUNC_ENABLE         (1 << 4)
#define HAL_MT_KG_IPL_PIPE_CFG_GLOBAL_CPU_LE_SWAP_EN             (1 << 5)
#define HAL_MT_KG_IPL_PIPE_CFG_GLOBAL_CPU_PROTECT_DISABLE        (1 << 6)
#define HAL_MT_KG_IPL_PIPE_CFG_GLOBAL_CFG_USE_CXH_TC             (1 << 7)
#define HAL_MT_KG_IPL_PIPE_CFG_GLOBAL_LAST                       (1 << 8)
    uint32 flag;
} hal_mt_kg_port_ipl_pipe_cfg_global_t;

typedef struct hal_mt_kg_port_ipl_bubble_insert_s {
    uint32 bubble_insert_interval;
    uint32 bubble_insert_enable;
    uint32 bubble_insert_mode;

/* Flag definitions for hal_mt_kg_port_ipl_bubble_insert_t */
#define HAL_MT_KG_IPL_BUBBLE_INSERT_INTERVAL (1 << 0)
#define HAL_MT_KG_IPL_BUBBLE_INSERT_ENABLE   (1 << 1)
#define HAL_MT_KG_IPL_BUBBLE_INSERT_MODE     (1 << 2)
#define HAL_MT_KG_IPL_BUBBLE_INSERT_LAST     (1 << 3)
    uint32 flag;
} hal_mt_kg_port_ipl_bubble_insert_t;

typedef struct hal_mt_kg_port_ipl_pst_fbm_mem_init_s {
    uint32 pst_dp0;
    uint32 pst_dp1;

/* Flag definitions for hal_mt_kg_port_ipl_pst_fbm_mem_init_t */
#define HAL_MT_KG_IPL_PST_FBM_MEM_INIT_PST_DP0 (1 << 0)
#define HAL_MT_KG_IPL_PST_FBM_MEM_INIT_PST_DP1 (1 << 1)
#define HAL_MT_KG_IPL_PST_FBM_MEM_INIT_LAST    (1 << 2)
    uint32 flag;
} hal_mt_kg_port_ipl_pst_fbm_mem_init_t;

typedef struct hal_mt_kg_port_ipl_pipe_vlan_etype_s {
    uint32 etype_num;
    uint32 etype_dir;
    uint32 etype_value;
} hal_mt_kg_port_ipl_pipe_vlan_etype_t;

typedef struct hal_mt_kg_port_ipl_dbg_cnt_s {
    uint32 pipe_pkt_in_total_cnt;
    uint32 pipe_eth_port_pkt_in_total_cnt;
    uint32 pipe_port_drop_pkt_cnt;
    uint32 pipe_cpx_port_pkt_in_total_cnt;
    uint32 pipe_cpi_port_pkt_in_total_cnt;
    uint32 pipe_fab_port_pkt_in_total_cnt;

    uint32 dp_pipe_pkt_out_total_cnt;
    uint32 dp_total_pkt_cnt_out;
    uint32 dp_total_byte_cnt_out;
    uint32 dp_sel_port_pkt_cnt_out; // coordinate work with cfg_pst_pkt_cnt_port_sel
    uint32 dp_sel_port_byte_cnt_out;
    uint32 dp_cpx_port_pkt_out_total_cnt;
    uint32 dp_cpi_port_pkt_out_total_cnt;
    uint32 dp_lbm_port_pkt_in_total_cnt;
    uint32 dp_lbm_port_pkt_out_total_cnt;

#define HAL_MT_KG_IPL_DBG_PIPE_PKT_IN_TOTAL_CNT          (1 << 0)
#define HAL_MT_KG_IPL_DBG_PIPE_ETH_PORT_PKT_IN_TOTAL_CNT (1 << 1)
#define HAL_MT_KG_IPL_DBG_PIPE_PORT_DROP_PKT_CNT         (1 << 2)
#define HAL_MT_KG_IPL_DBG_PIPE_CPX_PORT_PKT_IN_TOTAL_CNT (1 << 3)
#define HAL_MT_KG_IPL_DBG_PIPE_CPI_PORT_PKT_IN_TOTAL_CNT (1 << 4)
#define HAL_MT_KG_IPL_DBG_PIPE_FAB_PORT_PKT_IN_TOTAL_CNT (1 << 5)
#define HAL_MT_KG_IPL_DBG_DP_PIPE_PKT_OUT_TOTAL_CNT      (1 << 6)
#define HAL_MT_KG_IPL_DBG_DP_TOTAL_PKT_CNT_OUT           (1 << 7)
#define HAL_MT_KG_IPL_DBG_DP_TOTAL_BYTE_CNT_OUT          (1 << 8)
#define HAL_MT_KG_IPL_DBG_DP_SEL_PORT_PKT_CNT_OUT        (1 << 9)
#define HAL_MT_KG_IPL_DBG_DP_SEL_PORT_BYTE_CNT_OUT       (1 << 10)
#define HAL_MT_KG_IPL_DBG_DP_CPX_PORT_PKT_OUT_TOTAL_CNT  (1 << 11)
#define HAL_MT_KG_IPL_DBG_DP_CPI_PORT_PKT_OUT_TOTAL_CNT  (1 << 12)
#define HAL_MT_KG_IPL_DBG_DP_LBM_PORT_PKT_IN_TOTAL_CNT   (1 << 13)
#define HAL_MT_KG_IPL_DBG_DP_LBM_PORT_PKT_OUT_TOTAL_CNT  (1 << 14)
    uint32 flag;
} hal_mt_kg_port_ipl_dbg_cnt_t;

typedef struct hal_mt_kg_port_ipl_dbg_que_cnt_s {
    uint32 eth_queue_data_remain_cnt[HAL_MT_KG_PL_CHANNEL_NUM][HAL_MT_KG_PL_QUEUE_NUM];
    uint32 eth_queue_fd_remain_cnt[HAL_MT_KG_PL_CHANNEL_NUM][HAL_MT_KG_PL_QUEUE_NUM];
    uint32 eth_queue_data_used_max[HAL_MT_KG_PL_CHANNEL_NUM][HAL_MT_KG_PL_QUEUE_NUM];
    uint32 ipl_pause_hrm_num_used_max[HAL_MT_KG_PL_CHANNEL_NUM];

#define HAL_MT_KG_IPL_DBG_ETH_QUEUE_DATA_REMAIN_CNT  (1 << 0)
#define HAL_MT_KG_IPL_DBG_ETH_QUEUE_FD_REMAIN_CNT    (1 << 1)
#define HAL_MT_KG_IPL_DBG_ETH_QUEUE_DATA_USED_MAX    (1 << 2)
#define HAL_MT_KG_IPL_DBG_IPL_PAUSE_HRM_NUM_USED_MAX (1 << 3)

    uint32 flag;
} hal_mt_kg_port_ipl_dbg_que_cnt_t;

typedef enum hal_mt_kg_port_ipl_pipe_plq_e {
    HAL_MT_KG_IPL_PIPE_PLQ_0 = 0,
    HAL_MT_KG_IPL_PIPE_PLQ_1 = 1,
    HAL_MT_KG_IPL_PIPE_PLQ_LAST = 2,
} hal_mt_kg_port_ipl_pipe_plq_t;

typedef enum hal_mt_kg_port_ipl_pipe_pltc_e {
    HAL_MT_KG_IPL_PIPE_PLTC_0 = 0,
    HAL_MT_KG_IPL_PIPE_PLTC_1 = 1,
    HAL_MT_KG_IPL_PIPE_PLTC_2 = 2,
    HAL_MT_KG_IPL_PIPE_PLTC_3 = 3,
    HAL_MT_KG_IPL_PIPE_PLTC_LAST = 4,
} hal_mt_kg_port_ipl_pipe_pltc_t;

typedef enum hal_mt_kg_port_ipl_drop_rsn_e {
    HAL_MT_KG_IPL_FRM_ERR,
    HAL_MT_KG_IPL_CRC_ERR,          /* frames received with CRC Error */
    HAL_MT_KG_IPL_FRM_LEN_VIO,      /* Frames greater than programmed MaxFrameSize, violation */
    HAL_MT_KG_IPL_JABBER_ERR,       /* frames exceed Jabber size and have CRC Error */
    HAL_MT_KG_IPL_IEEE8023_LEN_ERR, /* frames received with Length Error, payload != length
                                                type */
} hal_mt_kg_port_ipl_drop_rsn_t;

typedef struct hal_mt_kg_port_ipl_pause_th_s {
    uint32 plq1_xon_th;
    uint32 plq1_xoff_th;
} hal_mt_kg_port_ipl_pause_th_t;

typedef struct hal_mt_kg_port_ipl_drop_th_s {
    uint32 pltc0_drop_th;
    uint32 pltc1_drop_th;
    uint32 pltc2_drop_th;
    uint32 pltc3_drop_th;
} hal_mt_kg_port_ipl_drop_th_t;

typedef struct hal_mt_kg_port_ipl_trunc_th_s {
    uint32 pltc0_trunc_th;
    uint32 pltc1_trunc_th;
    uint32 pltc2_trunc_th;
    uint32 pltc3_trunc_th;
} hal_mt_kg_port_ipl_trunc_th_t;

typedef struct hal_mt_kg_port_ipl_min_size_s {
    uint32 plq0_min_size;
    uint32 plq1_min_size;
} hal_mt_kg_port_ipl_min_size_t;

typedef struct hal_mt_kg_port_ipl_pipe_data_th_s {
    hal_mt_kg_port_ipl_pause_th_t pause_th;
    hal_mt_kg_port_ipl_drop_th_t drop_th;
    hal_mt_kg_port_ipl_trunc_th_t trunc_th;
    hal_mt_kg_port_ipl_min_size_t min_size;
} hal_mt_kg_port_ipl_pipe_data_th_t;

typedef struct hal_mt_kg_port_ipl_pipe_share_fifo_s {
    uint32 plq0_start_addr;
    uint32 plq0_size;
    uint32 plq1_start_addr;
    uint32 plq1_size;
} hal_mt_kg_port_ipl_pipe_share_fifo_t;

typedef struct hal_mt_kg_port_ipl_pipe_fd_buf_s {
    hal_mt_kg_port_ipl_pipe_data_th_t data_th;
    hal_mt_kg_port_ipl_pipe_share_fifo_t share_fifo;
} hal_mt_kg_port_ipl_pipe_fd_buf_t;
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief IPL init for port.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Device port number.
 * @param [in]    speed    - Device speed.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_init(const uint32 unit, const uint32 port, const clx_port_speed_t speed);

/**
 * @brief IPL deinit for port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Device port number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_deinit(const uint32 unit, const uint32 port);

/**
 * @brief IPL chip soft reset.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    state    - State.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_chip_soft_reset(uint32 unit, uint32 state);

/**
 * @brief IPL chip mem init.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_chip_mem_init(uint32 unit);

#if 0
/**
 * @brief IPL bubble config.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_bubble_set(uint32 unit);
#endif
/**
 * @brief IPL plane init.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_plane_init(uint32 unit);

/**
 * @brief IPL buffer empty check.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Device port number.
 * @return        CLX_E_OK         - Operate success.
 * @return        CLX_E_TIMEOUT    - Timeout.
 * @return        CLX_E_OTHERS     - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_buf_empty_check(const uint32 unit, const uint32 port);

/**
 * @brief IPL admin state config.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Device port number.
 * @param [in]    enable    - Enable.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_admin_state_cfg(const uint32 unit, const uint32 port, uint32 enable);

/**
 * @brief IPL pipe fd buffer get.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Device port number.
 * @param [out]    fd_buffer    - Fd buffer.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_pipe_fd_buf_cfg_get(uint32 unit,
                                       uint32 port,
                                       hal_mt_kg_port_ipl_pipe_fd_buf_t *fd_buffer);

/**
 * @brief IPL port speed config, include speed set and buffer config.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Device port number.
 * @param [in]    speed    - Speed.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_speed_set(const uint32 unit, const uint32 port, const clx_port_speed_t speed);

/**
 * @brief IPL rsn mask config.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Device port number.
 * @param [in]    reason     - Drop reason.
 * @param [in]    mask_en    - Mask enable.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_rsn_mask_set(const uint32 unit,
                                const uint32 port,
                                const uint32 reason,
                                const boolean mask_en);

clx_error_no_t
hal_mt_kg_port_ipl_rsn_mask_get(const uint32 unit,
                                const uint32 port,
                                const uint32 reason,
                                boolean *mask_en);

/**
 * @brief IPL fabric set.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    port         - Device port number.
 * @param [in]    fabric_en    - Fabric enable.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_fabric_mode_set(uint32 unit, uint32 port, uint32 fabric_en);

/**
 * @brief IPL fabric get.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Device port number.
 * @param [out]    fabric_en    - Fabric enable.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_fabric_mode_get(uint32 unit, uint32 port, uint32 *fabric_en);

/**
 * @brief This API is used to get the register list for ipl.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [in]     reg_info    - Register info.
 * @param [out]    reg_info    - Register info.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_port_ipl_dbg_reg_list_get(const uint32 unit, const uint32 port, uint32 *reg_info);

/**
 * @brief IPL q2tc map get.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Device port number.
 * @param [in]    q2tc_map    - Q2TC map.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_q2tc_map_get(uint32 unit, uint32 port, uint32 *q2tc_map);

/**
 * @brief IPL q2tc map cfg.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Device port number.
 * @param [in]    q2tc_map    - Q2TC map.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_q2tc_map_set(uint32 unit, uint32 port, uint32 *q2tc_map);

/**
 * @brief IPL tc2q map cfg.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Device port number.
 * @param [in]    tc2q_map    - TC2Q map.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_tc2q_map_set(uint32 unit, uint32 port, uint32 *tc2q_map);

/**
 * @brief Get IPL tc2q map.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Device port number.
 * @param [in]    tc2q_map    - TC2Q map.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_tc2q_map_get(uint32 unit, uint32 port, uint32 *tc2q_map);

/**
 * @brief IPL dscp pltc map get.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Device port number.
 * @param [in]    dscp            - Dscp.
 * @param [in]    ptr_loss_idx    - Loss index.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_dscp_plct_map_get(uint32 unit, uint32 port, uint32 dscp, uint32 *ptr_loss_idx);

/**
 * @brief IPL dscp pltc map cfg.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Device port number.
 * @param [in]    dscp            - Dscp.
 * @param [in]    ptr_loss_idx    - Loss index.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_dscp_plct_map_set(uint32 unit, uint32 port, uint32 dscp, uint32 ptr_loss_idx);

/**
 * @brief IPL vlan pltc map get.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Device port number.
 * @param [in]    pcp             - Dscp.
 * @param [in]    dei             - DEI.
 * @param [in]    ptr_loss_idx    - Loss index.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_vlan_pltc_map_get(uint32 unit,
                                     uint32 port,
                                     uint32 pcp,
                                     uint32 dei,
                                     uint32 *ptr_loss_idx);

/**
 * @brief Vlan pltc map cfg.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Device port number.
 * @param [in]    pcp             - Dscp.
 * @param [in]    dei             - DEI.
 * @param [in]    ptr_loss_idx    - Loss index.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_vlan_plct_map_set(uint32 unit,
                                     uint32 port,
                                     uint32 pcp,
                                     uint32 dei,
                                     uint32 ptr_loss_idx);

/**
 * @brief IPL exp pltc map get.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Device port number.
 * @param [in]    exp             - Exp.
 * @param [in]    ptr_loss_idx    - Loss index.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_exp_pltc_map_get(uint32 unit, uint32 port, uint32 exp, uint32 *ptr_loss_idx);

/**
 * @brief Exp pltc map cfg.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Device port number.
 * @param [in]    exp             - Exp.
 * @param [in]    ptr_loss_idx    - Loss index.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_exp_plct_map_set(uint32 unit, uint32 port, uint32 exp, uint32 ptr_loss_idx);

/**
 * @brief IPL debug counter get.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Device port number.
 * @param [out]    dbg_cnt    - Debug counter.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_dbg_cnt_get(uint32 unit, uint32 port, hal_mt_kg_port_ipl_dbg_cnt_t *dbg_cnt);

/**
 * @brief Get bac2ipl xoff count.
 *
 * @param [in]    unit                - Device unit number.
 * @param [in]    port                - Device port number.
 * @param [in]    bac2ipl_xoff_cnt    - Bac2ipl xoff count.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_bac2ipl_xoff_cnt_get(uint32 unit, uint32 port, uint32 *bac2ipl_xoff_cnt);

/**
 * @brief Get asm2ipl unrdy count.
 *
 * @param [in]    unit                 - Device unit number.
 * @param [in]    port                 - Device port number.
 * @param [in]    asm2ipl_unrdy_cnt    - Asm2ipl unrdy count.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_asm2ipl_unrdy_cnt_get(uint32 unit, uint32 port, uint32 *asm2ipl_unrdy_cnt);

/**
 * @brief Get ipl2umac xoff status.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    port             - Device port number.
 * @param [in]    ipl2umac_xoff    - Ipl2umac xoff status.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_ipl2umac_xoff_get(uint32 unit, uint32 port, uint32 *ipl2umac_xoff);

/**
 * @brief Get fast tm pfc status.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port           - Device port number.
 * @param [in]    fast_tm_pfc    - Fast tm pfc status.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_fast_tm_pfc_get(uint32 unit, uint32 port, uint32 *fast_tm_pfc);
/**
 * @brief IPL port fc mode config.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Device port number.
 * @param [in]    fc_mode    - Fc mode.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_fc_mode_set(uint32 unit, uint32 port, uint32 fc_mode);

/**
 * @brief IPL port fc mode get.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Device port number.
 * @param [out]    ptr_mode    - FC mode.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_fc_mode_get(uint32 unit, uint32 port, uint32 *ptr_mode);

/**
 * @brief IPL debug counter get.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Device port number.
 * @param [out]    dbg_cnt    - Debug counter.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_kg_port_ipl_dbg_que_cnt_get(uint32 unit,
                                   uint32 port,
                                   hal_mt_kg_port_ipl_dbg_que_cnt_t *dbg_cnt);

#endif /* __HAL_MT_KG_PORT_IPL_H__ */