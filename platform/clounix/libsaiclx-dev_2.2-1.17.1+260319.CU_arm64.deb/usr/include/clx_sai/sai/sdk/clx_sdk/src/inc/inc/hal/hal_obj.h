/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_obj.h
 * PURPOSE:
 *  1. Provide object API.
 * NOTES:
 */

#ifndef HAL_OBJ_H
#define HAL_OBJ_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_cfg.h>
#include <hal/hal.h>
#include <tob/tob_tbl.h>
#include <hal/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */

/*
 *    VM_ETAG       : bit31(1):1, bit11-bit30(20):ecid, bit0-bit10(11):di
 *    VM VNTAG/VEPA : bit31(1):0, bit26-bit30(5):type, bit11-bit25(15):vm_vif, bit0-bit10(11):di
 *    Others        : bit31(1):0, bit26-bit30(5):type, bit16-bit25(10):rsv, bit0-bit15(16):di
 *
 *             1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
 *            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * VM_ETAG    |1|            ecid                       |         di          |
 *            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 *            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * VNTAG/VEPA |0|  type   |        vif                  |         di          |
 *            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 *            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * Others     |0|  type   |      reserve      |             di                |
 *            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 */

#define HAL_OBJ_DI_SHIFT           (0)
#define HAL_OBJ_TYPE_SHIFT         (26)
#define HAL_OBJ_NORMAL_DI_BITS     (16)
#define HAL_OBJ_TYPE_BITS          (5)
#define HAL_OBJ_VM_ECID_BITS       (20)
#define HAL_OBJ_VM_ECID_SHIFT      (11)
#define HAL_OBJ_VM_VIF_BITS        (15)
#define HAL_OBJ_VM_VIF_SHIFT       (11)
#define HAL_OBJ_VM_DI_BITS         (11)
#define HAL_OBJ_VM_ETAG_TYPE_BITS  (1)
#define HAL_OBJ_VM_ETAG_TYPE_SHIFT (31)

#define HAL_OBJ_PHY_PORT_MIN (0)
#define HAL_OBJ_PHY_PORT_MAX (1535)
#define HAL_OBJ_LAG_BASE_ID  (1536)
#define HAL_OBJ_LAG_MIN      (0)
#define HAL_OBJ_LAG_MAX      (511)

#define HAL_OBJ_SET(__intf__, __shift__, __bit__, __id__) \
    ((__intf__) |= (((__id__) & ((1U << (__bit__)) - 1)) << (__shift__)))
#define HAL_OBJ_GET(__intf__, __shift__, __bit__, __id__) \
    ((__id__) = (((__intf__) >> (__shift__)) & ((1U << (__bit__)) - 1)))

#define HAL_OBJ_VM_ETAG_CHK(__intf__) (((__intf__) >> HAL_OBJ_VM_ETAG_TYPE_SHIFT) != 0)

#define HAL_OBJ_VM_DI_GET(__intf__, __id__)                                  \
    do {                                                                     \
        HAL_OBJ_GET(__intf__, HAL_OBJ_DI_SHIFT, HAL_OBJ_VM_DI_BITS, __id__); \
        if ((__id__) >= HAL_OBJ_LAG_BASE_ID) {                               \
            (__id__) += (HAL_LAG_BASE_ID_DFT - HAL_OBJ_LAG_BASE_ID);         \
        }                                                                    \
    } while (0)

#define HAL_OBJ_VM_ETAG_TYPE_SET(__intf__, __id__) \
    HAL_OBJ_SET(__intf__, HAL_OBJ_VM_ETAG_TYPE_SHIFT, HAL_OBJ_VM_ETAG_TYPE_BITS, __id__)
#define HAL_OBJ_VM_ETAG_SET(__intf__, __id__) \
    HAL_OBJ_SET(__intf__, HAL_OBJ_VM_ECID_SHIFT, HAL_OBJ_VM_ECID_BITS, __id__)
#define HAL_OBJ_VM_VNTAG_SET(__intf__, __id__) \
    HAL_OBJ_SET(__intf__, HAL_OBJ_VM_VIF_SHIFT, HAL_OBJ_VM_VIF_BITS, __id__)
#define HAL_OBJ_VM_DI_SET(__intf__, __id__)                                       \
    do {                                                                          \
        uint32 __sw_di__ = (__id__);                                              \
        if ((__id__) >= HAL_LAG_BASE_ID_DFT) {                                    \
            __sw_di__ -= (HAL_LAG_BASE_ID_DFT - HAL_OBJ_LAG_BASE_ID);             \
        }                                                                         \
        HAL_OBJ_SET((__intf__), HAL_OBJ_DI_SHIFT, HAL_OBJ_VM_DI_BITS, __sw_di__); \
    } while (0)

#define HAL_OBJ_TYPE_SET(__intf__, __id__) \
    HAL_OBJ_SET(__intf__, HAL_OBJ_TYPE_SHIFT, HAL_OBJ_TYPE_BITS, __id__)
#define HAL_OBJ_DI_SET(__intf__, __id__) \
    HAL_OBJ_SET(__intf__, HAL_OBJ_DI_SHIFT, HAL_OBJ_NORMAL_DI_BITS, __id__)
#define HAL_OBJ_TYPE_GET(__intf__, __id__)  \
    HAL_OBJ_VM_ETAG_CHK(__intf__) ?         \
        (__id__ = CLX_GPORT_TYPE_VM_ETAG) : \
        HAL_OBJ_GET(__intf__, HAL_OBJ_TYPE_SHIFT, HAL_OBJ_TYPE_BITS, __id__)
#define HAL_OBJ_DI_GET(__intf__, __id__)                                                     \
    do {                                                                                     \
        uint32 __type__;                                                                     \
        HAL_OBJ_TYPE_GET(__intf__, __type__);                                                \
        if ((CLX_GPORT_TYPE_VM_ETAG == __type__) || (CLX_GPORT_TYPE_VM_VNTAG == __type__)) { \
            HAL_OBJ_VM_DI_GET(__intf__, __id__);                                             \
        } else {                                                                             \
            HAL_OBJ_GET(__intf__, HAL_OBJ_DI_SHIFT, HAL_OBJ_NORMAL_DI_BITS, __id__);         \
        }                                                                                    \
    } while (0)
#define HAL_OBJ_CHK(__intf__) (((__intf__) >> HAL_OBJ_TYPE_SHIFT) != 0)

#define HAL_OBJ_VM_ECID_GET(__intf__, __id__) \
    (__id__ = (((__intf__) >> HAL_OBJ_VM_ECID_SHIFT) & ((1U << HAL_OBJ_VM_ECID_BITS) - 1)))
#define HAL_OBJ_VM_VIF_GET(__intf__, __id__) \
    (__id__ = (((__intf__) >> HAL_OBJ_VM_VIF_SHIFT) & ((1U << HAL_OBJ_VM_VIF_BITS) - 1)))

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief This function is responsible for create port.
 *
 * @param [in]     unit        - The unit number.
 * @param [in]     ptr_info    - The info to create port.
 * @param [out]    ptr_port    - Return created port.
 * @return         CLX_E_OK        - Successful.
 * @return         CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_obj_port_create(const uint32 unit, const hal_intf_obj_info_t *ptr_info, clx_port_t *ptr_port);

/**
 * @brief This function is responsible for destroy created port.
 *
 * @param [in]    unit    - The unit number.
 * @param [in]    port    - The created port.
 * @return        CLX_E_OK        - Successful.
 * @return        CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_obj_port_destroy(const uint32 unit, const clx_port_t port);

/**
 * @brief This function is responsible for get created port.
 *
 * @param [in]     unit        - The unit number.
 * @param [in]     ptr_info    - The info of created port.
 * @param [out]    ptr_port    - Return created port.
 * @return         CLX_E_OK        - Successful.
 * @return         CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_obj_port_get(const uint32 unit, const hal_intf_obj_info_t *ptr_info, clx_port_t *ptr_port);

/**
 * @brief This function is responsible for get created port info.
 *
 * @param [in]     unit        - The unit number.
 * @param [in]     port        - The created port.
 * @param [out]    ptr_info    - Return created port info.
 * @return         CLX_E_OK        - Successful.
 * @return         CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_obj_port_info_get(const uint32 unit, const clx_port_t port, hal_intf_obj_info_t *ptr_info);

/**
 * @brief This function is responsible for validate created port.
 *
 * @param [in]    unit    - The unit number.
 * @param [in]    port    - The created port.
 * @return        CLX_E_OK        - Successful.
 * @return        CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_obj_port_validate(const uint32 unit, const clx_port_t port);

/**
 * @brief This function is responsible for local interface.
 *
 * @param [in]     unit            - The unit number.
 * @param [in]     port            - The created port.
 * @param [out]    ptr_lcl_intf    - Local interface.
 * @return         CLX_E_OK        - Successful.
 * @return         CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_obj_lcl_intf_get(const uint32 unit, const clx_port_t port, uint32 *ptr_lcl_intf);

#endif /* #ifndef HAL_OBJ_H */
