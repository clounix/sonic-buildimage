/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_PKT_RX_H__)
#define __CLX_SAI_PKT_RX_H__


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_PKT_MAC_LEN_BYTE                     (6)
#define CLXS_PKT_VXLAN_LEN_WORD                   (2)
#define CLXS_PKT_IPV4_LEN_WORD                    (5)
#define CLXS_PKT_IPV6_LEN_WORD                    (10)
#define CLXS_PKT_ETHERTYPE_IPV4  0x0800
#define CLXS_PKT_ETHERTYPE_IPV6  0x86dd
#define SAI_PACKET_ACTION_MAX           9

#define SAI_FWD_ACTION_TO_CLXS(__action__)     ext_sai_action_to_clx_map[__action__]
#define CLXS_FWD_ACTION_TO_SAI(__action__)     ext_clx_action_to_sai_map[__action__]
#define CLXS_PKT_PORT_INDEX_TO_PHYPORT(__port__)        ((__port__ & 0x000000ff))


/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/


/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const clx_fwd_action_t           ext_sai_action_to_clx_map[SAI_PACKET_ACTION_MAX];
extern const sai_packet_action_t        ext_clx_action_to_sai_map[CLX_FWD_ACTION_LAST];


/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t
clxs_pkt_rx_register_callback(
    _In_ const uint32_t         unit,
    _In_ void                   *ptr_func);

clx_error_no_t
clxs_pkt_rx_free_buf(
    const void                  *ptr_buf);
sai_status_t
clxs_pkt_rx_init(
    _In_ const uint32_t         unit);

sai_status_t
clxs_pkt_rx_deinit(
    _In_ const uint32_t         unit);
#endif
