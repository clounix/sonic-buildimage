/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_cia.h
 * PURPOSE:
 *    Provide HAL driver API functions for CL8570.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NB_CIA_H
#define HAL_MT_NB_CIA_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_cia.h>
#include <hal/hal_cia.h>
#include <hal/hal_l2.h>
#include <hal/hal_l3.h>
#include <hal/hal_mpls.h>
#include <tob/mt/tob_mt.h>
/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_NB_CIA_UDF_INT_KEY_VLD_BMP_EXACT                                          \
    (CLX_CIA_UDF_INTERNAL_KEY_L2_SA_GRP_LBL | CLX_CIA_UDF_INTERNAL_KEY_L2_DA_GRP_LBL |   \
     CLX_CIA_UDF_INTERNAL_KEY_L3_SA_GRP_LBL | CLX_CIA_UDF_INTERNAL_KEY_L3_DA_GRP_LBL |   \
     CLX_CIA_UDF_INTERNAL_KEY_INTF_GRP_LBL | CLX_CIA_UDF_INTERNAL_KEY_RANGE |            \
     CLX_CIA_UDF_INTERNAL_KEY_BDID | CLX_CIA_UDF_INTERNAL_KEY_VRF |                      \
     CLX_CIA_UDF_INTERNAL_KEY_TCP_FLAGS | CLX_CIA_UDF_INTERNAL_KEY_STAG_VID |            \
     CLX_CIA_UDF_INTERNAL_KEY_CTAG_VID | CLX_CIA_UDF_INTERNAL_KEY_STAG_PCP_DEI |         \
     CLX_CIA_UDF_INTERNAL_KEY_CTAG_PCP_DEI | CLX_CIA_UDF_INTERNAL_KEY_VLAN_TAG_MODE_1Q | \
     CLX_CIA_UDF_INTERNAL_KEY_L3_ROUTE)
#define HAL_MT_NB_CIA_UDF_INT_KEY_VLD_BMP_IGR                                            \
    (CLX_CIA_UDF_INTERNAL_KEY_INTF_GRP_LBL | CLX_CIA_UDF_INTERNAL_KEY_RANGE |            \
     CLX_CIA_UDF_INTERNAL_KEY_BDID | CLX_CIA_UDF_INTERNAL_KEY_VRF |                      \
     CLX_CIA_UDF_INTERNAL_KEY_TCP_FLAGS | CLX_CIA_UDF_INTERNAL_KEY_STAG_VID |            \
     CLX_CIA_UDF_INTERNAL_KEY_CTAG_VID | CLX_CIA_UDF_INTERNAL_KEY_STAG_PCP_DEI |         \
     CLX_CIA_UDF_INTERNAL_KEY_CTAG_PCP_DEI | CLX_CIA_UDF_INTERNAL_KEY_VLAN_TAG_MODE_1Q | \
     CLX_CIA_UDF_INTERNAL_KEY_L3_ROUTE | CLX_CIA_UDF_INTERNAL_KEY_PORT_BMP)
#define HAL_MT_NB_CIA_UDF_INT_KEY_VLD_BMP_EGR                                 \
    (CLX_CIA_UDF_INTERNAL_KEY_RANGE | CLX_CIA_UDF_INTERNAL_KEY_BDID |         \
     CLX_CIA_UDF_INTERNAL_KEY_TCP_FLAGS | CLX_CIA_UDF_INTERNAL_KEY_L3_ROUTE | \
     CLX_CIA_UDF_INTERNAL_KEY_IGR_CIA_GRP_LBL)

#define HAL_MT_NB_CIA_UDF_0_PKG_TLV_BASE_ID (0)
#define HAL_MT_NB_CIA_ACTION_FLAGS_IGR                                                          \
    (CLX_CIA_ACT_FLAGS_METER_VLD | CLX_CIA_ACT_FLAGS_COUNTER_VLD |                              \
     CLX_CIA_ACT_FLAGS_DIST_COUNTER_VLD | CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_BLIND |               \
     CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_RED | CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_YELLOW |             \
     CLX_CIA_ACT_FLAGS_CANCEL_LEARN | CLX_CIA_ACT_FLAGS_COPY_TO_CPU | CLX_CIA_ACT_FLAGS_REDIR | \
     CLX_CIA_ACT_FLAGS_DROP | CLX_CIA_ACT_FLAGS_PKT_FCM | CLX_CIA_ACT_FLAGS_KEEP_TTL |          \
     CLX_CIA_ACT_FLAGS_TELM_ACT_VLD | CLX_CIA_ACT_FLAGS_XOR_LFSR |                              \
     CLX_CIA_ACT_FLAGS_ALLOW_TRUNCATE | CLX_CIA_ACT_FLAGS_FORCE_DECAP |                         \
     CLX_CIA_ACT_FLAGS_MIR_POLICER_VLD | CLX_CIA_ACT_FLAGS_BYPASS_TTL_CHECK_FAIL |              \
     CLX_CIA_ACT_FLAGS_BYPASS_RPF_CHECK_FAIL | CLX_CIA_ACT_FLAGS_VID_ACT_VLD |                  \
     CLX_CIA_ACT_FLAGS_UDF_RSN_VLD)

#define HAL_MT_NB_CIA_ACTION_FLAGS_EGR                                                            \
    (CLX_CIA_ACT_FLAGS_METER_VLD | CLX_CIA_ACT_FLAGS_COUNTER_VLD |                                \
     CLX_CIA_ACT_FLAGS_DIST_COUNTER_VLD | CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_BLIND |                 \
     CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_RED | CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_YELLOW |               \
     CLX_CIA_ACT_FLAGS_COPY_TO_CPU | CLX_CIA_ACT_FLAGS_DROP | CLX_CIA_ACT_FLAGS_MIR_POLICER_VLD | \
     CLX_CIA_ACT_FLAGS_UDF_RSN_VLD)

#define HAL_MT_NB_CIA_EXACT_FLAGS                                                                \
    (CLX_CIA_EXACT_GRP_PROF_FLAGS_EXACT_IGNORE_MSK | CLX_CIA_EXACT_GRP_PROF_FLAGS_EXACT_DA_LBL | \
     CLX_CIA_EXACT_GRP_PROF_FLAGS_EXACT_SA_LBL |                                                 \
     CLX_CIA_EXACT_GRP_PROF_FLAGS_EXACT_IGNORE_MSK_WITH_TILE)

#define HAL_MT_NB_CIA_UDF_PROF_NUM                     (64)
#define HAL_MT_NB_CIA_IGR_CIA_GROUP_LABEL_LSB_VLD_BITS (16)
#define HAL_MT_NB_CIA_REWR_PAGE_NUM                    (32)
#define HAL_MT_NB_CIA_IGR_UCP_DEFAULT_NUM              (24)
#define HAL_MT_NB_CIA_EGR_UCP_DEFAULT_NUM              (8)
#define HAL_MT_NB_CIA_EGR_UCP_16K_NUM                  (32)
#define HAL_MT_NB_CIA_EGR_UCP_12K_NUM                  (24)
#define HAL_MT_NB_CIA_EGR_UCP_8K_NUM                   (16)
#define HAL_MT_NB_CIA_EGR_UCP_0K_NUM                   (0)
#define HAL_MT_NB_CIA_IGR_UCP_16K_NUM                  (32)
#define HAL_MT_NB_CIA_IGR_UCP_8K_NUM                   (16)
#define HAL_MT_NB_CIA_IGR_UCP_4K_NUM                   (8)
#define HAL_MT_NB_CIA_IGR_UCP_0K_NUM                   (0)
#define HAL_MT_NB_CIA_IGR_UCP_NUM                      (24)
#define HAL_MT_NB_CIA_EGR_UCP_NUM                      (8)
#define HAL_MT_NB_CIA_UDF_KEY_BITS                     (200)
#define HAL_MT_NB_CIA_IGR_POST_UCP_NUM                 (HAL_MT_NB_CIA_IGR_UCP_NUM)
#define HAL_MT_NB_CIA_EGR_POST_UCP_NUM                 (HAL_MT_NB_CIA_EGR_UCP_NUM)
#define HAL_MT_NB_CIA_EXACT_UCP_NUM                    (24)
#define HAL_MT_NB_CIA_IGR_GROUP_NUM                    (12)
#define HAL_MT_NB_CIA_EGR_GROUP_NUM                    (4)
#define HAL_MT_NB_CIA_IGR_POST_GROUP_NUM               (HAL_MT_NB_CIA_IGR_GROUP_NUM)
#define HAL_MT_NB_CIA_EGR_POST_GROUP_NUM               (HAL_MT_NB_CIA_EGR_GROUP_NUM)
#define HAL_MT_NB_CIA_EXACT_GROUP_NUM                  (24)
#define HAL_MT_NB_CIA_UCP_ENTRY_NUM                    (512)
#define HAL_MT_NB_CIA_UCP_ENTRY_BITS                   (9)
#define HAL_MT_NB_CIA_IGR_ENTRY_NUM                    (HAL_MT_NB_CIA_IGR_UCP_NUM * HAL_MT_NB_CIA_UCP_ENTRY_NUM)
#define HAL_MT_NB_CIA_EGR_ENTRY_NUM                    (HAL_MT_NB_CIA_EGR_UCP_NUM * HAL_MT_NB_CIA_UCP_ENTRY_NUM)
#define HAL_MT_NB_CIA_BASEKEY_L3_WORDS_MAX             (HAL_MT_CIA_KEY_1X_WORDS * 2)
#define HAL_MT_NB_CIA_BASEKEY_WORDS_MAX                (HAL_MT_CIA_KEY_1X_WORDS * 3)
#define HAL_MT_NB_CIA_ACTION_QOS_PROF_PCP_DEI_VLD      (1U << 0)
#define HAL_MT_NB_CIA_ACTION_QOS_PROF_EXP_VLD          (1U << 1)
#define HAL_MT_NB_CIA_ACTION_QOS_PROF_DSCP_VLD         (1U << 2)
#define HAL_MT_NB_CIA_ACTION_FCM_INST_MAX              (6)
#define HAL_MT_NB_CIA_ACTION_TEML_IOAM_DELAY_BIT       (2)
#define HAL_MT_NB_CIA_ACTION_TEML_IOAM_ENABLE_BIT      (1)
#define HAL_MT_NB_CIA_ACTION_FWD_MSK_SRC_PRUNE         (0x03)
#define HAL_MT_NB_CIA_ACTION_FWD_MSK_TTL               (0x1C)
#define HAL_MT_NB_CIA_ACTION_FWD_MSK_RPF               (0x3E0)
#define HAL_MT_NB_CIA_FCM_TLV_BIDX_MAX                 (62)
#define HAL_MT_NB_CIA_MISC_ACTION_CHECK_FLAGS                           \
    (CLX_CIA_ACT_FLAGS_XOR_LFSR | CLX_CIA_ACT_FLAGS_VID_ACT_VLD |       \
     CLX_CIA_ACT_FLAGS_ALLOW_TRUNCATE | CLX_CIA_ACT_FLAGS_FORCE_DECAP | \
     CLX_CIA_ACT_FLAGS_CANCEL_LEARN | CLX_CIA_ACT_FLAGS_KEEP_TTL)

#define HAL_MT_NB_CIA_RSN_ACTION_CHECK_FLAGS \
    (CLX_CIA_ACT_FLAGS_COPY_TO_CPU | CLX_CIA_ACT_FLAGS_UDF_RSN_VLD)

#define HAL_MT_NB_CIA_LOG_ACTION_CHECK_FLAGS                            \
    (CLX_CIA_ACT_FLAGS_DROP | CLX_CIA_ACT_FLAGS_BYPASS_TTL_CHECK_FAIL | \
     CLX_CIA_ACT_FLAGS_BYPASS_RPF_CHECK_FAIL)

#define HAL_MT_NB_CIA_SFLW_ACTION_CHECK_FLAGS \
    (CLX_SAMPLE_FLAGS_SAMPLE_TO_MIR | CLX_SAMPLE_FLAGS_EGR_SAMPLE_HIGH_LATENCY)

#define HAL_MT_NB_CIA_DST_CNT_ACTION_CHECK_FLAGS (CLX_CIA_ACT_FLAGS_DIST_COUNTER_VLD)
#define HAL_MT_NB_CIA_SRV_CNT_ACTION_CHECK_FLAGS (CLX_CIA_ACT_FLAGS_COUNTER_VLD)
#define HAL_MT_NB_CIA_MARK_ACTION_CHECK_FLAGS    (CLX_CIA_ACT_FLAGS_METER_VLD)
#define HAL_MT_NB_CIA_POLICER_ACTION_CHECK_FLAGS (CLX_CIA_ACT_FLAGS_MIR_POLICER_VLD)
#define HAL_MT_NB_CIA_QOS_ACTION_CHECK_FLAGS     (CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_BLIND)
#define HAL_MT_NB_CIA_QOS2_ACTION_CHECK_FLAGS \
    (CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_YELLOW | CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_RED)
#define HAL_MT_NB_CIA_PBR_ACTION_CHECK_FLAGS           (CLX_CIA_ACT_FLAGS_REDIR)
#define HAL_MT_NB_CIA_TELM_ACTION_CHECK_FLAGS          (CLX_CIA_ACT_FLAGS_TELM_ACT_VLD)
#define HAL_MT_NB_CIA_IGR_CIA_LABEL_ACTION_CHECK_FLAGS (CLX_CIA_ACT_FLAGS_PKT_FCM)

#define HAL_MT_NB_CIA_IGR_POST_ENTRY_NUM \
    (HAL_MT_NB_CIA_IGR_POST_UCP_NUM * HAL_MT_NB_CIA_UCP_ENTRY_NUM)
#define HAL_MT_NB_CIA_EGR_POST_ENTRY_NUM \
    (HAL_MT_NB_CIA_EGR_POST_UCP_NUM * HAL_MT_NB_CIA_UCP_ENTRY_NUM)
#define HAL_MT_NB_CIA_FPU_1_LEVEL_START  (HAL_EXACT_BMP_LEVEL_MAX / 2)
#define HAL_MT_NB_CIA_FPU_1_GROUP_OFFSET (HAL_CIA_EXACT_GRP_NUM_MAX / 2)
#define HAL_MT_NB_CIA_TBL_ENTRY_GET(__unit__, __entry_1x_id__, __stage__, __tbl_entry_id__)       \
    do {                                                                                          \
        uint32 ucp_num = 0;                                                                       \
        if ((CLX_CIA_STAGE_IGR == __stage__) || (CLX_CIA_STAGE_IGR_POST == __stage__)) {          \
            __tbl_entry_id__ = __entry_1x_id__;                                                   \
        } else if (CLX_CIA_STAGE_EGR == __stage__) {                                              \
            hal_mt_cia_ucp_num_get(unit, CLX_CIA_STAGE_IGR, &ucp_num);                            \
            __tbl_entry_id__ =                                                                    \
                (__entry_1x_id__ + (ucp_num * PTR_HAL_CONST_INFO(__unit__, cia)->ucp_entry_num)); \
        } else if (CLX_CIA_STAGE_EGR_POST == __stage__) {                                         \
            hal_mt_cia_ucp_num_get(unit, CLX_CIA_STAGE_IGR_POST, &ucp_num);                       \
            __tbl_entry_id__ =                                                                    \
                (__entry_1x_id__ + (ucp_num * PTR_HAL_CONST_INFO(__unit__, cia)->ucp_entry_num)); \
        } else {                                                                                  \
            __tbl_entry_id__ = HAL_INVALID_ID;                                                    \
        }                                                                                         \
    } while (0)
/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MT_NB_CIA_SET_HASH_INST_TO_HASH_ENTRY(__fpu_inst__, __hash_entry__)       \
    do {                                                                              \
        if (HAL_IS_DEV_NB_RESOURCE_DOUBLE_FAMILY(unit)) {                             \
            if ((__fpu_inst__) == TOB_ODD_INST_IDX_BCAST) {                           \
                (__hash_entry__) = (__hash_entry__) | (1 << TOB_MT_HASH_INST_OFFSET); \
            }                                                                         \
        }                                                                             \
    } while (0)

#define HAL_MT_NB_CIA_CLEAR_HASH_INST_TO_HASH_ENTRY(__fpu_inst__, __hash_entry__)           \
    do {                                                                                    \
        if (HAL_IS_DEV_NB_RESOURCE_DOUBLE_FAMILY(unit)) {                                   \
            if ((__fpu_inst__) == TOB_ODD_INST_IDX_BCAST) {                                 \
                (__hash_entry__) = (__hash_entry__) & ((1 << TOB_MT_HASH_INST_OFFSET) - 1); \
            }                                                                               \
        }                                                                                   \
    } while (0)

/* DATA TYPE DECLARATIONS
 */

typedef struct hal_mt_nb_ciat_rslt_ucp_cfg_fld_s {
    uint32 base_mode_fld;
    uint32 udf_mode_fld;
    uint32 pbm_type_fld;
    uint32 qos_use_tc_fld; /* icia only */
    uint32 l4_port_swap_fld;
    uint32 l3_addr_swap_fld;
    uint32 l2_addr_swap_fld;
    uint32 base_fpu_label_sel_fld; /* icia only */
    uint32 udf_fpu_label_sel_fld;  /* icia only */
} hal_mt_nb_ciat_rslt_ucp_cfg_fld_t;

typedef enum hal_mt_nb_cia_pp_chk_type_e {
    HAL_MT_NB_CIA_PP_CHK_TYPE_MAC = 0,
    HAL_MT_NB_CIA_PP_CHK_TYPE_IPV4 = 1,
    HAL_MT_NB_CIA_PP_CHK_TYPE_IPV6 = 2,
    HAL_MT_NB_CIA_PP_CHK_TYPE_MPLS = 3,
    HAL_MT_NB_CIA_PP_CHK_TYPE_ARP = 4,
    HAL_MT_NB_CIA_PP_CHK_TYPE_LAST = 6,
} hal_mt_nb_cia_pp_chk_type_t;

typedef enum hal_mt_nb_cia_byte_sel_enum_e {
    HAL_MT_NB_CIA_BYTE_SEL_NONE = 0,
    HAL_MT_NB_CIA_BYTE_SEL_HM = 1,
    HAL_MT_NB_CIA_BYTE_SEL_LM = 2,
    HAL_MT_NB_CIA_BYTE_SEL_2B = 3,
} hal_mt_nb_cia_byte_sel_enum_t;

typedef enum hal_mt_nb_cia_pkg_tlv_fld_idx_e {
    HAL_MT_NB_CIA_PKG_TLV_FLD_IGR = 0,
    HAL_MT_NB_CIA_PKG_TLV_FLD_EGR,
    HAL_MT_NB_CIA_PKG_TLV_FLD_EXACT,
    HAL_MT_NB_CIA_PKG_TLV_FLD_LAST
} hal_mt_nb_cia_pkg_tlv_fld_idx_t;

typedef enum hal_mt_nb_cia_act_fcm_op_code_e {
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_DMAC_HI = 0,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_DMAC_LO = 1,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_SMAC_HI = 2,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_SMAC_LO = 3,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_L2_VLAN0 = 4,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_L2_VLAN1 = 5,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_IPV6_DA_3 = 6,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_IPV6_DA_2 = 7,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_IPV6_DA_1 = 8,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_IPV6_DA_0 = 9,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_IPV6_SA_3 = 10,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_IPV6_SA_2 = 11,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_IPV6_SA_1 = 12,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_IPV6_SA_0 = 13,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_IPV4_DIP = 14,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_IPV4_SIP = 15,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_IPV6_TOS = 16,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_IPV4_TOS = 17,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_L4_SPORT = 18,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_L4_DPORT = 19,
    HAL_MT_NB_CIA_ACT_FCM_OP_CODE_LAST
} hal_mt_nb_cia_act_fcm_op_code_t;

typedef struct hal_mt_nb_cia_key_cmn_fld_s {
    uint32 tbl_id;
    uint32 key_wd_fld_t, key_wd_fld_c;
} hal_mt_nb_cia_key_cmn_fld_t;

typedef struct hal_mt_nb_cia_key_arp_fld_s {
    uint32 tbl_id;
    uint32 key_1x_t_fld_t, key_1x_t_fld_c;
    uint32 decap_pass_fld_t, decap_pass_fld_c;
    uint32 use_tc_color_fld_t, use_tc_color_fld_c;
    uint32 src_bd_fld_t, src_bd_fld_c;
    uint32 is_routed_fld_t, is_routed_fld_c;
    uint32 arp_req_fld_t, arp_req_fld_c;
    uint32 arp_res_fld_t, arp_res_fld_c;
    uint32 sha_fld_t, sha_fld_c;
    uint32 tha_fld_t, tha_fld_c;
    uint32 spa_fld_t, spa_fld_c;
    uint32 tc_color_fld_t, tc_color_fld_c;
    uint32 pbm_fld_t, pbm_fld_c;
    uint32 vld_t;
} hal_mt_nb_cia_key_arp_fld_t;
typedef struct hal_mt_nb_cia_key_udf_fld_s {
    uint32 tbl_id;
    uint32 key_1x_t_fld_t, key_1x_t_fld_c;
    uint32 prof_idx_fld_t, prof_idx_fld_c;
    uint32 udfs_fld_t, udfs_fld_c;
    uint32 vld_t;
} hal_mt_nb_cia_key_udf_fld_t;

typedef struct hal_mt_nb_cia_key_mpls_fld_s {
    uint32 tbl_id;
    uint32 key_1x_t_fld_t, key_1x_t_fld_c;
    uint32 decap_pass_fld_t, decap_pass_fld_c;
    uint32 use_tc_color_fld_t, use_tc_color_fld_c;
    uint32 src_bd_fld_t, src_bd_fld_c;
    uint32 lbl0_lbl_fld_t, lbl0_lbl_fld_c;
    uint32 lbl1_lbl_fld_t, lbl1_lbl_fld_c;
    uint32 lbl2_lbl_fld_t, lbl2_lbl_fld_c;
    uint32 lbl3_lbl_fld_t, lbl3_lbl_fld_c;
    uint32 ttl_flg_fld_t, ttl_flg_fld_c;
    uint32 tc_color_fld_t, tc_color_fld_c;
    uint32 pbm_fld_t, pbm_fld_c;
    uint32 vld_t;
} hal_mt_nb_cia_key_mpls_fld_t;

typedef struct hal_mt_nb_cia_key_ipv4_fld_s {
    uint32 tbl_id;
    uint32 key_1x_t_fld_t, key_1x_t_fld_c;
    uint32 decap_pass_fld_t, decap_pass_fld_c;
    uint32 use_tc_color_fld_t, use_tc_color_fld_c;
    uint32 src_bd_fld_t, src_bd_fld_c;
    uint32 is_routed_fld_t, is_routed_fld_c;
    uint32 l2_hdr_present_fld_t, l2_hdr_present_fld_c;
    uint32 l3_ah_present_fld_t, l3_ah_present_fld_c;
    uint32 l3_ipv4_ihl_ne_5_fld_t, l3_ipv4_ihl_ne_5_fld_c;
    uint32 l4_tcp_flg_fld_t, l4_tcp_flg_fld_c;
    uint32 l3_ip_sa_fld_t, l3_ip_sa_fld_c;
    uint32 l3_ip_da_fld_t, l3_ip_da_fld_c;
    uint32 l3_ulp_fld_t, l3_ulp_fld_c;
    uint32 ttl_flg_fld_t, ttl_flg_fld_c;
    uint32 ip_frg_fld_t, ip_frg_fld_c;
    uint32 l4_b01_fld_t, l4_b01_fld_c;
    uint32 l4_b23_fld_t, l4_b23_fld_c;
    uint32 ecn_fld_t, ecn_fld_c;
    uint32 tc_color_fld_t, tc_color_fld_c;
    uint32 pbm_fld_t, pbm_fld_c;
    uint32 vld_t;
} hal_mt_nb_cia_key_ipv4_fld_t;

typedef struct hal_mt_nb_cia_key_mac_fld_s {
    uint32 tbl_id;
    uint32 key_1x_t_fld_t, key_1x_t_fld_c;
    uint32 decap_pass_fld_t, decap_pass_fld_c;
    uint32 use_tc_color_fld_t, use_tc_color_fld_c;
    uint32 src_bd_fld_t, src_bd_fld_c;
    uint32 is_routed_fld_t, is_routed_fld_c;
    uint32 l2_etyp_fld_t, l2_etyp_fld_c;
    uint32 l2_type_fld_t, l2_type_fld_c;
    uint32 l2_vlan_1st_vld_t, l2_vlan_1st_vld_c;
    uint32 l2_vlan_2nd_vld_t, l2_vlan_2nd_vld_c;
    uint32 l2_da_fld_t, l2_da_fld_c;
    uint32 l2_sa_fld_t, l2_sa_fld_c;
    uint32 tc_color_fld_t, tc_color_fld_c;
    uint32 pbm_fld_t, pbm_fld_c;
    uint32 vld_t;
} hal_mt_nb_cia_key_mac_fld_t;

typedef struct hal_mt_nb_cia_key_ipv6_fld_s {
    uint32 tbl_id;
    uint32 key_wd_h_fld_t, key_wd_h_fld_c;
    uint32 key_1x_h_fld_t, key_1x_h_fld_c;
    uint32 key_1x_1_fld_t, key_1x_1_fld_c;
    uint32 decap_pass_fld_t, decap_pass_fld_c;
    uint32 use_tc_color_fld_t, use_tc_color_fld_c;
    uint32 src_bd_fld_t, src_bd_fld_c;
    uint32 is_routed_fld_t, is_routed_fld_c;
    uint32 l2_hdr_present_fld_t, l2_hdr_present_fld_c;
    uint32 l3_ah_present_fld_t, l3_ah_present_fld_c;
    uint32 l3_ipv6_opt_exist_fld_t, l3_ipv6_opt_exist_fld_c;
    uint32 l4_tcp_flg_fld_t, l4_tcp_flg_fld_c;
    uint32 l3_ip_sa_fld_t, l3_ip_sa_fld_c;
    uint32 l3_ip_da_fld_t, l3_ip_da_fld_c;
    uint32 l3_ulp_fld_t, l3_ulp_fld_c;
    uint32 ttl_flg_fld_t, ttl_flg_fld_c;
    uint32 ip_frg_fld_t, ip_frg_fld_c;
    uint32 l4_b01_fld_t, l4_b01_fld_c;
    uint32 l4_b23_fld_t, l4_b23_fld_c;
    uint32 ecn_fld_t, ecn_fld_c;
    uint32 tc_color_fld_t, tc_color_fld_c;
    uint32 pbm_fld_t, pbm_fld_c;
    uint32 key_wd_l_fld_t, key_wd_l_fld_c;
    uint32 key_1x_l_fld_t, key_1x_l_fld_c;
    uint32 key_1x_0_fld_t, key_1x_0_fld_c;
    uint32 l3_ip_sa_h_fld_t, l3_ip_sa_h_fld_c;
    uint32 l3_ip_da_h_fld_t, l3_ip_da_h_fld_c;
    uint32 vld_t;
} hal_mt_nb_cia_key_ipv6_fld_t;

typedef struct hal_mt_nb_cia_key_ucp_fld_s {
    uint32 tbl_id;
    uint32 val_fld_t[HAL_CIA_KEY_WIDTH_MAX], val_fld_c[HAL_CIA_KEY_WIDTH_MAX];
    uint32 vld_t;
} hal_mt_nb_cia_key_ucp_fld_t;

typedef enum hal_mt_nb_cia_key_mac_fld_idx_e {
    HAL_MT_NB_CIA_KEY_MAC_FLD_1X_L2_IGR = 0,
    HAL_MT_NB_CIA_KEY_MAC_FLD_1X_L2_EGR,
    HAL_MT_NB_CIA_KEY_MAC_FLD_LAST
} hal_mt_nb_cia_key_mac_fld_idx_t;

typedef enum hal_mt_nb_cia_key_arp_fld_idx_e {
    HAL_MT_NB_CIA_KEY_ARP_FLD_1X_ARP_IGR = 0,
    HAL_MT_NB_CIA_KEY_ARP_FLD_1X_ARP_EGR,
    HAL_MT_NB_CIA_KEY_ARP_FLD_LAST
} hal_mt_nb_cia_key_arp_fld_idx_t;

typedef enum hal_mt_nb_cia_key_ipv4_fld_idx_e {
    HAL_MT_NB_CIA_KEY_IPV4_FLD_1X_IPV4_IGR = 0,
    HAL_MT_NB_CIA_KEY_IPV4_FLD_1X_IPV4_EGR,
    HAL_MT_NB_CIA_KEY_IPV4_FLD_LAST
} hal_mt_nb_cia_key_ipv4_fld_idx_t;

typedef enum hal_mt_nb_cia_key_ipv6_fld_idx_e {
    HAL_MT_NB_CIA_KEY_IPV6_FLD_2X_IPV6_IGR = 0,
    HAL_MT_NB_CIA_KEY_IPV6_FLD_2X_IPV6_EGR,
    HAL_MT_NB_CIA_KEY_IPV6_FLD_LAST
} hal_mt_nb_cia_key_ipv6_fld_idx_t;

typedef enum hal_mt_nb_cia_mpls_fld_idx_e {
    HAL_MT_NB_CIA_KEY_MPLS_FLD_1X_MPLS_IGR = 0,
    HAL_MT_NB_CIA_KEY_MPLS_FLD_1X_MPLS_EGR,
    HAL_MT_NB_CIA_KEY_MPLS_FLD_LAST
} hal_mt_nb_cia_mpls_fld_idx_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

clx_error_no_t
hal_mt_nb_cia_cfg_init(const uint32 unit);

clx_error_no_t
hal_mt_nb_cia_ucp_cfg_set(const uint32 unit,
                          const clx_cia_stage_t stage,
                          const uint32 tbl_id,
                          const uint32 grp_id,
                          const uint32 ucp_id,
                          const hal_cia_ucp_frm_type_t frame_type,
                          uint32 *ptr_buf);

clx_error_no_t
hal_mt_nb_cia_hw_entry_add(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const uint32 entry_1x_id,
                           const uint32 norm_width,
                           const hal_cmn_cia_plane_bcast_info_t *ptr_bcast_info,
                           uint32 (*ptr_entry_2d_buf)[HAL_CIA_ENTRY_WORDS]);

clx_error_no_t
hal_mt_nb_cia_hw_entry_vld_set(const uint32 unit,
                               const clx_cia_stage_t stage,
                               const uint32 hw_entry_id,
                               const uint32 norm_width,
                               const boolean entry_valid);

clx_error_no_t
hal_mt_nb_cia_hw_entry_read(const uint32 unit,
                            const clx_cia_stage_t stage,
                            const uint32 entry_1x_id,
                            const uint32 norm_width,
                            uint32 (*ptr_entry_2d_buf)[HAL_CIA_ENTRY_WORDS]);

clx_error_no_t
hal_mt_nb_cia_hw_entry_del(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const uint32 entry_1x_id,
                           const uint32 norm_width);

clx_error_no_t
hal_mt_nb_cia_cont_hw_entry_clear(const uint32 unit,
                                  const clx_cia_stage_t stage,
                                  const uint32 start_1x_entry,
                                  const uint32 last_1x_entry);

clx_error_no_t
hal_mt_nb_cia_hw_entry_move(const uint32 unit,
                            const clx_cia_stage_t stage,
                            const uint32 tbl_id,
                            const int32 src_1x_entry_id,
                            const int32 dst_1x_entry_id,
                            const uint32 tot_1x_move_entry_num,
                            const drv_dma_d2d_dir_t d2d_dir,
                            const uint32 shift_cnt,
                            const uint32 cont_move);

clx_error_no_t
hal_mt_nb_cia_move_tbl_id_get(const uint32 unit,
                              const clx_cia_stage_t stage,
                              const uint32 norm_width,
                              uint32 *ptr_tbl_id);

clx_error_no_t
hal_mt_nb_cia_exact_key_info_get(const uint32 unit,
                                 const clx_cia_exact_classify_t *ptr_classify,
                                 hal_cia_exact_entry_pack_info_t *ptr_pack_info,
                                 uint32 *ptr_key_tbl);

clx_error_no_t
hal_mt_nb_cia_exact_grp_prof_get(const uint32 unit,
                                 const clx_cia_stage_t stage,
                                 const uint32 grp_id,
                                 const uint32 ucp_member_bmp,
                                 clx_cia_exact_grp_prof_t *ptr_grp_prof);

clx_error_no_t
hal_mt_nb_cia_exact_grp_hw_cfg_set(const uint32 unit,
                                   const clx_cia_exact_grp_prof_t *ptr_grp_prof,
                                   const uint32 level);

clx_error_no_t
hal_mt_nb_cia_exact_key_pack(const uint32 unit,
                             const uint32 grp_id,
                             const clx_cia_exact_classify_t *ptr_classify,
                             const hal_cia_exact_entry_pack_info_t *ptr_pack_info,
                             uint32 key_tbl,
                             uint32 *ptr_key_buf);

clx_error_no_t
hal_mt_nb_cia_fpu_four_action_pack(const uint32 unit,
                                   const uint32 new_rslt_idx,
                                   uint32 *fpu_action,
                                   uint32 *fpu_action_type);

clx_error_no_t
hal_mt_nb_cia_exact_key_data_fld_unpack(const uint32 unit,
                                        hal_cia_exact_entry_pack_info_t *ptr_exact_key,
                                        const uint32 key_tbl,
                                        const uint32 *ptr_key_fld_buf,
                                        clx_cia_exact_classify_t *ptr_classify);

clx_error_no_t
hal_mt_nb_cia_tapping_tpid_set(const uint32 unit, const clx_swc_cfg_t property, const uint32 tpid);

clx_error_no_t
hal_mt_nb_cia_tapping_tpid_get(const uint32 unit, const clx_swc_cfg_t property, uint32 *tpid);

clx_error_no_t
hal_mt_nb_cia_grp_prof_get(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const uint32 group_id,
                           const uint32 ucp_member_bmp,
                           clx_cia_grp_prof_t *ptr_grp_prof);
clx_error_no_t
hal_mt_nb_cia_grp_prof_add(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const uint32 ucp_member_bmp,
                           const uint32 prio,
                           const clx_cia_grp_prof_t *ptr_grp_prof,
                           hal_cia_grp_info_t *ptr_hal_grp_info);

clx_error_no_t
hal_mt_nb_cia_entry_alloc_rsrc_free(const uint32 unit,
                                    const clx_cia_stage_t stage,
                                    const hal_cia_entry_alloc_info_t *ptr_alloc_info);
clx_error_no_t
hal_mt_nb_cia_ucp_reset(const uint32 unit,
                        const clx_cia_stage_t stage,
                        const uint32 grp_id,
                        uint32 ucp_bmp);

clx_error_no_t
hal_mt_nb_cia_grp_enable(const uint32 unit,
                         const clx_cia_stage_t stage,
                         const uint32 group,
                         const uint32 enable);

clx_error_no_t
hal_mt_nb_cia_udf_key_info_get(const uint32 unit,
                               const clx_cia_stage_t stage,
                               const uint32 group,
                               const clx_cia_classify_t *ptr_classify,
                               hal_cia_entry_pack_udf_key_t *ptr_udf_key);
clx_error_no_t
hal_mt_nb_cia_ucp_pbm_en_get(const uint32 unit,
                             const clx_cia_stage_t stage,
                             const uint32 group,
                             uint32 *ptr_ucp_pbm_en);

clx_error_no_t
hal_mt_nb_cia_ucp_to_grp_add(const uint32 unit,
                             const clx_cia_stage_t stage,
                             const uint32 group,
                             const uint32 new_ucp);

clx_error_no_t
hal_mt_nb_cia_pkt_format_get(const uint32 unit,
                             const clx_cia_stage_t stage,
                             const uint32 udf_prof_id,
                             const hal_cia_udf_info_t *ptr_udf_info,
                             clx_cia_pkt_format_t *ptr_pkt_format);

clx_error_no_t
hal_mt_nb_cia_pkg_lou_prof_idx_set(const uint32 unit,
                                   const clx_cia_stage_t stage,
                                   const uint32 udf_prof_id,
                                   const uint32 exact_pkg_vld,
                                   const uint32 pkg_vld,
                                   const uint32 lou_vld);
clx_error_no_t
hal_mt_nb_cia_pkg_lou_prof_idx_get(const uint32 unit,
                                   const clx_cia_stage_t stage,
                                   const uint32 udf_prof_id,
                                   uint32 *ptr_exact_pkg_prof_vld,
                                   uint32 *ptr_exact_pkg_prof_idx,
                                   uint32 *ptr_cia_pkg_prof_vld,
                                   uint32 *ptr_cia_pkg_prof_idx,
                                   uint32 *ptr_lou_prof_vld,
                                   uint32 *ptr_lou_prof_idx);
clx_error_no_t
hal_mt_nb_cia_tcam_pkg_lou_set(const uint32 unit,
                               const clx_cia_stage_t stage,
                               const uint32 udf_key_prof_id,
                               const boolean valid,
                               const clx_cia_pkt_format_t *ptr_pkt_format);
clx_error_no_t
hal_mt_nb_cia_pkg_prof_get(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const uint32 cia_pkg_prof_idx,
                           const uint32 cia_pkg_prof_vld,
                           const hal_cia_udf_info_t *ptr_udf_info,
                           clx_cia_udf_prof_t *ptr_profile);
clx_error_no_t
hal_mt_nb_cia_pkg_prof_set(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const uint32 udf_prof_id,
                           const clx_cia_udf_prof_t *ptr_profile,
                           uint32 *ptr_cia_pkg_vld,
                           uint32 *ptr_pkg_0_cnt,
                           uint32 *ptr_pkg_1_cnt,
                           uint32 *ptr_pkg_0_consecutive_bmp,
                           uint32 *ptr_pkg_1_consecutive_bmp,
                           uint32 *ptr_pkg_valid_bmp);

clx_error_no_t
hal_mt_nb_cia_exact_pkg_prof_get(const uint32 unit,
                                 const uint32 exact_pkg_prof_idx,
                                 const hal_cia_udf_info_t *ptr_udf_info,
                                 clx_cia_udf_prof_t *ptr_profile);
clx_error_no_t
hal_mt_nb_cia_exact_pkg_prof_set(const uint32 unit,
                                 const uint32 udf_prof_id,
                                 const clx_cia_udf_prof_t *ptr_profile,
                                 uint32 *ptr_exact_pkg_vld,
                                 uint32 *ptr_consecutive_bmp);
clx_error_no_t
hal_mt_nb_cia_range_prof_set(const uint32 unit,
                             const clx_cia_stage_t stage,
                             const uint32 udf_prof_id,
                             const uint32 range_id,
                             const clx_cia_range_cfg_t *ptr_range);
clx_error_no_t
hal_mt_nb_cia_range_prof_get(const uint32 unit,
                             const clx_cia_stage_t stage,
                             const uint32 udf_prof_id,
                             const uint32 range_id,
                             const hal_cia_range_info_t *ptr_range_info,
                             clx_cia_range_cfg_t *ptr_range);

clx_error_no_t
hal_mt_nb_cia_range_prof_clear(const uint32 unit,
                               const clx_cia_stage_t stage,
                               const uint32 udf_prof_id,
                               const uint32 range_id);

clx_error_no_t
hal_mt_nb_cia_pkg_prof_reset(const uint32 unit,
                             const clx_cia_stage_t stage,
                             const uint32 udf_prof_id);
clx_error_no_t
hal_mt_nb_cia_entry_unpack(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const hal_cia_entry_info_t *ptr_entry_info,
                           boolean *ptr_entry_valid,
                           clx_cia_classify_t *ptr_classify,
                           clx_cia_act_t *ptr_action);
clx_error_no_t

hal_mt_nb_cia_rim_fcm_act_set(const uint32 unit,
                              const uint32 is_flw,
                              const uint32 index,
                              const void *ptr_action);

clx_error_no_t
hal_mt_nb_cia_rim_fcm_act_get(const uint32 unit,
                              const uint32 is_flw,
                              const uint32 index,
                              const void *ptr_action);

clx_error_no_t
hal_mt_nb_cia_rim_fcm_act_trav(const uint32 unit,
                               const uint32 is_flw,
                               const clx_cia_rim_trav_func_t callback,
                               void *ptr_cookie);

clx_error_no_t
hal_mt_nb_cia_adj_info_update(const uint32 unit,
                              const uint32 adj_id,
                              const hal_l3_adj_info_t *ptr_adj_info);

clx_error_no_t
hal_mt_nb_cia_entry_pack(const uint32 unit,
                         const clx_cia_stage_t stage,
                         const uint32 group,
                         const boolean entry_vld,
                         const clx_cia_classify_t *ptr_classify,
                         const clx_cia_act_t *ptr_action,
                         hal_cia_entry_pack_info_t *ptr_pack_info,
                         hal_cia_entry_alloc_info_t *ptr_alloc_info,
                         hal_cmn_cia_plane_bcast_info_t *ptr_bcast_info,
                         uint32 *ptr_norm_width,
                         uint32 (*ptr_entry_2d_buf)[HAL_CIA_ENTRY_WORDS]);

/**
 * @brief The API is used to add an exact match entry to HW.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     stage             - UCP group stage type.
 * @param [in]     grp_id            - Group id.
 * @param [in]     ptr_entry_info    - The entry information.
 * @param [out]    ptr_entry_id      - The returned entry id from HW.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_mt_nb_cia_exact_entry_add(const uint32 unit,
                              const clx_cia_stage_t stage,
                              const uint32 grp_id,
                              const clx_cia_exact_entry_t *ptr_entry_info,
                              uint32 *ptr_entry_id);

/**
 * @brief The API is used to update entry to HW.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     grp_id            - Group id.
 * @param [in]     tile_bmp          - Tile bmp.
 * @param [in]     key_buf           - New key buffer.
 * @param [in]     new_rslt_tbl      -  MT_NB_TBL_CIAT_RSLT_UCP_ACTIONS_ID or
 *                                     MT_NB_TBL_FPU_HSH_POLICY_ID.
 * @param [in]     rslt_buf          - New rslt buffer.
 * @param [in]     ptr_entry_info    - Origin flow entry info.
 * @param [out]    key_idx           - New flow entry index.
 * @param [out]    new_rslt_idx      - For 4 action - CIAT_RSLT_UCP_ACTIONS index.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_mt_nb_cia_exact_action_update(const uint32 unit,
                                  const uint32 grp_id,
                                  const uint32 tile_bmp,
                                  uint32 *key_buf,
                                  const uint32 new_rslt_tbl,
                                  uint32 *rslt_buf,
                                  hal_cia_exact_entry_info_t *ptr_entry_info,
                                  uint32 *key_idx,
                                  uint32 *new_rslt_idx);

clx_error_no_t
hal_mt_nb_cia_exact_entry_get(const uint32 unit,
                              hal_cia_exact_entry_info_t *ptr_entry_info,
                              clx_cia_exact_classify_t *ptr_classify,
                              clx_cia_act_t *ptr_action);

clx_error_no_t
hal_mt_nb_cia_rim_rdir_to_l2_info_set(const uint32 unit,
                                      const uint32 tbl_id,
                                      const uint32 index,
                                      const clx_cia_redir_act_t *ptr_redir_action,
                                      hal_cia_avl_redir_info_t *ptr_avl_redir);

clx_error_no_t
hal_mt_nb_cia_rim_rdir_to_l2_uc_info_get(const uint32 unit,
                                         const uint32 tbl_id,
                                         const uint32 index,
                                         const hal_cia_avl_redir_info_t *ptr_avl_redir,
                                         clx_cia_redir_act_t *ptr_redir_action);

clx_error_no_t
hal_mt_nb_cia_rim_rdir_to_l2_mc_info_get(const uint32 unit,
                                         const uint32 tbl_id,
                                         const uint32 index,
                                         const hal_cia_avl_redir_info_t *ptr_avl_redir,
                                         clx_cia_redir_act_t *ptr_redir_action);

clx_error_no_t
hal_mt_nb_cia_rim_rdir_to_l3_mc_info_set(const uint32 unit,
                                         const uint32 tbl_id,
                                         const uint32 index,
                                         const clx_cia_redir_act_t *ptr_redir_action,
                                         hal_cia_avl_redir_info_t *ptr_avl_redir);

clx_error_no_t
hal_mt_nb_cia_rim_rdir_to_l3_uc_info_set(const uint32 unit,
                                         const uint32 tbl_id,
                                         const uint32 index,
                                         const clx_cia_redir_act_t *ptr_redir_action,
                                         hal_cia_avl_redir_info_t *ptr_avl_redir);
clx_error_no_t
hal_mt_nb_cia_rim_rdir_to_l3_ecmp_info_set(const uint32 unit,
                                           const uint32 tbl_id,
                                           const uint32 index,
                                           const clx_cia_redir_act_t *ptr_redir_action,
                                           hal_cia_avl_redir_info_t *ptr_avl_redir);

clx_error_no_t
hal_mt_nb_cia_rim_rdir_to_l3_mc_info_get(const uint32 unit,
                                         const uint32 tbl_id,
                                         const uint32 index,
                                         const hal_cia_avl_redir_info_t *ptr_avl_redir,
                                         clx_cia_redir_act_t *ptr_redir_action);

clx_error_no_t
hal_mt_nb_cia_rim_rdir_to_l3_mpls_info_get(const uint32 unit,
                                           const uint32 tbl_id,
                                           const uint32 index,
                                           clx_cia_redir_act_t *ptr_redir_action);

clx_error_no_t
hal_mt_nb_cia_rim_rdir_to_l3_mpls_info_set(const uint32 unit,
                                           const uint32 tbl_id,
                                           const uint32 index,
                                           const clx_cia_redir_act_t *ptr_redir_action,
                                           hal_cia_avl_redir_info_t *ptr_avl_redir);
clx_error_no_t
hal_mt_nb_cia_hash_id_to_entry_id_trans(uint32 unit, uint32 hash_idx, uint32 *entry_id);

clx_error_no_t
hal_mt_nb_cia_exact_entry_id_info_get(const uint32 unit,
                                      const uint32 hw_entry_id,
                                      clx_cia_stage_t *ptr_stage,
                                      uint32 *ptr_grp_id);

#endif /* End of HAL_MT_NB_CIA_H */
