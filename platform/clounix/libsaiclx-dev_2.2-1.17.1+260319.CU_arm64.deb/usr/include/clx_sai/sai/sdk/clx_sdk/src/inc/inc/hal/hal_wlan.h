/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_wlan.h
 * PURPOSE:
 *      It provide wlan hal layer api.
 * NOTES:
 *
 */

#ifndef HAL_WLAN_H
#define HAL_WLAN_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_wlan.h>
#include <hal/hal_tnl.h>
#include <util/lib/util_lib_avl.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_WLAN_CAPWAP_PROF_NUM (HAL_TNL_MAX_NUM_OF_FLEX_TNL)
#define HAL_WLAN_CAPWAP_RID_MIN  (1)
#define HAL_WLAN_CAPWAP_RID_MAX  (31)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_wlan_wbdb_e {
    HAL_WLAN_WBDB_PORT_KEY,
    HAL_WLAN_WBDB_PORT_SRV,
    HAL_WLAN_WBDB_CAPWAP_PROF,
    HAL_WLAN_WBDB_LAST
} hal_wlan_wbdb_t;

typedef enum hal_wlan_db_dump_flags_e {
    HAL_WLAN_DB_DUMP_FLAGS_CAPWAP_PROF,
    HAL_WLAN_DB_DUMP_FLAGS_PORT,
    HAL_WLAN_DB_DUMP_FLAGS_STA,
    HAL_WLAN_DB_DUMP_FLAGS_LAST
} hal_wlan_db_dump_flags_t;

typedef struct hal_wlan_capwap_hdr_s {
    clx_tnl_info_t tnl_info;
    uint16 capwap_client_port;
    uint8 rid;
    uint8 capwap_prof_id;
} hal_wlan_capwap_hdr_t;

typedef struct hal_wlan_port_avl_node_s {
    clx_port_t wlan_port; /* Key */
    hal_wlan_capwap_hdr_t hdr;
} hal_wlan_port_avl_node_t;

/* The AVL tree save port and bdid binding info, if node not exist encapsulation can not get udp
 * dport */
typedef struct hal_wlan_port_srv_avl_node_s {
    clx_port_t wlan_port; /* Key */
    uint32 bdid;          /* Key */

    uint32 ref;
} hal_wlan_port_srv_avl_node_t;

typedef struct hal_wlan_capwap_prof_s {
    boolean is_used;
    uint16 capwap_server_port; /* Capwap data plane UDP server port */
    uint16 capwap_client_port; /* Capwap data plane UDP client port */
    uint8 rid;                 /* Radio Identifier(RID) in CAPWAP header */
    boolean rid_group;         /* CAPWAP RID group */
    boolean udp_lite;          /* Use UDP-Lite as transport layer */
    uint32 lcl_offset;         /* When an AC-AP pair uses multiple RIDs, the local index
                                * is calculated by adding the RID to a base index.
                                * The base index offset must be a power of 2 and large enough
                                * to fit all RIDs.
                                * For example:
                                * - With 4 RIDs (0,1,2,3), use offset 4
                                * - With 5 RIDs (0,1,2,3,4), use offset 8
                                */
} hal_wlan_capwap_prof_t;

typedef struct hal_wlan_cb_s {
    util_lib_avl_head_t *ptr_port_avl;     /* hal_wlan_port_avl_node_t */
    util_lib_avl_head_t *ptr_port_srv_avl; /* hal_wlan_port_srv_avl_node_t */
    hal_wlan_capwap_prof_t prof[HAL_WLAN_CAPWAP_PROF_NUM];

    clx_semaphore_id_t capwap_sema;
    clx_semaphore_id_t sta_sema;
} hal_wlan_cb_t;

typedef struct hal_wlan_trav_node_s {
    clx_port_t port;
    clx_wlan_capwap_t hdr;
    clx_tnl_encap_info_t encap_info;
    clx_tnl_decap_info_t decap_info;
} hal_wlan_trav_node_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
clx_error_no_t
hal_wlan_port_validate(const uint32 unit, const clx_port_t port);

/**
 * @brief Compose wlan clx_port with unit and nvo3_encap_idx.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     nvo3_encap_idx    - Index to rwo_sram_nvo3_encap table.
 * @param [out]    ptr_port          - Clx_port.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_wlan_clx_port_compose(const uint32 unit, const uint32 nvo3_encap_idx, clx_port_t *ptr_port);

/**
 * @brief Transform hardware fields to user view for GET function.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     nvo3_encap_idx    - Nvo3_encap_idx.
 * @param [out]    ptr_port          - Srv6 port.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_wlan_sw_init_info_get(const uint32 unit, const uint32 nvo3_encap_idx, clx_port_t *ptr_port);

/**
 * @brief Get nvo3_encap_idx from wlan_port.
 *
 * @param [in]     unit                  - Device unit number.
 * @param [in]     wlan_port             - Wlan port.
 * @param [out]    ptr_nvo3_encap_idx    - Index to RWO_SRAM_NVO3_ENCAP (all planes equal value).
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_wlan_hw_init_info_get(const uint32 unit,
                          const clx_port_t wlan_port,
                          uint32 *ptr_nvo3_encap_idx);
#endif /* End of HAL_WLAN_H */