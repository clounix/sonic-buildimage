/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   hal_const_cmn.h
 * PURPOSE:
 *      It provides CL8600 chip specific definition.
 * NOTES:
 */

#ifndef HAL_CONST_CMN_H
#define HAL_CONST_CMN_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */
/* chip */
#define HAL_NB_CHIP_NUM     (32) /* 5 bit chip-id */
#define HAL_KG_CHIP_NUM     (16) /* 5 bit chip-id */
#define HAL_INVALID_CHIP_ID (31)

/* bin */
#define HAL_BIN_NUM_MAX (4)

/* plane, port */
#define HAL_PORT_NUM(unit)  (PTR_HAL_CONST_INFO(unit, port)->hal_port_num)
#define HAL_PLANE_NUM(unit) (PTR_HAL_CONST_INFO(unit, port)->hal_plane_num)

#define HAL_PORT_NUM_MAX  (256)
#define HAL_PLANE_NUM_MAX (8)

#define HAL_NB_PLANE_PORT         (32)
#define HAL_KG_PLANE_PORT         (88)
#define HAL_PLANE_ETH_PORT_MIN    (0)
#define HAL_PLANE_ETH_DP_PORT_MIN (0)

#define HAL_PLANE_ETH_PORT_MAX(unit) \
    (PTR_HAL_CONST_INFO(unit, port)->hal_plane_eth_port_max) /* include regular port, CPI port */

#define HAL_PLANE_ETH_DP_PORT_MAX(unit) \
    (PTR_HAL_CONST_INFO(unit, port)->hal_plane_eth_dp_port_max) /* include regular port */
#define HAL_PLANE_ETH_DP_PORT_MAX_CMN (33)
/* dst-idx */
#define HAL_PHY_PORT_NUM (2048)

#if defined(CLX_MOCK)
#define HAL_L2_MGID_NUM (4096)      /* reduce size for TMV */
#else
#define HAL_L2_MGID_NUM (16384)     /* non-replicate mgid */
#endif
#define HAL_L3_MGID_NUM      (8192) /* replicate mgid */
#define HAL_MGID_NUM         (HAL_L2_MGID_NUM + HAL_L3_MGID_NUM)
#define HAL_EXCPT_CPU_NUM    (256)
#define HAL_EXCPT_DROP_NUM   (256)
#define HAL_MIRROR_NUM       (256)
#define HAL_REDIRECT_CPU_NUM (2048)
#define HAL_TNL_NUM          (8192)
#define HAL_NSH_NUM          (8192)
#define HAL_INVALID_NUM      (10240)

/* vlan, mtu */
#define HAL_VID_MIN             (1)
#define HAL_VID_MAX             (4095)
#define HAL_TYPE_VLAN_INDEX_MIN (0)
#define HAL_TYPE_VLAN_INDEX_MAX (255)

#define HAL_CIA_ENTRY_WORDS (84)

/* header */
#define HAL_TMH_SIZE     (20)
#define HAL_PPH_SIZE     (20)
#define HAL_FABH_SIZE    (20)
#define HAL_TMH_PPH_SIZE (HAL_TMH_SIZE + HAL_PPH_SIZE)
#define HAL_HEADER_SIZE  (HAL_TMH_PPH_SIZE + HAL_FABH_SIZE)

/* invalid or reserved */
#define HAL_INVALID_GROUP_LABEL (0)

// #if defined(CLX_EN_NAMCHABARWA)
// #define HAL_INVALID_NVO3_ENCAP_IDX        (0)
// #define HAL_INVALID_NVO3_ADJ_IDX          (0)
// #else
// #define HAL_INVALID_NVO3_ENCAP_IDX        (0x3FFF)
// #define HAL_INVALID_NVO3_ADJ_IDX          (0xFF)
// #endif

#define HAL_INVALID_NVO3_ENCAP_IDX(unit) (PTR_HAL_CONST_INFO(unit, tnl)->invalid_nvo3_encap_idx)
#define HAL_INVALID_NVO3_ADJ_IDX(unit)   (PTR_HAL_CONST_INFO(unit, tnl)->invalid_nvo3_adj_idx)

#define HAL_INVALID_LCL_INTF_GRP  (0x1FFF)
#define HAL_INVALID_CNT_MTR_IDX   (0x7FFF)
#define HAL_INVALID_FDID          (0) /* means fdid is not created                         */
#define HAL_INVALID_L3_INTF       (0) /* means L3 interface is disabled                    */
#define HAL_INVALID_FRR_STATE_IDX (0) /* means ECMP FRR is disabled                        */
#define HAL_INVALID_SEG_VMID      (0xFFFFFF)
#define HAL_INVALID_CPU_ID        (0x1F)
#define HAL_INVALID_DOS_IDX       (0xF)
#define HAL_INVALID_HW_BUM_OFFSET (0x3)
#define HAL_INVALID_IEV_RSLT_IDX  (0x3FFFF)
#define HAL_INVALID_PHB_HW_IDX    (0x1F) /* SRV INTF uses invalid index                       */
#define HAL_DEFAULT_PHB_HW_IDX    (0x1F) /* LCL INTF uses default index                       */

#define HAL_RSV_FDID    (0x3FFF)         /* HW reserved; all 1 means use outer vid as FDID    */
#define HAL_RSV_L3_INTF (0x3FFF)         /* HW reserved; all 1 means use outer vid as L3 Intf */
                                         /*              all 1 means invalid at egress side   */
#define HAL_INVALID_ADJ_IDX    (0x3FFFF) /* For 18bit adj_idx                                 */
#define HAL_INVALID_MTR_HW_IDX (0x1FFFF)
#define HAL_RSV_MEL_IDX        (0x1FFF)

/* default and capacity */
#define HAL_DROP_STP_ID       (255)
#define HAL_FORWARD_STP_ID    (254)
#define HAL_SRV_BUM_OFFSET_BC (0x0)
#define HAL_SRV_ENTRY_NUM     (TOB_TABLE(unit, LT_TBL_IDS_RSLT_SRV_U_L2_INTF_ID)->entry_max_number)
#define HAL_ENCAP_BANK_NUM    (4) /* bank number of EME_RSLT_ENCAP_U_* */

/* reserved service l2 index */
#define HAL_SRV_EXCPT_TO_CPU_IDX                                    \
    (HAL_SRV_ENTRY_NUM - 2) /* HW rsv; raise ipp excpt_invld_srv_fe \
                             */
#define HAL_SRV_EXCPT_DROP_IDX \
    (HAL_SRV_ENTRY_NUM - 1) /* HW rsv; raise ipp/epp excpt_invld_srv_ff */
#define HAL_INVALID_SRV_IDX                                            \
    (0xFFFF)                /* HW rsv; find srv_l2_idx from elsewhere. \
                               If it's the final result, trigger ipp/epp excpt_invld_srv_ff */

/* reserved etm/emi_rslt_mc_sc_idx */
#define HAL_DFLT_MC_SC_IDX (8 * 1024 - 1)

#define HAL_ITM_PBM_WORDS                 (16) /* max mgid pbm words */
#define HAL_PP_PBM_WORDS                  (24) /* max pbm words of IPP/EPP except ITM */
#define HAL_ITM_BMP_WORDS_PER_PLANE(unit) (HAL_ITM_PBM_WORDS / HAL_PLANE_NUM(unit))
#define HAL_PP_BMP_WORDS_PER_PLANE        (HAL_PP_PBM_WORDS / HAL_PLANE_NUM_MAX)

/* [DO NOT CHANGE]
 * emi_iev_cfg3.ptp_igr_phy_port_msk
 * emi_iev_cfg4.ptp_igr_phy_port_val
 */
#define HAL_PTP_PORT (0x7F0)

/* ueid_mgid ranges */
#define HAL_PHY_PORT_BASE_ID    (0)
#define HAL_PHY_PORT_MIN        (HAL_PHY_PORT_BASE_ID)
#define HAL_PHY_PORT_MAX        (HAL_PHY_PORT_BASE_ID + HAL_PHY_PORT_NUM - 1)
#define HAL_PHY_PORT_INVALID_DI (HAL_PHY_PORT_NUM - 1)

/* Reserve DI number (38 DI, 2008 ~ 2046) for special ports like CPU/eCPU/RC port.*/
#define HAL_SPEC_PORT_DI_NUM  (40)
#define HAL_SPEC_PORT_DI_BASE (HAL_PHY_PORT_NUM - HAL_SPEC_PORT_DI_NUM)

#define HAL_FAB_BLOCK_DI (3 * 1024) /* blocked by sw config */

#define HAL_LAG_BASE_ID_DFT   (3 * 1024 + 512)
#define HAL_LAG_BASE_ID(unit) (PTR_HAL_CONST_INFO(unit, lag)->lag_base_id)

#define HAL_LAG_MIN(unit) (PTR_HAL_CONST_INFO(unit, lag)->lag_port_min)
#define HAL_LAG_MAX(unit) (PTR_HAL_CONST_INFO(unit, lag)->lag_port_max)

#define HAL_MGID_LAG_BASE_ID (2 * 1024)
#define HAL_MGID_LAG_NUM     (1 * 1024)
#define HAL_MGID_LAG_MIN     (0)
#define HAL_MGID_LAG_MAX     (HAL_MGID_LAG_MIN + HAL_MGID_LAG_NUM - 1)

#define HAL_MGID_BASE_ID(unit) (PTR_HAL_CONST_INFO(unit, l2)->mgid_base_id)
#define HAL_MGID_MIN(unit)     (HAL_MGID_BASE_ID(unit))
#define HAL_MGID_MAX(unit)     (HAL_MGID_BASE_ID(unit) + HAL_MGID_NUM - 1)
#define HAL_INVALID_MGID(unit) (HAL_MGID_MAX(unit))

/* reserved l2 mgid */
#define HAL_L2_MGID_DROP(unit) \
    (HAL_MGID_BASE_ID(unit) + PTR_HAL_CONST_INFO(unit, l2)->mgid_drop_offset)
/* [DO NOT CHANGE]
 * itm_cfg_cpu2cpu_w0.cpu2cpu_mgid_neighbor_hi/lo
 * itm_cfg_cpu2cpu_w1.cpu2cpu_mgid_neighbor_hi/lo
 */
#define HAL_L2_MGID_STK_CPU_BCAST(unit) \
    (HAL_MGID_BASE_ID(unit) + PTR_HAL_CONST_INFO(unit, l2)->mgid_stk_cpu_bcast_offset)
#define HAL_L2_MGID_STK_CPU_NEIGHBOR(unit) \
    (HAL_MGID_BASE_ID(unit) + PTR_HAL_CONST_INFO(unit, l2)->mgid_stk_cpu_neighbor_offset)
/* the mcast id will be allocated when vlan init */
#define HAL_L2_MGID_DEFAULT_VLAN(unit) \
    (HAL_MGID_BASE_ID(unit) + PTR_HAL_CONST_INFO(unit, l2)->mgid_dflt_vlan_offset)
#define HAL_L2_MGID_DEFAULT_VLAN_RSV1(unit) \
    (HAL_MGID_BASE_ID(unit) + PTR_HAL_CONST_INFO(unit, l2)->mgid_dflt_vlan_rsv1_offset)
#define HAL_L2_MGID_DEFAULT_VLAN_RSV2(unit) \
    (HAL_MGID_BASE_ID(unit) + PTR_HAL_CONST_INFO(unit, l2)->mgid_dflt_vlan_rsv2_offset)

#define HAL_L2_MCAST_ID_MIN (0)
#define HAL_L2_MCAST_ID_MAX (HAL_L2_MCAST_ID_MIN + HAL_L2_MGID_NUM - 1)

#define HAL_L2_ECMP_BASE_ID                                                                       \
    (48 * 1024) /* L2_ECMP: 48K~64K-1 (highest 2b set to all one, lower 14b is index in ecmp grp) \
                 */
#define HAL_L2_ECMP_ID_MIN (HAL_L2_ECMP_BASE_ID)
#define HAL_L2_ECMP_ID_MAX (16384 - 1 + HAL_L2_ECMP_BASE_ID)

#if defined(CLX_MOCK)
#define HAL_L3_MCAST_ID_MIN (16384)
#define HAL_L3_MCAST_ID_MAX (HAL_L3_MCAST_ID_MIN + HAL_L3_MGID_NUM - 1)
#else
#define HAL_L3_MCAST_ID_MIN (HAL_L2_MCAST_ID_MIN + HAL_L2_MGID_NUM)
#define HAL_L3_MCAST_ID_MAX (HAL_L3_MCAST_ID_MIN + HAL_L3_MGID_NUM - 1)
#endif

#define HAL_EXCPT_CPU_BASE_ID    (PTR_HAL_CONST_INFO(unit, port)->cpu_di_base)
#define HAL_EXCPT_CPU_NON_L3_MIN (0)
#define HAL_EXCPT_CPU_NON_L3_MAX (HAL_EXCPT_CPU_NON_L3_MIN + HAL_EXCPT_CPU_NUM - 1)
#define HAL_EXCPT_CPU_L3_MIN     (HAL_EXCPT_CPU_NON_L3_MIN + HAL_EXCPT_CPU_NUM)
#define HAL_EXCPT_CPU_L3_MAX     (HAL_EXCPT_CPU_L3_MIN + HAL_EXCPT_CPU_NUM - 1)

#define HAL_EXCPT_DROP_BASE_ID    (28 * 1024 + 512)
#define HAL_EXCPT_DROP_NON_L3_MIN (0)
#define HAL_EXCPT_DROP_NON_L3_MAX (HAL_EXCPT_DROP_NON_L3_MIN + HAL_EXCPT_DROP_NUM - 1)
#define HAL_EXCPT_DROP_L3_MIN     (HAL_EXCPT_DROP_NON_L3_MIN + HAL_EXCPT_DROP_NUM)
#define HAL_EXCPT_DROP_L3_MAX     (HAL_EXCPT_DROP_L3_MIN + HAL_EXCPT_DROP_NUM - 1)

#define HAL_DROP_BASE_ID(unit) (PTR_HAL_CONST_INFO(unit, port)->drop_di_base)
#define HAL_DROP_NUM(unit)     (PTR_HAL_CONST_INFO(unit, port)->drop_di_num)
#define HAL_DROP_MIN(unit)     (HAL_DROP_BASE_ID(unit))
#define HAL_DROP_MAX(unit)     (HAL_DROP_BASE_ID(unit) + HAL_DROP_NUM(unit) - 1)

#define HAL_PORT_MTU_JUMBO        9216
#define HAL_PORT_L2_MTU_MIN(unit) (PTR_HAL_CONST_INFO(unit, port)->l2_mtu_min)
#define HAL_PORT_L2_MTU_MAX(unit) (PTR_HAL_CONST_INFO(unit, port)->l2_mtu_max)
#define HAL_MAC_FRM_LENGTH_MAX    16383

/* HW definition:
 * 0: IEV default to drop
 * 1: IEV L3 exception suppress data forward
 * 2: IEV ACL drop
 * 3: IEV ICC drop
 */
//     #if defined(CLX_EN_NAMCHABARWA)
//         #define HAL_DROP_L3_UCAST_ID(unit)           (HAL_DROP_BASE_ID(unit))
//         #define HAL_DROP_L3_MCAST_ID(unit)           (HAL_DROP_BASE_ID(unit))
//         #define HAL_DROP_L3_LKP_MISS_ID(unit)        (HAL_DROP_BASE_ID(unit))
//     #endif
#define HAL_DROP_L3_UCAST_ID(unit)    (HAL_DROP_BASE_ID(unit) + 4)
#define HAL_DROP_L3_MCAST_ID(unit)    (HAL_DROP_BASE_ID(unit) + 5)
#define HAL_DROP_L3_LKP_MISS_ID(unit) (HAL_DROP_BASE_ID(unit) + 6)

#define HAL_MIRROR_BASE_ID (29 * 1024 + 512)
#define HAL_MIRROR_MIN     (HAL_MIRROR_BASE_ID)
#define HAL_MIRROR_MAX     (HAL_MIRROR_BASE_ID + HAL_MIRROR_NUM - 1)

#define HAL_REDIRECT_CPU_BASE_ID    (30 * 1024)
#define HAL_REDIRECT_CPU_MIN        (HAL_REDIRECT_CPU_BASE_ID)
#define HAL_REDIRECT_CPU_MAX        (HAL_REDIRECT_CPU_BASE_ID + HAL_REDIRECT_CPU_NUM - 1)
#define HAL_REDIRECT_CPU_QUEUE_BITS (6)

#define HAL_TUNNEL_BASE_ID(unit) (PTR_HAL_CONST_INFO(unit, tnl)->tunnel_di_base)
#define HAL_TUNNEL_MIN(unit)     (HAL_TUNNEL_BASE_ID(unit))
#define HAL_TUNNEL_MAX(unit)     (HAL_TUNNEL_MIN(unit) + HAL_TNL_NUM - 1)

#define HAL_NSH_BASE_ID (40 * 1024)
#define HAL_NSH_MIN     (HAL_NSH_BASE_ID)
#define HAL_NSH_MAX     (HAL_NSH_BASE_ID + HAL_NSH_NUM - 1)

#define HAL_INVALID_BASE_ID (54 * 1024)
#define HAL_INVALID_MIN     (HAL_INVALID_BASE_ID)
#define HAL_INVALID_MAX     (HAL_INVALID_BASE_ID + HAL_INVALID_NUM - 1)

/* src_idx ranges */
#define HAL_SRC_PHY_PORT_BASE_ID (0)
#define HAL_SRC_PHY_PORT_MIN     (HAL_SRC_PHY_PORT_BASE_ID)
#define HAL_SRC_PHY_PORT_MAX     (HAL_SRC_PHY_PORT_BASE_ID + HAL_PHY_PORT_NUM - 1)

#define HAL_SRC_LAG_PORT_BASE_ID (3 * 1024 + 512)
#define HAL_SRC_LAG_PORT_MIN     (HAL_SRC_LAG_PORT_BASE_ID)
#define HAL_SRC_LAG_PORT_MAX     (HAL_SRC_LAG_PORT_BASE_ID + HAL_LAG_PORT_NUM - 1)

#define HAL_SRC_TUNNEL_BASE_ID (4 * 1024)
#define HAL_SRC_TUNNEL_MIN     (HAL_SRC_TUNNEL_BASE_ID)
#define HAL_SRC_TUNNEL_MAX     (HAL_SRC_TUNNEL_BASE_ID + HAL_TNL_NUM - 1)

#define HAL_SRC_NSH_BASE_ID (12 * 1024)
#define HAL_SRC_NSH_MIN     (HAL_SRC_NSH_BASE_ID)
#define HAL_SRC_NSH_MAX     (HAL_SRC_NSH_BASE_ID + HAL_NSH_NUM - 1)

/* the reserved mgid num from HAL_MGID_0_MAX_ALLOC_NUM. \
 * - vlan would allocate 1 mgid (HAL_L2_MGID_DEFAULT_VLAN(unit)) when init */
#define HAL_MGID_0_ALLOC_RESERVE_NUM (1)
/* last enty index is reserved. It cannot forward traffic */
#define HAL_MGID_1_ALLOC_RESERVE_NUM (1)

#define HAL_MGID_0_MAX_ALLOC_NUM                \
    (HAL_L2_MGID_NUM - 3) /* reserve 3 mgid for \
                             HAL_L2_MGID_DROP(unit)/STK_CPU_BCAST/STK_CPU_NEIGHBOR. */
#define HAL_MGID_1_MAX_ALLOC_NUM \
    (HAL_L3_MGID_NUM)     /* mcast id = all 1 - 1, cannot forward traffic */

/* Reserve last 3 iev_rslt_entries for keep TTL.                    \
 * 1:(256k - 1) invalid, 2:(256k - 2), 3:(256k - 3)                 \
 * two code-points of 18-bit pbr_rslt_idx to allow ICIA_RSLT_IEV to \
 * carry valid decr_ttl decision, but no valid pbr_rslt_idx.        \
 */
#define HAL_IEV_RSLT_BNK_15_ALLOC_NUM (16381)

/* MACRO FUNCTION DECLARATIONS
 */
/* get EME_RSLT_ENCAP_U_* bank number from nvo3_encap_idx */
#define HAL_GET_ENCAP_BANK_BY_IDX(__id__) ((__id__) / (HAL_TNL_NUM / HAL_ENCAP_BANK_NUM))

/* get the lag_id, group_id or excpt_id from dst_idx */
#define HAL_GET_LAG_ID_FROM_DI(unit, dst_idx)   (dst_idx - HAL_LAG_BASE_ID(unit))
#define HAL_GET_MCAST_ID_FROM_DI(unit, dst_idx) (dst_idx - HAL_MGID_BASE_ID(unit))
#define HAL_GET_L2_ECMP_GRP_FROM_DI(dst_idx)    (dst_idx - HAL_L2_ECMP_BASE_ID)
#define HAL_GET_EXCPT_CPU_FROM_DI(dst_idx)      (dst_idx - HAL_EXCPT_CPU_BASE_ID)
#define HAL_GET_EXCPT_DROP_FROM_DI(dst_idx)     (dst_idx - HAL_EXCPT_DROP_BASE_ID)
#define HAL_GET_MIR_SES_FROM_DI(dst_idx)        (dst_idx - HAL_MIRROR_BASE_ID)

/* get the dst_idx from lag_id, group_id or excpt_id */
#define HAL_GET_DI_FROM_LAG_ID(unit, lag_id)     (lag_id + HAL_LAG_BASE_ID(unit))
#define HAL_GET_DI_FROM_MCAST_ID(unit, mcast_id) (mcast_id + HAL_MGID_BASE_ID(unit))
#define HAL_GET_DI_FROM_EXCPT_CPU(excpt_code)    (excpt_code + HAL_EXCPT_CPU_BASE_ID)
#define HAL_GET_DI_FROM_EXCPT_DROP(excpt_code)   (excpt_code + HAL_EXCPT_DROP_BASE_ID)
#define HAL_GET_DI_FROM_MIR_SES(mirror_ses)      (mirror_ses + HAL_MIRROR_BASE_ID)

#define _HAL_PLANE_PORT_TO_LCL_INTF(__unit__, __plane_id__, __plane_port__)        \
    (((__plane_port__) >= HAL_NB_PLANE_PORT) ?                                     \
         (HAL_PLANE_PORT_TO_CL_PORT(__unit__, __plane_id__, __plane_port__) - 1) : \
         ((__plane_id__) * HAL_NB_PLANE_PORT + (__plane_port__)))

#define HAL_MT_NB_PORT_LCL_MAX_NUM         8192
#define HAL_MT_KG_PORT_LCL_MAX_NUM         8280
#define HAL_MT_KG_PORT_LCL_INTF_GRP_OFFSET 88

#define _HAL_PLANE_PORT_TO_LCL_INTF_FROM_THE_END(__unit__, __plane_id__, __plane_port__) \
    (HAL_MT_NB_PORT_LCL_MAX_NUM -                                                        \
     _HAL_PLANE_PORT_TO_LCL_INTF(__unit__, __plane_id__, __plane_port__) - 1)

#define HAL_PLANE_PORT_TO_LCL_INTF(__unit__, __plane_id__, __plane_port__)                  \
    ((HAL_IS_DEVICE_NAMCHABARWA_FAMILY(__unit__)) ?                                         \
         _HAL_PLANE_PORT_TO_LCL_INTF_FROM_THE_END(__unit__, __plane_id__, __plane_port__) : \
         ((HAL_IS_DEVICE_KAWAGARBO_FAMILY(__unit__)) ?                                      \
              HAL_MT_KG_PORT_LCL_MAX_NUM - HAL_KG_PLANE_PORT + __plane_port__ :             \
              _HAL_PLANE_PORT_TO_LCL_INTF(__unit__, __plane_id__, __plane_port__)))

#define _HAL_MT_NB_PLANE_PORT_LCL_INTF_BASE (HAL_MT_NB_PORT_LCL_MAX_NUM - HAL_PORT_NUM_MAX)

/* kg 4T lcl_intf include plane info, not support, just support NB */
#define HAL_MT_LCL_INTF_TO_PLANE(__unit__, __lcl_intf__)                                    \
    (((HAL_PORT_NUM(__unit__) - (__lcl_intf__ - _HAL_MT_NB_PLANE_PORT_LCL_INTF_BASE) - 1) / \
      HAL_NB_PLANE_PORT))

#define HAL_MT_LCL_INTF_TO_PLANE_PORT(__unit__, __lcl_intf__)                                   \
    ((HAL_IS_DEVICE_KAWAGARBO_FAMILY(unit)) ?                                                   \
         (__lcl_intf__ - HAL_MT_KG_PORT_LCL_MAX_NUM + HAL_KG_PLANE_PORT) :                      \
         ((HAL_PORT_NUM(__unit__) - (__lcl_intf__ - _HAL_MT_NB_PLANE_PORT_LCL_INTF_BASE) - 1) % \
          HAL_NB_PLANE_PORT))

#define HAL_MT_NB_LCL_INTF_IS_PLANE_PORT(__unit__, __lcl_intf__) \
    ((__lcl_intf__ >= _HAL_MT_NB_PLANE_PORT_LCL_INTF_BASE) &&    \
     (__lcl_intf__ <= HAL_MT_NB_PORT_LCL_MAX_NUM - 1))

#define HAL_MT_KG_LCL_INTF_IS_PLANE_PORT(__unit__, __lcl_intf__)         \
    ((__lcl_intf__ >= HAL_MT_KG_PORT_LCL_MAX_NUM - HAL_KG_PLANE_PORT) && \
     (__lcl_intf__ <= HAL_MT_KG_PORT_LCL_MAX_NUM - 1))

/* Default mode LCL allocation:
 * 0-7921 for tunnel-port (refer to _hal_mt_nb_alloc_tbl DIS_RSLT_LCL, reserve 7922),
 * 7922-7923 for vlan compress (reserve 2),
 * 7924-8191 phy-port (reserve 268), refer to _HAL_PLANE_PORT_TO_LCL_INTF
 *      8*32 = 256 (0-255 for front port), special port follows the CL_PORT number
 *      cpu's local interface = 256
 *      cpi's local interface = 257,258
 *      rc's local interface = 259-266
 *      ecpu's local interface = 267
 *
 * Tapping mode LCL allocation:
 * 0-7914 for tunnel-port (refer to _hal_mt_nb_alloc_tbl DIS_RSLT_LCL, reserve 7915),
 * 7915-7916 for vlan compress (reserve 2),
 * 7917-8191 phy-port (reserve 275), refer to _HAL_PLANE_PORT_TO_LCL_INTF
 *      8*32 = 256 (0-255 for front port), special port follows the CL_PORT number
 *      cpu's local interface = 256
 *      cpi's local interface = 257,258
 *      rc's local interface = 259-269
 *      ecpu's local interface = 270-274
 */
/* vlan base egress 1q tag ports lcl intf group */
#define HAL_LCL_INTF_GRP_ID_RSV_TO_VLAN_EGR_1Q(unit) \
    ((HAL_IS_DEVICE_TAPPING_MODE(unit)) ? 7915 : 7922)
/* vlan base egress 1ad tag ports lcl intf group */
#define HAL_LCL_INTF_GRP_ID_RSV_TO_VLAN_EGR_1AD(unit) \
    ((HAL_IS_DEVICE_TAPPING_MODE(unit)) ? 7916 : 7923)
/* vlan base ingress ports lcl intf group */
#define HAL_LCL_INTF_GRP_ID_RSV_TO_VLAN_IGR(unit) ((HAL_IS_DEVICE_TAPPING_MODE(unit)) ? 7916 : 7923)
#define HAL_LCL_INTF_GRP_ID_TNL_MAX_NUM(unit)                 \
    (HAL_IS_DEVICE_NAMCHABARWA_FAMILY(unit) ?                 \
         ((HAL_IS_DEVICE_TAPPING_MODE(unit)) ? 7915 : 7922) : \
         ((HAL_IS_DEVICE_KG_DOUBLE_FAMILY(unit)) ? 8016 : 8104))
/* check dst_idx type */
#define HAL_DI_IS_PORT(ueid_mgid) \
    ((HAL_PHY_PORT_MIN <= ueid_mgid) && (ueid_mgid <= HAL_PHY_PORT_MAX))
#define HAL_DI_IS_MCAST_ID(unit, ueid_mgid) \
    ((HAL_MGID_MIN(unit) <= ueid_mgid) && (ueid_mgid <= HAL_MGID_MAX(unit)))
#define HAL_DI_IS_DROP(unit, ueid_mgid) \
    ((HAL_DROP_MIN(unit) <= ueid_mgid) && (ueid_mgid <= HAL_DROP_MAX(unit)))
#define HAL_DI_IS_TUNNEL(unit, ueid_mgid) \
    ((HAL_TUNNEL_MIN(unit) <= ueid_mgid) && (ueid_mgid <= HAL_TUNNEL_MAX(unit)))
#define HAL_DI_IS_NSH(ueid_mgid) ((HAL_NSH_MIN <= ueid_mgid) && (ueid_mgid <= HAL_NSH_MAX))
#define HAL_DI_IS_INVALID(ueid_mgid) \
    ((HAL_INVALID_MIN <= ueid_mgid) && (ueid_mgid <= HAL_INVALID_MAX))
#define HAL_DI_IS_L2_ECMP_GRP(ueid_mgid) \
    ((HAL_L2_ECMP_ID_MIN <= ueid_mgid) && (ueid_mgid <= HAL_L2_ECMP_ID_MAX))
#define HAL_DI_IS_LAG(unit, ueid_mgid) \
    ((HAL_LAG_MIN(unit) <= ueid_mgid) && (ueid_mgid <= HAL_LAG_MAX(unit)))

/* transfer DI <-> chip/cl port */
#define HAL_PORT_DI_NUM(__unit__) PTR_HAL_EXT_CHIP_INFO(__unit__)->phy_di_num
#define HAL_CL_PORT_TO_DI(__unit__, __chip__, __port__)                                          \
    ((__port__) >= CLX_PORT_NUM ?                                                                \
         HAL_PHY_PORT_INVALID_DI :                                                               \
         (PTR_HAL_EXT_CHIP_INFO(__unit__)->port_di_mode ?                                        \
              PTR_HAL_EXT_CHIP_INFO(__unit__)->lcl_di[(__port__)] :                              \
              (((__chip__) * HAL_PORT_DI_NUM(__unit__) +                                         \
                PTR_HAL_EXT_CHIP_INFO(__unit__)->lcl_di[(__port__)]) > HAL_PHY_PORT_INVALID_DI ? \
                   HAL_PHY_PORT_INVALID_DI :                                                     \
                   ((__chip__) * HAL_PORT_DI_NUM(__unit__) +                                     \
                    PTR_HAL_EXT_CHIP_INFO(__unit__)->lcl_di[(__port__)]))))

#define HAL_DI_TO_CL_PORT(__unit__, __di__)                                                     \
    (PTR_HAL_EXT_CHIP_INFO(__unit__)->port_di_mode ?                                            \
         (((__di__) >= HAL_PHY_PORT_NUM) ? HAL_INVALID_ID :                                     \
                                           PTR_HAL_EXT_CHIP_INFO(__unit__)->di_map[(__di__)]) : \
         PTR_HAL_EXT_CHIP_INFO(__unit__)->di_map[(__di__) % HAL_PORT_DI_NUM(__unit__)])
#define HAL_DI_TO_CHIP_ID(__unit__, __di__)                                            \
    (PTR_HAL_EXT_CHIP_INFO(__unit__)->port_di_mode ?                                   \
         (((__di__) > HAL_PHY_PORT_NUM) ?                                              \
              HAL_INVALID_CHIP_ID :                                                    \
              ((HAL_INVALID_ID != PTR_HAL_EXT_CHIP_INFO(__unit__)->di_map[(__di__)]) ? \
                   PTR_HAL_EXT_CHIP_INFO(__unit__)->hw_chip_id :                       \
                   HAL_INVALID_CHIP_ID)) :                                             \
         ((__di__) / HAL_PORT_DI_NUM(__unit__)))

/* transfer DI -> plane/plane-port/dp-plane-port */
#define HAL_DI_TO_PLANE(__unit__, __di__)                      \
    ((HAL_INVALID_ID == HAL_DI_TO_CL_PORT(__unit__, __di__)) ? \
         HAL_INVALID_ID :                                      \
         HAL_CL_PORT_TO_PLANE(__unit__, HAL_DI_TO_CL_PORT(__unit__, __di__)))
#define HAL_DI_TO_PLANE_PORT(__unit__, __di__)                 \
    ((HAL_INVALID_ID == HAL_DI_TO_CL_PORT(__unit__, __di__)) ? \
         HAL_INVALID_ID :                                      \
         HAL_CL_PORT_TO_PLANE_PORT(__unit__, HAL_DI_TO_CL_PORT(__unit__, __di__)))
#define HAL_DI_TO_DP_PLANE_PORT(__unit__, __di__)              \
    ((HAL_INVALID_ID == HAL_DI_TO_CL_PORT(__unit__, __di__)) ? \
         HAL_INVALID_ID :                                      \
         HAL_CL_PORT_TO_DP_PLANE_PORT(__unit__, HAL_DI_TO_CL_PORT(__unit__, __di__)))

/* __pp_pbmp__ is an array of uint32.
 * __dp_pbmp__ is an array of uint32.
 * __cl_pbmp__ is clx_port_bitmap_t type.
 */
#define HAL_CL_PBMP_TO_DP_PBMP(__unit__, __cl_pbmp__, __dp_pbmp__)                              \
    do {                                                                                        \
        uint32 __p, __idx;                                                                      \
        osal_memset(__dp_pbmp__, 0x0, HAL_BYTES_OF_WORD *HAL_ITM_PBM_WORDS);                    \
        CLX_PORT_FOREACH(__cl_pbmp__, __p)                                                      \
        {                                                                                       \
            __idx =                                                                             \
                HAL_CL_PORT_TO_PLANE((__unit__), __p) * HAL_ITM_BMP_WORDS_PER_PLANE(__unit__) + \
                (HAL_CL_PORT_TO_DP_PLANE_PORT((__unit__), __p) >> 5);                           \
            ((__dp_pbmp__)[__idx]) |= 1U                                                        \
                << (HAL_CL_PORT_TO_DP_PLANE_PORT((__unit__), __p) & 0x1F);                      \
        }                                                                                       \
    } while (0)

#define HAL_DP_PBMP_TO_CL_PBMP(__unit__, __dp_pbmp__, __cl_pbmp__)                                \
    do {                                                                                          \
        uint32 __pn, __p, __idx;                                                                  \
        osal_memset(__cl_pbmp__, 0x0, sizeof(clx_port_bitmap_t));                                 \
        for (__pn = 0; __pn < HAL_PLANE_NUM(__unit__); __pn++) {                                  \
            for (__p = HAL_PLANE_ETH_DP_PORT_MIN; __p <= HAL_PLANE_ETH_DP_PORT_MAX(__unit__);     \
                 __p++) {                                                                         \
                __idx = __pn * HAL_ITM_BMP_WORDS_PER_PLANE(__unit__) + (__p >> 5);                \
                if (__dp_pbmp__[__idx] & (1U << (__p & 0x1F))) {                                  \
                    CLX_PORT_ADD(__cl_pbmp__, HAL_DP_PLANE_PORT_TO_CL_PORT(__unit__, __pn, __p)); \
                }                                                                                 \
            }                                                                                     \
        }                                                                                         \
    } while (0)

#define HAL_CL_PBMP_TO_PP_PBMP(__unit__, __cl_pbmp__, __pp_pbmp__)                               \
    do {                                                                                         \
        uint32 __p, __idx;                                                                       \
        osal_memset(__pp_pbmp__, 0x0, HAL_BYTES_OF_WORD *HAL_PP_PBM_WORDS);                      \
        CLX_PORT_FOREACH(__cl_pbmp__, __p)                                                       \
        {                                                                                        \
            __idx = HAL_CL_PORT_TO_PLANE((__unit__), __p) * HAL_PP_BMP_WORDS_PER_PLANE +         \
                (HAL_CL_PORT_TO_PLANE_PORT((__unit__), __p) >> 5);                               \
            ((__pp_pbmp__)[__idx]) |= 1U << (HAL_CL_PORT_TO_PLANE_PORT((__unit__), __p) & 0x1F); \
        }                                                                                        \
    } while (0)

#define HAL_PP_PBMP_TO_CL_PBMP(__unit__, __pp_pbmp__, __cl_pbmp__)                               \
    do {                                                                                         \
        uint32 __pn, __p, __idx, __cl_port;                                                      \
        osal_memset(__cl_pbmp__, 0x0, sizeof(clx_port_bitmap_t));                                \
        for (__pn = 0; __pn < HAL_PLANE_NUM(__unit__); __pn++) {                                 \
            for (__p = HAL_PLANE_ETH_PORT_MIN; __p <= HAL_PLANE_ETH_PORT_MAX(__unit__); __p++) { \
                __idx = __pn * HAL_PP_BMP_WORDS_PER_PLANE + (__p >> 5);                          \
                if (__pp_pbmp__[__idx] & (1U << (__p & 0x1F))) {                                 \
                    __cl_port = HAL_PLANE_PORT_TO_CL_PORT(__unit__, __pn, __p);                  \
                    if (HAL_INVALID_ID != __cl_port) {                                           \
                        CLX_PORT_ADD(__cl_pbmp__, __cl_port);                                    \
                    }                                                                            \
                }                                                                                \
            }                                                                                    \
        }                                                                                        \
    } while (0)

/* DMA R/W uses 16-based address */
#define HAL_DMA_MEM_ALLOC(__ptr_orig__, __ptr_align__, __size__)                           \
    do {                                                                                   \
        (__ptr_orig__) = osal_dma_alloc((__size__) + 32);                                  \
        if (NULL != (__ptr_orig__)) {                                                      \
            (__ptr_align__) =                                                              \
                (void *)((char *)(__ptr_orig__) + 16 - ((clx_huge_t)(__ptr_orig__) % 16)); \
        } else {                                                                           \
            (__ptr_align__) = NULL;                                                        \
        }                                                                                  \
    } while (0)

/* DATA TYPE DECLARATIONS
 */
/* Start of Auto-gen Chip Enum */
typedef enum {
    HAL_PLANE_SIG_ASIC_ETH_PORT = 0,
    HAL_PLANE_PORT_ASIC_ETH_PORT = 1,
    HAL_PLANE_PORT_ASIC_FAB_PORT = 2,
    HAL_PLANE_FAB_ASIC_FAB_PORT = 3
} hal_plane_mode_enum_t;

typedef enum {
    HAL_UMAC_SIG_ASIC_ETH_PORT = 0,
    HAL_UMAC_PORT_ASIC_ETH_PORT = 1,
    HAL_UMAC_PORT_ASIC_FAB_PORT = 2,
    HAL_UMAC_FAB_ASIC_ETH_PORT = 3,
    HAL_UMAC_FAB_ASIC_FAB_PORT = 4
} hal_umac_mode_enum_t;

typedef enum {
    HAL_TM_HASH_ITMH = 0,
    HAL_TM_HASH_LCL_PHY_PORT = 1,
    HAL_TM_HASH_SYS_PHY_PORT = 2
} hal_tm_hash_mode_enum_t;

typedef enum {
    HAL_ETM_DROP_RSN_NONE = 0,
    HAL_ETM_DROP_RSN_SRC_SUPP = 1,
    HAL_ETM_DROP_RSN_INFO = 2
} hal_etm_drop_rsn_enum_t;

typedef enum {
    HAL_PORT_RECIR_0 = 32,
    HAL_PORT_RECIR_1 = 33,
    HAL_PORT_CPI = 34,
    HAL_PORT_PDMA = 35
} hal_int_port_num_enum_t;

typedef enum {
    HAL_VID_CTL_PUSH_0 = 0,
    HAL_VID_CTL_PUSH_1 = 1,
    HAL_VID_CTL_PUSH_2 = 2,
    HAL_VID_CTL_PUSH_2ND = 3,
    HAL_VID_CTL_COPY_1 = 4,
    HAL_VID_CTL_COPY_2 = 5,
    HAL_VID_CTL_AS_IS = 6,
    HAL_VID_CTL_NO_L2 = 7
} hal_vid_ctl_typ_enum_t;

typedef enum {
    HAL_LBL_UNK = 0,
    HAL_LBL_IPV4 = 1,
    HAL_LBL_IPV6 = 2,
    HAL_LBL_ELI = 3,
    HAL_LBL_GAL = 4,
    HAL_LBL_XL = 5,
    HAL_LBL_RSVD = 6,
    HAL_LBL_UHP_P2P = 7,
    HAL_LBL_UHP_MP = 8,
    HAL_LBL_UAL = 9,
    HAL_LBL_EL = 10,
    HAL_LBL_ESPL = 11,
    HAL_LBL_REG = 12,
    HAL_LBL_PWEL = 13
} hal_lbl_typ_enum_t;

typedef enum {
    HAL_ITMH_U_ETH = 0,
    HAL_ITMH_U_FAB = 1,
    HAL_ETMH_U_FAB = 2,
    HAL_ETMH_U_ETH = 3
} hal_tmh_typ_enum_t;

typedef enum {
    HAL_FABH_U_UC_REG = 0,
    HAL_FABH_U_UC_NVO3 = 1,
    HAL_FABH_U_MC = 2
} hal_fabh_typ_enum_t;

typedef enum {
    HAL_IP_FRG_NONE = 0,       /* 00 */
    HAL_IP_FRG_1ST = 1,        /* 01 */
    HAL_IP_FRG_MID = 2,        /* 10 */
    HAL_IP_FRG_LAST = 3,       /* 11 */
    HAL_IP_FRG_1ST_NONE = 0x0, /* 0* */
    HAL_IP_FRG_MID_LAST = 0x2, /* 1* */
} hal_ip_frg_typ_enum_t;

typedef enum {
    HAL_SRV_L2 = 0,
    HAL_SRV_L25_MPLS = 1,
    HAL_SRV_L3 = 2,
    HAL_SRV_EGR = 3,
    HAL_SRV_L25_NSH = 4,
} hal_srv_typ_enum_t;

typedef enum {
    HAL_DECAP_ACT_NONE = 0,
    HAL_DECAP_ACT_MPLS_1_LBL = 1,
    HAL_DECAP_ACT_MPLS_2_LBL = 2,
    HAL_DECAP_ACT_MPLS_3_LBL = 3,
    HAL_DECAP_ACT_MPLS_4_LBL = 4,
} hal_decap_act_typ_enum_t;

typedef enum {
    HAL_L2_IP_MC_NONE = 0,
    HAL_L2_IP_MC_XG = 1,
    HAL_L2_IP_MC_SG = 2,
    HAL_L2_IP_MC_XG_SG = 3
} hal_l2_ip_mc_typ_enum_t;

typedef enum {
    HAL_URPF_NONE = 0,
    HAL_URPF_LOOSE = 1,
    HAL_URPF_STRICT = 2,
    HAL_URPF_LOOSE_IGN_DFLT_RTE = 3
} hal_urpf_typ_enum_t;

typedef enum { HAL_REWR_NONE = 0, HAL_REWR_SIG = 1, HAL_REWR_DBL = 2 } hal_rewr_typ_enum_t;

typedef enum {
    HAL_CNT_IDX_IPP_L3_INTF = 0,
    HAL_CNT_IDX_IPP_L2_INTF = 1,
    HAL_CNT_IDX_IPP_LCL_INTF_UL = 2,
    HAL_CNT_IDX_IPP_LCL_INTF_EP = 3,
    HAL_CNT_IDX_IPP_VRF = 4,
    HAL_CNT_IDX_IPP_FDID = 5
} hal_cnt_idx_ipp_typ_enum_t;

typedef enum {
    HAL_CNT_IDX_EPP_L2_INTF = 0,
    HAL_CNT_IDX_EPP_LCL_INTF = 1,
    HAL_CNT_IDX_EPP_EP_DFLT = 2,
    HAL_CNT_IDX_EPP_L3_INTF = 3
} hal_cnt_idx_epp_typ_enum_t;

typedef enum {
    HAL_MTR_IDX_IPP_L3_INTF = 0,
    HAL_MTR_IDX_IPP_L2_INTF = 1,
    HAL_MTR_IDX_IPP_LCL_INTF_UL = 2,
    HAL_MTR_IDX_IPP_LCL_INTF_EP = 3,
    HAL_MTR_IDX_IPP_VRF = 4,
    HAL_MTR_IDX_IPP_FDID = 5
} hal_mtr_idx_ipp_typ_enum_t;

typedef enum {
    HAL_COLOR_GREEN = 0,
    HAL_COLOR_YELLOW = 1,
    HAL_COLOR_RED_0 = 2,
    HAL_COLOR_RED_1 = 3
} hal_color_enum_t;

typedef enum {
    HAL_CIA_MTR_MODE_SIG_QOS = 0,
    HAL_CIA_MTR_MODE_ALL_FAVOR_GREEN = 1,
    HAL_CIA_MTR_MODE_ALL_FAVOR_RED = 2,
    HAL_CIA_MTR_MODE_ALL_FAVOR_QOS = 3
} hal_cia_mtr_mode_enum_t;

typedef enum { HAL_CIA_CNT_PER_MTR = 0, HAL_CIA_CNT_PER_FNL = 1 } hal_cia_cnt_mode_enum_t;

typedef enum {
    HAL_MTR_COLOR_RES_AND = 0,
    HAL_MTR_COLOR_RES_OR = 1,
    HAL_MTR_COLOR_RES_FAVOR_CIR = 2,
    HAL_MTR_COLOR_RES_FAVOR_INTF = 3,
    HAL_MTR_COLOR_RES_FAVOR_DOMAIN = 4
} hal_mtr_color_res_mode_enum_t;

typedef enum {
    HAL_CNT_MODE_DISABLE = 0,
    HAL_CNT_MODE_FCNT = 1,
    HAL_CNT_MODE_BCNT = 2
} hal_cnt_mode_enum_t;

typedef enum {
    HAL_CNT_CFG_DISABLE = 0,
    HAL_CNT_CFG_FWD = 1,
    HAL_CNT_CFG_DROP = 2,
    HAL_CNT_CFG_ALL = 3
} hal_cnt_cfg_typ_enum_t;

typedef enum {
    HAL_VLAN_TAG_MODE_1Q_1AD = 0,
    HAL_VLAN_TAG_MODE_24B = 1,
    HAL_VLAN_TAG_MODE_1Q_1AD_0 = 2,
    HAL_VLAN_TAG_MODE_1Q_1AD_1 = 3
} hal_vlan_tag_mode_enum_t;

typedef enum {
    HAL_IDS_KEY_L2_LCL_INTF_1X_U_VM = 0,
    HAL_IDS_KEY_L2_LCL_INTF_1X_U_VEPA = 1,
    HAL_IDS_KEY_L2_LCL_INTF_1X_U_IPV4 = 2,
} hal_ids_key_l2_lcl_intf1x_typ_enum_t;

typedef enum { HAL_IDS_KEY_TCAM_TNL_DECAP_1X_U_IPV4 = 0 } hal_ids_key_tcam_tnl_decap1x_typ_enum_t;

typedef enum {
    HAL_IDS_RSLT_SRV_MPLS_L3_IPV4 = 0,
    HAL_IDS_RSLT_SRV_MPLS_L3_IPV6 = 1,
    HAL_IDS_RSLT_SRV_MPLS_L3_IP_PSR_0 = 2,
    HAL_IDS_RSLT_SRV_MPLS_L3_IP_PSR_1 = 3
} hal_ids_rslt_srv_mpls_l3_ip_typ_enum_t;

typedef enum {
    HAL_IDS_KEY_SRV_1X_U_NSH = 0,
    HAL_IDS_KEY_SRV_1X_U_PS = 1,
    HAL_IDS_KEY_SRV_1X_U_MPLS_1_LBL = 2,
    HAL_IDS_KEY_SRV_1X_U_MPLS_2_LBL = 3
} hal_ids_key_srv1x_typ_enum_t;

typedef enum {
    HAL_IDS_KEY_SRV_2X_U_MPLS_3_LBL = 0,
    HAL_IDS_KEY_SRV_2X_U_MPLS_4_LBL = 1
} hal_ids_key_srv2x_typ_enum_t;

typedef enum {
    HAL_IDS_RSLT_SRV_U_L2_INTF = 0,
    HAL_IDS_RSLT_SRV_U_MPLS_L2 = 1,
    HAL_IDS_RSLT_SRV_U_MPLS_L3 = 2
} hal_ids_rslt_srv_typ_enum_t;

typedef enum {
    HAL_RSLT_RANGE_PROF_U_REG = 0,
    HAL_RSLT_RANGE_PROF_U_PROG = 1
} hal_rslt_range_prof_type_enum_t;

typedef enum {
    HAL_ILE_KEY_1X_U_FLW = 1,
    HAL_ILE_KEY_1X_U_L2_FDB = 2,
    HAL_ILE_KEY_1X_U_L2_FDB_INDIR_FLW_LBL_VLD = 3,
    HAL_ILE_KEY_1X_U_L3_IPV4_XA = 4,
    HAL_ILE_KEY_1X_U_L3_IPV4_LPM = 4,
    HAL_ILE_KEY_1X_U_L3_IPV4_LPM_INDIR_FLW_LBL_VLD = 5,
    HAL_ILE_KEY_1X_U_L2_IPV4_XG = 6,
    HAL_ILE_KEY_1X_U_FCOE = 7,
    HAL_ILE_KEY_1X_U_L25_NON_MPLS = 8,
    HAL_ILE_KEY_1X_U_FCOE_ZONING = 9,
    HAL_ILE_KEY_1X_U_L2_FDB_IS_STATIC = 10,
    HAL_ILE_KEY_1X_U_L2_FDB_IS_STATIC_INDIR_FLW_LBL_VLD = 11,
    HAL_ILE_KEY_1X_U_L25_MPLS_LBL_1 = 12,
    HAL_ILE_KEY_1X_U_L25_MPLS_LBL_2 = 13,
    HAL_ILE_KEY_1X_U_L25_MPLS_LBL_3 = 14,
    HAL_ILE_KEY_1X_U_FAB_MAP = 15
} hal_ile_key1x_typ_enum_t;

typedef enum {
    HAL_ILE_KEY_1X_U_L25_PE_FDB = 0,
    HAL_ILE_KEY_1X_U_L25_NSH = 1,
} hal_ile_key1x_l25_typ_enum_t;

typedef enum {
    HAL_ILE_KEY_2X_U_L3_IPV6_XA = 1,
    HAL_ILE_KEY_2X_U_L2_IPV4_SG = 2,
    HAL_ILE_KEY_2X_U_L3_IPV4_SG = 3,
    HAL_ILE_KEY_2X_U_FLW = 4,
    HAL_ILE_KEY_2X_U_IPV4_SRC_GUARD = 5,
    HAL_ILE_KEY_2X_U_FCOE_SRC_GUARD = 6,
    HAL_ILE_KEY_2X_U_RSVD_4 = 7,
    HAL_ILE_KEY_2X_U_L25_MPLS = 9,
    HAL_ILE_KEY_2X_RSVD_0 = 12,
    HAL_ILE_KEY_2X_RSVD_1 = 13,
    HAL_ILE_KEY_2X_RSVD_2 = 14,
    HAL_ILE_KEY_2X_RSVD_3 = 15
} hal_ile_key2x_enum_t;

typedef enum {
    HAL_ILE_KEY_4X_U_L2_IPV6_XG = 1,
    HAL_ILE_KEY_4X_U_L2_IPV6_SG = 2,
    HAL_ILE_KEY_4X_U_L3_IPV6_SG = 3,
    HAL_ILE_KEY_4X_U_L3_IPV6_XA = 4,
    HAL_ILE_KEY_4X_U_L3_IPV6_LPM = 4,
    HAL_ILE_KEY_4X_U_L3_IPV6_LPM_INDIR_FLW_LBL_VLD = 5,
    HAL_ILE_KEY_4X_U_FLW = 6,
    HAL_ILE_KEY_4X_U_IPV6_SRC_GUARD = 7,
} hal_ile_key4x_enum_t;

typedef enum {
    HAL_ILE_KEY_TCAM_1X_U_L3_IPV4_XA = 0,
    HAL_ILE_KEY_TCAM_1X_U_FCOE = 1
} hal_ile_tcam1x_enum_t;

typedef enum {
    HAL_IKG_BOFFSET_ENCAP = 0,
    HAL_IKG_BOFFSET_ETH = 1,
    HAL_IKG_BOFFSET_L3 = 2,
    HAL_IKG_BOFFSET_L4 = 3
} hal_ikg_byte_offset_typ_enum_t;

typedef enum {
    HAL_DECAP_GRE_ETH = 0,
    HAL_DECAP_GRE_L3_NO_KEY = 1,
    HAL_DECAP_GRE_L3_W_KEY = 2,
    HAL_DECAP_IP_ETH = 3,
    HAL_DECAP_VXLAN_ETH = 4,
    HAL_DECAP_VXLAN_L3 = 5,
    HAL_DECAP_IPOIP = 6,
    HAL_DECAP_GRE_ERSPAN = 7,
    HAL_DECAP_FLEX_L3_0 = 8,
    HAL_DECAP_FLEX_L3_1 = 9,
    HAL_DECAP_FLEX_L3_2 = 10,
    HAL_DECAP_FLEX_L3_3 = 11,
    HAL_DECAP_FLEX_L2_0 = 12,
    HAL_DECAP_FLEX_L2_1 = 13,
    HAL_DECAP_FLEX_L2_2 = 14,
    HAL_DECAP_FLEX_L2_3 = 15
} hal_decap_ip_tnl_enum_t;

typedef enum {
    HAL_ICC_DECAP_NONE = 0,
    HAL_ICC_DECAP_MPLS = 2,
    HAL_ICC_DECAP_GRE = 3,
    HAL_ICC_DECAP_VXLAN_GPE = 4,
    HAL_ICC_DECAP_VXLAN_BAS = 5,
    HAL_ICC_DECAP_IP_RAW = 6
} hal_icc_decap_typ_enum_t;

typedef enum {
    HAL_RSLT_IDX_FUL = 0,
    HAL_RSLT_IDX_DBL = 1,
    HAL_RSLT_IDX_SIG = 2
} hal_rslt_idx_typ_enum_t;

typedef enum {
    HAL_RSLT_BNK_L2 = 0,
    HAL_RSLT_BNK_L3 = 1,
    HAL_RSLT_BNK_L4 = 2,
    HAL_RSLT_BNK_L2_INDIR = 3,
    HAL_RSLT_BNK_L3_INDIR = 4
} hal_rslt_bnk_typ_enum_t;

typedef enum { HAL_EXCPT_NONE = 0, HAL_EXCPT_REDIR = 1, HAL_EXCPT_DROP = 2 } hal_excpt_typ_enum_t;

typedef enum {
    HAL_RSLT_U_L2 = 0,
    HAL_RSLT_U_L25_MPLS = 1,
    HAL_RSLT_U_L3_UC = 3,
    HAL_RSLT_U_L3_MC = 4,
    HAL_RSLT_U_FLW = 5,
    HAL_RSLT_U_FLW_ICIA = 6,
    HAL_RSLT_U_FLW_ICIA_3X = 7
} hal_rslt_typ_enum_t;

typedef enum {
    HAL_FLW_LBL_CTL_INVLD = 0,
    HAL_FLW_LBL_CTL_L2_DA = 1,
    HAL_FLW_LBL_CTL_L3_DA = 2,
    HAL_FLW_LBL_CTL_REWR = 3
} hal_flw_lbl_ctl_typ_enum_t;

typedef enum {
    HAL_MRPF_FAIL_DROP = 0,
    HAL_MRPF_FAIL_TRAP = 1,
    HAL_MRPF_FAIL_L2 = 2,
    HAL_MRPF_FAIL_NOP = 3
} hal_mrpf_fail_act_typ_enum_t;

typedef enum {
    HAL_ICC_ACT_NONE = 0,
    HAL_ICC_ACT_CPU_QUE = 1,
    HAL_ICC_ACT_REDIR = 2,
    HAL_ICC_ACT_REDIR_IF_FWD = 3,
    HAL_ICC_ACT_CP2CPU_IF_FWD = 4,
    HAL_ICC_ACT_SUPP_CPU = 5,
    HAL_ICC_ACT_DROP_ALL = 6
} hal_icc_act_typ_enum_t;

typedef enum {
    HAL_PPH_HIT_IDX_SRV = 0,
    HAL_PPH_HIT_IDX_L2_0 = 1,
    HAL_PPH_HIT_IDX_L2_1 = 2,
    HAL_PPH_HIT_IDX_L3_0 = 3,
    HAL_PPH_HIT_IDX_L3_1 = 4,
    HAL_PPH_HIT_IDX_FLW = 5,
    HAL_PPH_HIT_IDX_ICIA = 6
} hal_pph_hit_idx_typ_enum_t;

typedef enum {
    HAL_WIDTH_1X = 0,
    HAL_WIDTH_2X = 1,
    HAL_WIDTH_4X = 2,
    HAL_WIDTH_HX = 3
} hal_width_enum_t;

typedef enum {
    HAL_TCAM_WIDTH_1X = 0,
    HAL_TCAM_WIDTH_2X_4X = 1,
    HAL_TCAM_WIDTH_HX = 2
} hal_tcam_width_enum_t;

typedef enum {
    HAL_EXM_L2 = 0,
    HAL_EXM_L25_L3 = 1,
    HAL_EXM_L25_L3_W_L2 = 2,
    HAL_EXM_FLW = 3,
    HAL_EXM_INTF_SET_CK = 4
} hal_exm_mode_enum_t;

typedef enum {
    HAL_HIT_BITS_DISABLE = 0,
    HAL_HIT_BITS_W3_2ND_ONLY = 1,
    HAL_HIT_BITS_W3_EITHER = 2,
    HAL_BIT_BITS_W1_SEPARATE = 3
} hal_hit_bits_mode_enum_t;

typedef enum {
    HAL_SRV_U_EP = 1,
    HAL_SRV_U_UL_BASE = 2,
    HAL_SRV_U_UL_NT1 = 3
} hal_srv_key_typ_enum_t;

typedef enum {
    HAL_FCM_INVLD = 0,
    HAL_FCM_1X = 1,
    HAL_FCM_2X = 2,
    HAL_FCM_4X = 3
} hal_fcm_cfg_enum_t;

typedef enum {
    HAL_FCM_OPCODE_NOP = 0,
    HAL_FCM_OPCODE_DEL = 1,
    HAL_FCM_OPCODE_INS = 2,
    HAL_FCM_OPCODE_RPL_BIT = 3,
    HAL_FCM_OPCODE_RPL_HI_NIBBLE = 4,
    HAL_FCM_OPCODE_RPL_LO_NIBBLE = 5,
    HAL_FCM_OPCODE_RPL_BLST = 6,
    HAL_FCM_OPCODE_RPL_BLST_W_MSK = 7
} hal_fcm_opcode_enum_t;

typedef enum {
    HAL_FCM_LAYER_L2 = 0,
    HAL_FCM_LAYER_L3 = 1,
    HAL_FCM_LAYER_L4 = 2
} hal_fcm_layer_enum_t;

typedef enum {
    HAL_ENCAP_NSH = 0,
    HAL_ENCAP_IP = 1,
    HAL_ENCAP_MPLS = 2,
} hal_encap_typ_enum_t;

typedef enum {
    HAL_VLAN_TAG_CTL_REMOVE_OUTER_TAG_AND_INNER_PRI_TAG = 0,
    HAL_VLAN_TAG_CTL_REMOVE_INNER_PRI_TAG = 1,
    HAL_VLAN_TAG_CTL_UNTAG = 2,
    HAL_VLAN_TAG_CTL_PRIO = 3,
    HAL_VLAN_TAG_CTL_TAG = 4
} hal_vlan_tag_ctl_enum_t;

typedef enum {
    HAL_EMI_LOU_BOFFSET_ETH = 1,
    HAL_EMI_LOU_BOFFSET_L3 = 2,
    HAL_EMI_LOU_BOFFSET_L4 = 3
} hal_lou_boffset_enum_t;

typedef enum {
    HAL_ITM_RSLT_DIL_UC_U_ETH = 0,
    HAL_ITM_RSLT_DIL_UC_U_FAB = 1
} hal_itm_rslt_dil_uc_typ_enum_t;

typedef enum {
    HAL_MET_CFG_MEL_PBM = 0,
    HAL_MET_CFG_MEL_FUL = 1,
    HAL_MET_CFG_MEL_LST_2 = 2,
    HAL_MET_CFG_MEL_LST_4 = 3
} hal_met_cfg_enum_t;
/* End of Auto-gen Chip Enum */

typedef enum {
    HAL_IDS_RSLT_L2_LCL_INIF_U_EP = 0,
    HAL_IDS_RSLT_L2_LCL_INIF_U_UL = 1,
} hal_ids_rslt_l2_lcl_inif_typ_enum_t;

typedef enum { HAL_IEV_RSLT_LAG_U_HW = 0, HAL_IEV_RSLT_LAG_U_SW = 1 } hal_iev_rslt_lag_type_enum_t;

typedef enum {
    HAL_EMI_KEY_L2_LCL_INTF_U_VEPA = 0,
    HAL_EMI_KEY_L2_LCL_INTF_U_VM = 1,
} hal_emi_key_l2_lcl_intf_typ_enum_t;

typedef enum {
    HAL_IP_TTL_ZERO = 0,
    HAL_IP_TTL_ONE = 1,
    HAL_IP_TTL_GT_ONE = 2,
} hal_ip_ttl_typ_enum_t;

typedef enum {
    HAL_UCP_PKG_MODE_NONE = 0,
    HAL_UCP_PKG_MODE_UP_TO_1 = 1,
    HAL_UCP_PKG_MODE_UP_TO_2 = 3,
} hal_ucp_pkg_mode_enum_t;

typedef enum {
    HAL_EMI_RSLT_2X_U_FCM = 0,
    HAL_EMI_RSLT_2X_U_NSH = 1,
} hal_emi_rslt_2x_typ_enum_t;

typedef enum {
    HAL_EMI_RSLT_IOAM_TYP_GRE = 0,
    HAL_EMI_RSLT_IOAM_TYP_GPE = 1,
    HAL_EMI_RSLT_IOAM_TYP_GENEVE = 2,
    HAL_EMI_RSLT_IOAM_TYP_INVALID = 3,
} hal_emi_rslt_ioam_typ_enum_t;

typedef enum { HAL_TMV_RSLT_LAG_U_SW = 0, HAL_TMV_RSLT_LAG_U_HW = 1 } hal_tmv_rslt_lag_type_enum_t;

typedef enum {
    HAL_EFUSE_PAGE_0 = 0,
    HAL_EFUSE_PAGE_1 = 1,
    HAL_EFUSE_PAGE_2 = 2,
    HAL_EFUSE_PAGE_3 = 3,
    HAL_EFUSE_PAGE_4 = 4,
    HAL_EFUSE_PAGE_5 = 5,
    HAL_EFUSE_PAGE_6 = 6,
    HAL_EFUSE_PAGE_7 = 7
} hal_efuse_page_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS */

#endif /* #ifndef HAL_CONST_CMN_H */
