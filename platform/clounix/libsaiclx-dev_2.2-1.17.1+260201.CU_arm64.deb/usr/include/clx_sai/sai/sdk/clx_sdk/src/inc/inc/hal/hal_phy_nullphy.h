/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_phy_nullphy.h
 * PURPOSE:
 *      It provide NULLPHY API.
 * NOTES:
 *
 */
#ifndef HAL_PHY_NULLPHY_H
#define HAL_PHY_NULLPHY_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <hal/hal_phy.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef struct hal_phy_nullphy_sw_db_s {
    hal_phy_admin_state_type_t admin_state;
    hal_phy_speed_type_t speed;
    hal_phy_eee_type_t eee;
    hal_phy_eee_mode_type_t eee_mode;
    hal_phy_fec_type_t fec;
    hal_phy_loopback_type_t loopback;
    hal_phy_pma_intf_type_t pma_intf;
    hal_phy_pmd_intf_type_t pmd_intf;
    hal_phy_anlt_type_t anlt;
    hal_phy_an_re_an_type_t an_restart;
    hal_phy_an_speed_type_t an_speed;
    hal_phy_an_eee_type_t an_eee;
    hal_phy_an_fec_type_t an_fec;
    hal_phy_an_fc_type_t an_fc;
    hal_phy_an_duplex_type_t an_duplex;
    hal_phy_an_rf_type_t an_rf;
    int32 temperature;
    hal_phy_prbs_pattern_type_t prbs_pattern;
    hal_phy_prbs_checker_type_t prbs_checker;
} hal_phy_nullphy_sw_db_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief Init the null PHY drive per unit.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_nullphy_init(const uint32 unit);

/**
 * @brief Deinit the null PHY drive per unit.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_nullphy_deinit(const uint32 unit);

#endif /* End of HAL_PHY_NULLPHY_H */
