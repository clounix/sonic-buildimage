/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_tm_pfc.h
 * PURPOSE:
 *      It provides TM module PFC API.
 * NOTES:
 *
 *
 */

#ifndef HAL_MT_NB_TM_PFC_H
#define HAL_MT_NB_TM_PFC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_tm.h>
#include <osal/osal.h>
#include <tob/tob_tbl.h>
#include <hal/hal.h>
#include <hal/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_KG_TM_MAX_PFC_SC_NUM (1)
/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/*********************************************/
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* TC classification */
typedef enum hal_mt_kg_tm_pfc_ipl_tc_classific_action_e {
    HAL_MT_KG_TM_PFC_IPL_TC_LOSSY0 = 0,
    HAL_MT_KG_TM_PFC_IPL_TC_LOSSLESS0 = 1,
    HAL_MT_KG_TM_PFC_IPL_TC_LAST
} hal_mt_kg_tm_pfc_ipl_tc_classific_action_t;

typedef enum hal_mt_kg_tm_pfc_epl_tc_classific_action_e {
    HAL_MT_KG_TM_PFC_EPL_TC_LOSSY0 = 0, /* not the same as NB */
    HAL_MT_KG_TM_PFC_EPL_TC_LOSSLESS0 = 1,
    HAL_MT_KG_TM_PFC_EPL_TC_LAST
} hal_mt_kg_tm_pfc_epl_tc_classific_action_t;

/* IPL FIFO classification */
typedef enum hal_mt_kg_tm_pfc_ipl_plq_e {
    HAL_MT_KG_TM_PFC_IPL_PLQ0 = 0, /* plq0 => lossy0 */
    HAL_MT_KG_TM_PFC_IPL_PLQ1,     /* plq1 => lossless0 */
    HAL_MT_KG_TM_PFC_IPL_PL_LAST
} hal_mt_kg_tm_pfc_ipl_plq_t;

/* IPL FIFO classification */
typedef enum hal_mt_kg_tm_pfc_data_ipl_plq_e {
    HAL_MT_KG_TM_PFC_DATA_IPL_PLQ0 = 0, /* plq0 => lossy0 */
    HAL_MT_KG_TM_PFC_DATA_IPL_PLQ1,     /* plq1 => lossy1 */
    HAL_MT_KG_TM_PFC_DATA_IPL_PLQ2,     /* plq2 => lossy2 */
    HAL_MT_KG_TM_PFC_DATA_IPL_PLQ3,     /* plq3 => lossless1 */
    HAL_MT_KG_TM_PFC_DATA_IPL_PL_LAST
} hal_mt_kg_tm_pfc_data_ipl_plq_t;

/**
 * @brief The function is used to set the mapping of the PCP and the queue group.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Physical port id.
 * @param [in]    queue      - Ingress or egress queue.
 * @param [in]    ptr_pfc    - PFC interface structl.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter. CLX_E_TABLE_FULL,
 *                                         -- Table is full.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
hal_mt_kg_tm_pfc_mapping_set(const uint32 unit,
                             const uint32 port,
                             const uint32 queue,
                             const clx_tm_pfc_mapping_cfg_t *ptr_pfc);

/**
 * @brief The function is used to get the mapping of the PCP and the queue group.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port id.
 * @param [in]     queue      - Ingress or egress queue.
 * @param [out]    ptr_pfc    - PFC interface struct.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Other error.
 */
clx_error_no_t
hal_mt_kg_tm_pfc_mapping_get(const uint32 unit,
                             const uint32 port,
                             const uint32 queue,
                             clx_tm_pfc_mapping_cfg_t *ptr_pfc);

clx_error_no_t
hal_mt_kg_tm_pfc_rsrc_init(const uint32 unit);
clx_error_no_t
hal_mt_kg_tm_pfc_cfg_init(const uint32 unit);
clx_error_no_t
hal_mt_kg_tm_pfc_rsrc_deinit(const uint32 unit);
clx_error_no_t
hal_mt_kg_tm_pfc_flowctrl_mode_set(const uint32 unit, const uint32 port, const hal_tm_fc_t mode);

clx_error_no_t
hal_mt_kg_tm_pfc_que_by_pri_get(const uint32 unit,
                                const uint32 port,
                                const uint32 pri,
                                uint32 *ptr_queue);

clx_error_no_t
hal_mt_kg_tm_pfc_wd_state_oper_event_handle(const uint32 unit,
                                            const clx_port_t port,
                                            const uint8 queue_id,
                                            const hal_tm_pfcwd_event_t event,
                                            hal_tm_pfcwd_queue_entry_t *ptr_runing_entry);

clx_error_no_t
hal_mt_kg_tm_pfc_wd_state_recovery_event_handle(const uint32 unit,
                                                const clx_port_t port,
                                                const uint8 queue_id,
                                                const hal_tm_pfcwd_event_t event,
                                                hal_tm_pfcwd_queue_entry_t *ptr_runing_entry);

clx_error_no_t
hal_mt_kg_tm_pfc_wd_state_cfg_not_ready_event_handle(const uint32 unit,
                                                     const clx_port_t port,
                                                     const uint8 queue_id,
                                                     const hal_tm_pfcwd_event_t event,
                                                     hal_tm_pfcwd_queue_entry_t *ptr_runing_entry);

clx_error_no_t
hal_mt_kg_tm_pfc_wd_state_disable_event_handle(const uint32 unit,
                                               const clx_port_t port,
                                               const uint8 queue_id,
                                               const hal_tm_pfcwd_event_t event,
                                               hal_tm_pfcwd_queue_entry_t *ptr_runing_entry);
clx_error_no_t
hal_mt_kg_tm_pfc_wd_state_event_storm_handle(const uint32 unit,
                                             const clx_port_t port,
                                             const uint8 queue_id,
                                             const hal_tm_pfcwd_event_t event,
                                             hal_tm_pfcwd_queue_entry_t *ptr_runing_entry);
clx_error_no_t
hal_mt_kg_tm_pfc_state_get(const uint32 unit,
                           const uint32 port,
                           const clx_tm_handler_t handler,
                           clx_tm_pfc_state_t *ptr_state);

clx_error_no_t
hal_mt_kg_tm_pfc_rx_pri_mask_set(const uint32 unit, const uint32 port, boolean mask_en);

clx_error_no_t
hal_mt_kg_tm_pfc_warm_pfcwd_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_kg_tm_pfc_warm_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_kg_tm_pfc_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_kg_tm_pfc_wd_warm_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

#endif /*end of HAL_MT_KG_TM_PFC_H*/
