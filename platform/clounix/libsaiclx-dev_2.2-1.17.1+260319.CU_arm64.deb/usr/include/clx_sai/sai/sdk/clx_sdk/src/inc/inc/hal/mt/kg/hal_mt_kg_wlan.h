/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_wlan.h
 * PURPOSE:
 *      It provide wlan hal chip layer api.
 * NOTES:
 *
 */

#ifndef HAL_MT_KG_WLAN_H
#define HAL_MT_KG_WLAN_H

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief Initialize WLAN module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_wlan_init(const uint32 unit);

/**
 * @brief Deinitialize WLAN module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_wlan_deinit(const uint32 unit);

/**
 * @brief Dump WLAN swdb information.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    flags    - Dump flags.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_kg_wlan_db_dump(const uint32 unit, const uint32 flags);

clx_error_no_t
hal_mt_kg_wlan_capwap_prof_add(const uint32 unit,
                               const uint32 id,
                               const clx_wlan_capwap_prof_t *ptr_profile);

clx_error_no_t
hal_mt_kg_wlan_capwap_prof_del(const uint32 unit, const uint32 id);

clx_error_no_t
hal_mt_kg_wlan_capwap_prof_get(const uint32 unit,
                               const uint32 id,
                               clx_wlan_capwap_prof_t *ptr_profile);

clx_error_no_t
hal_mt_kg_wlan_port_create(const uint32 unit,
                           const clx_wlan_capwap_t *ptr_capwap,
                           clx_port_t *ptr_port);

clx_error_no_t
hal_mt_kg_wlan_port_destroy(const uint32 unit, const clx_port_t port);

clx_error_no_t
hal_mt_kg_wlan_port_get(const uint32 unit,
                        const clx_wlan_capwap_t *ptr_capwap,
                        clx_port_t *ptr_port);

clx_error_no_t
hal_mt_kg_wlan_port_hdr_get(const uint32 unit,
                            const clx_port_t port,
                            clx_wlan_capwap_t *ptr_capwap);

clx_error_no_t
hal_mt_kg_wlan_port_trav(const uint32 unit, const clx_wlan_port_trav_func_t cb, void *ptr_cookie);

clx_error_no_t
hal_mt_kg_wlan_encap_add(const uint32 unit,
                         const clx_port_t port,
                         const clx_tnl_encap_info_t *ptr_encap_info);

clx_error_no_t
hal_mt_kg_wlan_encap_del(const uint32 unit, const clx_port_t port);

clx_error_no_t
hal_mt_kg_wlan_encap_get(const uint32 unit,
                         const clx_port_t port,
                         clx_tnl_encap_info_t *ptr_encap_info);

clx_error_no_t
hal_mt_kg_wlan_encap_trav(const uint32 unit, const clx_wlan_encap_trav_func_t cb, void *ptr_cookie);

clx_error_no_t
hal_mt_kg_wlan_decap_add(const uint32 unit,
                         const clx_port_t port,
                         const clx_tnl_decap_info_t *ptr_decap_info);

clx_error_no_t
hal_mt_kg_wlan_decap_del(const uint32 unit, const clx_port_t port);

clx_error_no_t
hal_mt_kg_wlan_decap_get(const uint32 unit,
                         const clx_port_t port,
                         clx_tnl_decap_info_t *ptr_decap_info);

clx_error_no_t
hal_mt_kg_wlan_decap_trav(const uint32 unit, const clx_wlan_decap_trav_func_t cb, void *ptr_cookie);

clx_error_no_t
hal_mt_kg_wlan_station_add(const uint32 unit, const clx_wlan_station_t *ptr_sta_mac);

clx_error_no_t
hal_mt_kg_wlan_station_del(const uint32 unit, const clx_wlan_station_t *ptr_sta_mac);

clx_error_no_t
hal_mt_kg_wlan_station_set(const uint32 unit, const clx_wlan_station_t *ptr_sta_mac);

clx_error_no_t
hal_mt_kg_wlan_station_get(const uint32 unit, clx_wlan_station_t *ptr_sta_mac);

clx_error_no_t
hal_mt_kg_wlan_port_vlan_bd_bind(const uint32 unit,
                                 const clx_port_t port,
                                 const uint32 svid,
                                 const uint32 cvid,
                                 const clx_bridge_domain_t bdid);

clx_error_no_t
hal_mt_kg_wlan_port_vlan_bd_unbind(const uint32 unit,
                                   const clx_port_t port,
                                   const uint32 svid,
                                   const uint32 cvid);

clx_error_no_t
hal_mt_kg_wlan_port_vlan_bd_get(const uint32 unit,
                                const clx_port_t port,
                                const uint32 svid,
                                const uint32 cvid,
                                clx_bridge_domain_t *ptr_bdid);

clx_error_no_t
hal_mt_kg_wlan_port_rid_max_get(const uint32 unit,
                                const uint32 nvo3_encap_idx,
                                uint32 *ptr_rid_max);

clx_error_no_t
hal_mt_kg_wlan_sw_init_get(const uint32 unit, const uint32 nvo3_encap_idx, clx_port_t *ptr_port);

clx_error_no_t
hal_mt_kg_wlan_hw_init_get(const uint32 unit,
                           const clx_port_t wlan_port,
                           uint32 *ptr_nvo3_encap_idx);
#endif /* End of HAL_MT_KG_WLAN_H */