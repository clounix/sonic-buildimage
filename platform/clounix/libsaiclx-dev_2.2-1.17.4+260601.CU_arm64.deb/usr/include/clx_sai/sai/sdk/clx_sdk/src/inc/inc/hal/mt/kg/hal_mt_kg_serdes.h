/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_serdes.h
 * PURPOSE:
 *      It provide HAL_MT_KG_SERDES module API.
 * NOTES:
 *
 */

#ifndef HAL_MT_KG_SERDES_H
#define HAL_MT_KG_SERDES_H

/* INCLUDE FILE DECLARATIONS
 */
#include <string.h>
#include <stdlib.h>
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <hal/mt/kg/hal_mt_kg_pma.h>
#include <clx/clx_cfg.h>
#include <hal/hal_phy.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MT_KG_SERDES_MAX_MACRO     (164)
#define HAL_MT_KG_SERDES_D2D_MAX_MACRO (12)

/* DATA TYPE DECLARATIONS
 */

/*serdes speed*/
typedef enum hal_mt_kg_serdes_pma_phy_speed_type_e {
    HAL_MT_KG_PMA_PHY_SPEED_TYPE_56P25_PAM4 = 0x0,
    HAL_MT_KG_PMA_PHY_SPEED_TYPE_10P3125,
    HAL_MT_KG_PMA_PHY_SPEED_TYPE_25P78125,
    HAL_MT_KG_PMA_PHY_SPEED_TYPE_26P5625,
    HAL_MT_KG_PMA_PHY_SPEED_TYPE_53P125_NRZ,
    HAL_MT_KG_PMA_PHY_SPEED_TYPE_53P125_PAM4,
    HAL_MT_KG_PMA_PHY_SPEED_TYPE_106P25,
    HAL_MT_KG_PMA_PHY_SPEED_TYPE_112P5,
    HAL_MT_KG_PMA_PHY_SPEED_TYPE_LAST
} hal_mt_kg_serdes_pma_phy_speed_type_t;

typedef enum hal_mt_kg_serdes_type_e {
    HAL_MT_KG_SERDES_TYPE_ETH = 0,
    HAL_MT_KG_SERDES_TYPE_D2D,
    HAL_MT_KG_SERDES_TYPE_LAST
} hal_mt_kg_serdes_type_t;

typedef enum hal_mt_kg_serdes_rate_mode_e {
    FULL_RATE_MODE,
    HALF_RATE_MODE
} hal_mt_kg_serdes_rate_mode_t;

typedef enum hal_mt_kg_serdes_firmware_speed_e {
    SPEED_UNKNOWN = -1,
    SPEED_25G = 0,
    SPEED_26G = 1,
    SPEED_28G = 2, // 28.076177
    SPEED_50G = 3,
    SPEED_53G = 4,
    SPEED_56G = 5, // 56.25
    SPEED_100G = 6,
    SPEED_106G = 7,
    SPEED_112G = 8,
    SPEED_46G = 9,
    SPEED_92G = 10,
    SPEED_90G = 11,
    SPEED_88G = 12,
    SPEED_96G = 13,
} hal_mt_kg_serdes_firmware_speed_t;

typedef struct hal_mt_kg_serdes_cfg_s {
    hal_mt_kg_pma_lane_mode_t lane_mode;
    uint32 serdes_speed; // 106000 - PAM4_106g
    uint32 offset;
    uint32 eq;
    int32 tx_fir[4]; //{post1, main, pre1, pre2}
    uint32 tx_scale[4];
    uint32 slice_tx_polarity[12][16];
    uint32 slice_rx_polarity[12][16];
    uint32 refclk_tree[12]; // d2d phy only
    uint32 refclk_hz;       // default is 156250000Hz,no need to set
} hal_mt_kg_serdes_cfg_t;

extern hal_mt_kg_serdes_cfg_t d2d_default_cfg;

/*
 * @brief Download the serdes firmware.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    type    - Device type.
 * @return        CLX_E_OK - Operation succeeded
 * @return        CLX_E_OTHERS - Operation failed
 */
clx_error_no_t
hal_mt_kg_serdes_fw_download(const uint32 unit, const uint32 type);

/**
 * @brief Disable the PRBS for D2D PHY.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation succeeded.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_kg_serdes_d2d_prbs_disable(const uint32 unit);

/**
 * @brief Set the TX idle for D2D PHY.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    enable    - Enable or disable.
 * @return        CLX_E_OK        - Operation succeeded.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_kg_serdes_d2d_tx_idle_set(const uint32 unit, const uint32 enable);

clx_error_no_t
hal_mt_kg_serdes_d2d_prbs_clear(const uint32 unit, const uint32 slice_idx);

clx_error_no_t
hal_mt_kg_serdes_d2d_prbs_cnt_print(const uint32 unit,
                                    const uint32 slice_idx,
                                    clx_time_t *start_time);
/**
 * @brief Configure D2D serdes for specific slice indices.
 *
 * @param unit         Unit ID
 * @param slice_indices Array of slice indices to configure
 * @param slice_count   Number of slices in the array
 * @param serdes_cfg    Serdes configuration.
 *
 * @return        CLX_E_OK        - Successfully configured slices.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_kg_serdes_d2d_slice_cfg_set(const uint32 unit,
                                   const uint32 *slice_indices,
                                   uint32 slice_count,
                                   const hal_mt_kg_serdes_cfg_t *serdes_cfg);

/**
 * @brief Set the serdes configuration for D2D PHY.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    serdes_cfg    - Serdes configuration.
 * @return        CLX_E_OK        - Operation succeeded.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_kg_serdes_d2d_cfg_set(const uint32 unit, const hal_mt_kg_serdes_cfg_t *serdes_cfg);

/**
 * @brief Check D2D serdes firmware tuning adapter status for specific slice indices.
 *
 * This function checks the tuning status for specified slice indices only.
 * @param unit         Unit ID
 * @param slice_indices Array of slice indices to check
 * @param slice_count   Number of slices in the array.
 *
 * @return        CLX_E_OK         - Successfully checked tuning status.
 * @return        CLX_E_TIMEOUT    - Timeout waiting for tuning completion.
 * @return        CLX_E_OTHERS     - Other errors.
 */
clx_error_no_t
hal_mt_kg_serdes_d2d_slice_fw_tuning_adapter_status_check(const uint32 unit,
                                                          const uint32 *slice_indices,
                                                          uint32 slice_count);

/**
 * @brief Disable D2D serdes PRBS for specific slice indices.
 *
 * This function disables PRBS for specified slice indices only.
 * @param unit         Unit ID
 * @param slice_indices Array of slice indices to disable PRBS
 * @param slice_count   Number of slices in the array.
 *
 * @return        CLX_E_OK        - Successfully disabled PRBS.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_kg_serdes_d2d_slice_prbs_disable(const uint32 unit,
                                        const uint32 *slice_indices,
                                        uint32 slice_count);

/**
 * @brief Check D2D serdes firmware tuning adapter status for all slices.
 *
 * This function checks the tuning status for all slices.
 * @param unit         Unit ID.
 *
 * @return        CLX_E_OK         - Successfully checked tuning status.
 * @return        CLX_E_TIMEOUT    - Timeout waiting for tuning completion.
 * @return        CLX_E_OTHERS     - Other errors.
 */
clx_error_no_t
hal_mt_kg_serdes_d2d_fw_tuning_adapter_status_check(const uint32 unit);

clx_error_no_t
hal_mt_kg_serdes_anlt_intr_enable(uint32 unit, uint32 port, uint32 enable);

clx_error_no_t
hal_mt_kg_serdes_an_intr_stat_get(uint32 unit, uint32 port, uint32 *status);

clx_error_no_t
hal_mt_kg_serdes_lt_fail_intr_enable(uint32 unit, uint32 port, uint32 enable);

clx_error_no_t
hal_mt_kg_serdes_lt_fail_intr_get(uint32 unit, uint32 port, uint32 *status);

clx_error_no_t
hal_mt_kg_serdes_lt_fail_state_get(uint32 unit, uint32 port, uint32 *status);

clx_error_no_t
hal_mt_kg_serdes_reg_read(uint32 unit,
                          uint32 type,
                          uint32 slice_index,
                          uint32 reg_addr,
                          uint32 *reg_data);

clx_error_no_t
hal_mt_kg_serdes_reg_write(uint32 unit,
                           uint32 type,
                           uint32 slice_index,
                           uint32 reg_addr,
                           uint32 reg_data);

/**
 * @brief Read the serdes register field.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     type          - Device type.
 * @param [in]     slice_idx     - Slice index.
 * @param [in]     reg_addr      - Register address.
 * @param [in]     bit_offset    - Bit offset.
 * @param [in]     bit_width     - Bit width.
 * @param [out]    value         - Value.
 * @return         CLX_E_OK        - Operation succeeded.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_kg_serdes_reg_filed_read(const uint32 unit,
                                const uint32 type,
                                const uint32 slice_idx,
                                uint32 reg_addr,
                                const uint32 bit_offset,
                                const uint32 bit_width,
                                uint32 *value);

/**
 * @brief Write the serdes register field.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    type          - Device type.
 * @param [in]    slice_idx     - Slice index.
 * @param [in]    reg_addr      - Register address.
 * @param [in]    bit_offset    - Bit offset.
 * @param [in]    bit_width     - Bit width.
 * @param [in]    value         - Value.
 * @return        CLX_E_OK        - Operation succeeded.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_kg_serdes_reg_filed_write(const uint32 unit,
                                 const uint32 type,
                                 const uint32 slice_idx,
                                 uint32 reg_addr,
                                 const uint32 bit_offset,
                                 const uint32 bit_width,
                                 const uint32 value);

/**
 * @brief Stop the CLI server by sending kill command through Unix socket.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation succeeded.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_mt_kg_serdes_server_stop(uint32 unit);

#endif /* End of HAL_MT_KG_SERDES_H */