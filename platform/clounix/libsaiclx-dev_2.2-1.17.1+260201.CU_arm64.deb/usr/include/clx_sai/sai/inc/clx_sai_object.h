/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_OBJECT_H__)
#define __CLX_SAI_OBJECT_H__

/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define OBJECT_VENDOR_ATTRIBUTE_REGISTER(object_type, attributes)  \
    do { \
        if ((object_type) < SAI_OBJECT_TYPE_MAX)          \
        {\
            vendor_attributes[(object_type)] = (clxs_sai_attribute_entry_t*)(&attributes);             \
            vendor_attributes_count[(object_type)] = sizeof(attributes)/sizeof(clxs_sai_attribute_entry_t);       \
        }\
        else        \
            CLXS_LOG_ERR("error object type %d", object_type);       \
    } while(0)


/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/
typedef struct
{
    const sai_stat_capability_t       *info;
    uint32_t                           count;
} clxs_object_stats_capability_info_t;


/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern clxs_sai_attribute_entry_t* vendor_attributes[];
extern uint32_t    vendor_attributes_count[];


/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t sai_get_maximum_objet_count(
    _In_  const sai_object_id_t      switch_id,
    _In_  const sai_object_type_t    object_type,
    _Out_ uint32_t                   *count);

sai_status_t
clxs_object_get_supported_object_type_list(
    _In_  const uint32_t             unit,
    _In_  const uint32_t             *vendor_attr_count,
    _Out_ sai_object_type_t          *ptr_object_list,
    _Out_ uint32_t                   *ptr_count);

#endif /* __CLX_SAI_OBJECT_H__ */
