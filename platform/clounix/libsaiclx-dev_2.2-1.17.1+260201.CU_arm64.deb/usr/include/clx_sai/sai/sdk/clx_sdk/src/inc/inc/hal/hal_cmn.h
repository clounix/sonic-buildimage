/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_cmn.h
 * PURPOSE:
 *  1. To maintain common internal utility API, such as src_supp_tag management,
 *     or exception code management.
 * NOTES:
 */

#ifndef HAL_CMN_H
#define HAL_CMN_H

/* INCLUDE FILE DECLARATIONS
 */
#include <hal/hal_l3.h>
#include <hal/hal_pkt_rsrc.h>
#include <hal/hal_ecc.h>
#include <drv/drv_dma.h>
#include <tob/tob.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_CMN_PVLAN_CVLAN_NUM        (5)
#define HAL_CMN_MCLAG_NUM              (6)
#define HAL_CMN_MCAST_LAG_EPOCH_MASTER (0)
#define HAL_CMN_MCAST_LAG_EPOCH_BACKUP (1)

/* MACRO FUNCTION DECLARATIONS
 */

/* protect ITM_RSLT_LAG_SEL & IEV_LAG_EPOCH */
#define HAL_CMN_LOCK_MCAST_LAG_SEL(unit)                                     \
    HAL_COMMON_LOCK_RESOURCE(&_ext_hal_cmn_cb[(unit)].lag_mcast_sel_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_CMN_FREE_MCAST_LAG_SEL(unit) \
    HAL_COMMON_FREE_RESOURCE(&_ext_hal_cmn_cb[(unit)].lag_mcast_sel_sema_id)

/* protect L2 mcast lag member */
#define HAL_CMN_LOCK_L2_MCAST_LAG_MBR(unit)                                     \
    HAL_COMMON_LOCK_RESOURCE(&_ext_hal_cmn_cb[(unit)].l2_mcast_lag_mbr_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_CMN_FREE_L2_MCAST_LAG_MBR(unit) \
    HAL_COMMON_FREE_RESOURCE(&_ext_hal_cmn_cb[(unit)].l2_mcast_lag_mbr_sema_id)
/* DATA TYPE DECLARATIONS
 */

typedef struct hal_cmn_cb_s {
    clx_semaphore_id_t lag_mcast_sel_sema_id;    /* protect ITM_RSLT_LAG_SEL & IEV_LAG_EPOCH */
    clx_semaphore_id_t l2_mcast_lag_mbr_sema_id; /* protect L2 mcast lag member */
} hal_cmn_cb_t;

typedef struct hal_cmn_cia_plane_bcast_info_s {
    boolean bcast_flag;
    uint32 bcast_cont_plane_idx;
    uint32 non_bcast_plane_bmp;
} hal_cmn_cia_plane_bcast_info_t;

typedef enum hal_cmn_action_e {
    HAL_CMN_ACTION_ADD = 0,
    HAL_CMN_ACTION_DEL,
    HAL_CMN_ACTION_SET,
    HAL_CMN_ACTION_GET,
    HAL_CMN_ACTION_LAST
} hal_cmn_action_t;

/* for maintaining IEV_RSLT_U_xxx relation to l3_output (ecmp/adj) */
typedef struct hal_cmn_rte_node_s {
    uint32 iev_idx;             /* index to union IEV_RSLT or IEV_RSLT_NVO3_ENCAP */
    clx_nhp_type_t output_type; /* ecmp, adj, nvo3_adj */
    uint32 output_id;

    struct hal_cmn_rte_node_s *ptr_prev_iev;
    struct hal_cmn_rte_node_s *ptr_next_iev;
} hal_cmn_rte_node_t;

typedef clx_error_no_t (*hal_cmn_adj_callback_func_t)(const uint32 unit,
                                                      const uint32 iev_idx,
                                                      const hal_l3_adj_info_t *ptr_adj_info);

typedef clx_error_no_t (*hal_cmn_nvo3_adj_callback_func_t)(const uint32 unit,
                                                           const uint32 nvo3_encap_idx,
                                                           const uint32 tnl_port_idx,
                                                           const uint32 path_idx,
                                                           const clx_port_t port);

typedef struct hal_cmn_latency_tbl_entry_s {
    uint32 is_tbl_id;
    union {
        uint32 tbl_id;
        uint32 addr;
    };
    union {
        uint32 field_id;
        uint32 offset;
    };
    uint32 entry_idx;
    uint32 data;
} hal_cmn_latency_tbl_entry_t;

/* GLOBAL VARIABLE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

clx_error_no_t
hal_cmn_init(const uint32 unit);

void
hal_cmn_deinit(const uint32 unit);

/**
 * @brief The function is used to compare rte_node iev_idx in rte_avl tree.
 *
 * @param [in]    ptr_user_param    - User parameter.
 * @param [in]    ptr_user_data     - User data.
 * @param [in]    ptr_node_data     - Node data.
 * @return        <0    - - ptr_user_data.iev_idx < ptr_node_data. iev_idx =0 -- ptr_user_data.
 *                        iev_idx = ptr_node_data. iev_idx >0 -- ptr_user_data.
 *                        iev_idx > ptr_node_data. iev_idx.
 */
int32
hal_cmn_rte_iev_cmp(void *ptr_user_param, void *ptr_user_data, void *ptr_node_data);

/**
 * @brief The function is used to save rte_node.
 *
 * @param [in]    ptr_user_param    - User parameter.
 * @param [in]    ptr_node_data     - User data.
 * @param [in]    pptr_cookie       - Cookie.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_cmn_rte_nodes_save_cb(void *ptr_user_param, void *ptr_node_data, void *pptr_cookie);

/**
 * @brief Configure FWR_RSLT_RM_TNL's usage of l3_output (ecmp or adj) to swdb.
 *
 * @param [in]    unit                 - Device unit number.
 * @param [in]    iev_idx              - Index to FWR_RSLT_RM_TNL.
 * @param [in]    ptr_output_type      - Ecmp or adj.
 * @param [in]    ptr_output_id        - Ecmp_id or adj_id.
 * @param [in]    action               - ADD/DEL/SET/GET.
 * @param [in]    pptr_nvo3_adj_arr    - Pointer to nvo3_adj_arr.
 * @param [in]    ptr_path_avl         - Pointer to path_avl.
 * @return        CLX_E_OK    - Operation successful.
 */
clx_error_no_t
hal_cmn_iev_nvo3_rte_node_cfg(const uint32 unit,
                              const uint32 iev_idx,
                              clx_nhp_type_t *ptr_output_type,
                              uint32 *ptr_output_id,
                              const hal_cmn_action_t action,
                              hal_cmn_rte_node_t **pptr_nvo3_adj_arr,
                              util_lib_avl_head_t *ptr_path_avl);

/**
 * @brief Save set-nvo3-adj-swdb for warm-deinit.
 *
 * @param [in]     pptr_nvo3_adj_arr    - Array of pointer to first node of each nvo3_adj_id.
 * @param [in]     ptr_path_avl         - Avl head of path_idx.
 * @param [in]     ptr_obj_meta         - Object Meta for the nonvolatile storage.
 * @param [out]    ptr_obj_meta         - Object Meta for the nonvolatile storage.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Operate wrong parameter.
 * @return         CLX_E_NO_MEMORY        - Operate no memory.
 */
clx_error_no_t
hal_cmn_iev_nvo3_rte_nodes_save(hal_cmn_rte_node_t **pptr_nvo3_adj_arr,
                                util_lib_avl_head_t *ptr_path_avl,
                                hal_io_obj_meta_t *ptr_obj_meta);

/**
 * @brief Restore set-nvo3-adj-swdb for warm-init.
 *
 * @param [in]    unit                 - Device unit number.
 * @param [in]    pptr_nvo3_adj_arr    - Array of pointer to first node of each nvo3_adj_id.
 * @param [in]    ptr_path_avl         - Avl head of path_idx.
 * @param [in]    ptr_obj_meta         - Object Meta for the nonvolatile storage.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_NO_MEMORY        - Operate no memory.
 * @return        CLX_E_TABLE_FULL       - Operate resource full.
 * @return        CLX_E_BAD_PARAMETER    - Operate wrong parameter.
 */
clx_error_no_t
hal_cmn_iev_nvo3_rte_nodes_restore(const uint32 unit,
                                   hal_cmn_rte_node_t **pptr_nvo3_adj_arr,
                                   util_lib_avl_head_t *ptr_path_avl,
                                   const hal_io_obj_meta_t *ptr_obj_meta);

/**
 * @brief Update hw path info by traversing nodes using given nvo3_adj_id.
 *
 * @param [in]    unit                 - Device unit number.
 * @param [in]    nvo3_adj_id          - Nvo3 adjacency id.
 * @param [in]    port                 - Info of nvo3_adj.
 * @param [in]    pptr_nvo3_adj_arr    - Array of pointer to first node of each nvo3_adj_id.
 * @param [in]    callback             - Callback function to update path.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate fail.
 */
clx_error_no_t
hal_cmn_nvo3_adj_egr_update(const uint32 unit,
                            const uint32 nvo3_adj_id,
                            const clx_port_t port,
                            hal_cmn_rte_node_t **pptr_nvo3_adj_arr,
                            hal_cmn_nvo3_adj_callback_func_t callback);

/**
 * @brief Get di from clx_port/native port.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Clx_port or native port.
 * @param [in]     reason    - Cpu reason if to_cpu.
 * @param [out]    ptr_di    - Di derived from input port.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_cmn_di_get(const uint32 unit, const clx_port_t port, const uint32 reason, uint32 *ptr_di);

/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */
extern hal_cmn_cb_t _ext_hal_cmn_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

#endif
