/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  util_cfg.h
 * PURPOSE:
 *      It provide user configuration options function API.
 * NOTES:
 */

#ifndef UTIL_CFG_H
#define UTIL_CFG_H

#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_cfg.h>

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS */

/**
 * @brief Get the value of customized configuration.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    cfg_type     - Config type.
 * @param [in]    ptr_value    - Config value.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
util_cfg_value_get(const uint32 unit, const clx_cfg_type_t cfg_type, clx_cfg_value_t *ptr_value);

/**
 * @brief Set the value of customized configuration.
 *
 * @param [in]    unit                - Device unit number.
 * @param [in]    ptr_cfg_callback    - Ptr to user cfg callback function.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
util_cfg_register(const uint32 unit, const clx_cfg_get_func_t ptr_cfg_callback);

/**
 * @brief Get led cfg from user registered callback function.
 *
 * **pptr_led_cfg    --   pointer to the external led cfg returned from user callback function
 * *ptr_cfg_size     --   return the bytes for the external led cfg.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK    - Operate success.
 */

clx_error_no_t
util_cfg_led_cfg_get(const uint32 unit, uint32 **pptr_led_cfg, uint32 *ptr_cfg_size);

/**
 * @brief Set the value of customized configuration.
 *
 * @param [in]    unit                    - Device unit number.
 * @param [in]    ptr_led_cfg_callback    - Ptr to user led cfg callback function.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */

clx_error_no_t
util_cfg_led_register(const uint32 unit, const clx_cfg_get_led_func_t ptr_led_cfg_callback);

/**
 * @brief Get the enum of customized configuration from string name.
 *
 * @param [in]     ptr_cfg_type_name    - String name of configuration.
 * @param [out]    ptr_cfg_type         - Pointer to the configuration enum.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad cfg type.
 */
clx_error_no_t
util_cfg_type_get(const char *ptr_cfg_type_name, clx_cfg_type_t *ptr_cfg_type);
#endif /* #ifndef UTIL_CFG_H */
