/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  util.h
 * PURPOSE:
 *      It provides UTIL module internal API
 *
 * NOTES:
 *
 */

#ifndef UTIL_H
#define UTIL_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <util/util_log.h>
#include <osal/osal.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define UTIL_MAC_STR_SIZE        (15)
#define UTIL_IPV4_STR_SIZE       (16)
#define UTIL_IPV6_STR_SIZE       (40)
#define UTIL_IP_ADDR_STR_SIZE    (UTIL_IPV6_STR_SIZE)
#define UTIL_IP_NETWORK_STR_SIZE (UTIL_IPV6_STR_SIZE)

/* DATA TYPE DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define UTIL_ENUM_CHK(__value__, __max__)                                    \
    do {                                                                     \
        if ((__value__) >= (__max__)) {                                      \
            UTIL_LOG_PRINT(UTIL_LOG_UTIL, UTIL_LOG_WARN,                     \
                           "invalid " #__value__ "=%u, range=0-%u,"          \
                           " rc=%d\n",                                       \
                           __value__, ((__max__) - 1), CLX_E_BAD_PARAMETER); \
            return CLX_E_BAD_PARAMETER;                                      \
        }                                                                    \
    } while (0)

#define UTIL_PTR_CHK(__ptr__)                                                                  \
    do {                                                                                       \
        if (NULL == (__ptr__)) {                                                               \
            UTIL_LOG_PRINT(UTIL_LOG_UTIL, UTIL_LOG_WARN, #__ptr__ " is null pointer, rc=%d\n", \
                           CLX_E_BAD_PARAMETER);                                               \
            return CLX_E_BAD_PARAMETER;                                                        \
        }                                                                                      \
    } while (0)

#define UTIL_RANGE_CHK(__value__, __min__, __max__)                                           \
    do {                                                                                      \
        if (((__value__) > (__max__)) || ((__value__) < (__min__))) {                         \
            UTIL_LOG_PRINT(UTIL_LOG_UTIL, UTIL_LOG_WARN,                                      \
                           "invalid " #__value__ "=%u, range=%u-%u,"                          \
                           " rc=%d\n",                                                        \
                           __value__, (uint32)__min__, (uint32)__max__, CLX_E_BAD_PARAMETER); \
            return CLX_E_BAD_PARAMETER;                                                       \
        }                                                                                     \
    } while (0)

#define UTIL_MAX_CHK(__value__, __max__)                                     \
    do {                                                                     \
        if ((__value__) > (__max__)) {                                       \
            UTIL_LOG_PRINT(UTIL_LOG_UTIL, UTIL_LOG_WARN,                     \
                           "invalid " #__value__ "=%u, range=0-%u,"          \
                           " rc=%d\n",                                       \
                           __value__, (uint32)__max__, CLX_E_BAD_PARAMETER); \
            return CLX_E_BAD_PARAMETER;                                      \
        }                                                                    \
    } while (0)
#define UTIL_BOOL_CHK(__value__)                                                                  \
    do {                                                                                          \
        if (((FALSE) != (__value__)) && ((TRUE) != (__value__))) {                                \
            UTIL_LOG_PRINT(UTIL_LOG_UTIL, UTIL_LOG_WARN, #__value__ "=%u isn't boolean, rc=%d\n", \
                           __value__, CLX_E_BAD_PARAMETER);                                       \
            return CLX_E_BAD_PARAMETER;                                                           \
        }                                                                                         \
    } while (0)

#define UTIL_MAC_TO_STR(__buf__, __mac__)                                                 \
    osal_snprintf(__buf__, UTIL_MAC_STR_SIZE, "%02X%02X-%02X%02X-%02X%02X", (__mac__)[0], \
                  (__mac__)[1], (__mac__)[2], (__mac__)[3], (__mac__)[4], (__mac__)[5])

#define UTIL_IPV4_TO_STR(__buf__, __ipv4__)                                                    \
    osal_snprintf(__buf__, UTIL_IPV4_STR_SIZE, "%d.%d.%d.%d", ((__ipv4__) & 0xFF000000) >> 24, \
                  ((__ipv4__) & 0x00FF0000) >> 16, ((__ipv4__) & 0x0000FF00) >> 8,             \
                  ((__ipv4__) & 0x000000FF))

#define UTIL_IPV6_TO_STR(__buf__, __ipv6__)                                                       \
    osal_snprintf(__buf__, UTIL_IPV6_STR_SIZE,                                                    \
                  "%02X%02X:%02X%02X:%02X%02X:%02X%02X:%02X%02X:%02X%02X:%02X%02X:%02X%02X",      \
                  (__ipv6__)[0], (__ipv6__)[1], (__ipv6__)[2], (__ipv6__)[3], (__ipv6__)[4],      \
                  (__ipv6__)[5], (__ipv6__)[6], (__ipv6__)[7], (__ipv6__)[8], (__ipv6__)[9],      \
                  (__ipv6__)[10], (__ipv6__)[11], (__ipv6__)[12], (__ipv6__)[13], (__ipv6__)[14], \
                  (__ipv6__)[15])

#define UTIL_ENDIAN_SWAP32(__val__)                                          \
    ({                                                                       \
        uint32 __val = (__val__);                                            \
        __val = ((__val & 0xFF00FF00) >> 8) | ((__val & 0x00FF00FF) << 8);   \
        __val = ((__val & 0xFFFF0000) >> 16) | ((__val & 0x0000FFFF) << 16); \
        __val;                                                               \
    })

#define UTIL_ENDIAN_SWAP16(__val__)                                \
    ({                                                             \
        uint16 __val = (__val__);                                  \
        __val = ((__val & 0xFF00) >> 8) | ((__val & 0x00FF) << 8); \
        __val;                                                     \
    })

/* Byte order conversion */
#if defined(CLX_EN_BIG_ENDIAN)
#define UTIL_HTONL(val) (val)
#define UTIL_HTONS(val) (val)
#define UTIL_NTOHL(val) (val)
#define UTIL_NTOHS(val) (val)
#else
#define UTIL_HTONL(val) UTIL_ENDIAN_SWAP32(val)
#define UTIL_HTONS(val) UTIL_ENDIAN_SWAP16(val)
#define UTIL_NTOHL(val) UTIL_ENDIAN_SWAP32(val)
#define UTIL_NTOHS(val) UTIL_ENDIAN_SWAP16(val)
#endif

/**
 * @brief This function initialize the UTIL module.
 *
 * @return        CLX_E_OK           - Operate success.
 * @return        CLX_E_NO_MEMORY    - Bad parameter.
 * @return        CLX_E_OTHERS       - Operate failed.
 */
clx_error_no_t
util_init(void);

/**
 * @brief This function deinitialize the UTIL module.
 *
 * @return        CLX_E_OK           - Operate success.
 * @return        CLX_E_NO_MEMORY    - Bad parameter.
 * @return        CLX_E_OTHERS       - Operate failed.
 */
clx_error_no_t
util_deinit(void);

uint32
util_fcid_prefix_get(const uint32 mask);

uint32
util_ipv4_prefix_get(const uint32 mask);

uint32
util_ipv6_prefix_get(const uint8 *ptr_mask);

void
util_ipv4_str_get(const clx_ipv4_t *ptr_ipv4, char *ptr_str);

void
util_ipv6_str_get(const clx_ipv6_t *ptr_ipv6, char *ptr_str);

void
util_ip_addr_str_get(const clx_ip_addr_t *ptr_ip_addr, char *ptr_str);

void
util_ip_network_str_get(const clx_ip_addr_t *ptr_network_addr, char *ptr_str);

/**
 * @brief Util_popcount() is a function to count number of one in a word.
 *
 * @param [in]    count    - The specified word.
 * @return        uint32    - Return number of one in a word.
 */
uint32
util_popcount(uint32 count);

/**
 * @brief Util_first_zero_find() is a function to get first zero bit from LSB.
 *
 * @param [in]    ui32_map    - The specified word.
 * @return        uint32    - Return available bit in a word.
 */
uint32
util_first_zero_find(uint32 ui32_map);

/**
 * @brief Util_last_zero_find() is a function to get last zero bit from LSB.
 *
 * @param [in]    ui32_map    - The specified word.
 * @return        uint32    - Return available bit in a word.
 */
uint32_t
util_last_zero_find(uint32_t ui32_map);

/**
 * @brief Integer division and rounding up.
 *
 * @param [in]    dividend    - Dividend.
 * @param [in]    divisor     - Divisor.
 * @return        uint32    - Return rounded quotient.
 */
uint32
util_int_div_and_round_up(uint32 dividend, uint32 divisor);

#endif
