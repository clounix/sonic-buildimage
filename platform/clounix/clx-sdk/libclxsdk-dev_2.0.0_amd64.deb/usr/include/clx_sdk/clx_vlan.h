/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  clx_vlan.h
 * PURPOSE:
 *      It provides vlan module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_VLAN_H
#define CLX_VLAN_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef enum
{
    CLX_VLAN_PROPERTY_IPMC,                     /* L2 IPv4/IPv6 multicast property. */
    CLX_VLAN_PROPERTY_METER_ID,                 /* VLAN meter id property. */
    CLX_VLAN_PROPERTY_METER_COLOR_RESOLVE_TYPE, /* VLAN meter color resolve type property. */
    CLX_VLAN_PROPERTY_SERVICE_COUNTER_ID,       /* Service counter ID. */
    CLX_VLAN_PROPERTY_DIST_COUNTER_ID,          /* Distribution counter ID. */
    CLX_VLAN_PROPERTY_LAST
} CLX_VLAN_PROPERTY_T;

/* This is the frame type value (FTV) which is used as part of a key to look up the protocol based VLAN table. */
typedef UI8_T  CLX_VLAN_FTV_T[5];

/* Private VLAN type of community, isolated and primary */
typedef enum
{
    CLX_VLAN_PVLAN_TYPE_NORMAL = 0,             /* None private VLAN. */
    CLX_VLAN_PVLAN_TYPE_PRIMARY,                /* Primary VLAN. */
    CLX_VLAN_PVLAN_TYPE_COMMUNITY,              /* Community VLAN. */
    CLX_VLAN_PVLAN_TYPE_ISOLATED,               /* Isolated VLAN. */
    CLX_VLAN_PVLAN_TYPE_LAST
} CLX_VLAN_PVLAN_TYPE_T;

/* VLAN Entry */
typedef struct CLX_VLAN_ENTRY_S
{
    CLX_VLAN_T          vlan;               /* 802.1Q VLAN ID. Range is 1-4094. */
    CLX_PORT_BITMAP_T   port_bitmap;        /* Tagged VLAN members. */
    CLX_PORT_BITMAP_T   ut_port_bitmap;     /* Untag VLAN members. */
} CLX_VLAN_ENTRY_T;

/* MAC VLAN Entry */
typedef struct CLX_VLAN_MAC_VLAN_ENTRY_S
{
    UI32_T      port;       /* Physical port ID. */
    CLX_MAC_T   mac;        /* Mac address. */
    CLX_VLAN_T  vlan;       /* 802.1Q VLAN is associated with the entry. The 802.1Q VLAN ID range is 1-4094. */
    UI8_T       pcp;        /* Priority code point of 802.1Q VLAN header. The 802.1Q PCP range is 0-7. */
    UI8_T       dei;        /* 1Q mode for CFI, 1AD mode for DEI*/
} CLX_VLAN_MAC_VLAN_ENTRY_T;

/* The frame type of protocol-based VLAN */
typedef enum
{
    CLX_VLAN_FRAME_TYPE_ETHERNET = 0,   /* Ethernet type. */
    CLX_VLAN_FRAME_TYPE_RFC1042,        /* RFC1042 type. */
    CLX_VLAN_FRAME_TYPE_SNAP_OTHER,     /* SNAP type. */
    CLX_VLAN_FRAME_TYPE_LLC_OTHER,      /* LLC type. */
    CLX_VLAN_FRAME_TYPE_LAST
} CLX_VLAN_FRAME_TYPE_T;

typedef struct CLX_VLAN_CLASSIFY_TYPE_S
{
    UI32_T                   port;              /* Classify port. */
    UI8_T                    pcp;               /* Priority control point. */
    UI8_T                    pcp_mask;          /* Priority control point mask. */
    UI8_T                    dei;               /* 1Q mode for CFI, 1AD mode for DEI. */
    UI8_T                    dei_mask;          /* CFI or DEI mask. */
    CLX_VLAN_T               svid;              /* Service VLAN ID. */
    CLX_VLAN_T               svid_mask;         /* Service VLAN ID mask. */
    CLX_VLAN_T               cvid;              /* Customer VLAN ID. */
    CLX_VLAN_T               cvid_mask;         /* Customer VLAN ID mask. */
    CLX_VLAN_FRAME_TYPE_T    frame_type;        /* Frame type. */
    UI16_T                   ethertype;         /* Link layer protocol type. */
    UI16_T                   ethertype_mask;    /* Link layer protocol type mask. */
    UI8_T                    ip_protocol;       /* Network layer protocol type. */
    UI8_T                    ip_protocol_mask;  /* Network layer protocol type mask. */
    UI16_T                   src_port;          /* Transport layer source port. */
    UI16_T                   src_port_mask;     /* Transport layer source port mask. */
    UI16_T                   dst_port;          /* Transport layer destination port. */
    UI16_T                   dst_port_mask;     /* Transport layer destination port mask. */

/* For trust/untrust port */
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_TRUST_VID_VALID     (1U << 0)  /* Trust frame VLAN ID valid flag. */
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_TRUST_VID           (1U << 1)  /* Trust VLAN ID to match flag. */
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_TRUST_PCP_DEI_VALID (1U << 2)  /* Trust PCP/DEI valid flag. */
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_TRUST_PCP_DEI       (1U << 3)  /* Trust PCP/DEI to match flag. */
/* For frame which has s-tag/c-tag */
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_STAG_EXIST_VALID    (1U << 4)  /* Service tag exist valid flag. */
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_STAG_EXIST          (1U << 5)  /* Service tag exist to match flag. */
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_CTAG_EXIST_VALID    (1U << 6)  /* Customer tag exist valid flag. */
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_CTAG_EXIST          (1U << 7)  /* Customer tag exist to match flag. */
/* For care port or not */
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_PORT_VALID          (1U << 8)  /* Port valid flag. */
/* sw references only */
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_VLAN_TAG_MODE_1Q    (1U << 9)  /* 1AD mode valid flag. */
    UI32_T                   flags;                                 /* Flag in bitmap form. */
} CLX_VLAN_CLASSIFY_TYPE_T;

typedef struct CLX_VLAN_CLASSIFY_ADDR_S
{
    UI32_T        port;                     /* Port number. */
    UI8_T         pcp;                      /* Priority control point. */
    UI8_T         pcp_mask;                 /* Priority control point mask. */
    UI8_T         dei;                      /* 1Q mode for CFI, 1AD mode for DEI. */
    UI8_T         dei_mask;                 /* CFI or DEI mask. */
    CLX_VLAN_T    svid;                     /* Service VLAN ID. */
    CLX_VLAN_T    svid_mask;                /* Service VLAN ID mask. */
    CLX_VLAN_T    cvid;                     /* Customer VLAN ID. */
    CLX_VLAN_T    cvid_mask;                /* Customer VLAN ID mask. */
    CLX_MAC_T     dmac;                     /* Destination MAC address. */
    CLX_MAC_T     dmac_mask;                /* Destination MAC address mask. */
    CLX_MAC_T     smac;                     /* Source MAC address. */
    CLX_MAC_T     smac_mask;                /* Source MAC address mask. */
    CLX_IP_T      dip;                      /* Destination IPv4/IPv6 address. */
    CLX_IP_T      dip_mask;                 /* Destination IPv4/IPv6 address mask. */
    CLX_IP_T      sip;                      /* Source IPv4/IPv6 address. */
    CLX_IP_T      sip_mask;                 /* Source IPv4/IPv6 address mask. */
    UI8_T         tos;                      /* Type of service(TOS). */
    UI8_T         tos_mask;                 /* TOS value mask. */
    UI32_T        flow_label;               /* IPv6 flow label for routing. */
    UI32_T        flow_label_mask;          /* IPv6 flow label mask. */

/* For trust/untrust port */
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_TRUST_VID_VALID     (1U << 0)  /* CLX_VLAN_CLASSIFY_ADDR_FLAGS_TRUST_VID valid flag. */
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_TRUST_VID           (1U << 1)  /* Trust packet VID. */
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_TRUST_PCP_DEI_VALID (1U << 2)  /* CLX_VLAN_CLASSIFY_ADDR_FLAGS_TRUST_PCP_DEI valid flag. */
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_TRUST_PCP_DEI       (1U << 3)  /* Trust packet PCP/DEI */
/* For frame which has s-tag/c-tag */
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_STAG_EXIST_VALID    (1U << 4)  /* CLX_VLAN_CLASSIFY_ADDR_FLAGS_STAG_EXIST valid flag. */
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_STAG_EXIST          (1U << 5)  /* Match Service tag. */
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_CTAG_EXIST_VALID    (1U << 6)  /* CLX_VLAN_CLASSIFY_ADDR_FLAGS_CTAG_EXIST valid flag. */
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_CTAG_EXIST          (1U << 7)  /* Match Customer tag. */
/* For care port or not */
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_PORT_VALID          (1U << 8)  /* Port valid flag. */
/* sw references only */
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_IPV6_ENTRY          (1U << 9)  /* IPv6 for match. */
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_VLAN_TAG_MODE_1Q    (1U << 10) /* If set VLAN 1Q, STAG will be ignored. */
    UI32_T        flags;                                            /* CLX_VLAN_CLASSIFY_ADDR_FLAGS_XXX. */
} CLX_VLAN_CLASSIFY_ADDR_T;


typedef struct CLX_VLAN_TAG_ACTION_S
{
    CLX_VLAN_T    svid;                                             /* Service VLAN ID. */
    CLX_VLAN_T    cvid;                                             /* Customer VLAN ID. */
    UI8_T         pcp;                                              /* Priority control point. */
    UI8_T         dei;                                              /* 1Q mode for CFI, 1AD mode for DEI. */

#define CLX_VLAN_TAG_ACTION_FLAGS_SVID_VALID        (1U << 0)       /* Service VLAN ID valid flag. */
#define CLX_VLAN_TAG_ACTION_FLAGS_CVID_VALID        (1U << 1)       /* Customer VLAN ID valid flag. */
#define CLX_VLAN_TAG_ACTION_FLAGS_PCP_DEI_VALID     (1U << 2)       /* PCP and DEI valid flag. */
    UI32_T        flags;                                            /* CLX_VLAN_TAG_ACTION_FLAGS_XXX. */
} CLX_VLAN_TAG_ACTION_T;

/* Primary VLAN Information of Private VLAN Entry*/
typedef struct CLX_VLAN_PVLAN_PRIMARY_VLAN_INFO_S
{
    CLX_VLAN_T          vlan_id;                    /* Primary VLAN ID. */
    CLX_PORT_BITMAP_T   primary_port_bitmap;        /* Primary VLAN port members. */
    CLX_PORT_BITMAP_T   trunk_port_bitmap;          /* Primary VLAN trunk ports. */
} CLX_VLAN_PVLAN_PRIMARY_VLAN_INFO_T;

/* Secondary VLAN Information of Private VLAN Entry */
typedef struct CLX_VLAN_PVLAN_SECONDARY_VLAN_INFO_S
{
    CLX_VLAN_T           vlan_id;              /* Secondary VLAN ID. */
    CLX_PORT_BITMAP_T    port_bitmap;          /* Secondary VLAN port members. */
} CLX_VLAN_PVLAN_SECONDARY_VLAN_INFO_T;

/* Private Vlan Entry */
typedef struct CLX_VLAN_PVLAN_ENTRY_S
{
    CLX_VLAN_PVLAN_PRIMARY_VLAN_INFO_T    primary_vlan;             /* Primary VLAN information. */
    CLX_VLAN_PVLAN_SECONDARY_VLAN_INFO_T  isolated_vlan;            /* Isolated VLAN information. */
    CLX_VLAN_PVLAN_SECONDARY_VLAN_INFO_T  *ptr_community_vlan_list; /* Community VLAN information. */
    UI16_T                                community_vlan_num;       /* Number of community VLANs. */
    UI32_T                                mcast_id;                 /* L2 multicast ID. */
    CLX_BRIDGE_DOMAIN_T                   bdid;                     /* Bridge Domain ID. */
} CLX_VLAN_PVLAN_ENTRY_T;


/* VLAN Isolation Entry */
typedef struct CLX_VLAN_ISOLATION_ENTRY_S
{
    CLX_VLAN_T           vlan;              /* Isolation VLAN ID. */
    CLX_PORT_BITMAP_T    egr_port_mask;     /* Egress port to forwarding. */
} CLX_VLAN_ISOLATION_ENTRY_T;

/* FUNCTION NAME:   CLX_VLAN_ENTRY_TRAVERSE_FUNC_T
 * PURPOSE:
 *      VLAN Traverse Callback Function.
 * INPUT:
 *      unit                -- Device unit number
 *      ptr_entry           -- VLAN entry information
 *      ptr_cookie          -- Callback parameter
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_OTHERS        -- Operate failed
 * NOTES:
 *      none
 */
typedef CLX_ERROR_NO_T
(*CLX_VLAN_ENTRY_TRAVERSE_FUNC_T)(
    const UI32_T              unit,
    const CLX_VLAN_ENTRY_T    *ptr_entry,
    void                      *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   clx_vlan_setProperty
 * PURPOSE:
 *      Set properties of the bridge domain.
 * INPUT:
 *      unit                -- Device unit number
 *      bdid                -- Bridge domain id
 *      property            -- Property type
 *      param0              -- First parameter
 *      param1              -- Second parameter
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Operate failed
 * NOTES:
 *      Should create the bridge domain before setting the property.
 */
CLX_ERROR_NO_T
clx_vlan_setProperty(
    const UI32_T                 unit,
    const CLX_BRIDGE_DOMAIN_T    bdid,
    const CLX_VLAN_PROPERTY_T    property,
    const UI32_T                 param0,
    const UI32_T                 param1);

/* FUNCTION NAME:   clx_vlan_getProperty
 * PURPOSE:
 *      Get properties of the bridge domain.
 * INPUT:
 *      unit                -- Device unit number
 *      bdid                -- Bridge domain id
 *      property            -- Property type
 * OUTPUT:
 *      ptr_param0         -- First parameter
 *      ptr_param1         -- Second parameter
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Operate failed
 * NOTES:
 *      Should create this bridge domain before getting the property.
 */
CLX_ERROR_NO_T
clx_vlan_getProperty(
    const UI32_T                 unit,
    const CLX_BRIDGE_DOMAIN_T    bdid,
    const CLX_VLAN_PROPERTY_T    property,
    UI32_T                       *ptr_param0,
    UI32_T                       *ptr_param1);

/* FUNCTION NAME:   clx_vlan_createVlan
 * PURPOSE:
 *     Create vlan entries.
 * INPUT:
 *      unit                -- Device unit number
 *      vid                 -- 802.1Q VLAN id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      This function will create vlan entry and set fields of vlan entry include
 *      portlist, untag portlist to default value.
 */
CLX_ERROR_NO_T
clx_vlan_createVlan(
    const UI32_T        unit,
    const CLX_VLAN_T    vid);

/* FUNCTION NAME:   clx_vlan_delVlan
 * PURPOSE:
 *      Delete a vlan entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      vid                   -- 802.1Q VLAN id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_vlan_delVlan(
    const UI32_T        unit,
    const CLX_VLAN_T    vid);

/* FUNCTION NAME:   clx_vlan_setPort
 * PURPOSE:
 *      Add member and untag port list of existing vlan entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      ptr_vlan_entry        -- VLAN entry
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *      VLAN entry includes member port list and untag port list.
 */
CLX_ERROR_NO_T
clx_vlan_setPort(
    const UI32_T              unit,
    const CLX_VLAN_ENTRY_T    *ptr_vlan_entry);

/* FUNCTION NAME:   clx_vlan_getPort
 * PURPOSE:
 *      Get a vlan entry with specified 802.1Q vlan.
 * INPUT:
 *      unit                  -- Device unit number
 * OUTPUT:
 *      ptr_vlan_entry        -- VLAN entry
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_vlan_getPort(
    const UI32_T        unit,
    CLX_VLAN_ENTRY_T    *ptr_vlan_entry);

/* FUNCTION NAME:   clx_vlan_traverseEntry
 * PURPOSE:
 *      Traverse vlan tagged/untagged member port for active vlan.
 * INPUT:
 *      unit        -- Device unit number
 *      callback    -- The callback function to be called for each traversed vlan entry
 *      ptr_cookie  -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie  -- The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK          -- Operate success
 *      CLX_E_NOT_SUPPORT -- Not supported feature
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_vlan_traverseEntry(
    const UI32_T                            unit,
    const CLX_VLAN_ENTRY_TRAVERSE_FUNC_T    callback,
    void                                    *ptr_cookie);

/* FUNCTION NAME:   clx_vlan_createBridgeDomain
 * PURPOSE:
 *      Create a bridge domain.
 * INPUT:
 *      unit                -- Device unit number
 *      bdid                -- Bridge domain id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_vlan_createBridgeDomain(
    const UI32_T                 unit,
    const CLX_BRIDGE_DOMAIN_T    bdid);

/* FUNCTION NAME:   clx_vlan_destroyBridgeDomain
 * PURPOSE:
 *      Destroy a bridge domain.
 * INPUT:
 *      unit                -- Device unit number
 *      bdid                -- Bridge domain id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_vlan_destroyBridgeDomain(
    const UI32_T                 unit,
    const CLX_BRIDGE_DOMAIN_T    bdid);

/* FUNCTION NAME:   clx_vlan_setService
 * PURPOSE:
 *      Set vlan-based service.
 * INPUT:
 *      unit                -- Device unit number
 *      vid                 -- 802.1Q VLAN id
 *      ptr_srv             -- Service properties
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      Service properties includes:
 *       1) Bridge domain id
 *       2) Flooding mcast id
 *       3) Learning control
 *       ...
 */
CLX_ERROR_NO_T
clx_vlan_setService(
    const UI32_T                unit,
    const CLX_VLAN_T            vid,
    const CLX_PORT_SEG_SRV_T    *ptr_srv);

/* FUNCTION NAME:   clx_vlan_getService
 * PURPOSE:
 *      Get vlan-based service.
 * INPUT:
 *      unit                -- Device unit number
 *      vid                 -- 802.1Q VLAN id
 * OUTPUT:
 *      ptr_srv             -- Service properties
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      Service properties includes:
 *       1) Bridge domain id
 *       2) Flooding mcast id
 *       3) Learning control
 *       ...
 */
CLX_ERROR_NO_T
clx_vlan_getService(
    const UI32_T          unit,
    const CLX_VLAN_T      vid,
    CLX_PORT_SEG_SRV_T    *ptr_srv);

/* FUNCTION NAME:   clx_vlan_setVlanIsolation
 * PURPOSE:
 *     config vlan isolation entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      vid                   -- 802.1Q VLAN id
 *      ptr_entry             -- VLAN isolation entry
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_vlan_setVlanIsolation(
    const UI32_T                        unit,
    const CLX_VLAN_T                    vid,
    const CLX_VLAN_ISOLATION_ENTRY_T    *ptr_entry);

/* FUNCTION NAME:   clx_vlan_getVlanIsolation
 * PURPOSE:
 *     Get vlan isolation entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      vid                   -- 802.1Q VLAN id
 * OUTPUT:
 *      ptr_entry             -- VLAN isolation entry
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_vlan_getVlanIsolation(
    const UI32_T                  unit,
    const CLX_VLAN_T              vid,
    CLX_VLAN_ISOLATION_ENTRY_T    *ptr_entry);

/* FUNCTION NAME:   clx_vlan_addMacVlan
 * PURPOSE:
 *      Add a mac-based vlan entry.
 * INPUT:
 *      unit                -- Device unit number
 *      ptr_entry           -- MAC VLAN entry
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_TABLE_FULL    -- No more memory
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_vlan_addMacVlan(
    const UI32_T                       unit,
    const CLX_VLAN_MAC_VLAN_ENTRY_T    *ptr_entry);

/* FUNCTION NAME:   clx_vlan_delMacVlan
 * PURPOSE:
 *      Delete a mac-based vlan entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      ptr_entry             -- MAC VLAN entry
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_vlan_delMacVlan(
    const UI32_T                       unit,
    const CLX_VLAN_MAC_VLAN_ENTRY_T    *ptr_entry);

/* FUNCTION NAME:   clx_vlan_getMacVlan
 * PURPOSE:
 *      Get a mac-based vlan entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      ptr_entry             -- Field "port" and "mac"
 * OUTPUT:
 *      ptr_entry             -- Field "vlan", "pcp" and "dei"
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_vlan_getMacVlan(
    const UI32_T                 unit,
    CLX_VLAN_MAC_VLAN_ENTRY_T    *ptr_entry);

/* FUNCTION NAME:   clx_vlan_setTypeEntry
 * PURPOSE:
 *      Set a type-based vlan entry.
 * INPUT:
 *      unit                -- Device unit number
 *      index               -- Index of the entry
 *      ptr_entry           -- Protocol-related and common L2 fields
 *      ptr_action          -- Assigned actions of vlan info
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_vlan_setTypeEntry(
    const UI32_T                      unit,
    const UI32_T                      index,
    const CLX_VLAN_CLASSIFY_TYPE_T    *ptr_entry,
    const CLX_VLAN_TAG_ACTION_T       *ptr_action);

/* FUNCTION NAME:   clx_vlan_getTypeEntry
 * PURPOSE:
 *      Get a type-based vlan entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      index                 -- Index of the entry
 * OUTPUT:
 *      ptr_entry             -- Protocol-related and common L2 fields
 *      ptr_action            -- Assigned actions of vlan info
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *      Type-based entry includes protocol type.
 */
CLX_ERROR_NO_T
clx_vlan_getTypeEntry(
    const UI32_T                unit,
    const UI32_T                index,
    CLX_VLAN_CLASSIFY_TYPE_T    *ptr_entry,
    CLX_VLAN_TAG_ACTION_T       *ptr_action);

/* FUNCTION NAME:   clx_vlan_setAddrEntry
 * PURPOSE:
 *      Set a address-based vlan entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      index                 -- Index of the entry
 *      ptr_entry             -- L2/L3 address-related and common L2 fields
 *      ptr_action            -- Assigned actions of vlan info
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *      Address-based entry includes mac and ip address.
 */
CLX_ERROR_NO_T
clx_vlan_setAddrEntry(
    const UI32_T                      unit,
    const UI32_T                      index,
    const CLX_VLAN_CLASSIFY_ADDR_T    *ptr_entry,
    const CLX_VLAN_TAG_ACTION_T       *ptr_action);

/* FUNCTION NAME:   clx_vlan_getAddrEntry
 * PURPOSE:
 *      Get a address-based vlan entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      index                 -- Index of the entry
 * OUTPUT:
 *      ptr_entry             -- L2/L3 address-related and common L2 fields
 *      ptr_action            -- Assigned actions of vlan info
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *      Address-based entry includes mac and ip address.
 */
CLX_ERROR_NO_T
clx_vlan_getAddrEntry(
    const UI32_T                unit,
    const UI32_T                index,
    CLX_VLAN_CLASSIFY_ADDR_T    *ptr_entry,
    CLX_VLAN_TAG_ACTION_T       *ptr_action);

/* FUNCTION NAME:   clx_vlan_addPvlanEntry
 * PURPOSE:
 *      Add a pvlan entry for the primary vlan.
 * INPUT:
 *      unit                  -- Device unit number
 *      primary_vlan          -- 802.1Q VLAN id
 *      ptr_pvlan_entry       -- Pvlan entry
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_vlan_addPvlanEntry(
    const UI32_T                    unit,
    const CLX_VLAN_T                primary_vlan,
    const CLX_VLAN_PVLAN_ENTRY_T    *ptr_pvlan_entry);

/* FUNCTION NAME:   clx_vlan_delPvlanEntry
 * PURPOSE:
 *      Delete a pvlan entry for the primary vlan.
 * INPUT:
 *      unit                  -- Device unit number
 *      primary_vlan          -- 802.1Q VLAN id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_vlan_delPvlanEntry(
    const UI32_T        unit,
    const CLX_VLAN_T    primary_vlan);

/* FUNCTION NAME:   clx_vlan_getPvlanEntry
 * PURPOSE:
 *      Get a pvlan entry for the primary vlan.
 * INPUT:
 *      unit                  -- Device unit number
 *      primary_vlan          -- 802.1Q VLAN id
 * OUTPUT:
 *      ptr_pvlan_entry       -- Pvlan entry
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_vlan_getPvlanEntry(
    const UI32_T              unit,
    const CLX_VLAN_T          primary_vlan,
    CLX_VLAN_PVLAN_ENTRY_T    *ptr_pvlan_entry);

#endif  /* End of CLX_VLAN_H */
