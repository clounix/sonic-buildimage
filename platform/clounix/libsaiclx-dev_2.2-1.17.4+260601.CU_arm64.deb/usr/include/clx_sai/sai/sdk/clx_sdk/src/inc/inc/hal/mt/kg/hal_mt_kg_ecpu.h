/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_ecpu.h
 * PURPOSE:
 *  Provide HAL driver API functions of ecpu module.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_KG_ECPU_H
#define HAL_MT_KG_ECPU_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_swc.h>
#include <hal/hal_ecpu.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO  DECLARATIONS
 */

#define HAL_MT_KG_ECPU_MAX_CORE (4)
// KG MEM is 2MB , access with DCP
#define HAL_MT_KG_ECPU_ITCM_LOW_ADDR  (0)
#define HAL_MT_KG_ECPU_ITCM_HI_ADDR   (0x200000)
#define HAL_MT_KG_ECPU_ITCMBASE       (0)
#define HAL_MT_KG_ECPU_ITCMBASE_CHAIN (0x4BC00) /*The address of ITCM on the chain*/
#define HAL_MT_KG_ECPU_MEM_DCP        (0x24D800)

#define HAL_MT_KG_EADDR2CHADDR(eaddr)  ((eaddr) - HAL_MT_KG_ECPU_ITCMBASE + HAL_MT_KG_ECPU_MEM_DCP)
#define HAL_MT_KG_CHADDR2EADDR(chaddr) ((chaddr) - HAL_MT_KG_ECPU_MEM_DCP + HAL_MT_KG_ECPU_ITCMBASE)

#define HAL_MT_KG_CFG_PDMA_CH_ENABLE (0x00041404)

/* Define elink ring buffer basic macro
 */
#define HAL_MT_KG_RING_BUFFER_BLOCK_SIZE   (1024 * 8)
#define HAL_MT_KG_RING_BUFFER_CONTROL_SIZE (1024) /*ring buffer control area size*/
#define HAL_MT_KG_RING_BUFFER_SIZE                                                             \
    (HAL_MT_KG_RING_BUFFER_BLOCK_SIZE - HAL_MT_KG_RING_BUFFER_CONTROL_SIZE) /*ring buffer data \
                                                                               area size*/
#define HAL_MT_KG_RING_BUFFER_BUFFER_SIZE (256)                             /*each buffer size*/

#define HAL_MT_KG_CORE0_MEM_SIZE (0x8C000)
#define HAL_MT_KG_CORE1_MEM_SIZE (0x3C000)
#define HAL_MT_KG_CORE2_MEM_SIZE (0x5C000)
#define HAL_MT_KG_CORE3_MEM_SIZE (0x4C000)

#define HAL_MT_KG_CORE0_MEM_BASE (0x000000)
#define HAL_MT_KG_CORE1_MEM_BASE (0x08C000)
#define HAL_MT_KG_CORE2_MEM_BASE (0x0C8000)
#define HAL_MT_KG_CORE3_MEM_BASE (0x124000)

#define HAL_MT_KG_ELINK_BASE (0x170000)

#define HAL_MT_KG_RING_BUFFER_TXBUFF_ADDR(core_id) \
    (HAL_MT_KG_ELINK_BASE + core_id * HAL_MT_KG_RING_BUFFER_BLOCK_SIZE * 2)
#define HAL_MT_KG_RING_BUFFER_TXBUFF_BASE(core_id) \
    (HAL_MT_KG_RING_BUFFER_TXBUFF_ADDR(core_id) + HAL_MT_KG_RING_BUFFER_CONTROL_SIZE)

#define HAL_MT_KG_RING_BUFFER_RXBUFF_ADDR(core_id) \
    (HAL_MT_KG_RING_BUFFER_TXBUFF_ADDR(core_id) + HAL_MT_KG_RING_BUFFER_BLOCK_SIZE)
#define HAL_MT_KG_RING_BUFFER_RXBUFF_BASE(core_id) \
    (HAL_MT_KG_RING_BUFFER_RXBUFF_ADDR(core_id) + HAL_MT_KG_RING_BUFFER_CONTROL_SIZE)

#define HAL_MT_KG_ECPU_INT_ECPU2SCPU_0_MSK  (0x0004B904)
#define HAL_MT_KG_ECPU_INT_ECPU2SCPU_1_MSK  (0x0004B914)
#define HAL_MT_KG_ECPU_INT_ECPU2SCPU_2_MSK  (0x0004B924)
#define HAL_MT_KG_ECPU_INT_ECPU2SCPU_3_MSK  (0x0004B934)
#define HAL_MT_KG_ECPU_INT_IRQ_PVT_DONE_MSK (0x0004B9AC)

#define HAL_MT_KG_ECPU_PORT_MIN_BANDWIDTH  0
#define HAL_MT_KG_ECPU_PORT_MIN_BURST_SIZE 0
#define HAL_MT_KG_ECPU_PORT_MAX_BANDWIDTH  100000 // pps
#define HAL_MT_KG_ECPU_PORT_MAX_BURST_SIZE 200
#define HAL_MT_KG_ECPU_QUEUE_NUM           8

/* ecpu used tx/rx pdma channel and general pdma channel 8 */
#define HAL_MT_KG_ECPU_FIFORXDATA_CH 16U
#define HAL_MT_KG_ECPU_FIFOTXDATA_CH 17U
#define HAL_MT_KG_ECPU_KG2ECPU_CH    8U

/* DATA TYPE DECLARATIONS
 */

/* FUNCTION MACRO DECLARATIONS
 */
/**
 * @brief This API is used to init ecpu tx/rx hw information.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK            - Successfully.
 * @return        CLX_E_NOT_INITED    - Ecpu not started.
 * @return        CLX_E_OTHERS        - Failed to init hardware.
 */
clx_error_no_t
hal_mt_kg_ecpu_hw_init(const uint32 unit);
/**
 * @brief This API is used to reboot ecpu.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK            - Successfully.
 * @return        CLX_E_NOT_INITED    - Ecpu not started.
 * @return        CLX_E_OTHERS        - Failed to reboot.
 */
clx_error_no_t
hal_mt_kg_ecpu_reboot(const uint32 unit);

/**
 * @brief This API is used to start the ecpu of the specified unit.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    index    - Firmware index.
 * @return        CLX_E_OK                 - Successfully.
 * @return        CLX_E_OTHERS             - Failed to start ecpu.
 * @return        CLX_E_BAD_PARAMETER      - Failed to get firmware path.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Failed to get firmware description path.
 */
clx_error_no_t
hal_mt_kg_ecpu_start(const uint32 unit, const uint32 index);

/**
 * @brief This API is used to stop ecpu of the specified unit.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to stop ecpu.
 */
clx_error_no_t
hal_mt_kg_ecpu_stop(const uint32 unit);

/**
 * @brief This API is used to force stop the ecpu of the specified unit.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to stop ecpu.
 */
clx_error_no_t
hal_mt_kg_ecpu_force_stop(const uint32 unit);

/**
 * @brief This API is used to read ecpu memory.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    addr    - Memory address.
 * @param [in]    len     - Memory length.
 * @param [in]    pbuf    - Buffer.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_OTHERS           - Failed to read memory.
 * @return        CLX_E_BAD_PARAMETER    - Parameters is invalid.
 */
clx_error_no_t
hal_mt_kg_ecpu_memory_read(const uint32 unit, const uint32 addr, const uint32 len, uint32 *pbuf);

/**
 * @brief This API is used to upload fireware to ecpu sram and start ecpu.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    core    - Core number.
 * @param [in]    path    - Fireware file name.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_OTHERS           - Failed to upload fireware.
 * @return        CLX_E_BAD_PARAMETER    - Failed to open fireware file,
 *                                         maybe it doesn't exist.
 */
clx_error_no_t
hal_mt_kg_ecpu_sram_fw_update(const uint32 unit, const uint32 core, char *path);

/**
 * @brief This API is used to register ecpu interrupt callback.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to register interrupt callback.
 */
clx_error_no_t
hal_mt_kg_ecpu_intr_register(const uint32 unit);

/**
 * @brief This API is used to unregister ecpu interrupt callback.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to register interrupt callback.
 */
clx_error_no_t
hal_mt_kg_ecpu_intr_unregister(const uint32 unit);

/**
 * @brief This API is used to trigger host to ecpu interrupt.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    core    - Core number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_ecpu_intr_to_ecpu_trigger(const uint32 unit, const uint32 core);

/**
 * @brief This API is used to clear ecpu to host interrupt.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    core    - Core number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_ecpu_from_ecpu_intr_clr(const uint32 unit, const uint32 core);

/**
 * @brief This API is used to enable ecpu to host interrupt.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    core    - Core number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_kg_ecpu_from_ecpu_intr_enable(const uint32 unit, const uint32 core);

clx_error_no_t
hal_mt_kg_ecpu_pdma_disable(const uint32 unit);

/**
 * @brief This API is used to get diag log buffer information.
 *
 * @param [out]    buf_info    - Buffer information pointer.
 * @return         CLX_E_OK    - Successfully.
 */
clx_error_no_t
hal_mt_kg_ecpu_diag_log_buf_info_get(hal_ecpu_diag_buf_info_t *buf_info);

/**
 * @brief This API is used to get dtcm address.
 *
 * @param [out]    addr    - Dtcm address pointer.
 * @return         CLX_E_OK    - Successfully.
 */
clx_error_no_t
hal_mt_kg_ecpu_dtcm_addr_get(uint64 *addr);

/**
 * @brief This API is used to get dtcm on chain address.
 *
 * @param [out]    addr    - Dtcm address pointer.
 * @return         CLX_E_OK    - Successfully.
 */
clx_error_no_t
hal_mt_kg_ecpu_dtcm_on_chain_addr_get(uint64 *addr);

/**
 * @brief This API is used to get itcm address.
 *
 * @param [out]    addr    - Dtcm address pointer.
 * @return         CLX_E_OK    - Successfully.
 */
clx_error_no_t
hal_mt_kg_ecpu_itcm_addr_get(uint64 *addr);

/**
 * @brief This API is used to get itcm on chain address.
 *
 * @param [out]    addr    - Dtcm address pointer.
 * @return         CLX_E_OK    - Successfully.
 */
clx_error_no_t
hal_mt_kg_ecpu_itcm_on_chain_addr_get(uint64 *addr);

/**
 * @brief This API is used to init ecpu ring buffer tx handle.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    core    - Core number @param [inout] pbuf - Ring buffer tx handler.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
clx_error_no_t
hal_mt_kg_ecpu_ring_buf_tx_handler_init(const uint32 unit,
                                        const uint32 core,
                                        hal_ecpu_ring_buffer_control_t *pbuf);

/**
 * @brief This API is used to init ecpu ring buffer rx handle.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    core    - Core number @param [inout] pbuf - Ring buffer rx handler.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
clx_error_no_t
hal_mt_kg_ecpu_ring_buf_rx_handler_init(const uint32 unit,
                                        const uint32 core,
                                        hal_ecpu_ring_buffer_control_t *pbuf);

clx_error_no_t
hal_mt_kg_ecpu_core_num_get(const uint32 unit, uint32 *pnum);

#endif /* #ifndef HAL_MT_KG_ECPU_H */
