/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_diag.h
 * PURPOSE:
 *  Provide HAL diag structure and diag help APIs.
 *
 * NOTES:
 */

#ifndef HAL_DIAG_H
#define HAL_DIAG_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

typedef clx_error_no_t (*HAL_DIAG_INIT)(const uint32 unit);

typedef clx_error_no_t (*HAL_DIAG_DEINIT)(const uint32 unit);

/* DATA TYPE DECLARATIONS
 */
typedef struct hal_diag_info_s {
    const char *driver_desc;
    HAL_DIAG_INIT init;
    HAL_DIAG_DEINIT deinit;
} hal_diag_info_t;

typedef struct hal_diag_reg_stage_s {
    char *stage_name;
    char **stage_reg;
    uint32 reg_num;
} hal_diag_reg_stage_t;

typedef clx_error_no_t (*hal_diag_sub_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_diag_sub_deinit_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_diag_sub_stage_reg_list_get_func_t)(const uint32 unit,
                                                                 uint32 stage_type,
                                                                 const char *stage_name,
                                                                 const char ***ptr_keyword_list,
                                                                 uint32 *ptr_keyword_count);

typedef struct hal_diag_sub_func_vec_s {
    hal_diag_sub_init_func_t hal_diag_sub_init;
    hal_diag_sub_deinit_func_t hal_diag_sub_deinit;
    hal_diag_sub_stage_reg_list_get_func_t hal_diag_sub_stage_reg_list_get;
} hal_diag_sub_func_vec_t;

#define HAL_DIAG_SUB_FUNC_CALL(__unit__, __module__, __func__, __param__)                        \
    ({                                                                                           \
        clx_error_no_t __rc = CLX_E_OK;                                                          \
        hal_diag_sub_func_vec_t *__sub_func_vec = NULL;                                          \
        void *__tmp_sub_func_vec = NULL;                                                         \
        if ((NULL == PTR_HAL_FUNC_VECTOR(__unit__)->diag_func_vec) ||                            \
            (NULL == PTR_HAL_FUNC_VECTOR(__unit__)->diag_func_vec->hal_diag_sub_func_vec_get)) { \
            __rc = CLX_E_NOT_SUPPORT;                                                            \
        } else {                                                                                 \
            UTIL_LOG_PRINT(UTIL_LOG_DIAG, UTIL_LOG_INFO, "[N]\n");                               \
            __rc = (PTR_HAL_FUNC_VECTOR(__unit__)->diag_func_vec->hal_diag_sub_func_vec_get(     \
                (__unit__), &__tmp_sub_func_vec));                                               \
            __sub_func_vec = (hal_diag_sub_func_vec_t *)__tmp_sub_func_vec;                      \
        }                                                                                        \
        if ((CLX_E_OK == __rc) &&                                                                \
            ((NULL == __sub_func_vec) ||                                                         \
             (NULL == __sub_func_vec->hal_diag_##__module__##_##__func__))) {                    \
            __rc = CLX_E_BAD_PARAMETER;                                                          \
        }                                                                                        \
        if (CLX_E_OK == __rc) {                                                                  \
            UTIL_LOG_PRINT(UTIL_LOG_DIAG, UTIL_LOG_INFO, "[N]\n");                               \
            __rc = __sub_func_vec->hal_diag_##__module__##_##__func__ __param__;                 \
        }                                                                                        \
        __rc;                                                                                    \
    })
/**
 * @brief Hal_diag_init() is a function that will init diag.
 *
 * @param [in]    unit    - The unit number of this switch chip.
 * @return        CLX_E_OK        - Initialize the diag successfully.
 * @return        CLX_E_OTHERS    - Fail to initialize the diag.
 */
clx_error_no_t
hal_diag_init(const uint32 unit);

/**
 * @brief Hal_diag_deinit() is a function that will deinit diag.
 *
 * @param [in]    unit    - The unit number of this switch chip.
 * @return        CLX_E_OK        - Deinitialize the diag successfully.
 * @return        CLX_E_OTHERS    - Fail to deinitialize the diag.
 */
clx_error_no_t
hal_diag_deinit(const uint32 unit);

#endif /* #ifndef HAL_DIAG_H */
