/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_lag.h
 * PURPOSE:
 *    Provide HAL driver API functions for CL8600.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_KG_LAG_H
#define HAL_MT_KG_LAG_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_lag.h>
#include <hal/hal_lag.h>
#include <hal/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_KG_LAG_PORT_NUM               (512 - 16 - 1)
#define HAL_MT_KG_LAG_GROUP_MAX_MEMBER_NUM   (512)
#define HAL_MT_KG_LAG_GRP_ID_MIN             (0)
#define HAL_MT_KG_LAG_GRP_ID_MAX             (HAL_MT_KG_LAG_PORT_NUM - 1)
#define HAL_MT_KG_LAG_PORT_LIST_ENTRY_NUM    (2048)
#define HAL_MT_KG_LAG_PORT_LIST_ENTRY_ID_MIN (0)
#define HAL_MT_KG_LAG_PORT_LIST_ENTRY_ID_MAX (HAL_MT_KG_LAG_PORT_LIST_ENTRY_NUM - 1)

#define HAL_MT_KG_LAG_PORT_MIN(unit) (HAL_LAG_BASE_ID(unit))
#define HAL_MT_KG_LAG_PORT_MAX(unit) (HAL_LAG_BASE_ID(unit) + HAL_MT_KG_LAG_PORT_NUM - 1)
#define HAL_MT_KG_LAG_PORT_MIN_DFT   (HAL_LAG_BASE_ID_DFT)
#define HAL_MT_KG_LAG_PORT_MAX_DFT   (HAL_LAG_BASE_ID_DFT + HAL_MT_KG_LAG_PORT_NUM - 1)

#define HAL_MT_KG_LAG_HASH_VAL_OFFSET_MAX (63)

#define HAL_MT_KG_LAG_FDL_HSH_BASE_OFFSET (11)
#define HAL_MT_KG_LAG_FDL_PROB_MIN        (0)
#define HAL_MT_KG_LAG_FDL_PROB_MAX        (255)

#define HAL_MT_KG_LAG_FDL_AGE_TH  (0xf4240) /* 1ms */
#define HAL_MT_KG_LAG_FDL_SCAN_TH (0x12c)
/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
clx_error_no_t
hal_mt_kg_lag_init_cfg(const uint32 unit);

clx_error_no_t
hal_mt_kg_lag_oriact_list_free(const uint32 unit,
                               const uint32 lag_id,
                               hal_lag_info_t *ptr_lag_info);

clx_error_no_t
hal_mt_kg_lag_oriact_list_alloc(const uint32 unit,
                                const uint32 lag_id,
                                hal_lag_info_t *ptr_lag_info);

clx_error_no_t
hal_mt_kg_lag_member_si_set(const uint32 unit,
                            const uint32 lag_di,
                            const uint32 add_member_cnt,
                            const hal_lag_member_di_info_t *ptr_add_member_di,
                            const uint32 del_member_cnt,
                            const uint32 *ptr_del_member_di);

clx_error_no_t
hal_mt_kg_lag_info_get(const uint32 unit,
                       const uint32 lag_id,
                       uint32 *ptr_member_cnt,
                       uint32 *ptr_member_di,
                       hal_lag_info_t *ptr_lag_info);

clx_error_no_t
hal_mt_kg_lag_info_set(const uint32 unit, const uint32 lag_id, const hal_lag_info_t *ptr_lag_info);

clx_error_no_t
hal_mt_kg_lag_hsh_path_by_hsh_get(const uint32 unit,
                                  const clx_swc_hsh_pkt_type_t hash_type,
                                  const uint32 lag_id,
                                  clx_lag_hashpath_rslt_info_t *ptr_rslt);

clx_error_no_t
hal_mt_kg_lag_attr_set(const uint32 unit, const uint32 lag_id, const clx_lag_attr_t *ptr_attr);

clx_error_no_t
hal_mt_kg_lag_attr_get(const uint32 unit, const uint32 lag_id, clx_lag_attr_t *ptr_attr);

clx_error_no_t
hal_mt_kg_lag_mc_hash_engine_set(const uint32 unit, const clx_swc_hsh_pkt_type_t hash_engine);

clx_error_no_t
hal_mt_kg_lag_mc_hash_engine_get(const uint32 unit, clx_swc_hsh_pkt_type_t *ptr_hash_engine);

clx_error_no_t
hal_mt_kg_lag_failover_set(const uint32 unit, const uint32 enable);

clx_error_no_t
hal_mt_kg_lag_failover_get(const uint32 unit, uint32 *ptr_enable);

clx_error_no_t
hal_mt_kg_lag_fdl_create(const uint32 unit,
                         const clx_lag_fdl_info_t *ptr_fdl_info,
                         uint32 *ptr_fdl_id);

clx_error_no_t
hal_mt_kg_lag_fdl_destroy(const uint32 unit, const uint32 fdl_id);

clx_error_no_t
hal_mt_kg_lag_fdl_set(const uint32 unit,
                      const clx_lag_fdl_info_t *ptr_fdl_info,
                      const uint32 fdl_id);

clx_error_no_t
hal_mt_kg_lag_fdl_get(const uint32 unit, const uint32 fdl_id, clx_lag_fdl_info_t *ptr_fdl_info);

clx_error_no_t
hal_mt_kg_lag_fdl_enable(const uint32 unit, const uint32 fdl_id, const uint32 enable);

clx_error_no_t
hal_mt_kg_lag_fdl_member_sync(const uint32 unit,
                              const uint32 lag_id,
                              const uint32 fdl_id,
                              const uint32 add_member_cnt,
                              const uint32 *ptr_add_member_di,
                              const uint32 del_member_cnt,
                              const uint32 *ptr_del_member_di);
#endif /* End of HAL_MT_KG_LAG_H */
