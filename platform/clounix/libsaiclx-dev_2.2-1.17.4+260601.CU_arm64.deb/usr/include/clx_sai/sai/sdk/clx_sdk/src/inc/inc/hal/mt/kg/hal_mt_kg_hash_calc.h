/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_hash_calc.h
 * PURPOSE:
 *  Declare Kawagarbo (CL8400) hash calculation types and functions.
 *
 * NOTES:
 */
#ifndef HAL_MT_KG_HASH_CALC_H
#define HAL_MT_KG_HASH_CALC_H

#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_swc.h>
#include <clx/clx_l3.h>
#include <hal/hal.h>
#include <tob/tob_tbl.h>
#include <hal/mt/kg/hal_mt_kg_hash_algo.h>
#include <util/util_log.h>

#define HAL_MT_KG_HASH_SWC_FLOW_PKT_HSH_FLAFS_COMPR (1 << 0)

#define HAL_MT_KG_HASH_SWC_FLOW_PKT_HSH_OUTPUT_MSK_XOR_MODE 1
#define HAL_MT_KG_HASH_SWC_FLOW_PKT_HSH_OUTPUT_SHIFT_0      0

#define HAL_MT_KG_HASH_SWC_FLOW_HSH_MPLS_KEY_LEN         (80)
#define HAL_MT_KG_HASH_SWC_FLOW_HSH_SI_L2_KEY_LEN        (126)
#define HAL_MT_KG_HASH_SWC_FLOW_HSH_L2_VID_L4_KEY_LEN    (128)
#define HAL_MT_KG_HASH_SWC_FLOW_HSH_L2_VID_INNER_KEY_LEN (127)
#define HAL_MT_KG_HASH_SWC_FLOW_HSH_L4_VM_INNER_KEY_LEN  (128)
#define HAL_MT_KG_HASH_SWC_FLOW_HSH_L3_IP_KEY_LEN        (128)
#define HAL_MT_KG_HASH_SWC_FLOW_HSH_COMPR_KEY_LEN        (128)

typedef struct hal_mt_kg_hash_calc_flow_hsh_si_l2_key_s {
    uint32 si;
    clx_mac_t dmac;
    clx_mac_t smac;
    uint32 l2_last_etype;
} hal_mt_kg_hash_calc_flow_hsh_si_l2_key_t;

typedef struct hal_mt_kg_hash_calc_flow_hsh_l2_vid_l4_key_s {
    uint32 svlan;
    uint32 cvlan;
    uint32 l3_ipv6_flw_lbl;
    uint32 l3_ulp;
    uint32 l4_dp;
    uint32 l4_sp;
    uint32 tnl_vni;
    uint32 tds_pre_acl_udf_0;
    uint32 entropy;
    uint32 flags;
} hal_mt_kg_hash_calc_flow_hsh_l2_vid_l4_key_t;

typedef struct hal_mt_kg_hash_calc_flow_hsh_l2_vid_inner_key_s {
    uint32 ipid;
    clx_mac_t dmac;
    clx_mac_t smac;
    uint32 svlan;
    uint32 cvlan;
} hal_mt_kg_hash_calc_flow_hsh_l2_vid_inner_key_t;

typedef struct hal_mt_kg_hash_calc_flow_hsh_key_s {
    hal_mt_kg_hash_calc_flow_hsh_si_l2_key_t si_l2_key;
    hal_mt_kg_hash_calc_flow_hsh_l2_vid_l4_key_t l2_vid_l4_key;
    clx_swc_flow_hsh_l3_ip_key_t l3_dip_key;
    clx_swc_flow_hsh_l3_ip_key_t l3_sip_key;
    clx_swc_flow_hsh_mpls_key_t mpls_key;
    hal_mt_kg_hash_calc_flow_hsh_l2_vid_inner_key_t l2_vid_inner_key;
    clx_swc_flow_hsh_l3_ip_key_t l3_dip_inner_key;
    clx_swc_flow_hsh_l3_ip_key_t l3_sip_inner_key;
    clx_swc_flow_hsh_mpls_key_t mpls_inner_key;
    clx_swc_flow_hsh_l4_inner_key_t l4_vm_inner_key;
} hal_mt_kg_hash_calc_flow_hsh_key_t;

typedef enum hal_mt_kg_hash_calc_flow_hsh_mpls_fld_e {
    HAL_MT_KG_HASH_CALC_FLOW_HSH_MPLS_KEY_LBL0_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_MPLS_KEY_LBL1_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_MPLS_KEY_LBL2_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_MPLS_KEY_LBL3_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_MPLS_KEY_LAST_FLD_ID
} hal_mt_kg_hash_calc_flow_hsh_mpls_fld_t;

typedef enum hal_mt_kg_hash_calc_flow_hsh_si_l2_key_fld_e {
    HAL_MT_KG_HASH_CALC_FLOW_HSH_SI_L2_KEY_SI_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_SI_L2_KEY_DMAC_VAL_0_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_SI_L2_KEY_DMAC_VAL_1_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_SI_L2_KEY_SMAC_VAL_0_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_SI_L2_KEY_SMAC_VAL_1_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_SI_L2_KEY_L2_LAST_ETYPE_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_SI_L2_KEY_LAST_FLD_ID
} hal_mt_kg_hash_calc_flow_hsh_si_l2_key_fld_t;

typedef enum hal_mt_kg_hash_calc_flow_hsh_l2_vid_l4_key_fld_e {
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L2_VID_L4_KEY_SVLAN_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L2_VID_L4_KEY_CVLAN_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L2_VID_L4_KEY_L3_IPV6_FLW_LBL_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L2_VID_L4_KEY_L3_ULP_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L2_VID_L4_KEY_L4_DP_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L2_VID_L4_KEY_L4_SP_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L2_VID_L4_KEY_TNL_VNI_FLD_ID,
    /* ENTROPY is multiplexed with TDS_PRE_ACL_UDF_0 */
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L2_VID_L4_KEY_TDS_PRE_ACL_UDF_0_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L2_VID_L4_KEY_ENTROPY_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L2_VID_L4_KEY_LAST_FLD_ID
} hal_mt_kg_hash_calc_flow_hsh_l2_vid_l4_key_fld_t;

typedef enum hal_mt_kg_hash_calc_flow_hsh_l2_vid_inner_key_fld_e {
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L2_VID_INNER_KEY_IPID_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L2_VID_INNER_KEY_L2_DMAC_0_INNER_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L2_VID_INNER_KEY_L2_DMAC_1_INNER_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L2_VID_INNER_KEY_L2_SMAC_0_INNER_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L2_VID_INNER_KEY_L2_SMAC_1_INNER_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L2_VID_INNER_KEY_L2_SVLAN_INNER_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L2_VID_INNER_KEY_L2_CVLAN_INNER_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L2_VID_INNER_KEY_LAST_FLD_ID
} hal_mt_kg_hash_calc_flow_hsh_l2_vid_inner_key_fld_t;

typedef enum hal_mt_kg_hash_calc_flow_hsh_l4_vm_inner_key_fld_e {
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L4_VM_INNER_KEY_L2_LAST_ETYPE_INNER_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L4_VM_INNER_KEY_L3_IPV6_FLW_LBL_INNER_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L4_VM_INNER_KEY_L3_ULP_INNER_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L4_VM_INNER_KEY_L4_DP_INNER_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L4_VM_INNER_KEY_L4_SP_INNER_FLD_ID,
    /*
     * DST_VMID_INNER is multiplexed with TDS_PRE_ACL_UDF_1 and DIS_PRE_ACL_UDF_0:
     * TDS_PRE_ACL_UDF_1 = DST_VMID_INNER & 0xffff
     * DIS_PRE_ACL_UDF_0 = (DST_VMID_INNER >> 16) & 0x3f
     */
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L4_VM_INNER_KEY_TDS_PRE_ACL_UDF_1_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L4_VM_INNER_KEY_DIS_PRE_ACL_UDF_0_FLD_ID,
    /* SRC_VMID_INNER is multiplexed with DIS_PRE_ACL_UDF_1 */
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L4_VM_INNER_KEY_DIS_PRE_ACL_UDF_1_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L4_VM_INNER_KEY_SRC_VMID_INNER_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L4_VM_INNER_KEY_LAST_FLD_ID
} hal_mt_kg_hash_calc_flow_hsh_l4_vm_inner_key_fld_t;

typedef enum hal_mt_kg_hash_calc_flow_hsh_l3_ip_key_fld_e {
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L3_IP_KEY_IP0_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L3_IP_KEY_IP1_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L3_IP_KEY_IP2_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L3_IP_KEY_IP3_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_L3_IP_KEY_LAST_FLD_ID
} hal_mt_kg_hash_calc_flow_hsh_l3_ip_key_fld_t;

typedef enum hal_mt_kg_hash_calc_flow_hsh_compr_hsh_eng_key_fld_e {
    HAL_MT_KG_HASH_CALC_FLOW_HSH_COMPR_HSH_ENG_KEY_SI_L2_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_COMPR_HSH_ENG_KEY_L2_VID_L4_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_COMPR_HSH_ENG_KEY_L3_DIP_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_COMPR_HSH_ENG_KEY_L3_SIP_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_COMPR_HSH_ENG_KEY_L2_VID_INNER_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_COMPR_HSH_ENG_KEY_L3_DIP_INNER_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_COMPR_HSH_ENG_KEY_L3_SIP_INNER_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_COMPR_HSH_ENG_KEY_L4_VM_INNER_FLD_ID,
    HAL_MT_KG_HASH_CALC_FLOW_HSH_COMPR_HSH_ENG_KEY_LAST_FLD_ID
} hal_mt_kg_hash_calc_flow_hsh_compr_hsh_eng_key_fld_t;

typedef struct hal_mt_kg_hash_calc_flow_hsh_compr_hsh_eng_key_s {
    uint32 si_l2;
    uint32 l2_vid_L4;
    uint32 l3_dip;
    uint32 l3_sip;
    uint32 l2_vid_inner;
    uint32 l3_dip_inner;
    uint32 l3_sip_inner;
    uint32 l4_vm_inner;
} hal_mt_kg_hash_calc_flow_hsh_compr_hsh_eng_key_t;

/**
 * @brief This function is to get flow hash value.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     prof_id         - Hash profile id.
 * @param [in]     hash_type       - Hash type.
 * @param [in]     ptr_hash_key    - Hash key.
 * @param [out]    p_hash_value    - Hash value.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_kg_hash_calc_swc_hsh_prof_path_val_get(const uint32 unit,
                                              const uint32 prof_id,
                                              const clx_swc_hsh_pkt_type_t hash_type,
                                              const clx_swc_flow_hsh_key_t *ptr_hash_key,
                                              uint32 *p_hash_value);

/**
 * @brief To get packet hash path.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     prof_id         - Hash profile id.
 * @param [in]     hash_type       - Hash type.
 * @param [in]     ptr_hash_key    - Pointer of hash key.
 * @param [in]     id              - Lag id / ECMP group id.
 * @param [out]    ptr_rslt        - Pointer of result.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
hal_mt_kg_hash_calc_swc_hsh_prof_path_get(const uint32 unit,
                                          const uint32 prof_id,
                                          const clx_swc_hsh_pkt_type_t hash_type,
                                          const clx_swc_flow_hsh_key_t *ptr_hash_key,
                                          const uint32 id,
                                          clx_swc_hsh_path_rslt_info_t *ptr_rslt);

/**
 * @brief To get hash path key.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     prof_id           - Hash profile id.
 * @param [in]     hash_type         - Hash type.
 * @param [in]     pkt_info          - Packet info.
 * @param [out]    ptr_key_bitmap    - Pointer of key bitmap.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
hal_mt_kg_hash_calc_swc_hsh_prof_path_key_get(const uint32 unit,
                                              const uint32 prof_id,
                                              const clx_swc_hsh_pkt_type_t hash_type,
                                              const clx_swc_hsh_path_pkt_info_t pkt_info,
                                              clx_swc_hsh_key_bmp_t *ptr_key_bitmap);
#endif