/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI, CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_namchabarwa_pkj_psr.h
 * PURPOSE:
 *     It provides packet journal parser trigger APIs for CL8600.
 *
 * NOTES:
 *
 */
#ifndef HAL_MT_NB_PKJ_PSR_H
#define HAL_MT_NB_PKJ_PSR_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <hal/hal_pkj.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* GLOBAL VARIABLE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM DECLARATIONS
 */
clx_error_no_t
hal_mt_nb_pkj_psr_init(const uint32 unit);

clx_error_no_t
hal_mt_nb_pkj_psr_deinit(const uint32 unit);

clx_error_no_t
hal_mt_nb_pkj_psr_property_set(const uint32 unit,
                               const hal_pkj_property_t property,
                               const uint32 value);

clx_error_no_t
hal_mt_nb_pkj_psr_property_get(const uint32 unit,
                               const hal_pkj_property_t property,
                               uint32 *ptr_value);

clx_error_no_t
hal_mt_nb_pkj_psr_trigger_key_set(const uint32 unit,
                                  const uint32 flags,
                                  const hal_pkj_trig_key_t *ptr_trig_key);

clx_error_no_t
hal_mt_nb_pkj_psr_trigger_key_get(const uint32 unit, hal_pkj_trig_key_t *ptr_trig_key);

clx_error_no_t
hal_mt_nb_pkj_psr_tm_capture_sel_set(const uint32 unit, const hal_pkj_tm_capture_sel_t *ptr_tm_sel);

clx_error_no_t
hal_mt_nb_pkj_psr_tm_capture_sel_get(const uint32 unit, hal_pkj_tm_capture_sel_t *ptr_tm_sel);

clx_error_no_t
hal_mt_nb_pkj_psr_fpu_tcam_cb_id_get(const uint32 unit,
                                     const uint32 slc_id,
                                     const uint32 tcam_id,
                                     uint32 *ptr_cbid);

clx_error_no_t
hal_mt_nb_pkj_psr_fpu_hash_cb_id_get(const uint32 unit,
                                     const uint32 slc_id,
                                     const uint32 stage_id,
                                     const uint32 tile_id,
                                     uint32 *ptr_cbid);
#endif /* End of HAL_MT_NB_PKJ_PSR_H */