/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_sec.h
 * PURPOSE:
 *    Provide HAL driver API functions for namchabarwa.
 *
 * NOTES:
 *    None
 */

#ifndef HAL_MT_NB_SEC_H
#define HAL_MT_NB_SEC_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_sec.h>
#include <hal/hal_sec.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define HAL_MT_NB_SEC_ISOLATION_GRP_NUM_MAX (1)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Get the isolation group config.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     grp_id         - Group id.
 * @param [out]    ptr_grp_cfg    - Isolation group config.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mt_nb_sec_isola_grp_cfg_get(const uint32 unit,
                                const uint32 grp_id,
                                clx_sec_isolation_grp_cfg_t *ptr_grp_cfg);

/**
 * @brief Set the isolation group config.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    grp_id         - Group id.
 * @param [in]    ptr_grp_cfg    - Isolation group config.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mt_nb_sec_isola_grp_cfg_set(const uint32 unit,
                                const uint32 grp_id,
                                const clx_sec_isolation_grp_cfg_t *ptr_grp_cfg);

/**
 * @brief Set isolation port config.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Port id.
 * @param [in]    ptr_port_cfg    - Isolation port config information.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_nb_sec_isola_port_cfg_set(const uint32 unit,
                                 const clx_port_t port,
                                 const clx_sec_isolation_port_cfg_t *ptr_port_cfg);

/**
 * @brief Get isolation port config.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Port id.
 * @param [out]    ptr_port_cfg    - Isolation port config information.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_nb_sec_isola_port_cfg_get(const uint32 unit,
                                 const clx_port_t port,
                                 clx_sec_isolation_port_cfg_t *ptr_port_cfg);

#endif /* End of HAL_MT_NB_SEC_H */
