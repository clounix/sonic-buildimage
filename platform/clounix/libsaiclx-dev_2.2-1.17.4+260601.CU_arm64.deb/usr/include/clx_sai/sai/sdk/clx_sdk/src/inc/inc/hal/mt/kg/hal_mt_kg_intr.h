/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   hal_mt_kg_intr.h
 * PURPOSE:
 *      It provide HAL INTR module API.
 * NOTES:
 */

#ifndef HAL_MT_KG_INTR_H
#define HAL_MT_KG_INTR_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_init.h>
#include <hal/mt/hal_mt_intr.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MT_KG_INTR_CHAIN_CNT (7)

/* DATA TYPE DECLARATIONS
 */
typedef struct hal_mt_kg_intr_slv_info_s {
    char slv_name[64];  /* SLV device name */
    uint32 bit_offset;  /* Bit offset in chain register */
    uint32 hier_id;     /* Hierarchical register ID, like MT_KG_REG_TOP_HIER_IRQ_ID */
    uint32 hier_msk_id; /* Hierarchical mask register ID, like MT_KG_REG_TOP_HIER_IRQ_MSK_ID */
    uint32 hier_tst_id; /* Hierarchical test register ID, like MT_KG_REG_TOP_HIER_IRQ_TST_ID */
    uint32 subinst;     /* Sub-instance for CLX_DDC_SLV, 0~11 subinstances.
                           MT_KG_REG_CLX_DDC_RSFEC_DEC_IN_MEM_ECC_ERR_INT_ID */
    const hal_mt_intr_node_t *node_head; /* Head node */
} hal_mt_kg_intr_slv_info_t;

typedef struct hal_mt_kg_intr_chain_info_s {
    hal_mt_kg_intr_slv_info_t *ptr_chain_array; /* Pointer to chain0~6 array */
    uint32 slv_cnt;                             /* Number of slaves in each chain array */
} hal_mt_kg_intr_chain_info_t;

#endif /* #ifndef HAL_MT_KG_INTR_H */
