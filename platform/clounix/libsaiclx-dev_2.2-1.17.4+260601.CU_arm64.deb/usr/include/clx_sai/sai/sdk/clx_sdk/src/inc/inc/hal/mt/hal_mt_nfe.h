/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nfe.h
 * PURPOSE:
 *    Provide HAL driver API functions for netflow module.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NFE_H
#define HAL_MT_NFE_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_nfe.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_NFE_CB_MUTEX_SEMA_NAME     ("NFE_CB_MUTEX_SEMA")
#define HAL_MT_NFE_SLC_CNT                2
#define HAL_MT_NFE_PROF_CNT_MAX           32
#define HAL_MT_NFE_THD_CFG_DFLT           0xFFFF
#define HAL_MT_NFE_AGING_INTERVAL_DFLT    (30 * 1000) // 30s
#define HAL_MT_NFE_AGING_INTERVAL_MIN     (1000)      // 1s
#define HAL_MT_NFE_AGING_INTERVAL_INVALID (0)         // 0s

#define HAL_MT_NFE_IP4_PREFIX_LEN_MAX  32
#define HAL_MT_NFE_IP6_PREFIX_LEN_MAX  128
#define HAL_MT_NFE_IP4_PREFIX_LEN_DFLT 32
#define HAL_MT_NFE_IP6_PREFIX_LEN_DFLT 128
#define HAL_MT_NFE_SAMPLER_DFLT        0
#define HAL_MT_NFE_LATENCY_MODE_DFLT   CLX_NFE_LATENCY_UNIT_1NS
#define HAL_MT_NFE_PKT_TYPE_DFLT       CLX_NFE_PKT_TYPE_ALL
#define HAL_MT_NFE_PKT_LEN_TYPE_DFLT   CLX_NFE_PKT_LEN_TYPE_FRM
#define HAL_MT_NFE_KEY_DFLT            0
#define HAL_MT_NFE_THD_MAX             0xffff
#define HAL_MT_NFE_FLOW_EVENT_DFLT                                                \
    (CLX_NFE_EVENT_FLAG_TCP_FIN | CLX_NFE_EVENT_FLAG_TCP_RST |                    \
     CLX_NFE_EVENT_FLAG_BYTE_CNT_OVERFLOW | CLX_NFE_EVENT_FLAG_PKT_CNT_OVERFLOW | \
     CLX_NFE_EVENT_FLAG_TOTAL_QUEUE_OVERFLOW | CLX_NFE_EVENT_FLAG_TOTAL_LATENCY_OVERFLOW)

#define HAL_MT_NFE_FLOW_ENTRY_NTY_MAX 1024

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MT_NFE_CHECK_RC_RETURN(rc, module, level, format, arg...)   \
    do {                                                                \
        if (rc != CLX_E_OK) {                                           \
            UTIL_LOG_PRINT(module, level, "rc:%u, " format, rc, ##arg); \
            return rc;                                                  \
        }                                                               \
    } while (0);

#define HAL_MT_NFE_CHECK_RC_NOT_RETURN(rc, module, level, format, arg...) \
    do {                                                                  \
        if (rc != CLX_E_OK) {                                             \
            UTIL_LOG_PRINT(module, level, "rc:%u, " format, rc, ##arg);   \
        }                                                                 \
    } while (0);

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_mt_nfe_fsm_status_e {
    HAL_MT_NFE_FSM_STATUS_IDLE,
    HAL_MT_NFE_FSM_STATUS_IGR_SCAN_1X_WAIT_DONE,
    HAL_MT_NFE_FSM_STATUS_IGR_SCAN_2X_WAIT_DONE,
    HAL_MT_NFE_FSM_STATUS_IGR_AGING_1X_WAIT_DONE,
    HAL_MT_NFE_FSM_STATUS_IGR_AGING_2X_WAIT_DONE,
    HAL_MT_NFE_FSM_STATUS_IGR_FORCE_AGING_1X_WAIT_DONE,
    HAL_MT_NFE_FSM_STATUS_IGR_FORCE_AGING_2X_WAIT_DONE,
    HAL_MT_NFE_FSM_STATUS_EGR_SCAN_1X_WAIT_DONE,
    HAL_MT_NFE_FSM_STATUS_EGR_SCAN_2X_WAIT_DONE,
    HAL_MT_NFE_FSM_STATUS_EGR_AGING_1X_WAIT_DONE,
    HAL_MT_NFE_FSM_STATUS_EGR_AGING_2X_WAIT_DONE,
    HAL_MT_NFE_FSM_STATUS_EGR_FORCE_AGING_1X_WAIT_DONE,
    HAL_MT_NFE_FSM_STATUS_EGR_FORCE_AGING_2X_WAIT_DONE,
    HAL_MT_NFE_FSM_STATUS_LAST,
} hal_mt_nfe_fsm_status_t;

/* Macro to convert FSM status to direction */
#define HAL_MT_NFE_STATUS_TO_DIR(status)                        \
    (((status) < HAL_MT_NFE_FSM_STATUS_EGR_SCAN_1X_WAIT_DONE) ? \
         CLX_NFE_DIR_IGR :                                      \
         (((status) < HAL_MT_NFE_FSM_STATUS_LAST) ? CLX_NFE_DIR_EGR : CLX_NFE_DIR_IGR))

/*
 * NFE FSM events definition.
 */
typedef enum hal_mt_nfe_fsm_event_e {
    HAL_MT_NFE_FSM_EVENT_SCAN_START = 0,
    HAL_MT_NFE_FSM_EVENT_AGE_START,
    HAL_MT_NFE_FSM_EVENT_FORCE_AGE_START,
    HAL_MT_NFE_FSM_EVENT_SCAN_DONE,
    HAL_MT_NFE_FSM_EVENT_BATCH_DONE,
    HAL_MT_NFE_FSM_EVENT_ABORT,
    HAL_MT_NFE_FSM_EVENT_FINISH,
    HAL_MT_NFE_FSM_EVENT_LAST,
} hal_mt_nfe_fsm_event_t;

/*
 * NFE FSM action function prototype.
 */
typedef clx_error_no_t (*hal_mt_nfe_fsm_action_func_t)(const uint32 unit, const uint32 slc);

typedef struct hal_mt_nfe_prof_info_s {
    boolean is_used;
    uint32 ref_cnt;
    clx_semaphore_id_t sema;
    clx_nfe_prof_cfg_info_t prof_cfg;
} hal_mt_nfe_prof_info_t;

#define HAL_MT_NFE_FLAG_SCAN_DONE  0x1
#define HAL_MT_NFE_FLAG_BATCH_DONE 0x2
#define HAL_MT_NFE_FLAG_ALL_DONE   ((HAL_MT_NFE_FLAG_SCAN_DONE) | (HAL_MT_NFE_FLAG_BATCH_DONE))

#define HAL_MT_NFE_FSM_PENDING_EVT_CNT (4)
typedef struct hal_mt_nfe_fsm_info_s {
    hal_mt_nfe_fsm_status_t status;
    uint16 flag_on_slice[HAL_MT_NFE_SLC_CNT];
    hal_mt_nfe_fsm_event_t fsm_pending_evt[HAL_MT_NFE_FSM_PENDING_EVT_CNT];
    uint32 fsm_pending_evt_idx;
    hal_mt_nfe_fsm_event_t current_evt;
    uint32 fsm_flag;
} hal_mt_nfe_fsm_info_t;

typedef struct hal_mt_nfe_fifo_notify_handler_s {
    clx_nfe_flow_data_notify_func_t callback;
    void *ptr_cookie;
} hal_mt_nfe_fifo_notify_handler_t;

typedef struct hal_mt_nfe_thd_info_s {
    boolean is_yellow_happened;
    boolean is_red_happened;
    clx_nfe_thd_cfg_t thd_cfg;
} hal_mt_nfe_thd_info_t;

typedef struct hal_mt_nfe_aging_info_s {
    osal_timer_id_t timer_id;
    uint32 aging_interval;
    uint32 running_aging_interval;
    boolean is_aging_running;
} hal_mt_nfe_aging_info_t;

typedef struct hal_mt_nfe_scan_info_s {
    osal_timer_id_t timer_id;
    uint32 scan_interval;
    boolean is_scan_running;
} hal_mt_nfe_scan_info_t;

typedef struct hal_mt_nfe_glb_info_s {
    uint32 unit;
    clx_nfe_dir_t dir;
    hal_mt_nfe_thd_info_t thd_info;
} hal_mt_nfe_glb_info_t;

typedef struct hal_mt_nfe_cb_s {
    hal_mt_nfe_prof_info_t prof_info[HAL_MT_NFE_PROF_CNT_MAX];
    hal_mt_nfe_glb_info_t glb_info[CLX_NFE_DIR_LAST];
    clx_semaphore_id_t sema;
    hal_mt_nfe_aging_info_t aging_info;
    hal_mt_nfe_scan_info_t scan_info;
    hal_mt_nfe_fsm_info_t fsm_info;
    hal_mt_nfe_fifo_notify_handler_t notify_handler;
} hal_mt_nfe_cb_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief This API is used to initialize nfe module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK                - Successfully.
 * @return        CLX_E_ALREADY_INITED    - Already initialized.
 * @return        CLX_E_OTHERS            - Other errors.
 */
clx_error_no_t
hal_mt_nfe_init(const uint32 unit);

/**
 * @brief This API is used to deinitialize nfe module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK            - Successfully.
 * @return        CLX_E_NOT_INITED    - Not initialized.
 * @return        CLX_E_OTHERS        - Other errors.
 */
clx_error_no_t
hal_mt_nfe_deinit(const uint32 unit);

/**
 * @brief This API is used to handle nfe scan done interrupt.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    slc     - Slice number.
 * @param [in]    dir     - Direction.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_nfe_scan_done_proc(const uint32 unit, const uint32 slc, const uint32 dir);

/**
 * @brief This API is used to handle nfe scan done interrupt.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    dir     - Direction.
 * @param [in]    slc     - Slice number.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_nfe_yellow_thd_intr_proc(const uint32 unit, const uint32 dir, const uint32 slc);

/**
 * @brief This API is used to handle nfe scan done interrupt.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    dir     - Direction.
 * @param [in]    slc     - Slice number.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_nfe_red_thd_intr_proc(const uint32 unit, const uint32 dir, const uint32 slc);

/**
 * @brief This API is used to create nfe profile.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     ptr_nfe_info       - NFE profile configuration information.
 * @param [out]    ptr_nfe_prof_id    - NFE profile ID.
 * @return         CLX_E_OK               - Successfully.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return         CLX_E_TABLE_FULL       - Profile table full.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_nfe_prof_create(const uint32 unit,
                       const clx_nfe_prof_cfg_info_t *ptr_nfe_info,
                       uint32 *ptr_nfe_prof_id);

/**
 * @brief This API is used to destroy nfe profile.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    nfe_prof_id    - NFE profile ID.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_ENTRY_IN_USE     - Profile in use.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_nfe_prof_destroy(const uint32 unit, const uint32 nfe_prof_id);

/**
 * @brief This API is used to reference nfe profile.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    nfe_prof_id    - NFE profile ID.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_nfe_prof_refer_incr(const uint32 unit, const uint32 nfe_prof_id);

/**
 * @brief This API is used to unreference nfe profile.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    nfe_prof_id    - NFE profile ID.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_nfe_prof_refer_decr(const uint32 unit, const uint32 nfe_prof_id);

/**
 * @brief This API is used to check if nfe profile is referenced.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    nfe_prof_id    - NFE profile ID.
 * @return        TRUE     - Reference count is zero.
 * @return        FALSE    - Reference count is not zero.
 */
boolean
hal_mt_nfe_prof_refer_zero_is(const uint32 unit, const uint32 nfe_prof_id);

/**
 * @brief This API is used to set nfe profile.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    nfe_prof_id     - NFE profile ID.
 * @param [in]    ptr_nfe_info    - NFE profile configuration information.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_ENTRY_IN_USE     - Profile in use.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_nfe_prof_set(const uint32 unit,
                    const uint32 nfe_prof_id,
                    const clx_nfe_prof_cfg_info_t *ptr_nfe_info);

/**
 * @brief This API is used to get nfe profile.
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     nfe_prof_id          - NFE profile ID.
 * @param [out]    ptr_nfe_prof_info    - NFE profile configuration information.
 * @return         CLX_E_OK                 - Successfully.
 * @return         CLX_E_BAD_PARAMETER      - Invalid parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Profile not found.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
hal_mt_nfe_prof_get(const uint32 unit,
                    const uint32 nfe_prof_id,
                    clx_nfe_prof_cfg_info_t *ptr_nfe_prof_info);

/**
 * @brief This API is used to set nfe long flow interval.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    interval    - Aging interval in milliseconds.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_nfe_aging_interval_set(const uint32 unit, const uint32 interval);

/**
 * @brief This API is used to get nfe long flow interval.
 *
 * @param [in]     unit            - Device unit number.
 * @param [out]    ptr_interval    - Aging interval in milliseconds.
 * @return         CLX_E_OK               - Successfully.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_nfe_aging_interval_get(const uint32 unit, uint32 *ptr_interval);

/**
 * @brief This API is used to set force aging.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_nfe_aging_force_set(const uint32 unit);

/**
 * @brief This API is used to set nfe thd.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    dir        - Direction.
 * @param [in]    ptr_cfg    - NFE threshold configuration.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_nfe_thd_set(const uint32 unit, const clx_nfe_dir_t dir, const clx_nfe_thd_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get nfe thd.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     dir        - Direction.
 * @param [out]    ptr_cfg    - NFE threshold configuration.
 * @return         CLX_E_OK               - Successfully.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_nfe_thd_get(const uint32 unit, const clx_nfe_dir_t dir, clx_nfe_thd_cfg_t *ptr_cfg);

/**
 * @brief This API is used to set flow data notify callback.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    notify_func    - Flow data notification callback function.
 * @param [in]    ptr_cookie     - User-defined cookie for callback.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_nfe_flow_data_notify_cb_set(const uint32 unit,
                                   const clx_nfe_flow_data_notify_func_t notify_func,
                                   void *ptr_cookie);

/**
 * @brief Initialize netflow FSM (Finite State Machine).
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_nfe_fsm_init(const uint32 unit);

/**
 * @brief Dispatch event to netflow FSM.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    event    - FSM event to dispatch.
 * @param [in]    slc      - Slice number.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_nfe_fsm_dispatch(const uint32 unit, const hal_mt_nfe_fsm_event_t event, const uint32 slc);

/**
 * @brief This API is used to get current state machine event.
 *
 * @param [in]    unit    - Device unit number.
 * @return        hal_mt_nfe_fsm_event_t    - Current evt.
 */
hal_mt_nfe_fsm_event_t
hal_mt_nfe_current_event_get(const uint32 unit);

#endif /* HAL_MT_NFE_H */