/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_kg_qos.h
 * PURPOSE:
 *      It provides hal qos module API.
 * NOTES:
 *      None.
 */

#ifndef HAL_MT_KG_QOS_H
#define HAL_MT_KG_QOS_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_qos.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_KAWAGARBO_INVALID_PHB_HW_IDX (0x7F) /* KG SRV INTF uses invalid index */
#define HAL_MT_KAWAGARBO_DEFAULT_PHB_HW_IDX (0x0)  /* KG LCL INTF uses default index */
#define HAL_MT_KAWAGARBO_DEFAULT_PROF_IDX   (0)    /* KG default profile index */
/* total number of traffice class for qos mapping for kawagarbo */
#define HAL_MT_KG_QOS_TC_NUM (8)
/* qos phb_prof_idx min value for local interface */
#define HAL_MT_KG_QOS_PHB_PROFILE_MIN (0)
/* qos phb_prof_idx max value for local interface */
#define HAL_MT_KG_QOS_PHB_PROFILE_MAX (127)
/* qos phb_prof_idx max value for local interface */
#define HAL_MT_KG_BDI_QOS_PHB_PROFILE_MAX (126)

extern hal_qos_init_pri_to_phb_entry_t hal_qos_init_dot1p_to_phb[HAL_QOS_DOT1P_NUM];
extern hal_qos_init_phb_to_dot1p_entry_t hal_qos_init_phb_to_dot1p[HAL_QOS_PRIORITY_NUM]
                                                                  [HAL_QOS_COLOR_NUM];
extern hal_qos_init_pri_to_phb_entry_t hal_qos_init_dscp_to_phb[HAL_QOS_DSCP_NUM];
extern hal_qos_init_phb_to_dscp_entry_t hal_qos_init_phb_to_dscp[HAL_QOS_PRIORITY_NUM]
                                                                [HAL_QOS_COLOR_NUM];
extern hal_qos_init_pri_to_phb_entry_t hal_qos_init_exp_to_phb[HAL_QOS_EXP_NUM];
extern hal_qos_init_phb_to_exp_entry_t hal_qos_init_phb_to_exp[HAL_QOS_PRIORITY_NUM]
                                                              [HAL_QOS_COLOR_NUM];
extern hal_qos_used_flag_t *_ptr_hal_qos_used_flag[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
extern clx_semaphore_id_t _profile_sema[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
/* MACRO FUNCTION DECLARATIONS
 */

/* LOCAL SUBPROGRAM DECLARATIONS
 */

/**
 * @brief This API is used to create a new QoS profile (also called QoS mapping).
 *        QoS mapping is the mapping between {pcp,dei}, {dscp} or {exp} to {priority,
 *        color}. priority(traffic class) is used by chip to derivate queue by another API
 *        clx_tm_setTcQueueMapping.
 *
 * Use this API to create a new mapping profile.
 * support_chip all.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    direction       - Mapping direction, including CLX_DIR_INGRESS and CLX_DIR_EGRESS.
 * @param [in]    mapping_type    - The type of the mapping profile. CLX_QOS_MAPPING_TYPE_DOT1P
 *                                  means the mapping of ingress pcp/dei to phb or egress phb to
 *                                  pcp/dei. CLX_QOS_MAPPING_TYPE_DSCP means the mapping of ingress
 *                                  dscp to phb or egress phb to dscp. CLX_QOS_MAPPING_TYPE_EXP
 *                                  means the mapping of ingress exp to phb or egress phb to exp.
 *                                  CLX_QOS_MAPPING_TYPE_DFLT_DOT1P, CLX_QOS_MAPPING_TYPE_DFLT_DSCP,
 *                                  CLX_QOS_MAPPING_TYPE_DFLT_EXP donot support.
 * @param [in]    profile_id      - An assigned number that represents the software profile ID and
 *                                  the index of hardware table on this QoS mapping type.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - NO more memory for the entry.
 * @return        CLX_E_ENTRY_EXISTS     - The mapping profile is already created.
 */
clx_error_no_t
hal_mt_kg_qos_prof_create(const uint32 unit,
                          const clx_dir_t direction,
                          const clx_qos_mapping_type_t mapping_type,
                          const uint32 profile_id);

/**
 * @brief This API is used to delete a QoS profile.
 *
 * Use this API to destroy a mapping profile. The mapping profile can be destroyed
 * only when the mapping profile is not used by other objects
 * (such as port/vm/interface/tunnel etc.).
 * support_chip all.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    direction       - Mapping direction, including CLX_DIR_INGRESS and CLX_DIR_EGRESS.
 * @param [in]    mapping_type    - The type of the mapping profile. CLX_QOS_MAPPING_TYPE_DOT1P
 *                                  means the mapping of ingress pcp/dei to phb or egress phb to
 *                                  pcp/dei. CLX_QOS_MAPPING_TYPE_DSCP means the mapping of ingress
 *                                  dscp to phb or egress phb to dscp. CLX_QOS_MAPPING_TYPE_EXP
 *                                  means the mapping of ingress exp to phb or egress phb to exp.
 *                                  CLX_QOS_MAPPING_TYPE_DFLT_DOT1P, CLX_QOS_MAPPING_TYPE_DFLT_DSCP,
 *                                  CLX_QOS_MAPPING_TYPE_DFLT_EXP donot support.
 * @param [in]    profile_id      - An assigned number that represents the software profile ID and
 *                                  the index of hardware table on this QoS mapping type.
 * @return        CLX_E_OK                 - Operation successful.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The mapping proile is not exist.
 * @return        CLX_E_NOT_SUPPORT        - Not support to delete the mapping profile.
 *                                           (eg. the mapping profile has been applied to a
 *                                           port/vm/interface/ tunnel and so on).
 */
clx_error_no_t
hal_mt_kg_qos_prof_delete(const uint32 unit,
                          const clx_dir_t direction,
                          const clx_qos_mapping_type_t mapping_type,
                          const uint32 profile_id);

/**
 * @brief This API is used to configure a profile entry.
 *
 * Use this API to configure a mapping entry. User should set all fields needed according to the
 * "mapping_type" parameter in the entry.
 * If "mapping_type" is CLX_QOS_MAPPING_TYPE_DOT1P or CLX_QOS_MAPPING_TYPE_DFLT_DOT1P,
 * fields "pcp", "dei", "priority", "color" must be input by user, and other fields must be ignored.
 * If "mapping_type" is CLX_QOS_MAPPING_TYPE_DSCP or CLX_QOS_MAPPING_TYPE_DFLT_DSCP,
 * fields "dscp", "priority", "color" must be input by user, and other fields must be ignored.
 * If "mapping_type" is CLX_QOS_MAPPING_TYPE_EXP or CLX_QOS_MAPPING_TYPE_DFLT_EXP,
 * fields "exp", "priority", "color" must be input by user, and other fields must be ignored.
 * support_chip all.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    direction       - Mapping direction, including CLX_DIR_INGRESS and CLX_DIR_EGRESS.
 * @param [in]    mapping_type    - The type of the mapping profile. CLX_QOS_MAPPING_TYPE_DOT1P
 *                                  means the mapping of ingress pcp/dei to phb or egress phb to
 *                                  pcp/dei. CLX_QOS_MAPPING_TYPE_DSCP means the mapping of ingress
 *                                  dscp to phb or egress phb to dscp. CLX_QOS_MAPPING_TYPE_EXP
 *                                  means the mapping of ingress exp to phb or egress phb to exp.
 *                                  CLX_QOS_MAPPING_TYPE_DFLT_DOT1P means the default mapping of
 *                                  egress phb to pcp/dei when packets untag in.
 *                                  CLX_QOS_MAPPING_TYPE_DFLT_DSCP means the default mapping of
 *                                  egress phb to dscp when packets untag in.
 *                                  CLX_QOS_MAPPING_TYPE_DFLT_EXP means the default mapping of
 *                                  egress phb to exp when packets untag in.
 * @param [in]    profile_id      - An assigned number that represents the software profile ID and
 *                                  the index of hardware table on this QoS mapping type.
 *                                  For CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI,
 *                                  CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP and
 *                                  CLX_QOS_MAPPING_DFLT_PHB_TO_EXP, the profile_id should set to 0.
 * @param [in]    ptr_cfg         - The config of the priority mapping.
 * @return        CLX_E_OK                 - Operate success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The mapping proile is not found.
 */
clx_error_no_t
hal_mt_kg_qos_prof_cfg_set(const uint32 unit,
                           const clx_dir_t direction,
                           const clx_qos_mapping_type_t mapping_type,
                           const uint32 profile_id,
                           const clx_qos_mapping_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get the information of a profile entry.
 *
 * Use this API to get a mapping entry.
 * support_chip all.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     direction       - Mapping direction, including CLX_DIR_INGRESS and
 *                                   CLX_DIR_EGRESS.
 * @param [in]     mapping_type    - The type of the mapping profile. CLX_QOS_MAPPING_TYPE_DOT1P
 *                                   means the mapping of ingress pcp/dei to phb or egress phb to
 *                                   pcp/dei. CLX_QOS_MAPPING_TYPE_DSCP means the mapping of
 *                                   ingress dscp to phb or egress phb to dscp.
 *                                   CLX_QOS_MAPPING_TYPE_EXP means the mapping of ingress exp to
 *                                   phb or egress phb to exp. CLX_QOS_MAPPING_TYPE_DFLT_DOT1P
 *                                   means the default mapping of egress phb to pcp/dei when
 *                                   packets untag in. CLX_QOS_MAPPING_TYPE_DFLT_DSCP means the
 *                                   default mapping of egress phb to dscp when packets untag in.
 *                                   CLX_QOS_MAPPING_TYPE_DFLT_EXP means the default mapping of
 *                                   egress phb to exp when packets untag in.
 * @param [in]     profile_id      - An assigned number that represents the software profile ID and
 *                                   the index of hardware table on this QoS mapping type.
 *                                   For CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI,
 *                                   CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP and
 *                                   CLX_QOS_MAPPING_DFLT_PHB_TO_EXP, the profile_id should set to
 *                                   0.
 * @param [in]     ptr_cfg         - The config which to be obtained by user.
 *                                   If "mapping_type" is CLX_QOS_MAPPING_TYPE_DOT1P: if
 *                                   "direction" is CLX_DIR_INGRESS, fields "pcp" and "dei" are the
 *                                   input. if "direction" is CLX_DIR_EGRESS,
 *                                   fields "priority" and "color" are the input.
 *                                   If "mapping_type" is CLX_QOS_MAPPING_TYPE_DSCP: if "direction"
 *                                   is CLX_DIR_INGRESS, field "dscp" is the input.
 *                                   if "direction" is CLX_DIR_EGRESS, fields "priority" and
 *                                   "color" are the input. If "mapping_type" is
 *                                   CLX_QOS_MAPPING_TYPE_EXP: if "direction" is CLX_DIR_INGRESS,
 *                                   field "exp" is the input. if "direction" is CLX_DIR_EGRESS,
 *                                   fields "priority" and "color" are the input.
 *                                   If "mapping_type" is CLX_QOS_MAPPING_TYPE_DFLT_DOT1P,
 *                                   CLX_QOS_MAPPING_TYPE_DFLT_DSCP or
 *                                   CLX_QOS_MAPPING_TYPE_DFLT_EXP, fields "priority",
 *                                   "color" are the input.
 * @param [out]    ptr_cfg         - The config which to be obtained by user.
 *                                   If "mapping_type" is CLX_QOS_MAPPING_TYPE_DOT1P: if
 *                                   "direction" is CLX_DIR_INGRESS, fields "priority" and "color"
 *                                   are the output. if "direction" is CLX_DIR_EGRESS,
 *                                   fields "pcp" and "dei" are the output.
 *                                   If "mapping_type" is CLX_QOS_MAPPING_TYPE_DSCP: if "direction"
 *                                   is CLX_DIR_INGRESS, fields "priority" and "color" are the
 *                                   output. if "direction" is CLX_DIR_EGRESS,
 *                                   field "dscp" is the output. If "mapping_type" is
 *                                   CLX_QOS_MAPPING_TYPE_EXP: if "direction" is CLX_DIR_INGRESS,
 *                                   field "priority" and "color" are the output.
 *                                   if "direction" is CLX_DIR_EGRESS, fields "exp" is the output.
 *                                   If "mapping_type" is CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI,
 *                                   fields "pcp" and "dei" are the output.
 *                                   If "mapping_type" is CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP,
 *                                   fields "dscp" is the output. If "mapping_type" is
 *                                   CLX_QOS_MAPPING_DFLT_PHB_TO_EXP, fields "exp" is the output.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The mapping profile_id is not exists.
 * @return         CLX_E_NOT_INITED         - SDK module has not been initialized.
 */
clx_error_no_t
hal_mt_kg_qos_prof_cfg_get(const uint32 unit,
                           const clx_dir_t direction,
                           const clx_qos_mapping_type_t mapping_type,
                           const uint32 profile_id,
                           clx_qos_mapping_cfg_t *ptr_cfg);

/**
 * @brief Apply or unapply a priority mapping profile.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     direction           - Mapping direction, including CLX_DIR_INGRESS and
 *                                       CLX_DIR_EGRESS.
 * @param [in]     intf_type           - Interface type: Local interface and L2 service interface.
 * @param [in]     mapping_type        - The type of the mapping profile.
 *                                       CLX_QOS_MAPPING_TYPE_DOT1P means the mapping of ingress
 *                                       pcp/dei to phb or egress phb to pcp/dei.
 *                                       CLX_QOS_MAPPING_TYPE_DSCP means the mapping of ingress
 *                                       dscp to phb or egress phb to dscp.
 *                                       CLX_QOS_MAPPING_TYPE_EXP means the mapping of ingress exp
 *                                       to phb or egress phb to exp.
 *                                       CLX_QOS_MAPPING_TYPE_DFLT_DOT1P means the default mapping
 *                                       of egress phb to pcp/dei when packets untag in.
 *                                        CLX_QOS_MAPPING_TYPE_DFLT_DSCP means the default mapping
 *                                       of egress phb to dscp when packets untag in.
 *                                        CLX_QOS_MAPPING_TYPE_DFLT_EXP means the default mapping
 *                                       of egress phb to exp when packets untag in.
 * @param [in]     profile_id          - An int value which means the mapping profile id and aslo
 *                                       the index in hardware table. 0 ~ 127: apply profile;
 *                                       CLX_QOS_INVALID_PROFILE_ID: cancel to apply profile.
 * @param [in]     ptr_phb_prof_idx    - Pointer for the old phb_prof_idx in table L2_LCL_INTF or
 *                                       L2_SRV_INTF.
 * @param [out]    ptr_phb_prof_idx    - Qos module return a new phb_prof_idx to applier.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - NO more memory for apply.
 */
clx_error_no_t
hal_mt_kg_qos_prof_apply(const uint32 unit,
                         const clx_dir_t direction,
                         const hal_qos_intf_type_t intf_type,
                         const clx_qos_mapping_type_t mapping_type,
                         const uint32 profile_id,
                         uint32 *ptr_phb_prof_idx);

clx_error_no_t
hal_mt_kg_qos_user_profile_index_get(const uint32 unit,
                                     const clx_dir_t direction,
                                     const clx_qos_mapping_type_t mapping_type,
                                     const uint32 qos_prof_id,
                                     uint32 *ptr_profile_id);

clx_error_no_t
hal_mt_kg_qos_wb_deinit(const uint32 unit, hal_io_obj_meta_t *ptr_wbdb_obj, uint32 *ptr_obj_count);
clx_error_no_t
hal_mt_kg_qos_prof_cfg_set(const uint32 unit,
                           const clx_dir_t direction,
                           const clx_qos_mapping_type_t mapping_type,
                           const uint32 profile_id,
                           const clx_qos_mapping_cfg_t *ptr_cfg);

clx_error_no_t
hal_mt_kg_qos_wb_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_kg_qos_cfg_init(const uint32 unit);

clx_error_no_t
hal_mt_kg_qos_rsc_init(const uint32 unit);

clx_error_no_t
hal_mt_kg_qos_map_prof_cfg_alloc(const uint32 unit,
                                 const clx_dir_t direction,
                                 const clx_qos_mapping_type_t mapping_type,
                                 const uint32 profile_id);

clx_error_no_t
hal_mt_kg_qos_map_prof_cfg_free(const uint32 unit,
                                const clx_dir_t direction,
                                const clx_qos_mapping_type_t mapping_type,
                                const uint32 profile_id);

clx_error_no_t
hal_mt_kg_qos_copy_to_2nd_set(const uint32 unit, const uint32 to_2nd);

clx_error_no_t
hal_mt_kg_qos_copy_to_2nd_get(const uint32 unit, uint32 *ptr_to_2nd);

#endif /* End of HAL_MT_KG_QOS_H */
