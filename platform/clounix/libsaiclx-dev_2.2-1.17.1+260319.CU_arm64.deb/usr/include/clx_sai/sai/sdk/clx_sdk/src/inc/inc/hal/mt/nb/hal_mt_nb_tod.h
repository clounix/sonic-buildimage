/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_tod.h
 * PURPOSE:
 *  Provide HAL driver API functions of tod module.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NB_TOD_H
#define HAL_MT_NB_TOD_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>

/**
 * @brief This API is used to restart tod 1pps irq.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    ptr     - Interrupt register node pointer.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
clx_error_no_t
hal_mt_nb_tod_pps_irq_restart(const uint32 unit, void *ptr);

/**
 * @brief This API is used to register tod interrupt.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
clx_error_no_t
hal_mt_nb_tod_intr_register(const uint32 unit);

/**
 * @brief This API is used to unregister tod interrupt.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
clx_error_no_t
hal_mt_nb_tod_intr_unregister(const uint32 unit);

/**
 * @brief This API is used to init hardware tod register and start-up tod.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
clx_error_no_t
hal_mt_nb_tod_hw_init(const uint32 unit);

/**
 * @brief This API is used to get current tod value from asic.
 *
 * @param [in]     unit         - Device unit number.
 * @param [out]    tod_value    - Store current tod value.
 * @return         CLX_E_OK               - Successfully.
 * @return         CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
clx_error_no_t
hal_mt_nb_tod_current_value_get(const uint32 unit, uint32 *tod_value);

#endif /* #ifndef HAL_MT_NB_TOD_H */
