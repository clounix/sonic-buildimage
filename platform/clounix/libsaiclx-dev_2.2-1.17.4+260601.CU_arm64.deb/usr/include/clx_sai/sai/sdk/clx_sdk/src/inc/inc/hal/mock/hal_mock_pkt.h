/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied, and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Co., Ltd. (C) 2020-2026
 *
 *******************************************************************************/

/* FILE NAME: hal_mock_pkt.h
 * PURPOSE:
 *      Provide HAL MOCK PKT module APIs that mirror the on-chip
 *      hal_mt_nb_pkt_srv.c / hal_mt_nb_pkt_drv.c surface but route
 *      hostif and packet TX/RX to the user-space asicsim instead of the
 *      kernel knet driver. Packet I/O is done with raw AF_PACKET sockets
 *      bound to the TAP devices that asicsim creates for each hostif,
 *      using select() + recv()/send().
 * NOTES:
 */

#ifndef HAL_MOCK_PKT_H
#define HAL_MOCK_PKT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_pkt.h>
#include <clx/clx_netif.h>

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* ------------------------------------------------------------------ Init/Deinit */
clx_error_no_t
hal_mock_pkt_init(const uint32 unit);

clx_error_no_t
hal_mock_pkt_deinit(const uint32 unit);

clx_error_no_t
hal_mock_pkt_rx_init(const uint32 unit);

clx_error_no_t
hal_mock_pkt_rx_deinit(const uint32 unit);

/* ------------------------------------------------------------------ Rx callback */
clx_error_no_t
hal_mock_pkt_rx_cb_set(const uint32 unit,
                       const clx_pkt_rx_func_t cb,
                       void *ptr_cookie,
                       const clx_pkt_cb_op_t op_mode);

clx_error_no_t
hal_mock_pkt_udf_rx_mem_cb_set(const uint32 unit,
                               const clx_pkt_rx_alloc_func_t alloc_cb,
                               const clx_pkt_rx_free_func_t free_cb);

/* ------------------------------------------------------------------ Tx */
clx_error_no_t
hal_mock_pkt_tx_send(const uint32 unit, const clx_pkt_tx_pkt_t *ptr_tx_pkt);

clx_error_no_t
hal_mock_pkt_tx_prepare(const uint32 unit,
                        clx_pkt_tx_pkt_t *ptr_pkt,
                        const uint8 *ptr_data_buf,
                        uint32 len);

/* ------------------------------------------------------------------ Counters */
clx_error_no_t
hal_mock_pkt_tx_cnt_get(const uint32 unit, const uint32 channel, clx_pkt_tx_cnt_t *ptr_tx_cnt);

clx_error_no_t
hal_mock_pkt_rx_cnt_get(const uint32 unit, const uint32 channel, clx_pkt_rx_cnt_t *ptr_rx_cnt);

clx_error_no_t
hal_mock_pkt_tx_cnt_clear(const uint32 unit, const uint32 channel);

clx_error_no_t
hal_mock_pkt_rx_cnt_clear(const uint32 unit, const uint32 channel);

clx_error_no_t
hal_mock_pkt_tx_dbg_cnt_show(const uint32 unit, const uint32 channel);

clx_error_no_t
hal_mock_pkt_rx_dbg_cnt_show(const uint32 unit, const uint32 channel);

/* ------------------------------------------------------------------ Queue cfg */
clx_error_no_t
hal_mock_pkt_queue_cfg_set(const uint32 unit, const clx_pkt_rx_queue_cfg_t *ptr_queue_cfg);

clx_error_no_t
hal_mock_pkt_queue_cfg_get(const uint32 unit, clx_pkt_rx_queue_cfg_t *ptr_queue_cfg);

/* ------------------------------------------------------------------ Hostif (NETIF) */
clx_error_no_t
hal_mock_pkt_intf_create(const uint32 unit,
                         const clx_netif_intf_t *ptr_net_intf,
                         uint32 *ptr_intf_id);

clx_error_no_t
hal_mock_pkt_intf_destroy(const uint32 unit, const uint32 id);

clx_error_no_t
hal_mock_pkt_intf_get(const uint32 unit, const uint32 intf_id, clx_netif_intf_t *ptr_net_intf);

clx_error_no_t
hal_mock_pkt_intf_set(const uint32 unit,
                      const uint32 intf_id,
                      const clx_netif_intf_t *ptr_net_intf);

clx_error_no_t
hal_mock_pkt_intf_cnt_get(const uint32 unit, const uint32 id, clx_netif_intf_cnt_t *ptr_intf_cnt);

clx_error_no_t
hal_mock_pkt_intf_cnt_clear(const uint32 unit, const uint32 id);

/* ------------------------------------------------------------------ Profile */
clx_error_no_t
hal_mock_pkt_prof_create(const uint32 unit,
                         const clx_netif_prof_t *ptr_net_profile,
                         uint32 *ptr_profile_id);

clx_error_no_t
hal_mock_pkt_prof_destroy(const uint32 unit, const uint32 id);

clx_error_no_t
hal_mock_pkt_prof_get(const uint32 unit,
                      const uint32 profile_id,
                      clx_netif_prof_t *ptr_net_profile);

/* ------------------------------------------------------------------ Netlink */
clx_error_no_t
hal_mock_pkt_netlink_create(const uint32 unit,
                            const clx_netif_netlink_t *ptr_netlink,
                            uint32 *ptr_netlink_id);

clx_error_no_t
hal_mock_pkt_netlink_destroy(const uint32 unit, const uint32 netlink_id);

clx_error_no_t
hal_mock_pkt_netlink_get(const uint32 unit,
                         const uint32 netlink_id,
                         clx_netif_netlink_t *ptr_netlink);

#endif /* HAL_MOCK_PKT_H */
