/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2026
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_stk.h
 * PURPOSE:
 *      It provides hal stacking module API.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_STK_H
#define HAL_STK_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_stk.h>
#include <clx/clx_port.h>
#include <hal/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_STK_DFLT_CHIP_MODE  (HAL_STK_CHIP_MODE_PORT_CHIP)
#define HAL_STK_DFLT_CHIP_ID    (0)
#define HAL_STK_INVALID_CHIP_ID (HAL_INVALID_CHIP_ID)

#define HAL_STK_UC_INVLID_VQI_GRP  (0x3F)
#define HAL_STK_MIR_INVLID_VQI_GRP (0x1FF)
#define HAL_STK_CPU_INVLID_VQI_GRP (0x3F)

#define HAL_STK_PATH_PORT_NUM    (16) /* maximum supported port for each path */
#define HAL_STK_PATH_GRP_NUM     (32) /* only clockwise anti-clockwise */
#define HAL_STK_PATH_GRP_MIN     (0)
#define HAL_STK_PATH_GRP_MAX     (HAL_STK_PATH_GRP_MIN + HAL_STK_PATH_GRP_NUM - 1)
#define HAL_STK_INVALID_PATH_GRP (255) /* sw reserved for unconfiged chip path */
#define HAL_STK_PATH_CPU_FAB_NUM (4)
#define HAL_STK_PATH_CPU_FAB_MAX (HAL_STK_PATH_GRP_MIN + HAL_STK_PATH_CPU_FAB_NUM - 1)

#define HAL_STK_UC_SEL_HSH_BITS  (4)
#define HAL_STK_UC_SEL_ENTRY_NUM (1U << HAL_STK_UC_SEL_HSH_BITS)

#define HAL_STK_MC_SEL_HSH_BITS  (10)
#define HAL_STK_MC_SEL_ENTRY_NUM (1U << HAL_STK_MC_SEL_HSH_BITS)
#define HAL_STK_MC_SEL_EPOCH_BIT (HAL_STK_MC_SEL_HSH_BITS)

#define HAL_STK_MIR_SEL_HSH_BITS  (4)
#define HAL_STK_MIR_SEL_ENTRY_NUM (1U << HAL_STK_MIR_SEL_HSH_BITS)

#define HAL_STK_CPU_SEL_HSH_BITS  (4)
#define HAL_STK_CPU_SEL_ENTRY_NUM (1U << HAL_STK_CPU_SEL_HSH_BITS)

#define HAL_STK_LCL_CPI0_CPU_ID (30)
#define HAL_STK_LCL_CPI1_CPU_ID (31)

#define HAL_STK_CPU2CPU_PLANE      (1)
#define HAL_STK_CPU2CPU_PLANE_PORT (33)
#define HAL_STK_CPU2CPU_SUPP_IDX   (135)

#define HAL_STK_FABRIC_PATH_ID_MAX         (254)
#define HAL_STK_PORT_LIST_ENTRY_NUM        (2048)
#define HAL_STK_PORT_LIST_ENTRY_ID_MAX     (HAL_STK_PORT_LIST_ENTRY_NUM - 1)
#define HAL_STK_PORT_LIST_RSVD_INVALID_IDX (0)
#define HAL_STK_FABRIC_PANEL_PATH_PORT_NUM (128) /* Fabric panel path support mbr */
#define HAL_STK_FABRIC_PANEL_PATH_MIN      (HAL_STK_PATH_GRP_MAX + 1)
#define HAL_STK_FABRIC_PANEL_PATH_NUM      (256 - HAL_STK_PATH_GRP_NUM - 1)
#define HAL_STK_FABRIC_PANEL_PATH_MAX \
    (HAL_STK_FABRIC_PANEL_PATH_MIN + HAL_STK_FABRIC_PANEL_PATH_NUM - 1)
#define HAL_STK_PORT_CNT_THRESHOLD (4)
#define HAL_STK_LIST_IS_ORI        (0)
#define HAL_STK_LIST_IS_ACT        (1)
#define HAL_STK_TC_PROFILE_IDX_MAX (7)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_STK_LOCK(unit) \
    HAL_COMMON_LOCK_RESOURCE(&_hal_stk_cb[(unit)].sema_id, CLX_SEMAPHORE_WAIT_FOREVER)

#define HAL_STK_UNLOCK(unit) HAL_COMMON_FREE_RESOURCE(&_hal_stk_cb[(unit)].sema_id)

#define HAL_STK_LCL_DI_TO_DI(__unit__, __chip__, __lcl_di__) \
    ((__chip__) * HAL_PORT_DI_NUM(__unit__) + (__lcl_di__))

#define HAL_STK_LCL_DI_MIN(__unit__) (HAL_GBL_CHIP_IDX(__unit__) * HAL_PORT_DI_NUM(__unit__))
#define HAL_STK_LCL_DI_MAX(__unit__) \
    (((HAL_GBL_CHIP_IDX(__unit__) + 1) * HAL_PORT_DI_NUM(__unit__)) - 1)
#define HAL_STK_IS_LCL_DI(__unit__, __di__) \
    ((HAL_STK_LCL_DI_MIN(__unit__) <= (__di__)) && (HAL_STK_LCL_DI_MAX(__unit__) >= (__di__)))

#define HAL_STK_CHIP_MIN(__unit__) (0)
#define HAL_STK_CHIP_MAX(__unit__)                           \
    ((PTR_HAL_EXT_CHIP_INFO(__unit__)->port_di_mode) ?       \
         (PTR_HAL_CONST_INFO(__unit__, stk)->chip_num - 1) : \
         ((HAL_PHY_PORT_NUM / HAL_PORT_DI_NUM(__unit__)) - 1))

#define HAL_STK_PLANE_BMP_FOREACH(__unit__, __plane__)                          \
    for ((__plane__) = 0; (__plane__) < HAL_PLANE_NUM(__unit__); (__plane__)++) \
        if (UTIL_LIB_BMP_BIT_CHK((HAL_PLANE_BMP((__unit__))), (__plane__)))

#define HAL_STK_DP_PLANE_PORT_ETH_BMP_FOREACH(__pbmp__, __dp_pn_port__)         \
    for ((__dp_pn_port__) = HAL_PLANE_ETH_DP_PORT_MIN;                          \
         (__dp_pn_port__) <= HAL_PLANE_ETH_DP_PORT_MAX_CMN; (__dp_pn_port__)++) \
        if (UTIL_LIB_BMP_BIT_CHK((__pbmp__), (__dp_pn_port__)))

#define HAL_STK_IS_FAB_CHIP(__unit__) \
    (HAL_STK_CHIP_MODE_CHASSIS_FAB == _hal_stk_cb[(__unit__)].chip_mode)

#define HAL_STK_IS_STACKING(__unit__) \
    (HAL_STK_CHIP_MODE_STACKING == _hal_stk_cb[(__unit__)].chip_mode)

#define HAL_STK_IS_PORT_CHIP(__unit__)                                     \
    ((HAL_STK_CHIP_MODE_PORT_CHIP == _hal_stk_cb[(__unit__)].chip_mode) || \
     (HAL_STK_CHIP_MODE_CHASSIS_LC == _hal_stk_cb[(__unit__)].chip_mode))

/* DATA TYPE DECLARATIONS
 */
typedef uint32 HAL_STK_DP_PBMP_T[HAL_ITM_PBM_WORDS];
typedef uint32 HAL_STK_DP_PBMP_OLD_V2_T[8];

typedef enum hal_stk_chip_mode_e {
    HAL_STK_CHIP_MODE_PORT_CHIP = 0,
    HAL_STK_CHIP_MODE_CHASSIS_FAB,
    HAL_STK_CHIP_MODE_CHASSIS_LC,
    HAL_STK_CHIP_MODE_STACKING,
    HAL_STK_CHIP_MODE_LAST
} hal_stk_chip_mode_t;

typedef enum hal_stk_wbdb_e {
    HAL_STK_WBDB_CHIP_MODE,
    HAL_STK_WBDB_PATH_PBMP,
    HAL_STK_WBDB_CPU_PATH_PBMP,
    HAL_STK_WBDB_MY_CHIP_ID,
    HAL_STK_WBDB_DPI_PORT_PBMP,
    HAL_STK_WBDB_CHASSIS_WITH_NB,
    HAL_STK_WBDB_L2UC_CPU_ID,
    HAL_STK_WBDB_L2UC_CPU_QUEUE,
    HAL_STK_WBDB_L3UC_CPU_ID,
    HAL_STK_WBDB_L3UC_CPU_QUEUE,
    HAL_STK_WBDB_FABRIC_PANEL_PATH_INFO,
    HAL_STK_WBDB_PORTLIST_ACT_ALLOC_ARR,
    HAL_STK_WBDB_PORTLIST_ACT_CONT_ENTRY_NUM_ARR,
    HAL_STK_WBDB_PORT_REF,
    HAL_STK_WBDB_PATH_INFO,
    HAL_STK_WBDB_PORTLIST_ORI_ALLOC_ARR,
    HAL_STK_WBDB_PORTLIST_ORI_CONT_ENTRY_NUM_ARR,
    HAL_STK_WBDB_LAST
} hal_stk_wbdb_t;

typedef struct hal_stk_fabric_panel_path_info_s {
    uint32 act_base_idx;
    uint32 act_size;
    uint32 act_list[HAL_STK_FABRIC_PANEL_PATH_PORT_NUM];
    HAL_STK_DP_PBMP_T fabric_panel_path_pbmp;
    uint32 tc_profile;
} hal_stk_fabric_panel_path_info_t;

typedef struct hal_stk_path_info_s {
    uint32 ori_port_cnt;
    uint32 ori_port_list[HAL_STK_PATH_PORT_NUM];
    uint32 hw_ori_base_idx;
    uint32 hw_ori_size;
    uint32 hw_ori_list[HAL_STK_PATH_PORT_NUM * HAL_STK_PATH_PORT_NUM];
    uint32 act_port_cnt;
    uint32 act_port_list[HAL_STK_PATH_PORT_NUM];
    uint32 hw_act_base_idx;
    uint32 hw_act_size;
    uint32 hw_act_list[HAL_STK_PATH_PORT_NUM * HAL_STK_PATH_PORT_NUM];
    uint32 tc_profile;
} hal_stk_path_info_t;

typedef struct hal_stk_cb_s {
    hal_stk_chip_mode_t chip_mode;
    HAL_STK_DP_PBMP_T path_pbmp[HAL_STK_PATH_GRP_NUM];
    HAL_STK_DP_PBMP_T cpu_path_pbmp[HAL_STK_PATH_GRP_NUM];
    HAL_STK_DP_PBMP_T dpi_port_pbmp;
    hal_stk_fabric_panel_path_info_t fabric_panel_path_info[HAL_STK_FABRIC_PANEL_PATH_NUM];
    uint32 port_list_act_alloc_arr[HAL_STK_PORT_LIST_ENTRY_NUM];
    uint32 port_list_act_cont_entry_num_arr[HAL_STK_PORT_LIST_ENTRY_NUM];
    uint32 port_ref[CLX_PORT_NUM];
    hal_stk_path_info_t path_info[HAL_STK_PATH_GRP_NUM];
    uint32 port_list_ori_alloc_arr[HAL_STK_PORT_LIST_ENTRY_NUM];
    uint32 port_list_ori_cont_entry_num_arr[HAL_STK_PORT_LIST_ENTRY_NUM];
    uint32 my_chip_id;
    uint32 chassis_with_nb;
    uint32 *ptr_lag_sel_dma_buf_not_align;
    uint32 *ptr_lag_sel_dma_buf;
    clx_semaphore_id_t sema_id;
    uint16 l2uc_cpu_id;
    uint16 l2uc_cpu_queue;
    uint16 l3uc_cpu_id;
    uint16 l3uc_cpu_queue;
} hal_stk_cb_t;

extern hal_stk_cb_t _hal_stk_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/* GLOBAL VARIABLE DECLARATIONS
 */

/* LOCAL SUBPROGRAM DECLARATIONS
 */
/**
 * @brief Config stacking related register/table.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stk_init(const uint32 unit);

/**
 * @brief Config stacking related register/table.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stk_deinit(const uint32 unit);

/**
 * @brief Get chip id.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_chip    - Device chip id.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_stk_my_chip_id_get(const uint32 unit, uint32 *ptr_chip);

/* EXPORTED HAL PROGRAMS
 */

/**
 * @brief Get fabric port bitmap in hw plane port view.
 *
 * 1. For pp_pbmp size, please reference HAL_ITM_PBM_WORDS.
 *
 * @param [in]     unit           - Device unit number.
 * @param [out]    ptr_pp_pbmp    - Mgid port bitmap (optional).
 * @param [out]    cl_pbmp        - Clx_port_bitmap_t (optional).
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stk_fab_port_bmp_get(const uint32 unit, uint32 *ptr_pp_pbmp, clx_port_bitmap_t cl_pbmp);

/**
 * @brief Check given port is used as fabric port or not.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port 0 : used as front port.
 * @param [out]    ptr_is_fab    - Status.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stk_fab_port_check(const uint32 unit, const uint32 port, boolean *ptr_is_fab);

/**
 * @brief Get path number.
 *
 * @param [in]    unit    - Device unit number.
 * @return        uint32    - Path number.
 */
uint32
hal_stk_path_num_get(const uint32 unit);

/**
 * @brief Initiate the stk configuration.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_stk_cfg_init(const uint32 unit);

/**
 * @brief Get chip mode.
 *
 * @param [in]     unit             - Device unit number.
 * @param [out]    ptr_chip_mode    - Chip mode.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_stk_chip_mode_get(const uint32 unit, uint32 *ptr_chip_mode);

/**
 * @brief Set chip configuration.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    cfg_type        - Chip configuration type.
 * @param [in]    ptr_chip_cfg    - Chip configuration.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stk_chip_cfg_set(const uint32 unit,
                     const clx_stk_chip_cfg_type_t cfg_type,
                     const clx_stk_chip_cfg_t *ptr_chip_cfg);

/**
 * @brief Get chip configuration.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     cfg_type        - Chip configuration type.
 * @param [out]    ptr_chip_cfg    - Chip configuration.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stk_chip_cfg_get(const uint32 unit,
                     const clx_stk_chip_cfg_type_t cfg_type,
                     clx_stk_chip_cfg_t *ptr_chip_cfg);

/**
 * @brief Add fabric port/cpu_port to a path.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    cfg_type        - Port configuration type.
 * @param [in]    ptr_port_cfg    - Port configuration.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stk_fab_port_add(const uint32 unit,
                     const clx_stk_port_cfg_type_t cfg_type,
                     const clx_stk_port_cfg_t *ptr_port_cfg);

/**
 * @brief Delete fabric port/cpu_port from a path.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    cfg_type        - Port configuration type.
 * @param [in]    ptr_port_cfg    - Port configuration.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stk_fab_port_del(const uint32 unit,
                     const clx_stk_port_cfg_type_t cfg_type,
                     const clx_stk_port_cfg_t *ptr_port_cfg);

/**
 * @brief Get fabric port list from a path.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     cfg_type        - Port configuration type.
 * @param [out]    ptr_port_cfg    - Port configuration.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stk_fab_port_get(const uint32 unit,
                     const clx_stk_port_cfg_type_t cfg_type,
                     clx_stk_port_cfg_t *ptr_port_cfg);

/**
 * @brief Set the mapping of path/cpu_path and remote chip.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    cfg_type        - Path configuration type.
 * @param [in]    ptr_path_cfg    - Path configuration.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stk_path_remote_map_set(const uint32 unit,
                            const clx_stk_path_cfg_type_t cfg_type,
                            const clx_stk_path_cfg_t *ptr_path_cfg);

/**
 * @brief Update fabric link group member.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Cl port.
 * @param [in]    link    - Link status.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stk_member_update(const uint32 unit, const uint32 port, const uint32 link);

/**
 * @brief Alloc fabric link group entry index.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    list_flag        - FLG entry list type.
 * @param [in]    alloc_num        - The number of Alloc entry.
 * @param [in]    ptr_alloc_idx    - Base index.
 * @return        CLX_E_OK            - Operate success.
 * @return        CLX_E_TABLE_FULL    - Table full.
 */
clx_error_no_t
hal_stk_portlist_idx_alloc(const uint32 unit,
                           const uint32 list_flag,
                           const uint32 alloc_num,
                           uint32 *ptr_alloc_idx);

/**
 * @brief Free fabric link group entry index.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    list_flag    - FLG entry list type.
 * @param [in]    free_idx     - Base index.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stk_portlist_idx_free(const uint32 unit, const uint32 list_flag, const uint32 free_idx);

/**
 * @brief Get path member ori or act port list and cnt.
 *
 * @param [in]     list_flag        - FLG entry list type.
 * @param [in]     ptr_path_info    - Path member port list and cnt.
 * @param [out]    ptr_path_info    - Path ori port list and cnt.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stk_mbr_size_and_list_get(const uint32 list_flag, hal_stk_path_info_t *ptr_path_info);
/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */
#endif
